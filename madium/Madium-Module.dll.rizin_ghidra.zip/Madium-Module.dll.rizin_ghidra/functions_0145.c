// Chunk 145 - 50 functions

// ============================================================
// Function: FUN_1801eb950
// Address: 0x1801eb950
// Size: 288 bytes
// ============================================================
undefined8 fcn.1801eb950(int64_t arg_28h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 uVar4;
    int32_t in_R8D;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801eb960;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_R8D == 0x2000) {
        if (*(int32_t *)(in_RCX + 0x1538) == 0) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eb98e;
        iVar2 = func_0x0001802446f0(in_RDX, 0x2a, 2);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eb99f;
            iVar2 = func_0x000180244a90(in_RDX, 2);
            if (iVar2 != 0) {
                uVar1 = *(undefined4 *)(in_RCX + 0x1538);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eb9b7;
                iVar2 = func_0x0001802446f0(in_RDX, uVar1, 4);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eb9c3;
                    iVar2 = func_0x000180244000(in_RDX);
                    if (iVar2 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eb9dc;
        func_0x000180229480();
        uVar4 = 0x8b2;
    } else {
        if (*(int32_t *)(in_RCX + 0xb18) != 2) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eba0f;
        iVar2 = func_0x0001802446f0(in_RDX, 0x2a, 2);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eba20;
            iVar2 = func_0x000180244a90(in_RDX, 2);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eba2c;
                iVar2 = func_0x000180244000(in_RDX);
                if (iVar2 != 0) {
                    return 1;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eba35;
        func_0x000180229480();
        uVar4 = 0x8bf;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eba4d;
    func_0x0001802295a0(0x1804b7630, uVar4, 0x1804b7ab8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801eba63;
    func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
    return 0;
}

// ============================================================
// Function: FUN_1801eba70
// Address: 0x1801eba70
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801eba70(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801eba80;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    if ((((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c) & 4) != 0) ||
        ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20) & 8) != 0)) && (*(int64_t *)(in_RCX + 0xa80) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebac5;
        func_0x0001801ab2d0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebad8;
        iVar1 = func_0x0001802446f0(in_RDX, 0xb, 2);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebae9;
            iVar1 = func_0x000180244a90(in_RDX, 2);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebb05;
                iVar1 = func_0x000180244bf0(in_RDX, *(undefined8 *)((int64_t)&var_18h + iVar2), 
                                            *(undefined8 *)((int64_t)&arg_38h + iVar2), 1);
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebb11;
                    iVar1 = func_0x000180244000(in_RDX);
                    if (iVar1 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebb2a;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebb42;
        func_0x0001802295a0(0x1804b7630, 0x67c, 0x1804b78f8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebb58;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801ebb70
// Address: 0x1801ebb70
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ebb70(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ebb80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(uint32_t *)(in_RCX + 0x160) & 0x200) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebbb8;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebbcc;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebbe5;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebbfd;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebc13;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801ebc20
// Address: 0x1801ebc20
// Size: 256 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ebc20(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ebc30;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(in_RCX + 0xb14) != 0) {
        if ((((*(int32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x28) != 0x40) &&
             (iVar1 = *(int32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x24), iVar1 != 4)) && (iVar1 != 0x400)) &&
           (((iVar1 != 0x40000 && (iVar1 != 0x400000)) && (iVar1 != 0x800000)))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebc9e;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebcb2;
                iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebccb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebce3;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ebcf9;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
        *(undefined4 *)(in_RCX + 0xb14) = 0;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801ebd20
// Address: 0x1801ebd20
// Size: 532 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801ebd20(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_80h)
{
    char cVar1;
    undefined2 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801ebd35;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
        if (*(int64_t *)(in_RCX + 0x4e0) != 0) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd6e;
        iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd7f;
            iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd98;
                iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebda4;
                    iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4));
                    if (iVar3 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdc2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdda;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdf0;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x4e0) == 0) {
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe1b;
            iVar3 = fcn.1801b3c40(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4));
            if (iVar3 != 0) {
                return 2;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe24;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe3c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe52;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if ((*(int32_t *)(in_RCX + 0x508) != 0) && ((*(uint8_t *)(in_RCX + 0xb10) & 2) == 0)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe99;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebeae;
        iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebecb;
            iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
            if (iVar3 != 0) {
                uVar2 = *(undefined2 *)(in_RCX + 0x4de);
                uVar7 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebee3;
                iVar5 = fcn.1801ab700(uVar7, uVar2);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebeed;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf05;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf1b;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                    return 0;
                }
                cVar1 = *(char *)(iVar5 + 0x30);
                *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBP;
                if (cVar1 == '\0') {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf47;
                    iVar5 = fcn.1801c6690(*(int64_t *)((int64_t)&var_20h + iVar4));
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf54;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf6c;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf82;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf96;
                    iVar6 = fcn.18022eef0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                          *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_80h + iVar4), 
                                          *(int64_t *)(&stack0x00000090 + iVar4), *(int64_t *)(&stack0x00000098 + iVar4)
                                         );
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfa0;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfb8;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfce;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfd6;
                        fcn.18022ecc0(iVar5);
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebff3;
                    iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4));
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfff;
                        iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                              *(int64_t *)(&stack0x00000038 + iVar4), 
                                              *(int64_t *)(&stack0x00000040 + iVar4), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar4));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec01a;
                            fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b7630, 0x7d3);
                            *(int64_t *)(in_RCX + 0x308) = iVar5;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec035;
                            iVar3 = fcn.1801c5dc0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4));
code_r0x0001801ec152:
                            if (iVar3 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec03f;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec057;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec06d;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec075;
                    fcn.18022ecc0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec08c;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b7630, 2000);
                } else {
                    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0b2;
                    iVar3 = fcn.1801c6010(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)(&stack0x00000088 + iVar4));
                    if (iVar3 == 0) {
                        return 0;
                    }
                    if (*(int64_t *)((int64_t)&arg_30h + iVar4) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0c9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0e1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0f7;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        uVar7 = 0x7ef;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec115;
                        iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec121;
                            iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                                  *(int64_t *)(&stack0x00000038 + iVar4), 
                                                  *(int64_t *)(&stack0x00000040 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar4));
                            if (iVar3 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec13c;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar4), 0x1804b7630, 0x7f9);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec152;
                                iVar3 = fcn.1801c68f0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                                      *(int64_t *)(&stack0x00000038 + iVar4), 
                                                      *(int64_t *)(&stack0x00000040 + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                      *(int64_t *)(&stack0x00000068 + iVar4), 
                                                      *(int64_t *)(&stack0x00000078 + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_80h + iVar4), 
                                                      *(int64_t *)(&stack0x00000100 + iVar4));
                                goto code_r0x0001801ec152;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec17c;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec194;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1aa;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        uVar7 = 0x7f6;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1c1;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar4), 0x1804b7630, uVar7);
                }
                return 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1ca;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1e2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1f8;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801ebf34
// Address: 0x1801ebf34
// Size: 579 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801ebd20(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_80h)
{
    char cVar1;
    undefined2 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801ebd35;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
        if (*(int64_t *)(in_RCX + 0x4e0) != 0) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd6e;
        iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd7f;
            iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd98;
                iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebda4;
                    iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4));
                    if (iVar3 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdc2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdda;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdf0;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x4e0) == 0) {
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe1b;
            iVar3 = fcn.1801b3c40(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4));
            if (iVar3 != 0) {
                return 2;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe24;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe3c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe52;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if ((*(int32_t *)(in_RCX + 0x508) != 0) && ((*(uint8_t *)(in_RCX + 0xb10) & 2) == 0)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe99;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebeae;
        iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebecb;
            iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
            if (iVar3 != 0) {
                uVar2 = *(undefined2 *)(in_RCX + 0x4de);
                uVar7 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebee3;
                iVar5 = fcn.1801ab700(uVar7, uVar2);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebeed;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf05;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf1b;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                    return 0;
                }
                cVar1 = *(char *)(iVar5 + 0x30);
                *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBP;
                if (cVar1 == '\0') {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf47;
                    iVar5 = fcn.1801c6690(*(int64_t *)((int64_t)&var_20h + iVar4));
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf54;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf6c;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf82;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf96;
                    iVar6 = fcn.18022eef0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                          *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_80h + iVar4), 
                                          *(int64_t *)(&stack0x00000090 + iVar4), *(int64_t *)(&stack0x00000098 + iVar4)
                                         );
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfa0;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfb8;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfce;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfd6;
                        fcn.18022ecc0(iVar5);
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebff3;
                    iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4));
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfff;
                        iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                              *(int64_t *)(&stack0x00000038 + iVar4), 
                                              *(int64_t *)(&stack0x00000040 + iVar4), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar4));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec01a;
                            fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b7630, 0x7d3);
                            *(int64_t *)(in_RCX + 0x308) = iVar5;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec035;
                            iVar3 = fcn.1801c5dc0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4));
code_r0x0001801ec152:
                            if (iVar3 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec03f;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec057;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec06d;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec075;
                    fcn.18022ecc0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec08c;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b7630, 2000);
                } else {
                    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0b2;
                    iVar3 = fcn.1801c6010(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)(&stack0x00000088 + iVar4));
                    if (iVar3 == 0) {
                        return 0;
                    }
                    if (*(int64_t *)((int64_t)&arg_30h + iVar4) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0c9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0e1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0f7;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        uVar7 = 0x7ef;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec115;
                        iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec121;
                            iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                                  *(int64_t *)(&stack0x00000038 + iVar4), 
                                                  *(int64_t *)(&stack0x00000040 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar4));
                            if (iVar3 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec13c;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar4), 0x1804b7630, 0x7f9);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec152;
                                iVar3 = fcn.1801c68f0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                                      *(int64_t *)(&stack0x00000038 + iVar4), 
                                                      *(int64_t *)(&stack0x00000040 + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                      *(int64_t *)(&stack0x00000068 + iVar4), 
                                                      *(int64_t *)(&stack0x00000078 + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_80h + iVar4), 
                                                      *(int64_t *)(&stack0x00000100 + iVar4));
                                goto code_r0x0001801ec152;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec17c;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec194;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1aa;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        uVar7 = 0x7f6;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1c1;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar4), 0x1804b7630, uVar7);
                }
                return 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1ca;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1e2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1f8;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801ec177
// Address: 0x1801ec177
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801ebd20(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_80h)
{
    char cVar1;
    undefined2 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801ebd35;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
        if (*(int64_t *)(in_RCX + 0x4e0) != 0) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd6e;
        iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd7f;
            iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd98;
                iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebda4;
                    iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4));
                    if (iVar3 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdc2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdda;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdf0;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x4e0) == 0) {
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe1b;
            iVar3 = fcn.1801b3c40(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4));
            if (iVar3 != 0) {
                return 2;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe24;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe3c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe52;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if ((*(int32_t *)(in_RCX + 0x508) != 0) && ((*(uint8_t *)(in_RCX + 0xb10) & 2) == 0)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe99;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebeae;
        iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebecb;
            iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
            if (iVar3 != 0) {
                uVar2 = *(undefined2 *)(in_RCX + 0x4de);
                uVar7 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebee3;
                iVar5 = fcn.1801ab700(uVar7, uVar2);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebeed;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf05;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf1b;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                    return 0;
                }
                cVar1 = *(char *)(iVar5 + 0x30);
                *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBP;
                if (cVar1 == '\0') {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf47;
                    iVar5 = fcn.1801c6690(*(int64_t *)((int64_t)&var_20h + iVar4));
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf54;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf6c;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf82;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf96;
                    iVar6 = fcn.18022eef0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                          *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_80h + iVar4), 
                                          *(int64_t *)(&stack0x00000090 + iVar4), *(int64_t *)(&stack0x00000098 + iVar4)
                                         );
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfa0;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfb8;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfce;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfd6;
                        fcn.18022ecc0(iVar5);
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebff3;
                    iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4));
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfff;
                        iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                              *(int64_t *)(&stack0x00000038 + iVar4), 
                                              *(int64_t *)(&stack0x00000040 + iVar4), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar4));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec01a;
                            fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b7630, 0x7d3);
                            *(int64_t *)(in_RCX + 0x308) = iVar5;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec035;
                            iVar3 = fcn.1801c5dc0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4));
code_r0x0001801ec152:
                            if (iVar3 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec03f;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec057;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec06d;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec075;
                    fcn.18022ecc0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec08c;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b7630, 2000);
                } else {
                    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0b2;
                    iVar3 = fcn.1801c6010(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)(&stack0x00000088 + iVar4));
                    if (iVar3 == 0) {
                        return 0;
                    }
                    if (*(int64_t *)((int64_t)&arg_30h + iVar4) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0c9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0e1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0f7;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        uVar7 = 0x7ef;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec115;
                        iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec121;
                            iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                                  *(int64_t *)(&stack0x00000038 + iVar4), 
                                                  *(int64_t *)(&stack0x00000040 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar4));
                            if (iVar3 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec13c;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar4), 0x1804b7630, 0x7f9);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec152;
                                iVar3 = fcn.1801c68f0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                                      *(int64_t *)(&stack0x00000038 + iVar4), 
                                                      *(int64_t *)(&stack0x00000040 + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                      *(int64_t *)(&stack0x00000068 + iVar4), 
                                                      *(int64_t *)(&stack0x00000078 + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_80h + iVar4), 
                                                      *(int64_t *)(&stack0x00000100 + iVar4));
                                goto code_r0x0001801ec152;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec17c;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec194;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1aa;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        uVar7 = 0x7f6;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1c1;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar4), 0x1804b7630, uVar7);
                }
                return 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1ca;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1e2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1f8;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801ec1c5
// Address: 0x1801ec1c5
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801ebd20(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_80h)
{
    char cVar1;
    undefined2 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801ebd35;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
        if (*(int64_t *)(in_RCX + 0x4e0) != 0) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd6e;
        iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd7f;
            iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebd98;
                iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebda4;
                    iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4));
                    if (iVar3 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdc2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdda;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebdf0;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x4e0) == 0) {
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe1b;
            iVar3 = fcn.1801b3c40(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4));
            if (iVar3 != 0) {
                return 2;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe24;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe3c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe52;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    if ((*(int32_t *)(in_RCX + 0x508) != 0) && ((*(uint8_t *)(in_RCX + 0xb10) & 2) == 0)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebe99;
    iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebeae;
        iVar3 = fcn.180244a90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebecb;
            iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
            if (iVar3 != 0) {
                uVar2 = *(undefined2 *)(in_RCX + 0x4de);
                uVar7 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebee3;
                iVar5 = fcn.1801ab700(uVar7, uVar2);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebeed;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf05;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf1b;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                    return 0;
                }
                cVar1 = *(char *)(iVar5 + 0x30);
                *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBP;
                if (cVar1 == '\0') {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf47;
                    iVar5 = fcn.1801c6690(*(int64_t *)((int64_t)&var_20h + iVar4));
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf54;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf6c;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf82;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebf96;
                    iVar6 = fcn.18022eef0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                          *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_80h + iVar4), 
                                          *(int64_t *)(&stack0x00000090 + iVar4), *(int64_t *)(&stack0x00000098 + iVar4)
                                         );
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfa0;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfb8;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfce;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfd6;
                        fcn.18022ecc0(iVar5);
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebff3;
                    iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar4));
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ebfff;
                        iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                              *(int64_t *)(&stack0x00000038 + iVar4), 
                                              *(int64_t *)(&stack0x00000040 + iVar4), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar4));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec01a;
                            fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b7630, 0x7d3);
                            *(int64_t *)(in_RCX + 0x308) = iVar5;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec035;
                            iVar3 = fcn.1801c5dc0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4));
code_r0x0001801ec152:
                            if (iVar3 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec03f;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec057;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec06d;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec075;
                    fcn.18022ecc0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec08c;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b7630, 2000);
                } else {
                    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0b2;
                    iVar3 = fcn.1801c6010(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)(&stack0x00000088 + iVar4));
                    if (iVar3 == 0) {
                        return 0;
                    }
                    if (*(int64_t *)((int64_t)&arg_30h + iVar4) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0c9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0e1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec0f7;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        uVar7 = 0x7ef;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec115;
                        iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec121;
                            iVar3 = fcn.180244000(*(int64_t *)((int64_t)&var_20h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                                  *(int64_t *)(&stack0x00000038 + iVar4), 
                                                  *(int64_t *)(&stack0x00000040 + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar4));
                            if (iVar3 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec13c;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar4), 0x1804b7630, 0x7f9);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec152;
                                iVar3 = fcn.1801c68f0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                                      *(int64_t *)(&stack0x00000038 + iVar4), 
                                                      *(int64_t *)(&stack0x00000040 + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                      *(int64_t *)(&stack0x00000068 + iVar4), 
                                                      *(int64_t *)(&stack0x00000078 + iVar4), 
                                                      *(int64_t *)((int64_t)&arg_80h + iVar4), 
                                                      *(int64_t *)(&stack0x00000100 + iVar4));
                                goto code_r0x0001801ec152;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec17c;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec194;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1aa;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                        uVar7 = 0x7f6;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1c1;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar4), 0x1804b7630, uVar7);
                }
                return 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1ca;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1e2;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ec1f8;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801ec210
// Address: 0x1801ec210
// Size: 233 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ec210(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ec220;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (3 < (uint8_t)(*(char *)(*(int64_t *)(in_RCX + 0x8f8) + 0x350) - 1U)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec258;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec269;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec289;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec295;
                iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                      *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec2ae;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec2c6;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec2dc;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801ec300
// Address: 0x1801ec300
// Size: 257 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801ec300(int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ec310;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 0x4b4);
    *(undefined4 *)(in_RCX + 0x4b4) = 0;
    if ((iVar4 != 0) && (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x2e0), pcVar1 != (code *)0x0)) {
        uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x2e8);
        uVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ec35c;
        iVar4 = (*pcVar1)(uVar3, (int64_t)&iStackX_20 + iVar5 + -8, (int64_t)&arg_38h + iVar5, uVar2);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ec377;
            iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar5));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ec393;
                iVar4 = fcn.180244bf0(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                      *(int64_t *)(&stack0x00000048 + iVar5));
                if (iVar4 != 0) {
                    *(undefined4 *)(in_RCX + 0x4b4) = 1;
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ec3b6;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ec3ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ec3e4;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
            return 0;
        }
    }
    return 2;
}

// ============================================================
// Function: FUN_1801ec410
// Address: 0x1801ec410
// Size: 207 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ec410(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ec420;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(in_RCX + 0x508) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec455;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec466;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec47f;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec48b;
                iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                      *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec4a4;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec4bc;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec4d2;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801ec4e0
// Address: 0x1801ec4e0
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ec4e0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ec4f0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(in_RCX + 0x4b0) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec525;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec536;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec547;
            iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec561;
                iVar1 = fcn.1802445f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec57b;
                    iVar1 = fcn.1802445f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                          *(int64_t *)(&stack0x00000058 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec587;
                        iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                              *(int64_t *)(&stack0x00000030 + iVar2), 
                                              *(int64_t *)(&stack0x00000038 + iVar2), 
                                              *(int64_t *)(&stack0x00000040 + iVar2), 
                                              *(int64_t *)(&stack0x00000048 + iVar2), 
                                              *(int64_t *)(&stack0x00000050 + iVar2), 
                                              *(int64_t *)(&stack0x00000058 + iVar2));
                        if (iVar1 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec593;
                            iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                                  *(int64_t *)(&stack0x00000030 + iVar2), 
                                                  *(int64_t *)(&stack0x00000038 + iVar2), 
                                                  *(int64_t *)(&stack0x00000040 + iVar2), 
                                                  *(int64_t *)(&stack0x00000048 + iVar2), 
                                                  *(int64_t *)(&stack0x00000050 + iVar2), 
                                                  *(int64_t *)(&stack0x00000058 + iVar2));
                            if (iVar1 != 0) {
                                return 1;
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec5ac;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec5c4;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec5da;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801ec5f0
// Address: 0x1801ec5f0
// Size: 266 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ec5f0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ec600;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(char *)(in_RCX + 0xb52) == '\0') {
        *(undefined *)(in_RCX + 0xb53) = 0;
        return 2;
    }
    if ((*(char *)(in_RCX + 0xb53) == '\x01') && (*(int64_t *)(in_RCX + 0x15a0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec657;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec668;
            iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec681;
                iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec68d;
                    iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2)
                                          , *(int64_t *)(&stack0x00000040 + iVar2), 
                                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2)
                                          , *(int64_t *)(&stack0x00000058 + iVar2));
                    if (iVar1 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec6a6;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec6be;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec6d4;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined2 *)(in_RCX + 0xb52) = 0;
    return 2;
}

// ============================================================
// Function: FUN_1801ec700
// Address: 0x1801ec700
// Size: 220 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ec700(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ec710;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(int32_t *)(in_RCX + 0xb60) == 1) &&
       ((*(int32_t *)(in_RCX + 0x508) == 0 ||
        ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
          (iVar1 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar1)) && (iVar1 != 0x10000)))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec764;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec778;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec791;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec7a9;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec7bf;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801ec7e0
// Address: 0x1801ec7e0
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ec7e0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ec7f0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(in_RCX + 0xa60) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec80b;
        iVar1 = fcn.1801adc40();
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec822;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec836;
                iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec84f;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec867;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec87d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    }
    *(undefined4 *)(in_RCX + 0xa60) = 0;
    return 2;
}

// ============================================================
// Function: FUN_1801ec8b0
// Address: 0x1801ec8b0
// Size: 324 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ec8b0(int64_t arg_28h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ec8c0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_R8D == 0x4000) || (*(int32_t *)(in_RCX + 0xa34) == 0)) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec8f6;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec90b;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                (iVar1 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar1)) && (iVar1 != 0x10000)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec944;
                iVar1 = func_0x0001801b6ff0(in_RCX, *(undefined8 *)((int64_t)&arg_48h + iVar2), in_RDX);
                if (iVar1 == 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec950;
            iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec959;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec971;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec987;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0;
            }
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec9a9;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec9c1;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ec9d7;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801eca00
// Address: 0x1801eca00
// Size: 584 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801eca00(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_b8h)
{
    int16_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801eca1c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar8 = 1;
    if (*(int16_t *)(in_RCX + 0x4de) == 0) {
code_r0x0001801ecc29:
        uVar6 = 2;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801eca48;
        func_0x0001801ab620();
        if (*(int64_t *)((int64_t)&arg_48h + iVar5) == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801eca55;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801eca6d;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5), 
                          *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801eca83;
            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
            uVar6 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801eca92;
            uVar3 = func_0x000180194ed0(in_RCX);
            uVar7 = 0;
            if (*(int64_t *)((int64_t)&arg_48h + iVar5) != 0) {
                do {
                    iVar2 = *(int64_t *)((int64_t)&var_8h + iVar5);
                    *(undefined8 *)((int64_t)&iStackX_20 + iVar5 + -0x20) = 0;
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar5) = 0;
                    iVar1 = *(int16_t *)(iVar2 + uVar7 * 2);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecad4;
                    iVar4 = func_0x0001801adc80(in_RCX, iVar1, uVar3, uVar3);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecae9;
                        iVar4 = func_0x0001801ada30(in_RCX, iVar1, 0x20004);
                        if (iVar4 != 0) {
                            if (uVar8 != 0) {
                                if (*(int16_t *)(in_RCX + 0x4de) == iVar1) goto code_r0x0001801ecc29;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecb12;
                                iVar4 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar5), 
                                                      *(int64_t *)(&stack0x00000038 + iVar5));
                                if (iVar4 == 0) {
code_r0x0001801ecb84:
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecb89;
                                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecba1;
                                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar5), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                  *(int64_t *)(&stack0x00000028 + iVar5));
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecbb7;
                                    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
                                    return 0;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecb23;
                                iVar4 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
                                if (iVar4 == 0) goto code_r0x0001801ecb84;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecb34;
                                iVar4 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
                                uVar8 = 0;
                                if (iVar4 == 0) goto code_r0x0001801ecb84;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecb4c;
                            iVar4 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar5), 
                                                  *(int64_t *)(&stack0x00000038 + iVar5));
                            if (iVar4 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecbc0;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecbd8;
                                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                              *(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)(&stack0x00000028 + iVar5));
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecbee;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
                                return 0;
                            }
                        }
                    }
                    uVar7 = uVar7 + 1;
                } while (uVar7 < *(uint64_t *)((int64_t)&arg_48h + iVar5));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecb66;
            iVar4 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                  *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                                  *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecb76;
                iVar4 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                      *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5)
                                      , *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5));
                if (iVar4 != 0) {
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecbf7;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecc0f;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5), 
                          *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ecc25;
            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
            uVar6 = 0;
        }
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801ecc50
// Address: 0x1801ecc50
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ecc50(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ecc60;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar1 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar1)) && (iVar1 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecc9d;
        iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eccae;
            iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eccc4;
                iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eccd0;
                    iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2)
                                          , *(int64_t *)(&stack0x00000040 + iVar2), 
                                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2)
                                          , *(int64_t *)(&stack0x00000058 + iVar2));
                    if (iVar1 != 0) {
                        return 1;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecce9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eccf5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecd0d;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecd23;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801ecd30
// Address: 0x1801ecd30
// Size: 251 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801ecd30(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ecd40;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0xb98) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecd76;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecd87;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecd9b;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecdb7;
                iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecdcb;
                    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                          *(int64_t *)(&stack0x00000058 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecdd7;
                        iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                              *(int64_t *)(&stack0x00000030 + iVar2), 
                                              *(int64_t *)(&stack0x00000038 + iVar2), 
                                              *(int64_t *)(&stack0x00000040 + iVar2), 
                                              *(int64_t *)(&stack0x00000048 + iVar2), 
                                              *(int64_t *)(&stack0x00000050 + iVar2), 
                                              *(int64_t *)(&stack0x00000058 + iVar2));
                        if (iVar1 != 0) {
                            return 1;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ecdf0;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ece08;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ece1e;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801ece30
// Address: 0x1801ece30
// Size: 162 bytes
// ============================================================
undefined8 fcn.1801ece30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_80h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    undefined *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    int64_t iVar10;
    undefined8 *in_RDX;
    uint8_t *puVar11;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    int64_t iVar13;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ece3c;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if ((*(int64_t *)(in_RCX + 0x260) != 0) && (*(int64_t *)(in_RCX + 0x2e8) != 0)) {
        return 1;
    }
    puVar3 = (undefined *)*in_RDX;
    uVar1 = in_RDX[1];
    uVar12 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar8) = puVar3;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = uVar1;
    if (1 < uVar12) {
        uVar12 = uVar12 - 2;
        puVar11 = puVar3 + 2;
        uVar9 = (uint64_t)CONCAT11(*puVar3, puVar3[1]);
        if (uVar9 <= uVar12) {
            iVar13 = uVar12 - uVar9;
            *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11 + uVar9;
            *(int64_t *)((int64_t)&var_20h + iVar8) = iVar13;
            if (iVar13 == 0) {
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar8);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar8 + 4);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar8);
                uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar8 + 4);
                *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11;
                *(uint64_t *)((int64_t)&var_20h + iVar8) = uVar9;
                *(undefined4 *)in_RDX = uVar4;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar5;
                *(undefined4 *)(in_RDX + 1) = uVar6;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar7;
                if (1 < uVar9) {
                    auVar2._4_4_ = unaff_XMM6_Db;
                    auVar2._0_4_ = unaff_XMM6_Da;
                    auVar2._8_4_ = unaff_XMM6_Dc;
                    auVar2._12_4_ = unaff_XMM6_Dd;
                    *(undefined (*) [16])((int64_t)&arg_38h + iVar8) = auVar2;
                    iVar13 = *(int64_t *)((int64_t)&var_20h + iVar8);
                    while (uVar9 != 0) {
                        uVar12 = (uint64_t)*puVar11;
                        if (uVar9 - 1 < uVar12) break;
                        iVar10 = (uVar9 - 1) - uVar12;
                        *(uint8_t **)((int64_t)&arg_28h + iVar8) = puVar11 + uVar12 + 1;
                        *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar10;
                        uVar4 = *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4);
                        uVar5 = *(undefined4 *)((int64_t)&arg_30h + iVar8);
                        uVar6 = *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4);
                        *(undefined4 *)((int64_t)&var_18h + iVar8) = *(undefined4 *)((int64_t)&arg_28h + iVar8);
                        *(undefined4 *)((int64_t)&var_18h + iVar8 + 4) = uVar4;
                        *(undefined4 *)((int64_t)&var_20h + iVar8) = uVar5;
                        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = uVar6;
                        if (uVar12 == 0) break;
                        if (iVar10 == 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0x4c8);
                            *(undefined8 *)((int64_t)&arg_58h + iVar8) = unaff_RDI;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf4f;
                            fcn.180224990(uVar1, 0x1804b7630, 0x1df);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf73;
                            fcn.180224990(0, 0x1804a9450, 0x1d9);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            if (iVar13 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfae;
                                iVar10 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar8));
                                *(int64_t *)(in_RCX + 0x4c8) = iVar10;
                                if (iVar10 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfdb;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecff3;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                  *(int64_t *)(&stack0x00000048 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed009;
                                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                                    return 0;
                                }
                                *(int64_t *)(in_RCX + 0x4d0) = iVar13;
                            }
                            return 1;
                        }
                        puVar11 = *(uint8_t **)((int64_t)&var_18h + iVar8);
                        uVar9 = *(uint64_t *)((int64_t)&var_20h + iVar8);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed020;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed038;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed04e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed060;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed078;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed08e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_1801eced2
// Address: 0x1801eced2
// Size: 260 bytes
// ============================================================
undefined8 fcn.1801ece30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_80h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    undefined *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    int64_t iVar10;
    undefined8 *in_RDX;
    uint8_t *puVar11;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    int64_t iVar13;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ece3c;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if ((*(int64_t *)(in_RCX + 0x260) != 0) && (*(int64_t *)(in_RCX + 0x2e8) != 0)) {
        return 1;
    }
    puVar3 = (undefined *)*in_RDX;
    uVar1 = in_RDX[1];
    uVar12 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar8) = puVar3;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = uVar1;
    if (1 < uVar12) {
        uVar12 = uVar12 - 2;
        puVar11 = puVar3 + 2;
        uVar9 = (uint64_t)CONCAT11(*puVar3, puVar3[1]);
        if (uVar9 <= uVar12) {
            iVar13 = uVar12 - uVar9;
            *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11 + uVar9;
            *(int64_t *)((int64_t)&var_20h + iVar8) = iVar13;
            if (iVar13 == 0) {
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar8);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar8 + 4);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar8);
                uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar8 + 4);
                *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11;
                *(uint64_t *)((int64_t)&var_20h + iVar8) = uVar9;
                *(undefined4 *)in_RDX = uVar4;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar5;
                *(undefined4 *)(in_RDX + 1) = uVar6;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar7;
                if (1 < uVar9) {
                    auVar2._4_4_ = unaff_XMM6_Db;
                    auVar2._0_4_ = unaff_XMM6_Da;
                    auVar2._8_4_ = unaff_XMM6_Dc;
                    auVar2._12_4_ = unaff_XMM6_Dd;
                    *(undefined (*) [16])((int64_t)&arg_38h + iVar8) = auVar2;
                    iVar13 = *(int64_t *)((int64_t)&var_20h + iVar8);
                    while (uVar9 != 0) {
                        uVar12 = (uint64_t)*puVar11;
                        if (uVar9 - 1 < uVar12) break;
                        iVar10 = (uVar9 - 1) - uVar12;
                        *(uint8_t **)((int64_t)&arg_28h + iVar8) = puVar11 + uVar12 + 1;
                        *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar10;
                        uVar4 = *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4);
                        uVar5 = *(undefined4 *)((int64_t)&arg_30h + iVar8);
                        uVar6 = *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4);
                        *(undefined4 *)((int64_t)&var_18h + iVar8) = *(undefined4 *)((int64_t)&arg_28h + iVar8);
                        *(undefined4 *)((int64_t)&var_18h + iVar8 + 4) = uVar4;
                        *(undefined4 *)((int64_t)&var_20h + iVar8) = uVar5;
                        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = uVar6;
                        if (uVar12 == 0) break;
                        if (iVar10 == 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0x4c8);
                            *(undefined8 *)((int64_t)&arg_58h + iVar8) = unaff_RDI;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf4f;
                            fcn.180224990(uVar1, 0x1804b7630, 0x1df);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf73;
                            fcn.180224990(0, 0x1804a9450, 0x1d9);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            if (iVar13 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfae;
                                iVar10 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar8));
                                *(int64_t *)(in_RCX + 0x4c8) = iVar10;
                                if (iVar10 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfdb;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecff3;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                  *(int64_t *)(&stack0x00000048 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed009;
                                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                                    return 0;
                                }
                                *(int64_t *)(in_RCX + 0x4d0) = iVar13;
                            }
                            return 1;
                        }
                        puVar11 = *(uint8_t **)((int64_t)&var_18h + iVar8);
                        uVar9 = *(uint64_t *)((int64_t)&var_20h + iVar8);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed020;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed038;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed04e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed060;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed078;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed08e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_1801ecfd6
// Address: 0x1801ecfd6
// Size: 69 bytes
// ============================================================
undefined8 fcn.1801ece30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_80h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    undefined *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    int64_t iVar10;
    undefined8 *in_RDX;
    uint8_t *puVar11;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    int64_t iVar13;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ece3c;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if ((*(int64_t *)(in_RCX + 0x260) != 0) && (*(int64_t *)(in_RCX + 0x2e8) != 0)) {
        return 1;
    }
    puVar3 = (undefined *)*in_RDX;
    uVar1 = in_RDX[1];
    uVar12 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar8) = puVar3;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = uVar1;
    if (1 < uVar12) {
        uVar12 = uVar12 - 2;
        puVar11 = puVar3 + 2;
        uVar9 = (uint64_t)CONCAT11(*puVar3, puVar3[1]);
        if (uVar9 <= uVar12) {
            iVar13 = uVar12 - uVar9;
            *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11 + uVar9;
            *(int64_t *)((int64_t)&var_20h + iVar8) = iVar13;
            if (iVar13 == 0) {
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar8);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar8 + 4);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar8);
                uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar8 + 4);
                *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11;
                *(uint64_t *)((int64_t)&var_20h + iVar8) = uVar9;
                *(undefined4 *)in_RDX = uVar4;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar5;
                *(undefined4 *)(in_RDX + 1) = uVar6;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar7;
                if (1 < uVar9) {
                    auVar2._4_4_ = unaff_XMM6_Db;
                    auVar2._0_4_ = unaff_XMM6_Da;
                    auVar2._8_4_ = unaff_XMM6_Dc;
                    auVar2._12_4_ = unaff_XMM6_Dd;
                    *(undefined (*) [16])((int64_t)&arg_38h + iVar8) = auVar2;
                    iVar13 = *(int64_t *)((int64_t)&var_20h + iVar8);
                    while (uVar9 != 0) {
                        uVar12 = (uint64_t)*puVar11;
                        if (uVar9 - 1 < uVar12) break;
                        iVar10 = (uVar9 - 1) - uVar12;
                        *(uint8_t **)((int64_t)&arg_28h + iVar8) = puVar11 + uVar12 + 1;
                        *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar10;
                        uVar4 = *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4);
                        uVar5 = *(undefined4 *)((int64_t)&arg_30h + iVar8);
                        uVar6 = *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4);
                        *(undefined4 *)((int64_t)&var_18h + iVar8) = *(undefined4 *)((int64_t)&arg_28h + iVar8);
                        *(undefined4 *)((int64_t)&var_18h + iVar8 + 4) = uVar4;
                        *(undefined4 *)((int64_t)&var_20h + iVar8) = uVar5;
                        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = uVar6;
                        if (uVar12 == 0) break;
                        if (iVar10 == 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0x4c8);
                            *(undefined8 *)((int64_t)&arg_58h + iVar8) = unaff_RDI;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf4f;
                            fcn.180224990(uVar1, 0x1804b7630, 0x1df);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf73;
                            fcn.180224990(0, 0x1804a9450, 0x1d9);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            if (iVar13 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfae;
                                iVar10 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar8));
                                *(int64_t *)(in_RCX + 0x4c8) = iVar10;
                                if (iVar10 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfdb;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecff3;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                  *(int64_t *)(&stack0x00000048 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed009;
                                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                                    return 0;
                                }
                                *(int64_t *)(in_RCX + 0x4d0) = iVar13;
                            }
                            return 1;
                        }
                        puVar11 = *(uint8_t **)((int64_t)&var_18h + iVar8);
                        uVar9 = *(uint64_t *)((int64_t)&var_20h + iVar8);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed020;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed038;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed04e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed060;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed078;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed08e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_1801ed01b
// Address: 0x1801ed01b
// Size: 64 bytes
// ============================================================
undefined8 fcn.1801ece30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_80h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    undefined *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    int64_t iVar10;
    undefined8 *in_RDX;
    uint8_t *puVar11;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    int64_t iVar13;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ece3c;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if ((*(int64_t *)(in_RCX + 0x260) != 0) && (*(int64_t *)(in_RCX + 0x2e8) != 0)) {
        return 1;
    }
    puVar3 = (undefined *)*in_RDX;
    uVar1 = in_RDX[1];
    uVar12 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar8) = puVar3;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = uVar1;
    if (1 < uVar12) {
        uVar12 = uVar12 - 2;
        puVar11 = puVar3 + 2;
        uVar9 = (uint64_t)CONCAT11(*puVar3, puVar3[1]);
        if (uVar9 <= uVar12) {
            iVar13 = uVar12 - uVar9;
            *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11 + uVar9;
            *(int64_t *)((int64_t)&var_20h + iVar8) = iVar13;
            if (iVar13 == 0) {
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar8);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar8 + 4);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar8);
                uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar8 + 4);
                *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11;
                *(uint64_t *)((int64_t)&var_20h + iVar8) = uVar9;
                *(undefined4 *)in_RDX = uVar4;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar5;
                *(undefined4 *)(in_RDX + 1) = uVar6;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar7;
                if (1 < uVar9) {
                    auVar2._4_4_ = unaff_XMM6_Db;
                    auVar2._0_4_ = unaff_XMM6_Da;
                    auVar2._8_4_ = unaff_XMM6_Dc;
                    auVar2._12_4_ = unaff_XMM6_Dd;
                    *(undefined (*) [16])((int64_t)&arg_38h + iVar8) = auVar2;
                    iVar13 = *(int64_t *)((int64_t)&var_20h + iVar8);
                    while (uVar9 != 0) {
                        uVar12 = (uint64_t)*puVar11;
                        if (uVar9 - 1 < uVar12) break;
                        iVar10 = (uVar9 - 1) - uVar12;
                        *(uint8_t **)((int64_t)&arg_28h + iVar8) = puVar11 + uVar12 + 1;
                        *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar10;
                        uVar4 = *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4);
                        uVar5 = *(undefined4 *)((int64_t)&arg_30h + iVar8);
                        uVar6 = *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4);
                        *(undefined4 *)((int64_t)&var_18h + iVar8) = *(undefined4 *)((int64_t)&arg_28h + iVar8);
                        *(undefined4 *)((int64_t)&var_18h + iVar8 + 4) = uVar4;
                        *(undefined4 *)((int64_t)&var_20h + iVar8) = uVar5;
                        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = uVar6;
                        if (uVar12 == 0) break;
                        if (iVar10 == 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0x4c8);
                            *(undefined8 *)((int64_t)&arg_58h + iVar8) = unaff_RDI;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf4f;
                            fcn.180224990(uVar1, 0x1804b7630, 0x1df);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf73;
                            fcn.180224990(0, 0x1804a9450, 0x1d9);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            if (iVar13 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfae;
                                iVar10 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar8));
                                *(int64_t *)(in_RCX + 0x4c8) = iVar10;
                                if (iVar10 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfdb;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecff3;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                  *(int64_t *)(&stack0x00000048 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed009;
                                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                                    return 0;
                                }
                                *(int64_t *)(in_RCX + 0x4d0) = iVar13;
                            }
                            return 1;
                        }
                        puVar11 = *(uint8_t **)((int64_t)&var_18h + iVar8);
                        uVar9 = *(uint64_t *)((int64_t)&var_20h + iVar8);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed020;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed038;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed04e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed060;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed078;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed08e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_1801ed05b
// Address: 0x1801ed05b
// Size: 59 bytes
// ============================================================
undefined8 fcn.1801ece30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_80h)
{
    undefined8 uVar1;
    undefined auVar2 [16];
    undefined *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    int64_t iVar10;
    undefined8 *in_RDX;
    uint8_t *puVar11;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    int64_t iVar13;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ece3c;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if ((*(int64_t *)(in_RCX + 0x260) != 0) && (*(int64_t *)(in_RCX + 0x2e8) != 0)) {
        return 1;
    }
    puVar3 = (undefined *)*in_RDX;
    uVar1 = in_RDX[1];
    uVar12 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar8) = puVar3;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = uVar1;
    if (1 < uVar12) {
        uVar12 = uVar12 - 2;
        puVar11 = puVar3 + 2;
        uVar9 = (uint64_t)CONCAT11(*puVar3, puVar3[1]);
        if (uVar9 <= uVar12) {
            iVar13 = uVar12 - uVar9;
            *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11 + uVar9;
            *(int64_t *)((int64_t)&var_20h + iVar8) = iVar13;
            if (iVar13 == 0) {
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar8);
                uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar8 + 4);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar8);
                uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar8 + 4);
                *(uint8_t **)((int64_t)&var_18h + iVar8) = puVar11;
                *(uint64_t *)((int64_t)&var_20h + iVar8) = uVar9;
                *(undefined4 *)in_RDX = uVar4;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar5;
                *(undefined4 *)(in_RDX + 1) = uVar6;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar7;
                if (1 < uVar9) {
                    auVar2._4_4_ = unaff_XMM6_Db;
                    auVar2._0_4_ = unaff_XMM6_Da;
                    auVar2._8_4_ = unaff_XMM6_Dc;
                    auVar2._12_4_ = unaff_XMM6_Dd;
                    *(undefined (*) [16])((int64_t)&arg_38h + iVar8) = auVar2;
                    iVar13 = *(int64_t *)((int64_t)&var_20h + iVar8);
                    while (uVar9 != 0) {
                        uVar12 = (uint64_t)*puVar11;
                        if (uVar9 - 1 < uVar12) break;
                        iVar10 = (uVar9 - 1) - uVar12;
                        *(uint8_t **)((int64_t)&arg_28h + iVar8) = puVar11 + uVar12 + 1;
                        *(int64_t *)((int64_t)&arg_30h + iVar8) = iVar10;
                        uVar4 = *(undefined4 *)((int64_t)&arg_28h + iVar8 + 4);
                        uVar5 = *(undefined4 *)((int64_t)&arg_30h + iVar8);
                        uVar6 = *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4);
                        *(undefined4 *)((int64_t)&var_18h + iVar8) = *(undefined4 *)((int64_t)&arg_28h + iVar8);
                        *(undefined4 *)((int64_t)&var_18h + iVar8 + 4) = uVar4;
                        *(undefined4 *)((int64_t)&var_20h + iVar8) = uVar5;
                        *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = uVar6;
                        if (uVar12 == 0) break;
                        if (iVar10 == 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0x4c8);
                            *(undefined8 *)((int64_t)&arg_58h + iVar8) = unaff_RDI;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf4f;
                            fcn.180224990(uVar1, 0x1804b7630, 0x1df);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecf73;
                            fcn.180224990(0, 0x1804a9450, 0x1d9);
                            *(undefined8 *)(in_RCX + 0x4c8) = 0;
                            *(undefined8 *)(in_RCX + 0x4d0) = 0;
                            if (iVar13 != 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfae;
                                iVar10 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar8));
                                *(int64_t *)(in_RCX + 0x4c8) = iVar10;
                                if (iVar10 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecfdb;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ecff3;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), 
                                                  *(int64_t *)((int64_t)&var_20h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                                  *(int64_t *)(&stack0x00000048 + iVar8));
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed009;
                                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                                    return 0;
                                }
                                *(int64_t *)(in_RCX + 0x4d0) = iVar13;
                            }
                            return 1;
                        }
                        puVar11 = *(uint8_t **)((int64_t)&var_18h + iVar8);
                        uVar9 = *(uint64_t *)((int64_t)&var_20h + iVar8);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed020;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed038;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                  *(int64_t *)(&stack0x00000048 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed04e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed060;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed078;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ed08e;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_1801ed0a0
// Address: 0x1801ed0a0
// Size: 257 bytes
// ============================================================
undefined8 fcn.1801ed0a0(int64_t arg_28h, int64_t arg_30h)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint8_t *puVar7;
    int64_t iVar8;
    uint8_t **in_RDX;
    uint8_t *puVar9;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ed0ac;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int64_t *)(in_RCX + 0x1590) == 0) {
        *(undefined2 *)(in_RCX + 0xb50) = 0;
        return 1;
    }
    puVar1 = *in_RDX;
    puVar9 = in_RDX[1];
    puVar7 = in_RDX[1];
    *(uint8_t **)((int64_t)&arg_28h + iVar6) = puVar1;
    *(uint8_t **)((int64_t)&arg_30h + iVar6) = puVar9;
    if (puVar7 != (uint8_t *)0x0) {
        puVar7 = puVar7 + -1;
        puVar9 = (uint8_t *)(uint64_t)*puVar1;
        if (puVar9 <= puVar7) {
            iVar8 = (int64_t)puVar7 - (int64_t)puVar9;
            *(uint8_t **)((int64_t)&arg_28h + iVar6) = puVar9 + (int64_t)(puVar1 + 1);
            *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar8;
            if (iVar8 == 0) {
                uVar2 = *(undefined4 *)((int64_t)&arg_28h + iVar6 + 4);
                uVar3 = *(undefined4 *)((int64_t)&arg_30h + iVar6);
                uVar4 = *(undefined4 *)((int64_t)&arg_30h + iVar6 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&arg_28h + iVar6);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar2;
                *(undefined4 *)(in_RDX + 1) = uVar3;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar4;
                if (puVar9 != (uint8_t *)0x0) {
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = in_RCX + 0xb50;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ed14e;
                    uVar5 = fcn.1801eaef0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)(&stack0x00000038 + iVar6));
                    *(undefined *)(in_RCX + 0xb51) = uVar5;
                    return 1;
                }
                *(undefined *)(in_RCX + 0xb51) = 2;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ed125;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                goto code_r0x0001801ed170;
            }
        }
    }
    *(undefined *)(in_RCX + 0xb51) = 2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ed16b;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
code_r0x0001801ed170:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ed183;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ed199;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801ed1b0
// Address: 0x1801ed1b0
// Size: 2626 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_11c8h because it doesn't fit into ProtoModel

void fcn.1801ed1b0(int64_t param_1, int64_t *param_2)
{
    undefined *puVar1;
    uint8_t uVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    code *pcVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iStackX_8;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_1168h;
    int64_t var_1160h;
    int64_t var_1158h;
    int64_t var_1150h;
    int64_t var_1148h;
    int64_t var_1140h;
    int64_t var_1118h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x1801ed1d2;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9);
    puVar3 = *(undefined8 **)(param_1 + 8);
    if ((puVar3[0x1d] == 0) || ((*(uint32_t *)(param_1 + 0x160) & 0x800) == 0)) goto code_r0x0001801ed8d5;
    puVar7 = (undefined *)*param_2;
    var_1160h = (int64_t)puVar7;
    var_1158h = param_2[1];
    if (1 < (uint64_t)param_2[1]) {
        uVar12 = param_2[1] - 2;
        puVar1 = puVar7 + 2;
        uVar13 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
        if (uVar13 <= uVar12) {
            var_1158h = uVar12 - uVar13;
            var_1160h = (int64_t)(puVar1 + uVar13);
            if (var_1158h == 0) {
                *param_2 = (int64_t)(puVar1 + uVar13);
                param_2[1] = 0;
                if ((uVar13 < 0x20) || (uVar12 = uVar13 - 0x20, uVar13 < uVar12)) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb83;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb9b;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edbb1;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                    goto code_r0x0001801ed8d5;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed27c;
                iVar10 = func_0x000180215470();
                iVar11 = *(int64_t *)(param_1 + 0xb88);
                uVar4 = puVar3[0x8c];
                uVar5 = *puVar3;
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) = 0x20;
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed2ad;
                iVar11 = func_0x00018022fea0(uVar5, 0x1804af24c, uVar4, iVar11 + 0x300);
                if ((iVar10 == 0) || (iVar11 == 0)) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb3c;
                    func_0x000180215310(iVar10);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb44;
                    fcn.18022ecc0(iVar11);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb49;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb61;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                  *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb77;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                    goto code_r0x0001801ed8d5;
                }
                var_1168h = 0x20;
                uVar4 = puVar3[0x8c];
                uVar5 = *puVar3;
                *(undefined8 *)((int64_t)&var_8h + iVar9) = 0;
                *(int64_t *)((int64_t)&var_10h + iVar9) = iVar11;
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar9) = uVar4;
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed2f9;
                iVar8 = func_0x00018025c2e0(iVar10, 0, 0x1804b30b0, uVar5);
                if (0 < iVar8) {
                    *(uint64_t *)(&stack0xffffffffffffffe8 + iVar9) = uVar12;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed319;
                    iVar8 = func_0x00018025bc60(iVar10, &var_1140h, &var_1168h, puVar1);
                    if ((0 < iVar8) && (var_1168h == 0x20)) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed334;
                        func_0x000180215310(iVar10);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed33c;
                        fcn.18022ecc0(iVar11);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed34f;
                        iVar8 = func_0x0001802262e0(&var_1140h, puVar1 + uVar12, 0x20);
                        if (iVar8 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed358;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed370;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed386;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                            goto code_r0x0001801ed8d5;
                        }
                        if (CONCAT11(*puVar1, puVar7[3]) != 1) goto code_r0x0001801ed8d5;
                        if (uVar13 - 2 < 2) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edab5;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edacd;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edae3;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                            goto code_r0x0001801ed8d5;
                        }
                        if (CONCAT11(puVar7[4], puVar7[5]) != 0x304) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed3d2;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed3ea;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed400;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                            goto code_r0x0001801ed8d5;
                        }
                        if (uVar13 - 4 < 2) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801eda7b;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801eda93;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edaa9;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                            goto code_r0x0001801ed8d5;
                        }
                        if (uVar13 - 6 < 2) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801eda41;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801eda59;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                          *(int64_t *)((int64_t)&var_10h + iVar9), 
                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801eda6f;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                            goto code_r0x0001801ed8d5;
                        }
                        if (CONCAT11(puVar7[6], puVar7[7]) == *(int16_t *)(param_1 + 0x4de)) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed450;
                            iVar11 = func_0x0001801a0300(param_1, puVar7 + 8, 0);
                            if (*(int64_t *)(param_1 + 0x300) == iVar11) {
                                if (((uVar13 != 8) &&
                                    (*(undefined *)((int64_t)&iStackX_8 + iVar9) = puVar7[10], 7 < uVar13 - 9)) &&
                                   (uVar12 = CONCAT71(CONCAT61(CONCAT51(CONCAT41(CONCAT31(CONCAT21(CONCAT11(puVar7[0xb]
                                                                                                            , puVar7[0xc
                                                            ]), puVar7[0xd]), puVar7[0xe]), puVar7[0xf]), puVar7[0x10])
                                                            , puVar7[0x11]), puVar7[0x12]), 1 < uVar13 - 0x11)) {
                                    uVar14 = (uint64_t)CONCAT11(puVar7[0x13], puVar7[0x14]);
                                    var_1150h = (int64_t)(puVar7 + 0x15);
                                    if ((uVar14 <= uVar13 - 0x13) && (iVar11 = (uVar13 - 0x13) - uVar14, iVar11 != 0)) {
                                        uVar2 = (puVar7 + 0x15)[uVar14];
                                        uVar13 = iVar11 - 1;
                                        if ((uVar2 <= uVar13) && (uVar13 - uVar2 == 0x20)) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed538;
                                            uVar13 = func_0x000180467bd4(0);
                                            iVar11 = var_1150h;
                                            if ((uVar13 < uVar12) || (600 < uVar13 - uVar12)) goto code_r0x0001801ed8d5;
                                            pcVar6 = (code *)puVar3[0x1d];
                                            uVar4 = *(undefined8 *)(param_1 + 0x40);
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed56b;
                                            iVar8 = (*pcVar6)(uVar4, var_1150h + 1 + uVar14, uVar2);
                                            if (iVar8 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed574;
                                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                              *(int64_t *)((int64_t)&var_10h + iVar9));
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed58c;
                                                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                              *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                              *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed5a2;
                                                fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                                                goto code_r0x0001801ed8d5;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed5c0;
                                            iVar8 = func_0x000180244550((int64_t)&iStackX_10 + iVar9, &var_1118h, 0x10cc
                                                                        , 0);
                                            if (iVar8 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed5c9;
                                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                              *(int64_t *)((int64_t)&var_10h + iVar9));
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed5e1;
                                                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                              *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                              *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed5f7;
                                                fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                                                goto code_r0x0001801ed8d5;
                                            }
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed613;
                                            iVar8 = fcn.1802446f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                                  *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                                  *(int64_t *)(&stack0x00000028 + iVar9));
                                            if (iVar8 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed62a;
                                                iVar8 = fcn.180244a90(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                                      *(int64_t *)((int64_t)&var_10h + iVar9));
                                                if (iVar8 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed647;
                                                    iVar8 = fcn.1802446f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9)
                                                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                                          *(int64_t *)(&stack0x00000028 + iVar9));
                                                    if (iVar8 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed666;
                                                        iVar8 = fcn.1802445f0(*(int64_t *)
                                                                               (&stack0xffffffffffffffe8 + iVar9), 
                                                                              *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                                              *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                                              *(int64_t *)(&stack0x00000028 + iVar9));
                                                        if (iVar8 != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed68c;
                                                            iVar8 = fcn.180244bf0(*(int64_t *)((int64_t)&var_8h + iVar9)
                                                                                  , *(int64_t *)
                                                                                     ((int64_t)&iStackX_20 +
                                                                                     iVar9 + -0x20), 
                                                                                  *(int64_t *)
                                                                                   ((int64_t)&iStackX_20 + iVar9 + -8));
                                                            if (iVar8 != 0) {
                                                                uVar4 = *(undefined8 *)(param_1 + 0x300);
                                                                pcVar6 = *(code **)(*(int64_t *)(param_1 + 0x18) + 0xb0)
                                                                ;
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                     0x1801ed6b2;
                                                                iVar8 = (*pcVar6)(uVar4, (int64_t)&iStackX_10 + iVar9, 
                                                                                  &var_1160h);
                                                                if (iVar8 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                         0x1801ed6cc;
                                                                    iVar8 = fcn.1802446f0(*(int64_t *)
                                                                                           (&stack0xffffffffffffffe8 +
                                                                                           iVar9), *(int64_t *)
                                                                                                    ((int64_t)&var_10h +
                                                                                                    iVar9), 
                                                                                          *(int64_t *)
                                                                                           ((int64_t)&var_8h + iVar9), 
                                                                                          *(int64_t *)
                                                                                           (&stack0x00000028 + iVar9));
                                                                    if (iVar8 != 0) {
                                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                             0x1801ed6e3;
                                                                        iVar8 = fcn.180244a90(*(int64_t *)
                                                                                               (&stack0xffffffffffffffe8
                                                                                               + iVar9), 
                                                                                              *(int64_t *)
                                                                                               ((int64_t)&var_10h +
                                                                                               iVar9));
                                                                        if (iVar8 != 0) {
                                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9)
                                                                                 = 0x1801ed700;
                                                                            iVar8 = fcn.1802446f0(*(int64_t *)
                                                                                                   (&
                                                            stack0xffffffffffffffe8 + iVar9), 
                                                            *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                            *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                            *(int64_t *)(&stack0x00000028 + iVar9));
                                                            if (iVar8 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                     0x1801ed717;
                                                                iVar8 = fcn.180244a90(*(int64_t *)
                                                                                       (&stack0xffffffffffffffe8 + iVar9
                                                                                       ), *(int64_t *)
                                                                                           ((int64_t)&var_10h + iVar9));
                                                                if (iVar8 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                         0x1801ed733;
                                                                    iVar8 = fcn.1802446f0(*(int64_t *)
                                                                                           (&stack0xffffffffffffffe8 +
                                                                                           iVar9), *(int64_t *)
                                                                                                    ((int64_t)&var_10h +
                                                                                                    iVar9), 
                                                                                          *(int64_t *)
                                                                                           ((int64_t)&var_8h + iVar9), 
                                                                                          *(int64_t *)
                                                                                           (&stack0x00000028 + iVar9));
                                                                    if (iVar8 != 0) {
                                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                             0x1801ed745;
                                                                        iVar8 = fcn.180244000(*(int64_t *)
                                                                                               ((int64_t)&var_10h +
                                                                                               iVar9), *(int64_t *)
                                                                                                        ((int64_t)&
                                                            var_8h + iVar9), 
                                                            *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                                            *(int64_t *)((int64_t)&iStackX_8 + iVar9), 
                                                            *(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                                            *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), 
                                                            *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                                                            *(int64_t *)(&stack0x00000028 + iVar9));
                                                            if (iVar8 != 0) {
                                                                if (*(char *)((int64_t)&iStackX_8 + iVar9) == '\0') {
code_r0x0001801ed7f1:
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                         0x1801ed806;
                                                                    iVar8 = fcn.1802446f0(*(int64_t *)
                                                                                           (&stack0xffffffffffffffe8 +
                                                                                           iVar9), *(int64_t *)
                                                                                                    ((int64_t)&var_10h +
                                                                                                    iVar9), 
                                                                                          *(int64_t *)
                                                                                           ((int64_t)&var_8h + iVar9), 
                                                                                          *(int64_t *)
                                                                                           (&stack0x00000028 + iVar9));
                                                                    if (iVar8 != 0) {
                                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                             0x1801ed81d;
                                                                        iVar8 = fcn.180244a90(*(int64_t *)
                                                                                               (&stack0xffffffffffffffe8
                                                                                               + iVar9), 
                                                                                              *(int64_t *)
                                                                                               ((int64_t)&var_10h +
                                                                                               iVar9));
                                                                        if (iVar8 != 0) {
                                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9)
                                                                                 = 0x1801ed83b;
                                                                            iVar8 = fcn.180244bf0(*(int64_t *)
                                                                                                   ((int64_t)&var_8h +
                                                                                                   iVar9), *(int64_t *)
                                                                                                            ((int64_t)&
                                                            iStackX_20 + iVar9 + -0x20), 
                                                            *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                                                            if (iVar8 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                     0x1801ed84d;
                                                                iVar8 = fcn.180244000(*(int64_t *)
                                                                                       ((int64_t)&var_10h + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&var_8h + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_20 +
                                                                                       iVar9 + -0x20), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_8 + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_10 + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_20 +
                                                                                       iVar9 + -8), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_20 + iVar9), 
                                                                                      *(int64_t *)
                                                                                       (&stack0x00000028 + iVar9));
                                                                if (iVar8 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                         0x1801ed85f;
                                                                    iVar8 = fcn.180244000(*(int64_t *)
                                                                                           ((int64_t)&var_10h + iVar9), 
                                                                                          *(int64_t *)
                                                                                           ((int64_t)&var_8h + iVar9), 
                                                                                          *(int64_t *)
                                                                                           ((int64_t)&iStackX_20 +
                                                                                           iVar9 + -0x20), 
                                                                                          *(int64_t *)
                                                                                           ((int64_t)&iStackX_8 + iVar9)
                                                                                          , *(int64_t *)
                                                                                             ((int64_t)&iStackX_10 +
                                                                                             iVar9), 
                                                                                          *(int64_t *)
                                                                                           ((int64_t)&iStackX_20 +
                                                                                           iVar9 + -8), 
                                                                                          *(int64_t *)
                                                                                           ((int64_t)&iStackX_20 + iVar9
                                                                                           ), *(int64_t *)
                                                                                               (&stack0x00000028 + iVar9
                                                                                               ));
                                                                    if (iVar8 != 0) {
                                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                             0x1801ed871;
                                                                        iVar8 = fcn.180244000(*(int64_t *)
                                                                                               ((int64_t)&var_10h +
                                                                                               iVar9), *(int64_t *)
                                                                                                        ((int64_t)&
                                                            var_8h + iVar9), 
                                                            *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                                            *(int64_t *)((int64_t)&iStackX_8 + iVar9), 
                                                            *(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                                            *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), 
                                                            *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                                                            *(int64_t *)(&stack0x00000028 + iVar9));
                                                            if (iVar8 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                     0x1801ed887;
                                                                iVar8 = func_0x0001802442e0((int64_t)&iStackX_10 + iVar9
                                                                                            , &var_1148h);
                                                                if (iVar8 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                         0x1801ed895;
                                                                    iVar8 = func_0x000180244200((int64_t)&iStackX_10 +
                                                                                                iVar9);
                                                                    if (iVar8 != 0) {
                                                                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar9) =
                                                                             var_1148h;
                                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                             0x1801ed8b4;
                                                                        iVar8 = func_0x0001801ae390(param_1, iVar11, 
                                                                                                    uVar14, &var_1118h);
                                                                        if (iVar8 != 0) {
                                                                            *(undefined4 *)(param_1 + 0x8c8) = 1;
                                                                            *(undefined4 *)(param_1 + 0xb30) = 1;
                                                                        }
                                                                        goto code_r0x0001801ed8d5;
                                                                    }
                                                                }
                                                            }
                                                            }
                                                            }
                                                            }
                                                            }
                                                            }
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed909;
                                                            func_0x000180243fb0((int64_t)&iStackX_10 + iVar9);
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed90e;
                                                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9)
                                                                          , *(int64_t *)((int64_t)&var_10h + iVar9));
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed926;
                                                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9)
                                                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar9 + -8));
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed93c;
                                                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                                                            } else {
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                     0x1801ed76d;
                                                                iVar8 = fcn.1802446f0(*(int64_t *)
                                                                                       (&stack0xffffffffffffffe8 + iVar9
                                                                                       ), *(int64_t *)
                                                                                           ((int64_t)&var_10h + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&var_8h + iVar9), 
                                                                                      *(int64_t *)
                                                                                       (&stack0x00000028 + iVar9));
                                                                if (iVar8 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                         0x1801ed780;
                                                                    iVar8 = fcn.180244a90(*(int64_t *)
                                                                                           (&stack0xffffffffffffffe8 +
                                                                                           iVar9), *(int64_t *)
                                                                                                    ((int64_t)&var_10h +
                                                                                                    iVar9));
                                                                    if (iVar8 != 0) {
                                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                             0x1801ed79b;
                                                                        iVar8 = fcn.1802446f0(*(int64_t *)
                                                                                               (&stack0xffffffffffffffe8
                                                                                               + iVar9), 
                                                                                              *(int64_t *)
                                                                                               ((int64_t)&var_10h +
                                                                                               iVar9), *(int64_t *)
                                                                                                        ((int64_t)&
                                                            var_8h + iVar9), *(int64_t *)(&stack0x00000028 + iVar9));
                                                            if (iVar8 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) =
                                                                     0x1801ed7a9;
                                                                iVar8 = fcn.180244000(*(int64_t *)
                                                                                       ((int64_t)&var_10h + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&var_8h + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_20 +
                                                                                       iVar9 + -0x20), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_8 + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_10 + iVar9), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_20 +
                                                                                       iVar9 + -8), 
                                                                                      *(int64_t *)
                                                                                       ((int64_t)&iStackX_20 + iVar9), 
                                                                                      *(int64_t *)
                                                                                       (&stack0x00000028 + iVar9));
                                                                if (iVar8 != 0) goto code_r0x0001801ed7f1;
                                                            }
                                                            }
                                                            }
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed7b7;
                                                            func_0x000180243fb0((int64_t)&iStackX_10 + iVar9);
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed7bc;
                                                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9)
                                                                          , *(int64_t *)((int64_t)&var_10h + iVar9));
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed7d4;
                                                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9)
                                                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar9 + -8));
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed7ea;
                                                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                                                            }
                                                            goto code_r0x0001801ed8d5;
                                                            }
                                                            }
                                                            }
                                                            }
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed94a;
                                                            func_0x000180243fb0((int64_t)&iStackX_10 + iVar9);
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed94f;
                                                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9)
                                                                          , *(int64_t *)((int64_t)&var_10h + iVar9));
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed967;
                                                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9)
                                                                          , *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar9 + -8));
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed97d;
                                                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                                                            goto code_r0x0001801ed8d5;
                                                            }
                                                            }
                                                            }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed98e;
                                            func_0x000180243fb0((int64_t)&iStackX_10 + iVar9);
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed993;
                                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                          *(int64_t *)((int64_t)&var_10h + iVar9));
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed9ab;
                                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                                          *(int64_t *)((int64_t)&var_10h + iVar9), 
                                                          *(int64_t *)((int64_t)&var_8h + iVar9), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed9c1;
                                            fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                                            goto code_r0x0001801ed8d5;
                                        }
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed9cd;
                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                              *(int64_t *)((int64_t)&var_10h + iVar9));
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed9e5;
                                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                              *(int64_t *)((int64_t)&var_10h + iVar9), 
                                              *(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed9fb;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                                goto code_r0x0001801ed8d5;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801eda07;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)((int64_t)&var_10h + iVar9));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801eda1f;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), 
                                      *(int64_t *)((int64_t)&var_10h + iVar9), *(int64_t *)((int64_t)&var_8h + iVar9), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801eda35;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                        goto code_r0x0001801ed8d5;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edaf2;
                func_0x000180215310(iVar10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edafa;
                fcn.18022ecc0(iVar11);
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edaff;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb17;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                              *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20)
                              , *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edb2d;
                fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
                goto code_r0x0001801ed8d5;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edbbd;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edbd5;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                  *(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -0x20), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801edbeb;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_8 + iVar9));
code_r0x0001801ed8d5:
    *(undefined8 *)((int64_t)&uStack_40 + iVar9) = 0x1801ed8e4;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801edc00
// Address: 0x1801edc00
// Size: 140 bytes
// ============================================================
undefined8 fcn.1801edc00(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801edc0c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)(param_2 + 8) == 0) {
        if (*(int32_t *)(param_1 + 0x8c8) == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801edc62;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801edc7a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801edc1e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801edc36;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801edc4c;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_1801edc90
// Address: 0x1801edc90
// Size: 336 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801edc90(int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    uint8_t *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint8_t *puVar7;
    int64_t iVar8;
    uint8_t **in_RDX;
    uint8_t *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801edca5;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar5 = *in_RDX;
    puVar9 = in_RDX[1];
    puVar7 = in_RDX[1];
    *(uint8_t **)((int64_t)&var_18h + iVar6) = puVar5;
    *(uint8_t **)((int64_t)&var_20h + iVar6) = puVar9;
    if (puVar7 != (uint8_t *)0x0) {
        puVar7 = puVar7 + -1;
        puVar9 = (uint8_t *)(uint64_t)*puVar5;
        if (puVar9 <= puVar7) {
            iVar8 = (int64_t)puVar7 - (int64_t)puVar9;
            *(uint8_t **)((int64_t)&var_18h + iVar6) = puVar9 + (int64_t)(puVar5 + 1);
            *(int64_t *)((int64_t)&var_20h + iVar6) = iVar8;
            if (iVar8 == 0) {
                uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar6 + 4);
                uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar6);
                uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar6 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar6);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar2;
                *(undefined4 *)(in_RDX + 1) = uVar3;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar4;
                if (puVar9 != (uint8_t *)0x0) {
                    if (*(int32_t *)(in_RCX + 0x508) != 0) {
                        return 1;
                    }
                    uVar1 = *(undefined8 *)(in_RCX + 0xa80);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801edd22;
                    fcn.180224990(uVar1, 0x1804a9450, 0x1d9);
                    *(undefined8 *)(in_RCX + 0xa80) = 0;
                    *(undefined8 *)(in_RCX + 0xa78) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801edd49;
                    iVar8 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar6));
                    *(int64_t *)(in_RCX + 0xa80) = iVar8;
                    if (iVar8 != 0) {
                        *(uint8_t **)(in_RCX + 0xa78) = puVar9;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801edd76;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801edd8e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    goto code_r0x0001801eddc3;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801edda0;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801eddb8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
code_r0x0001801eddc3:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801eddce;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801edde0
// Address: 0x1801edde0
// Size: 113 bytes
// ============================================================
undefined8 fcn.1801edde0(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801eddec;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)(param_2 + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801eddfe;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ede16;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ede2c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    if ((*(uint8_t *)(param_1 + 0x9a8) & 1) == 0) {
        *(uint32_t *)(param_1 + 0x160) = *(uint32_t *)(param_1 + 0x160) | 0x200;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801ede80
// Address: 0x1801ede80
// Size: 508 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel

undefined8
fcn.1801ede80(int64_t arg_28h, int64_t arg_30h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_f0h, int64_t arg_f8h,
             int64_t arg_100h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t uVar4;
    int64_t *in_RDX;
    uint16_t uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar10;
    uint16_t uVar11;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ede93;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 0;
    var_8h = 0x20;
    var_98h = 0;
    var_88h = 0;
    var_90h = 0;
    uVar5 = 0;
    *(undefined2 *)(in_RCX + 0x4e8) = 0;
    if ((*(int32_t *)(in_RCX + 0x508) != 0) && ((*(uint8_t *)(in_RCX + 0xb10) & 2) == 0)) {
        return 1;
    }
    if (*(int64_t *)(in_RCX + 0x4e0) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edee5;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edefd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edf13;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        return 0;
    }
    var_48h = *in_RDX;
    var_40h = in_RDX[1];
    uVar4 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_f0h + iVar3) = unaff_RDI;
    if (1 < uVar4) {
        uVar4 = uVar4 - 2;
        puVar1 = (undefined *)(var_48h + 2);
        uVar8 = (uint64_t)CONCAT11(*(undefined *)var_48h, *(undefined *)(var_48h + 1));
        if (uVar8 <= uVar4) {
            var_48h = (int64_t)(puVar1 + uVar8);
            var_40h = uVar4 - uVar8;
            if (var_40h == 0) {
                *in_RDX = var_48h;
                in_RDX[1] = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edf95;
                var_60h = (int64_t)puVar1;
                var_58h = uVar8;
                fcn.1801ab620(in_RCX, &var_78h, &var_38h);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfa5;
                fcn.1801ab3a0(in_RCX, &var_48h, &var_50h);
                var_70h = *(int64_t *)(in_RCX + 0xa98);
                var_68h = *(int64_t *)(in_RCX + 0xaa0);
                if (var_70h == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfc5;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfdd;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar3));
                } else {
                    if ((*(int16_t *)(in_RCX + 0x4de) == 0) || (uVar8 != 0)) {
                        *(int64_t **)((int64_t)&arg_30h + iVar3) = &var_8h;
                        *(int64_t **)((int64_t)&arg_28h + iVar3) = &var_90h;
                        *(int64_t **)((int64_t)&var_20h + iVar3) = &var_98h;
                        *(int64_t **)((int64_t)&var_18h + iVar3) = &var_88h;
                        *(int64_t *)((int64_t)&var_10h + iVar3) = var_38h;
                        *(int64_t *)((int64_t)&var_8h + iVar3) = var_78h;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee070;
                        iVar2 = fcn.1801eab30(*(int64_t *)(&stack0x00000048 + iVar3), 
                                              *(int64_t *)(&stack0x00000058 + iVar3), 
                                              *(int64_t *)(&stack0x00000060 + iVar3), 
                                              *(int64_t *)(&stack0x00000068 + iVar3), 
                                              *(int64_t *)(&stack0x00000070 + iVar3), 
                                              *(int64_t *)(&stack0x00000078 + iVar3), 
                                              *(int64_t *)(&stack0x00000080 + iVar3), 
                                              *(int64_t *)(&stack0x00000090 + iVar3), 
                                              *(int64_t *)(&stack0x00000128 + iVar3));
                        if (iVar2 == 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&arg_f8h + iVar3) = unaff_R12;
                        *(undefined8 *)((int64_t)&arg_100h + iVar3) = unaff_R13;
                        *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_R14;
                        *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_R15;
                        iVar9 = var_98h;
                        if ((iVar2 != 2) && (var_60h = 0, iVar10 = var_78h, var_50h != 0)) {
                            do {
                                var_8h = var_8h & 0xffffffffffff0000;
                                var_a0h = 0;
                                uVar4 = *(uint64_t *)(var_48h + var_60h * 8);
                                var_a8h._0_4_ = 0;
                                var_80h = uVar4;
                                if ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x16 & 1) == 0) {
                                    uVar4 = var_90h;
                                    uVar11 = uVar5;
                                    uVar7 = uVar5;
                                    if (uVar4 != 0) {
                                        do {
                                            *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                            *(undefined4 *)((int64_t)&var_8h + iVar3) = 1;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee21d;
                                            iVar2 = fcn.1801ae070(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                                            if (iVar2 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee234;
                                                iVar2 = fcn.1801ada30(*(int64_t *)((int64_t)&var_18h + iVar3));
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
                                                    *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee257;
                                                    iVar2 = fcn.1801adc80(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_30h + iVar3));
                                                    if ((iVar2 != 0) && ((uint64_t)var_a0h < uVar4)) {
                                                        var_a8h._0_4_ = (uint32_t)var_a0h;
                                                        uVar11 = *(uint16_t *)(var_88h + var_a0h * 2);
                                                        uVar4 = var_a0h;
                                                    }
                                                }
                                            }
                                            uVar7 = uVar7 + 1;
                                        } while ((uint64_t)uVar7 < (uint64_t)var_80h);
                                        var_8h = CONCAT62(var_8h._2_6_, uVar11);
                                        if (uVar11 != 0) goto code_r0x0001801ee2f9;
                                    }
                                    *(int64_t **)((int64_t)&var_20h + iVar3) = &var_8h;
                                    *(int64_t **)((int64_t)&var_18h + iVar3) = &var_a8h;
                                    *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                    *(int64_t *)((int64_t)&var_8h + iVar3) = var_80h;
                                } else {
                                    uVar11 = uVar5;
                                    uVar7 = uVar5;
                                    if (var_90h != 0) {
                                        do {
                                            *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                            *(undefined4 *)((int64_t)&var_8h + iVar3) = 1;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee12b;
                                            iVar2 = fcn.1801ae070(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                                            if (iVar2 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee141;
                                                iVar2 = fcn.1801ada30(*(int64_t *)((int64_t)&var_18h + iVar3));
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
                                                    *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee163;
                                                    iVar2 = fcn.1801adc80(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_30h + iVar3));
                                                    if ((iVar2 != 0) && ((uint64_t)var_a0h < uVar4)) {
                                                        uVar11 = *(uint16_t *)(iVar10 + var_a0h * 2);
                                                        var_a8h._0_4_ = (uint32_t)uVar7;
                                                        uVar4 = var_a0h;
                                                    }
                                                }
                                            }
                                            uVar7 = uVar7 + 1;
                                        } while ((uint64_t)uVar7 < (uint64_t)var_90h);
                                        var_8h = CONCAT62(var_8h._2_6_, uVar11);
                                        if (uVar11 != 0) {
code_r0x0001801ee2f9:
                                            iVar9 = var_98h;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee313;
                                            iVar2 = fcn.1801eaf80(*(int64_t *)((int64_t)&var_8h + iVar3));
                                            if (iVar2 == 0) goto code_r0x0001801ee329;
                                            break;
                                        }
                                    }
                                    *(int64_t **)((int64_t)&var_20h + iVar3) = &var_8h;
                                    *(int64_t **)((int64_t)&var_18h + iVar3) = &var_a8h;
                                    *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                    *(int64_t *)((int64_t)&var_8h + iVar3) = var_70h;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee2d1;
                                fcn.1801ea9e0(*(int64_t *)((int64_t)&arg_28h + iVar3), 
                                              *(int64_t *)(&stack0x00000038 + iVar3), 
                                              *(int64_t *)(&stack0x00000040 + iVar3), 
                                              *(int64_t *)(&stack0x00000048 + iVar3), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)(&stack0x00000058 + iVar3), 
                                              *(int64_t *)(&stack0x00000060 + iVar3), 
                                              *(int64_t *)(&stack0x000000a8 + iVar3));
                                iVar9 = var_98h;
                                if ((int16_t)var_8h != 0) {
                                    *(int16_t *)(in_RCX + 0x4e8) = (int16_t)var_8h;
                                    break;
                                }
                                var_60h = var_60h + 1;
                                iVar10 = iVar10 + var_80h * 2;
                            } while ((uint64_t)var_60h < (uint64_t)var_50h);
                        }
                        uVar6 = 1;
code_r0x0001801ee329:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee33f;
                        fcn.180224990(var_88h, 0x1804b7630, 999);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee354;
                        fcn.180224990(iVar9, 0x1804b7630, 1000);
                        return uVar6;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee000;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee018;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar3));
                }
                goto code_r0x0001801ee3a0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee37d;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee395;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3));
code_r0x0001801ee3a0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee3ab;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801ee07c
// Address: 0x1801ee07c
// Size: 764 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel

undefined8
fcn.1801ede80(int64_t arg_28h, int64_t arg_30h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_f0h, int64_t arg_f8h,
             int64_t arg_100h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t uVar4;
    int64_t *in_RDX;
    uint16_t uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar10;
    uint16_t uVar11;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ede93;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 0;
    var_8h = 0x20;
    var_98h = 0;
    var_88h = 0;
    var_90h = 0;
    uVar5 = 0;
    *(undefined2 *)(in_RCX + 0x4e8) = 0;
    if ((*(int32_t *)(in_RCX + 0x508) != 0) && ((*(uint8_t *)(in_RCX + 0xb10) & 2) == 0)) {
        return 1;
    }
    if (*(int64_t *)(in_RCX + 0x4e0) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edee5;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edefd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edf13;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        return 0;
    }
    var_48h = *in_RDX;
    var_40h = in_RDX[1];
    uVar4 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_f0h + iVar3) = unaff_RDI;
    if (1 < uVar4) {
        uVar4 = uVar4 - 2;
        puVar1 = (undefined *)(var_48h + 2);
        uVar8 = (uint64_t)CONCAT11(*(undefined *)var_48h, *(undefined *)(var_48h + 1));
        if (uVar8 <= uVar4) {
            var_48h = (int64_t)(puVar1 + uVar8);
            var_40h = uVar4 - uVar8;
            if (var_40h == 0) {
                *in_RDX = var_48h;
                in_RDX[1] = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edf95;
                var_60h = (int64_t)puVar1;
                var_58h = uVar8;
                fcn.1801ab620(in_RCX, &var_78h, &var_38h);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfa5;
                fcn.1801ab3a0(in_RCX, &var_48h, &var_50h);
                var_70h = *(int64_t *)(in_RCX + 0xa98);
                var_68h = *(int64_t *)(in_RCX + 0xaa0);
                if (var_70h == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfc5;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfdd;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar3));
                } else {
                    if ((*(int16_t *)(in_RCX + 0x4de) == 0) || (uVar8 != 0)) {
                        *(int64_t **)((int64_t)&arg_30h + iVar3) = &var_8h;
                        *(int64_t **)((int64_t)&arg_28h + iVar3) = &var_90h;
                        *(int64_t **)((int64_t)&var_20h + iVar3) = &var_98h;
                        *(int64_t **)((int64_t)&var_18h + iVar3) = &var_88h;
                        *(int64_t *)((int64_t)&var_10h + iVar3) = var_38h;
                        *(int64_t *)((int64_t)&var_8h + iVar3) = var_78h;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee070;
                        iVar2 = fcn.1801eab30(*(int64_t *)(&stack0x00000048 + iVar3), 
                                              *(int64_t *)(&stack0x00000058 + iVar3), 
                                              *(int64_t *)(&stack0x00000060 + iVar3), 
                                              *(int64_t *)(&stack0x00000068 + iVar3), 
                                              *(int64_t *)(&stack0x00000070 + iVar3), 
                                              *(int64_t *)(&stack0x00000078 + iVar3), 
                                              *(int64_t *)(&stack0x00000080 + iVar3), 
                                              *(int64_t *)(&stack0x00000090 + iVar3), 
                                              *(int64_t *)(&stack0x00000128 + iVar3));
                        if (iVar2 == 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&arg_f8h + iVar3) = unaff_R12;
                        *(undefined8 *)((int64_t)&arg_100h + iVar3) = unaff_R13;
                        *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_R14;
                        *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_R15;
                        iVar9 = var_98h;
                        if ((iVar2 != 2) && (var_60h = 0, iVar10 = var_78h, var_50h != 0)) {
                            do {
                                var_8h = var_8h & 0xffffffffffff0000;
                                var_a0h = 0;
                                uVar4 = *(uint64_t *)(var_48h + var_60h * 8);
                                var_a8h._0_4_ = 0;
                                var_80h = uVar4;
                                if ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x16 & 1) == 0) {
                                    uVar4 = var_90h;
                                    uVar11 = uVar5;
                                    uVar7 = uVar5;
                                    if (uVar4 != 0) {
                                        do {
                                            *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                            *(undefined4 *)((int64_t)&var_8h + iVar3) = 1;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee21d;
                                            iVar2 = fcn.1801ae070(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                                            if (iVar2 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee234;
                                                iVar2 = fcn.1801ada30(*(int64_t *)((int64_t)&var_18h + iVar3));
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
                                                    *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee257;
                                                    iVar2 = fcn.1801adc80(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_30h + iVar3));
                                                    if ((iVar2 != 0) && ((uint64_t)var_a0h < uVar4)) {
                                                        var_a8h._0_4_ = (uint32_t)var_a0h;
                                                        uVar11 = *(uint16_t *)(var_88h + var_a0h * 2);
                                                        uVar4 = var_a0h;
                                                    }
                                                }
                                            }
                                            uVar7 = uVar7 + 1;
                                        } while ((uint64_t)uVar7 < (uint64_t)var_80h);
                                        var_8h = CONCAT62(var_8h._2_6_, uVar11);
                                        if (uVar11 != 0) goto code_r0x0001801ee2f9;
                                    }
                                    *(int64_t **)((int64_t)&var_20h + iVar3) = &var_8h;
                                    *(int64_t **)((int64_t)&var_18h + iVar3) = &var_a8h;
                                    *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                    *(int64_t *)((int64_t)&var_8h + iVar3) = var_80h;
                                } else {
                                    uVar11 = uVar5;
                                    uVar7 = uVar5;
                                    if (var_90h != 0) {
                                        do {
                                            *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                            *(undefined4 *)((int64_t)&var_8h + iVar3) = 1;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee12b;
                                            iVar2 = fcn.1801ae070(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                                            if (iVar2 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee141;
                                                iVar2 = fcn.1801ada30(*(int64_t *)((int64_t)&var_18h + iVar3));
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
                                                    *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee163;
                                                    iVar2 = fcn.1801adc80(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_30h + iVar3));
                                                    if ((iVar2 != 0) && ((uint64_t)var_a0h < uVar4)) {
                                                        uVar11 = *(uint16_t *)(iVar10 + var_a0h * 2);
                                                        var_a8h._0_4_ = (uint32_t)uVar7;
                                                        uVar4 = var_a0h;
                                                    }
                                                }
                                            }
                                            uVar7 = uVar7 + 1;
                                        } while ((uint64_t)uVar7 < (uint64_t)var_90h);
                                        var_8h = CONCAT62(var_8h._2_6_, uVar11);
                                        if (uVar11 != 0) {
code_r0x0001801ee2f9:
                                            iVar9 = var_98h;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee313;
                                            iVar2 = fcn.1801eaf80(*(int64_t *)((int64_t)&var_8h + iVar3));
                                            if (iVar2 == 0) goto code_r0x0001801ee329;
                                            break;
                                        }
                                    }
                                    *(int64_t **)((int64_t)&var_20h + iVar3) = &var_8h;
                                    *(int64_t **)((int64_t)&var_18h + iVar3) = &var_a8h;
                                    *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                    *(int64_t *)((int64_t)&var_8h + iVar3) = var_70h;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee2d1;
                                fcn.1801ea9e0(*(int64_t *)((int64_t)&arg_28h + iVar3), 
                                              *(int64_t *)(&stack0x00000038 + iVar3), 
                                              *(int64_t *)(&stack0x00000040 + iVar3), 
                                              *(int64_t *)(&stack0x00000048 + iVar3), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)(&stack0x00000058 + iVar3), 
                                              *(int64_t *)(&stack0x00000060 + iVar3), 
                                              *(int64_t *)(&stack0x000000a8 + iVar3));
                                iVar9 = var_98h;
                                if ((int16_t)var_8h != 0) {
                                    *(int16_t *)(in_RCX + 0x4e8) = (int16_t)var_8h;
                                    break;
                                }
                                var_60h = var_60h + 1;
                                iVar10 = iVar10 + var_80h * 2;
                            } while ((uint64_t)var_60h < (uint64_t)var_50h);
                        }
                        uVar6 = 1;
code_r0x0001801ee329:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee33f;
                        fcn.180224990(var_88h, 0x1804b7630, 999);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee354;
                        fcn.180224990(iVar9, 0x1804b7630, 1000);
                        return uVar6;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee000;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee018;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar3));
                }
                goto code_r0x0001801ee3a0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee37d;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee395;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3));
code_r0x0001801ee3a0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee3ab;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801ee378
// Address: 0x1801ee378
// Size: 72 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel

undefined8
fcn.1801ede80(int64_t arg_28h, int64_t arg_30h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_f0h, int64_t arg_f8h,
             int64_t arg_100h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t uVar4;
    int64_t *in_RDX;
    uint16_t uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar10;
    uint16_t uVar11;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ede93;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 0;
    var_8h = 0x20;
    var_98h = 0;
    var_88h = 0;
    var_90h = 0;
    uVar5 = 0;
    *(undefined2 *)(in_RCX + 0x4e8) = 0;
    if ((*(int32_t *)(in_RCX + 0x508) != 0) && ((*(uint8_t *)(in_RCX + 0xb10) & 2) == 0)) {
        return 1;
    }
    if (*(int64_t *)(in_RCX + 0x4e0) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edee5;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edefd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edf13;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        return 0;
    }
    var_48h = *in_RDX;
    var_40h = in_RDX[1];
    uVar4 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_f0h + iVar3) = unaff_RDI;
    if (1 < uVar4) {
        uVar4 = uVar4 - 2;
        puVar1 = (undefined *)(var_48h + 2);
        uVar8 = (uint64_t)CONCAT11(*(undefined *)var_48h, *(undefined *)(var_48h + 1));
        if (uVar8 <= uVar4) {
            var_48h = (int64_t)(puVar1 + uVar8);
            var_40h = uVar4 - uVar8;
            if (var_40h == 0) {
                *in_RDX = var_48h;
                in_RDX[1] = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edf95;
                var_60h = (int64_t)puVar1;
                var_58h = uVar8;
                fcn.1801ab620(in_RCX, &var_78h, &var_38h);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfa5;
                fcn.1801ab3a0(in_RCX, &var_48h, &var_50h);
                var_70h = *(int64_t *)(in_RCX + 0xa98);
                var_68h = *(int64_t *)(in_RCX + 0xaa0);
                if (var_70h == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfc5;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801edfdd;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar3));
                } else {
                    if ((*(int16_t *)(in_RCX + 0x4de) == 0) || (uVar8 != 0)) {
                        *(int64_t **)((int64_t)&arg_30h + iVar3) = &var_8h;
                        *(int64_t **)((int64_t)&arg_28h + iVar3) = &var_90h;
                        *(int64_t **)((int64_t)&var_20h + iVar3) = &var_98h;
                        *(int64_t **)((int64_t)&var_18h + iVar3) = &var_88h;
                        *(int64_t *)((int64_t)&var_10h + iVar3) = var_38h;
                        *(int64_t *)((int64_t)&var_8h + iVar3) = var_78h;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee070;
                        iVar2 = fcn.1801eab30(*(int64_t *)(&stack0x00000048 + iVar3), 
                                              *(int64_t *)(&stack0x00000058 + iVar3), 
                                              *(int64_t *)(&stack0x00000060 + iVar3), 
                                              *(int64_t *)(&stack0x00000068 + iVar3), 
                                              *(int64_t *)(&stack0x00000070 + iVar3), 
                                              *(int64_t *)(&stack0x00000078 + iVar3), 
                                              *(int64_t *)(&stack0x00000080 + iVar3), 
                                              *(int64_t *)(&stack0x00000090 + iVar3), 
                                              *(int64_t *)(&stack0x00000128 + iVar3));
                        if (iVar2 == 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&arg_f8h + iVar3) = unaff_R12;
                        *(undefined8 *)((int64_t)&arg_100h + iVar3) = unaff_R13;
                        *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_R14;
                        *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_R15;
                        iVar9 = var_98h;
                        if ((iVar2 != 2) && (var_60h = 0, iVar10 = var_78h, var_50h != 0)) {
                            do {
                                var_8h = var_8h & 0xffffffffffff0000;
                                var_a0h = 0;
                                uVar4 = *(uint64_t *)(var_48h + var_60h * 8);
                                var_a8h._0_4_ = 0;
                                var_80h = uVar4;
                                if ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x16 & 1) == 0) {
                                    uVar4 = var_90h;
                                    uVar11 = uVar5;
                                    uVar7 = uVar5;
                                    if (uVar4 != 0) {
                                        do {
                                            *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                            *(undefined4 *)((int64_t)&var_8h + iVar3) = 1;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee21d;
                                            iVar2 = fcn.1801ae070(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                                            if (iVar2 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee234;
                                                iVar2 = fcn.1801ada30(*(int64_t *)((int64_t)&var_18h + iVar3));
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
                                                    *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee257;
                                                    iVar2 = fcn.1801adc80(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_30h + iVar3));
                                                    if ((iVar2 != 0) && ((uint64_t)var_a0h < uVar4)) {
                                                        var_a8h._0_4_ = (uint32_t)var_a0h;
                                                        uVar11 = *(uint16_t *)(var_88h + var_a0h * 2);
                                                        uVar4 = var_a0h;
                                                    }
                                                }
                                            }
                                            uVar7 = uVar7 + 1;
                                        } while ((uint64_t)uVar7 < (uint64_t)var_80h);
                                        var_8h = CONCAT62(var_8h._2_6_, uVar11);
                                        if (uVar11 != 0) goto code_r0x0001801ee2f9;
                                    }
                                    *(int64_t **)((int64_t)&var_20h + iVar3) = &var_8h;
                                    *(int64_t **)((int64_t)&var_18h + iVar3) = &var_a8h;
                                    *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                    *(int64_t *)((int64_t)&var_8h + iVar3) = var_80h;
                                } else {
                                    uVar11 = uVar5;
                                    uVar7 = uVar5;
                                    if (var_90h != 0) {
                                        do {
                                            *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                            *(undefined4 *)((int64_t)&var_8h + iVar3) = 1;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee12b;
                                            iVar2 = fcn.1801ae070(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                  *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                                            if (iVar2 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee141;
                                                iVar2 = fcn.1801ada30(*(int64_t *)((int64_t)&var_18h + iVar3));
                                                if (iVar2 != 0) {
                                                    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
                                                    *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee163;
                                                    iVar2 = fcn.1801adc80(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar3), 
                                                                          *(int64_t *)((int64_t)&var_18h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                                                          *(int64_t *)((int64_t)&arg_30h + iVar3));
                                                    if ((iVar2 != 0) && ((uint64_t)var_a0h < uVar4)) {
                                                        uVar11 = *(uint16_t *)(iVar10 + var_a0h * 2);
                                                        var_a8h._0_4_ = (uint32_t)uVar7;
                                                        uVar4 = var_a0h;
                                                    }
                                                }
                                            }
                                            uVar7 = uVar7 + 1;
                                        } while ((uint64_t)uVar7 < (uint64_t)var_90h);
                                        var_8h = CONCAT62(var_8h._2_6_, uVar11);
                                        if (uVar11 != 0) {
code_r0x0001801ee2f9:
                                            iVar9 = var_98h;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee313;
                                            iVar2 = fcn.1801eaf80(*(int64_t *)((int64_t)&var_8h + iVar3));
                                            if (iVar2 == 0) goto code_r0x0001801ee329;
                                            break;
                                        }
                                    }
                                    *(int64_t **)((int64_t)&var_20h + iVar3) = &var_8h;
                                    *(int64_t **)((int64_t)&var_18h + iVar3) = &var_a8h;
                                    *(int64_t **)((int64_t)&var_10h + iVar3) = &var_a0h;
                                    *(int64_t *)((int64_t)&var_8h + iVar3) = var_70h;
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee2d1;
                                fcn.1801ea9e0(*(int64_t *)((int64_t)&arg_28h + iVar3), 
                                              *(int64_t *)(&stack0x00000038 + iVar3), 
                                              *(int64_t *)(&stack0x00000040 + iVar3), 
                                              *(int64_t *)(&stack0x00000048 + iVar3), 
                                              *(int64_t *)(&stack0x00000050 + iVar3), 
                                              *(int64_t *)(&stack0x00000058 + iVar3), 
                                              *(int64_t *)(&stack0x00000060 + iVar3), 
                                              *(int64_t *)(&stack0x000000a8 + iVar3));
                                iVar9 = var_98h;
                                if ((int16_t)var_8h != 0) {
                                    *(int16_t *)(in_RCX + 0x4e8) = (int16_t)var_8h;
                                    break;
                                }
                                var_60h = var_60h + 1;
                                iVar10 = iVar10 + var_80h * 2;
                            } while ((uint64_t)var_60h < (uint64_t)var_50h);
                        }
                        uVar6 = 1;
code_r0x0001801ee329:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee33f;
                        fcn.180224990(var_88h, 0x1804b7630, 999);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee354;
                        fcn.180224990(iVar9, 0x1804b7630, 1000);
                        return uVar6;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee000;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee018;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)(&stack0x00000038 + iVar3));
                }
                goto code_r0x0001801ee3a0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee37d;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee395;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3));
code_r0x0001801ee3a0:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ee3ab;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801ee3c0
// Address: 0x1801ee3c0
// Size: 207 bytes
// ============================================================
undefined8 fcn.1801ee3c0(int64_t param_1, uint8_t **param_2)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ee3cc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_2[1] != (uint8_t *)0x1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ee459;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ee471;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ee487;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    uVar1 = **param_2;
    *param_2 = *param_2 + 1;
    param_2[1] = (uint8_t *)0x0;
    if (uVar1 - 1 < 4) {
        if (*(char *)(*(int64_t *)(param_1 + 0x8f8) + 0x350) == -1) {
            *(uint8_t *)(*(int64_t *)(param_1 + 0x8f8) + 0x350) = uVar1;
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ee41e;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ee436;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ee44c;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801ee4c0
// Address: 0x1801ee4c0
// Size: 105 bytes
// ============================================================
undefined8 fcn.1801ee4c0(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ee4cc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)(param_2 + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ee4de;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ee4f6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ee50c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    *(undefined4 *)(param_1 + 0xba8) = 2;
    return 1;
}

// ============================================================
// Function: FUN_1801ee530
// Address: 0x1801ee530
// Size: 2185 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1801ee530(int64_t arg_28h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    uint8_t *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    int64_t in_RCX;
    uint8_t *puVar16;
    uint64_t uVar17;
    uint8_t **in_RDX;
    uint64_t uVar18;
    uint64_t uVar19;
    uint8_t *puVar20;
    uint8_t *puVar21;
    uint64_t uVar22;
    uint8_t *puVar23;
    int64_t var_8h;
    int64_t var_18h;
    uint8_t var_21h [3];
    undefined2 var_24h [2];
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_10h;
    
    uStack_40 = 0x1801ee552;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11);
    uVar3 = *(undefined8 *)(in_RCX + 8);
    uVar14 = 0;
    uVar1 = *(uint8_t *)(in_RCX + 0xb10);
    uVar15 = *(undefined8 *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&var_18h + iVar11) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar11) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar11) = uVar15;
    if ((uVar1 & 3) == 0) goto code_r0x0001801eecdb;
    puVar23 = *in_RDX;
    puVar21 = in_RDX[1];
    puVar4 = in_RDX[1];
    *(uint8_t **)((int64_t)&arg_40h + iVar11) = puVar23;
    *(uint8_t **)(&stack0x00000048 + iVar11) = puVar21;
    if (puVar4 < (uint8_t *)0x2) {
code_r0x0001801eed7f:
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed84;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
    } else {
        puVar21 = puVar23 + 2;
        puVar23 = (uint8_t *)(uint64_t)CONCAT11(*puVar23, puVar23[1]);
        if (puVar4 + -2 < puVar23) goto code_r0x0001801eed7f;
        *(undefined4 *)((int64_t)&arg_28h + iVar11) = 0;
        *(uint8_t **)((int64_t)&arg_40h + iVar11) = puVar21 + (int64_t)puVar23;
        uVar2 = *(undefined4 *)((int64_t)&arg_40h + iVar11 + 4);
        uVar6 = *(undefined4 *)(&stack0x00000048 + iVar11);
        uVar7 = *(undefined4 *)(&stack0x0000004c + iVar11);
        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&arg_40h + iVar11);
        *(undefined4 *)((int64_t)in_RDX + 4) = uVar2;
        *(undefined4 *)(in_RDX + 1) = uVar6;
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar7;
        *(undefined4 *)(in_RCX + 0xa60) = 0;
        uVar22 = uVar14;
        uVar18 = uVar14;
        if (puVar23 == (uint8_t *)0x0) goto code_r0x0001801eecdb;
        while (uVar9 = (uint32_t)uVar18, (uint8_t *)0x1 < puVar23) {
            puVar4 = puVar21 + 2;
            puVar21 = (uint8_t *)(uint64_t)CONCAT11(*puVar21, puVar21[1]);
            if (puVar23 + 0xfffffffffffffffe < puVar21) break;
            uVar18 = (int64_t)(puVar23 + 0xfffffffffffffffe) - (int64_t)puVar21;
            puVar16 = puVar4 + (int64_t)puVar21;
            if (uVar18 < 4) break;
            puVar23 = (uint8_t *)(uVar18 - 4);
            uVar1 = puVar16[1];
            var_21h[iVar11] = *puVar16;
            var_21h[iVar11 + 1] = puVar16[2];
            var_21h[iVar11 + 2] = puVar16[3];
            pcVar5 = *(code **)(in_RCX + 0x978);
            *(uint8_t **)((int64_t)&arg_40h + iVar11) = puVar16 + 4;
            if (pcVar5 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee693;
                iVar8 = (*pcVar5)(uVar15, puVar4, puVar21, (int64_t)&var_18h + iVar11);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeada;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                  *(int64_t *)((int64_t)&var_10h + iVar11));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeaf2;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                  *(int64_t *)((int64_t)&var_10h + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), 
                                  *(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_18h + iVar11));
                    goto code_r0x0001801eeda1;
                }
                uVar22 = *(uint64_t *)((int64_t)&var_18h + iVar11);
            }
            if (uVar22 != 0) {
code_r0x0001801ee9c1:
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee9cb;
                iVar12 = func_0x00018019dc20(uVar22, 0);
                if (iVar12 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed34;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                  *(int64_t *)((int64_t)&var_10h + iVar11));
                } else {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee9e1;
                    func_0x00018019c980(*(undefined8 *)((int64_t)&var_18h + iVar11));
                    uVar15 = *(undefined8 *)(in_RCX + 0x8d0);
                    *(int64_t *)((int64_t)&var_18h + iVar11) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eea00;
                    fcn.180498030(iVar12 + 0x280, in_RCX + 0x8d8, uVar15);
                    iVar12 = *(int64_t *)((int64_t)&var_18h + iVar11);
                    uVar15 = *(undefined8 *)(in_RCX + 0x8d0);
                    *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4) = 1;
                    *(undefined8 *)(iVar12 + 0x278) = uVar15;
                    if (uVar9 == 0) {
                        *(undefined4 *)(in_RCX + 0xb1c) = 1;
                    }
                    *(undefined4 *)(in_RCX + 0xa60) = 1;
code_r0x0001801eea37:
                    uVar2 = *(undefined4 *)(*(int64_t *)(*(int64_t *)((int64_t)&var_18h + iVar11) + 0x2f8) + 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eea52;
                    uVar14 = func_0x0001801a08e0(uVar3, uVar2);
                    *(uint64_t *)((int64_t)&arg_30h + iVar11) = uVar14;
                    if (uVar14 != 0) {
                        uVar2 = *(undefined4 *)(*(int64_t *)(in_RCX + 0x300) + 0x40);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eea75;
                        uVar15 = func_0x0001801a08e0(uVar3, uVar2);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eea7d;
                        uVar15 = func_0x00018020f750(uVar15);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eea88;
                        iVar8 = func_0x00018020f860(uVar14, uVar15);
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eea9a;
                            func_0x00018019c980(*(undefined8 *)((int64_t)&var_18h + iVar11));
                            uVar22 = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar11) = 0;
                            *(undefined4 *)(in_RCX + 0xb1c) = 0;
                            *(undefined4 *)(in_RCX + 0xa60) = 0;
                            goto code_r0x0001801eeab5;
                        }
                        uVar22 = *(uint64_t *)((int64_t)&var_18h + iVar11);
                        goto code_r0x0001801eeb95;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed28;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                  *(int64_t *)((int64_t)&var_10h + iVar11));
                }
code_r0x0001801eed39:
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed4c;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11)
                              , *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11)
                              , *(int64_t *)((int64_t)&var_18h + iVar11));
                goto code_r0x0001801eed57;
            }
            if ((*(int64_t *)(in_RCX + 0x970) != 0) && (puVar21 < (uint8_t *)0x101)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee6d7;
                fcn.180224990(0, 0x1804a9450, 0x1f6);
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee6ef;
                iVar12 = func_0x000180223270(puVar4, puVar21, 0x1804a9450, 0x1f9);
                if (iVar12 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb6e;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                  *(int64_t *)((int64_t)&var_10h + iVar11));
                } else {
                    pcVar5 = *(code **)(in_RCX + 0x970);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee717;
                    uVar9 = (*pcVar5)(*(undefined8 *)((int64_t)&arg_38h + iVar11), iVar12, &var_248h, 0x200);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee72e;
                    fcn.180224990(iVar12, 0x1804b7630, 0x558);
                    if (uVar9 < 0x201) {
                        if (uVar9 == 0) {
code_r0x0001801ee7c3:
                            uVar22 = *(uint64_t *)((int64_t)&var_18h + iVar11);
                            uVar9 = *(uint32_t *)((int64_t)&arg_28h + iVar11);
                            if (uVar22 != 0) goto code_r0x0001801ee9c1;
                            uVar14 = *(uint64_t *)((int64_t)&arg_30h + iVar11);
                            goto code_r0x0001801ee7db;
                        }
                        *(undefined2 *)(var_21h + iVar11 + 3) = 0x113;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee756;
                        iVar12 = func_0x00018019e0c0(in_RCX, var_21h + iVar11 + 3);
                        if (iVar12 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee767;
                            iVar13 = func_0x00018019cd20();
                            *(int64_t *)((int64_t)&var_18h + iVar11) = iVar13;
                            if (iVar13 != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee784;
                                iVar8 = func_0x000180192fd0(iVar13, &var_248h, uVar9);
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee799;
                                    iVar8 = func_0x00018019ce00(*(undefined8 *)((int64_t)&var_18h + iVar11), iVar12);
                                    if (iVar8 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee7b0;
                                        iVar8 = func_0x00018019ce10(*(undefined8 *)((int64_t)&var_18h + iVar11), 0x304);
                                        if (iVar8 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee7c3;
                                            func_0x000180244fc0(&var_248h, uVar9);
                                            goto code_r0x0001801ee7c3;
                                        }
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb08;
                            func_0x000180244fc0(&var_248h, uVar9);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb0d;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                          *(int64_t *)((int64_t)&var_10h + iVar11));
                            goto code_r0x0001801eed39;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb23;
                        func_0x000180244fc0(&var_248h, uVar9);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb28;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                      *(int64_t *)((int64_t)&var_10h + iVar11));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb62;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                      *(int64_t *)((int64_t)&var_10h + iVar11));
                    }
                }
code_r0x0001801eeb2d:
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb40;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11)
                              , *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11)
                              , *(int64_t *)((int64_t)&var_18h + iVar11));
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb56;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar11));
                goto code_r0x0001801eecdb;
            }
code_r0x0001801ee7db:
            if (((*(uint64_t *)(in_RCX + 0x9a8) >> 0xe & 1) == 0) &&
               ((*(int32_t *)(in_RCX + 0x1538) == 0 || ((*(uint64_t *)(in_RCX + 0x9a8) >> 0x18 & 1) != 0)))) {
                *(int64_t *)((int64_t)&var_10h + iVar11) = (int64_t)&var_18h + iVar11;
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar11) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee81d;
                uVar10 = func_0x0001801ad190(in_RCX, puVar4, puVar21, 0);
                uVar22 = *(uint64_t *)((int64_t)&var_18h + iVar11);
            } else {
                *(undefined4 *)(in_RCX + 0xa60) = 1;
                if (puVar21 == (uint8_t *)0x0) {
                    uVar10 = 3;
                } else if (puVar21 == (uint8_t *)0x20) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee851;
                    uVar22 = func_0x00018019d010(in_RCX, puVar4, 0x20);
                    if (uVar22 == 0) {
                        uVar22 = *(uint64_t *)((int64_t)&var_18h + iVar11);
                        uVar10 = 4;
                    } else {
                        *(uint64_t *)((int64_t)&var_18h + iVar11) = uVar22;
                        uVar10 = 5;
                    }
                } else {
                    uVar10 = 4;
                }
            }
            if (uVar10 == 3) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb86;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11))
                ;
                goto code_r0x0001801eed89;
            }
            if (uVar10 < 2) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eeb7a;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11))
                ;
                goto code_r0x0001801eeb2d;
            }
            if ((uVar10 - 2 & 0xfffffffd) != 0) {
                if ((*(int32_t *)(in_RCX + 0x1538) != 0) && ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x18 & 1) == 0)) {
                    uVar15 = *(undefined8 *)(in_RCX + 0xb88);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee8bb;
                    iVar8 = func_0x00018019c8a0(uVar15, uVar22);
                    if (iVar8 == 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee8c9;
                        func_0x00018019c980(*(undefined8 *)((int64_t)&var_18h + iVar11));
                        uVar22 = 0;
                        *(undefined8 *)((int64_t)&var_18h + iVar11) = 0;
                        goto code_r0x0001801eeab5;
                    }
                    uVar22 = *(uint64_t *)((int64_t)&var_18h + iVar11);
                }
                uVar14 = *(uint64_t *)(uVar22 + 0x2e0);
                uVar17 = (uint64_t)*(uint32_t *)(uVar22 + 0x334) * 1000000;
                uVar19 = (uint64_t)
                         CONCAT31(CONCAT21(CONCAT11(var_21h[iVar11], uVar1), var_21h[iVar11 + 1]), var_21h[iVar11 + 2]);
                uVar18 = uVar19 * 1000000;
                uVar22 = uVar18 + (uint64_t)*(uint32_t *)(uVar22 + 0x334) * -1000000;
                if (uVar18 <= uVar17 && uVar17 + uVar19 * -1000000 != 0) {
                    uVar22 = 0;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801ee93a;
                uVar18 = func_0x0001802450c0();
                if (uVar18 < uVar14) {
                    uVar18 = 0;
code_r0x0001801ee95d:
                    uVar14 = uVar18 + 1000000000;
                } else {
                    uVar18 = uVar18 - uVar14;
                    uVar14 = 0xffffffffffffffff;
                    if (999999999 < ~uVar18) goto code_r0x0001801ee95d;
                }
                if ((uVar9 == 0) &&
                   (((uVar17 = *(uint64_t *)(*(int64_t *)((int64_t)&var_18h + iVar11) + 0x2d8), uVar18 < uVar17 ||
                     (uVar18 <= uVar17)) && (uVar22 <= uVar14)))) {
                    uVar18 = 0xffffffffffffffff;
                    if (9999999999 < ~uVar22) {
                        uVar18 = uVar22 + 10000000000;
                    }
                    if ((uVar14 < uVar18) || (uVar14 <= uVar18)) {
                        *(undefined4 *)(in_RCX + 0xb1c) = 1;
                    }
                }
                goto code_r0x0001801eea37;
            }
code_r0x0001801eeab5:
            uVar9 = uVar9 + 1;
            uVar18 = (uint64_t)uVar9;
            *(uint32_t *)((int64_t)&arg_28h + iVar11) = uVar9;
            if (puVar23 == (uint8_t *)0x0) {
code_r0x0001801eeb95:
                uVar10 = 0;
                if (uVar22 == 0) goto code_r0x0001801eecdb;
                puVar4 = *in_RDX;
                iVar12 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eebb8;
                iVar8 = func_0x00018020f800(uVar14);
                if (iVar8 < 1) goto code_r0x0001801eed62;
                puVar23 = *in_RDX;
                if ((uint8_t *)0x1 < in_RDX[1]) {
                    puVar16 = in_RDX[1] + -2;
                    puVar21 = puVar23 + 2;
                    puVar23 = (uint8_t *)(uint64_t)CONCAT11(*puVar23, puVar23[1]);
                    if (puVar23 <= puVar16) {
                        *in_RDX = puVar23 + (int64_t)puVar21;
                        in_RDX[1] = puVar16 + -(int64_t)puVar23;
                        goto code_r0x0001801eec17;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed19;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11))
                ;
                goto code_r0x0001801eec51;
            }
            puVar21 = *(uint8_t **)((int64_t)&arg_40h + iVar11);
            uVar15 = *(undefined8 *)((int64_t)&arg_38h + iVar11);
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed78;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
    }
code_r0x0001801eed89:
    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed9c;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                  *(int64_t *)((int64_t)&var_18h + iVar11));
code_r0x0001801eeda1:
    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eedb2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar11));
code_r0x0001801eecdb:
    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eecea;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar11));
    return;
    while( true ) {
        puVar20 = (uint8_t *)(uint64_t)*puVar21;
        puVar16 = puVar21 + 1;
        if (puVar23 + -1 < puVar20) goto code_r0x0001801eed05;
        puVar23 = puVar23 + -1 + -(int64_t)puVar20;
        puVar21 = puVar16 + (int64_t)puVar20;
        uVar10 = uVar10 + 1;
        if (uVar9 < uVar10) break;
code_r0x0001801eec17:
        if (puVar23 == (uint8_t *)0x0) {
code_r0x0001801eed05:
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed0a;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
            goto code_r0x0001801eec51;
        }
    }
    if (puVar20 == (uint8_t *)(int64_t)iVar8) {
        iVar13 = *(int64_t *)(in_RCX + 0xf8);
        *(undefined4 *)((int64_t)&var_8h + iVar11) = *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4);
        *(undefined4 *)(&stack0x00000000 + iVar11) = 0;
        uVar3 = *(undefined8 *)(iVar13 + 8);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar11) = *(undefined8 *)((int64_t)&var_18h + iVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar11) = 0;
        *(uint8_t **)(&stack0xffffffffffffffe8 + iVar11) = puVar16;
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eecae;
        iVar8 = func_0x0001801c9e00(in_RCX, uVar14, uVar3, (int64_t)puVar4 - iVar12);
        if (iVar8 == 1) {
            uVar3 = *(undefined8 *)(in_RCX + 0x8f8);
            *(uint32_t *)(in_RCX + 0xb38) = uVar9;
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eecca;
            func_0x00018019c980(uVar3);
            *(undefined8 *)(in_RCX + 0x8f8) = *(undefined8 *)((int64_t)&var_18h + iVar11);
            goto code_r0x0001801eecdb;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eec4c;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
code_r0x0001801eec51:
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eec64;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                      *(int64_t *)((int64_t)&var_18h + iVar11));
code_r0x0001801eed57:
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed62;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar11));
    }
code_r0x0001801eed62:
    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801eed6c;
    func_0x00018019c980(*(undefined8 *)((int64_t)&var_18h + iVar11));
    goto code_r0x0001801eecdb;
}

// ============================================================
// Function: FUN_1801eedc0
// Address: 0x1801eedc0
// Size: 260 bytes
// ============================================================
undefined8 fcn.1801eedc0(int64_t param_1, uint8_t **param_2)
{
    uint8_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    uint8_t *puVar6;
    uint8_t *puVar7;
    uint8_t *puVar8;
    int64_t iVar9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801eedcc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar7 = *param_2;
    puVar6 = param_2[1];
    puVar8 = param_2[1];
    *(uint8_t **)((int64_t)&var_18h + iVar5) = puVar7;
    *(uint8_t **)((int64_t)&var_20h + iVar5) = puVar6;
    if (puVar8 != (uint8_t *)0x0) {
        puVar8 = puVar8 + -1;
        puVar6 = (uint8_t *)(uint64_t)*puVar7;
        puVar7 = puVar7 + 1;
        if (puVar6 <= puVar8) {
            iVar9 = (int64_t)puVar8 - (int64_t)puVar6;
            *(uint8_t **)((int64_t)&var_18h + iVar5) = puVar6 + (int64_t)puVar7;
            *(int64_t *)((int64_t)&var_20h + iVar5) = iVar9;
            if (iVar9 == 0) {
                uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar5 + 4);
                uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar5);
                uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar5 + 4);
                *(undefined4 *)param_2 = *(undefined4 *)((int64_t)&var_18h + iVar5);
                *(undefined4 *)((int64_t)param_2 + 4) = uVar2;
                *(undefined4 *)(param_2 + 1) = uVar3;
                *(undefined4 *)((int64_t)param_2 + 0xc) = uVar4;
                if (puVar6 != (uint8_t *)0x0) {
                    while (puVar6 != (uint8_t *)0x0) {
                        uVar1 = *puVar7;
                        puVar6 = puVar6 + -1;
                        puVar7 = puVar7 + 1;
                        if (uVar1 == 1) {
                            *(uint32_t *)(param_1 + 0xb10) = *(uint32_t *)(param_1 + 0xb10) | 2;
                        } else if ((uVar1 == 0) && ((*(uint32_t *)(param_1 + 0x9a8) >> 10 & 1) != 0)) {
                            *(uint32_t *)(param_1 + 0xb10) = *(uint32_t *)(param_1 + 0xb10) | 1;
                        }
                    }
                    if (((*(uint8_t *)(param_1 + 0xb10) & 1) != 0) &&
                       ((*(uint64_t *)(param_1 + 0x9a8) & 0x800000000) != 0)) {
                        *(undefined4 *)(param_1 + 0xb10) = 1;
                    }
                    return 1;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801eee8e;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801eeea6;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801eeebc;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801eeed0
// Address: 0x1801eeed0
// Size: 260 bytes
// ============================================================
undefined8 fcn.1801eeed0(int64_t param_1, uint8_t **param_2)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint8_t *puVar5;
    uint8_t *puVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801eeedc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_2[1] != (uint8_t *)0x0) {
        puVar5 = param_2[1] + -1;
        uVar2 = **param_2;
        puVar6 = (uint8_t *)(uint64_t)uVar2;
        puVar1 = *param_2 + 1;
        *param_2 = puVar1;
        param_2[1] = puVar5;
        if (puVar6 <= puVar5) {
            *param_2 = puVar1 + (int64_t)puVar6;
            param_2[1] = puVar5 + -(int64_t)puVar6;
            if ((uint64_t)uVar2 == *(uint64_t *)(param_1 + 0x460)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801eef74;
                iVar3 = fcn.180497f30(puVar1, param_1 + 0x420);
                if (iVar3 == 0) {
                    *(undefined4 *)(param_1 + 0x4b0) = 1;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801eef7d;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                             );
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801eef2f;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                             );
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801eef47;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801eef5d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801eef9e;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801eefb6;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801eefcc;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801eefe0
// Address: 0x1801eefe0
// Size: 274 bytes
// ============================================================
undefined8 fcn.1801eefe0(int64_t arg_28h, int64_t arg_30h)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint8_t *puVar7;
    int64_t iVar8;
    uint8_t **in_RDX;
    uint8_t *puVar9;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801eefec;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int64_t *)(in_RCX + 0x15a0) == 0) {
        *(undefined2 *)(in_RCX + 0xb52) = 0;
        return 1;
    }
    puVar1 = *in_RDX;
    puVar9 = in_RDX[1];
    puVar7 = in_RDX[1];
    *(uint8_t **)((int64_t)&arg_28h + iVar6) = puVar1;
    *(uint8_t **)((int64_t)&arg_30h + iVar6) = puVar9;
    if (puVar7 == (uint8_t *)0x0) {
code_r0x0001801ef0b7:
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ef0bc;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    } else {
        puVar7 = puVar7 + -1;
        puVar9 = (uint8_t *)(uint64_t)*puVar1;
        if (puVar7 < puVar9) goto code_r0x0001801ef0b7;
        iVar8 = (int64_t)puVar7 - (int64_t)puVar9;
        *(uint8_t **)((int64_t)&arg_28h + iVar6) = puVar9 + (int64_t)(puVar1 + 1);
        *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar8;
        if (iVar8 != 0) goto code_r0x0001801ef0b7;
        uVar2 = *(undefined4 *)((int64_t)&arg_28h + iVar6 + 4);
        uVar3 = *(undefined4 *)((int64_t)&arg_30h + iVar6);
        uVar4 = *(undefined4 *)((int64_t)&arg_30h + iVar6 + 4);
        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&arg_28h + iVar6);
        *(undefined4 *)((int64_t)in_RDX + 4) = uVar2;
        *(undefined4 *)(in_RDX + 1) = uVar3;
        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar4;
        if (puVar9 != (uint8_t *)0x0) {
            *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = in_RCX + 0xb52;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ef085;
            cVar5 = fcn.1801eaef0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
            *(char *)(in_RCX + 0xb53) = cVar5;
            if (cVar5 == '\x01') {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ef098;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ef0b0;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar6));
            goto code_r0x0001801ef0d9;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ef05f;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ef0d4;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
code_r0x0001801ef0d9:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ef0ea;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801ef100
// Address: 0x1801ef100
// Size: 123 bytes
// ============================================================
undefined8 fcn.1801ef100(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    char cVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef10c;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar3 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar3;
    if (uVar11 < 2) {
code_r0x0001801ef39d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3a2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3ba;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3d0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
        return 0;
    }
    uVar11 = uVar11 - 2;
    uVar10 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
    if (uVar11 < uVar10) goto code_r0x0001801ef39d;
    iVar12 = uVar11 - uVar10;
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
    *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
    if (iVar12 != 0) goto code_r0x0001801ef39d;
    uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar9);
    *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
    *(undefined4 *)(in_RDX + 1) = uVar5;
    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
    if (uVar10 == 0) goto code_r0x0001801ef39d;
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
    cVar2 = puVar7[2];
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBP;
    if ((cVar2 == '\0') && (1 < uVar10 - 1)) {
        puVar1 = puVar7 + 5;
        uVar11 = (uint64_t)CONCAT11(puVar7[3], puVar7[4]);
        if (uVar10 - 3 == uVar11) {
            if ((*(int32_t *)(in_RCX + 0x508) != 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) || (iVar8 == 0x10000)))) {
                iVar12 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&arg_50h + iVar9) = unaff_RSI;
                iVar12 = *(int64_t *)(iVar12 + 0x318);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef206;
                    uVar10 = func_0x000180498cd0(iVar12);
                    if (uVar11 == uVar10) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef219;
                        iVar8 = func_0x0001802262e0(puVar1, iVar12, uVar10);
                        if (iVar8 == 0) {
                            *(undefined4 *)(in_RCX + 0xb60) = 1;
                            return 1;
                        }
                    }
                }
                *(undefined4 *)(in_RCX + 0xb60) = 0;
                return 1;
            }
            if (uVar11 < 0x100) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2a5;
                iVar12 = func_0x000180498a80(puVar1, 0, uVar11);
                if (iVar12 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0xa18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2cf;
                    fcn.180224990(uVar3, 0x1804b7630, 0x9b);
                    *(undefined8 *)(in_RCX + 0xa18) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2ec;
                    fcn.180224990(0, 0x1804a9450, 0x1f6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef304;
                    iVar12 = func_0x000180223270(puVar1, uVar11, 0x1804a9450, 0x1f9);
                    *(int64_t *)(in_RCX + 0xa18) = iVar12;
                    if (iVar12 != 0) {
                        *(undefined4 *)(in_RCX + 0xb60) = 1;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef315;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef32d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9));
                    goto code_r0x0001801ef33b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2af;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef26d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef285;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                          *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar9));
            goto code_r0x0001801ef33b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef375;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef38d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                  *(int64_t *)((int64_t)&arg_48h + iVar9));
code_r0x0001801ef33b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef343;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
    return 0;
}

// ============================================================
// Function: FUN_1801ef17b
// Address: 0x1801ef17b
// Size: 194 bytes
// ============================================================
undefined8 fcn.1801ef100(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    char cVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef10c;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar3 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar3;
    if (uVar11 < 2) {
code_r0x0001801ef39d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3a2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3ba;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3d0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
        return 0;
    }
    uVar11 = uVar11 - 2;
    uVar10 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
    if (uVar11 < uVar10) goto code_r0x0001801ef39d;
    iVar12 = uVar11 - uVar10;
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
    *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
    if (iVar12 != 0) goto code_r0x0001801ef39d;
    uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar9);
    *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
    *(undefined4 *)(in_RDX + 1) = uVar5;
    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
    if (uVar10 == 0) goto code_r0x0001801ef39d;
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
    cVar2 = puVar7[2];
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBP;
    if ((cVar2 == '\0') && (1 < uVar10 - 1)) {
        puVar1 = puVar7 + 5;
        uVar11 = (uint64_t)CONCAT11(puVar7[3], puVar7[4]);
        if (uVar10 - 3 == uVar11) {
            if ((*(int32_t *)(in_RCX + 0x508) != 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) || (iVar8 == 0x10000)))) {
                iVar12 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&arg_50h + iVar9) = unaff_RSI;
                iVar12 = *(int64_t *)(iVar12 + 0x318);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef206;
                    uVar10 = func_0x000180498cd0(iVar12);
                    if (uVar11 == uVar10) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef219;
                        iVar8 = func_0x0001802262e0(puVar1, iVar12, uVar10);
                        if (iVar8 == 0) {
                            *(undefined4 *)(in_RCX + 0xb60) = 1;
                            return 1;
                        }
                    }
                }
                *(undefined4 *)(in_RCX + 0xb60) = 0;
                return 1;
            }
            if (uVar11 < 0x100) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2a5;
                iVar12 = func_0x000180498a80(puVar1, 0, uVar11);
                if (iVar12 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0xa18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2cf;
                    fcn.180224990(uVar3, 0x1804b7630, 0x9b);
                    *(undefined8 *)(in_RCX + 0xa18) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2ec;
                    fcn.180224990(0, 0x1804a9450, 0x1f6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef304;
                    iVar12 = func_0x000180223270(puVar1, uVar11, 0x1804a9450, 0x1f9);
                    *(int64_t *)(in_RCX + 0xa18) = iVar12;
                    if (iVar12 != 0) {
                        *(undefined4 *)(in_RCX + 0xb60) = 1;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef315;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef32d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9));
                    goto code_r0x0001801ef33b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2af;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef26d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef285;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                          *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar9));
            goto code_r0x0001801ef33b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef375;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef38d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                  *(int64_t *)((int64_t)&arg_48h + iVar9));
code_r0x0001801ef33b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef343;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
    return 0;
}

// ============================================================
// Function: FUN_1801ef23d
// Address: 0x1801ef23d
// Size: 34 bytes
// ============================================================
undefined8 fcn.1801ef100(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    char cVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef10c;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar3 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar3;
    if (uVar11 < 2) {
code_r0x0001801ef39d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3a2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3ba;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3d0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
        return 0;
    }
    uVar11 = uVar11 - 2;
    uVar10 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
    if (uVar11 < uVar10) goto code_r0x0001801ef39d;
    iVar12 = uVar11 - uVar10;
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
    *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
    if (iVar12 != 0) goto code_r0x0001801ef39d;
    uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar9);
    *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
    *(undefined4 *)(in_RDX + 1) = uVar5;
    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
    if (uVar10 == 0) goto code_r0x0001801ef39d;
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
    cVar2 = puVar7[2];
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBP;
    if ((cVar2 == '\0') && (1 < uVar10 - 1)) {
        puVar1 = puVar7 + 5;
        uVar11 = (uint64_t)CONCAT11(puVar7[3], puVar7[4]);
        if (uVar10 - 3 == uVar11) {
            if ((*(int32_t *)(in_RCX + 0x508) != 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) || (iVar8 == 0x10000)))) {
                iVar12 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&arg_50h + iVar9) = unaff_RSI;
                iVar12 = *(int64_t *)(iVar12 + 0x318);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef206;
                    uVar10 = func_0x000180498cd0(iVar12);
                    if (uVar11 == uVar10) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef219;
                        iVar8 = func_0x0001802262e0(puVar1, iVar12, uVar10);
                        if (iVar8 == 0) {
                            *(undefined4 *)(in_RCX + 0xb60) = 1;
                            return 1;
                        }
                    }
                }
                *(undefined4 *)(in_RCX + 0xb60) = 0;
                return 1;
            }
            if (uVar11 < 0x100) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2a5;
                iVar12 = func_0x000180498a80(puVar1, 0, uVar11);
                if (iVar12 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0xa18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2cf;
                    fcn.180224990(uVar3, 0x1804b7630, 0x9b);
                    *(undefined8 *)(in_RCX + 0xa18) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2ec;
                    fcn.180224990(0, 0x1804a9450, 0x1f6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef304;
                    iVar12 = func_0x000180223270(puVar1, uVar11, 0x1804a9450, 0x1f9);
                    *(int64_t *)(in_RCX + 0xa18) = iVar12;
                    if (iVar12 != 0) {
                        *(undefined4 *)(in_RCX + 0xb60) = 1;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef315;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef32d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9));
                    goto code_r0x0001801ef33b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2af;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef26d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef285;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                          *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar9));
            goto code_r0x0001801ef33b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef375;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef38d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                  *(int64_t *)((int64_t)&arg_48h + iVar9));
code_r0x0001801ef33b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef343;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
    return 0;
}

// ============================================================
// Function: FUN_1801ef25f
// Address: 0x1801ef25f
// Size: 246 bytes
// ============================================================
undefined8 fcn.1801ef100(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    char cVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef10c;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar3 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar3;
    if (uVar11 < 2) {
code_r0x0001801ef39d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3a2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3ba;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3d0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
        return 0;
    }
    uVar11 = uVar11 - 2;
    uVar10 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
    if (uVar11 < uVar10) goto code_r0x0001801ef39d;
    iVar12 = uVar11 - uVar10;
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
    *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
    if (iVar12 != 0) goto code_r0x0001801ef39d;
    uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar9);
    *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
    *(undefined4 *)(in_RDX + 1) = uVar5;
    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
    if (uVar10 == 0) goto code_r0x0001801ef39d;
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
    cVar2 = puVar7[2];
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBP;
    if ((cVar2 == '\0') && (1 < uVar10 - 1)) {
        puVar1 = puVar7 + 5;
        uVar11 = (uint64_t)CONCAT11(puVar7[3], puVar7[4]);
        if (uVar10 - 3 == uVar11) {
            if ((*(int32_t *)(in_RCX + 0x508) != 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) || (iVar8 == 0x10000)))) {
                iVar12 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&arg_50h + iVar9) = unaff_RSI;
                iVar12 = *(int64_t *)(iVar12 + 0x318);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef206;
                    uVar10 = func_0x000180498cd0(iVar12);
                    if (uVar11 == uVar10) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef219;
                        iVar8 = func_0x0001802262e0(puVar1, iVar12, uVar10);
                        if (iVar8 == 0) {
                            *(undefined4 *)(in_RCX + 0xb60) = 1;
                            return 1;
                        }
                    }
                }
                *(undefined4 *)(in_RCX + 0xb60) = 0;
                return 1;
            }
            if (uVar11 < 0x100) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2a5;
                iVar12 = func_0x000180498a80(puVar1, 0, uVar11);
                if (iVar12 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0xa18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2cf;
                    fcn.180224990(uVar3, 0x1804b7630, 0x9b);
                    *(undefined8 *)(in_RCX + 0xa18) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2ec;
                    fcn.180224990(0, 0x1804a9450, 0x1f6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef304;
                    iVar12 = func_0x000180223270(puVar1, uVar11, 0x1804a9450, 0x1f9);
                    *(int64_t *)(in_RCX + 0xa18) = iVar12;
                    if (iVar12 != 0) {
                        *(undefined4 *)(in_RCX + 0xb60) = 1;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef315;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef32d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9));
                    goto code_r0x0001801ef33b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2af;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef26d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef285;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                          *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar9));
            goto code_r0x0001801ef33b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef375;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef38d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                  *(int64_t *)((int64_t)&arg_48h + iVar9));
code_r0x0001801ef33b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef343;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
    return 0;
}

// ============================================================
// Function: FUN_1801ef355
// Address: 0x1801ef355
// Size: 27 bytes
// ============================================================
undefined8 fcn.1801ef100(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    char cVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef10c;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar3 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar3;
    if (uVar11 < 2) {
code_r0x0001801ef39d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3a2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3ba;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3d0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
        return 0;
    }
    uVar11 = uVar11 - 2;
    uVar10 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
    if (uVar11 < uVar10) goto code_r0x0001801ef39d;
    iVar12 = uVar11 - uVar10;
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
    *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
    if (iVar12 != 0) goto code_r0x0001801ef39d;
    uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar9);
    *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
    *(undefined4 *)(in_RDX + 1) = uVar5;
    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
    if (uVar10 == 0) goto code_r0x0001801ef39d;
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
    cVar2 = puVar7[2];
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBP;
    if ((cVar2 == '\0') && (1 < uVar10 - 1)) {
        puVar1 = puVar7 + 5;
        uVar11 = (uint64_t)CONCAT11(puVar7[3], puVar7[4]);
        if (uVar10 - 3 == uVar11) {
            if ((*(int32_t *)(in_RCX + 0x508) != 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) || (iVar8 == 0x10000)))) {
                iVar12 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&arg_50h + iVar9) = unaff_RSI;
                iVar12 = *(int64_t *)(iVar12 + 0x318);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef206;
                    uVar10 = func_0x000180498cd0(iVar12);
                    if (uVar11 == uVar10) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef219;
                        iVar8 = func_0x0001802262e0(puVar1, iVar12, uVar10);
                        if (iVar8 == 0) {
                            *(undefined4 *)(in_RCX + 0xb60) = 1;
                            return 1;
                        }
                    }
                }
                *(undefined4 *)(in_RCX + 0xb60) = 0;
                return 1;
            }
            if (uVar11 < 0x100) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2a5;
                iVar12 = func_0x000180498a80(puVar1, 0, uVar11);
                if (iVar12 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0xa18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2cf;
                    fcn.180224990(uVar3, 0x1804b7630, 0x9b);
                    *(undefined8 *)(in_RCX + 0xa18) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2ec;
                    fcn.180224990(0, 0x1804a9450, 0x1f6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef304;
                    iVar12 = func_0x000180223270(puVar1, uVar11, 0x1804a9450, 0x1f9);
                    *(int64_t *)(in_RCX + 0xa18) = iVar12;
                    if (iVar12 != 0) {
                        *(undefined4 *)(in_RCX + 0xb60) = 1;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef315;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef32d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9));
                    goto code_r0x0001801ef33b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2af;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef26d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef285;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                          *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar9));
            goto code_r0x0001801ef33b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef375;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef38d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                  *(int64_t *)((int64_t)&arg_48h + iVar9));
code_r0x0001801ef33b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef343;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
    return 0;
}

// ============================================================
// Function: FUN_1801ef370
// Address: 0x1801ef370
// Size: 45 bytes
// ============================================================
undefined8 fcn.1801ef100(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    char cVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef10c;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar3 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar3;
    if (uVar11 < 2) {
code_r0x0001801ef39d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3a2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3ba;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3d0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
        return 0;
    }
    uVar11 = uVar11 - 2;
    uVar10 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
    if (uVar11 < uVar10) goto code_r0x0001801ef39d;
    iVar12 = uVar11 - uVar10;
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
    *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
    if (iVar12 != 0) goto code_r0x0001801ef39d;
    uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar9);
    *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
    *(undefined4 *)(in_RDX + 1) = uVar5;
    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
    if (uVar10 == 0) goto code_r0x0001801ef39d;
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
    cVar2 = puVar7[2];
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBP;
    if ((cVar2 == '\0') && (1 < uVar10 - 1)) {
        puVar1 = puVar7 + 5;
        uVar11 = (uint64_t)CONCAT11(puVar7[3], puVar7[4]);
        if (uVar10 - 3 == uVar11) {
            if ((*(int32_t *)(in_RCX + 0x508) != 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) || (iVar8 == 0x10000)))) {
                iVar12 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&arg_50h + iVar9) = unaff_RSI;
                iVar12 = *(int64_t *)(iVar12 + 0x318);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef206;
                    uVar10 = func_0x000180498cd0(iVar12);
                    if (uVar11 == uVar10) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef219;
                        iVar8 = func_0x0001802262e0(puVar1, iVar12, uVar10);
                        if (iVar8 == 0) {
                            *(undefined4 *)(in_RCX + 0xb60) = 1;
                            return 1;
                        }
                    }
                }
                *(undefined4 *)(in_RCX + 0xb60) = 0;
                return 1;
            }
            if (uVar11 < 0x100) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2a5;
                iVar12 = func_0x000180498a80(puVar1, 0, uVar11);
                if (iVar12 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0xa18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2cf;
                    fcn.180224990(uVar3, 0x1804b7630, 0x9b);
                    *(undefined8 *)(in_RCX + 0xa18) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2ec;
                    fcn.180224990(0, 0x1804a9450, 0x1f6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef304;
                    iVar12 = func_0x000180223270(puVar1, uVar11, 0x1804a9450, 0x1f9);
                    *(int64_t *)(in_RCX + 0xa18) = iVar12;
                    if (iVar12 != 0) {
                        *(undefined4 *)(in_RCX + 0xb60) = 1;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef315;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef32d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9));
                    goto code_r0x0001801ef33b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2af;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef26d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef285;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                          *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar9));
            goto code_r0x0001801ef33b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef375;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef38d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                  *(int64_t *)((int64_t)&arg_48h + iVar9));
code_r0x0001801ef33b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef343;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
    return 0;
}

// ============================================================
// Function: FUN_1801ef39d
// Address: 0x1801ef39d
// Size: 59 bytes
// ============================================================
undefined8 fcn.1801ef100(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    char cVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef10c;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar7 = (undefined *)*in_RDX;
    uVar3 = in_RDX[1];
    uVar11 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7;
    *(undefined8 *)((int64_t)&var_20h + iVar9) = uVar3;
    if (uVar11 < 2) {
code_r0x0001801ef39d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3a2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3ba;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                      *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                      *(int64_t *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef3d0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
        return 0;
    }
    uVar11 = uVar11 - 2;
    uVar10 = (uint64_t)CONCAT11(*puVar7, puVar7[1]);
    if (uVar11 < uVar10) goto code_r0x0001801ef39d;
    iVar12 = uVar11 - uVar10;
    *(undefined **)((int64_t)&var_18h + iVar9) = puVar7 + 2 + uVar10;
    *(int64_t *)((int64_t)&var_20h + iVar9) = iVar12;
    if (iVar12 != 0) goto code_r0x0001801ef39d;
    uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar9);
    *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
    *(undefined4 *)(in_RDX + 1) = uVar5;
    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
    if (uVar10 == 0) goto code_r0x0001801ef39d;
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBX;
    cVar2 = puVar7[2];
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBP;
    if ((cVar2 == '\0') && (1 < uVar10 - 1)) {
        puVar1 = puVar7 + 5;
        uVar11 = (uint64_t)CONCAT11(puVar7[3], puVar7[4]);
        if (uVar10 - 3 == uVar11) {
            if ((*(int32_t *)(in_RCX + 0x508) != 0) &&
               ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                 (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) || (iVar8 == 0x10000)))) {
                iVar12 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&arg_50h + iVar9) = unaff_RSI;
                iVar12 = *(int64_t *)(iVar12 + 0x318);
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef206;
                    uVar10 = func_0x000180498cd0(iVar12);
                    if (uVar11 == uVar10) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef219;
                        iVar8 = func_0x0001802262e0(puVar1, iVar12, uVar10);
                        if (iVar8 == 0) {
                            *(undefined4 *)(in_RCX + 0xb60) = 1;
                            return 1;
                        }
                    }
                }
                *(undefined4 *)(in_RCX + 0xb60) = 0;
                return 1;
            }
            if (uVar11 < 0x100) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2a5;
                iVar12 = func_0x000180498a80(puVar1, 0, uVar11);
                if (iVar12 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0xa18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2cf;
                    fcn.180224990(uVar3, 0x1804b7630, 0x9b);
                    *(undefined8 *)(in_RCX + 0xa18) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2ec;
                    fcn.180224990(0, 0x1804a9450, 0x1f6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef304;
                    iVar12 = func_0x000180223270(puVar1, uVar11, 0x1804a9450, 0x1f9);
                    *(int64_t *)(in_RCX + 0xa18) = iVar12;
                    if (iVar12 != 0) {
                        *(undefined4 *)(in_RCX + 0xb60) = 1;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef315;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef32d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar9));
                    goto code_r0x0001801ef33b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef2af;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef26d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef285;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                          *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar9));
            goto code_r0x0001801ef33b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef375;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef38d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                  *(int64_t *)(&stack0x00000028 + iVar9), *(int64_t *)(&stack0x00000030 + iVar9), 
                  *(int64_t *)((int64_t)&arg_48h + iVar9));
code_r0x0001801ef33b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801ef343;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar9));
    return 0;
}

// ============================================================
// Function: FUN_1801ef3e0
// Address: 0x1801ef3e0
// Size: 124 bytes
// ============================================================
undefined8 fcn.1801ef3e0(int64_t param_1, undefined8 *param_2)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef3ec;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    pcVar2 = *(code **)(param_1 + 0xad0);
    if (pcVar2 != (code *)0x0) {
        uVar3 = *(undefined8 *)(param_1 + 0xad8);
        uVar1 = *(undefined4 *)(param_2 + 1);
        uVar4 = *param_2;
        uVar5 = *(undefined8 *)(param_1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef412;
        iVar6 = (*pcVar2)(uVar5, uVar4, uVar1, uVar3);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef41b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef433;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef449;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar7));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801ef460
// Address: 0x1801ef460
// Size: 235 bytes
// ============================================================
undefined8 fcn.1801ef460(int64_t param_1, undefined8 *param_2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined *puVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef46c;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar5 = (undefined *)*param_2;
    uVar6 = param_2[1];
    uVar10 = param_2[1];
    *(undefined **)((int64_t)&var_18h + iVar8) = puVar5;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = uVar6;
    if (1 < uVar10) {
        uVar10 = uVar10 - 2;
        uVar9 = (uint64_t)CONCAT11(*puVar5, puVar5[1]);
        if (uVar9 <= uVar10) {
            iVar11 = uVar10 - uVar9;
            *(undefined **)((int64_t)&var_18h + iVar8) = puVar5 + 2 + uVar9;
            *(int64_t *)((int64_t)&var_20h + iVar8) = iVar11;
            if (iVar11 == 0) {
                uVar1 = *(undefined4 *)((int64_t)&var_18h + iVar8);
                uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar8 + 4);
                uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar8);
                uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar8 + 4);
                *(undefined **)((int64_t)&var_18h + iVar8) = puVar5 + 2;
                *(uint64_t *)((int64_t)&var_20h + iVar8) = uVar9;
                *(undefined4 *)param_2 = uVar1;
                *(undefined4 *)((int64_t)param_2 + 4) = uVar2;
                *(undefined4 *)(param_2 + 1) = uVar3;
                *(undefined4 *)((int64_t)param_2 + 0xc) = uVar4;
                if (uVar9 != 0) {
                    if ((*(int32_t *)(param_1 + 0x78) != 0) && (*(int32_t *)(param_1 + 0x508) != 0)) {
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef4f5;
                    iVar7 = func_0x0001801ab8b0(param_1, (int64_t)&var_18h + iVar8, 0);
                    if (iVar7 != 0) {
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef4fe;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x0001801ef51a;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef515;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
code_r0x0001801ef51a:
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef52d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000028 + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef543;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_1801ef550
// Address: 0x1801ef550
// Size: 238 bytes
// ============================================================
undefined8 fcn.1801ef550(int64_t param_1, undefined8 *param_2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined *puVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef55c;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar5 = (undefined *)*param_2;
    uVar6 = param_2[1];
    uVar10 = param_2[1];
    *(undefined **)((int64_t)&var_18h + iVar8) = puVar5;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = uVar6;
    if (1 < uVar10) {
        uVar10 = uVar10 - 2;
        uVar9 = (uint64_t)CONCAT11(*puVar5, puVar5[1]);
        if (uVar9 <= uVar10) {
            iVar11 = uVar10 - uVar9;
            *(undefined **)((int64_t)&var_18h + iVar8) = puVar5 + 2 + uVar9;
            *(int64_t *)((int64_t)&var_20h + iVar8) = iVar11;
            if (iVar11 == 0) {
                uVar1 = *(undefined4 *)((int64_t)&var_18h + iVar8);
                uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar8 + 4);
                uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar8);
                uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar8 + 4);
                *(undefined **)((int64_t)&var_18h + iVar8) = puVar5 + 2;
                *(uint64_t *)((int64_t)&var_20h + iVar8) = uVar9;
                *(undefined4 *)param_2 = uVar1;
                *(undefined4 *)((int64_t)param_2 + 4) = uVar2;
                *(undefined4 *)(param_2 + 1) = uVar3;
                *(undefined4 *)((int64_t)param_2 + 0xc) = uVar4;
                if (uVar9 != 0) {
                    if ((*(int32_t *)(param_1 + 0x78) != 0) && (*(int32_t *)(param_1 + 0x508) != 0)) {
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef5e8;
                    iVar7 = func_0x0001801ab8b0(param_1, (int64_t)&var_18h + iVar8, 1);
                    if (iVar7 != 0) {
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef5f1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x0001801ef60d;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef608;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8));
code_r0x0001801ef60d:
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef620;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_20h + iVar8), 
                  *(int64_t *)(&stack0x00000028 + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801ef636;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_1801ef640
// Address: 0x1801ef640
// Size: 313 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801ef640(int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    uint8_t *puVar8;
    int64_t iVar9;
    uint8_t **in_RDX;
    uint8_t *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ef655;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar1 = *in_RDX;
    puVar10 = in_RDX[1];
    puVar8 = in_RDX[1];
    *(uint8_t **)((int64_t)&var_18h + iVar7) = puVar1;
    *(uint8_t **)((int64_t)&var_20h + iVar7) = puVar10;
    if (puVar8 != (uint8_t *)0x0) {
        puVar8 = puVar8 + -1;
        uVar2 = *puVar1;
        puVar10 = (uint8_t *)(uint64_t)uVar2;
        puVar1 = puVar1 + 1;
        if (puVar10 <= puVar8) {
            iVar9 = (int64_t)puVar8 - (int64_t)puVar10;
            *(uint8_t **)((int64_t)&var_18h + iVar7) = puVar10 + (int64_t)puVar1;
            *(int64_t *)((int64_t)&var_20h + iVar7) = iVar9;
            if (iVar9 == 0) {
                uVar4 = *(undefined4 *)((int64_t)&var_18h + iVar7 + 4);
                uVar5 = *(undefined4 *)((int64_t)&var_20h + iVar7);
                uVar6 = *(undefined4 *)((int64_t)&var_20h + iVar7 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar7);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef6b4;
                iVar9 = func_0x000180498a80(puVar1, 0, uVar2);
                if (iVar9 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 0xbf0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef6d2;
                    fcn.180224990(uVar3, 0x1804a9450, 0x1f6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef6e9;
                    iVar9 = func_0x000180223270(puVar1, uVar2, 0x1804a9450, 0x1f9);
                    *(int64_t *)(in_RCX + 0xbf0) = iVar9;
                    if (iVar9 != 0) {
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef6fa;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef712;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar7));
                    goto code_r0x0001801ef75c;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef739;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef751;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                  *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                  *(int64_t *)(&stack0x00000048 + iVar7));
code_r0x0001801ef75c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801ef767;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1801ef780
// Address: 0x1801ef780
// Size: 1088 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801ef780(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined *puVar1;
    uint8_t *puVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    undefined *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint8_t *puVar13;
    uint8_t **in_RDX;
    uint64_t uVar14;
    uint64_t uVar15;
    uint8_t *puVar16;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ef79e;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((*(int32_t *)(in_RCX + 0x508) == 0) && (in_R9 == 0)) {
        if (in_RDX[1] == (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efb8b;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efba3;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                          *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                          *(int64_t *)(&stack0x00000038 + iVar10));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efbb9;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
            return 0;
        }
        *(uint32_t *)(in_RCX + 0xa20) = (uint32_t)**in_RDX;
        *in_RDX = *in_RDX + 1;
        in_RDX[1] = in_RDX[1] + -1;
        if (*(int32_t *)(in_RCX + 0xa20) == 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef810;
            iVar9 = fcn.1801b4960(in_RDX, (int64_t)&var_8h + iVar10);
            if (iVar9 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef819;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10));
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef831;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                              *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000038 + iVar10));
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef847;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef85e;
            fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                          *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                          *(int64_t *)(&stack0x00000040 + iVar10));
            uVar14 = *(uint64_t *)((int64_t)&var_10h + iVar10);
            if (uVar14 == 0) {
                *(undefined8 *)(in_RCX + 0xa38) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef86d;
                iVar11 = fcn.180221f20();
                *(int64_t *)(in_RCX + 0xa38) = iVar11;
                if (iVar11 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef87e;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef896;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                                  *(int64_t *)(&stack0x00000038 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef8ac;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
                    return 0;
                }
            }
            if (uVar14 == 0) {
code_r0x0001801efa6c:
                puVar16 = *in_RDX;
                puVar2 = in_RDX[1];
                puVar13 = in_RDX[1];
                *(uint8_t **)((int64_t)&var_8h + iVar10) = puVar16;
                *(uint8_t **)((int64_t)&var_10h + iVar10) = puVar2;
                if ((uint8_t *)0x1 < puVar13) {
                    puVar13 = puVar13 + -2;
                    uVar3 = *puVar16;
                    puVar2 = puVar16 + 2;
                    uVar4 = puVar16[1];
                    puVar16 = (uint8_t *)(uint64_t)CONCAT11(uVar3, uVar4);
                    if (puVar16 <= puVar13) {
                        iVar11 = (int64_t)puVar13 - (int64_t)puVar16;
                        *(uint8_t **)((int64_t)&var_8h + iVar10) = puVar2 + (int64_t)puVar16;
                        *(int64_t *)((int64_t)&var_10h + iVar10) = iVar11;
                        if (iVar11 == 0) {
                            uVar6 = *(undefined4 *)((int64_t)&var_8h + iVar10 + 4);
                            uVar7 = *(undefined4 *)((int64_t)&var_10h + iVar10);
                            uVar8 = *(undefined4 *)((int64_t)&var_10h + iVar10 + 4);
                            *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_8h + iVar10);
                            *(undefined4 *)((int64_t)in_RDX + 4) = uVar6;
                            *(undefined4 *)(in_RDX + 1) = uVar7;
                            *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar8;
                            if (puVar16 == (uint8_t *)0x0) {
                                return 1;
                            }
                            *(uint8_t **)((int64_t)&arg_48h + iVar10) = puVar2;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efae8;
                            fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar10), 
                                          *(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)((int64_t)&var_18h + iVar10), 
                                          *(int64_t *)((int64_t)&var_20h + iVar10), 
                                          *(int64_t *)(&stack0x00000040 + iVar10));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efaf7;
                            iVar11 = fcn.180237470(0, (int64_t)&arg_48h + iVar10, CONCAT11(uVar3, uVar4));
                            *(int64_t *)(in_RCX + 0xa40) = iVar11;
                            if ((iVar11 != 0) &&
                               (*(uint8_t **)((int64_t)&arg_48h + iVar10) == puVar2 + (int64_t)puVar16)) {
                                return 1;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efb17;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), 
                                          *(int64_t *)((int64_t)&var_10h + iVar10));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efb2f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), 
                                          *(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)((int64_t)&var_18h + iVar10), 
                                          *(int64_t *)((int64_t)&var_20h + iVar10), 
                                          *(int64_t *)(&stack0x00000038 + iVar10));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efb45;
                            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
                            return 0;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efb51;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10));
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efb69;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                              *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000038 + iVar10));
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efb7f;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
                return 0;
            }
            while (1 < uVar14) {
                puVar5 = *(undefined **)((int64_t)&var_8h + iVar10);
                puVar1 = puVar5 + 2;
                uVar15 = (uint64_t)CONCAT11(*puVar5, puVar5[1]);
                if (uVar14 - 2 < uVar15) break;
                iVar11 = (uVar14 - 2) - uVar15;
                *(undefined **)((int64_t)&var_18h + iVar10) = puVar1 + uVar15;
                *(int64_t *)((int64_t)&var_20h + iVar10) = iVar11;
                uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar10 + 4);
                uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar10);
                uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar10 + 4);
                *(undefined4 *)((int64_t)&var_8h + iVar10) = *(undefined4 *)((int64_t)&var_18h + iVar10);
                *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = uVar6;
                *(undefined4 *)((int64_t)&var_10h + iVar10) = uVar7;
                *(undefined4 *)((int64_t)&var_10h + iVar10 + 4) = uVar8;
                if (uVar15 == 0) break;
                *(undefined **)((int64_t)&arg_48h + iVar10) = puVar1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef937;
                iVar12 = fcn.18023f260(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                       *(int64_t *)((int64_t)&var_18h + iVar10), 
                                       *(int64_t *)((int64_t)&var_20h + iVar10), *(int64_t *)(&stack0x00000028 + iVar10)
                                       , *(int64_t *)(&stack0x00000030 + iVar10), 
                                       *(int64_t *)(&stack0x00000038 + iVar10), *(int64_t *)(&stack0x00000040 + iVar10)
                                       , *(int64_t *)((int64_t)&arg_50h + iVar10), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar10), *(int64_t *)(&stack0x00000070 + iVar10)
                                      );
                if (iVar12 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef9fd;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efa15;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                                  *(int64_t *)(&stack0x00000038 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efa2b;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
                    return 0;
                }
                if (*(undefined **)((int64_t)&arg_48h + iVar10) != puVar1 + uVar15) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef9be;
                    fcn.18023f210(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0x00000038 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef9c3;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef9db;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                                  *(int64_t *)(&stack0x00000038 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef9f1;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef95d;
                iVar9 = fcn.180222110(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                      , *(int64_t *)(&stack0x00000030 + iVar10), *(int64_t *)(&stack0x00000038 + iVar10)
                                      , *(int64_t *)(&stack0x00000040 + iVar10));
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef97c;
                    fcn.18023f210(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0x00000038 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef981;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef999;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                                  *(int64_t *)(&stack0x00000038 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801ef9af;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
                    return 0;
                }
                if (iVar11 == 0) goto code_r0x0001801efa6c;
                uVar14 = *(uint64_t *)((int64_t)&var_10h + iVar10);
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efa37;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efa4f;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)&var_10h + iVar10), 
                          *(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                          *(int64_t *)(&stack0x00000038 + iVar10));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801efa65;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar10));
            return 0;
        }
        *(undefined4 *)(in_RCX + 0xa20) = 0xffffffff;
    }
    return 1;
}

