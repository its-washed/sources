// Chunk 44 - 50 functions

// ============================================================
// Function: FUN_180091c30
// Address: 0x180091c30
// Size: 37 bytes
// ============================================================
undefined8 fcn.180091c30(int64_t arg1)
{
    int32_t iVar1;
    
    iVar1 = fcn.180086c20();
    if (iVar1 != 0) {
        fcn.180086510(arg1);
    }
    return 1;
}

// ============================================================
// Function: FUN_180091c60
// Address: 0x180091c60
// Size: 32 bytes
// ============================================================
undefined8 fcn.180091c60(int64_t arg1)
{
    fcn.180086b20(arg1, *(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a));
    return 1;
}

// ============================================================
// Function: FUN_180091c80
// Address: 0x180091c80
// Size: 444 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180091c80(int64_t arg1)
{
    char cVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (piVar2 <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar8 + 0xc) != 10) || (iVar3 = *piVar8, iVar3 == 0)) {
        func_0x0001800883d0(arg1, 1, 0x18063cb4c);
        pcVar5 = (code *)swi(3);
        uVar7 = (*pcVar5)();
        return uVar7;
    }
    if (iVar3 == arg1) {
        puVar9 = (undefined8 *)0x180611c70;
        goto code_r0x000180091e14;
    }
    cVar1 = *(char *)(iVar3 + 3);
    if (cVar1 == '\x01') {
code_r0x000180091da6:
        if (((*(char *)0x180777010 == '\0') || (piVar2 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
            puVar4 = *(undefined4 **)(arg1 + 0x40);
            *puVar4 = 1;
            puVar4[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x00018009a4a0(iVar3);
            return 1;
        }
code_r0x000180091e24:
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar5 = (code *)swi(3);
        uVar7 = (*pcVar5)();
        return uVar7;
    }
    if (cVar1 != '\x06') {
        if (cVar1 != '\0') {
            if (((*(char *)0x180777010 == '\0') || (piVar2 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
               (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
                puVar4 = *(undefined4 **)(arg1 + 0x40);
                *puVar4 = 0;
                puVar4[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                if (*(char *)(iVar3 + 3) == '\x04') {
                    func_0x0001800867f0(arg1, 0x18063ddf8, 0x11);
                } else if (*(char *)(iVar3 + 3) == '\x05') {
                    func_0x0001800867f0(arg1, 0x18063dde0, 0x17);
                } else if ((int32_t)(*(int64_t *)(iVar3 + 0x40) - *(int64_t *)(iVar3 + 0x28) >> 4) != 0) {
                    func_0x000180085680(iVar3, arg1, 1);
                }
                func_0x00018009a4a0(iVar3);
                return 2;
            }
            goto code_r0x000180091e24;
        }
        if (*(int64_t *)(iVar3 + 0x18) == *(int64_t *)(iVar3 + 0x78)) goto code_r0x000180091da6;
    }
    puVar9 = (undefined8 *)0x180611c80;
code_r0x000180091e14:
    func_0x000180088560(arg1, 0x18063dd60, *puVar9);
    pcVar5 = (code *)swi(3);
    uVar7 = (*pcVar5)();
    return uVar7;
}

// ============================================================
// Function: FUN_180091e40
// Address: 0x180091e40
// Size: 506 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.180091e40(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    undefined8 *puVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t var_38h;
    
    puVar7 = (undefined8 *)0x180611bf0;
    iVar8 = 0;
    piVar2 = (int64_t *)0x180611bf0;
    do {
        iVar8 = iVar8 + 1;
        piVar2 = piVar2 + 2;
    } while (*piVar2 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x180625b18);
    iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar3;
        iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x180625b18, iVar8);
        if (iVar3 != 0) {
            func_0x000180088560(arg1, 0x18063da68, 0x180625b18);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = fcn.180085510(unaff_RDI), iVar8 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-4];
        puVar4[1] = puVar4[-3];
        puVar4[2] = puVar4[-2];
        puVar4[3] = puVar4[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x180625b18);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar4 = puVar6 + -4;
    if (puVar4 < puVar6) {
        do {
            puVar4[-4] = *puVar4;
            puVar4[-3] = puVar4[1];
            puVar4[-2] = puVar4[2];
            puVar4[-1] = puVar4[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar4 = puVar4 + 4;
        } while (puVar4 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar3 = 0x18063c32c;
    do {
        func_0x0001800869f0(arg1, puVar7[1], iVar3, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar7);
        iVar3 = puVar7[2];
        puVar7 = puVar7 + 2;
    } while (iVar3 != 0);
    func_0x0001800869f0(arg1, 0x1800916f0, 0x18063c9d0, 0, 0x1800917b0);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063c9d0);
    return 1;
}

// ============================================================
// Function: FUN_180092040
// Address: 0x180092040
// Size: 903 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_16eh
// WARNING: [rz-ghidra] Detected overlap for variable var_174h
// WARNING: [rz-ghidra] Detected overlap for variable var_178h

void fcn.180092040(int64_t arg1)
{
    char *pcVar1;
    char cVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    char *pcVar13;
    uint32_t uVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_1b8h;
    int64_t var_1ach;
    int64_t var_198h;
    undefined4 var_174h;
    int64_t var_16fh;
    int64_t var_190h;
    int64_t var_180h;
    char acStack_b9 [97];
    int64_t var_58h;
    int64_t var_4eh;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_1b8h;
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar6 = piVar8;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 10)) {
        iVar5 = 0;
        iVar10 = arg1;
code_r0x0001800920da:
        uVar12 = 0;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        iVar10 = 0;
        if (*(int32_t *)((int64_t)piVar8 + 0xc) == 10) {
            iVar10 = *piVar8;
        }
        if (arg1 == iVar10) {
            iVar5 = 1;
            goto code_r0x0001800920da;
        }
        fcn.180085610(iVar10, 1);
        iVar5 = 1;
        uVar12 = *(int64_t *)(iVar10 + 0x40) - *(int64_t *)(iVar10 + 0x28) >> 4;
    }
    uVar11 = 0;
    iVar4 = func_0x000180085d50(arg1, iVar5 + 1);
    if (iVar4 == 0) {
        if (iVar5 != 0) {
code_r0x000180092347:
            func_0x000180088380(arg1, iVar5 + 1, 0x18063de10);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar6 = piVar8;
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8))
        goto code_r0x000180092347;
        iVar4 = -(int32_t)((int64_t)*(int64_t **)(arg1 + 0x40) - (int64_t)piVar8 >> 4);
    } else {
        iVar4 = func_0x000180085f50(arg1, iVar5 + 1, 0);
        if (iVar4 < 0) {
            func_0x000180088380(arg1, iVar5 + 1, 0x180622770);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    }
    uVar14 = iVar5 + 2;
    piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (uint64_t)uVar14 * 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009236f;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + (uint64_t)uVar14 * 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    pcVar13 = (char *)(*piVar8 + 0x18);
    if (pcVar13 != (char *)0x0) {
        iVar5 = func_0x000180092a10(iVar10, iVar4, pcVar13, &var_198h);
        if (iVar5 != 0) {
            cVar2 = *pcVar13;
            _var_58h = SUB1610(ZEXT816(0), 0);
            var_4eh._0_6_ = SUB166(ZEXT816(0), 0);
            var_4eh._0_6_ = 0;
            stack0xffffffffffffffb8 = SUB1610(ZEXT816(0), 6);
            while (cVar2 != '\0') {
                if ((int32_t)cVar2 - 0x61U < 0x1a) {
                    if (acStack_b9[cVar2] != '\0') {
                        if (arg1 != iVar10) {
                            func_0x0001800858c0(iVar10, uVar12 & 0xffffffff);
                        }
                        func_0x000180088380(arg1, uVar14, 0x18063de40);
                        pcVar3 = (code *)swi(3);
                        (*pcVar3)();
                        return;
                    }
                    acStack_b9[cVar2] = '\x01';
                }
                if (cVar2 == 'a') {
                    func_0x0001800865e0(arg1, (undefined)var_16fh);
                    fcn.180086b20(arg1, (int32_t)var_16fh._1_1_);
                    uVar11 = uVar11 + 2;
                } else if (cVar2 == 'f') {
                    if (iVar10 == arg1) {
                        func_0x000180085bf0(arg1, ~uVar11);
                        uVar11 = uVar11 + 1;
                    } else {
                        func_0x000180085680(iVar10, arg1, 1);
                        uVar11 = uVar11 + 1;
                    }
                } else if (cVar2 == 'l') {
                    func_0x0001800865e0(arg1, var_174h);
                    uVar11 = uVar11 + 1;
                } else {
                    if (cVar2 == 'n') {
                        iVar9 = 0x1805aadb1;
                        if (var_198h != 0) {
                            iVar9 = var_198h;
                        }
                    } else {
                        if (cVar2 != 's') {
                            if (arg1 != iVar10) {
                                func_0x0001800858c0(iVar10, uVar12 & 0xffffffff);
                            }
                            func_0x000180088380(arg1, uVar14, 0x18063de30);
                            pcVar3 = (code *)swi(3);
                            (*pcVar3)();
                            return;
                        }
                        iVar9 = var_180h;
                        if (var_180h == 0) {
                            fcn.180086510(arg1);
                            uVar11 = uVar11 + 1;
                            goto code_r0x000180092330;
                        }
                    }
                    uVar7 = fcn.180498cd0(iVar9);
                    func_0x0001800867f0(arg1, iVar9, uVar7);
                    uVar11 = uVar11 + 1;
                }
code_r0x000180092330:
                pcVar1 = pcVar13 + 1;
                pcVar13 = pcVar13 + 1;
                cVar2 = *pcVar1;
            }
        }
        fcn.180459870(var_38h ^ (uint64_t)&var_1b8h);
        return;
    }
code_r0x00018009236f:
    func_0x000180088470(arg1, uVar14, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800923d0
// Address: 0x1800923d0
// Size: 306 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800923d0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_3d8 [32];
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_174h;
    undefined uStack_39;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3d8;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar9;
    if (piVar1 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 10)) {
        uVar10 = 1;
        iVar11 = 0;
        iVar13 = 2;
        iVar12 = arg1;
    } else {
        piVar6 = piVar9;
        if (piVar1 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 10) {
            iVar12 = *piVar6;
        } else {
            iVar12 = 0;
        }
        uVar10 = 2;
        iVar11 = 0x10;
        iVar13 = 3;
    }
    piVar9 = (int64_t *)((int64_t)piVar9 + iVar11);
    piVar6 = piVar9;
    if (piVar1 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        iVar11 = 0;
    } else {
        if (piVar1 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = func_0x0001800a8360(arg1);
            if (iVar4 == 0) goto code_r0x000180092957;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + iVar11);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar11 = *piVar9 + 0x18;
        if (iVar11 == 0) {
code_r0x000180092957:
            func_0x000180088470(arg1, uVar10, 6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + iVar13 * 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
        uVar5 = (uint32_t)(arg1 == iVar12);
    } else {
        uVar5 = func_0x000180088860(arg1, iVar13);
    }
    if (-1 < (int32_t)uVar5) {
        var_3b0h = (int64_t)&var_198h;
        var_3a0h = 0;
        var_3b8h = (int64_t)&var_398h;
        var_3a8h = arg1;
        if (iVar11 != 0) {
            uVar7 = fcn.180498cd0(iVar11);
            piVar9 = &var_398h;
            if (0x200 < uVar7) {
                func_0x0001800890e0(&var_3b8h, uVar7 - 0x200, 0xffffffff);
                piVar9 = (int64_t *)var_3b8h;
            }
            fcn.180498030(piVar9, iVar11, uVar7);
            var_3b8h = var_3b8h + uVar7;
            if (var_3b0h == var_3b8h) {
                func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
            }
            *(undefined *)var_3b8h = 10;
            var_3b8h = var_3b8h + 1;
        }
        iVar4 = func_0x000180092a10(iVar12, uVar5, 0x18063da64, &var_198h);
        iVar11 = var_3a8h;
        iVar13 = var_3a0h;
        iVar3 = var_180h;
        while (var_3a8h = iVar11, var_3a0h = iVar13, iVar4 != 0) {
            var_180h = iVar3;
            if ((*(char *)var_190h != 'C') || (*(char *)(var_190h + 1) != '\0')) {
                if (var_188h != 0) {
                    uVar7 = fcn.180498cd0(iVar3);
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, (uVar7 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    fcn.180498030(var_3b8h, iVar3, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (0 < (int32_t)(uint32_t)var_174h) {
                    piVar9 = &var_38h;
                    uVar8 = (uint32_t)var_174h;
                    do {
                        piVar9 = (int64_t *)((int64_t)piVar9 + -1);
                        *(char *)piVar9 = (char)uVar8 + (char)((uint64_t)uVar8 / 10) * -10 + '0';
                        uVar8 = (uint32_t)((uint64_t)uVar8 / 10);
                    } while (uVar8 != 0);
                    if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_3b8h = 0x3a;
                    uVar7 = (int64_t)&var_38h - (int64_t)piVar9;
                    var_3b8h = var_3b8h + 1;
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, (uVar7 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    fcn.180498030(var_3b8h, piVar9, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (var_198h != 0) {
                    if ((uint64_t)(var_3b0h - var_3b8h) < 10) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 10, 0xffffffff);
                    }
                    iVar11 = var_198h;
                    *(undefined8 *)var_3b8h = 0x6f6974636e756620;
                    *(undefined2 *)(var_3b8h + 8) = 0x206e;
                    iVar13 = var_3b8h + 10;
                    var_3b8h = iVar13;
                    uVar7 = fcn.180498cd0(var_198h);
                    if ((uint64_t)(var_3b0h - iVar13) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, uVar7 + (iVar13 - var_3b0h), 0xffffffff);
                        iVar13 = var_3b8h;
                    }
                    fcn.180498030(iVar13, iVar11, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                    func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                }
                *(undefined *)var_3b8h = 10;
                var_3b8h = var_3b8h + 1;
            }
            uVar5 = uVar5 + 1;
            iVar4 = func_0x000180092a10(iVar12, uVar5, 0x18063da64, &var_198h);
            iVar11 = var_3a8h;
            iVar13 = var_3a0h;
            iVar3 = var_180h;
        }
        if (iVar13 == 0) {
            func_0x0001800867f0(iVar11, &var_398h, (var_3b8h - (int64_t)&var_3b8h) + -0x20);
        } else {
            if (*(uint64_t *)(*(int64_t *)(iVar11 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar11 + 0x20) + 0x30))
            {
                (**(code **)0x180782658)(iVar11, 1);
            }
            iVar12 = *(int64_t *)(iVar11 + 0x40);
            if (var_3b8h == var_3b0h) {
                uVar10 = func_0x00018009a7e0(iVar11, iVar13);
                *(undefined8 *)(iVar12 + -0x10) = uVar10;
                *(undefined4 *)(iVar12 + -4) = 6;
            } else {
                uVar10 = fcn.18009a8e0(iVar11, iVar13 + 0x18, (var_3b8h - iVar13) + -0x18);
                *(undefined8 *)(iVar12 + -0x10) = uVar10;
                *(undefined4 *)(iVar12 + -4) = 6;
            }
        }
        fcn.180459870(var_38h ^ (uint64_t)auStack_3d8);
        return;
    }
    func_0x000180088380(arg1, iVar13, 0x180622770);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180092502
// Address: 0x180092502
// Size: 1090 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800923d0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_3d8 [32];
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_174h;
    undefined uStack_39;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3d8;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar9;
    if (piVar1 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 10)) {
        uVar10 = 1;
        iVar11 = 0;
        iVar13 = 2;
        iVar12 = arg1;
    } else {
        piVar6 = piVar9;
        if (piVar1 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 10) {
            iVar12 = *piVar6;
        } else {
            iVar12 = 0;
        }
        uVar10 = 2;
        iVar11 = 0x10;
        iVar13 = 3;
    }
    piVar9 = (int64_t *)((int64_t)piVar9 + iVar11);
    piVar6 = piVar9;
    if (piVar1 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        iVar11 = 0;
    } else {
        if (piVar1 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = func_0x0001800a8360(arg1);
            if (iVar4 == 0) goto code_r0x000180092957;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + iVar11);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar11 = *piVar9 + 0x18;
        if (iVar11 == 0) {
code_r0x000180092957:
            func_0x000180088470(arg1, uVar10, 6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + iVar13 * 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
        uVar5 = (uint32_t)(arg1 == iVar12);
    } else {
        uVar5 = func_0x000180088860(arg1, iVar13);
    }
    if (-1 < (int32_t)uVar5) {
        var_3b0h = (int64_t)&var_198h;
        var_3a0h = 0;
        var_3b8h = (int64_t)&var_398h;
        var_3a8h = arg1;
        if (iVar11 != 0) {
            uVar7 = fcn.180498cd0(iVar11);
            piVar9 = &var_398h;
            if (0x200 < uVar7) {
                func_0x0001800890e0(&var_3b8h, uVar7 - 0x200, 0xffffffff);
                piVar9 = (int64_t *)var_3b8h;
            }
            fcn.180498030(piVar9, iVar11, uVar7);
            var_3b8h = var_3b8h + uVar7;
            if (var_3b0h == var_3b8h) {
                func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
            }
            *(undefined *)var_3b8h = 10;
            var_3b8h = var_3b8h + 1;
        }
        iVar4 = func_0x000180092a10(iVar12, uVar5, 0x18063da64, &var_198h);
        iVar11 = var_3a8h;
        iVar13 = var_3a0h;
        iVar3 = var_180h;
        while (var_3a8h = iVar11, var_3a0h = iVar13, iVar4 != 0) {
            var_180h = iVar3;
            if ((*(char *)var_190h != 'C') || (*(char *)(var_190h + 1) != '\0')) {
                if (var_188h != 0) {
                    uVar7 = fcn.180498cd0(iVar3);
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, (uVar7 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    fcn.180498030(var_3b8h, iVar3, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (0 < (int32_t)(uint32_t)var_174h) {
                    piVar9 = &var_38h;
                    uVar8 = (uint32_t)var_174h;
                    do {
                        piVar9 = (int64_t *)((int64_t)piVar9 + -1);
                        *(char *)piVar9 = (char)uVar8 + (char)((uint64_t)uVar8 / 10) * -10 + '0';
                        uVar8 = (uint32_t)((uint64_t)uVar8 / 10);
                    } while (uVar8 != 0);
                    if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_3b8h = 0x3a;
                    uVar7 = (int64_t)&var_38h - (int64_t)piVar9;
                    var_3b8h = var_3b8h + 1;
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, (uVar7 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    fcn.180498030(var_3b8h, piVar9, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (var_198h != 0) {
                    if ((uint64_t)(var_3b0h - var_3b8h) < 10) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 10, 0xffffffff);
                    }
                    iVar11 = var_198h;
                    *(undefined8 *)var_3b8h = 0x6f6974636e756620;
                    *(undefined2 *)(var_3b8h + 8) = 0x206e;
                    iVar13 = var_3b8h + 10;
                    var_3b8h = iVar13;
                    uVar7 = fcn.180498cd0(var_198h);
                    if ((uint64_t)(var_3b0h - iVar13) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, uVar7 + (iVar13 - var_3b0h), 0xffffffff);
                        iVar13 = var_3b8h;
                    }
                    fcn.180498030(iVar13, iVar11, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                    func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                }
                *(undefined *)var_3b8h = 10;
                var_3b8h = var_3b8h + 1;
            }
            uVar5 = uVar5 + 1;
            iVar4 = func_0x000180092a10(iVar12, uVar5, 0x18063da64, &var_198h);
            iVar11 = var_3a8h;
            iVar13 = var_3a0h;
            iVar3 = var_180h;
        }
        if (iVar13 == 0) {
            func_0x0001800867f0(iVar11, &var_398h, (var_3b8h - (int64_t)&var_3b8h) + -0x20);
        } else {
            if (*(uint64_t *)(*(int64_t *)(iVar11 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar11 + 0x20) + 0x30))
            {
                (**(code **)0x180782658)(iVar11, 1);
            }
            iVar12 = *(int64_t *)(iVar11 + 0x40);
            if (var_3b8h == var_3b0h) {
                uVar10 = func_0x00018009a7e0(iVar11, iVar13);
                *(undefined8 *)(iVar12 + -0x10) = uVar10;
                *(undefined4 *)(iVar12 + -4) = 6;
            } else {
                uVar10 = fcn.18009a8e0(iVar11, iVar13 + 0x18, (var_3b8h - iVar13) + -0x18);
                *(undefined8 *)(iVar12 + -0x10) = uVar10;
                *(undefined4 *)(iVar12 + -4) = 6;
            }
        }
        fcn.180459870(var_38h ^ (uint64_t)auStack_3d8);
        return;
    }
    func_0x000180088380(arg1, iVar13, 0x180622770);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180092944
// Address: 0x180092944
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800923d0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_3d8 [32];
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_174h;
    undefined uStack_39;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3d8;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar9;
    if (piVar1 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 10)) {
        uVar10 = 1;
        iVar11 = 0;
        iVar13 = 2;
        iVar12 = arg1;
    } else {
        piVar6 = piVar9;
        if (piVar1 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 10) {
            iVar12 = *piVar6;
        } else {
            iVar12 = 0;
        }
        uVar10 = 2;
        iVar11 = 0x10;
        iVar13 = 3;
    }
    piVar9 = (int64_t *)((int64_t)piVar9 + iVar11);
    piVar6 = piVar9;
    if (piVar1 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        iVar11 = 0;
    } else {
        if (piVar1 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = func_0x0001800a8360(arg1);
            if (iVar4 == 0) goto code_r0x000180092957;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + iVar11);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar11 = *piVar9 + 0x18;
        if (iVar11 == 0) {
code_r0x000180092957:
            func_0x000180088470(arg1, uVar10, 6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + iVar13 * 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
        uVar5 = (uint32_t)(arg1 == iVar12);
    } else {
        uVar5 = func_0x000180088860(arg1, iVar13);
    }
    if (-1 < (int32_t)uVar5) {
        var_3b0h = (int64_t)&var_198h;
        var_3a0h = 0;
        var_3b8h = (int64_t)&var_398h;
        var_3a8h = arg1;
        if (iVar11 != 0) {
            uVar7 = fcn.180498cd0(iVar11);
            piVar9 = &var_398h;
            if (0x200 < uVar7) {
                func_0x0001800890e0(&var_3b8h, uVar7 - 0x200, 0xffffffff);
                piVar9 = (int64_t *)var_3b8h;
            }
            fcn.180498030(piVar9, iVar11, uVar7);
            var_3b8h = var_3b8h + uVar7;
            if (var_3b0h == var_3b8h) {
                func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
            }
            *(undefined *)var_3b8h = 10;
            var_3b8h = var_3b8h + 1;
        }
        iVar4 = func_0x000180092a10(iVar12, uVar5, 0x18063da64, &var_198h);
        iVar11 = var_3a8h;
        iVar13 = var_3a0h;
        iVar3 = var_180h;
        while (var_3a8h = iVar11, var_3a0h = iVar13, iVar4 != 0) {
            var_180h = iVar3;
            if ((*(char *)var_190h != 'C') || (*(char *)(var_190h + 1) != '\0')) {
                if (var_188h != 0) {
                    uVar7 = fcn.180498cd0(iVar3);
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, (uVar7 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    fcn.180498030(var_3b8h, iVar3, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (0 < (int32_t)(uint32_t)var_174h) {
                    piVar9 = &var_38h;
                    uVar8 = (uint32_t)var_174h;
                    do {
                        piVar9 = (int64_t *)((int64_t)piVar9 + -1);
                        *(char *)piVar9 = (char)uVar8 + (char)((uint64_t)uVar8 / 10) * -10 + '0';
                        uVar8 = (uint32_t)((uint64_t)uVar8 / 10);
                    } while (uVar8 != 0);
                    if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_3b8h = 0x3a;
                    uVar7 = (int64_t)&var_38h - (int64_t)piVar9;
                    var_3b8h = var_3b8h + 1;
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, (uVar7 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    fcn.180498030(var_3b8h, piVar9, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (var_198h != 0) {
                    if ((uint64_t)(var_3b0h - var_3b8h) < 10) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 10, 0xffffffff);
                    }
                    iVar11 = var_198h;
                    *(undefined8 *)var_3b8h = 0x6f6974636e756620;
                    *(undefined2 *)(var_3b8h + 8) = 0x206e;
                    iVar13 = var_3b8h + 10;
                    var_3b8h = iVar13;
                    uVar7 = fcn.180498cd0(var_198h);
                    if ((uint64_t)(var_3b0h - iVar13) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, uVar7 + (iVar13 - var_3b0h), 0xffffffff);
                        iVar13 = var_3b8h;
                    }
                    fcn.180498030(iVar13, iVar11, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                    func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                }
                *(undefined *)var_3b8h = 10;
                var_3b8h = var_3b8h + 1;
            }
            uVar5 = uVar5 + 1;
            iVar4 = func_0x000180092a10(iVar12, uVar5, 0x18063da64, &var_198h);
            iVar11 = var_3a8h;
            iVar13 = var_3a0h;
            iVar3 = var_180h;
        }
        if (iVar13 == 0) {
            func_0x0001800867f0(iVar11, &var_398h, (var_3b8h - (int64_t)&var_3b8h) + -0x20);
        } else {
            if (*(uint64_t *)(*(int64_t *)(iVar11 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar11 + 0x20) + 0x30))
            {
                (**(code **)0x180782658)(iVar11, 1);
            }
            iVar12 = *(int64_t *)(iVar11 + 0x40);
            if (var_3b8h == var_3b0h) {
                uVar10 = func_0x00018009a7e0(iVar11, iVar13);
                *(undefined8 *)(iVar12 + -0x10) = uVar10;
                *(undefined4 *)(iVar12 + -4) = 6;
            } else {
                uVar10 = fcn.18009a8e0(iVar11, iVar13 + 0x18, (var_3b8h - iVar13) + -0x18);
                *(undefined8 *)(iVar12 + -0x10) = uVar10;
                *(undefined4 *)(iVar12 + -4) = 6;
            }
        }
        fcn.180459870(var_38h ^ (uint64_t)auStack_3d8);
        return;
    }
    func_0x000180088380(arg1, iVar13, 0x180622770);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180092957
// Address: 0x180092957
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800923d0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_3d8 [32];
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_174h;
    undefined uStack_39;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3d8;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar9;
    if (piVar1 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 10)) {
        uVar10 = 1;
        iVar11 = 0;
        iVar13 = 2;
        iVar12 = arg1;
    } else {
        piVar6 = piVar9;
        if (piVar1 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 10) {
            iVar12 = *piVar6;
        } else {
            iVar12 = 0;
        }
        uVar10 = 2;
        iVar11 = 0x10;
        iVar13 = 3;
    }
    piVar9 = (int64_t *)((int64_t)piVar9 + iVar11);
    piVar6 = piVar9;
    if (piVar1 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        iVar11 = 0;
    } else {
        if (piVar1 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = func_0x0001800a8360(arg1);
            if (iVar4 == 0) goto code_r0x000180092957;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + iVar11);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar11 = *piVar9 + 0x18;
        if (iVar11 == 0) {
code_r0x000180092957:
            func_0x000180088470(arg1, uVar10, 6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + -0x10 + iVar13 * 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
        uVar5 = (uint32_t)(arg1 == iVar12);
    } else {
        uVar5 = func_0x000180088860(arg1, iVar13);
    }
    if (-1 < (int32_t)uVar5) {
        var_3b0h = (int64_t)&var_198h;
        var_3a0h = 0;
        var_3b8h = (int64_t)&var_398h;
        var_3a8h = arg1;
        if (iVar11 != 0) {
            uVar7 = fcn.180498cd0(iVar11);
            piVar9 = &var_398h;
            if (0x200 < uVar7) {
                func_0x0001800890e0(&var_3b8h, uVar7 - 0x200, 0xffffffff);
                piVar9 = (int64_t *)var_3b8h;
            }
            fcn.180498030(piVar9, iVar11, uVar7);
            var_3b8h = var_3b8h + uVar7;
            if (var_3b0h == var_3b8h) {
                func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
            }
            *(undefined *)var_3b8h = 10;
            var_3b8h = var_3b8h + 1;
        }
        iVar4 = func_0x000180092a10(iVar12, uVar5, 0x18063da64, &var_198h);
        iVar11 = var_3a8h;
        iVar13 = var_3a0h;
        iVar3 = var_180h;
        while (var_3a8h = iVar11, var_3a0h = iVar13, iVar4 != 0) {
            var_180h = iVar3;
            if ((*(char *)var_190h != 'C') || (*(char *)(var_190h + 1) != '\0')) {
                if (var_188h != 0) {
                    uVar7 = fcn.180498cd0(iVar3);
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, (uVar7 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    fcn.180498030(var_3b8h, iVar3, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (0 < (int32_t)(uint32_t)var_174h) {
                    piVar9 = &var_38h;
                    uVar8 = (uint32_t)var_174h;
                    do {
                        piVar9 = (int64_t *)((int64_t)piVar9 + -1);
                        *(char *)piVar9 = (char)uVar8 + (char)((uint64_t)uVar8 / 10) * -10 + '0';
                        uVar8 = (uint32_t)((uint64_t)uVar8 / 10);
                    } while (uVar8 != 0);
                    if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_3b8h = 0x3a;
                    uVar7 = (int64_t)&var_38h - (int64_t)piVar9;
                    var_3b8h = var_3b8h + 1;
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, (uVar7 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    fcn.180498030(var_3b8h, piVar9, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (var_198h != 0) {
                    if ((uint64_t)(var_3b0h - var_3b8h) < 10) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 10, 0xffffffff);
                    }
                    iVar11 = var_198h;
                    *(undefined8 *)var_3b8h = 0x6f6974636e756620;
                    *(undefined2 *)(var_3b8h + 8) = 0x206e;
                    iVar13 = var_3b8h + 10;
                    var_3b8h = iVar13;
                    uVar7 = fcn.180498cd0(var_198h);
                    if ((uint64_t)(var_3b0h - iVar13) < uVar7) {
                        func_0x0001800890e0(&var_3b8h, uVar7 + (iVar13 - var_3b0h), 0xffffffff);
                        iVar13 = var_3b8h;
                    }
                    fcn.180498030(iVar13, iVar11, uVar7);
                    var_3b8h = var_3b8h + uVar7;
                }
                if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                    func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                }
                *(undefined *)var_3b8h = 10;
                var_3b8h = var_3b8h + 1;
            }
            uVar5 = uVar5 + 1;
            iVar4 = func_0x000180092a10(iVar12, uVar5, 0x18063da64, &var_198h);
            iVar11 = var_3a8h;
            iVar13 = var_3a0h;
            iVar3 = var_180h;
        }
        if (iVar13 == 0) {
            func_0x0001800867f0(iVar11, &var_398h, (var_3b8h - (int64_t)&var_3b8h) + -0x20);
        } else {
            if (*(uint64_t *)(*(int64_t *)(iVar11 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar11 + 0x20) + 0x30))
            {
                (**(code **)0x180782658)(iVar11, 1);
            }
            iVar12 = *(int64_t *)(iVar11 + 0x40);
            if (var_3b8h == var_3b0h) {
                uVar10 = func_0x00018009a7e0(iVar11, iVar13);
                *(undefined8 *)(iVar12 + -0x10) = uVar10;
                *(undefined4 *)(iVar12 + -4) = 6;
            } else {
                uVar10 = fcn.18009a8e0(iVar11, iVar13 + 0x18, (var_3b8h - iVar13) + -0x18);
                *(undefined8 *)(iVar12 + -0x10) = uVar10;
                *(undefined4 *)(iVar12 + -4) = 6;
            }
        }
        fcn.180459870(var_38h ^ (uint64_t)auStack_3d8);
        return;
    }
    func_0x000180088380(arg1, iVar13, 0x180622770);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180092970
// Address: 0x180092970
// Size: 33 bytes
// ============================================================
undefined8 fcn.180092970(undefined8 param_1)
{
    fcn.180088b20(param_1, 0x1806227a4, 0x180611ca0);
    return 1;
}

// ============================================================
// Function: FUN_180092a10
// Address: 0x180092a10
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180092a10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar6 = (uint32_t)arg2;
    if ((int32_t)uVar6 < 0) {
        if ((*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4 < (int64_t)(int32_t)-uVar6) ||
           (piVar8 = (int64_t *)((int64_t)(int32_t)uVar6 * 0x10 + *(int64_t *)(arg1 + 0x40)),
           *(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
            return false;
        }
        iVar10 = 0;
    } else {
        if ((uint32_t)((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333) <= uVar6) {
            iVar9 = 0;
            goto code_r0x000180092cea;
        }
        iVar10 = *(int64_t *)(arg1 + 0x18) + (int64_t)(int32_t)uVar6 * -0x28;
        piVar8 = *(int64_t **)(iVar10 + 8);
    }
    iVar9 = *piVar8;
    if ((iVar9 != 0) && (cVar1 = *(char *)arg3, cVar1 != '\0')) {
        iVar11 = 0;
        do {
    // switch table (21 cases) at 0x180092d04
            switch(cVar1) {
            case 'a':
                if (*(char *)(iVar9 + 3) == '\0') {
                    *(undefined *)(arg4 + 0x2a) = *(undefined *)(*(int64_t *)(iVar9 + 0x20) + 4);
                    *(undefined *)(arg4 + 0x29) = *(undefined *)(*(int64_t *)(iVar9 + 0x20) + 5);
                } else {
                    *(undefined *)(arg4 + 0x2a) = 1;
                    *(undefined *)(arg4 + 0x29) = 0;
                }
                break;
            case 'f':
                iVar11 = iVar9;
                break;
            case 'l':
                if (iVar10 == 0) {
                    if (*(char *)(iVar9 + 3) != '\0') goto code_r0x000180092baf;
                    *(undefined4 *)(arg4 + 0x24) = *(undefined4 *)(*(int64_t *)(iVar9 + 0x20) + 0x8c);
                } else if ((*(int32_t *)((int64_t)*(int64_t **)(iVar10 + 8) + 0xc) == 8) &&
                          (*(char *)(**(int64_t **)(iVar10 + 8) + 3) == '\0')) {
                    uVar3 = func_0x0001800929a0((uint64_t)*(uint32_t *)((int64_t)(cVar1 + -0x61) * 4 + 0x180092d04) +
                                                0x180000000, iVar10);
                    *(undefined4 *)(arg4 + 0x24) = uVar3;
                } else {
code_r0x000180092baf:
                    *(undefined4 *)(arg4 + 0x24) = 0xffffffff;
                }
                break;
            case 'n':
                if (iVar10 == 0) {
                    if (*(char *)(iVar9 + 3) == '\0') {
                        iVar7 = *(int64_t *)(iVar9 + 0x20);
                        goto code_r0x000180092c4f;
                    }
                    iVar7 = (iVar9 - *(int64_t *)(iVar9 + 0x30)) + 0x30;
                    if (iVar7 == 0) goto code_r0x000180092c26;
                    *(int64_t *)arg4 = iVar7;
                } else {
                    iVar7 = **(int64_t **)(iVar10 + 8);
                    if (*(char *)(iVar7 + 3) == '\0') {
                        iVar7 = *(int64_t *)(iVar7 + 0x20);
code_r0x000180092c4f:
                        iVar7 = iVar7 - *(int64_t *)(iVar7 + 0x20);
                        if (iVar7 == -0x20) goto code_r0x000180092c26;
                        *(int64_t *)arg4 = iVar7 + 0x38;
                    } else {
                        iVar7 = (iVar7 - *(int64_t *)(iVar7 + 0x30)) + 0x30;
                        if (iVar7 == 0) {
code_r0x000180092c26:
                            iVar7 = 0;
                        }
                        *(int64_t *)arg4 = iVar7;
                    }
                }
                break;
            case 's':
                if (*(char *)(iVar9 + 3) == '\0') {
                    piVar8 = (int64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x10);
                    iVar7 = *piVar8 - (int64_t)piVar8;
                    *(undefined8 *)(arg4 + 8) = 0x18063de74;
                    *(int64_t *)(arg4 + 0x10) = iVar7 + 0x18;
                    *(undefined4 *)(arg4 + 0x20) = *(undefined4 *)(*(int64_t *)(iVar9 + 0x20) + 0x8c);
                    uVar4 = func_0x000180099480(arg4 + 0x38, iVar7, iVar7 + 0x18, *(undefined4 *)(iVar7 + 0x14));
                    *(undefined8 *)(arg4 + 0x18) = uVar4;
                } else {
                    *(undefined8 *)(arg4 + 0x10) = 0x18063de7c;
                    *(undefined8 *)(arg4 + 8) = 0x180622794;
                    *(undefined4 *)(arg4 + 0x20) = 0xffffffff;
                    *(undefined8 *)(arg4 + 0x18) = 0x18063de78;
                }
                break;
            case 'u':
                *(undefined *)(arg4 + 0x28) = *(undefined *)(iVar9 + 4);
            }
            cVar1 = *(char *)(arg3 + 1);
            arg3 = arg3 + 1;
        } while (cVar1 != '\0');
        if (iVar11 != 0) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            piVar8 = *(int64_t **)(arg1 + 0x40);
            *piVar8 = iVar11;
            *(undefined4 *)((int64_t)piVar8 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar5 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                iVar2 = iVar5 * 2;
                if (iVar5 < 1) {
                    iVar2 = iVar5 + 1;
                }
                func_0x000180093240(arg1, iVar2, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        }
    }
code_r0x000180092cea:
    return iVar9 != 0;
}

// ============================================================
// Function: FUN_180092ac2
// Address: 0x180092ac2
// Size: 454 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180092a10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar6 = (uint32_t)arg2;
    if ((int32_t)uVar6 < 0) {
        if ((*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4 < (int64_t)(int32_t)-uVar6) ||
           (piVar8 = (int64_t *)((int64_t)(int32_t)uVar6 * 0x10 + *(int64_t *)(arg1 + 0x40)),
           *(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
            return false;
        }
        iVar10 = 0;
    } else {
        if ((uint32_t)((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333) <= uVar6) {
            iVar9 = 0;
            goto code_r0x000180092cea;
        }
        iVar10 = *(int64_t *)(arg1 + 0x18) + (int64_t)(int32_t)uVar6 * -0x28;
        piVar8 = *(int64_t **)(iVar10 + 8);
    }
    iVar9 = *piVar8;
    if ((iVar9 != 0) && (cVar1 = *(char *)arg3, cVar1 != '\0')) {
        iVar11 = 0;
        do {
    // switch table (21 cases) at 0x180092d04
            switch(cVar1) {
            case 'a':
                if (*(char *)(iVar9 + 3) == '\0') {
                    *(undefined *)(arg4 + 0x2a) = *(undefined *)(*(int64_t *)(iVar9 + 0x20) + 4);
                    *(undefined *)(arg4 + 0x29) = *(undefined *)(*(int64_t *)(iVar9 + 0x20) + 5);
                } else {
                    *(undefined *)(arg4 + 0x2a) = 1;
                    *(undefined *)(arg4 + 0x29) = 0;
                }
                break;
            case 'f':
                iVar11 = iVar9;
                break;
            case 'l':
                if (iVar10 == 0) {
                    if (*(char *)(iVar9 + 3) != '\0') goto code_r0x000180092baf;
                    *(undefined4 *)(arg4 + 0x24) = *(undefined4 *)(*(int64_t *)(iVar9 + 0x20) + 0x8c);
                } else if ((*(int32_t *)((int64_t)*(int64_t **)(iVar10 + 8) + 0xc) == 8) &&
                          (*(char *)(**(int64_t **)(iVar10 + 8) + 3) == '\0')) {
                    uVar3 = func_0x0001800929a0((uint64_t)*(uint32_t *)((int64_t)(cVar1 + -0x61) * 4 + 0x180092d04) +
                                                0x180000000, iVar10);
                    *(undefined4 *)(arg4 + 0x24) = uVar3;
                } else {
code_r0x000180092baf:
                    *(undefined4 *)(arg4 + 0x24) = 0xffffffff;
                }
                break;
            case 'n':
                if (iVar10 == 0) {
                    if (*(char *)(iVar9 + 3) == '\0') {
                        iVar7 = *(int64_t *)(iVar9 + 0x20);
                        goto code_r0x000180092c4f;
                    }
                    iVar7 = (iVar9 - *(int64_t *)(iVar9 + 0x30)) + 0x30;
                    if (iVar7 == 0) goto code_r0x000180092c26;
                    *(int64_t *)arg4 = iVar7;
                } else {
                    iVar7 = **(int64_t **)(iVar10 + 8);
                    if (*(char *)(iVar7 + 3) == '\0') {
                        iVar7 = *(int64_t *)(iVar7 + 0x20);
code_r0x000180092c4f:
                        iVar7 = iVar7 - *(int64_t *)(iVar7 + 0x20);
                        if (iVar7 == -0x20) goto code_r0x000180092c26;
                        *(int64_t *)arg4 = iVar7 + 0x38;
                    } else {
                        iVar7 = (iVar7 - *(int64_t *)(iVar7 + 0x30)) + 0x30;
                        if (iVar7 == 0) {
code_r0x000180092c26:
                            iVar7 = 0;
                        }
                        *(int64_t *)arg4 = iVar7;
                    }
                }
                break;
            case 's':
                if (*(char *)(iVar9 + 3) == '\0') {
                    piVar8 = (int64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x10);
                    iVar7 = *piVar8 - (int64_t)piVar8;
                    *(undefined8 *)(arg4 + 8) = 0x18063de74;
                    *(int64_t *)(arg4 + 0x10) = iVar7 + 0x18;
                    *(undefined4 *)(arg4 + 0x20) = *(undefined4 *)(*(int64_t *)(iVar9 + 0x20) + 0x8c);
                    uVar4 = func_0x000180099480(arg4 + 0x38, iVar7, iVar7 + 0x18, *(undefined4 *)(iVar7 + 0x14));
                    *(undefined8 *)(arg4 + 0x18) = uVar4;
                } else {
                    *(undefined8 *)(arg4 + 0x10) = 0x18063de7c;
                    *(undefined8 *)(arg4 + 8) = 0x180622794;
                    *(undefined4 *)(arg4 + 0x20) = 0xffffffff;
                    *(undefined8 *)(arg4 + 0x18) = 0x18063de78;
                }
                break;
            case 'u':
                *(undefined *)(arg4 + 0x28) = *(undefined *)(iVar9 + 4);
            }
            cVar1 = *(char *)(arg3 + 1);
            arg3 = arg3 + 1;
        } while (cVar1 != '\0');
        if (iVar11 != 0) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            piVar8 = *(int64_t **)(arg1 + 0x40);
            *piVar8 = iVar11;
            *(undefined4 *)((int64_t)piVar8 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar5 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                iVar2 = iVar5 * 2;
                if (iVar5 < 1) {
                    iVar2 = iVar5 + 1;
                }
                func_0x000180093240(arg1, iVar2, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        }
    }
code_r0x000180092cea:
    return iVar9 != 0;
}

// ============================================================
// Function: FUN_180092c88
// Address: 0x180092c88
// Size: 208 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180092a10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar6 = (uint32_t)arg2;
    if ((int32_t)uVar6 < 0) {
        if ((*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4 < (int64_t)(int32_t)-uVar6) ||
           (piVar8 = (int64_t *)((int64_t)(int32_t)uVar6 * 0x10 + *(int64_t *)(arg1 + 0x40)),
           *(int32_t *)((int64_t)piVar8 + 0xc) != 8)) {
            return false;
        }
        iVar10 = 0;
    } else {
        if ((uint32_t)((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333) <= uVar6) {
            iVar9 = 0;
            goto code_r0x000180092cea;
        }
        iVar10 = *(int64_t *)(arg1 + 0x18) + (int64_t)(int32_t)uVar6 * -0x28;
        piVar8 = *(int64_t **)(iVar10 + 8);
    }
    iVar9 = *piVar8;
    if ((iVar9 != 0) && (cVar1 = *(char *)arg3, cVar1 != '\0')) {
        iVar11 = 0;
        do {
    // switch table (21 cases) at 0x180092d04
            switch(cVar1) {
            case 'a':
                if (*(char *)(iVar9 + 3) == '\0') {
                    *(undefined *)(arg4 + 0x2a) = *(undefined *)(*(int64_t *)(iVar9 + 0x20) + 4);
                    *(undefined *)(arg4 + 0x29) = *(undefined *)(*(int64_t *)(iVar9 + 0x20) + 5);
                } else {
                    *(undefined *)(arg4 + 0x2a) = 1;
                    *(undefined *)(arg4 + 0x29) = 0;
                }
                break;
            case 'f':
                iVar11 = iVar9;
                break;
            case 'l':
                if (iVar10 == 0) {
                    if (*(char *)(iVar9 + 3) != '\0') goto code_r0x000180092baf;
                    *(undefined4 *)(arg4 + 0x24) = *(undefined4 *)(*(int64_t *)(iVar9 + 0x20) + 0x8c);
                } else if ((*(int32_t *)((int64_t)*(int64_t **)(iVar10 + 8) + 0xc) == 8) &&
                          (*(char *)(**(int64_t **)(iVar10 + 8) + 3) == '\0')) {
                    uVar3 = func_0x0001800929a0((uint64_t)*(uint32_t *)((int64_t)(cVar1 + -0x61) * 4 + 0x180092d04) +
                                                0x180000000, iVar10);
                    *(undefined4 *)(arg4 + 0x24) = uVar3;
                } else {
code_r0x000180092baf:
                    *(undefined4 *)(arg4 + 0x24) = 0xffffffff;
                }
                break;
            case 'n':
                if (iVar10 == 0) {
                    if (*(char *)(iVar9 + 3) == '\0') {
                        iVar7 = *(int64_t *)(iVar9 + 0x20);
                        goto code_r0x000180092c4f;
                    }
                    iVar7 = (iVar9 - *(int64_t *)(iVar9 + 0x30)) + 0x30;
                    if (iVar7 == 0) goto code_r0x000180092c26;
                    *(int64_t *)arg4 = iVar7;
                } else {
                    iVar7 = **(int64_t **)(iVar10 + 8);
                    if (*(char *)(iVar7 + 3) == '\0') {
                        iVar7 = *(int64_t *)(iVar7 + 0x20);
code_r0x000180092c4f:
                        iVar7 = iVar7 - *(int64_t *)(iVar7 + 0x20);
                        if (iVar7 == -0x20) goto code_r0x000180092c26;
                        *(int64_t *)arg4 = iVar7 + 0x38;
                    } else {
                        iVar7 = (iVar7 - *(int64_t *)(iVar7 + 0x30)) + 0x30;
                        if (iVar7 == 0) {
code_r0x000180092c26:
                            iVar7 = 0;
                        }
                        *(int64_t *)arg4 = iVar7;
                    }
                }
                break;
            case 's':
                if (*(char *)(iVar9 + 3) == '\0') {
                    piVar8 = (int64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x10);
                    iVar7 = *piVar8 - (int64_t)piVar8;
                    *(undefined8 *)(arg4 + 8) = 0x18063de74;
                    *(int64_t *)(arg4 + 0x10) = iVar7 + 0x18;
                    *(undefined4 *)(arg4 + 0x20) = *(undefined4 *)(*(int64_t *)(iVar9 + 0x20) + 0x8c);
                    uVar4 = func_0x000180099480(arg4 + 0x38, iVar7, iVar7 + 0x18, *(undefined4 *)(iVar7 + 0x14));
                    *(undefined8 *)(arg4 + 0x18) = uVar4;
                } else {
                    *(undefined8 *)(arg4 + 0x10) = 0x18063de7c;
                    *(undefined8 *)(arg4 + 8) = 0x180622794;
                    *(undefined4 *)(arg4 + 0x20) = 0xffffffff;
                    *(undefined8 *)(arg4 + 0x18) = 0x18063de78;
                }
                break;
            case 'u':
                *(undefined *)(arg4 + 0x28) = *(undefined *)(iVar9 + 4);
            }
            cVar1 = *(char *)(arg3 + 1);
            arg3 = arg3 + 1;
        } while (cVar1 != '\0');
        if (iVar11 != 0) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            piVar8 = *(int64_t **)(arg1 + 0x40);
            *piVar8 = iVar11;
            *(undefined4 *)((int64_t)piVar8 + 0xc) = 8;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar5 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
                iVar2 = iVar5 * 2;
                if (iVar5 < 1) {
                    iVar2 = iVar5 + 1;
                }
                func_0x000180093240(arg1, iVar2, 0);
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        }
    }
code_r0x000180092cea:
    return iVar9 != 0;
}

// ============================================================
// Function: FUN_180092d60
// Address: 0x180092d60
// Size: 40 bytes
// ============================================================
void fcn.180092d60(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    
    uVar2 = fcn.1800a3c60();
    fcn.180093000(arg1, 0x18063de58, 0x18063eff0, uVar2);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180092d90
// Address: 0x180092d90
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180092d90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar2 = fcn.1800a3c60(arg1, arg3);
    uVar3 = fcn.1800a3c60(arg1, arg2);
    fcn.180093000(arg1, 0x18063de88, uVar3, uVar2);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180092de0
// Address: 0x180092de0
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180092de0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = fcn.1800a3c60(arg1, arg3);
    uVar3 = fcn.1800a3c60(arg1, arg2);
    fcn.180093000(arg1, 0x18063deb0, uVar3, 0x18063ded4, uVar2);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180092e30
// Address: 0x180092e30
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180092e30(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = fcn.1800a3b90();
    iVar3 = fcn.1800a3b90(arg1, arg3);
    if (((*(int32_t *)(arg3 + 0xc) == 6) && (arg3 = *(int64_t *)arg3, arg3 != 0)) && (*(uint32_t *)(arg3 + 0x14) < 0x41)
       ) {
        fcn.180093000(arg1, 0x18063df40, iVar2 + 0x18, arg3 + 0x18);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    fcn.180093000(arg1, 0x18063df20, iVar2 + 0x18, iVar3 + 0x18);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180092ea0
// Address: 0x180092ea0
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180092ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int32_t *)(arg3 + 0xc) != 6) {
        uVar2 = fcn.1800a3c60(arg1, arg3);
        uVar3 = fcn.1800a3c60(arg1, arg2);
        fcn.180093000(arg1, 0x18063df00, uVar3, uVar2);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    arg3 = *(int64_t *)arg3;
    uVar2 = fcn.1800a3c60();
    fcn.180093000(arg1, 0x18063ded8, uVar2, arg3 + 0x18);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180092f10
// Address: 0x180092f10
// Size: 17 bytes
// ============================================================
void fcn.180092f10(undefined8 param_1)
{
    code *pcVar1;
    
    fcn.180093000(param_1, 0x18063df70);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180092f30
// Address: 0x180092f30
// Size: 207 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180092f30(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_148 [32];
    int64_t var_128h;
    int64_t var_118h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_148;
    piVar2 = *(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
    if ((*(int32_t *)((int64_t)piVar2 + 0xc) == 8) && (iVar4 = *piVar2, *(char *)(iVar4 + 3) == '\0')) {
        piVar2 = (int64_t *)(*(int64_t *)(iVar4 + 0x20) + 0x10);
        iVar4 = *piVar2 - (int64_t)piVar2;
        uVar3 = func_0x000180099480(&var_118h, arg2, iVar4 + 0x18, *(undefined4 *)(iVar4 + 0x14));
        uVar1 = func_0x0001800929a0();
        var_128h = arg2;
        fcn.180099450(arg1, 0x18063df60, uVar3, uVar1);
    } else if (arg2 == 0) {
        fcn.180086510();
    } else {
        uVar3 = fcn.180498cd0(arg2);
        func_0x0001800867f0(arg1, arg2, uVar3);
    }
    fcn.180459870(uStack_18 ^ (uint64_t)auStack_148);
    return;
}

// ============================================================
// Function: FUN_180093000
// Address: 0x180093000
// Size: 88 bytes
// ============================================================
void fcn.180093000(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    int64_t iStackX_18;
    int64_t iStackX_20;
    int64_t var_208h;
    
    iStackX_18 = arg3;
    iStackX_20 = arg4;
    fcn.180065f10(&var_208h, 0x200, arg2, &iStackX_18);
    fcn.180085610(arg1, 1);
    fcn.180092f30(arg1, (int64_t)&var_208h);
    fcn.1800931b0(arg1, 2);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180093080
// Address: 0x180093080
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180093080(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int32_t *)(arg1 + 0x20) == 2) {
        iVar3 = *(int64_t *)(arg1 + 0x18);
        iVar1 = *(int64_t *)(iVar3 + 0x40);
        if (*(int32_t *)(iVar1 + -4) != 6) {
            if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
                *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
            }
            iVar2 = func_0x0001800a8360(iVar3);
            if (iVar2 == 0) goto code_r0x0001800930fd;
            if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(iVar3, 1);
            }
            iVar1 = *(int64_t *)(iVar3 + 0x40);
        }
        iVar3 = *(int64_t *)(iVar1 + -0x10) + 0x18;
        if (iVar3 != 0) {
            return iVar3;
        }
    }
code_r0x0001800930fd:
    iVar2 = *(int32_t *)(arg1 + 0x20);
    if (iVar2 == 2) {
        return 0x18063df98;
    }
    if (iVar2 == 3) {
        return 0x18063e050;
    }
    if (iVar2 == 4) {
        return 0x18063e028;
    }
    if (iVar2 == 5) {
        return 0x18063e000;
    }
    return 0x18063dfd0;
}

// ============================================================
// Function: FUN_180093190
// Address: 0x180093190
// Size: 31 bytes
// ============================================================
undefined8 fcn.180093190(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    
    (*(code *)arg2)(arg1, arg3);
    return 0;
}

// ============================================================
// Function: FUN_1800931b0
// Address: 0x1800931b0
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800931b0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t var_38h;
    
    fcn.180093060(&var_38h, arg1, arg2 & 0xffffffff);
    fcn.18045bae0(var_38h);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800931e0
// Address: 0x1800931e0
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800931e0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x18063e140;
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    *(undefined4 *)(arg1 + 0x20) = *(undefined4 *)(arg2 + 0x20);
    return arg1;
}

// ============================================================
// Function: FUN_180093240
// Address: 0x180093240
// Size: 21 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800933af)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800934a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
    iVar6 = iVar9;
    if (iVar9 < (int32_t)arg2) {
        iVar6 = (int32_t)arg2;
    }
    iVar6 = iVar6 + iVar9;
    if (0x4000000 < iVar6) {
        fcn.1800931b0(arg1, 4);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar1 = (int64_t)iVar6 + 5;
    if (0xfffffffffffffff < uVar1) {
        fcn.180098420();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    iVar3 = *(int64_t *)(arg1 + 0x38);
    piVar2 = (int32_t *)(arg1 + 0x60);
    iVar10 = (int32_t)piVar2;
    iVar7 = func_0x0001800988a0(arg1, iVar3, (int64_t)(*(int32_t *)(arg1 + 0x60) - iVar10) << 4, uVar1 * 0x10, 
                                *(undefined *)arg1);
    *(int64_t *)(arg1 + 0x38) = iVar7;
    for (iVar9 = *piVar2 - iVar10; iVar9 < iVar6 + 5; iVar9 = iVar9 + 1) {
        *(undefined4 *)(iVar7 + 0xc + (int64_t)iVar9 * 0x10) = 0;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    *piVar2 = iVar10 + iVar6 + 5;
    *(int64_t *)(arg1 + 0x30) = (int64_t)iVar6 * 0x10 + iVar7;
    *(uint64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x40) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    for (; iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 0x20)) {
        *(uint64_t *)(iVar4 + 8) = (*(int64_t *)(iVar4 + 8) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    }
    piVar8 = *(int64_t **)(arg1 + 0x78);
    if (piVar8 <= *(int64_t **)(arg1 + 0x18)) {
        do {
            *piVar8 = (*piVar8 - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[2] = (piVar8[2] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[1] = (piVar8[1] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8 = piVar8 + 5;
        } while (piVar8 <= *(int64_t **)(arg1 + 0x18));
    }
    *(uint64_t *)(arg1 + 0x28) = (*(int64_t *)(arg1 + 0x28) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    return;
}

// ============================================================
// Function: FUN_180093255
// Address: 0x180093255
// Size: 34 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800933af)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800934a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
    iVar6 = iVar9;
    if (iVar9 < (int32_t)arg2) {
        iVar6 = (int32_t)arg2;
    }
    iVar6 = iVar6 + iVar9;
    if (0x4000000 < iVar6) {
        fcn.1800931b0(arg1, 4);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar1 = (int64_t)iVar6 + 5;
    if (0xfffffffffffffff < uVar1) {
        fcn.180098420();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    iVar3 = *(int64_t *)(arg1 + 0x38);
    piVar2 = (int32_t *)(arg1 + 0x60);
    iVar10 = (int32_t)piVar2;
    iVar7 = func_0x0001800988a0(arg1, iVar3, (int64_t)(*(int32_t *)(arg1 + 0x60) - iVar10) << 4, uVar1 * 0x10, 
                                *(undefined *)arg1);
    *(int64_t *)(arg1 + 0x38) = iVar7;
    for (iVar9 = *piVar2 - iVar10; iVar9 < iVar6 + 5; iVar9 = iVar9 + 1) {
        *(undefined4 *)(iVar7 + 0xc + (int64_t)iVar9 * 0x10) = 0;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    *piVar2 = iVar10 + iVar6 + 5;
    *(int64_t *)(arg1 + 0x30) = (int64_t)iVar6 * 0x10 + iVar7;
    *(uint64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x40) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    for (; iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 0x20)) {
        *(uint64_t *)(iVar4 + 8) = (*(int64_t *)(iVar4 + 8) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    }
    piVar8 = *(int64_t **)(arg1 + 0x78);
    if (piVar8 <= *(int64_t **)(arg1 + 0x18)) {
        do {
            *piVar8 = (*piVar8 - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[2] = (piVar8[2] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[1] = (piVar8[1] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8 = piVar8 + 5;
        } while (piVar8 <= *(int64_t **)(arg1 + 0x18));
    }
    *(uint64_t *)(arg1 + 0x28) = (*(int64_t *)(arg1 + 0x28) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    return;
}

// ============================================================
// Function: FUN_180093277
// Address: 0x180093277
// Size: 153 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800933af)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800934a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
    iVar6 = iVar9;
    if (iVar9 < (int32_t)arg2) {
        iVar6 = (int32_t)arg2;
    }
    iVar6 = iVar6 + iVar9;
    if (0x4000000 < iVar6) {
        fcn.1800931b0(arg1, 4);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar1 = (int64_t)iVar6 + 5;
    if (0xfffffffffffffff < uVar1) {
        fcn.180098420();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    iVar3 = *(int64_t *)(arg1 + 0x38);
    piVar2 = (int32_t *)(arg1 + 0x60);
    iVar10 = (int32_t)piVar2;
    iVar7 = func_0x0001800988a0(arg1, iVar3, (int64_t)(*(int32_t *)(arg1 + 0x60) - iVar10) << 4, uVar1 * 0x10, 
                                *(undefined *)arg1);
    *(int64_t *)(arg1 + 0x38) = iVar7;
    for (iVar9 = *piVar2 - iVar10; iVar9 < iVar6 + 5; iVar9 = iVar9 + 1) {
        *(undefined4 *)(iVar7 + 0xc + (int64_t)iVar9 * 0x10) = 0;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    *piVar2 = iVar10 + iVar6 + 5;
    *(int64_t *)(arg1 + 0x30) = (int64_t)iVar6 * 0x10 + iVar7;
    *(uint64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x40) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    for (; iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 0x20)) {
        *(uint64_t *)(iVar4 + 8) = (*(int64_t *)(iVar4 + 8) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    }
    piVar8 = *(int64_t **)(arg1 + 0x78);
    if (piVar8 <= *(int64_t **)(arg1 + 0x18)) {
        do {
            *piVar8 = (*piVar8 - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[2] = (piVar8[2] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[1] = (piVar8[1] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8 = piVar8 + 5;
        } while (piVar8 <= *(int64_t **)(arg1 + 0x18));
    }
    *(uint64_t *)(arg1 + 0x28) = (*(int64_t *)(arg1 + 0x28) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    return;
}

// ============================================================
// Function: FUN_180093310
// Address: 0x180093310
// Size: 148 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800933af)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800934a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
    iVar6 = iVar9;
    if (iVar9 < (int32_t)arg2) {
        iVar6 = (int32_t)arg2;
    }
    iVar6 = iVar6 + iVar9;
    if (0x4000000 < iVar6) {
        fcn.1800931b0(arg1, 4);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar1 = (int64_t)iVar6 + 5;
    if (0xfffffffffffffff < uVar1) {
        fcn.180098420();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    iVar3 = *(int64_t *)(arg1 + 0x38);
    piVar2 = (int32_t *)(arg1 + 0x60);
    iVar10 = (int32_t)piVar2;
    iVar7 = func_0x0001800988a0(arg1, iVar3, (int64_t)(*(int32_t *)(arg1 + 0x60) - iVar10) << 4, uVar1 * 0x10, 
                                *(undefined *)arg1);
    *(int64_t *)(arg1 + 0x38) = iVar7;
    for (iVar9 = *piVar2 - iVar10; iVar9 < iVar6 + 5; iVar9 = iVar9 + 1) {
        *(undefined4 *)(iVar7 + 0xc + (int64_t)iVar9 * 0x10) = 0;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    *piVar2 = iVar10 + iVar6 + 5;
    *(int64_t *)(arg1 + 0x30) = (int64_t)iVar6 * 0x10 + iVar7;
    *(uint64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x40) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    for (; iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 0x20)) {
        *(uint64_t *)(iVar4 + 8) = (*(int64_t *)(iVar4 + 8) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    }
    piVar8 = *(int64_t **)(arg1 + 0x78);
    if (piVar8 <= *(int64_t **)(arg1 + 0x18)) {
        do {
            *piVar8 = (*piVar8 - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[2] = (piVar8[2] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[1] = (piVar8[1] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8 = piVar8 + 5;
        } while (piVar8 <= *(int64_t **)(arg1 + 0x18));
    }
    *(uint64_t *)(arg1 + 0x28) = (*(int64_t *)(arg1 + 0x28) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    return;
}

// ============================================================
// Function: FUN_1800933a4
// Address: 0x1800933a4
// Size: 6 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800933af)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800934a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
    iVar6 = iVar9;
    if (iVar9 < (int32_t)arg2) {
        iVar6 = (int32_t)arg2;
    }
    iVar6 = iVar6 + iVar9;
    if (0x4000000 < iVar6) {
        fcn.1800931b0(arg1, 4);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar1 = (int64_t)iVar6 + 5;
    if (0xfffffffffffffff < uVar1) {
        fcn.180098420();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    iVar3 = *(int64_t *)(arg1 + 0x38);
    piVar2 = (int32_t *)(arg1 + 0x60);
    iVar10 = (int32_t)piVar2;
    iVar7 = func_0x0001800988a0(arg1, iVar3, (int64_t)(*(int32_t *)(arg1 + 0x60) - iVar10) << 4, uVar1 * 0x10, 
                                *(undefined *)arg1);
    *(int64_t *)(arg1 + 0x38) = iVar7;
    for (iVar9 = *piVar2 - iVar10; iVar9 < iVar6 + 5; iVar9 = iVar9 + 1) {
        *(undefined4 *)(iVar7 + 0xc + (int64_t)iVar9 * 0x10) = 0;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    *piVar2 = iVar10 + iVar6 + 5;
    *(int64_t *)(arg1 + 0x30) = (int64_t)iVar6 * 0x10 + iVar7;
    *(uint64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x40) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    for (; iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 0x20)) {
        *(uint64_t *)(iVar4 + 8) = (*(int64_t *)(iVar4 + 8) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    }
    piVar8 = *(int64_t **)(arg1 + 0x78);
    if (piVar8 <= *(int64_t **)(arg1 + 0x18)) {
        do {
            *piVar8 = (*piVar8 - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[2] = (piVar8[2] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[1] = (piVar8[1] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8 = piVar8 + 5;
        } while (piVar8 <= *(int64_t **)(arg1 + 0x18));
    }
    *(uint64_t *)(arg1 + 0x28) = (*(int64_t *)(arg1 + 0x28) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    return;
}

// ============================================================
// Function: FUN_1800933aa
// Address: 0x1800933aa
// Size: 43 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800933af)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800934a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
    iVar6 = iVar9;
    if (iVar9 < (int32_t)arg2) {
        iVar6 = (int32_t)arg2;
    }
    iVar6 = iVar6 + iVar9;
    if (0x4000000 < iVar6) {
        fcn.1800931b0(arg1, 4);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar1 = (int64_t)iVar6 + 5;
    if (0xfffffffffffffff < uVar1) {
        fcn.180098420();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    iVar3 = *(int64_t *)(arg1 + 0x38);
    piVar2 = (int32_t *)(arg1 + 0x60);
    iVar10 = (int32_t)piVar2;
    iVar7 = func_0x0001800988a0(arg1, iVar3, (int64_t)(*(int32_t *)(arg1 + 0x60) - iVar10) << 4, uVar1 * 0x10, 
                                *(undefined *)arg1);
    *(int64_t *)(arg1 + 0x38) = iVar7;
    for (iVar9 = *piVar2 - iVar10; iVar9 < iVar6 + 5; iVar9 = iVar9 + 1) {
        *(undefined4 *)(iVar7 + 0xc + (int64_t)iVar9 * 0x10) = 0;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    *piVar2 = iVar10 + iVar6 + 5;
    *(int64_t *)(arg1 + 0x30) = (int64_t)iVar6 * 0x10 + iVar7;
    *(uint64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x40) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    for (; iVar4 != 0; iVar4 = *(int64_t *)(iVar4 + 0x20)) {
        *(uint64_t *)(iVar4 + 8) = (*(int64_t *)(iVar4 + 8) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    }
    piVar8 = *(int64_t **)(arg1 + 0x78);
    if (piVar8 <= *(int64_t **)(arg1 + 0x18)) {
        do {
            *piVar8 = (*piVar8 - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[2] = (piVar8[2] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8[1] = (piVar8[1] - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
            piVar8 = piVar8 + 5;
        } while (piVar8 <= *(int64_t **)(arg1 + 0x18));
    }
    *(uint64_t *)(arg1 + 0x28) = (*(int64_t *)(arg1 + 0x28) - iVar3 & 0xfffffffffffffff0U) + *(int64_t *)(arg1 + 0x38);
    return;
}

// ============================================================
// Function: FUN_1800933e0
// Address: 0x1800933e0
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800933e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    unkbyte7 in_stack_ffffffffffffffe9;
    
    iVar4 = (int32_t)arg2;
    if ((uint64_t)(int64_t)iVar4 < 0x666666666666667) {
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar3 = fcn.1800988a0(CONCAT71(in_stack_ffffffffffffffe9, *(undefined *)arg1));
        *(int64_t *)(arg1 + 0x78) = iVar3;
        *(int32_t *)(arg1 + 100) = iVar4;
        *(int64_t *)(arg1 + 0x70) = iVar3 + (int64_t)iVar4 * 0x28 + -0x28;
        *(int64_t *)(arg1 + 0x18) = iVar3 + (*(int64_t *)(arg1 + 0x18) - iVar1 >> 3) * 8;
        return;
    }
    fcn.180098420(arg1);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180093406
// Address: 0x180093406
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800933e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    unkbyte7 in_stack_ffffffffffffffe9;
    
    iVar4 = (int32_t)arg2;
    if ((uint64_t)(int64_t)iVar4 < 0x666666666666667) {
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar3 = fcn.1800988a0(CONCAT71(in_stack_ffffffffffffffe9, *(undefined *)arg1));
        *(int64_t *)(arg1 + 0x78) = iVar3;
        *(int32_t *)(arg1 + 100) = iVar4;
        *(int64_t *)(arg1 + 0x70) = iVar3 + (int64_t)iVar4 * 0x28 + -0x28;
        *(int64_t *)(arg1 + 0x18) = iVar3 + (*(int64_t *)(arg1 + 0x18) - iVar1 >> 3) * 8;
        return;
    }
    fcn.180098420(arg1);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180093491
// Address: 0x180093491
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800933e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    unkbyte7 in_stack_ffffffffffffffe9;
    
    iVar4 = (int32_t)arg2;
    if ((uint64_t)(int64_t)iVar4 < 0x666666666666667) {
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar3 = fcn.1800988a0(CONCAT71(in_stack_ffffffffffffffe9, *(undefined *)arg1));
        *(int64_t *)(arg1 + 0x78) = iVar3;
        *(int32_t *)(arg1 + 100) = iVar4;
        *(int64_t *)(arg1 + 0x70) = iVar3 + (int64_t)iVar4 * 0x28 + -0x28;
        *(int64_t *)(arg1 + 0x18) = iVar3 + (*(int64_t *)(arg1 + 0x18) - iVar1 >> 3) * 8;
        return;
    }
    fcn.180098420(arg1);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800934d0
// Address: 0x1800934d0
// Size: 96 bytes
// ============================================================
undefined8 fcn.1800934d0(int64_t arg1)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t arg2;
    int64_t in_R8;
    int64_t in_R9;
    
    iVar1 = *(int32_t *)(arg1 + 100);
    arg2 = 0x57e4;
    if (0x57e3 < iVar1) {
        fcn.1800931b0(arg1, 5);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    if (iVar1 < 20000) {
        arg2 = 20000;
        if (iVar1 * 2 < 20000) {
            arg2 = (uint64_t)(uint32_t)(iVar1 * 2);
        }
    }
    fcn.1800933e0(arg1, arg2);
    if (*(int32_t *)(arg1 + 100) < 0x4e21) {
        *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + 0x28;
        return *(undefined8 *)(arg1 + 0x18);
    }
    fcn.180093000(arg1, 0x18063d8d0, in_R8, in_R9);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180093530
// Address: 0x180093530
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180093530(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int32_t iVar3;
    char in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = func_0x0001800a5fa0();
    if (iVar3 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (in_R9B == '\0') {
            (**(code **)0x1807825a0)(arg1);
        } else {
            *(undefined *)(arg1 + 3) = 0x7f;
        }
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18009354e
// Address: 0x18009354e
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180093530(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int32_t iVar3;
    char in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = func_0x0001800a5fa0();
    if (iVar3 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (in_R9B == '\0') {
            (**(code **)0x1807825a0)(arg1);
        } else {
            *(undefined *)(arg1 + 3) = 0x7f;
        }
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18009359a
// Address: 0x18009359a
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180093530(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int32_t iVar3;
    char in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = func_0x0001800a5fa0();
    if (iVar3 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (in_R9B == '\0') {
            (**(code **)0x1807825a0)(arg1);
        } else {
            *(undefined *)(arg1 + 3) = 0x7f;
        }
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800935b0
// Address: 0x1800935b0
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800935b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    bool bVar7;
    bool bVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar2 = *(uint16_t *)(arg1 + 0x68);
    iVar10 = (int32_t)arg3;
    if (199 < uVar2) {
        if (uVar2 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if (0xe0 < uVar2) {
            fcn.1800931b0(arg1, 5);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    bVar7 = false;
    iVar3 = *(int64_t *)(arg1 + 0x18);
    iVar4 = *(int64_t *)(arg1 + 0x78);
    if (((iVar3 != iVar4) && (iVar5 = **(int64_t **)(iVar3 + 8), *(char *)(iVar5 + 3) != '\0')) &&
       (iVar5 + 0x28 + *(int64_t *)(iVar5 + 0x28) != 0)) {
        *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + 1;
        bVar7 = true;
    }
    arg2 = arg2 - *(int64_t *)(arg1 + 0x38);
    fcn.180093530(arg1);
    cVar1 = *(char *)(arg1 + 3);
    if (((cVar1 == '\x01') || (cVar1 == '\x06')) || (cVar1 == '\x7f')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if ((bVar7) && (*(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + -1, bVar8)) {
        iVar9 = 0;
        if (iVar10 != -1) {
            iVar9 = iVar10;
        }
        *(int64_t *)((*(int64_t *)(arg1 + 0x78) - iVar4) + iVar3) =
             (int64_t)iVar9 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    if ((iVar10 != -1) && (!bVar8)) {
        *(int64_t *)(arg1 + 0x40) = (int64_t)iVar10 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
    // WARNING: Could not recover jumptable at 0x0001800936d2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)0x180782658)(arg1, 1);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1800935e3
// Address: 0x1800935e3
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800935b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    bool bVar7;
    bool bVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar2 = *(uint16_t *)(arg1 + 0x68);
    iVar10 = (int32_t)arg3;
    if (199 < uVar2) {
        if (uVar2 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if (0xe0 < uVar2) {
            fcn.1800931b0(arg1, 5);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    bVar7 = false;
    iVar3 = *(int64_t *)(arg1 + 0x18);
    iVar4 = *(int64_t *)(arg1 + 0x78);
    if (((iVar3 != iVar4) && (iVar5 = **(int64_t **)(iVar3 + 8), *(char *)(iVar5 + 3) != '\0')) &&
       (iVar5 + 0x28 + *(int64_t *)(iVar5 + 0x28) != 0)) {
        *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + 1;
        bVar7 = true;
    }
    arg2 = arg2 - *(int64_t *)(arg1 + 0x38);
    fcn.180093530(arg1);
    cVar1 = *(char *)(arg1 + 3);
    if (((cVar1 == '\x01') || (cVar1 == '\x06')) || (cVar1 == '\x7f')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if ((bVar7) && (*(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + -1, bVar8)) {
        iVar9 = 0;
        if (iVar10 != -1) {
            iVar9 = iVar10;
        }
        *(int64_t *)((*(int64_t *)(arg1 + 0x78) - iVar4) + iVar3) =
             (int64_t)iVar9 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    if ((iVar10 != -1) && (!bVar8)) {
        *(int64_t *)(arg1 + 0x40) = (int64_t)iVar10 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
    // WARNING: Could not recover jumptable at 0x0001800936d2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)0x180782658)(arg1, 1);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180093660
// Address: 0x180093660
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800935b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    bool bVar7;
    bool bVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar2 = *(uint16_t *)(arg1 + 0x68);
    iVar10 = (int32_t)arg3;
    if (199 < uVar2) {
        if (uVar2 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if (0xe0 < uVar2) {
            fcn.1800931b0(arg1, 5);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    bVar7 = false;
    iVar3 = *(int64_t *)(arg1 + 0x18);
    iVar4 = *(int64_t *)(arg1 + 0x78);
    if (((iVar3 != iVar4) && (iVar5 = **(int64_t **)(iVar3 + 8), *(char *)(iVar5 + 3) != '\0')) &&
       (iVar5 + 0x28 + *(int64_t *)(iVar5 + 0x28) != 0)) {
        *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + 1;
        bVar7 = true;
    }
    arg2 = arg2 - *(int64_t *)(arg1 + 0x38);
    fcn.180093530(arg1);
    cVar1 = *(char *)(arg1 + 3);
    if (((cVar1 == '\x01') || (cVar1 == '\x06')) || (cVar1 == '\x7f')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if ((bVar7) && (*(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + -1, bVar8)) {
        iVar9 = 0;
        if (iVar10 != -1) {
            iVar9 = iVar10;
        }
        *(int64_t *)((*(int64_t *)(arg1 + 0x78) - iVar4) + iVar3) =
             (int64_t)iVar9 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    if ((iVar10 != -1) && (!bVar8)) {
        *(int64_t *)(arg1 + 0x40) = (int64_t)iVar10 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
    // WARNING: Could not recover jumptable at 0x0001800936d2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)0x180782658)(arg1, 1);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180093699
// Address: 0x180093699
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800935b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    bool bVar7;
    bool bVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar2 = *(uint16_t *)(arg1 + 0x68);
    iVar10 = (int32_t)arg3;
    if (199 < uVar2) {
        if (uVar2 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if (0xe0 < uVar2) {
            fcn.1800931b0(arg1, 5);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    bVar7 = false;
    iVar3 = *(int64_t *)(arg1 + 0x18);
    iVar4 = *(int64_t *)(arg1 + 0x78);
    if (((iVar3 != iVar4) && (iVar5 = **(int64_t **)(iVar3 + 8), *(char *)(iVar5 + 3) != '\0')) &&
       (iVar5 + 0x28 + *(int64_t *)(iVar5 + 0x28) != 0)) {
        *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + 1;
        bVar7 = true;
    }
    arg2 = arg2 - *(int64_t *)(arg1 + 0x38);
    fcn.180093530(arg1);
    cVar1 = *(char *)(arg1 + 3);
    if (((cVar1 == '\x01') || (cVar1 == '\x06')) || (cVar1 == '\x7f')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if ((bVar7) && (*(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + -1, bVar8)) {
        iVar9 = 0;
        if (iVar10 != -1) {
            iVar9 = iVar10;
        }
        *(int64_t *)((*(int64_t *)(arg1 + 0x78) - iVar4) + iVar3) =
             (int64_t)iVar9 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    if ((iVar10 != -1) && (!bVar8)) {
        *(int64_t *)(arg1 + 0x40) = (int64_t)iVar10 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
    // WARNING: Could not recover jumptable at 0x0001800936d2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)0x180782658)(arg1, 1);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1800936c7
// Address: 0x1800936c7
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800935b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    bool bVar7;
    bool bVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar2 = *(uint16_t *)(arg1 + 0x68);
    iVar10 = (int32_t)arg3;
    if (199 < uVar2) {
        if (uVar2 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if (0xe0 < uVar2) {
            fcn.1800931b0(arg1, 5);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    bVar7 = false;
    iVar3 = *(int64_t *)(arg1 + 0x18);
    iVar4 = *(int64_t *)(arg1 + 0x78);
    if (((iVar3 != iVar4) && (iVar5 = **(int64_t **)(iVar3 + 8), *(char *)(iVar5 + 3) != '\0')) &&
       (iVar5 + 0x28 + *(int64_t *)(iVar5 + 0x28) != 0)) {
        *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + 1;
        bVar7 = true;
    }
    arg2 = arg2 - *(int64_t *)(arg1 + 0x38);
    fcn.180093530(arg1);
    cVar1 = *(char *)(arg1 + 3);
    if (((cVar1 == '\x01') || (cVar1 == '\x06')) || (cVar1 == '\x7f')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if ((bVar7) && (*(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + -1, bVar8)) {
        iVar9 = 0;
        if (iVar10 != -1) {
            iVar9 = iVar10;
        }
        *(int64_t *)((*(int64_t *)(arg1 + 0x78) - iVar4) + iVar3) =
             (int64_t)iVar9 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    if ((iVar10 != -1) && (!bVar8)) {
        *(int64_t *)(arg1 + 0x40) = (int64_t)iVar10 * 0x10 + arg2 + *(int64_t *)(arg1 + 0x38);
    }
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
    // WARNING: Could not recover jumptable at 0x0001800936d2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)0x180782658)(arg1, 1);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180093700
// Address: 0x180093700
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.180093700(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint32_t *puVar1;
    char cVar2;
    uint16_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar3 = *(uint16_t *)(arg1 + 0x68);
    if (199 < uVar3) {
        if (uVar3 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (0xe0 < uVar3) {
            fcn.1800931b0(arg1, 5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    iVar4 = *(int64_t *)(arg1 + 0x38);
    iVar6 = fcn.1800a5fa0(arg1, arg2, 1);
    if (iVar6 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        (**(code **)0x1807825a0)(arg1);
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    *(int64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x38) - iVar4) + 0x10 + arg2;
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_180093736
// Address: 0x180093736
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.180093700(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint32_t *puVar1;
    char cVar2;
    uint16_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar3 = *(uint16_t *)(arg1 + 0x68);
    if (199 < uVar3) {
        if (uVar3 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (0xe0 < uVar3) {
            fcn.1800931b0(arg1, 5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    iVar4 = *(int64_t *)(arg1 + 0x38);
    iVar6 = fcn.1800a5fa0(arg1, arg2, 1);
    if (iVar6 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        (**(code **)0x1807825a0)(arg1);
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    *(int64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x38) - iVar4) + 0x10 + arg2;
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_180093755
// Address: 0x180093755
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.180093700(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint32_t *puVar1;
    char cVar2;
    uint16_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar3 = *(uint16_t *)(arg1 + 0x68);
    if (199 < uVar3) {
        if (uVar3 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (0xe0 < uVar3) {
            fcn.1800931b0(arg1, 5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    iVar4 = *(int64_t *)(arg1 + 0x38);
    iVar6 = fcn.1800a5fa0(arg1, arg2, 1);
    if (iVar6 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        (**(code **)0x1807825a0)(arg1);
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    *(int64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x38) - iVar4) + 0x10 + arg2;
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_180093796
// Address: 0x180093796
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.180093700(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint32_t *puVar1;
    char cVar2;
    uint16_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar3 = *(uint16_t *)(arg1 + 0x68);
    if (199 < uVar3) {
        if (uVar3 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (0xe0 < uVar3) {
            fcn.1800931b0(arg1, 5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    iVar4 = *(int64_t *)(arg1 + 0x38);
    iVar6 = fcn.1800a5fa0(arg1, arg2, 1);
    if (iVar6 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        (**(code **)0x1807825a0)(arg1);
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    *(int64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x38) - iVar4) + 0x10 + arg2;
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_1800937c8
// Address: 0x1800937c8
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.180093700(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint32_t *puVar1;
    char cVar2;
    uint16_t uVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar3 = *(uint16_t *)(arg1 + 0x68);
    if (199 < uVar3) {
        if (uVar3 == 200) {
            fcn.180093000(arg1, 0x18063e0f0, arg3, arg4);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (0xe0 < uVar3) {
            fcn.1800931b0(arg1, 5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    iVar4 = *(int64_t *)(arg1 + 0x38);
    iVar6 = fcn.1800a5fa0(arg1, arg2, 1);
    if (iVar6 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        (**(code **)0x1807825a0)(arg1);
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    *(int64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x38) - iVar4) + 0x10 + arg2;
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_180093800
// Address: 0x180093800
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180093800(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t var_8h;
    
    iVar5 = (int32_t)arg2;
    if ((iVar5 != 2) && (iVar5 != 3)) {
        if (iVar5 == 4) {
            uVar7 = 0x11;
            uVar6 = 0x18063ddf8;
        } else {
            if (iVar5 != 5) goto code_r0x00018009386e;
            uVar7 = 0x17;
            uVar6 = 0x18063dde0;
        }
        uVar6 = fcn.18009a8e0(arg1, uVar6, uVar7);
        *(undefined8 *)arg3 = uVar6;
        *(undefined4 *)(arg3 + 0xc) = 6;
        *(int64_t *)(arg1 + 0x40) = arg3 + 0x10;
        return;
    }
    iVar1 = *(int64_t *)(arg1 + 0x40);
    uVar2 = *(undefined4 *)(iVar1 + -0xc);
    uVar3 = *(undefined4 *)(iVar1 + -8);
    uVar4 = *(undefined4 *)(iVar1 + -4);
    *(undefined4 *)arg3 = *(undefined4 *)(iVar1 + -0x10);
    *(undefined4 *)(arg3 + 4) = uVar2;
    *(undefined4 *)(arg3 + 8) = uVar3;
    *(undefined4 *)(arg3 + 0xc) = uVar4;
code_r0x00018009386e:
    *(int64_t *)(arg1 + 0x40) = arg3 + 0x10;
    return;
}

// ============================================================
// Function: FUN_180093890
// Address: 0x180093890
// Size: 402 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180093890(int64_t arg1)
{
    int64_t *piVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    uint64_t uVar12;
    int32_t iVar13;
    undefined4 *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    
    do {
        do {
            while( true ) {
                if (((*(char *)(arg1 + 3) != '\0') && (*(char *)(arg1 + 3) != '\x7f')) ||
                   (uVar12 = *(uint64_t *)(arg1 + 0x18), uVar12 <= *(uint64_t *)(arg1 + 0x78))) {
                    return;
                }
                *(undefined *)(arg1 + 3) = 0;
                iVar3 = **(int64_t **)(uVar12 + 8);
                if (*(char *)(iVar3 + 3) != '\0') break;
                if ((*(char *)0x180777dd8 != '\0') && ((*(uint32_t *)(uVar12 + 0x24) & 8) != 0)) {
                    *(uint32_t *)(uVar12 + 0x24) = *(uint32_t *)(uVar12 + 0x24) & 0xfffffff7;
                    iVar3 = *(int64_t *)(uVar12 + 0x18);
                    iVar9 = *(int32_t *)(iVar3 + -4);
                    uVar12 = (uint64_t)(uint8_t)((uint32_t)iVar9 >> 8);
                    iVar4 = *(int64_t *)(arg1 + 0x28);
                    puVar11 = (undefined4 *)(iVar4 + 0x30 + uVar12 * 0x10);
                    uVar6 = puVar11[1];
                    uVar7 = puVar11[2];
                    uVar8 = puVar11[3];
                    puVar5 = (undefined4 *)(iVar4 + 0x20 + uVar12 * 0x10);
                    *puVar5 = *puVar11;
                    puVar5[1] = uVar6;
                    puVar5[2] = uVar7;
                    puVar5[3] = uVar8;
                    if (*(int32_t *)(iVar4 + 0x3c + uVar12 * 0x10) == 0) {
                        iVar9 = 1;
                    } else {
                        iVar9 = iVar9 >> 0x10;
                    }
                    *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x18) = iVar3 + (int64_t)iVar9 * 4;
                }
                (**(code **)0x1807825a0)(arg1);
            }
            if (*(char *)0x180777030 != '\0') {
                *(uint32_t *)(uVar12 + 0x24) = *(uint32_t *)(uVar12 + 0x24) & 0xfffffffd;
            }
            iVar9 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, 0);
            cVar2 = *(char *)(arg1 + 3);
            if (cVar2 == '\x06') {
                return;
            }
            if (cVar2 == '\x01') {
                return;
            }
        } while ((*(char *)0x180777030 != '\0') && (cVar2 == '\x7f'));
        iVar3 = *(int64_t *)(arg1 + 0x40);
        iVar4 = *(int64_t *)(arg1 + 0x18);
        if (*(char *)0x180777df8 != '\0') {
            piVar1 = (int64_t *)(**(int64_t **)(iVar4 + 8) + 8);
            *piVar1 = *piVar1 + -1;
        }
        iVar13 = *(int32_t *)(iVar4 + 0x20);
        puVar11 = *(undefined4 **)(iVar4 + 8);
        puVar5 = *(undefined4 **)(arg1 + 0x40);
        puVar10 = puVar11;
        puVar14 = (undefined4 *)(iVar3 + (int64_t)iVar9 * -0x10);
        if (iVar13 != 0) {
            do {
                puVar11 = puVar10;
                if (puVar5 <= puVar14) break;
                puVar11 = puVar10 + 4;
                uVar6 = puVar14[1];
                uVar7 = puVar14[2];
                uVar8 = puVar14[3];
                *puVar10 = *puVar14;
                puVar10[1] = uVar6;
                puVar10[2] = uVar7;
                puVar10[3] = uVar8;
                iVar13 = iVar13 + -1;
                puVar10 = puVar11;
                puVar14 = puVar14 + 4;
            } while (iVar13 != 0);
            for (; 0 < iVar13; iVar13 = iVar13 + -1) {
                puVar11[3] = 0;
                puVar11 = puVar11 + 4;
            }
        }
        *(undefined8 **)(arg1 + 0x18) = (undefined8 *)(iVar4 + -0x28);
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(iVar4 + -0x18);
        if (*(int32_t *)(iVar4 + 0x20) != -1) {
            puVar11 = *(undefined4 **)(undefined8 *)(iVar4 + -0x28);
        }
        *(undefined4 **)(arg1 + 0x40) = puVar11;
    } while( true );
}

