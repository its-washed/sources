// Chunk 123 - 50 functions

// ============================================================
// Function: FUN_1801a6210
// Address: 0x1801a6210
// Size: 76 bytes
// ============================================================
void fcn.1801a6210(int64_t arg_30h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *unaff_RBX;
    undefined4 *unaff_RDI;
    
    uVar1 = unaff_RBX[1];
    uVar2 = unaff_RBX[2];
    uVar3 = unaff_RBX[3];
    *unaff_RDI = *unaff_RBX;
    unaff_RDI[1] = uVar1;
    unaff_RDI[2] = uVar2;
    unaff_RDI[3] = uVar3;
    uVar1 = unaff_RBX[5];
    uVar2 = unaff_RBX[6];
    uVar3 = unaff_RBX[7];
    unaff_RDI[4] = unaff_RBX[4];
    unaff_RDI[5] = uVar1;
    unaff_RDI[6] = uVar2;
    unaff_RDI[7] = uVar3;
    uVar1 = unaff_RBX[9];
    uVar2 = unaff_RBX[10];
    uVar3 = unaff_RBX[0xb];
    unaff_RDI[8] = unaff_RBX[8];
    unaff_RDI[9] = uVar1;
    unaff_RDI[10] = uVar2;
    unaff_RDI[0xb] = uVar3;
    uVar1 = unaff_RBX[0xd];
    uVar2 = unaff_RBX[0xe];
    uVar3 = unaff_RBX[0xf];
    unaff_RDI[0xc] = unaff_RBX[0xc];
    unaff_RDI[0xd] = uVar1;
    unaff_RDI[0xe] = uVar2;
    unaff_RDI[0xf] = uVar3;
    uVar1 = unaff_RBX[0x11];
    uVar2 = unaff_RBX[0x12];
    uVar3 = unaff_RBX[0x13];
    unaff_RDI[0x10] = unaff_RBX[0x10];
    unaff_RDI[0x11] = uVar1;
    unaff_RDI[0x12] = uVar2;
    unaff_RDI[0x13] = uVar3;
    uVar1 = unaff_RBX[0x15];
    uVar2 = unaff_RBX[0x16];
    uVar3 = unaff_RBX[0x17];
    unaff_RDI[0x14] = unaff_RBX[0x14];
    unaff_RDI[0x15] = uVar1;
    unaff_RDI[0x16] = uVar2;
    unaff_RDI[0x17] = uVar3;
    uVar1 = unaff_RBX[0x19];
    uVar2 = unaff_RBX[0x1a];
    uVar3 = unaff_RBX[0x1b];
    unaff_RDI[0x18] = unaff_RBX[0x18];
    unaff_RDI[0x19] = uVar1;
    unaff_RDI[0x1a] = uVar2;
    unaff_RDI[0x1b] = uVar3;
    uVar1 = unaff_RBX[0x1d];
    uVar2 = unaff_RBX[0x1e];
    uVar3 = unaff_RBX[0x1f];
    unaff_RDI[0x1c] = unaff_RBX[0x1c];
    unaff_RDI[0x1d] = uVar1;
    unaff_RDI[0x1e] = uVar2;
    unaff_RDI[0x1f] = uVar3;
    return;
}

// ============================================================
// Function: FUN_1801a625c
// Address: 0x1801a625c
// Size: 55 bytes
// ============================================================
undefined8 fcn.1801a625c(void)
{
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000038;
    int64_t in_stack_00000040;
    int64_t in_stack_00000050;
    
    fcn.180229480(in_stack_00000020, in_stack_00000028);
    fcn.1802295a0(in_stack_00000020, in_stack_00000028, in_stack_00000030, in_stack_00000038, in_stack_00000050);
    fcn.1802296d0(in_stack_00000040);
    return 0;
}

// ============================================================
// Function: FUN_1801a62c0
// Address: 0x1801a62c0
// Size: 742 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801a62c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h)
{
    int32_t *piVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int32_t **in_RCX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a62d0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((*(uint8_t *)(in_RCX + 0x15) & 2) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a62e8;
    func_0x000180229b10();
    uVar3 = *(uint32_t *)(in_RCX + 0x15);
    if ((uVar3 & 1) == 0) {
        piVar6 = *in_RCX;
        if (piVar6 != (int32_t *)0x0) {
            if (*piVar6 == 0) {
code_r0x0001801a6324:
                if (*(int32_t *)(in_RCX + 0xf) == 0) {
                    if ((*(int64_t *)(piVar6 + 700) != 0) && (*(int64_t *)(piVar6 + 0x2be) != 0))
                    goto code_r0x0001801a635b;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a63c1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a63d9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar5));
                    piVar6 = (int32_t *)0x1804adc60;
                    goto code_r0x0001801a63e0;
                }
                if (*(int64_t *)(*(int64_t *)(piVar6 + 2) + 0x2c0) == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a633d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                } else {
code_r0x0001801a635b:
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6363;
                    iVar2 = func_0x0001801a5eb0(in_RCX);
                    if (iVar2 != 0) {
                        piVar6[0x58] = piVar6[0x58] | 0x4000;
                        piVar6 = *in_RCX;
                        if (*(int32_t *)(in_RCX + 0xf) == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6395;
                            func_0x000180194930(piVar6);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a638e;
                            func_0x0001801944a0();
                        }
                        *(uint32_t *)(in_RCX + 0x15) = *(uint32_t *)(in_RCX + 0x15) | 1;
                        uVar3 = *(uint32_t *)(in_RCX + 0x15);
                        goto code_r0x0001801a63a2;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a636c;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                }
                goto code_r0x0001801a649c;
            }
            if ((char)*piVar6 < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6318;
                piVar6 = (int32_t *)func_0x0001801bda50(piVar6);
                if (piVar6 != (int32_t *)0x0) goto code_r0x0001801a6324;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6435;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    } else {
code_r0x0001801a63a2:
        piVar6 = *in_RCX;
        if ((uVar3 & 4) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6441;
            iVar2 = func_0x0001801933a0(piVar6);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a63b7;
            iVar2 = func_0x000180194120(piVar6, 0, 0);
        }
        if (0 < iVar2) {
            if ((*(uint8_t *)(in_RCX + 0x15) & 4) != 0) {
code_r0x0001801a6591:
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6596;
                func_0x0001802299d0();
                return 1;
            }
            piVar6 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6538;
            func_0x000180193570(piVar6, (int64_t)&arg_40h + iVar5, (int64_t)&arg_38h + iVar5);
            if ((*(int64_t *)((int64_t)&arg_40h + iVar5) != 0) && (*(int32_t *)((int64_t)&arg_38h + iVar5) != 0)) {
                *(uint32_t *)(in_RCX + 0x15) = *(uint32_t *)(in_RCX + 0x15) | 4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6553;
                func_0x0001802299d0();
                piVar6 = in_RCX[0xb];
                piVar1 = in_RCX[0xc];
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a655d;
                uVar7 = (*(code *)piVar6)(piVar1);
                return uVar7;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a656d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6585;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar5));
            piVar6 = (int32_t *)0x1804adc88;
code_r0x0001801a63e0:
            *(int32_t **)((int64_t)&var_20h + iVar5) = piVar6;
            *(undefined8 *)((int64_t)&var_18h + iVar5) = 0x178;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a640a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
            if (*(int32_t *)((int64_t)in_RCX + 0x7c) == 0) {
                return 0;
            }
            piVar1 = in_RCX[0x12];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6420;
            func_0x0001802547a0(piVar1);
            in_RCX[0x13] = (int32_t *)0x178;
            goto code_r0x0001801a64fd;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6450;
        iVar4 = func_0x000180229970();
        piVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6463;
        iVar2 = func_0x000180196bb0(piVar6, iVar2, 0 < iVar4);
        if ((((iVar2 == 2) || (iVar2 == 3)) || (iVar2 == 4)) || ((iVar2 == 0xb || (iVar2 == 0xc))))
        goto code_r0x0001801a6591;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6497;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    }
code_r0x0001801a649c:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a64af;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    piVar6 = (int32_t *)0x1804adc38;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804adc38;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a64e0;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    if (*(int32_t *)((int64_t)in_RCX + 0x7c) == 0) {
        return 0;
    }
    piVar1 = in_RCX[0x12];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a64f2;
    func_0x0001802547a0(piVar1);
    in_RCX[0x13] = (int32_t *)0x1;
code_r0x0001801a64fd:
    *(uint32_t *)(in_RCX + 0x15) = *(uint32_t *)(in_RCX + 0x15) | 2;
    in_RCX[0x14] = piVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a6510;
    func_0x0001802299d0();
    return 0;
}

// ============================================================
// Function: FUN_1801a65b0
// Address: 0x1801a65b0
// Size: 41 bytes
// ============================================================
void fcn.1801a65b0(int64_t arg_50h, int64_t arg_70h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_R9;
    
    iVar2 = fcn.18045a350();
    iVar1 = *(int64_t *)((int64_t)&arg_70h + -iVar2);
    // WARNING: Could not recover jumptable at 0x0001801a65d6. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(iVar1 + 0x48))(in_R9, *(undefined8 *)((int64_t)&arg_50h + -iVar2), *(undefined8 *)(iVar1 + 0x50));
    return;
}

// ============================================================
// Function: FUN_1801a65e0
// Address: 0x1801a65e0
// Size: 35 bytes
// ============================================================
void fcn.1801a65e0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801a6610
// Address: 0x1801a6610
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1801a6610(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a6620;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a6640;
    puVar2 = (undefined8 *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (puVar2 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *puVar2 = *in_RCX;
    puVar2[1] = in_RDX;
    puVar2[2] = 0;
    return puVar2;
}

// ============================================================
// Function: FUN_1801a66d0
// Address: 0x1801a66d0
// Size: 35 bytes
// ============================================================
void fcn.1801a66d0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801a6700
// Address: 0x1801a6700
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1801a6700(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t iVar4;
    undefined8 unaff_RSI;
    int64_t iVar5;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a6716;
    iVar3 = fcn.18045a350();
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *in_RCX = in_RDX;
        return in_RDX;
    }
    *(undefined8 *)((int64_t)&arg_28h + -iVar3) = unaff_RSI;
    iVar5 = 0;
    while( true ) {
        iVar4 = iVar1;
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801a6761;
        iVar2 = fcn.180497f30(iVar4, in_RDX, 8);
        if (0 < iVar2) {
            *(int64_t *)(in_RDX + 0x10) = iVar4;
            if (iVar5 == 0) {
                *in_RCX = in_RDX;
                return in_RDX;
            }
            *(int64_t *)(iVar5 + 0x10) = in_RDX;
            return in_RDX;
        }
        if (iVar2 == 0) break;
        iVar1 = *(int64_t *)(iVar4 + 0x10);
        iVar5 = iVar4;
        if (iVar1 == 0) {
            *(undefined8 *)(in_RDX + 0x10) = 0;
            *(int64_t *)(iVar4 + 0x10) = in_RDX;
            return in_RDX;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a67b0
// Address: 0x1801a67b0
// Size: 40 bytes
// ============================================================
int64_t fcn.1801a67b0(int64_t arg_30h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar4 = 0x10;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180224d70;
    iVar2 = fcn.18045a350(0x10, 0x1804adcb0, 0x26);
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d7b;
    iVar3 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                         );
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d90;
        fcn.1804986e0(iVar3, 0, uVar4);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1801a6830
// Address: 0x1801a6830
// Size: 1049 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Type propagation algorithm not settling

int64_t * fcn.1801a6830(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    int64_t *in_RDX;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t aiStackX_10 [2];
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a6848;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar1 = (undefined8 *)*in_RDX;
    *(undefined4 *)((int64_t)&arg_40h + iVar7) = 0;
    piVar10 = (int64_t *)0x0;
    iVar8 = puVar1[0xce];
    if (iVar8 == puVar1[0xcd]) {
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a688d;
            iVar8 = func_0x000180224ed0(10, 0x38, 0x1804aeee0, 0xf3);
        } else {
            uVar3 = puVar1[0xcc];
            *(undefined4 *)((int64_t)aiStackX_10 + iVar7 + -8) = 0xf8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a68b4;
            iVar8 = func_0x000180224f60(uVar3, iVar8 + 10, 0x38, 0x1804aeee0);
        }
        if (iVar8 == 0) {
            return (int64_t *)0x0;
        }
        iVar2 = puVar1[0xce];
        puVar1[0xcc] = iVar8;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a68dc;
        fcn.1804986e0(iVar8 + iVar2 * 0x38, 0, 0x230);
        puVar1[0xce] = puVar1[0xce] + 10;
    }
    piVar9 = (int64_t *)(puVar1[0xcc] + puVar1[0xcd] * 0x38);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6905;
    iVar8 = func_0x00018022ae60(in_RCX, 0x1804aeef0);
    if ((iVar8 == 0) || (*(int32_t *)(iVar8 + 8) != 4)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6bb9;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar7));
    } else {
        uVar3 = *(undefined8 *)(iVar8 + 0x10);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a692e;
        iVar8 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x109);
        *piVar9 = iVar8;
        piVar11 = (int64_t *)0x0;
        if (iVar8 == 0) goto code_r0x0001801a6be3;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6949;
        iVar8 = func_0x00018022ae60(in_RCX, 0x1804aef18);
        if ((iVar8 == 0) || (*(int32_t *)(iVar8 + 8) != 4)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6bad;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar7));
        } else {
            uVar3 = *(undefined8 *)(iVar8 + 0x10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6972;
            iVar8 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x112);
            piVar9[1] = iVar8;
            piVar11 = piVar10;
            if (iVar8 == 0) goto code_r0x0001801a6be3;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a698e;
            iVar8 = func_0x00018022ae60(in_RCX, 0x1804aef30);
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a69a4;
                iVar5 = func_0x00018022a610(iVar8, (int64_t)&arg_48h + iVar7);
                if ((iVar5 != 0) && (*(uint32_t *)((int64_t)&arg_48h + iVar7) < 0x10000)) {
                    *(int16_t *)((int64_t)piVar9 + 0x1c) = (int16_t)*(uint32_t *)((int64_t)&arg_48h + iVar7);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a69ce;
                    iVar8 = func_0x00018022ae60(in_RCX, 0x1804aef40);
                    if ((iVar8 == 0) || (*(int32_t *)(iVar8 + 8) != 4)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6b95;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar7));
                    } else {
                        uVar3 = *(undefined8 *)(iVar8 + 0x10);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a69f7;
                        iVar8 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x122);
                        piVar9[2] = iVar8;
                        if (iVar8 == 0) goto code_r0x0001801a6be3;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6a13;
                        iVar8 = func_0x00018022ae60(in_RCX, 0x1804aef50);
                        if (iVar8 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6a28;
                            iVar5 = func_0x00018022a610(iVar8, piVar9 + 3);
                            if (iVar5 != 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6a3f;
                                iVar8 = func_0x00018022ae60(in_RCX, 0x1804aef68);
                                if (iVar8 == 0) {
                                    uVar6 = *(uint32_t *)((int64_t)&arg_40h + iVar7);
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6a51;
                                    iVar5 = func_0x00018022a610(iVar8, (int64_t)&arg_40h + iVar7);
                                    if ((iVar5 == 0) || (uVar6 = *(uint32_t *)((int64_t)&arg_40h + iVar7), 1 < uVar6)) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6a63;
                                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), 
                                                      *(int64_t *)((int64_t)aiStackX_10 + iVar7));
                                        goto code_r0x0001801a6bbe;
                                    }
                                }
                                *(uint8_t *)(piVar9 + 6) = (uint8_t)uVar6 & 1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6a85;
                                iVar8 = func_0x00018022ae60(in_RCX, 0x1804aef80);
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6a9a;
                                    iVar5 = func_0x000180229fc0(iVar8, piVar9 + 4);
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6ab1;
                                        iVar8 = func_0x00018022ae60(in_RCX, 0x1804aef90);
                                        if (iVar8 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6ac6;
                                            iVar5 = func_0x000180229fc0(iVar8, (int64_t)piVar9 + 0x24);
                                            if (iVar5 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6add;
                                                iVar8 = func_0x00018022ae60(in_RCX, 0x1804aefa0);
                                                if (iVar8 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6aee;
                                                    iVar5 = func_0x000180229fc0(iVar8, piVar9 + 5);
                                                    if (iVar5 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6b01;
                                                        iVar8 = func_0x00018022ae60(in_RCX, 0x1804aefb0);
                                                        if (iVar8 != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6b12;
                                                            iVar5 = func_0x000180229fc0(iVar8, (int64_t)piVar9 + 0x2c);
                                                            if (iVar5 != 0) {
                                                                piVar11 = (int64_t *)0x1;
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) =
                                                                     0x1801a6b20;
                                                                func_0x000180229b10();
                                                                uVar3 = puVar1[0x8c];
                                                                iVar8 = piVar9[2];
                                                                uVar4 = *puVar1;
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) =
                                                                     0x1801a6b33;
                                                                iVar8 = func_0x0001802579b0(uVar4, iVar8, uVar3);
                                                                if (iVar8 != 0) {
                                                                    puVar1[0xcd] = puVar1[0xcd] + 1;
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) =
                                                                         0x1801a6b4a;
                                                                    func_0x000180257a00(iVar8);
                                                                    piVar9 = (int64_t *)0x0;
                                                                }
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) =
                                                                     0x1801a6b4f;
                                                                func_0x0001802299d0();
                                                                goto code_r0x0001801a6be3;
                                                            }
                                                        }
                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6b59;
                                                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), 
                                                                      *(int64_t *)((int64_t)aiStackX_10 + iVar7));
                                                        goto code_r0x0001801a6bbe;
                                                    }
                                                }
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6b65;
                                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), 
                                                              *(int64_t *)((int64_t)aiStackX_10 + iVar7));
                                                goto code_r0x0001801a6bbe;
                                            }
                                        }
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6b71;
                                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), 
                                                      *(int64_t *)((int64_t)aiStackX_10 + iVar7));
                                        goto code_r0x0001801a6bbe;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6b7d;
                                fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar7));
                                goto code_r0x0001801a6bbe;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6b89;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar7));
                    }
                    goto code_r0x0001801a6bbe;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6ba1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar7));
        }
    }
code_r0x0001801a6bbe:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6bd1;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar7), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar7 + 8), *(int64_t *)((int64_t)&var_20h + iVar7), 
                  *(int64_t *)((int64_t)&arg_38h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6be3;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    piVar11 = piVar10;
code_r0x0001801a6be3:
    if (piVar9 != (int64_t *)0x0) {
        iVar8 = *piVar9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6bfd;
        func_0x000180224990(iVar8, 0x1804aeee0, 0x15c);
        iVar8 = piVar9[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6c13;
        func_0x000180224990(iVar8, 0x1804aeee0, 0x15d);
        iVar8 = piVar9[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a6c29;
        func_0x000180224990(iVar8, 0x1804aeee0, 0x15e);
        piVar9[1] = 0;
        *piVar9 = 0;
        piVar9[2] = 0;
    }
    return piVar11;
}

// ============================================================
// Function: FUN_1801a6c50
// Address: 0x1801a6c50
// Size: 226 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined4 fcn.1801a6c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 in_RCX;
    int64_t *in_RDX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined4 uVar15;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_30 = 0x1801a6c67;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar2 = (undefined8 *)*in_RDX;
    uVar7 = 0;
    iVar13 = in_RDX[1];
    *(undefined4 *)((int64_t)&arg_40h + iVar9) = 0;
    uVar15 = 0;
    iVar10 = puVar2[0xd1];
    if (iVar10 == puVar2[0xd0]) {
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6cb4;
            iVar10 = func_0x000180224ed0(10, 0x68, 0x1804aeee0, 0x189);
        } else {
            uVar3 = puVar2[0xcf];
            *(undefined4 *)((int64_t)&var_8h + iVar9) = 0x18e;
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6cdb;
            iVar10 = func_0x000180224f60(uVar3, iVar10 + 10, 0x68, 0x1804aeee0);
        }
        if (iVar10 == 0) {
            return 0;
        }
        iVar11 = puVar2[0xd1];
        puVar2[0xcf] = iVar10;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d11;
        fcn.1804986e0(iVar11 * 0x68 + iVar10, 0, 0x410);
        puVar2[0xd1] = puVar2[0xd1] + 10;
    }
    piVar14 = (int64_t *)(puVar2[0xcf] + puVar2[0xd0] * 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d44;
    iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefd0);
    if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 8) != 4)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73c5;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
    } else {
        iVar11 = piVar14[2];
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d70;
        func_0x000180224990(iVar11, 0x1804aeee0, 0x19f);
        uVar3 = *(undefined8 *)(iVar10 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d86;
        iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1a0);
        piVar14[2] = iVar10;
        uVar6 = uVar7;
        if (iVar10 == 0) goto code_r0x0001801a73ef;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6da2;
        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aeff8);
        if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 8) != 4)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73b9;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
            goto code_r0x0001801a73ca;
        }
        iVar11 = *piVar14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6dcd;
        func_0x000180224990(iVar11, 0x1804aeee0, 0x1a9);
        uVar3 = *(undefined8 *)(iVar10 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6de3;
        iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1aa);
        *piVar14 = iVar10;
        uVar6 = uVar15;
        if (iVar10 == 0) goto code_r0x0001801a73ef;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6dfe;
        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af010);
        if (iVar10 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e14;
            iVar5 = func_0x00018022a610(iVar10, (int64_t)&arg_40h + iVar9);
            if ((iVar5 != 0) && (*(uint32_t *)((int64_t)&arg_40h + iVar9) < 0x10000)) {
                *(int16_t *)(piVar14 + 1) = (int16_t)*(uint32_t *)((int64_t)&arg_40h + iVar9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e3e;
                iVar10 = func_0x00018022ae60(in_RCX, 0x1804af028);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e53;
                    iVar5 = func_0x00018022a610(iVar10, piVar14 + 10);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e6a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af040);
                        if (iVar10 == 0) {
                            piVar14[3] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[3];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e98;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1c6);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6eae;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1c7);
                            piVar14[3] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6eca;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af050);
                        if (iVar10 == 0) {
                            piVar14[4] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[4];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6ef8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1d2);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f0e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1d3);
                            piVar14[4] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f2a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af068);
                        if (iVar10 == 0) {
                            piVar14[5] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[5];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f58;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1de);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f6e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1df);
                            piVar14[5] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f8a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af080);
                        if (iVar10 == 0) {
                            piVar14[6] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[6];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fb8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1ea);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fce;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1eb);
                            piVar14[6] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fea;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af098);
                        if (iVar10 == 0) {
                            piVar14[7] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[7];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7018;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1f6);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a702e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1f7);
                            piVar14[7] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a704a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af0b0);
                        if (iVar10 == 0) {
                            piVar14[8] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[8];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7078;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x202);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a708e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x203);
                            piVar14[8] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70aa;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af0c8);
                        if (iVar10 == 0) {
                            piVar14[9] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[9];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70d8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x20e);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70ee;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x20f);
                            piVar14[9] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)piVar14 + 0x5c) = 0xffffffffffffffff;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7112;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefa0);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7123;
                            iVar5 = func_0x000180229fc0(iVar10, (int64_t)piVar14 + 0x5c);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a712c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                uVar15 = uVar7;
                                goto code_r0x0001801a73ca;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7145;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefb0);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7156;
                            iVar5 = func_0x000180229fc0(iVar10, piVar14 + 0xc);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a715f;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                goto code_r0x0001801a73ca;
                            }
                        }
                        iVar5 = *(int32_t *)(piVar14 + 0xc);
                        if (((iVar5 != 0) && (iVar5 != -1)) && (*(int32_t *)((int64_t)piVar14 + 0x5c) < iVar5)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a717f;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9)
                                         );
                            goto code_r0x0001801a73ca;
                        }
                        *(undefined8 *)((int64_t)piVar14 + 0x5c) = 0xffffffffffffffff;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71a0;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aef80);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71b5;
                            iVar5 = func_0x000180229fc0(iVar10, (int64_t)piVar14 + 0x54);
                            if (iVar5 != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71cc;
                                iVar10 = func_0x00018022ae60(in_RCX, 0x1804aef90);
                                if (iVar10 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71e1;
                                    iVar5 = func_0x000180229fc0(iVar10, piVar14 + 0xb);
                                    if (iVar5 != 0) {
                                        iVar5 = *(int32_t *)(piVar14 + 0xb);
                                        if (((iVar5 != 0) && (iVar5 != -1)) &&
                                           (iVar5 < *(int32_t *)((int64_t)piVar14 + 0x54))) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71ff;
                                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                                          *(int64_t *)(&stack0x00000000 + iVar9));
                                            goto code_r0x0001801a73ca;
                                        }
                                        iVar1 = *(int32_t *)((int64_t)piVar14 + 0x54);
                                        if (((iVar1 == 0) || (iVar1 == -1)) || (iVar1 < 0x305)) {
                                            if (((iVar5 != 0) && (iVar5 != -1)) && (iVar5 < 0x304)) {
                                                *(undefined8 *)((int64_t)piVar14 + 0x54) = 0xffffffffffffffff;
                                                goto code_r0x0001801a724f;
                                            }
                                            if (iVar1 == -1) goto code_r0x0001801a724f;
                                        } else {
                                            *(undefined8 *)((int64_t)piVar14 + 0x54) = 0xffffffffffffffff;
code_r0x0001801a724f:
                                            if (*(int32_t *)((int64_t)piVar14 + 0x5c) == -1) {
                                                uVar6 = 1;
                                                goto code_r0x0001801a73ef;
                                            }
                                        }
                                        uVar15 = 1;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a726b;
                                        func_0x000180229b10();
                                        iVar10 = piVar14[8];
                                        if ((iVar10 == 0) && (iVar10 = piVar14[4], iVar10 == 0)) {
                                            iVar10 = piVar14[2];
                                        }
                                        uVar3 = puVar2[0x8c];
                                        uVar4 = *puVar2;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7293;
                                        iVar11 = func_0x0001802579b0(uVar4, iVar10, uVar3);
                                        if (iVar11 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72a7;
                                            iVar12 = func_0x0001801dd170(iVar11);
                                            if (iVar12 == iVar13) {
                                                iVar13 = piVar14[2];
                                                iVar12 = piVar14[3];
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72c0;
                                                func_0x00018022c870(iVar12, iVar13, 0);
                                                iVar13 = piVar14[2];
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72c9;
                                                iVar5 = func_0x00018022d1b0(iVar13);
                                                if (iVar5 != 0) {
                                                    iVar13 = piVar14[2];
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72da;
                                                    uVar6 = func_0x00018022d1b0(iVar13);
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72e1;
                                                    iVar13 = func_0x00018022cba0(uVar6);
                                                    if (iVar13 != 0) {
                                                        iVar13 = piVar14[4];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[5];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72ff;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        iVar13 = piVar14[8];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[9];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7314;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        iVar13 = piVar14[6];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[7];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7329;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        if (piVar14[6] != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7337;
                                                            uVar7 = func_0x00018022d1b0();
                                                        }
                                                        iVar13 = piVar14[2];
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7346;
                                                        uVar6 = func_0x00018022d1b0(iVar10);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7350;
                                                        uVar8 = func_0x00018022d1b0(iVar13);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a735d;
                                                        func_0x000180256560(uVar8, uVar7, uVar6);
                                                        puVar2[0xd0] = puVar2[0xd0] + 1;
                                                        piVar14 = (int64_t *)0x0;
                                                        goto code_r0x0001801a7366;
                                                    }
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a737d;
                                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                                goto code_r0x0001801a73ca;
                                            }
code_r0x0001801a7366:
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a736e;
                                            func_0x000180257a00(iVar11);
                                        }
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7373;
                                        func_0x0001802299d0();
                                        uVar6 = uVar15;
                                        goto code_r0x0001801a73ef;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7389;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                goto code_r0x0001801a73ca;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7395;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
                        goto code_r0x0001801a73ca;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73a1;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
                goto code_r0x0001801a73ca;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
    }
code_r0x0001801a73ca:
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73dd;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar9), *(int64_t *)((int64_t)aiStackX_8 + iVar9 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar9));
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73ef;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar9 + 0x10));
    uVar6 = uVar15;
code_r0x0001801a73ef:
    if (piVar14 != (int64_t *)0x0) {
        iVar13 = *piVar14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7417;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x283);
        iVar13 = piVar14[2];
        *piVar14 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7430;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x285);
        iVar13 = piVar14[3];
        piVar14[2] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a744a;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x287);
        iVar13 = piVar14[4];
        piVar14[3] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7464;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x289);
        iVar13 = piVar14[5];
        piVar14[4] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a747e;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28b);
        iVar13 = piVar14[6];
        piVar14[5] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7498;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28d);
        iVar13 = piVar14[7];
        piVar14[6] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74b2;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28f);
        iVar13 = piVar14[8];
        piVar14[7] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74cc;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x291);
        iVar13 = piVar14[9];
        piVar14[8] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74e6;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x293);
        piVar14[9] = 0;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801a6d32
// Address: 0x1801a6d32
// Size: 1744 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined4 fcn.1801a6c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 in_RCX;
    int64_t *in_RDX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined4 uVar15;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_30 = 0x1801a6c67;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar2 = (undefined8 *)*in_RDX;
    uVar7 = 0;
    iVar13 = in_RDX[1];
    *(undefined4 *)((int64_t)&arg_40h + iVar9) = 0;
    uVar15 = 0;
    iVar10 = puVar2[0xd1];
    if (iVar10 == puVar2[0xd0]) {
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6cb4;
            iVar10 = func_0x000180224ed0(10, 0x68, 0x1804aeee0, 0x189);
        } else {
            uVar3 = puVar2[0xcf];
            *(undefined4 *)((int64_t)&var_8h + iVar9) = 0x18e;
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6cdb;
            iVar10 = func_0x000180224f60(uVar3, iVar10 + 10, 0x68, 0x1804aeee0);
        }
        if (iVar10 == 0) {
            return 0;
        }
        iVar11 = puVar2[0xd1];
        puVar2[0xcf] = iVar10;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d11;
        fcn.1804986e0(iVar11 * 0x68 + iVar10, 0, 0x410);
        puVar2[0xd1] = puVar2[0xd1] + 10;
    }
    piVar14 = (int64_t *)(puVar2[0xcf] + puVar2[0xd0] * 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d44;
    iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefd0);
    if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 8) != 4)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73c5;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
    } else {
        iVar11 = piVar14[2];
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d70;
        func_0x000180224990(iVar11, 0x1804aeee0, 0x19f);
        uVar3 = *(undefined8 *)(iVar10 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d86;
        iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1a0);
        piVar14[2] = iVar10;
        uVar6 = uVar7;
        if (iVar10 == 0) goto code_r0x0001801a73ef;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6da2;
        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aeff8);
        if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 8) != 4)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73b9;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
            goto code_r0x0001801a73ca;
        }
        iVar11 = *piVar14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6dcd;
        func_0x000180224990(iVar11, 0x1804aeee0, 0x1a9);
        uVar3 = *(undefined8 *)(iVar10 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6de3;
        iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1aa);
        *piVar14 = iVar10;
        uVar6 = uVar15;
        if (iVar10 == 0) goto code_r0x0001801a73ef;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6dfe;
        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af010);
        if (iVar10 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e14;
            iVar5 = func_0x00018022a610(iVar10, (int64_t)&arg_40h + iVar9);
            if ((iVar5 != 0) && (*(uint32_t *)((int64_t)&arg_40h + iVar9) < 0x10000)) {
                *(int16_t *)(piVar14 + 1) = (int16_t)*(uint32_t *)((int64_t)&arg_40h + iVar9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e3e;
                iVar10 = func_0x00018022ae60(in_RCX, 0x1804af028);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e53;
                    iVar5 = func_0x00018022a610(iVar10, piVar14 + 10);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e6a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af040);
                        if (iVar10 == 0) {
                            piVar14[3] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[3];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e98;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1c6);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6eae;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1c7);
                            piVar14[3] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6eca;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af050);
                        if (iVar10 == 0) {
                            piVar14[4] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[4];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6ef8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1d2);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f0e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1d3);
                            piVar14[4] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f2a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af068);
                        if (iVar10 == 0) {
                            piVar14[5] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[5];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f58;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1de);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f6e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1df);
                            piVar14[5] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f8a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af080);
                        if (iVar10 == 0) {
                            piVar14[6] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[6];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fb8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1ea);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fce;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1eb);
                            piVar14[6] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fea;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af098);
                        if (iVar10 == 0) {
                            piVar14[7] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[7];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7018;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1f6);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a702e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1f7);
                            piVar14[7] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a704a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af0b0);
                        if (iVar10 == 0) {
                            piVar14[8] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[8];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7078;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x202);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a708e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x203);
                            piVar14[8] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70aa;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af0c8);
                        if (iVar10 == 0) {
                            piVar14[9] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[9];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70d8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x20e);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70ee;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x20f);
                            piVar14[9] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)piVar14 + 0x5c) = 0xffffffffffffffff;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7112;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefa0);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7123;
                            iVar5 = func_0x000180229fc0(iVar10, (int64_t)piVar14 + 0x5c);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a712c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                uVar15 = uVar7;
                                goto code_r0x0001801a73ca;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7145;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefb0);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7156;
                            iVar5 = func_0x000180229fc0(iVar10, piVar14 + 0xc);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a715f;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                goto code_r0x0001801a73ca;
                            }
                        }
                        iVar5 = *(int32_t *)(piVar14 + 0xc);
                        if (((iVar5 != 0) && (iVar5 != -1)) && (*(int32_t *)((int64_t)piVar14 + 0x5c) < iVar5)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a717f;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9)
                                         );
                            goto code_r0x0001801a73ca;
                        }
                        *(undefined8 *)((int64_t)piVar14 + 0x5c) = 0xffffffffffffffff;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71a0;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aef80);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71b5;
                            iVar5 = func_0x000180229fc0(iVar10, (int64_t)piVar14 + 0x54);
                            if (iVar5 != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71cc;
                                iVar10 = func_0x00018022ae60(in_RCX, 0x1804aef90);
                                if (iVar10 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71e1;
                                    iVar5 = func_0x000180229fc0(iVar10, piVar14 + 0xb);
                                    if (iVar5 != 0) {
                                        iVar5 = *(int32_t *)(piVar14 + 0xb);
                                        if (((iVar5 != 0) && (iVar5 != -1)) &&
                                           (iVar5 < *(int32_t *)((int64_t)piVar14 + 0x54))) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71ff;
                                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                                          *(int64_t *)(&stack0x00000000 + iVar9));
                                            goto code_r0x0001801a73ca;
                                        }
                                        iVar1 = *(int32_t *)((int64_t)piVar14 + 0x54);
                                        if (((iVar1 == 0) || (iVar1 == -1)) || (iVar1 < 0x305)) {
                                            if (((iVar5 != 0) && (iVar5 != -1)) && (iVar5 < 0x304)) {
                                                *(undefined8 *)((int64_t)piVar14 + 0x54) = 0xffffffffffffffff;
                                                goto code_r0x0001801a724f;
                                            }
                                            if (iVar1 == -1) goto code_r0x0001801a724f;
                                        } else {
                                            *(undefined8 *)((int64_t)piVar14 + 0x54) = 0xffffffffffffffff;
code_r0x0001801a724f:
                                            if (*(int32_t *)((int64_t)piVar14 + 0x5c) == -1) {
                                                uVar6 = 1;
                                                goto code_r0x0001801a73ef;
                                            }
                                        }
                                        uVar15 = 1;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a726b;
                                        func_0x000180229b10();
                                        iVar10 = piVar14[8];
                                        if ((iVar10 == 0) && (iVar10 = piVar14[4], iVar10 == 0)) {
                                            iVar10 = piVar14[2];
                                        }
                                        uVar3 = puVar2[0x8c];
                                        uVar4 = *puVar2;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7293;
                                        iVar11 = func_0x0001802579b0(uVar4, iVar10, uVar3);
                                        if (iVar11 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72a7;
                                            iVar12 = func_0x0001801dd170(iVar11);
                                            if (iVar12 == iVar13) {
                                                iVar13 = piVar14[2];
                                                iVar12 = piVar14[3];
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72c0;
                                                func_0x00018022c870(iVar12, iVar13, 0);
                                                iVar13 = piVar14[2];
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72c9;
                                                iVar5 = func_0x00018022d1b0(iVar13);
                                                if (iVar5 != 0) {
                                                    iVar13 = piVar14[2];
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72da;
                                                    uVar6 = func_0x00018022d1b0(iVar13);
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72e1;
                                                    iVar13 = func_0x00018022cba0(uVar6);
                                                    if (iVar13 != 0) {
                                                        iVar13 = piVar14[4];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[5];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72ff;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        iVar13 = piVar14[8];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[9];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7314;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        iVar13 = piVar14[6];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[7];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7329;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        if (piVar14[6] != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7337;
                                                            uVar7 = func_0x00018022d1b0();
                                                        }
                                                        iVar13 = piVar14[2];
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7346;
                                                        uVar6 = func_0x00018022d1b0(iVar10);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7350;
                                                        uVar8 = func_0x00018022d1b0(iVar13);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a735d;
                                                        func_0x000180256560(uVar8, uVar7, uVar6);
                                                        puVar2[0xd0] = puVar2[0xd0] + 1;
                                                        piVar14 = (int64_t *)0x0;
                                                        goto code_r0x0001801a7366;
                                                    }
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a737d;
                                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                                goto code_r0x0001801a73ca;
                                            }
code_r0x0001801a7366:
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a736e;
                                            func_0x000180257a00(iVar11);
                                        }
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7373;
                                        func_0x0001802299d0();
                                        uVar6 = uVar15;
                                        goto code_r0x0001801a73ef;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7389;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                goto code_r0x0001801a73ca;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7395;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
                        goto code_r0x0001801a73ca;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73a1;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
                goto code_r0x0001801a73ca;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
    }
code_r0x0001801a73ca:
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73dd;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar9), *(int64_t *)((int64_t)aiStackX_8 + iVar9 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar9));
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73ef;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar9 + 0x10));
    uVar6 = uVar15;
code_r0x0001801a73ef:
    if (piVar14 != (int64_t *)0x0) {
        iVar13 = *piVar14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7417;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x283);
        iVar13 = piVar14[2];
        *piVar14 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7430;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x285);
        iVar13 = piVar14[3];
        piVar14[2] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a744a;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x287);
        iVar13 = piVar14[4];
        piVar14[3] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7464;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x289);
        iVar13 = piVar14[5];
        piVar14[4] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a747e;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28b);
        iVar13 = piVar14[6];
        piVar14[5] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7498;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28d);
        iVar13 = piVar14[7];
        piVar14[6] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74b2;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28f);
        iVar13 = piVar14[8];
        piVar14[7] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74cc;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x291);
        iVar13 = piVar14[9];
        piVar14[8] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74e6;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x293);
        piVar14[9] = 0;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801a7402
// Address: 0x1801a7402
// Size: 253 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined4 fcn.1801a6c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 in_RCX;
    int64_t *in_RDX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined4 uVar15;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_30 = 0x1801a6c67;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar2 = (undefined8 *)*in_RDX;
    uVar7 = 0;
    iVar13 = in_RDX[1];
    *(undefined4 *)((int64_t)&arg_40h + iVar9) = 0;
    uVar15 = 0;
    iVar10 = puVar2[0xd1];
    if (iVar10 == puVar2[0xd0]) {
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6cb4;
            iVar10 = func_0x000180224ed0(10, 0x68, 0x1804aeee0, 0x189);
        } else {
            uVar3 = puVar2[0xcf];
            *(undefined4 *)((int64_t)&var_8h + iVar9) = 0x18e;
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6cdb;
            iVar10 = func_0x000180224f60(uVar3, iVar10 + 10, 0x68, 0x1804aeee0);
        }
        if (iVar10 == 0) {
            return 0;
        }
        iVar11 = puVar2[0xd1];
        puVar2[0xcf] = iVar10;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d11;
        fcn.1804986e0(iVar11 * 0x68 + iVar10, 0, 0x410);
        puVar2[0xd1] = puVar2[0xd1] + 10;
    }
    piVar14 = (int64_t *)(puVar2[0xcf] + puVar2[0xd0] * 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d44;
    iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefd0);
    if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 8) != 4)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73c5;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
    } else {
        iVar11 = piVar14[2];
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d70;
        func_0x000180224990(iVar11, 0x1804aeee0, 0x19f);
        uVar3 = *(undefined8 *)(iVar10 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6d86;
        iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1a0);
        piVar14[2] = iVar10;
        uVar6 = uVar7;
        if (iVar10 == 0) goto code_r0x0001801a73ef;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6da2;
        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aeff8);
        if ((iVar10 == 0) || (*(int32_t *)(iVar10 + 8) != 4)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73b9;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
            goto code_r0x0001801a73ca;
        }
        iVar11 = *piVar14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6dcd;
        func_0x000180224990(iVar11, 0x1804aeee0, 0x1a9);
        uVar3 = *(undefined8 *)(iVar10 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6de3;
        iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1aa);
        *piVar14 = iVar10;
        uVar6 = uVar15;
        if (iVar10 == 0) goto code_r0x0001801a73ef;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6dfe;
        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af010);
        if (iVar10 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e14;
            iVar5 = func_0x00018022a610(iVar10, (int64_t)&arg_40h + iVar9);
            if ((iVar5 != 0) && (*(uint32_t *)((int64_t)&arg_40h + iVar9) < 0x10000)) {
                *(int16_t *)(piVar14 + 1) = (int16_t)*(uint32_t *)((int64_t)&arg_40h + iVar9);
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e3e;
                iVar10 = func_0x00018022ae60(in_RCX, 0x1804af028);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e53;
                    iVar5 = func_0x00018022a610(iVar10, piVar14 + 10);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e6a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af040);
                        if (iVar10 == 0) {
                            piVar14[3] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[3];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6e98;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1c6);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6eae;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1c7);
                            piVar14[3] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6eca;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af050);
                        if (iVar10 == 0) {
                            piVar14[4] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[4];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6ef8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1d2);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f0e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1d3);
                            piVar14[4] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f2a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af068);
                        if (iVar10 == 0) {
                            piVar14[5] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[5];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f58;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1de);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f6e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1df);
                            piVar14[5] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6f8a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af080);
                        if (iVar10 == 0) {
                            piVar14[6] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[6];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fb8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1ea);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fce;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1eb);
                            piVar14[6] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a6fea;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af098);
                        if (iVar10 == 0) {
                            piVar14[7] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[7];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7018;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x1f6);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a702e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x1f7);
                            piVar14[7] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a704a;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af0b0);
                        if (iVar10 == 0) {
                            piVar14[8] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[8];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7078;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x202);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a708e;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x203);
                            piVar14[8] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70aa;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804af0c8);
                        if (iVar10 == 0) {
                            piVar14[9] = 0;
                        } else {
                            if (*(int32_t *)(iVar10 + 8) != 4) goto code_r0x0001801a73ef;
                            iVar11 = piVar14[9];
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70d8;
                            func_0x000180224990(iVar11, 0x1804aeee0, 0x20e);
                            uVar3 = *(undefined8 *)(iVar10 + 0x10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a70ee;
                            iVar10 = func_0x0001802231e0(uVar3, 0x1804aeee0, 0x20f);
                            piVar14[9] = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801a73ef;
                        }
                        *(undefined8 *)((int64_t)piVar14 + 0x5c) = 0xffffffffffffffff;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7112;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefa0);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7123;
                            iVar5 = func_0x000180229fc0(iVar10, (int64_t)piVar14 + 0x5c);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a712c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                uVar15 = uVar7;
                                goto code_r0x0001801a73ca;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7145;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aefb0);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7156;
                            iVar5 = func_0x000180229fc0(iVar10, piVar14 + 0xc);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a715f;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                goto code_r0x0001801a73ca;
                            }
                        }
                        iVar5 = *(int32_t *)(piVar14 + 0xc);
                        if (((iVar5 != 0) && (iVar5 != -1)) && (*(int32_t *)((int64_t)piVar14 + 0x5c) < iVar5)) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a717f;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9)
                                         );
                            goto code_r0x0001801a73ca;
                        }
                        *(undefined8 *)((int64_t)piVar14 + 0x5c) = 0xffffffffffffffff;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71a0;
                        iVar10 = func_0x00018022ae60(in_RCX, 0x1804aef80);
                        if (iVar10 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71b5;
                            iVar5 = func_0x000180229fc0(iVar10, (int64_t)piVar14 + 0x54);
                            if (iVar5 != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71cc;
                                iVar10 = func_0x00018022ae60(in_RCX, 0x1804aef90);
                                if (iVar10 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71e1;
                                    iVar5 = func_0x000180229fc0(iVar10, piVar14 + 0xb);
                                    if (iVar5 != 0) {
                                        iVar5 = *(int32_t *)(piVar14 + 0xb);
                                        if (((iVar5 != 0) && (iVar5 != -1)) &&
                                           (iVar5 < *(int32_t *)((int64_t)piVar14 + 0x54))) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a71ff;
                                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                                          *(int64_t *)(&stack0x00000000 + iVar9));
                                            goto code_r0x0001801a73ca;
                                        }
                                        iVar1 = *(int32_t *)((int64_t)piVar14 + 0x54);
                                        if (((iVar1 == 0) || (iVar1 == -1)) || (iVar1 < 0x305)) {
                                            if (((iVar5 != 0) && (iVar5 != -1)) && (iVar5 < 0x304)) {
                                                *(undefined8 *)((int64_t)piVar14 + 0x54) = 0xffffffffffffffff;
                                                goto code_r0x0001801a724f;
                                            }
                                            if (iVar1 == -1) goto code_r0x0001801a724f;
                                        } else {
                                            *(undefined8 *)((int64_t)piVar14 + 0x54) = 0xffffffffffffffff;
code_r0x0001801a724f:
                                            if (*(int32_t *)((int64_t)piVar14 + 0x5c) == -1) {
                                                uVar6 = 1;
                                                goto code_r0x0001801a73ef;
                                            }
                                        }
                                        uVar15 = 1;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a726b;
                                        func_0x000180229b10();
                                        iVar10 = piVar14[8];
                                        if ((iVar10 == 0) && (iVar10 = piVar14[4], iVar10 == 0)) {
                                            iVar10 = piVar14[2];
                                        }
                                        uVar3 = puVar2[0x8c];
                                        uVar4 = *puVar2;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7293;
                                        iVar11 = func_0x0001802579b0(uVar4, iVar10, uVar3);
                                        if (iVar11 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72a7;
                                            iVar12 = func_0x0001801dd170(iVar11);
                                            if (iVar12 == iVar13) {
                                                iVar13 = piVar14[2];
                                                iVar12 = piVar14[3];
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72c0;
                                                func_0x00018022c870(iVar12, iVar13, 0);
                                                iVar13 = piVar14[2];
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72c9;
                                                iVar5 = func_0x00018022d1b0(iVar13);
                                                if (iVar5 != 0) {
                                                    iVar13 = piVar14[2];
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72da;
                                                    uVar6 = func_0x00018022d1b0(iVar13);
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72e1;
                                                    iVar13 = func_0x00018022cba0(uVar6);
                                                    if (iVar13 != 0) {
                                                        iVar13 = piVar14[4];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[5];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a72ff;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        iVar13 = piVar14[8];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[9];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7314;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        iVar13 = piVar14[6];
                                                        if (iVar13 != 0) {
                                                            iVar12 = piVar14[7];
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7329;
                                                            func_0x00018022c870(iVar12, iVar13, 0);
                                                        }
                                                        if (piVar14[6] != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7337;
                                                            uVar7 = func_0x00018022d1b0();
                                                        }
                                                        iVar13 = piVar14[2];
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7346;
                                                        uVar6 = func_0x00018022d1b0(iVar10);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7350;
                                                        uVar8 = func_0x00018022d1b0(iVar13);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a735d;
                                                        func_0x000180256560(uVar8, uVar7, uVar6);
                                                        puVar2[0xd0] = puVar2[0xd0] + 1;
                                                        piVar14 = (int64_t *)0x0;
                                                        goto code_r0x0001801a7366;
                                                    }
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a737d;
                                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                                goto code_r0x0001801a73ca;
                                            }
code_r0x0001801a7366:
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a736e;
                                            func_0x000180257a00(iVar11);
                                        }
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7373;
                                        func_0x0001802299d0();
                                        uVar6 = uVar15;
                                        goto code_r0x0001801a73ef;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7389;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)(&stack0x00000000 + iVar9));
                                goto code_r0x0001801a73ca;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7395;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
                        goto code_r0x0001801a73ca;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73a1;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
                goto code_r0x0001801a73ca;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9));
    }
code_r0x0001801a73ca:
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73dd;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar9), *(int64_t *)((int64_t)aiStackX_8 + iVar9 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar9));
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a73ef;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar9 + 0x10));
    uVar6 = uVar15;
code_r0x0001801a73ef:
    if (piVar14 != (int64_t *)0x0) {
        iVar13 = *piVar14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7417;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x283);
        iVar13 = piVar14[2];
        *piVar14 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7430;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x285);
        iVar13 = piVar14[3];
        piVar14[2] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a744a;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x287);
        iVar13 = piVar14[4];
        piVar14[3] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7464;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x289);
        iVar13 = piVar14[5];
        piVar14[4] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a747e;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28b);
        iVar13 = piVar14[6];
        piVar14[5] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a7498;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28d);
        iVar13 = piVar14[7];
        piVar14[6] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74b2;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x28f);
        iVar13 = piVar14[8];
        piVar14[7] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74cc;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x291);
        iVar13 = piVar14[9];
        piVar14[8] = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1801a74e6;
        func_0x000180224990(iVar13, 0x1804aeee0, 0x293);
        piVar14[9] = 0;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801a7500
// Address: 0x1801a7500
// Size: 270 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f8h because it doesn't fit into ProtoModel

undefined8 fcn.1801a7500(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar9;
    undefined8 in_R8;
    undefined8 in_R9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a7512;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar7 = 0;
    if (*(int32_t *)(in_RDX + 0x14) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a7530;
        uVar7 = func_0x00018022ccf0();
    }
    uVar2 = puVar1[0x8c];
    uVar3 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a7545;
    iVar5 = func_0x00018022e980(in_R9, uVar3, uVar7, uVar2);
    if (0 < iVar5) {
        if (*(int64_t *)(in_RCX + 1000) == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a7579;
        iVar5 = func_0x000180237500(in_R8, (int64_t)&arg_40h + iVar6, (int64_t)&arg_38h + iVar6, 0);
        if (iVar5 != 0) {
            uVar10 = 0;
            if (*(uint64_t *)(in_RCX + 0x3f8) != 0) {
                uVar4 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x640);
                do {
                    uVar9 = 0;
                    if (uVar4 != 0) {
                        iVar8 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x650);
                        do {
                            if (*(int16_t *)(iVar8 + 0x10) == *(int16_t *)(*(int64_t *)(in_RCX + 1000) + uVar10 * 2)) {
                                if (((*(int32_t *)(iVar8 + 0x2c) != 0) &&
                                    (*(int32_t *)((int64_t)&arg_40h + iVar6) == *(int32_t *)(iVar8 + 0x14))) &&
                                   (*(int32_t *)((int64_t)&arg_38h + iVar6) == *(int32_t *)(iVar8 + 0x1c))) {
                                    return 1;
                                }
                                break;
                            }
                            iVar8 = iVar8 + 0x48;
                            uVar9 = uVar9 + 1;
                        } while (uVar9 < uVar4);
                    }
                    uVar10 = uVar10 + 1;
                } while (uVar10 < *(uint64_t *)(in_RCX + 0x3f8));
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a7610
// Address: 0x1801a7610
// Size: 52 bytes
// ============================================================
void fcn.1801a7610(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a761a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801a763f;
    fcn.18025b1c0();
    return;
}

// ============================================================
// Function: FUN_1801a7650
// Address: 0x1801a7650
// Size: 57 bytes
// ============================================================
undefined8 fcn.1801a7650(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a765a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_RCX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801a767f;
    fcn.18025b1c0();
    return 1;
}

// ============================================================
// Function: FUN_1801a7690
// Address: 0x1801a7690
// Size: 72 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f8h because it doesn't fit into ProtoModel

uint64_t fcn.1801a7690(int64_t placeholder_0, int64_t arg2, int64_t placeholder_2, undefined8 placeholder_3,
                      int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined8 unaff_R14;
    uint64_t uVar12;
    bool bVar13;
    int64_t iStackX_8;
    int64_t var_10h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801a76a9;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = *(undefined8 *)(placeholder_0 + 8);
    uVar7 = 0;
    iVar4 = -1;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = uVar10;
    uVar12 = uVar7;
    if (*(int64_t *)(placeholder_0 + 0x1588) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
        do {
            uVar7 = *(uint64_t *)(*(int64_t *)(placeholder_0 + 0x1580) + uVar12 * 8);
            if ((((*(int32_t *)(uVar7 + 0x14) != 0x40) && (*(int32_t *)(uVar7 + 0x14) != 0x2a3)) &&
                (*(int32_t *)(uVar7 + 0x1c) != 0x74)) && (*(int32_t *)(uVar7 + 0x1c) != 6)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7732;
                iVar3 = func_0x0001801adb40(placeholder_0, uVar7);
                if (iVar3 != 0) {
                    if (*(int32_t *)(uVar7 + 0x14) != 0) {
                        uVar1 = *(undefined4 *)(uVar7 + 0x18);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a774b;
                        iVar8 = func_0x0001801a08e0(uVar10, uVar1);
                        if (iVar8 == 0) goto code_r0x0001801a7913;
                    }
                    if (placeholder_2 == 0) {
                        iVar3 = *(int32_t *)(uVar7 + 0x20);
                        if ((iVar3 < 0) || (*(int32_t *)(placeholder_0 + 0x118) <= iVar3)) goto code_r0x0001801a7913;
                        iVar11 = 0x15a8;
                        iVar8 = 0x15a0;
                        if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
                            iVar8 = 0x1590;
                            iVar11 = 0x1598;
                        }
                        iVar8 = *(int64_t *)(iVar8 + placeholder_0);
                        if (iVar8 == 0) {
                            piVar9 = (int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20);
code_r0x0001801a77b3:
                            iVar8 = (int64_t)iVar3 * 0x28;
                            if ((*(int64_t *)(*piVar9 + iVar8) == 0) || (*(int64_t *)(*piVar9 + 8 + iVar8) == 0)) {
                                bVar13 = false;
                            } else {
                                bVar13 = true;
                            }
                        } else {
                            uVar10 = *(undefined8 *)(iVar11 + placeholder_0);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a77da;
                            iVar8 = func_0x000180498a80(iVar8, 2, uVar10);
                            piVar9 = (int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20);
                            if (iVar8 == 0) goto code_r0x0001801a77b3;
                            bVar13 = *(int64_t *)(*piVar9 + 8 + (int64_t)iVar3 * 0x28) != 0;
                        }
                        if (bVar13) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7837;
                            iVar3 = fcn.1801a7500(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                                  *(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6));
                            if (iVar3 != 0) {
                                uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
                                iVar8 = *(int64_t *)
                                         (*(int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20) + 8 +
                                         (int64_t)*(int32_t *)(uVar7 + 0x20) * 0x28);
code_r0x0001801a7899:
                                if (*(int32_t *)(uVar7 + 0x1c) == 0x198) {
                                    if (iVar4 == -1) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78b1;
                                        iVar4 = func_0x0001801a86f0(iVar8);
                                    }
                                    if ((*(int32_t *)(uVar7 + 0x28) == 0) || (iVar4 == *(int32_t *)(uVar7 + 0x28)))
                                    break;
                                } else {
                                    if (*(int32_t *)(uVar7 + 0x1c) != 0x390) break;
                                    if ((iVar8 != 0) && (*(int32_t *)(uVar7 + 0x14) != 0)) {
                                        uVar1 = *(undefined4 *)(uVar7 + 0x18);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78df;
                                        iVar11 = func_0x0001801a08e0(uVar10, uVar1);
                                        if (iVar11 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78ef;
                                            iVar3 = func_0x00018020f800(iVar11);
                                            if (0 < iVar3) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78fb;
                                                iVar3 = func_0x00018020f800(iVar11);
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a790a;
                                                iVar5 = func_0x00018022fbd0(iVar8);
                                                if (iVar3 * 2 + 2 <= iVar5) break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        uVar2 = *(undefined8 *)(placeholder_0 + 8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a786b;
                        iVar8 = func_0x0001801a2080(placeholder_2, (int64_t)&arg_40h + iVar6, uVar2);
                        if ((iVar8 != 0) && (*(int32_t *)((int64_t)&arg_40h + iVar6) == *(int32_t *)(uVar7 + 0x20))) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7892;
                            iVar3 = fcn.1801a7500(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                                  *(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6));
                            iVar8 = placeholder_2;
                            if (iVar3 != 0) goto code_r0x0001801a7899;
                        }
                    }
                }
            }
code_r0x0001801a7913:
            uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(placeholder_0 + 0x1588));
    }
    if (uVar12 == *(uint64_t *)(placeholder_0 + 0x1588)) {
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801a76d8
// Address: 0x1801a76d8
// Size: 605 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f8h because it doesn't fit into ProtoModel

uint64_t fcn.1801a7690(int64_t placeholder_0, int64_t arg2, int64_t placeholder_2, undefined8 placeholder_3,
                      int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined8 unaff_R14;
    uint64_t uVar12;
    bool bVar13;
    int64_t iStackX_8;
    int64_t var_10h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801a76a9;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = *(undefined8 *)(placeholder_0 + 8);
    uVar7 = 0;
    iVar4 = -1;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = uVar10;
    uVar12 = uVar7;
    if (*(int64_t *)(placeholder_0 + 0x1588) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
        do {
            uVar7 = *(uint64_t *)(*(int64_t *)(placeholder_0 + 0x1580) + uVar12 * 8);
            if ((((*(int32_t *)(uVar7 + 0x14) != 0x40) && (*(int32_t *)(uVar7 + 0x14) != 0x2a3)) &&
                (*(int32_t *)(uVar7 + 0x1c) != 0x74)) && (*(int32_t *)(uVar7 + 0x1c) != 6)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7732;
                iVar3 = func_0x0001801adb40(placeholder_0, uVar7);
                if (iVar3 != 0) {
                    if (*(int32_t *)(uVar7 + 0x14) != 0) {
                        uVar1 = *(undefined4 *)(uVar7 + 0x18);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a774b;
                        iVar8 = func_0x0001801a08e0(uVar10, uVar1);
                        if (iVar8 == 0) goto code_r0x0001801a7913;
                    }
                    if (placeholder_2 == 0) {
                        iVar3 = *(int32_t *)(uVar7 + 0x20);
                        if ((iVar3 < 0) || (*(int32_t *)(placeholder_0 + 0x118) <= iVar3)) goto code_r0x0001801a7913;
                        iVar11 = 0x15a8;
                        iVar8 = 0x15a0;
                        if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
                            iVar8 = 0x1590;
                            iVar11 = 0x1598;
                        }
                        iVar8 = *(int64_t *)(iVar8 + placeholder_0);
                        if (iVar8 == 0) {
                            piVar9 = (int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20);
code_r0x0001801a77b3:
                            iVar8 = (int64_t)iVar3 * 0x28;
                            if ((*(int64_t *)(*piVar9 + iVar8) == 0) || (*(int64_t *)(*piVar9 + 8 + iVar8) == 0)) {
                                bVar13 = false;
                            } else {
                                bVar13 = true;
                            }
                        } else {
                            uVar10 = *(undefined8 *)(iVar11 + placeholder_0);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a77da;
                            iVar8 = func_0x000180498a80(iVar8, 2, uVar10);
                            piVar9 = (int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20);
                            if (iVar8 == 0) goto code_r0x0001801a77b3;
                            bVar13 = *(int64_t *)(*piVar9 + 8 + (int64_t)iVar3 * 0x28) != 0;
                        }
                        if (bVar13) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7837;
                            iVar3 = fcn.1801a7500(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                                  *(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6));
                            if (iVar3 != 0) {
                                uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
                                iVar8 = *(int64_t *)
                                         (*(int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20) + 8 +
                                         (int64_t)*(int32_t *)(uVar7 + 0x20) * 0x28);
code_r0x0001801a7899:
                                if (*(int32_t *)(uVar7 + 0x1c) == 0x198) {
                                    if (iVar4 == -1) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78b1;
                                        iVar4 = func_0x0001801a86f0(iVar8);
                                    }
                                    if ((*(int32_t *)(uVar7 + 0x28) == 0) || (iVar4 == *(int32_t *)(uVar7 + 0x28)))
                                    break;
                                } else {
                                    if (*(int32_t *)(uVar7 + 0x1c) != 0x390) break;
                                    if ((iVar8 != 0) && (*(int32_t *)(uVar7 + 0x14) != 0)) {
                                        uVar1 = *(undefined4 *)(uVar7 + 0x18);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78df;
                                        iVar11 = func_0x0001801a08e0(uVar10, uVar1);
                                        if (iVar11 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78ef;
                                            iVar3 = func_0x00018020f800(iVar11);
                                            if (0 < iVar3) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78fb;
                                                iVar3 = func_0x00018020f800(iVar11);
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a790a;
                                                iVar5 = func_0x00018022fbd0(iVar8);
                                                if (iVar3 * 2 + 2 <= iVar5) break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        uVar2 = *(undefined8 *)(placeholder_0 + 8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a786b;
                        iVar8 = func_0x0001801a2080(placeholder_2, (int64_t)&arg_40h + iVar6, uVar2);
                        if ((iVar8 != 0) && (*(int32_t *)((int64_t)&arg_40h + iVar6) == *(int32_t *)(uVar7 + 0x20))) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7892;
                            iVar3 = fcn.1801a7500(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                                  *(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6));
                            iVar8 = placeholder_2;
                            if (iVar3 != 0) goto code_r0x0001801a7899;
                        }
                    }
                }
            }
code_r0x0001801a7913:
            uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(placeholder_0 + 0x1588));
    }
    if (uVar12 == *(uint64_t *)(placeholder_0 + 0x1588)) {
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801a7935
// Address: 0x1801a7935
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3f8h because it doesn't fit into ProtoModel

uint64_t fcn.1801a7690(int64_t placeholder_0, int64_t arg2, int64_t placeholder_2, undefined8 placeholder_3,
                      int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined8 unaff_R14;
    uint64_t uVar12;
    bool bVar13;
    int64_t iStackX_8;
    int64_t var_10h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801a76a9;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = *(undefined8 *)(placeholder_0 + 8);
    uVar7 = 0;
    iVar4 = -1;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = uVar10;
    uVar12 = uVar7;
    if (*(int64_t *)(placeholder_0 + 0x1588) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
        do {
            uVar7 = *(uint64_t *)(*(int64_t *)(placeholder_0 + 0x1580) + uVar12 * 8);
            if ((((*(int32_t *)(uVar7 + 0x14) != 0x40) && (*(int32_t *)(uVar7 + 0x14) != 0x2a3)) &&
                (*(int32_t *)(uVar7 + 0x1c) != 0x74)) && (*(int32_t *)(uVar7 + 0x1c) != 6)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7732;
                iVar3 = func_0x0001801adb40(placeholder_0, uVar7);
                if (iVar3 != 0) {
                    if (*(int32_t *)(uVar7 + 0x14) != 0) {
                        uVar1 = *(undefined4 *)(uVar7 + 0x18);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a774b;
                        iVar8 = func_0x0001801a08e0(uVar10, uVar1);
                        if (iVar8 == 0) goto code_r0x0001801a7913;
                    }
                    if (placeholder_2 == 0) {
                        iVar3 = *(int32_t *)(uVar7 + 0x20);
                        if ((iVar3 < 0) || (*(int32_t *)(placeholder_0 + 0x118) <= iVar3)) goto code_r0x0001801a7913;
                        iVar11 = 0x15a8;
                        iVar8 = 0x15a0;
                        if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
                            iVar8 = 0x1590;
                            iVar11 = 0x1598;
                        }
                        iVar8 = *(int64_t *)(iVar8 + placeholder_0);
                        if (iVar8 == 0) {
                            piVar9 = (int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20);
code_r0x0001801a77b3:
                            iVar8 = (int64_t)iVar3 * 0x28;
                            if ((*(int64_t *)(*piVar9 + iVar8) == 0) || (*(int64_t *)(*piVar9 + 8 + iVar8) == 0)) {
                                bVar13 = false;
                            } else {
                                bVar13 = true;
                            }
                        } else {
                            uVar10 = *(undefined8 *)(iVar11 + placeholder_0);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a77da;
                            iVar8 = func_0x000180498a80(iVar8, 2, uVar10);
                            piVar9 = (int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20);
                            if (iVar8 == 0) goto code_r0x0001801a77b3;
                            bVar13 = *(int64_t *)(*piVar9 + 8 + (int64_t)iVar3 * 0x28) != 0;
                        }
                        if (bVar13) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7837;
                            iVar3 = fcn.1801a7500(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                                  *(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6));
                            if (iVar3 != 0) {
                                uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
                                iVar8 = *(int64_t *)
                                         (*(int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20) + 8 +
                                         (int64_t)*(int32_t *)(uVar7 + 0x20) * 0x28);
code_r0x0001801a7899:
                                if (*(int32_t *)(uVar7 + 0x1c) == 0x198) {
                                    if (iVar4 == -1) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78b1;
                                        iVar4 = func_0x0001801a86f0(iVar8);
                                    }
                                    if ((*(int32_t *)(uVar7 + 0x28) == 0) || (iVar4 == *(int32_t *)(uVar7 + 0x28)))
                                    break;
                                } else {
                                    if (*(int32_t *)(uVar7 + 0x1c) != 0x390) break;
                                    if ((iVar8 != 0) && (*(int32_t *)(uVar7 + 0x14) != 0)) {
                                        uVar1 = *(undefined4 *)(uVar7 + 0x18);
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78df;
                                        iVar11 = func_0x0001801a08e0(uVar10, uVar1);
                                        if (iVar11 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78ef;
                                            iVar3 = func_0x00018020f800(iVar11);
                                            if (0 < iVar3) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a78fb;
                                                iVar3 = func_0x00018020f800(iVar11);
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a790a;
                                                iVar5 = func_0x00018022fbd0(iVar8);
                                                if (iVar3 * 2 + 2 <= iVar5) break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        uVar2 = *(undefined8 *)(placeholder_0 + 8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a786b;
                        iVar8 = func_0x0001801a2080(placeholder_2, (int64_t)&arg_40h + iVar6, uVar2);
                        if ((iVar8 != 0) && (*(int32_t *)((int64_t)&arg_40h + iVar6) == *(int32_t *)(uVar7 + 0x20))) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801a7892;
                            iVar3 = fcn.1801a7500(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                                  *(int64_t *)(&stack0x00000000 + iVar6), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar6));
                            iVar8 = placeholder_2;
                            if (iVar3 != 0) goto code_r0x0001801a7899;
                        }
                    }
                }
            }
code_r0x0001801a7913:
            uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(placeholder_0 + 0x1588));
    }
    if (uVar12 == *(uint64_t *)(placeholder_0 + 0x1588)) {
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801a7960
// Address: 0x1801a7960
// Size: 35 bytes
// ============================================================
void fcn.1801a7960(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801a7990
// Address: 0x1801a7990
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801a7990(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 *in_RCX;
    int32_t *in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a79a5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a79c0;
    iVar1 = fcn.180223670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 == 0) {
        *in_RCX = 6;
        return;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a79e9;
    iVar1 = fcn.180223670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a7a00;
        iVar1 = fcn.180223670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a7a13;
            iVar1 = fcn.180223670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            if (iVar1 == 0) {
                *in_RCX = 0x74;
                return;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a7a3c;
            iVar1 = fcn.180223670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a7a5e;
                iVar1 = fcn.18022d080(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
                *in_RDX = iVar1;
                if (iVar1 != 0) {
                    return;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a7a6c;
                iVar1 = fcn.18022ca40(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                      *(int64_t *)(&stack0x00000068 + iVar2));
                *in_RDX = iVar1;
                return;
            }
            *in_RCX = 0x198;
            return;
        }
    }
    *in_RCX = 0x390;
    return;
}

// ============================================================
// Function: FUN_1801a7aa0
// Address: 0x1801a7aa0
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801a7aa0(int64_t arg_58h, int64_t arg_c0h)
{
    undefined2 *puVar1;
    char cVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    char *pcVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    char *pcVar11;
    int64_t iVar12;
    undefined *puVar13;
    undefined8 uVar14;
    int16_t *piVar15;
    int64_t *piVar16;
    char *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar17;
    uint64_t uVar18;
    int16_t iVar19;
    int64_t *in_R8;
    uint64_t uVar20;
    undefined8 *puVar21;
    undefined8 unaff_R14;
    uint64_t uVar22;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801a7ab5;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_58h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10)
    ;
    uVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 0;
    uVar22 = in_RDX & 0xffffffff;
    *(undefined4 *)((int64_t)&var_8h + iVar10) = 0;
    *(undefined4 *)(&stack0x00000000 + iVar10) = 0;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
    if (((in_R8 == (int64_t *)0x0) || (in_RCX == (char *)0x0)) || ((int32_t)in_RDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8062;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a807a;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&var_18h + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a808c;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar10));
        goto code_r0x0001801a7cfa;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar10) = unaff_R14;
    uVar20 = uVar18;
    uVar17 = uVar18;
    while( true ) {
        iVar8 = (int32_t)uVar17;
        iVar9 = (int32_t)uVar22;
        if (iVar9 < 1) break;
        cVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b2a;
        pcVar11 = (char *)func_0x00018045b928(0x1804ae018, (int32_t)cVar2);
        pcVar6 = *(char **)0x18069c688;
        if (pcVar11 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b47;
            iVar7 = func_0x0001802237e0(*(char **)0x18069c688, in_RCX, 1);
            pcVar11 = pcVar6;
            if (iVar7 != 0) goto code_r0x0001801a7d22;
        }
        cVar2 = *pcVar11;
        if (cVar2 == '*') {
            if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
        } else if (cVar2 == '-') {
            if (iVar8 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)(&stack0x00000000 + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar17 = 1;
        } else {
            if ((cVar2 == '/') || (cVar2 == ':')) goto code_r0x0001801a7cfa;
            if (cVar2 != '?') {
                puVar21 = (undefined8 *)0x1804adff8;
                uVar22 = uVar18;
                goto code_r0x0001801a7bd0;
            }
            if ((int32_t)uVar20 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar20 = 1;
        }
    }
    if (iVar9 == 0) goto code_r0x0001801a7cfa;
    goto code_r0x0001801a7d22;
code_r0x0001801a7bd0:
    do {
        uVar3 = *puVar21;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bdc;
        iVar12 = func_0x000180498cd0(uVar3);
        if (iVar9 == iVar12) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bf2;
            iVar8 = func_0x0001802237e0(uVar3, in_RCX, (int64_t)iVar9);
            if (iVar8 == 0) {
                if ((*(int32_t *)((int64_t)&var_8h + iVar10 + 4) == 0) && (*(int32_t *)(&stack0x00000000 + iVar10) == 0)
                   ) {
                    iVar12 = uVar22 * 0x10;
                    uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c45;
                    func_0x000180498cd0(uVar3);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c5b;
                    puVar13 = (undefined *)
                              fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    if (puVar13 != (undefined *)0x0) {
                        if ((*(int32_t *)((int64_t)&var_8h + iVar10) != 0) && (**(char **)(iVar12 + 0x1804ae000) != '*')
                           ) {
                            *puVar13 = 0x2a;
                            *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 1;
                        }
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c88;
                        uVar14 = func_0x000180498cd0(uVar3);
                        iVar4 = *(int64_t *)((int64_t)aiStackX_8 + iVar10);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c9d;
                        func_0x000180498030(puVar13 + iVar4, uVar3, uVar14);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7ca6;
                        iVar12 = func_0x000180498cd0(uVar3);
                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar10) = in_R8;
                        puVar13[iVar4 + iVar12] = 0;
                        *(undefined4 *)(in_R8 + 0xb) = 1;
                        in_R8[10] = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cd2;
                        func_0x00018024a850(puVar13, 0x2f, 1, 0x1801ade20);
                        in_R8[10] = 1;
                        *(undefined4 *)(in_R8 + 0xb) = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cf0;
                        func_0x000180224990(puVar13, 0x1804aeee0, 0x555);
                    }
                }
                goto code_r0x0001801a7cfa;
            }
        }
        uVar22 = uVar22 + 1;
        puVar21 = puVar21 + 2;
    } while (uVar22 < 2);
    iVar8 = *(int32_t *)(&stack0x00000000 + iVar10);
    *(undefined4 *)((int64_t)&var_8h + iVar10) = *(undefined4 *)((int64_t)&var_8h + iVar10);
code_r0x0001801a7d22:
    iVar12 = in_R8[1];
    if (in_R8[2] == iVar12) {
        iVar4 = in_R8[3];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x56f;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d56;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[1] = in_R8[1] + 0x20;
        in_R8[3] = iVar12;
    }
    iVar12 = in_R8[7];
    if (in_R8[8] == iVar12) {
        iVar4 = in_R8[9];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x57c;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d90;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[7] = in_R8[7] + 0x20;
        in_R8[9] = iVar12;
    }
    if (iVar9 < 0x40) {
        uVar22 = (uint64_t)iVar9;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7dc1;
        func_0x000180498030((int64_t)&var_18h + iVar10, in_RCX, uVar22);
        if (0x3f < uVar22) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8098;
            func_0x000180459e6c();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar12 = *in_R8;
        *(undefined *)((int64_t)&var_18h + uVar22 + iVar10) = 0;
        uVar22 = uVar18;
        uVar20 = uVar18;
        if (*(int64_t *)(iVar12 + 0x668) != 0) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e05;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) {
code_r0x0001801a7e35:
                    iVar19 = *(int16_t *)(*(int64_t *)(iVar12 + 0x660) + 0x1c + uVar20 * 0x38);
                    if (iVar19 != 0) goto code_r0x0001801a7e98;
                    break;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e1f;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) goto code_r0x0001801a7e35;
                uVar20 = uVar20 + 1;
            } while (uVar20 < *(uint64_t *)(iVar12 + 0x668));
        }
        do {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e6d;
            iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
            if (iVar9 == 0) {
                iVar19 = *(int16_t *)(uVar22 * 0x10 + 0x1804ae028);
                if (iVar19 != 0) goto code_r0x0001801a7e98;
                break;
            }
            uVar22 = uVar22 + 1;
        } while (uVar22 < 7);
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7e98:
    uVar22 = *(uint64_t *)(*in_R8 + 0x668);
    if (uVar22 != 0) {
        piVar15 = (int16_t *)(*(int64_t *)(*in_R8 + 0x660) + 0x1c);
        uVar20 = uVar18;
        do {
            if (*piVar15 == iVar19) {
                uVar22 = in_R8[2];
                if (iVar8 == 0) {
                    if (uVar22 == 0) goto code_r0x0001801a8016;
                    piVar15 = (int16_t *)in_R8[3];
                    goto code_r0x0001801a8000;
                }
                if (uVar22 != 0) {
                    piVar15 = (int16_t *)in_R8[3];
                    uVar20 = uVar18;
                    goto code_r0x0001801a7ef0;
                }
                break;
            }
            uVar20 = uVar20 + 1;
            piVar15 = piVar15 + 0x1c;
        } while (uVar20 < uVar22);
    }
    goto code_r0x0001801a7cfa;
    while( true ) {
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar18) break;
code_r0x0001801a8000:
        if (*piVar15 == iVar19) goto code_r0x0001801a7cfa;
    }
code_r0x0001801a8016:
    *(int16_t *)(in_R8[3] + uVar22 * 2) = iVar19;
    in_R8[2] = in_R8[2] + 1;
    piVar16 = (int64_t *)(in_R8[6] + in_R8[5] * 8);
    *piVar16 = *piVar16 + 1;
    if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) {
        *(int16_t *)(in_R8[9] + in_R8[8] * 2) = iVar19;
        in_R8[8] = in_R8[8] + 1;
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7ef0:
    if (*piVar15 != iVar19) {
        uVar20 = uVar20 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar20) goto code_r0x0001801a7cfa;
        goto code_r0x0001801a7ef0;
    }
    uVar17 = uVar20;
    if (uVar20 < uVar22 - 1) {
        do {
            puVar1 = (undefined2 *)(in_R8[3] + uVar17 * 2);
            uVar17 = uVar17 + 1;
            *puVar1 = puVar1[1];
            uVar22 = in_R8[2];
        } while (uVar17 < uVar22 - 1);
    }
    in_R8[2] = uVar22 - 1;
    uVar22 = uVar18;
    if (in_R8[5] == 0) {
code_r0x0001801a7f77:
        piVar16 = (int64_t *)(in_R8[6] + uVar22 * 8);
        *piVar16 = *piVar16 + -1;
    } else {
        piVar16 = (int64_t *)in_R8[6];
        uVar17 = uVar18;
        while( true ) {
            uVar17 = uVar17 + *piVar16;
            if (uVar20 < uVar17) break;
            uVar22 = uVar22 + 1;
            piVar16 = piVar16 + 1;
            if ((uint64_t)in_R8[5] <= uVar22) goto code_r0x0001801a7f77;
        }
        *(int64_t *)(in_R8[6] + uVar22 * 8) = *piVar16 + -1;
    }
    uVar22 = in_R8[8];
    if (uVar22 == 0) goto code_r0x0001801a7cfa;
    piVar15 = (int16_t *)in_R8[9];
    do {
        if (*piVar15 == iVar19) {
            if (uVar18 < uVar22 - 1) {
                do {
                    puVar1 = (undefined2 *)(in_R8[9] + uVar18 * 2);
                    uVar18 = uVar18 + 1;
                    *puVar1 = puVar1[1];
                    uVar22 = in_R8[8];
                } while (uVar18 < uVar22 - 1);
            }
            in_R8[8] = uVar22 - 1;
            break;
        }
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
    } while (uVar18 < uVar22);
code_r0x0001801a7cfa:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d0a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801a7b0b
// Address: 0x1801a7b0b
// Size: 495 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801a7aa0(int64_t arg_58h, int64_t arg_c0h)
{
    undefined2 *puVar1;
    char cVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    char *pcVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    char *pcVar11;
    int64_t iVar12;
    undefined *puVar13;
    undefined8 uVar14;
    int16_t *piVar15;
    int64_t *piVar16;
    char *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar17;
    uint64_t uVar18;
    int16_t iVar19;
    int64_t *in_R8;
    uint64_t uVar20;
    undefined8 *puVar21;
    undefined8 unaff_R14;
    uint64_t uVar22;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801a7ab5;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_58h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10)
    ;
    uVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 0;
    uVar22 = in_RDX & 0xffffffff;
    *(undefined4 *)((int64_t)&var_8h + iVar10) = 0;
    *(undefined4 *)(&stack0x00000000 + iVar10) = 0;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
    if (((in_R8 == (int64_t *)0x0) || (in_RCX == (char *)0x0)) || ((int32_t)in_RDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8062;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a807a;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&var_18h + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a808c;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar10));
        goto code_r0x0001801a7cfa;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar10) = unaff_R14;
    uVar20 = uVar18;
    uVar17 = uVar18;
    while( true ) {
        iVar8 = (int32_t)uVar17;
        iVar9 = (int32_t)uVar22;
        if (iVar9 < 1) break;
        cVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b2a;
        pcVar11 = (char *)func_0x00018045b928(0x1804ae018, (int32_t)cVar2);
        pcVar6 = *(char **)0x18069c688;
        if (pcVar11 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b47;
            iVar7 = func_0x0001802237e0(*(char **)0x18069c688, in_RCX, 1);
            pcVar11 = pcVar6;
            if (iVar7 != 0) goto code_r0x0001801a7d22;
        }
        cVar2 = *pcVar11;
        if (cVar2 == '*') {
            if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
        } else if (cVar2 == '-') {
            if (iVar8 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)(&stack0x00000000 + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar17 = 1;
        } else {
            if ((cVar2 == '/') || (cVar2 == ':')) goto code_r0x0001801a7cfa;
            if (cVar2 != '?') {
                puVar21 = (undefined8 *)0x1804adff8;
                uVar22 = uVar18;
                goto code_r0x0001801a7bd0;
            }
            if ((int32_t)uVar20 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar20 = 1;
        }
    }
    if (iVar9 == 0) goto code_r0x0001801a7cfa;
    goto code_r0x0001801a7d22;
code_r0x0001801a7bd0:
    do {
        uVar3 = *puVar21;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bdc;
        iVar12 = func_0x000180498cd0(uVar3);
        if (iVar9 == iVar12) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bf2;
            iVar8 = func_0x0001802237e0(uVar3, in_RCX, (int64_t)iVar9);
            if (iVar8 == 0) {
                if ((*(int32_t *)((int64_t)&var_8h + iVar10 + 4) == 0) && (*(int32_t *)(&stack0x00000000 + iVar10) == 0)
                   ) {
                    iVar12 = uVar22 * 0x10;
                    uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c45;
                    func_0x000180498cd0(uVar3);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c5b;
                    puVar13 = (undefined *)
                              fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    if (puVar13 != (undefined *)0x0) {
                        if ((*(int32_t *)((int64_t)&var_8h + iVar10) != 0) && (**(char **)(iVar12 + 0x1804ae000) != '*')
                           ) {
                            *puVar13 = 0x2a;
                            *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 1;
                        }
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c88;
                        uVar14 = func_0x000180498cd0(uVar3);
                        iVar4 = *(int64_t *)((int64_t)aiStackX_8 + iVar10);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c9d;
                        func_0x000180498030(puVar13 + iVar4, uVar3, uVar14);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7ca6;
                        iVar12 = func_0x000180498cd0(uVar3);
                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar10) = in_R8;
                        puVar13[iVar4 + iVar12] = 0;
                        *(undefined4 *)(in_R8 + 0xb) = 1;
                        in_R8[10] = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cd2;
                        func_0x00018024a850(puVar13, 0x2f, 1, 0x1801ade20);
                        in_R8[10] = 1;
                        *(undefined4 *)(in_R8 + 0xb) = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cf0;
                        func_0x000180224990(puVar13, 0x1804aeee0, 0x555);
                    }
                }
                goto code_r0x0001801a7cfa;
            }
        }
        uVar22 = uVar22 + 1;
        puVar21 = puVar21 + 2;
    } while (uVar22 < 2);
    iVar8 = *(int32_t *)(&stack0x00000000 + iVar10);
    *(undefined4 *)((int64_t)&var_8h + iVar10) = *(undefined4 *)((int64_t)&var_8h + iVar10);
code_r0x0001801a7d22:
    iVar12 = in_R8[1];
    if (in_R8[2] == iVar12) {
        iVar4 = in_R8[3];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x56f;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d56;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[1] = in_R8[1] + 0x20;
        in_R8[3] = iVar12;
    }
    iVar12 = in_R8[7];
    if (in_R8[8] == iVar12) {
        iVar4 = in_R8[9];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x57c;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d90;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[7] = in_R8[7] + 0x20;
        in_R8[9] = iVar12;
    }
    if (iVar9 < 0x40) {
        uVar22 = (uint64_t)iVar9;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7dc1;
        func_0x000180498030((int64_t)&var_18h + iVar10, in_RCX, uVar22);
        if (0x3f < uVar22) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8098;
            func_0x000180459e6c();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar12 = *in_R8;
        *(undefined *)((int64_t)&var_18h + uVar22 + iVar10) = 0;
        uVar22 = uVar18;
        uVar20 = uVar18;
        if (*(int64_t *)(iVar12 + 0x668) != 0) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e05;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) {
code_r0x0001801a7e35:
                    iVar19 = *(int16_t *)(*(int64_t *)(iVar12 + 0x660) + 0x1c + uVar20 * 0x38);
                    if (iVar19 != 0) goto code_r0x0001801a7e98;
                    break;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e1f;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) goto code_r0x0001801a7e35;
                uVar20 = uVar20 + 1;
            } while (uVar20 < *(uint64_t *)(iVar12 + 0x668));
        }
        do {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e6d;
            iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
            if (iVar9 == 0) {
                iVar19 = *(int16_t *)(uVar22 * 0x10 + 0x1804ae028);
                if (iVar19 != 0) goto code_r0x0001801a7e98;
                break;
            }
            uVar22 = uVar22 + 1;
        } while (uVar22 < 7);
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7e98:
    uVar22 = *(uint64_t *)(*in_R8 + 0x668);
    if (uVar22 != 0) {
        piVar15 = (int16_t *)(*(int64_t *)(*in_R8 + 0x660) + 0x1c);
        uVar20 = uVar18;
        do {
            if (*piVar15 == iVar19) {
                uVar22 = in_R8[2];
                if (iVar8 == 0) {
                    if (uVar22 == 0) goto code_r0x0001801a8016;
                    piVar15 = (int16_t *)in_R8[3];
                    goto code_r0x0001801a8000;
                }
                if (uVar22 != 0) {
                    piVar15 = (int16_t *)in_R8[3];
                    uVar20 = uVar18;
                    goto code_r0x0001801a7ef0;
                }
                break;
            }
            uVar20 = uVar20 + 1;
            piVar15 = piVar15 + 0x1c;
        } while (uVar20 < uVar22);
    }
    goto code_r0x0001801a7cfa;
    while( true ) {
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar18) break;
code_r0x0001801a8000:
        if (*piVar15 == iVar19) goto code_r0x0001801a7cfa;
    }
code_r0x0001801a8016:
    *(int16_t *)(in_R8[3] + uVar22 * 2) = iVar19;
    in_R8[2] = in_R8[2] + 1;
    piVar16 = (int64_t *)(in_R8[6] + in_R8[5] * 8);
    *piVar16 = *piVar16 + 1;
    if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) {
        *(int16_t *)(in_R8[9] + in_R8[8] * 2) = iVar19;
        in_R8[8] = in_R8[8] + 1;
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7ef0:
    if (*piVar15 != iVar19) {
        uVar20 = uVar20 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar20) goto code_r0x0001801a7cfa;
        goto code_r0x0001801a7ef0;
    }
    uVar17 = uVar20;
    if (uVar20 < uVar22 - 1) {
        do {
            puVar1 = (undefined2 *)(in_R8[3] + uVar17 * 2);
            uVar17 = uVar17 + 1;
            *puVar1 = puVar1[1];
            uVar22 = in_R8[2];
        } while (uVar17 < uVar22 - 1);
    }
    in_R8[2] = uVar22 - 1;
    uVar22 = uVar18;
    if (in_R8[5] == 0) {
code_r0x0001801a7f77:
        piVar16 = (int64_t *)(in_R8[6] + uVar22 * 8);
        *piVar16 = *piVar16 + -1;
    } else {
        piVar16 = (int64_t *)in_R8[6];
        uVar17 = uVar18;
        while( true ) {
            uVar17 = uVar17 + *piVar16;
            if (uVar20 < uVar17) break;
            uVar22 = uVar22 + 1;
            piVar16 = piVar16 + 1;
            if ((uint64_t)in_R8[5] <= uVar22) goto code_r0x0001801a7f77;
        }
        *(int64_t *)(in_R8[6] + uVar22 * 8) = *piVar16 + -1;
    }
    uVar22 = in_R8[8];
    if (uVar22 == 0) goto code_r0x0001801a7cfa;
    piVar15 = (int16_t *)in_R8[9];
    do {
        if (*piVar15 == iVar19) {
            if (uVar18 < uVar22 - 1) {
                do {
                    puVar1 = (undefined2 *)(in_R8[9] + uVar18 * 2);
                    uVar18 = uVar18 + 1;
                    *puVar1 = puVar1[1];
                    uVar22 = in_R8[8];
                } while (uVar18 < uVar22 - 1);
            }
            in_R8[8] = uVar22 - 1;
            break;
        }
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
    } while (uVar18 < uVar22);
code_r0x0001801a7cfa:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d0a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801a7cfa
// Address: 0x1801a7cfa
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801a7aa0(int64_t arg_58h, int64_t arg_c0h)
{
    undefined2 *puVar1;
    char cVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    char *pcVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    char *pcVar11;
    int64_t iVar12;
    undefined *puVar13;
    undefined8 uVar14;
    int16_t *piVar15;
    int64_t *piVar16;
    char *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar17;
    uint64_t uVar18;
    int16_t iVar19;
    int64_t *in_R8;
    uint64_t uVar20;
    undefined8 *puVar21;
    undefined8 unaff_R14;
    uint64_t uVar22;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801a7ab5;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_58h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10)
    ;
    uVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 0;
    uVar22 = in_RDX & 0xffffffff;
    *(undefined4 *)((int64_t)&var_8h + iVar10) = 0;
    *(undefined4 *)(&stack0x00000000 + iVar10) = 0;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
    if (((in_R8 == (int64_t *)0x0) || (in_RCX == (char *)0x0)) || ((int32_t)in_RDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8062;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a807a;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&var_18h + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a808c;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar10));
        goto code_r0x0001801a7cfa;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar10) = unaff_R14;
    uVar20 = uVar18;
    uVar17 = uVar18;
    while( true ) {
        iVar8 = (int32_t)uVar17;
        iVar9 = (int32_t)uVar22;
        if (iVar9 < 1) break;
        cVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b2a;
        pcVar11 = (char *)func_0x00018045b928(0x1804ae018, (int32_t)cVar2);
        pcVar6 = *(char **)0x18069c688;
        if (pcVar11 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b47;
            iVar7 = func_0x0001802237e0(*(char **)0x18069c688, in_RCX, 1);
            pcVar11 = pcVar6;
            if (iVar7 != 0) goto code_r0x0001801a7d22;
        }
        cVar2 = *pcVar11;
        if (cVar2 == '*') {
            if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
        } else if (cVar2 == '-') {
            if (iVar8 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)(&stack0x00000000 + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar17 = 1;
        } else {
            if ((cVar2 == '/') || (cVar2 == ':')) goto code_r0x0001801a7cfa;
            if (cVar2 != '?') {
                puVar21 = (undefined8 *)0x1804adff8;
                uVar22 = uVar18;
                goto code_r0x0001801a7bd0;
            }
            if ((int32_t)uVar20 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar20 = 1;
        }
    }
    if (iVar9 == 0) goto code_r0x0001801a7cfa;
    goto code_r0x0001801a7d22;
code_r0x0001801a7bd0:
    do {
        uVar3 = *puVar21;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bdc;
        iVar12 = func_0x000180498cd0(uVar3);
        if (iVar9 == iVar12) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bf2;
            iVar8 = func_0x0001802237e0(uVar3, in_RCX, (int64_t)iVar9);
            if (iVar8 == 0) {
                if ((*(int32_t *)((int64_t)&var_8h + iVar10 + 4) == 0) && (*(int32_t *)(&stack0x00000000 + iVar10) == 0)
                   ) {
                    iVar12 = uVar22 * 0x10;
                    uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c45;
                    func_0x000180498cd0(uVar3);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c5b;
                    puVar13 = (undefined *)
                              fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    if (puVar13 != (undefined *)0x0) {
                        if ((*(int32_t *)((int64_t)&var_8h + iVar10) != 0) && (**(char **)(iVar12 + 0x1804ae000) != '*')
                           ) {
                            *puVar13 = 0x2a;
                            *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 1;
                        }
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c88;
                        uVar14 = func_0x000180498cd0(uVar3);
                        iVar4 = *(int64_t *)((int64_t)aiStackX_8 + iVar10);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c9d;
                        func_0x000180498030(puVar13 + iVar4, uVar3, uVar14);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7ca6;
                        iVar12 = func_0x000180498cd0(uVar3);
                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar10) = in_R8;
                        puVar13[iVar4 + iVar12] = 0;
                        *(undefined4 *)(in_R8 + 0xb) = 1;
                        in_R8[10] = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cd2;
                        func_0x00018024a850(puVar13, 0x2f, 1, 0x1801ade20);
                        in_R8[10] = 1;
                        *(undefined4 *)(in_R8 + 0xb) = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cf0;
                        func_0x000180224990(puVar13, 0x1804aeee0, 0x555);
                    }
                }
                goto code_r0x0001801a7cfa;
            }
        }
        uVar22 = uVar22 + 1;
        puVar21 = puVar21 + 2;
    } while (uVar22 < 2);
    iVar8 = *(int32_t *)(&stack0x00000000 + iVar10);
    *(undefined4 *)((int64_t)&var_8h + iVar10) = *(undefined4 *)((int64_t)&var_8h + iVar10);
code_r0x0001801a7d22:
    iVar12 = in_R8[1];
    if (in_R8[2] == iVar12) {
        iVar4 = in_R8[3];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x56f;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d56;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[1] = in_R8[1] + 0x20;
        in_R8[3] = iVar12;
    }
    iVar12 = in_R8[7];
    if (in_R8[8] == iVar12) {
        iVar4 = in_R8[9];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x57c;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d90;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[7] = in_R8[7] + 0x20;
        in_R8[9] = iVar12;
    }
    if (iVar9 < 0x40) {
        uVar22 = (uint64_t)iVar9;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7dc1;
        func_0x000180498030((int64_t)&var_18h + iVar10, in_RCX, uVar22);
        if (0x3f < uVar22) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8098;
            func_0x000180459e6c();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar12 = *in_R8;
        *(undefined *)((int64_t)&var_18h + uVar22 + iVar10) = 0;
        uVar22 = uVar18;
        uVar20 = uVar18;
        if (*(int64_t *)(iVar12 + 0x668) != 0) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e05;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) {
code_r0x0001801a7e35:
                    iVar19 = *(int16_t *)(*(int64_t *)(iVar12 + 0x660) + 0x1c + uVar20 * 0x38);
                    if (iVar19 != 0) goto code_r0x0001801a7e98;
                    break;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e1f;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) goto code_r0x0001801a7e35;
                uVar20 = uVar20 + 1;
            } while (uVar20 < *(uint64_t *)(iVar12 + 0x668));
        }
        do {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e6d;
            iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
            if (iVar9 == 0) {
                iVar19 = *(int16_t *)(uVar22 * 0x10 + 0x1804ae028);
                if (iVar19 != 0) goto code_r0x0001801a7e98;
                break;
            }
            uVar22 = uVar22 + 1;
        } while (uVar22 < 7);
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7e98:
    uVar22 = *(uint64_t *)(*in_R8 + 0x668);
    if (uVar22 != 0) {
        piVar15 = (int16_t *)(*(int64_t *)(*in_R8 + 0x660) + 0x1c);
        uVar20 = uVar18;
        do {
            if (*piVar15 == iVar19) {
                uVar22 = in_R8[2];
                if (iVar8 == 0) {
                    if (uVar22 == 0) goto code_r0x0001801a8016;
                    piVar15 = (int16_t *)in_R8[3];
                    goto code_r0x0001801a8000;
                }
                if (uVar22 != 0) {
                    piVar15 = (int16_t *)in_R8[3];
                    uVar20 = uVar18;
                    goto code_r0x0001801a7ef0;
                }
                break;
            }
            uVar20 = uVar20 + 1;
            piVar15 = piVar15 + 0x1c;
        } while (uVar20 < uVar22);
    }
    goto code_r0x0001801a7cfa;
    while( true ) {
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar18) break;
code_r0x0001801a8000:
        if (*piVar15 == iVar19) goto code_r0x0001801a7cfa;
    }
code_r0x0001801a8016:
    *(int16_t *)(in_R8[3] + uVar22 * 2) = iVar19;
    in_R8[2] = in_R8[2] + 1;
    piVar16 = (int64_t *)(in_R8[6] + in_R8[5] * 8);
    *piVar16 = *piVar16 + 1;
    if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) {
        *(int16_t *)(in_R8[9] + in_R8[8] * 2) = iVar19;
        in_R8[8] = in_R8[8] + 1;
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7ef0:
    if (*piVar15 != iVar19) {
        uVar20 = uVar20 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar20) goto code_r0x0001801a7cfa;
        goto code_r0x0001801a7ef0;
    }
    uVar17 = uVar20;
    if (uVar20 < uVar22 - 1) {
        do {
            puVar1 = (undefined2 *)(in_R8[3] + uVar17 * 2);
            uVar17 = uVar17 + 1;
            *puVar1 = puVar1[1];
            uVar22 = in_R8[2];
        } while (uVar17 < uVar22 - 1);
    }
    in_R8[2] = uVar22 - 1;
    uVar22 = uVar18;
    if (in_R8[5] == 0) {
code_r0x0001801a7f77:
        piVar16 = (int64_t *)(in_R8[6] + uVar22 * 8);
        *piVar16 = *piVar16 + -1;
    } else {
        piVar16 = (int64_t *)in_R8[6];
        uVar17 = uVar18;
        while( true ) {
            uVar17 = uVar17 + *piVar16;
            if (uVar20 < uVar17) break;
            uVar22 = uVar22 + 1;
            piVar16 = piVar16 + 1;
            if ((uint64_t)in_R8[5] <= uVar22) goto code_r0x0001801a7f77;
        }
        *(int64_t *)(in_R8[6] + uVar22 * 8) = *piVar16 + -1;
    }
    uVar22 = in_R8[8];
    if (uVar22 == 0) goto code_r0x0001801a7cfa;
    piVar15 = (int16_t *)in_R8[9];
    do {
        if (*piVar15 == iVar19) {
            if (uVar18 < uVar22 - 1) {
                do {
                    puVar1 = (undefined2 *)(in_R8[9] + uVar18 * 2);
                    uVar18 = uVar18 + 1;
                    *puVar1 = puVar1[1];
                    uVar22 = in_R8[8];
                } while (uVar18 < uVar22 - 1);
            }
            in_R8[8] = uVar22 - 1;
            break;
        }
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
    } while (uVar18 < uVar22);
code_r0x0001801a7cfa:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d0a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801a7d1c
// Address: 0x1801a7d1c
// Size: 833 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801a7aa0(int64_t arg_58h, int64_t arg_c0h)
{
    undefined2 *puVar1;
    char cVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    char *pcVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    char *pcVar11;
    int64_t iVar12;
    undefined *puVar13;
    undefined8 uVar14;
    int16_t *piVar15;
    int64_t *piVar16;
    char *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar17;
    uint64_t uVar18;
    int16_t iVar19;
    int64_t *in_R8;
    uint64_t uVar20;
    undefined8 *puVar21;
    undefined8 unaff_R14;
    uint64_t uVar22;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801a7ab5;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_58h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10)
    ;
    uVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 0;
    uVar22 = in_RDX & 0xffffffff;
    *(undefined4 *)((int64_t)&var_8h + iVar10) = 0;
    *(undefined4 *)(&stack0x00000000 + iVar10) = 0;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
    if (((in_R8 == (int64_t *)0x0) || (in_RCX == (char *)0x0)) || ((int32_t)in_RDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8062;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a807a;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&var_18h + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a808c;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar10));
        goto code_r0x0001801a7cfa;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar10) = unaff_R14;
    uVar20 = uVar18;
    uVar17 = uVar18;
    while( true ) {
        iVar8 = (int32_t)uVar17;
        iVar9 = (int32_t)uVar22;
        if (iVar9 < 1) break;
        cVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b2a;
        pcVar11 = (char *)func_0x00018045b928(0x1804ae018, (int32_t)cVar2);
        pcVar6 = *(char **)0x18069c688;
        if (pcVar11 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b47;
            iVar7 = func_0x0001802237e0(*(char **)0x18069c688, in_RCX, 1);
            pcVar11 = pcVar6;
            if (iVar7 != 0) goto code_r0x0001801a7d22;
        }
        cVar2 = *pcVar11;
        if (cVar2 == '*') {
            if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
        } else if (cVar2 == '-') {
            if (iVar8 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)(&stack0x00000000 + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar17 = 1;
        } else {
            if ((cVar2 == '/') || (cVar2 == ':')) goto code_r0x0001801a7cfa;
            if (cVar2 != '?') {
                puVar21 = (undefined8 *)0x1804adff8;
                uVar22 = uVar18;
                goto code_r0x0001801a7bd0;
            }
            if ((int32_t)uVar20 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar20 = 1;
        }
    }
    if (iVar9 == 0) goto code_r0x0001801a7cfa;
    goto code_r0x0001801a7d22;
code_r0x0001801a7bd0:
    do {
        uVar3 = *puVar21;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bdc;
        iVar12 = func_0x000180498cd0(uVar3);
        if (iVar9 == iVar12) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bf2;
            iVar8 = func_0x0001802237e0(uVar3, in_RCX, (int64_t)iVar9);
            if (iVar8 == 0) {
                if ((*(int32_t *)((int64_t)&var_8h + iVar10 + 4) == 0) && (*(int32_t *)(&stack0x00000000 + iVar10) == 0)
                   ) {
                    iVar12 = uVar22 * 0x10;
                    uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c45;
                    func_0x000180498cd0(uVar3);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c5b;
                    puVar13 = (undefined *)
                              fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    if (puVar13 != (undefined *)0x0) {
                        if ((*(int32_t *)((int64_t)&var_8h + iVar10) != 0) && (**(char **)(iVar12 + 0x1804ae000) != '*')
                           ) {
                            *puVar13 = 0x2a;
                            *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 1;
                        }
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c88;
                        uVar14 = func_0x000180498cd0(uVar3);
                        iVar4 = *(int64_t *)((int64_t)aiStackX_8 + iVar10);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c9d;
                        func_0x000180498030(puVar13 + iVar4, uVar3, uVar14);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7ca6;
                        iVar12 = func_0x000180498cd0(uVar3);
                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar10) = in_R8;
                        puVar13[iVar4 + iVar12] = 0;
                        *(undefined4 *)(in_R8 + 0xb) = 1;
                        in_R8[10] = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cd2;
                        func_0x00018024a850(puVar13, 0x2f, 1, 0x1801ade20);
                        in_R8[10] = 1;
                        *(undefined4 *)(in_R8 + 0xb) = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cf0;
                        func_0x000180224990(puVar13, 0x1804aeee0, 0x555);
                    }
                }
                goto code_r0x0001801a7cfa;
            }
        }
        uVar22 = uVar22 + 1;
        puVar21 = puVar21 + 2;
    } while (uVar22 < 2);
    iVar8 = *(int32_t *)(&stack0x00000000 + iVar10);
    *(undefined4 *)((int64_t)&var_8h + iVar10) = *(undefined4 *)((int64_t)&var_8h + iVar10);
code_r0x0001801a7d22:
    iVar12 = in_R8[1];
    if (in_R8[2] == iVar12) {
        iVar4 = in_R8[3];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x56f;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d56;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[1] = in_R8[1] + 0x20;
        in_R8[3] = iVar12;
    }
    iVar12 = in_R8[7];
    if (in_R8[8] == iVar12) {
        iVar4 = in_R8[9];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x57c;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d90;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[7] = in_R8[7] + 0x20;
        in_R8[9] = iVar12;
    }
    if (iVar9 < 0x40) {
        uVar22 = (uint64_t)iVar9;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7dc1;
        func_0x000180498030((int64_t)&var_18h + iVar10, in_RCX, uVar22);
        if (0x3f < uVar22) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8098;
            func_0x000180459e6c();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar12 = *in_R8;
        *(undefined *)((int64_t)&var_18h + uVar22 + iVar10) = 0;
        uVar22 = uVar18;
        uVar20 = uVar18;
        if (*(int64_t *)(iVar12 + 0x668) != 0) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e05;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) {
code_r0x0001801a7e35:
                    iVar19 = *(int16_t *)(*(int64_t *)(iVar12 + 0x660) + 0x1c + uVar20 * 0x38);
                    if (iVar19 != 0) goto code_r0x0001801a7e98;
                    break;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e1f;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) goto code_r0x0001801a7e35;
                uVar20 = uVar20 + 1;
            } while (uVar20 < *(uint64_t *)(iVar12 + 0x668));
        }
        do {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e6d;
            iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
            if (iVar9 == 0) {
                iVar19 = *(int16_t *)(uVar22 * 0x10 + 0x1804ae028);
                if (iVar19 != 0) goto code_r0x0001801a7e98;
                break;
            }
            uVar22 = uVar22 + 1;
        } while (uVar22 < 7);
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7e98:
    uVar22 = *(uint64_t *)(*in_R8 + 0x668);
    if (uVar22 != 0) {
        piVar15 = (int16_t *)(*(int64_t *)(*in_R8 + 0x660) + 0x1c);
        uVar20 = uVar18;
        do {
            if (*piVar15 == iVar19) {
                uVar22 = in_R8[2];
                if (iVar8 == 0) {
                    if (uVar22 == 0) goto code_r0x0001801a8016;
                    piVar15 = (int16_t *)in_R8[3];
                    goto code_r0x0001801a8000;
                }
                if (uVar22 != 0) {
                    piVar15 = (int16_t *)in_R8[3];
                    uVar20 = uVar18;
                    goto code_r0x0001801a7ef0;
                }
                break;
            }
            uVar20 = uVar20 + 1;
            piVar15 = piVar15 + 0x1c;
        } while (uVar20 < uVar22);
    }
    goto code_r0x0001801a7cfa;
    while( true ) {
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar18) break;
code_r0x0001801a8000:
        if (*piVar15 == iVar19) goto code_r0x0001801a7cfa;
    }
code_r0x0001801a8016:
    *(int16_t *)(in_R8[3] + uVar22 * 2) = iVar19;
    in_R8[2] = in_R8[2] + 1;
    piVar16 = (int64_t *)(in_R8[6] + in_R8[5] * 8);
    *piVar16 = *piVar16 + 1;
    if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) {
        *(int16_t *)(in_R8[9] + in_R8[8] * 2) = iVar19;
        in_R8[8] = in_R8[8] + 1;
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7ef0:
    if (*piVar15 != iVar19) {
        uVar20 = uVar20 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar20) goto code_r0x0001801a7cfa;
        goto code_r0x0001801a7ef0;
    }
    uVar17 = uVar20;
    if (uVar20 < uVar22 - 1) {
        do {
            puVar1 = (undefined2 *)(in_R8[3] + uVar17 * 2);
            uVar17 = uVar17 + 1;
            *puVar1 = puVar1[1];
            uVar22 = in_R8[2];
        } while (uVar17 < uVar22 - 1);
    }
    in_R8[2] = uVar22 - 1;
    uVar22 = uVar18;
    if (in_R8[5] == 0) {
code_r0x0001801a7f77:
        piVar16 = (int64_t *)(in_R8[6] + uVar22 * 8);
        *piVar16 = *piVar16 + -1;
    } else {
        piVar16 = (int64_t *)in_R8[6];
        uVar17 = uVar18;
        while( true ) {
            uVar17 = uVar17 + *piVar16;
            if (uVar20 < uVar17) break;
            uVar22 = uVar22 + 1;
            piVar16 = piVar16 + 1;
            if ((uint64_t)in_R8[5] <= uVar22) goto code_r0x0001801a7f77;
        }
        *(int64_t *)(in_R8[6] + uVar22 * 8) = *piVar16 + -1;
    }
    uVar22 = in_R8[8];
    if (uVar22 == 0) goto code_r0x0001801a7cfa;
    piVar15 = (int16_t *)in_R8[9];
    do {
        if (*piVar15 == iVar19) {
            if (uVar18 < uVar22 - 1) {
                do {
                    puVar1 = (undefined2 *)(in_R8[9] + uVar18 * 2);
                    uVar18 = uVar18 + 1;
                    *puVar1 = puVar1[1];
                    uVar22 = in_R8[8];
                } while (uVar18 < uVar22 - 1);
            }
            in_R8[8] = uVar22 - 1;
            break;
        }
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
    } while (uVar18 < uVar22);
code_r0x0001801a7cfa:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d0a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801a805d
// Address: 0x1801a805d
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801a7aa0(int64_t arg_58h, int64_t arg_c0h)
{
    undefined2 *puVar1;
    char cVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    char *pcVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    char *pcVar11;
    int64_t iVar12;
    undefined *puVar13;
    undefined8 uVar14;
    int16_t *piVar15;
    int64_t *piVar16;
    char *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar17;
    uint64_t uVar18;
    int16_t iVar19;
    int64_t *in_R8;
    uint64_t uVar20;
    undefined8 *puVar21;
    undefined8 unaff_R14;
    uint64_t uVar22;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801a7ab5;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_58h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10)
    ;
    uVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 0;
    uVar22 = in_RDX & 0xffffffff;
    *(undefined4 *)((int64_t)&var_8h + iVar10) = 0;
    *(undefined4 *)(&stack0x00000000 + iVar10) = 0;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
    if (((in_R8 == (int64_t *)0x0) || (in_RCX == (char *)0x0)) || ((int32_t)in_RDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8062;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a807a;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&var_18h + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a808c;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar10));
        goto code_r0x0001801a7cfa;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar10) = unaff_R14;
    uVar20 = uVar18;
    uVar17 = uVar18;
    while( true ) {
        iVar8 = (int32_t)uVar17;
        iVar9 = (int32_t)uVar22;
        if (iVar9 < 1) break;
        cVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b2a;
        pcVar11 = (char *)func_0x00018045b928(0x1804ae018, (int32_t)cVar2);
        pcVar6 = *(char **)0x18069c688;
        if (pcVar11 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b47;
            iVar7 = func_0x0001802237e0(*(char **)0x18069c688, in_RCX, 1);
            pcVar11 = pcVar6;
            if (iVar7 != 0) goto code_r0x0001801a7d22;
        }
        cVar2 = *pcVar11;
        if (cVar2 == '*') {
            if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
        } else if (cVar2 == '-') {
            if (iVar8 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)(&stack0x00000000 + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar17 = 1;
        } else {
            if ((cVar2 == '/') || (cVar2 == ':')) goto code_r0x0001801a7cfa;
            if (cVar2 != '?') {
                puVar21 = (undefined8 *)0x1804adff8;
                uVar22 = uVar18;
                goto code_r0x0001801a7bd0;
            }
            if ((int32_t)uVar20 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar20 = 1;
        }
    }
    if (iVar9 == 0) goto code_r0x0001801a7cfa;
    goto code_r0x0001801a7d22;
code_r0x0001801a7bd0:
    do {
        uVar3 = *puVar21;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bdc;
        iVar12 = func_0x000180498cd0(uVar3);
        if (iVar9 == iVar12) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bf2;
            iVar8 = func_0x0001802237e0(uVar3, in_RCX, (int64_t)iVar9);
            if (iVar8 == 0) {
                if ((*(int32_t *)((int64_t)&var_8h + iVar10 + 4) == 0) && (*(int32_t *)(&stack0x00000000 + iVar10) == 0)
                   ) {
                    iVar12 = uVar22 * 0x10;
                    uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c45;
                    func_0x000180498cd0(uVar3);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c5b;
                    puVar13 = (undefined *)
                              fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    if (puVar13 != (undefined *)0x0) {
                        if ((*(int32_t *)((int64_t)&var_8h + iVar10) != 0) && (**(char **)(iVar12 + 0x1804ae000) != '*')
                           ) {
                            *puVar13 = 0x2a;
                            *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 1;
                        }
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c88;
                        uVar14 = func_0x000180498cd0(uVar3);
                        iVar4 = *(int64_t *)((int64_t)aiStackX_8 + iVar10);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c9d;
                        func_0x000180498030(puVar13 + iVar4, uVar3, uVar14);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7ca6;
                        iVar12 = func_0x000180498cd0(uVar3);
                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar10) = in_R8;
                        puVar13[iVar4 + iVar12] = 0;
                        *(undefined4 *)(in_R8 + 0xb) = 1;
                        in_R8[10] = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cd2;
                        func_0x00018024a850(puVar13, 0x2f, 1, 0x1801ade20);
                        in_R8[10] = 1;
                        *(undefined4 *)(in_R8 + 0xb) = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cf0;
                        func_0x000180224990(puVar13, 0x1804aeee0, 0x555);
                    }
                }
                goto code_r0x0001801a7cfa;
            }
        }
        uVar22 = uVar22 + 1;
        puVar21 = puVar21 + 2;
    } while (uVar22 < 2);
    iVar8 = *(int32_t *)(&stack0x00000000 + iVar10);
    *(undefined4 *)((int64_t)&var_8h + iVar10) = *(undefined4 *)((int64_t)&var_8h + iVar10);
code_r0x0001801a7d22:
    iVar12 = in_R8[1];
    if (in_R8[2] == iVar12) {
        iVar4 = in_R8[3];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x56f;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d56;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[1] = in_R8[1] + 0x20;
        in_R8[3] = iVar12;
    }
    iVar12 = in_R8[7];
    if (in_R8[8] == iVar12) {
        iVar4 = in_R8[9];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x57c;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d90;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[7] = in_R8[7] + 0x20;
        in_R8[9] = iVar12;
    }
    if (iVar9 < 0x40) {
        uVar22 = (uint64_t)iVar9;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7dc1;
        func_0x000180498030((int64_t)&var_18h + iVar10, in_RCX, uVar22);
        if (0x3f < uVar22) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8098;
            func_0x000180459e6c();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar12 = *in_R8;
        *(undefined *)((int64_t)&var_18h + uVar22 + iVar10) = 0;
        uVar22 = uVar18;
        uVar20 = uVar18;
        if (*(int64_t *)(iVar12 + 0x668) != 0) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e05;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) {
code_r0x0001801a7e35:
                    iVar19 = *(int16_t *)(*(int64_t *)(iVar12 + 0x660) + 0x1c + uVar20 * 0x38);
                    if (iVar19 != 0) goto code_r0x0001801a7e98;
                    break;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e1f;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) goto code_r0x0001801a7e35;
                uVar20 = uVar20 + 1;
            } while (uVar20 < *(uint64_t *)(iVar12 + 0x668));
        }
        do {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e6d;
            iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
            if (iVar9 == 0) {
                iVar19 = *(int16_t *)(uVar22 * 0x10 + 0x1804ae028);
                if (iVar19 != 0) goto code_r0x0001801a7e98;
                break;
            }
            uVar22 = uVar22 + 1;
        } while (uVar22 < 7);
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7e98:
    uVar22 = *(uint64_t *)(*in_R8 + 0x668);
    if (uVar22 != 0) {
        piVar15 = (int16_t *)(*(int64_t *)(*in_R8 + 0x660) + 0x1c);
        uVar20 = uVar18;
        do {
            if (*piVar15 == iVar19) {
                uVar22 = in_R8[2];
                if (iVar8 == 0) {
                    if (uVar22 == 0) goto code_r0x0001801a8016;
                    piVar15 = (int16_t *)in_R8[3];
                    goto code_r0x0001801a8000;
                }
                if (uVar22 != 0) {
                    piVar15 = (int16_t *)in_R8[3];
                    uVar20 = uVar18;
                    goto code_r0x0001801a7ef0;
                }
                break;
            }
            uVar20 = uVar20 + 1;
            piVar15 = piVar15 + 0x1c;
        } while (uVar20 < uVar22);
    }
    goto code_r0x0001801a7cfa;
    while( true ) {
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar18) break;
code_r0x0001801a8000:
        if (*piVar15 == iVar19) goto code_r0x0001801a7cfa;
    }
code_r0x0001801a8016:
    *(int16_t *)(in_R8[3] + uVar22 * 2) = iVar19;
    in_R8[2] = in_R8[2] + 1;
    piVar16 = (int64_t *)(in_R8[6] + in_R8[5] * 8);
    *piVar16 = *piVar16 + 1;
    if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) {
        *(int16_t *)(in_R8[9] + in_R8[8] * 2) = iVar19;
        in_R8[8] = in_R8[8] + 1;
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7ef0:
    if (*piVar15 != iVar19) {
        uVar20 = uVar20 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar20) goto code_r0x0001801a7cfa;
        goto code_r0x0001801a7ef0;
    }
    uVar17 = uVar20;
    if (uVar20 < uVar22 - 1) {
        do {
            puVar1 = (undefined2 *)(in_R8[3] + uVar17 * 2);
            uVar17 = uVar17 + 1;
            *puVar1 = puVar1[1];
            uVar22 = in_R8[2];
        } while (uVar17 < uVar22 - 1);
    }
    in_R8[2] = uVar22 - 1;
    uVar22 = uVar18;
    if (in_R8[5] == 0) {
code_r0x0001801a7f77:
        piVar16 = (int64_t *)(in_R8[6] + uVar22 * 8);
        *piVar16 = *piVar16 + -1;
    } else {
        piVar16 = (int64_t *)in_R8[6];
        uVar17 = uVar18;
        while( true ) {
            uVar17 = uVar17 + *piVar16;
            if (uVar20 < uVar17) break;
            uVar22 = uVar22 + 1;
            piVar16 = piVar16 + 1;
            if ((uint64_t)in_R8[5] <= uVar22) goto code_r0x0001801a7f77;
        }
        *(int64_t *)(in_R8[6] + uVar22 * 8) = *piVar16 + -1;
    }
    uVar22 = in_R8[8];
    if (uVar22 == 0) goto code_r0x0001801a7cfa;
    piVar15 = (int16_t *)in_R8[9];
    do {
        if (*piVar15 == iVar19) {
            if (uVar18 < uVar22 - 1) {
                do {
                    puVar1 = (undefined2 *)(in_R8[9] + uVar18 * 2);
                    uVar18 = uVar18 + 1;
                    *puVar1 = puVar1[1];
                    uVar22 = in_R8[8];
                } while (uVar18 < uVar22 - 1);
            }
            in_R8[8] = uVar22 - 1;
            break;
        }
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
    } while (uVar18 < uVar22);
code_r0x0001801a7cfa:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d0a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801a8093
// Address: 0x1801a8093
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801a7aa0(int64_t arg_58h, int64_t arg_c0h)
{
    undefined2 *puVar1;
    char cVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    char *pcVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    char *pcVar11;
    int64_t iVar12;
    undefined *puVar13;
    undefined8 uVar14;
    int16_t *piVar15;
    int64_t *piVar16;
    char *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar17;
    uint64_t uVar18;
    int16_t iVar19;
    int64_t *in_R8;
    uint64_t uVar20;
    undefined8 *puVar21;
    undefined8 unaff_R14;
    uint64_t uVar22;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801a7ab5;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_58h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10)
    ;
    uVar18 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 0;
    uVar22 = in_RDX & 0xffffffff;
    *(undefined4 *)((int64_t)&var_8h + iVar10) = 0;
    *(undefined4 *)(&stack0x00000000 + iVar10) = 0;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
    if (((in_R8 == (int64_t *)0x0) || (in_RCX == (char *)0x0)) || ((int32_t)in_RDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8062;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a807a;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&var_18h + iVar10));
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a808c;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar10));
        goto code_r0x0001801a7cfa;
    }
    *(undefined8 *)((int64_t)&arg_c0h + iVar10) = unaff_R14;
    uVar20 = uVar18;
    uVar17 = uVar18;
    while( true ) {
        iVar8 = (int32_t)uVar17;
        iVar9 = (int32_t)uVar22;
        if (iVar9 < 1) break;
        cVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b2a;
        pcVar11 = (char *)func_0x00018045b928(0x1804ae018, (int32_t)cVar2);
        pcVar6 = *(char **)0x18069c688;
        if (pcVar11 == (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7b47;
            iVar7 = func_0x0001802237e0(*(char **)0x18069c688, in_RCX, 1);
            pcVar11 = pcVar6;
            if (iVar7 != 0) goto code_r0x0001801a7d22;
        }
        cVar2 = *pcVar11;
        if (cVar2 == '*') {
            if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
        } else if (cVar2 == '-') {
            if (iVar8 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)(&stack0x00000000 + iVar10) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar17 = 1;
        } else {
            if ((cVar2 == '/') || (cVar2 == ':')) goto code_r0x0001801a7cfa;
            if (cVar2 != '?') {
                puVar21 = (undefined8 *)0x1804adff8;
                uVar22 = uVar18;
                goto code_r0x0001801a7bd0;
            }
            if ((int32_t)uVar20 != 0) goto code_r0x0001801a7cfa;
            in_RCX = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = 1;
            uVar22 = (uint64_t)(iVar9 - 1);
            uVar20 = 1;
        }
    }
    if (iVar9 == 0) goto code_r0x0001801a7cfa;
    goto code_r0x0001801a7d22;
code_r0x0001801a7bd0:
    do {
        uVar3 = *puVar21;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bdc;
        iVar12 = func_0x000180498cd0(uVar3);
        if (iVar9 == iVar12) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7bf2;
            iVar8 = func_0x0001802237e0(uVar3, in_RCX, (int64_t)iVar9);
            if (iVar8 == 0) {
                if ((*(int32_t *)((int64_t)&var_8h + iVar10 + 4) == 0) && (*(int32_t *)(&stack0x00000000 + iVar10) == 0)
                   ) {
                    iVar12 = uVar22 * 0x10;
                    uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c45;
                    func_0x000180498cd0(uVar3);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c5b;
                    puVar13 = (undefined *)
                              fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                            *(int64_t *)(&stack0xfffffffffffffff0 + iVar10));
                    if (puVar13 != (undefined *)0x0) {
                        if ((*(int32_t *)((int64_t)&var_8h + iVar10) != 0) && (**(char **)(iVar12 + 0x1804ae000) != '*')
                           ) {
                            *puVar13 = 0x2a;
                            *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 1;
                        }
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c88;
                        uVar14 = func_0x000180498cd0(uVar3);
                        iVar4 = *(int64_t *)((int64_t)aiStackX_8 + iVar10);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7c9d;
                        func_0x000180498030(puVar13 + iVar4, uVar3, uVar14);
                        uVar3 = *(undefined8 *)(iVar12 + 0x1804ae000);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7ca6;
                        iVar12 = func_0x000180498cd0(uVar3);
                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar10) = in_R8;
                        puVar13[iVar4 + iVar12] = 0;
                        *(undefined4 *)(in_R8 + 0xb) = 1;
                        in_R8[10] = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cd2;
                        func_0x00018024a850(puVar13, 0x2f, 1, 0x1801ade20);
                        in_R8[10] = 1;
                        *(undefined4 *)(in_R8 + 0xb) = 0;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7cf0;
                        func_0x000180224990(puVar13, 0x1804aeee0, 0x555);
                    }
                }
                goto code_r0x0001801a7cfa;
            }
        }
        uVar22 = uVar22 + 1;
        puVar21 = puVar21 + 2;
    } while (uVar22 < 2);
    iVar8 = *(int32_t *)(&stack0x00000000 + iVar10);
    *(undefined4 *)((int64_t)&var_8h + iVar10) = *(undefined4 *)((int64_t)&var_8h + iVar10);
code_r0x0001801a7d22:
    iVar12 = in_R8[1];
    if (in_R8[2] == iVar12) {
        iVar4 = in_R8[3];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x56f;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d56;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[1] = in_R8[1] + 0x20;
        in_R8[3] = iVar12;
    }
    iVar12 = in_R8[7];
    if (in_R8[8] == iVar12) {
        iVar4 = in_R8[9];
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0x57c;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d90;
        iVar12 = func_0x000180224f60(iVar4, iVar12 + 0x20, 2, 0x1804aeee0);
        if (iVar12 == 0) goto code_r0x0001801a7cfa;
        in_R8[7] = in_R8[7] + 0x20;
        in_R8[9] = iVar12;
    }
    if (iVar9 < 0x40) {
        uVar22 = (uint64_t)iVar9;
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7dc1;
        func_0x000180498030((int64_t)&var_18h + iVar10, in_RCX, uVar22);
        if (0x3f < uVar22) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a8098;
            func_0x000180459e6c();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar12 = *in_R8;
        *(undefined *)((int64_t)&var_18h + uVar22 + iVar10) = 0;
        uVar22 = uVar18;
        uVar20 = uVar18;
        if (*(int64_t *)(iVar12 + 0x668) != 0) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e05;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) {
code_r0x0001801a7e35:
                    iVar19 = *(int16_t *)(*(int64_t *)(iVar12 + 0x660) + 0x1c + uVar20 * 0x38);
                    if (iVar19 != 0) goto code_r0x0001801a7e98;
                    break;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e1f;
                iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                      *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
                if (iVar9 == 0) goto code_r0x0001801a7e35;
                uVar20 = uVar20 + 1;
            } while (uVar20 < *(uint64_t *)(iVar12 + 0x668));
        }
        do {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7e6d;
            iVar9 = fcn.180223670(*(int64_t *)(&stack0xffffffffffffffe8 + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar10), 
                                  *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
            if (iVar9 == 0) {
                iVar19 = *(int16_t *)(uVar22 * 0x10 + 0x1804ae028);
                if (iVar19 != 0) goto code_r0x0001801a7e98;
                break;
            }
            uVar22 = uVar22 + 1;
        } while (uVar22 < 7);
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7e98:
    uVar22 = *(uint64_t *)(*in_R8 + 0x668);
    if (uVar22 != 0) {
        piVar15 = (int16_t *)(*(int64_t *)(*in_R8 + 0x660) + 0x1c);
        uVar20 = uVar18;
        do {
            if (*piVar15 == iVar19) {
                uVar22 = in_R8[2];
                if (iVar8 == 0) {
                    if (uVar22 == 0) goto code_r0x0001801a8016;
                    piVar15 = (int16_t *)in_R8[3];
                    goto code_r0x0001801a8000;
                }
                if (uVar22 != 0) {
                    piVar15 = (int16_t *)in_R8[3];
                    uVar20 = uVar18;
                    goto code_r0x0001801a7ef0;
                }
                break;
            }
            uVar20 = uVar20 + 1;
            piVar15 = piVar15 + 0x1c;
        } while (uVar20 < uVar22);
    }
    goto code_r0x0001801a7cfa;
    while( true ) {
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar18) break;
code_r0x0001801a8000:
        if (*piVar15 == iVar19) goto code_r0x0001801a7cfa;
    }
code_r0x0001801a8016:
    *(int16_t *)(in_R8[3] + uVar22 * 2) = iVar19;
    in_R8[2] = in_R8[2] + 1;
    piVar16 = (int64_t *)(in_R8[6] + in_R8[5] * 8);
    *piVar16 = *piVar16 + 1;
    if (*(int32_t *)((int64_t)&var_8h + iVar10) != 0) {
        *(int16_t *)(in_R8[9] + in_R8[8] * 2) = iVar19;
        in_R8[8] = in_R8[8] + 1;
    }
    goto code_r0x0001801a7cfa;
code_r0x0001801a7ef0:
    if (*piVar15 != iVar19) {
        uVar20 = uVar20 + 1;
        piVar15 = piVar15 + 1;
        if (uVar22 <= uVar20) goto code_r0x0001801a7cfa;
        goto code_r0x0001801a7ef0;
    }
    uVar17 = uVar20;
    if (uVar20 < uVar22 - 1) {
        do {
            puVar1 = (undefined2 *)(in_R8[3] + uVar17 * 2);
            uVar17 = uVar17 + 1;
            *puVar1 = puVar1[1];
            uVar22 = in_R8[2];
        } while (uVar17 < uVar22 - 1);
    }
    in_R8[2] = uVar22 - 1;
    uVar22 = uVar18;
    if (in_R8[5] == 0) {
code_r0x0001801a7f77:
        piVar16 = (int64_t *)(in_R8[6] + uVar22 * 8);
        *piVar16 = *piVar16 + -1;
    } else {
        piVar16 = (int64_t *)in_R8[6];
        uVar17 = uVar18;
        while( true ) {
            uVar17 = uVar17 + *piVar16;
            if (uVar20 < uVar17) break;
            uVar22 = uVar22 + 1;
            piVar16 = piVar16 + 1;
            if ((uint64_t)in_R8[5] <= uVar22) goto code_r0x0001801a7f77;
        }
        *(int64_t *)(in_R8[6] + uVar22 * 8) = *piVar16 + -1;
    }
    uVar22 = in_R8[8];
    if (uVar22 == 0) goto code_r0x0001801a7cfa;
    piVar15 = (int16_t *)in_R8[9];
    do {
        if (*piVar15 == iVar19) {
            if (uVar18 < uVar22 - 1) {
                do {
                    puVar1 = (undefined2 *)(in_R8[9] + uVar18 * 2);
                    uVar18 = uVar18 + 1;
                    *puVar1 = puVar1[1];
                    uVar22 = in_R8[8];
                } while (uVar18 < uVar22 - 1);
            }
            in_R8[8] = uVar22 - 1;
            break;
        }
        uVar18 = uVar18 + 1;
        piVar15 = piVar15 + 1;
    } while (uVar18 < uVar22);
code_r0x0001801a7cfa:
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801a7d0a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801a80a0
// Address: 0x1801a80a0
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801a80a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar11;
    int32_t in_R8D;
    undefined8 uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a80b5;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8D == -1) {
        in_R8D = *(int32_t *)(in_RDX + 0x20);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801a80d1;
    uVar9 = func_0x000180197870();
    if ((int32_t)uVar9 == 0) {
        return uVar9;
    }
    iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20);
    uVar9 = *(undefined8 *)(iVar6 + 8 + (int64_t)in_R8D * 0x28);
    uVar12 = *(undefined8 *)(iVar6 + (int64_t)in_R8D * 0x28);
    uVar11 = *(undefined8 *)((int64_t)auStackX_18 + iVar8);
    *(undefined8 *)(&stack0x00000038 + iVar8) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
    *(undefined8 *)((int64_t)auStackX_18 + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + -8) = *(undefined8 *)((int64_t)&arg_30h + iVar8);
    *(undefined8 *)((int64_t)&var_8h + iVar8) = uVar11;
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + -0x18) = 0x1801a7512;
    iVar6 = fcn.18045a350(in_RCX, in_RDX, uVar12, uVar9);
    iVar6 = -iVar6;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar11 = 0;
    if (*(int32_t *)(in_RDX + 0x14) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar8 + -0x18) = 0x1801a7530;
        uVar11 = func_0x00018022ccf0();
    }
    uVar2 = puVar1[0x8c];
    uVar3 = *puVar1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar8 + -0x18) = 0x1801a7545;
    iVar5 = func_0x00018022e980(uVar9, uVar3, uVar11, uVar2);
    if (0 < iVar5) {
        if (*(int64_t *)(in_RCX + 1000) == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar6 + iVar8) = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar8 + -0x18) = 0x1801a7579;
        iVar5 = func_0x000180237500(uVar12, &stack0x00000060 + iVar6 + iVar8, &stack0x00000058 + iVar6 + iVar8, 0);
        if (iVar5 != 0) {
            uVar13 = 0;
            if (*(uint64_t *)(in_RCX + 0x3f8) != 0) {
                uVar4 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x640);
                do {
                    uVar10 = 0;
                    if (uVar4 != 0) {
                        iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x650);
                        do {
                            if (*(int16_t *)(iVar7 + 0x10) == *(int16_t *)(*(int64_t *)(in_RCX + 1000) + uVar13 * 2)) {
                                if (((*(int32_t *)(iVar7 + 0x2c) != 0) &&
                                    (*(int32_t *)(&stack0x00000060 + iVar6 + iVar8) == *(int32_t *)(iVar7 + 0x14))) &&
                                   (*(int32_t *)(&stack0x00000058 + iVar6 + iVar8) == *(int32_t *)(iVar7 + 0x1c))) {
                                    return 1;
                                }
                                break;
                            }
                            iVar7 = iVar7 + 0x48;
                            uVar10 = uVar10 + 1;
                        } while (uVar10 < uVar4);
                    }
                    uVar13 = uVar13 + 1;
                } while (uVar13 < *(uint64_t *)(in_RCX + 0x3f8));
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a8120
// Address: 0x1801a8120
// Size: 763 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801a8120(int64_t arg_28h, int64_t arg_80h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined2 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined *puVar6;
    uint64_t *puVar7;
    char *in_RCX;
    uint64_t uVar8;
    int32_t in_EDX;
    char *pcVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t *in_R8;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a8136;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_28h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    uVar10 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar5 + 4) = 0;
    if (in_RCX != (char *)0x0) {
        iVar4 = in_EDX + -1;
        if (*in_RCX != '?') {
            iVar4 = in_EDX;
        }
        if ((*in_R8 != 0x3e) && (iVar4 < 0x28)) {
            uVar11 = (uint64_t)iVar4;
            pcVar9 = in_RCX + 1;
            if (*in_RCX != '?') {
                pcVar9 = in_RCX;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a81a2;
            func_0x000180498030((int64_t)&stack0x00000000 + iVar5, pcVar9, uVar11);
            if (0x27 < uVar11) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a841a;
                func_0x000180459e6c();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            (&stack0x00000000)[uVar11 + iVar5] = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a81c0;
            puVar6 = (undefined *)func_0x00018045b928((int64_t)&stack0x00000000 + iVar5, 0x2b);
            if (puVar6 == (undefined *)0x0) {
                uVar11 = in_R8[0x11];
                if (uVar11 == 0) {
                    iVar13 = 0x1804ae0e0;
                    uVar11 = uVar10;
                    do {
                        if (*(int64_t *)(iVar13 + 8) != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a8296;
                            iVar4 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                  *(int64_t *)(&stack0x00000000 + iVar5), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                            if (iVar4 != 0) goto code_r0x0001801a829a;
code_r0x0001801a82c0:
                            uVar3 = *(undefined2 *)(iVar13 + 0x10);
                            goto code_r0x0001801a83ac;
                        }
code_r0x0001801a829a:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a82a7;
                        iVar4 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)(&stack0x00000000 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                        if (iVar4 == 0) goto code_r0x0001801a82c0;
                        uVar11 = uVar11 + 1;
                        iVar13 = iVar13 + 0x48;
                    } while (uVar11 < 0x1f);
                } else {
                    uVar8 = uVar10;
                    uVar12 = uVar10;
                    if (*(int64_t *)(uVar11 + 0x640) != 0) {
                        while (*(int64_t *)(*(int64_t *)(uVar11 + 0x650) + 8 + uVar8) == 0) {
code_r0x0001801a8213:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a8220;
                            iVar4 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                  *(int64_t *)(&stack0x00000000 + iVar5), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                            if (iVar4 == 0) goto code_r0x0001801a8243;
                            uVar11 = in_R8[0x11];
                            uVar12 = uVar12 + 1;
                            uVar8 = uVar8 + 0x48;
                            if (*(uint64_t *)(uVar11 + 0x640) <= uVar12) goto code_r0x0001801a83f4;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a820f;
                        iVar4 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)(&stack0x00000000 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
                        if (iVar4 != 0) goto code_r0x0001801a8213;
code_r0x0001801a8243:
                        if (*(int32_t *)(*(int64_t *)(in_R8[0x11] + 0x650) + 0x2c + uVar12 * 0x48) == 0)
                        goto code_r0x0001801a83f4;
                        uVar3 = *(undefined2 *)(*(int64_t *)(in_R8[0x11] + 0x650) + uVar12 * 0x48 + 0x10);
code_r0x0001801a83ac:
                        *(undefined2 *)((int64_t)in_R8 + *in_R8 * 2 + 8) = uVar3;
                        *in_R8 = *in_R8 + 1;
                        uVar11 = *in_R8 - 1;
                        if (uVar11 == 0) goto code_r0x0001801a83f4;
                        puVar7 = in_R8 + 1;
                        do {
                            if (*(int16_t *)puVar7 == *(int16_t *)((int64_t)in_R8 + uVar11 * 2 + 8)) {
                                *in_R8 = uVar11;
                                break;
                            }
                            uVar10 = uVar10 + 1;
                            puVar7 = (uint64_t *)((int64_t)puVar7 + 2);
                        } while (uVar10 < uVar11);
                    }
                }
            } else {
                *puVar6 = 0;
                if (puVar6[1] != '\0') {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a82ea;
                    fcn.1801a7990(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a82fd;
                    fcn.1801a7990(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
                    iVar4 = *(int32_t *)((int64_t)&var_8h + iVar5);
                    if ((iVar4 != 0) && (iVar1 = *(int32_t *)((int64_t)&var_8h + iVar5 + 4), iVar1 != 0)) {
                        uVar11 = in_R8[0x11];
                        uVar8 = uVar10;
                        if (uVar11 == 0) {
                            do {
                                if ((*(int32_t *)(uVar8 + 0x1804ae0f4) == iVar1) &&
                                   (*(int32_t *)(uVar8 + 0x1804ae0fc) == iVar4)) {
                                    uVar3 = *(undefined2 *)(uVar8 + 0x1804ae0f0);
                                    goto code_r0x0001801a83ac;
                                }
                                uVar8 = uVar8 + 0x48;
                            } while (uVar8 < 0x8b8);
                        } else if (*(uint64_t *)(uVar11 + 0x640) != 0) {
                            iVar13 = *(int64_t *)(uVar11 + 0x650);
                            do {
                                if ((*(int32_t *)(iVar13 + 0x14) == iVar1) && (*(int32_t *)(iVar13 + 0x1c) == iVar4)) {
                                    if (*(int32_t *)(*(int64_t *)(in_R8[0x11] + 0x650) + 0x2c + uVar8 * 0x48) != 0) {
                                        uVar3 = *(undefined2 *)(iVar13 + 0x10);
                                        goto code_r0x0001801a83ac;
                                    }
                                    break;
                                }
                                uVar8 = uVar8 + 1;
                                iVar13 = iVar13 + 0x48;
                            } while (uVar8 < *(uint64_t *)(uVar11 + 0x640));
                        }
                    }
                }
            }
        }
    }
code_r0x0001801a83f4:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801a8401;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801a8420
// Address: 0x1801a8420
// Size: 253 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_678h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

int32_t fcn.1801a8420(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a843a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX != 0) {
        if (*(int32_t *)(in_RDX + 0x14) == 0) {
            iVar4 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a845f;
            iVar4 = func_0x0001801a08e0();
            if (iVar4 == 0) {
                return 0;
            }
        }
        if (iVar4 == 0) {
            if (*(int16_t *)(in_RDX + 0x10) == 0x807) {
                return 0x80;
            }
            if (*(int16_t *)(in_RDX + 0x10) == 0x808) {
                return 0xe0;
            }
            iVar1 = *(int32_t *)(in_RDX + 0x20);
            if (iVar1 < 9) {
                return 0;
            }
            if (iVar1 + -9 < *(int32_t *)(in_RCX + 0x680)) {
                return *(int32_t *)((int64_t)iVar1 * 0x68 + -0x358 + *(int64_t *)(in_RCX + 0x678));
            }
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a8478;
        iVar1 = func_0x000180203a00(iVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a8482;
        iVar2 = func_0x00018020f800(iVar4);
        if (0 < iVar2 << 2) {
            if (iVar1 == 0x40) {
                return 0x40;
            }
            if (iVar1 == 0x72) {
                return 0x43;
            }
            if (iVar1 == 4) {
                return 0x27;
            }
            return iVar2 << 2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a8520
// Address: 0x1801a8520
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801a8520(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a8535;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8543;
    uVar3 = func_0x0001801e3990(in_RDX);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8550;
    iVar1 = func_0x000180222010(in_RCX);
    if (0 < iVar1) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a855e;
            uVar4 = func_0x000180222340(in_RCX, iVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8569;
            iVar1 = func_0x0001802378e0(uVar3, uVar4);
            if (iVar1 == 0) {
                return 1;
            }
            iVar5 = iVar5 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8577;
            iVar1 = func_0x000180222010(in_RCX);
        } while (iVar5 < iVar1);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a85b0
// Address: 0x1801a85b0
// Size: 308 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801a85b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t in_R8;
    int32_t in_R9D;
    bool bVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a85ce;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    bVar7 = (*(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0;
    iVar6 = 0x34;
    if (bVar7) {
        iVar6 = 0x2c;
    }
    iVar4 = *(int32_t *)(iVar6 + in_RDX);
    iVar6 = 0x38;
    if (bVar7) {
        iVar6 = 0x30;
    }
    uVar1 = *(undefined4 *)(iVar6 + in_RDX);
    if ((((*(uint32_t *)(in_RDX + 0x1c) & *(uint32_t *)(in_RCX + 0x410)) == 0) &&
        ((*(uint32_t *)(in_RDX + 0x20) & *(uint32_t *)(in_RCX + 0x414)) == 0)) && (*(int32_t *)(in_RCX + 0x41c) != 0)) {
        if ((*(uint32_t *)(in_RCX + 0x160) & 0x4000) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801a8650;
            iVar3 = func_0x00018019e0f0(in_RDX);
            if (((iVar3 != 0x3001301) && (iVar3 != 0x3001302)) && (iVar3 != 0x3001303)) {
                return true;
            }
        }
        if (((iVar4 == 0x301) && (in_R9D != 0)) && ((*(uint8_t *)(in_RDX + 0x1c) & 0x84) != 0)) {
            iVar4 = 0x300;
        }
        uVar2 = *(undefined4 *)(in_RCX + 0x41c);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801a868a;
        iVar4 = func_0x0001801afd90(in_RCX, iVar4, uVar2);
        if (iVar4 < 1) {
            uVar2 = *(undefined4 *)(in_RCX + 0x418);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801a86a0;
            iVar4 = func_0x0001801afd90(in_RCX, uVar1, uVar2);
            if (-1 < iVar4) {
                uVar1 = *(undefined4 *)(in_RDX + 0x44);
                *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801a86bb;
                iVar4 = func_0x0001801a2690(in_RCX, in_R8 & 0xffffffff, uVar1, 0);
                return iVar4 == 0;
            }
        }
    }
    return true;
}

// ============================================================
// Function: FUN_1801a86f0
// Address: 0x1801a86f0
// Size: 99 bytes
// ============================================================
void fcn.1801a86f0(int64_t arg_58h, int64_t arg_90h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a86fa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_58h + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801a871f;
    iVar1 = fcn.18022f7c0(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                          *(int64_t *)(&stack0x00000078 + iVar2), *(int64_t *)(&stack0x00000088 + iVar2), 
                          *(int64_t *)((int64_t)&arg_90h + iVar2));
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801a872d;
        fcn.18022d1b0(*(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801a873a;
        fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
        return;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801a874e;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
    return;
}

// ============================================================
// Function: FUN_1801a8760
// Address: 0x1801a8760
// Size: 427 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_3c0h because it doesn't fit into ProtoModel

undefined8 fcn.1801a8760(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int64_t iVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a877e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *(int64_t *)(in_RCX + 0x878);
    iVar8 = 0;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
    iVar5 = 0x50;
    iVar11 = 0;
    if (*(int32_t *)(iVar7 + 0x18) != 2) {
        if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20) & 0x14) == 0) {
            if (*(int64_t *)(in_RCX + 0x3d8) == 0) {
                return 0;
            }
            uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x3d8) + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a87e0;
            iVar5 = func_0x00018022fb60(uVar2);
        } else {
            iVar5 = 0x80;
            if (*(int32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x44) != 0x100) {
                iVar5 = 0x50;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a87ef;
    iVar4 = func_0x0001801a2630(in_RCX, 0, 0);
    if (iVar5 < iVar4) {
        iVar5 = iVar4;
    }
    if (iVar5 < 0xc0) {
        if (iVar5 < 0x98) {
            if (iVar5 < 0x80) {
                if (iVar5 < 0x70) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a8834;
                    iVar7 = func_0x000180256430(0);
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a882d;
                    iVar7 = func_0x000180256460();
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a8821;
                iVar7 = func_0x0001802564a0();
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a8812;
            iVar7 = func_0x0001802564e0();
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a8803;
        iVar7 = func_0x000180256520();
    }
    iVar9 = iVar8;
    iVar10 = iVar8;
    if (iVar7 != 0) {
        uVar2 = puVar1[0x8c];
        uVar3 = *puVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a8856;
        iVar8 = func_0x0001802591e0(uVar3, 0x1804ad19c, uVar2);
        iVar9 = 0;
        iVar10 = iVar11;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a8866;
            iVar5 = func_0x00018025a8a0(iVar8);
            if (iVar5 == 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a8870;
                iVar9 = func_0x00018025b2a0();
                if (iVar9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a888a;
                    iVar5 = func_0x00018025b310(iVar9, 0x1804af230, iVar7);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a88a3;
                        iVar5 = func_0x00018025b4e0(iVar9, 0x1804af234, 2);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a88af;
                            iVar10 = func_0x00018025b5a0(iVar9);
                            if (iVar10 != 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a88cd;
                                func_0x00018025a780(iVar8, (int64_t)&arg_28h + iVar6, 0x84, iVar10);
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a88d5;
    func_0x000180256a40(iVar10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a88dd;
    func_0x00018025b220(iVar9);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a88e5;
    func_0x000180258be0(iVar8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801a88ed;
    func_0x000180255290(iVar7);
    return *(undefined8 *)((int64_t)&arg_28h + iVar6);
}

// ============================================================
// Function: FUN_1801a8910
// Address: 0x1801a8910
// Size: 56 bytes
// ============================================================
undefined8
fcn.1801a8910(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_d0h,
             int64_t arg_e0h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t **in_RCX;
    int64_t *piVar12;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t *in_R8;
    uint64_t in_R9;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_18 [2];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar12 = *in_RCX;
    if (piVar12 == (int64_t *)0x0) {
        if (in_RCX[1] == (int64_t *)0x0) {
            return 0;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar7 + 8) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar7) = 0x1801bc83c;
        iVar8 = fcn.18045a350();
        piVar12 = in_RCX[1];
        *(undefined8 *)((int64_t)auStackX_18 + -iVar8 + iVar7) = 0x1801bc850;
        iVar6 = func_0x00018021d590(piVar12);
        if (iVar6 < 1) {
            return 0;
        }
        if (in_R8 != (uint64_t *)0x0) {
            *in_R8 = (uint64_t)*(uint32_t *)((int64_t)&arg_50h + -iVar8 + iVar7);
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar7 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar7) = 0x18025721a;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined4 *)((int64_t)&arg_e0h + iVar8 + iVar7) = 0;
    if ((piVar12 == (int64_t *)0x0) || (*piVar12 == 0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x1802573cc;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x1802573e4;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7), *(int64_t *)(&stack0x00000058 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7));
    } else if (*(int64_t *)(*piVar12 + 0x50) == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257255;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x18025726d;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7), *(int64_t *)(&stack0x00000058 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7));
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257283;
        uVar9 = func_0x000180257880(extraout_XMM0_Da, 0x18063dcac);
        if (in_RDX == 0) {
            if (in_R8 != (uint64_t *)0x0) {
                *in_R8 = uVar9;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257292;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x1802572aa;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000058 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7));
        } else {
            if (uVar9 <= in_R9) {
                if (*(int32_t *)((int64_t)&arg_e0h + iVar8 + iVar7) != 0) {
                    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257317;
                    puVar10 = (undefined4 *)
                              func_0x000180229bc0((int64_t)&arg_a0h + iVar8 + iVar7, 0x1804bb8e0, 
                                                  (int64_t)&arg_e0h + iVar8 + iVar7);
                    uVar3 = puVar10[1];
                    uVar4 = puVar10[2];
                    uVar5 = puVar10[3];
                    *(undefined4 *)((int64_t)&arg_50h + iVar8 + iVar7) = *puVar10;
                    *(undefined4 *)((int64_t)&arg_50h + iVar8 + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000058 + iVar8 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000005c + iVar8 + iVar7) = uVar5;
                    uVar3 = puVar10[5];
                    uVar4 = puVar10[6];
                    uVar5 = puVar10[7];
                    *(undefined4 *)((int64_t)&arg_60h + iVar8 + iVar7) = puVar10[4];
                    *(undefined4 *)((int64_t)&arg_60h + iVar8 + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000068 + iVar8 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000006c + iVar8 + iVar7) = uVar5;
                    *(undefined8 *)((int64_t)&arg_70h + iVar8 + iVar7) = *(undefined8 *)(puVar10 + 8);
                    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257340;
                    puVar10 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_a0h + iVar8 + iVar7);
                    uVar3 = puVar10[1];
                    uVar4 = puVar10[2];
                    uVar5 = puVar10[3];
                    *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7) = *puVar10;
                    *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7 + 4) = uVar3;
                    *(undefined4 *)((int64_t)&arg_80h + iVar8 + iVar7) = uVar4;
                    *(undefined4 *)((int64_t)&arg_80h + iVar8 + iVar7 + 4) = uVar5;
                    uVar3 = puVar10[5];
                    uVar4 = puVar10[6];
                    uVar5 = puVar10[7];
                    *(undefined4 *)((int64_t)&arg_88h + iVar8 + iVar7) = puVar10[4];
                    *(undefined4 *)((int64_t)&arg_88h + iVar8 + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000090 + iVar8 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x00000094 + iVar8 + iVar7) = uVar5;
                    iVar1 = *piVar12;
                    *(undefined8 *)((int64_t)&arg_98h + iVar8 + iVar7) = *(undefined8 *)(puVar10 + 8);
                    pcVar2 = *(code **)(iVar1 + 0x80);
                    if (pcVar2 != (code *)0x0) {
                        iVar1 = piVar12[1];
                        *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257377;
                        iVar6 = (*pcVar2)(iVar1, (int64_t)&arg_50h + iVar8 + iVar7);
                        if (iVar6 < 1) {
                            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257380;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x180257398;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7), 
                                          *(int64_t *)(&stack0x00000058 + iVar8 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7));
                            goto code_r0x0001802573e9;
                        }
                    }
                }
                iVar1 = piVar12[1];
                pcVar2 = *(code **)(*piVar12 + 0x50);
                *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x1802573b8;
                uVar11 = (*pcVar2)(iVar1, in_RDX, (int64_t)&arg_40h + iVar8 + iVar7, in_R9);
                if (in_R8 == (uint64_t *)0x0) {
                    return uVar11;
                }
                *in_R8 = *(uint64_t *)((int64_t)&arg_40h + iVar8 + iVar7);
                return uVar11;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x1802572cb;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x1802572e3;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000058 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7));
        }
    }
code_r0x0001802573e9:
    *(undefined8 *)((int64_t)auStackX_18 + iVar8 + iVar7) = 0x1802573f6;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1801a8950
// Address: 0x1801a8950
// Size: 65 bytes
// ============================================================
void fcn.1801a8950(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801a8960;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)arg1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a896e;
        fcn.180257070(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8976;
        fcn.1801bc880(arg1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a898b;
        fcn.180224990(arg1, 0x1804aeee0, 0x12fc);
    }
    return;
}

// ============================================================
// Function: FUN_1801a89a0
// Address: 0x1801a89a0
// Size: 225 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801a89a0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    int64_t *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a89ba;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a89e6;
        puVar7 = (undefined4 *)func_0x000180229e30((int64_t)&var_18h + iVar6, 0x1804af254, in_R9, 0);
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar6) = *puVar7;
        *(undefined4 *)((int64_t)&arg_48h + iVar6 + 4) = uVar2;
        *(undefined4 *)(&stack0x00000050 + iVar6) = uVar3;
        *(undefined4 *)(&stack0x00000054 + iVar6) = uVar4;
        uVar2 = puVar7[5];
        uVar3 = puVar7[6];
        uVar4 = puVar7[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar6) = puVar7[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar6 + 4) = uVar2;
        *(undefined4 *)(&stack0x00000060 + iVar6) = uVar3;
        *(undefined4 *)(&stack0x00000064 + iVar6) = uVar4;
        *(undefined8 *)((int64_t)&arg_68h + iVar6) = *(undefined8 *)(puVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a8a0c;
        puVar7 = (undefined4 *)func_0x000180229ba0((int64_t)&var_18h + iVar6);
        iVar1 = *in_RCX;
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)((int64_t)&arg_70h + iVar6) = *puVar7;
        *(undefined4 *)((int64_t)&arg_70h + iVar6 + 4) = uVar2;
        *(undefined4 *)(&stack0x00000078 + iVar6) = uVar3;
        *(undefined4 *)(&stack0x0000007c + iVar6) = uVar4;
        uVar2 = puVar7[5];
        uVar3 = puVar7[6];
        uVar4 = puVar7[7];
        *(undefined4 *)((int64_t)&arg_80h + iVar6) = puVar7[4];
        *(undefined4 *)((int64_t)&arg_80h + iVar6 + 4) = uVar2;
        *(undefined4 *)(&stack0x00000088 + iVar6) = uVar3;
        *(undefined4 *)(&stack0x0000008c + iVar6) = uVar4;
        *(undefined8 *)((int64_t)&arg_90h + iVar6) = *(undefined8 *)(puVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a8a41;
        iVar5 = func_0x000180257420(iVar1, in_RDX, in_R8, (int64_t)&arg_48h + iVar6);
        if (iVar5 != 0) {
            return 1;
        }
    }
    if (in_RCX[1] == 0) {
        uVar8 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a8a64;
        uVar8 = func_0x0001801bc8a0(in_RCX, in_RDX, in_R8, in_R9);
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801a8a90
// Address: 0x1801a8a90
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t * fcn.1801a8a90(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a8aa5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8ac2;
    piVar3 = (int64_t *)
             fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000040 + iVar2));
    iVar4 = 0;
    if (piVar3 != (int64_t *)0x0) {
        if ((*(int64_t *)(in_RCX + 0x260) == 0) && (*(int64_t *)(in_RCX + 600) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8aea;
            iVar1 = fcn.1801bc900(piVar3);
            if (iVar1 != 0) {
                return piVar3;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8b17;
            iVar4 = fcn.180256ae0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8b27;
                iVar5 = fcn.1802570e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
                *piVar3 = iVar5;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8b37;
                    fcn.180256b30(iVar4);
                    return piVar3;
                }
            }
        }
        iVar5 = *piVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8b52;
        fcn.180257070(iVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8b5a;
        fcn.180256b30(iVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a8b6f;
        fcn.180224990(piVar3, 0x1804aeee0, 0x12f1);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1801a8b90
// Address: 0x1801a8b90
// Size: 56 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018025c50f: Changing call to branch
// WARNING: Possible PIC construction at 0x00018025cdcc: Changing call to branch

uint64_t fcn.1801a8b90(int64_t arg_98h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_d8h,
                      int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h)
{
    uint32_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t **in_RCX;
    int64_t iVar10;
    int64_t *piVar11;
    undefined8 in_RDX;
    int32_t *unaff_RBX;
    undefined *puVar12;
    undefined8 *puVar13;
    undefined8 *puVar14;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    piVar11 = *in_RCX;
    if (piVar11 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar6) = 0x1802574ca;
        fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x0001802574dc. Too many branches
    // WARNING: Treating indirect jump as call
        uVar9 = (**(code **)(*piVar11 + 0x48))(piVar11[1]);
        return uVar9;
    }
    if (in_RCX[1] == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar6) = 0x1801bc95a;
    iVar7 = fcn.18045a350();
    piVar11 = in_RCX[1];
    *(undefined8 *)(&stack0x00000048 + -iVar7 + iVar6) = 0x18021d94a;
    iVar8 = fcn.18045a350();
    if (*piVar11 == 0) {
        return 0;
    }
    iVar10 = piVar11[1];
    puVar12 = &stack0x00000078 + ((-iVar7 + iVar6) - iVar8);
    while( true ) {
        *(undefined8 *)(puVar12 + -8) = 0x1802149ba;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        if (in_R8 == 0) {
            return 1;
        }
        if ((*(uint32_t *)(iVar10 + 0x18) >> 0xb & 1) != 0) break;
        puVar1 = *(uint32_t **)(iVar10 + 0x28);
        if (((puVar1 == (uint32_t *)0x0) || (uVar4 = *puVar1, (uVar4 & 0xc1f0) == 0)) ||
           (*(int64_t *)(puVar1 + 0xc) == 0)) {
            iVar7 = *(int64_t *)(iVar10 + 8);
            if (((iVar7 == 0) || (*(int64_t *)(iVar7 + 0x68) == 0)) || ((*(uint32_t *)(iVar10 + 0x18) >> 8 & 1) != 0)) {
                if (*(code **)(iVar10 + 0x30) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180214abd. Too many branches
    // WARNING: Treating indirect jump as call
                    uVar9 = (**(code **)(iVar10 + 0x30))();
                    return uVar9;
                }
                return 0;
            }
            if (*(code **)(iVar7 + 0x88) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180214aa6. Too many branches
    // WARNING: Treating indirect jump as call
                uVar9 = (**(code **)(iVar7 + 0x88))(*(undefined8 *)(iVar10 + 0x38), in_RDX);
                return uVar9;
            }
            *(undefined8 *)(puVar12 + iVar6 + -8) = 0x180214a8a;
            fcn.180229480(*(int64_t *)(puVar12 + iVar6 + 0x20), *(int64_t *)(puVar12 + iVar6 + 0x28));
            goto code_r0x0001802149eb;
        }
        if (uVar4 == 0x80) {
            *(int32_t **)(puVar12 + iVar6 + 0x38) = unaff_RBX;
            *(int64_t *)(puVar12 + iVar6 + 0x40) = unaff_RBP;
            *(int64_t *)(puVar12 + iVar6 + 0x48) = unaff_RSI;
            *(undefined8 *)(puVar12 + iVar6 + 0x20) = unaff_R14;
            *(undefined8 *)(puVar12 + iVar6 + 0x18) = 0x18025c35b;
            unaff_RBP = in_R8;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            unaff_RBX = *(int32_t **)(iVar10 + 0x28);
            if ((*(uint32_t *)(iVar10 + 0x18) & 0x800) != 0) {
                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c379;
                fcn.180229480(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48)
                             );
                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c391;
                fcn.1802295a0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48)
                              , *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x50), 
                              *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x58), *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x70)
                             );
                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c3a3;
                fcn.1802296d0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60));
                return 0;
            }
            *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60) = unaff_RDI;
            if (unaff_RBX != (int32_t *)0x0) {
                if (((*unaff_RBX == 0x80) && (*(int64_t *)(unaff_RBX + 0xc) != 0)) &&
                   (unaff_RDI = *(int64_t *)(unaff_RBX + 10), unaff_RDI != 0)) {
                    iVar8 = 0x1805aadb1;
                    if (*(int64_t *)(unaff_RDI + 0x10) != 0) {
                        iVar8 = *(int64_t *)(unaff_RDI + 0x10);
                    }
                    if (*(int64_t *)(unaff_RDI + 0x98) != 0) {
                        *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c440;
                        func_0x000180229b10();
                        pcVar2 = *(code **)(unaff_RDI + 0x98);
                        uVar3 = *(undefined8 *)(unaff_RBX + 0xc);
                        *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c453;
                        uVar4 = (*pcVar2)(uVar3, in_RDX, unaff_RBP);
                        if ((int32_t)uVar4 < 1) {
                            *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c45e;
                            iVar5 = func_0x000180229970();
                            if (iVar5 == 0) {
                                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c467;
                                fcn.180229480(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                              *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48));
                                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c47f;
                                fcn.1802295a0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                              *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48), 
                                              *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x50), 
                                              *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x58), 
                                              *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x70));
                                *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40) = iVar8;
                                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c49e;
                                fcn.1802296d0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60));
                            }
                        }
                        *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c4a3;
                        func_0x000180229900();
                        return (uint64_t)uVar4;
                    }
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c3fd;
                    fcn.180229480(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48));
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c415;
                    fcn.1802295a0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x50), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x58), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x70));
                    *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40) = iVar8;
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c434;
                    fcn.1802296d0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60));
                    return 0;
                }
                if (*(int64_t *)(unaff_RBX + 0x1e) == 0) {
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c4b5;
                    fcn.180229480(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48));
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c4cd;
                    fcn.1802295a0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x50), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x58), 
                                  *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x70));
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c4df;
                    fcn.1802296d0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60));
                    return 0;
                }
                if ((*(uint8_t *)(unaff_RBX + 0x28) & 1) != 0) {
                    pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1e) + 0xf8);
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025c4fb;
                    iVar5 = (*pcVar2)(unaff_RBX, iVar10);
                    if (iVar5 == 0) {
                        return 0;
                    }
                }
                unaff_RBX[0x28] = unaff_RBX[0x28] & 0xfffffffe;
            }
            puVar13 = (undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18);
            puVar12 = puVar12 + iVar7 + iVar6 + 0x18;
            *puVar13 = 0x18025c514;
            unaff_RSI = iVar10;
            in_R8 = unaff_RBP;
            unaff_R14 = in_RDX;
        } else {
            if (uVar4 != 0x100) {
                *(undefined8 *)(puVar12 + iVar6 + -8) = 0x180214a54;
                fcn.180229480(*(int64_t *)(puVar12 + iVar6 + 0x20), *(int64_t *)(puVar12 + iVar6 + 0x28));
                goto code_r0x0001802149eb;
            }
            *(int32_t **)(puVar12 + iVar6 + 0x38) = unaff_RBX;
            *(int64_t *)(puVar12 + iVar6 + 0x40) = unaff_RBP;
            *(int64_t *)(puVar12 + iVar6 + 0x48) = unaff_RSI;
            *(undefined8 *)(puVar12 + iVar6 + 0x20) = unaff_R14;
            *(undefined8 *)(puVar12 + iVar6 + 0x18) = 0x18025cc4b;
            unaff_RBP = in_R8;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            unaff_RBX = *(int32_t **)(iVar10 + 0x28);
            if ((*(uint32_t *)(iVar10 + 0x18) & 0x800) != 0) {
                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cc69;
                fcn.180229480(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48)
                             );
                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cc81;
                fcn.1802295a0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48)
                              , *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x50), 
                              *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x58), *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x70)
                             );
                *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cc93;
                fcn.1802296d0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60));
                return 0;
            }
            *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60) = unaff_RDI;
            if (unaff_RBX != (int32_t *)0x0) {
                if (((*unaff_RBX == 0x100) && (*(int64_t *)(unaff_RBX + 0xc) != 0)) &&
                   (unaff_RDI = *(int64_t *)(unaff_RBX + 10), unaff_RDI != 0)) {
                    iVar8 = 0x1805aadb1;
                    if (*(int64_t *)(unaff_RDI + 0x10) != 0) {
                        iVar8 = *(int64_t *)(unaff_RDI + 0x10);
                    }
                    if (*(int64_t *)(unaff_RDI + 0xb8) == 0) {
                        *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cced;
                        fcn.180229480(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                      *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48));
                        *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd05;
                        fcn.1802295a0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                      *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48), 
                                      *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x50), 
                                      *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x58), 
                                      *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x70));
                        *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40) = iVar8;
                        *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd24;
                        fcn.1802296d0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60));
                        return 0;
                    }
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd30;
                    func_0x000180229b10();
                    pcVar2 = *(code **)(unaff_RDI + 0xb8);
                    uVar3 = *(undefined8 *)(unaff_RBX + 0xc);
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd43;
                    uVar4 = (*pcVar2)(uVar3, in_RDX, unaff_RBP);
                    if ((int32_t)uVar4 < 1) {
                        *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd4e;
                        iVar5 = func_0x000180229970();
                        if (iVar5 == 0) {
                            *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd57;
                            fcn.180229480(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                          *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48));
                            *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd6f;
                            fcn.1802295a0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40), 
                                          *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x48), 
                                          *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x50), 
                                          *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x58), 
                                          *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x70));
                            *(int64_t *)(puVar12 + iVar7 + iVar6 + 0x40) = iVar8;
                            *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd8e;
                            fcn.1802296d0(*(int64_t *)(puVar12 + iVar7 + iVar6 + 0x60));
                        }
                    }
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cd93;
                    func_0x000180229900();
                    return (uint64_t)uVar4;
                }
                if ((*(uint8_t *)(unaff_RBX + 0x28) & 1) != 0) {
                    pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1e) + 0xf8);
                    *(undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18) = 0x18025cdb4;
                    iVar5 = (*pcVar2)(unaff_RBX, iVar10);
                    if (iVar5 == 0) {
                        return 0;
                    }
                }
                unaff_RBX[0x28] = unaff_RBX[0x28] & 0xfffffffe;
            }
            puVar14 = (undefined8 *)(puVar12 + iVar7 + iVar6 + 0x18);
            puVar12 = puVar12 + iVar7 + iVar6 + 0x18;
            *puVar14 = 0x18025cdd1;
            unaff_RSI = iVar10;
            in_R8 = unaff_RBP;
            unaff_R14 = in_RDX;
        }
    }
    *(undefined8 *)(puVar12 + iVar6 + -8) = 0x1802149df;
    fcn.180229480(*(int64_t *)(puVar12 + iVar6 + 0x20), *(int64_t *)(puVar12 + iVar6 + 0x28));
code_r0x0001802149eb:
    *(undefined8 *)(puVar12 + iVar6 + -8) = 0x1802149f7;
    fcn.1802295a0(*(int64_t *)(puVar12 + iVar6 + 0x20), *(int64_t *)(puVar12 + iVar6 + 0x28), 
                  *(int64_t *)(puVar12 + iVar6 + 0x30), *(int64_t *)(puVar12 + iVar6 + 0x38), 
                  *(int64_t *)(puVar12 + iVar6 + 0x50));
    *(undefined8 *)(puVar12 + iVar6 + -8) = 0x180214a09;
    fcn.1802296d0(*(int64_t *)(puVar12 + iVar6 + 0x40));
    return 0;
}

// ============================================================
// Function: FUN_1801a8bd0
// Address: 0x1801a8bd0
// Size: 74 bytes
// ============================================================
uint64_t fcn.1801a8bd0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                      int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_f8h,
                      int64_t arg_100h, int64_t arg_110h, int64_t arg_210h)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int64_t iVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar12;
    undefined8 unaff_RDI;
    uint32_t uVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    undefined8 unaff_R14;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a8bdc;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801a8bf4;
    uVar9 = fcn.18025b140(*(int64_t *)((int64_t)&arg_40h + iVar8), *(int64_t *)((int64_t)&arg_48h + iVar8), 
                          *(int64_t *)((int64_t)&arg_50h + iVar8), *(int64_t *)(&stack0x00000058 + iVar8));
    if ((int32_t)uVar9 == 0) {
        return uVar9;
    }
    uVar15 = 0x1804aea20;
    uVar14 = 0;
    iVar5 = 0x5c;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = *(undefined8 *)((int64_t)auStackX_10 + iVar8 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar8 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar8) = 0x180191a30;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar4 = iVar7 + iVar8 + 0x18;
    uVar13 = (uint32_t)uVar14;
    uVar9 = (uint64_t)(int32_t)uVar13;
    if ((iVar5 == 0x5c) && (uVar13 == 1)) {
        *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar8) = uVar15;
        *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar7 + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar8) = 0;
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar8) = 0x180191a69;
        uVar9 = fcn.1801abdc0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar8), 
                              *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar8), 
                              *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar8), 
                              *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar8), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar8), 
                              *(int64_t *)(&stack0x000000a8 + iVar7 + iVar8), 
                              *(int64_t *)(&stack0x000000b0 + iVar7 + iVar8));
        return uVar9;
    }
    if (in_RCX == 0) {
        if ((iVar5 - 0x62U & 0xfffffffb) != 0) {
            return 0;
        }
        iVar5 = 0;
        iVar11 = 0;
        iVar10 = 0;
        uVar12 = *(undefined8 *)(&stack0x00000058 + iVar7 + iVar8);
        *(undefined8 *)(&stack0x00000058 + iVar7 + iVar8) = *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar8);
        *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar8) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar8) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_40h + iVar7 + iVar8 + 0x18 + -0x18) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar8) = 0x1801ac790;
        iVar7 = fcn.18045a350(0, 0, uVar15);
        iVar7 = -iVar7;
        *(uint64_t *)((int64_t)&arg_100h + iVar7 + iVar4 + -0x18) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&arg_40h + iVar7 + iVar4 + -0x18;
        iVar8 = *(int64_t *)((int64_t)&arg_f8h + iVar7 + iVar4 + -0x18);
        *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar4 + -0x18) = 0;
        if (iVar10 != 0) {
            iVar8 = iVar10;
        }
        *(int64_t *)((int64_t)&arg_f8h + iVar7 + iVar4 + -0x18) = iVar8;
        *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar4 + -0x18) = (int64_t)&arg_70h + iVar7 + iVar4 + -0x18;
        *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac7f0;
        iVar6 = fcn.18024a850(*(int64_t *)((int64_t)&arg_68h + iVar7 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)&arg_70h + iVar7 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar4 + -0x18), 
                              *(int64_t *)(&stack0x00000088 + iVar7 + iVar4 + -0x18));
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&arg_110h + iVar7 + iVar4 + -0x18) = uVar12;
            iVar8 = *(int64_t *)((int64_t)&arg_70h + iVar7 + iVar4 + -0x18);
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac80f;
                fcn.180229480(*(int64_t *)((int64_t)&arg_60h + iVar7 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar4 + -0x18));
                *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac827;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_60h + iVar7 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)&arg_70h + iVar7 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar4 + -0x18), 
                              *(int64_t *)(&stack0x00000090 + iVar7 + iVar4 + -0x18));
                *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac840;
                fcn.1802296d0(*(int64_t *)(&stack0x00000080 + iVar7 + iVar4 + -0x18));
            } else if (iVar11 != 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac86d;
                iVar10 = fcn.180224ed0(*(int64_t *)((int64_t)&arg_60h + iVar7 + iVar4 + -0x18));
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac886;
                    fcn.180498030(iVar10, (int64_t)&arg_78h + iVar7 + iVar4 + -0x18, iVar8 * 2);
                    if (iVar5 == 0) {
                        uVar15 = *(undefined8 *)(iVar11 + 0x40);
                        *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac8ba;
                        fcn.180224990(uVar15, 0x1804aeee0, 0xf17);
                        *(int64_t *)(iVar11 + 0x40) = iVar10;
                        *(int64_t *)(iVar11 + 0x48) = iVar8;
                    } else {
                        uVar15 = *(undefined8 *)(iVar11 + 0x50);
                        *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac8a1;
                        fcn.180224990(uVar15, 0x1804aeee0, 0xf13);
                        *(int64_t *)(iVar11 + 0x50) = iVar10;
                        *(int64_t *)(iVar11 + 0x58) = iVar8;
                    }
                }
            }
        }
        uVar9 = *(uint64_t *)((int64_t)&arg_100h + iVar7 + iVar4 + -0x18);
        *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar4 + -0x18) = 0x1801ac8e1;
        uVar9 = fcn.180459870(uVar9 ^ (int64_t)&arg_40h + iVar7 + iVar4 + -0x18);
        return uVar9;
    }
    // switch table (116 cases) at 0x180191e00
    switch(iVar5) {
    case 0x10:
        *(undefined8 *)(in_RCX + 0x178) = uVar15;
        return 1;
    default:
    // WARNING: Could not recover jumptable at 0x000180191dfb. Too many branches
    // WARNING: Treating indirect jump as call
        uVar9 = (**(code **)(*(int64_t *)(in_RCX + 8) + 0xa0))(in_RCX);
        return uVar9;
    case 0x14:
        if (*(int64_t *)(in_RCX + 0x30) == 0) {
            return 0;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(in_RCX + 0x30) + 0x50);
    case 0x15:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x78);
    case 0x16:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x80);
    case 0x17:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x7c);
    case 0x18:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x84);
    case 0x19:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x8c);
    case 0x1a:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x88);
    case 0x1b:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x9c);
    case 0x1c:
        return (uint64_t)*(uint32_t *)(in_RCX + 0xa0);
    case 0x1d:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x90);
    case 0x1e:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x94);
    case 0x1f:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x98);
    case 0x21:
        *(uint32_t *)(in_RCX + 0x140) = *(uint32_t *)(in_RCX + 0x140) | uVar13;
        return (uint64_t)*(uint32_t *)(in_RCX + 0x140);
    case 0x28:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x168);
    case 0x29:
        uVar2 = *(uint32_t *)(in_RCX + 0x168);
        *(uint32_t *)(in_RCX + 0x168) = uVar13;
        return (uint64_t)uVar2;
    case 0x2a:
        if (-1 < (int32_t)uVar13) {
            uVar13 = *(uint32_t *)(in_RCX + 0x38);
            *(uint64_t *)(in_RCX + 0x38) = uVar9;
            return (uint64_t)uVar13;
        }
        break;
    case 0x2b:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x38);
    case 0x2c:
        uVar2 = *(uint32_t *)(in_RCX + 0x50);
        *(uint32_t *)(in_RCX + 0x50) = uVar13;
        return (uint64_t)uVar2;
    case 0x2d:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x50);
    case 0x32:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x150);
    case 0x33:
        if (-1 < (int32_t)uVar13) {
            uVar13 = *(uint32_t *)(in_RCX + 0x150);
            *(uint64_t *)(in_RCX + 0x150) = uVar9;
            return (uint64_t)uVar13;
        }
        break;
    case 0x34:
        if (uVar13 - 0x200 < 0x3e01) {
            *(uint64_t *)(in_RCX + 0x1f0) = uVar9;
            if (uVar9 < *(uint64_t *)(in_RCX + 0x1e8)) {
                *(uint64_t *)(in_RCX + 0x1e8) = uVar9;
            }
            return 1;
        }
        break;
    case 0x4e:
        *(uint32_t *)(in_RCX + 0x140) = *(uint32_t *)(in_RCX + 0x140) & ~uVar13;
        return (uint64_t)*(uint32_t *)(in_RCX + 0x140);
    case 99:
        iVar8 = *(int64_t *)(in_RCX + 0x158);
        puVar1 = (uint32_t *)(iVar8 + 0x1c);
        *puVar1 = *puVar1 | uVar13;
        return (uint64_t)*(uint32_t *)(iVar8 + 0x1c);
    case 100:
        iVar8 = *(int64_t *)(in_RCX + 0x158);
        puVar1 = (uint32_t *)(iVar8 + 0x1c);
        *puVar1 = *puVar1 & ~uVar13;
        return (uint64_t)*(uint32_t *)(iVar8 + 0x1c);
    case 0x7b:
        uVar3 = *(undefined4 *)(in_RCX + 0x148);
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar8) = 0x180191d57;
        iVar5 = fcn.180197230(uVar14 & 0xffffffff, uVar3);
        if (iVar5 == 0) {
            return 0;
        }
        uVar3 = **(undefined4 **)(in_RCX + 8);
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar8) = 0x180191d6f;
        iVar5 = fcn.1801afd20(uVar3, uVar14 & 0xffffffff, in_RCX + 0x144);
        if (iVar5 == 0) {
            return 0;
        }
        return 1;
    case 0x7c:
        uVar3 = *(undefined4 *)(in_RCX + 0x144);
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar8) = 0x180191da4;
        iVar5 = fcn.180197230(uVar3, uVar14 & 0xffffffff);
        if (iVar5 != 0) {
            uVar3 = **(undefined4 **)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar8) = 0x180191dba;
            iVar5 = fcn.1801afd20(uVar3);
            if (iVar5 != 0) {
                return 1;
            }
        }
        return 0;
    case 0x7d:
        if ((uVar9 <= *(uint64_t *)(in_RCX + 0x1f0)) && (uVar13 != 0)) {
            *(uint64_t *)(in_RCX + 0x1e8) = uVar9;
            return 1;
        }
        break;
    case 0x7e:
        if (uVar13 - 1 < 0x20) {
            *(uint64_t *)(in_RCX + 0x1f8) = uVar9;
            return 1;
        }
        break;
    case 0x82:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x144);
    case 0x83:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x148);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a8c20
// Address: 0x1801a8c20
// Size: 125 bytes
// ============================================================
undefined8 fcn.1801a8c20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a8c2c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c44;
    iVar2 = fcn.18025b140(*(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
    if (iVar2 == 0) {
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x680) != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x160);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c73;
        fcn.180224990(uVar1, 0x1804aeee0, 0x2b2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c91;
        iVar5 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(int64_t *)(in_RCX + 0x160) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
        uVar6 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        if (*(int64_t *)(in_RCX + 0x680) != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8cd1;
                uVar3 = fcn.18022d1b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + uVar6 * 8) = uVar3;
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + 4 + uVar6 * 8) = 0;
                uVar6 = uVar6 + 1;
            } while (uVar6 < *(uint64_t *)(in_RCX + 0x680));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a8c9d
// Address: 0x1801a8c9d
// Size: 23 bytes
// ============================================================
undefined8 fcn.1801a8c20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a8c2c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c44;
    iVar2 = fcn.18025b140(*(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
    if (iVar2 == 0) {
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x680) != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x160);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c73;
        fcn.180224990(uVar1, 0x1804aeee0, 0x2b2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c91;
        iVar5 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(int64_t *)(in_RCX + 0x160) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
        uVar6 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        if (*(int64_t *)(in_RCX + 0x680) != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8cd1;
                uVar3 = fcn.18022d1b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + uVar6 * 8) = uVar3;
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + 4 + uVar6 * 8) = 0;
                uVar6 = uVar6 + 1;
            } while (uVar6 < *(uint64_t *)(in_RCX + 0x680));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a8cb4
// Address: 0x1801a8cb4
// Size: 71 bytes
// ============================================================
undefined8 fcn.1801a8c20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a8c2c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c44;
    iVar2 = fcn.18025b140(*(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
    if (iVar2 == 0) {
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x680) != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x160);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c73;
        fcn.180224990(uVar1, 0x1804aeee0, 0x2b2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c91;
        iVar5 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(int64_t *)(in_RCX + 0x160) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
        uVar6 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        if (*(int64_t *)(in_RCX + 0x680) != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8cd1;
                uVar3 = fcn.18022d1b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + uVar6 * 8) = uVar3;
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + 4 + uVar6 * 8) = 0;
                uVar6 = uVar6 + 1;
            } while (uVar6 < *(uint64_t *)(in_RCX + 0x680));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a8cfb
// Address: 0x1801a8cfb
// Size: 10 bytes
// ============================================================
undefined8 fcn.1801a8c20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a8c2c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c44;
    iVar2 = fcn.18025b140(*(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
    if (iVar2 == 0) {
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x680) != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x160);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c73;
        fcn.180224990(uVar1, 0x1804aeee0, 0x2b2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c91;
        iVar5 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(int64_t *)(in_RCX + 0x160) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
        uVar6 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        if (*(int64_t *)(in_RCX + 0x680) != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8cd1;
                uVar3 = fcn.18022d1b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + uVar6 * 8) = uVar3;
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + 4 + uVar6 * 8) = 0;
                uVar6 = uVar6 + 1;
            } while (uVar6 < *(uint64_t *)(in_RCX + 0x680));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a8d05
// Address: 0x1801a8d05
// Size: 19 bytes
// ============================================================
undefined8 fcn.1801a8c20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a8c2c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c44;
    iVar2 = fcn.18025b140(*(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
    if (iVar2 == 0) {
        return 0;
    }
    if (*(int64_t *)(in_RCX + 0x680) != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x160);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c73;
        fcn.180224990(uVar1, 0x1804aeee0, 0x2b2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8c91;
        iVar5 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(int64_t *)(in_RCX + 0x160) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
        uVar6 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        if (*(int64_t *)(in_RCX + 0x680) != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a8cd1;
                uVar3 = fcn.18022d1b0(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + uVar6 * 8) = uVar3;
                *(undefined4 *)(*(int64_t *)(in_RCX + 0x160) + 4 + uVar6 * 8) = 0;
                uVar6 = uVar6 + 1;
            } while (uVar6 < *(uint64_t *)(in_RCX + 0x680));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a8d20
// Address: 0x1801a8d20
// Size: 422 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801a8d20(int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_68h, int64_t arg_d8h)
{
    undefined4 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined8 in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801a8d3c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0xffffffff;
    uVar7 = 0x1000;
    if (in_R9D == 0) {
        uVar7 = 0;
    }
    uVar1 = 0xffffffff;
    if (*(int32_t *)((int64_t)&arg_68h + iVar4) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8dc7;
        iVar5 = func_0x000180238400(in_R8);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8dd4;
            uVar1 = func_0x00018022fb60(iVar5);
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = in_R8;
        if (in_RCX == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8dfc;
            iVar2 = func_0x0001801a25e0(in_RDX, uVar7 | 0x60011, uVar1, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8df2;
            iVar2 = func_0x0001801a2690(in_RCX);
        }
        if (iVar2 == 0) {
            return 0x18d;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8d78;
        iVar5 = func_0x000180238400(in_R8);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8d85;
            uVar1 = func_0x00018022fb60(iVar5);
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = in_R8;
        if (in_RCX == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8dad;
            iVar2 = func_0x0001801a25e0(in_RDX, uVar7 | 0x60010, uVar1, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8da3;
            iVar2 = func_0x0001801a2690(in_RCX);
        }
        if (iVar2 == 0) {
            return 399;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8e18;
    uVar3 = func_0x00018023bbb0(in_R8);
    if ((uVar3 >> 0xd & 1) == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8e48;
        iVar2 = func_0x000180237500(in_R8, (int64_t)&arg_60h + iVar4, (int64_t)&var_8h + iVar4, 
                                    (int64_t)&arg_68h + iVar4);
        if (iVar2 == 0) {
            *(undefined4 *)((int64_t)&arg_68h + iVar4) = 0xffffffff;
        } else {
            uVar8 = *(undefined4 *)((int64_t)&arg_68h + iVar4);
        }
        if (*(int32_t *)((int64_t)&arg_60h + iVar4) == 0) {
            *(undefined4 *)((int64_t)&arg_60h + iVar4) = *(undefined4 *)((int64_t)&var_8h + iVar4);
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = in_R8;
        if (in_RCX == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8e97;
            iVar2 = func_0x0001801a25e0(in_RDX, uVar7 | 0x60012, uVar8);
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8e8d;
            iVar2 = func_0x0001801a2690(in_RCX);
        }
        uVar6 = 1;
        if (iVar2 == 0) {
            uVar6 = 0x18e;
        }
    } else {
        uVar6 = 1;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801a8ed0
// Address: 0x1801a8ed0
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801a8ed0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar7;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    uint32_t uVar8;
    undefined8 unaff_R15;
    int32_t iStackX_8;
    int64_t var_ch;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a8ee6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar7 = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f07;
        in_R8 = func_0x000180222340(in_RDX, 0);
        if (in_R8 == 0) {
            return 0xc0103;
        }
        iVar7 = 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R15;
    uVar8 = 0x1000;
    if (in_R9D == 0) {
        uVar8 = 0;
    }
    uVar1 = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f50;
    iVar5 = func_0x000180238400(in_R8);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f5d;
        uVar1 = func_0x00018022fb60(iVar5);
    }
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_R8;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f83;
        iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60010, uVar1, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f7a;
        iVar2 = func_0x0001801a2690(in_RCX);
    }
    if (iVar2 == 0) {
        uVar6 = 399;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8fa3;
        uVar3 = func_0x00018023bbb0(in_R8);
        if ((uVar3 >> 0xd & 1) == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8fc8;
            iVar2 = func_0x000180237500(in_R8, (int64_t)&iStackX_8 + iVar4, (int64_t)&var_ch + iVar4, 
                                        (int64_t)&arg_58h + iVar4);
            if (iVar2 == 0) {
                uVar1 = 0xffffffff;
                *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0xffffffff;
            } else {
                uVar1 = *(undefined4 *)((int64_t)&arg_58h + iVar4);
            }
            if (*(int32_t *)((int64_t)&iStackX_8 + iVar4) == 0) {
                *(undefined4 *)((int64_t)&iStackX_8 + iVar4) = *(undefined4 *)((int64_t)&var_ch + iVar4);
            }
            *(int64_t *)((int64_t)&var_8h + iVar4) = in_R8;
            if (in_RCX == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9016;
                iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60012, uVar1);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a900d;
                iVar2 = func_0x0001801a2690(in_RCX);
            }
            if (iVar2 == 0) {
                return 0x18e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a902c;
        iVar2 = func_0x000180222010(in_RDX);
        if (iVar7 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a904a;
                uVar6 = func_0x000180222340(in_RDX, iVar7);
                uVar1 = 0xffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a905a;
                iVar5 = func_0x000180238400(uVar6);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9067;
                    uVar1 = func_0x00018022fb60(iVar5);
                }
                *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar6;
                if (in_RCX == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a908d;
                    iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60011, uVar1, 0);
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9084;
                    iVar2 = func_0x0001801a2690(in_RCX);
                }
                if (iVar2 == 0) {
                    return 0x18d;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a909d;
                uVar3 = func_0x00018023bbb0(uVar6);
                if ((uVar3 >> 0xd & 1) == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a90c2;
                    iVar2 = func_0x000180237500(uVar6, (int64_t)&iStackX_8 + iVar4, (int64_t)&var_ch + iVar4, 
                                                (int64_t)&arg_58h + iVar4);
                    if (iVar2 == 0) {
                        uVar1 = 0xffffffff;
                        *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0xffffffff;
                    } else {
                        uVar1 = *(undefined4 *)((int64_t)&arg_58h + iVar4);
                    }
                    if (*(int32_t *)((int64_t)&iStackX_8 + iVar4) == 0) {
                        *(undefined4 *)((int64_t)&iStackX_8 + iVar4) = *(undefined4 *)((int64_t)&var_ch + iVar4);
                    }
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar6;
                    if (in_RCX == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9110;
                        iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60012, uVar1);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9107;
                        iVar2 = func_0x0001801a2690(in_RCX);
                    }
                    if (iVar2 == 0) {
                        return 0x18e;
                    }
                }
                iVar7 = iVar7 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9122;
                iVar2 = func_0x000180222010(in_RDX);
            } while (iVar7 < iVar2);
        }
        uVar6 = 1;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801a8f23
// Address: 0x1801a8f23
// Size: 534 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801a8ed0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar7;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    uint32_t uVar8;
    undefined8 unaff_R15;
    int32_t iStackX_8;
    int64_t var_ch;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a8ee6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar7 = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f07;
        in_R8 = func_0x000180222340(in_RDX, 0);
        if (in_R8 == 0) {
            return 0xc0103;
        }
        iVar7 = 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R15;
    uVar8 = 0x1000;
    if (in_R9D == 0) {
        uVar8 = 0;
    }
    uVar1 = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f50;
    iVar5 = func_0x000180238400(in_R8);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f5d;
        uVar1 = func_0x00018022fb60(iVar5);
    }
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_R8;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f83;
        iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60010, uVar1, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f7a;
        iVar2 = func_0x0001801a2690(in_RCX);
    }
    if (iVar2 == 0) {
        uVar6 = 399;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8fa3;
        uVar3 = func_0x00018023bbb0(in_R8);
        if ((uVar3 >> 0xd & 1) == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8fc8;
            iVar2 = func_0x000180237500(in_R8, (int64_t)&iStackX_8 + iVar4, (int64_t)&var_ch + iVar4, 
                                        (int64_t)&arg_58h + iVar4);
            if (iVar2 == 0) {
                uVar1 = 0xffffffff;
                *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0xffffffff;
            } else {
                uVar1 = *(undefined4 *)((int64_t)&arg_58h + iVar4);
            }
            if (*(int32_t *)((int64_t)&iStackX_8 + iVar4) == 0) {
                *(undefined4 *)((int64_t)&iStackX_8 + iVar4) = *(undefined4 *)((int64_t)&var_ch + iVar4);
            }
            *(int64_t *)((int64_t)&var_8h + iVar4) = in_R8;
            if (in_RCX == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9016;
                iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60012, uVar1);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a900d;
                iVar2 = func_0x0001801a2690(in_RCX);
            }
            if (iVar2 == 0) {
                return 0x18e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a902c;
        iVar2 = func_0x000180222010(in_RDX);
        if (iVar7 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a904a;
                uVar6 = func_0x000180222340(in_RDX, iVar7);
                uVar1 = 0xffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a905a;
                iVar5 = func_0x000180238400(uVar6);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9067;
                    uVar1 = func_0x00018022fb60(iVar5);
                }
                *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar6;
                if (in_RCX == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a908d;
                    iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60011, uVar1, 0);
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9084;
                    iVar2 = func_0x0001801a2690(in_RCX);
                }
                if (iVar2 == 0) {
                    return 0x18d;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a909d;
                uVar3 = func_0x00018023bbb0(uVar6);
                if ((uVar3 >> 0xd & 1) == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a90c2;
                    iVar2 = func_0x000180237500(uVar6, (int64_t)&iStackX_8 + iVar4, (int64_t)&var_ch + iVar4, 
                                                (int64_t)&arg_58h + iVar4);
                    if (iVar2 == 0) {
                        uVar1 = 0xffffffff;
                        *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0xffffffff;
                    } else {
                        uVar1 = *(undefined4 *)((int64_t)&arg_58h + iVar4);
                    }
                    if (*(int32_t *)((int64_t)&iStackX_8 + iVar4) == 0) {
                        *(undefined4 *)((int64_t)&iStackX_8 + iVar4) = *(undefined4 *)((int64_t)&var_ch + iVar4);
                    }
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar6;
                    if (in_RCX == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9110;
                        iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60012, uVar1);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9107;
                        iVar2 = func_0x0001801a2690(in_RCX);
                    }
                    if (iVar2 == 0) {
                        return 0x18e;
                    }
                }
                iVar7 = iVar7 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9122;
                iVar2 = func_0x000180222010(in_RDX);
            } while (iVar7 < iVar2);
        }
        uVar6 = 1;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801a9139
// Address: 0x1801a9139
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801a8ed0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar7;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    uint32_t uVar8;
    undefined8 unaff_R15;
    int32_t iStackX_8;
    int64_t var_ch;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a8ee6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar7 = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f07;
        in_R8 = func_0x000180222340(in_RDX, 0);
        if (in_R8 == 0) {
            return 0xc0103;
        }
        iVar7 = 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R15;
    uVar8 = 0x1000;
    if (in_R9D == 0) {
        uVar8 = 0;
    }
    uVar1 = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f50;
    iVar5 = func_0x000180238400(in_R8);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f5d;
        uVar1 = func_0x00018022fb60(iVar5);
    }
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_R8;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f83;
        iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60010, uVar1, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f7a;
        iVar2 = func_0x0001801a2690(in_RCX);
    }
    if (iVar2 == 0) {
        uVar6 = 399;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8fa3;
        uVar3 = func_0x00018023bbb0(in_R8);
        if ((uVar3 >> 0xd & 1) == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8fc8;
            iVar2 = func_0x000180237500(in_R8, (int64_t)&iStackX_8 + iVar4, (int64_t)&var_ch + iVar4, 
                                        (int64_t)&arg_58h + iVar4);
            if (iVar2 == 0) {
                uVar1 = 0xffffffff;
                *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0xffffffff;
            } else {
                uVar1 = *(undefined4 *)((int64_t)&arg_58h + iVar4);
            }
            if (*(int32_t *)((int64_t)&iStackX_8 + iVar4) == 0) {
                *(undefined4 *)((int64_t)&iStackX_8 + iVar4) = *(undefined4 *)((int64_t)&var_ch + iVar4);
            }
            *(int64_t *)((int64_t)&var_8h + iVar4) = in_R8;
            if (in_RCX == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9016;
                iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60012, uVar1);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a900d;
                iVar2 = func_0x0001801a2690(in_RCX);
            }
            if (iVar2 == 0) {
                return 0x18e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a902c;
        iVar2 = func_0x000180222010(in_RDX);
        if (iVar7 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a904a;
                uVar6 = func_0x000180222340(in_RDX, iVar7);
                uVar1 = 0xffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a905a;
                iVar5 = func_0x000180238400(uVar6);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9067;
                    uVar1 = func_0x00018022fb60(iVar5);
                }
                *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar6;
                if (in_RCX == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a908d;
                    iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60011, uVar1, 0);
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9084;
                    iVar2 = func_0x0001801a2690(in_RCX);
                }
                if (iVar2 == 0) {
                    return 0x18d;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a909d;
                uVar3 = func_0x00018023bbb0(uVar6);
                if ((uVar3 >> 0xd & 1) == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a90c2;
                    iVar2 = func_0x000180237500(uVar6, (int64_t)&iStackX_8 + iVar4, (int64_t)&var_ch + iVar4, 
                                                (int64_t)&arg_58h + iVar4);
                    if (iVar2 == 0) {
                        uVar1 = 0xffffffff;
                        *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0xffffffff;
                    } else {
                        uVar1 = *(undefined4 *)((int64_t)&arg_58h + iVar4);
                    }
                    if (*(int32_t *)((int64_t)&iStackX_8 + iVar4) == 0) {
                        *(undefined4 *)((int64_t)&iStackX_8 + iVar4) = *(undefined4 *)((int64_t)&var_ch + iVar4);
                    }
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar6;
                    if (in_RCX == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9110;
                        iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60012, uVar1);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9107;
                        iVar2 = func_0x0001801a2690(in_RCX);
                    }
                    if (iVar2 == 0) {
                        return 0x18e;
                    }
                }
                iVar7 = iVar7 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9122;
                iVar2 = func_0x000180222010(in_RDX);
            } while (iVar7 < iVar2);
        }
        uVar6 = 1;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801a914d
// Address: 0x1801a914d
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801a8ed0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar7;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R14;
    uint32_t uVar8;
    undefined8 unaff_R15;
    int32_t iStackX_8;
    int64_t var_ch;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801a8ee6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar7 = 0;
    if (in_R8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f07;
        in_R8 = func_0x000180222340(in_RDX, 0);
        if (in_R8 == 0) {
            return 0xc0103;
        }
        iVar7 = 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R15;
    uVar8 = 0x1000;
    if (in_R9D == 0) {
        uVar8 = 0;
    }
    uVar1 = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f50;
    iVar5 = func_0x000180238400(in_R8);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f5d;
        uVar1 = func_0x00018022fb60(iVar5);
    }
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_R8;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f83;
        iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60010, uVar1, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8f7a;
        iVar2 = func_0x0001801a2690(in_RCX);
    }
    if (iVar2 == 0) {
        uVar6 = 399;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8fa3;
        uVar3 = func_0x00018023bbb0(in_R8);
        if ((uVar3 >> 0xd & 1) == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a8fc8;
            iVar2 = func_0x000180237500(in_R8, (int64_t)&iStackX_8 + iVar4, (int64_t)&var_ch + iVar4, 
                                        (int64_t)&arg_58h + iVar4);
            if (iVar2 == 0) {
                uVar1 = 0xffffffff;
                *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0xffffffff;
            } else {
                uVar1 = *(undefined4 *)((int64_t)&arg_58h + iVar4);
            }
            if (*(int32_t *)((int64_t)&iStackX_8 + iVar4) == 0) {
                *(undefined4 *)((int64_t)&iStackX_8 + iVar4) = *(undefined4 *)((int64_t)&var_ch + iVar4);
            }
            *(int64_t *)((int64_t)&var_8h + iVar4) = in_R8;
            if (in_RCX == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9016;
                iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60012, uVar1);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a900d;
                iVar2 = func_0x0001801a2690(in_RCX);
            }
            if (iVar2 == 0) {
                return 0x18e;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a902c;
        iVar2 = func_0x000180222010(in_RDX);
        if (iVar7 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a904a;
                uVar6 = func_0x000180222340(in_RDX, iVar7);
                uVar1 = 0xffffffff;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a905a;
                iVar5 = func_0x000180238400(uVar6);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9067;
                    uVar1 = func_0x00018022fb60(iVar5);
                }
                *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar6;
                if (in_RCX == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a908d;
                    iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60011, uVar1, 0);
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9084;
                    iVar2 = func_0x0001801a2690(in_RCX);
                }
                if (iVar2 == 0) {
                    return 0x18d;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a909d;
                uVar3 = func_0x00018023bbb0(uVar6);
                if ((uVar3 >> 0xd & 1) == 0) {
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a90c2;
                    iVar2 = func_0x000180237500(uVar6, (int64_t)&iStackX_8 + iVar4, (int64_t)&var_ch + iVar4, 
                                                (int64_t)&arg_58h + iVar4);
                    if (iVar2 == 0) {
                        uVar1 = 0xffffffff;
                        *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0xffffffff;
                    } else {
                        uVar1 = *(undefined4 *)((int64_t)&arg_58h + iVar4);
                    }
                    if (*(int32_t *)((int64_t)&iStackX_8 + iVar4) == 0) {
                        *(undefined4 *)((int64_t)&iStackX_8 + iVar4) = *(undefined4 *)((int64_t)&var_ch + iVar4);
                    }
                    *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar6;
                    if (in_RCX == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9110;
                        iVar2 = func_0x0001801a25e0(0, uVar8 | 0x60012, uVar1);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9107;
                        iVar2 = func_0x0001801a2690(in_RCX);
                    }
                    if (iVar2 == 0) {
                        return 0x18e;
                    }
                }
                iVar7 = iVar7 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801a9122;
                iVar2 = func_0x000180222010(in_RDX);
            } while (iVar7 < iVar2);
        }
        uVar6 = 1;
    }
    return uVar6;
}

