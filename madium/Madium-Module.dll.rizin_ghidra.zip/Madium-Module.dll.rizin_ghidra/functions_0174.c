// Chunk 174 - 50 functions

// ============================================================
// Function: FUN_18022e22d
// Address: 0x18022e22d
// Size: 6 bytes
// ============================================================
void fcn.18022e22d(void)
{
    return;
}

// ============================================================
// Function: FUN_18022e240
// Address: 0x18022e240
// Size: 43 bytes
// ============================================================
void fcn.18022e240(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e24c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*param_2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022e262;
        iVar1 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                              *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
        *param_2 = iVar1;
    }
    return;
}

// ============================================================
// Function: FUN_18022e270
// Address: 0x18022e270
// Size: 43 bytes
// ============================================================
void fcn.18022e270(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e27c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*param_2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022e292;
        iVar1 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                              *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
        *param_2 = iVar1;
    }
    return;
}

// ============================================================
// Function: FUN_18022e2a0
// Address: 0x18022e2a0
// Size: 72 bytes
// ============================================================
void fcn.18022e2a0(int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_b0h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    code *pcVar8;
    int32_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar10;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022e2aa;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022e2b7;
    func_0x000180281a70(6);
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022e2c1;
    func_0x000180281a70(2);
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022e2cb;
    func_0x000180281a70(1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022e2d5;
    func_0x000180281a70(0xffffffff);
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022e2da;
    func_0x000180298840();
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022e2df;
    func_0x000180256800();
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = 0x18025959a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int64_t *)0x18077e748 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar6 + iVar5) = 0x1802595b5;
    piVar7 = (int32_t *)func_0x000180222290(*(int64_t *)0x18077e748, 0x180196ec0);
    pcVar8 = (code *)0x180259560;
    if (piVar7 != (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000070 + iVar6 + iVar5) = unaff_RBP;
        *(undefined8 *)(&stack0x00000048 + iVar6 + iVar5) = unaff_RSI;
        *(undefined8 *)(&stack0x00000040 + iVar6 + iVar5) = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_78h + iVar4 + iVar6 + iVar5) = unaff_RBX;
        iVar9 = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar4 + iVar6 + iVar5) = unaff_R14;
        if (0 < *piVar7) {
            *(undefined8 *)((int64_t)&arg_80h + iVar4 + iVar6 + iVar5) = unaff_RDI;
            iVar10 = 0;
            do {
                iVar1 = *(int64_t *)(iVar10 + *(int64_t *)(piVar7 + 2));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(piVar7 + 8);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)(&stack0x00000040 + iVar4 + iVar6 + iVar5) = 0x1802220b2;
                        (*pcVar8)();
                    } else {
                        *(undefined8 *)(&stack0x00000040 + iVar4 + iVar6 + iVar5) = 0x1802220ae;
                        (*pcVar2)(pcVar8, iVar1);
                    }
                }
                iVar9 = iVar9 + 1;
                iVar10 = iVar10 + 8;
            } while (iVar9 < *piVar7);
        }
        uVar3 = *(undefined8 *)(piVar7 + 2);
        *(undefined8 *)(&stack0x00000040 + iVar4 + iVar6 + iVar5) = 0x1802220d7;
        func_0x000180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)(&stack0x00000040 + iVar4 + iVar6 + iVar5) = 0x1802220ec;
        func_0x000180224990(piVar7, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_18022e2f0
// Address: 0x18022e2f0
// Size: 211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18022e2f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e305;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e31a;
    iVar1 = func_0x000180243560(4, 0);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e32f;
        iVar3 = fcn.180281b80(*(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar3;
        if (iVar3 != 0) {
            return iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e341;
        uVar4 = func_0x000180299670(in_RCX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e34f;
        iVar1 = func_0x0001802993f0(uVar4, in_RDX);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e358;
            func_0x000180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e366;
            uVar5 = func_0x0001802119f0(in_RCX, in_RDX, 0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e36e;
            func_0x000180211a40(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e373;
            func_0x0001802299d0();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e37e;
            iVar1 = func_0x0001802993f0(uVar4, in_RDX);
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e398;
        iVar1 = func_0x000180299310(uVar4, iVar1, fcn.18022e240, (int64_t)&arg_38h + iVar2);
        if (iVar1 != 0) {
            return *(int64_t *)((int64_t)&arg_38h + iVar2);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022e3d0
// Address: 0x18022e3d0
// Size: 211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18022e3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e3e5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e3fa;
    iVar1 = func_0x000180243560(8, 0);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e40f;
        iVar3 = fcn.180281b80(*(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar3;
        if (iVar3 != 0) {
            return iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e421;
        uVar4 = func_0x000180299670(in_RCX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e42f;
        iVar1 = func_0x0001802993f0(uVar4, in_RDX);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e438;
            func_0x000180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e446;
            uVar5 = func_0x000180215540(in_RCX, in_RDX, 0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e44e;
            func_0x000180215590(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e453;
            func_0x0001802299d0();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e45e;
            iVar1 = func_0x0001802993f0(uVar4, in_RDX);
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e478;
        iVar1 = func_0x000180299310(uVar4, iVar1, fcn.18022e270, (int64_t)&arg_38h + iVar2);
        if (iVar1 != 0) {
            return *(int64_t *)((int64_t)&arg_38h + iVar2);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022e4b0
// Address: 0x18022e4b0
// Size: 324 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18022e4b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar6;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e4d0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = in_RDX & 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022e4e2;
    iVar1 = func_0x000180299e80(in_RDX & 0xffffffff);
    if ((in_R8 != 0) && ((iVar1 == 0x198 || (iVar1 == 0x494)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022e503;
        iVar4 = func_0x00018021eaf0(in_R8);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022e510;
            uVar5 = func_0x000180266ad0(iVar4);
            if ((int32_t)uVar5 == 0x494) {
                if (iVar1 == 0x198) {
                    uVar6 = uVar5 & 0xffffffff;
                }
            } else if (iVar1 == 0x494) {
                uVar6 = 0x198;
            }
        }
    }
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022e53d;
    iVar1 = func_0x0001802304b0(in_RCX, uVar6);
    if (iVar1 == 0) {
        return false;
    }
    iVar1 = *in_RCX;
    *(int64_t *)(in_RCX + 8) = in_R8;
    if (iVar1 < 0x199) {
        if (iVar1 == 0x198) {
            if (in_R8 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022e58e;
                iVar1 = func_0x0001802a5150(in_R8);
                goto code_r0x00018022e5ba;
            }
        } else {
            if (iVar1 == 6) goto code_r0x00018022e5ad;
            if (iVar1 == 0x1c) {
                if (in_R8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022e57f;
                    iVar1 = func_0x0001802a3990(in_R8);
                    goto code_r0x00018022e5ba;
                }
            } else {
                if (iVar1 != 0x74) goto code_r0x00018022e59e;
                if (in_R8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022e570;
                    iVar1 = func_0x0001802a3f60(in_R8);
                    goto code_r0x00018022e5ba;
                }
            }
        }
code_r0x00018022e5c3:
        uVar2 = 0;
    } else {
        if (iVar1 != 0x390) {
            if (iVar1 != 0x494) {
code_r0x00018022e59e:
                in_RCX[0x13] = in_RCX[0x13] & 0xfffffffe;
                return in_R8 != 0;
            }
            goto code_r0x00018022e5cc;
        }
code_r0x00018022e5ad:
        if (in_R8 == 0) goto code_r0x00018022e5c3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022e5ba;
        iVar1 = func_0x0001802a63f0(in_R8);
code_r0x00018022e5ba:
        uVar2 = 1;
        if (iVar1 == 0) goto code_r0x00018022e5c3;
    }
    in_RCX[0x13] = in_RCX[0x13] & 0xfffffffe;
    in_RCX[0x13] = in_RCX[0x13] | uVar2;
code_r0x00018022e5cc:
    return in_R8 != 0;
}

// ============================================================
// Function: FUN_18022e600
// Address: 0x18022e600
// Size: 100 bytes
// ============================================================
uint32_t fcn.18022e600(int64_t arg_28h)
{
    uint32_t **ppuVar1;
    uint32_t *puVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e60c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x60) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e622;
        iVar3 = fcn.180299e80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
        if (iVar3 < 0x391) {
            if (((iVar3 == 0x390) || (iVar3 == 6)) || (iVar3 == 0x74)) {
                return 1;
            }
            if (iVar3 == 0x198) {
                ppuVar1 = *(uint32_t ***)(*(int64_t *)(in_RCX + 0x20) + 0x18);
                if ((ppuVar1 != (uint32_t **)0x0) && (puVar2 = *ppuVar1, puVar2 != (uint32_t *)0x0)) {
                    return ~(*puVar2 >> 2) & 1;
                }
                return 0;
            }
        } else {
            if (iVar3 == 0x43f) {
                return 1;
            }
            if (iVar3 == 0x440) {
                return 1;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e66e;
        uVar5 = fcn.1801dd170();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e676;
        fcn.18027f1e0(uVar5);
        uVar5 = *(undefined8 *)(in_RCX + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e687;
        fcn.18029f2b0(uVar5, 0xc);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e695;
        iVar6 = fcn.180248180(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                             );
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e6a7;
            fcn.1802481d0(iVar6);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022e664
// Address: 0x18022e664
// Size: 59 bytes
// ============================================================
uint32_t fcn.18022e600(int64_t arg_28h)
{
    uint32_t **ppuVar1;
    uint32_t *puVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e60c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x60) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e622;
        iVar3 = fcn.180299e80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
        if (iVar3 < 0x391) {
            if (((iVar3 == 0x390) || (iVar3 == 6)) || (iVar3 == 0x74)) {
                return 1;
            }
            if (iVar3 == 0x198) {
                ppuVar1 = *(uint32_t ***)(*(int64_t *)(in_RCX + 0x20) + 0x18);
                if ((ppuVar1 != (uint32_t **)0x0) && (puVar2 = *ppuVar1, puVar2 != (uint32_t *)0x0)) {
                    return ~(*puVar2 >> 2) & 1;
                }
                return 0;
            }
        } else {
            if (iVar3 == 0x43f) {
                return 1;
            }
            if (iVar3 == 0x440) {
                return 1;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e66e;
        uVar5 = fcn.1801dd170();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e676;
        fcn.18027f1e0(uVar5);
        uVar5 = *(undefined8 *)(in_RCX + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e687;
        fcn.18029f2b0(uVar5, 0xc);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e695;
        iVar6 = fcn.180248180(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                             );
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e6a7;
            fcn.1802481d0(iVar6);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022e69f
// Address: 0x18022e69f
// Size: 27 bytes
// ============================================================
uint32_t fcn.18022e600(int64_t arg_28h)
{
    uint32_t **ppuVar1;
    uint32_t *puVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e60c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x60) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e622;
        iVar3 = fcn.180299e80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4));
        if (iVar3 < 0x391) {
            if (((iVar3 == 0x390) || (iVar3 == 6)) || (iVar3 == 0x74)) {
                return 1;
            }
            if (iVar3 == 0x198) {
                ppuVar1 = *(uint32_t ***)(*(int64_t *)(in_RCX + 0x20) + 0x18);
                if ((ppuVar1 != (uint32_t **)0x0) && (puVar2 = *ppuVar1, puVar2 != (uint32_t *)0x0)) {
                    return ~(*puVar2 >> 2) & 1;
                }
                return 0;
            }
        } else {
            if (iVar3 == 0x43f) {
                return 1;
            }
            if (iVar3 == 0x440) {
                return 1;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e66e;
        uVar5 = fcn.1801dd170();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e676;
        fcn.18027f1e0(uVar5);
        uVar5 = *(undefined8 *)(in_RCX + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e687;
        fcn.18029f2b0(uVar5, 0xc);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e695;
        iVar6 = fcn.180248180(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                             );
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022e6a7;
            fcn.1802481d0(iVar6);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022e6c0
// Address: 0x18022e6c0
// Size: 703 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t * fcn.18022e6c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    code *pcVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int32_t *in_RDX;
    int32_t *piVar7;
    int32_t *piVar8;
    int32_t *piVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e6da;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar7 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
    piVar9 = piVar7;
    if (((*in_RCX != 0) && (piVar9 = (int32_t *)0x0, *(int64_t *)(in_RCX + 0x18) == 0)) &&
       (*(int64_t *)(in_RDX + 0x18) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e706;
        iVar3 = func_0x000180230bd0((int64_t)&arg_28h + iVar5);
        in_RDX = *(int32_t **)((int64_t)&arg_28h + iVar5);
        piVar8 = piVar7;
        piVar9 = in_RDX;
        if (iVar3 == 0) goto code_r0x00018022e90d;
    }
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        if (*in_RCX == 0) {
            if ((*in_RDX == 0) || (*(int64_t *)(in_RDX + 0x18) != 0)) {
                uVar2 = *(undefined8 *)(in_RDX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e74c;
                iVar3 = func_0x0001802305c0(in_RCX, uVar2);
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e736;
                iVar3 = func_0x0001802304b0(in_RCX);
            }
            piVar8 = (int32_t *)0x0;
            if (iVar3 == 0) goto code_r0x00018022e90d;
            goto code_r0x00018022e786;
        }
        if (*in_RCX == *in_RDX) goto code_r0x00018022e781;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e75f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
code_r0x00018022e764:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e777;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
    } else {
code_r0x00018022e781:
        if (in_RDX == (int32_t *)0x0) {
code_r0x00018022e7e9:
            if (*(int64_t *)(in_RCX + 0x18) == 0) {
                if ((*(int64_t *)(in_RCX + 2) != 0) &&
                   (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x80), pcVar1 != (code *)0x0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e827;
                    uVar4 = (*pcVar1)(in_RCX);
                    goto code_r0x00018022e829;
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e7fc;
                iVar3 = func_0x00018029f040(in_RCX, 4);
                uVar4 = (uint32_t)(iVar3 == 0);
code_r0x00018022e829:
                if (uVar4 != 0) {
                    if (*(int64_t *)(in_RCX + 0x18) != 0) {
                        if (*(int64_t *)(in_RDX + 0x18) != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e851;
                            uVar4 = func_0x00018029e810(in_RCX, in_RDX, 4);
                            piVar8 = (int32_t *)(uint64_t)uVar4;
                            goto code_r0x00018022e90d;
                        }
                        if (*(int64_t *)(in_RCX + 0x1a) == 0) {
                            *(int64_t *)((int64_t)&arg_28h + iVar5) = *(int64_t *)(in_RCX + 0x18);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e875;
                            iVar6 = func_0x000180230ea0(in_RDX, 0, (int64_t)&arg_28h + iVar5, 0);
                            if (iVar6 != 0) {
                                uVar2 = *(undefined8 *)(in_RCX + 0x18);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e89b;
                                iVar6 = func_0x000180257af0(uVar2, iVar6, 4);
                                *(int64_t *)(in_RCX + 0x1a) = iVar6;
                                piVar8 = (int32_t *)(uint64_t)(iVar6 != 0);
                                goto code_r0x00018022e90d;
                            }
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e87f;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), 
                                          *(int64_t *)((int64_t)&var_20h + iVar5));
                            goto code_r0x00018022e764;
                        }
                    }
                    piVar8 = (int32_t *)0x0;
                    if ((*(int64_t *)(in_RDX + 2) != 0) &&
                       (pcVar1 = *(code **)(*(int64_t *)(in_RDX + 2) + 0x88), pcVar1 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e8c6;
                        uVar4 = (*pcVar1)(in_RCX, in_RDX);
                        piVar8 = (int32_t *)(uint64_t)uVar4;
                    }
                    goto code_r0x00018022e90d;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e8d5;
            iVar3 = func_0x00018022fee0(in_RCX, in_RDX);
            if (iVar3 == 1) {
                piVar8 = (int32_t *)0x1;
                goto code_r0x00018022e90d;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e8e3;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e8fb;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
        } else {
code_r0x00018022e786:
            if (*(int64_t *)(in_RDX + 0x18) == 0) {
                if ((*(int64_t *)(in_RDX + 2) == 0) ||
                   (pcVar1 = *(code **)(*(int64_t *)(in_RDX + 2) + 0x80), pcVar1 == (code *)0x0))
                goto code_r0x00018022e7e9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e7bc;
                uVar4 = (*pcVar1)(in_RDX);
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e799;
                iVar3 = func_0x00018029f040(in_RDX, 4);
                uVar4 = (uint32_t)(iVar3 == 0);
            }
            if (uVar4 == 0) goto code_r0x00018022e7e9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e7c7;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e7df;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e90d;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    piVar8 = piVar7;
code_r0x00018022e90d:
    if (piVar9 != (int32_t *)0x0) {
        LOCK();
        piVar7 = piVar9 + 0xc;
        iVar3 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar3 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e929;
            func_0x000180231190(piVar9);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e93a;
            fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5));
            uVar2 = *(undefined8 *)(piVar9 + 0xe);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e943;
            fcn.1802227d0(uVar2);
            uVar2 = *(undefined8 *)(piVar9 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e953;
            func_0x000180222050(uVar2, 0x18029aca0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022e968;
            fcn.180224990(piVar9, 0x1804e1cf0, 0x73e);
        }
    }
    return piVar8;
}

// ============================================================
// Function: FUN_18022e980
// Address: 0x18022e980
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.18022e980(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e9a0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e9b4;
    iVar3 = func_0x000180215470();
    if (iVar3 == 0) {
        uVar1 = 0xffffffff;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e9c8;
        func_0x000180229b10();
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar2) = in_RCX;
        *(undefined8 *)((int64_t)&var_18h + iVar2) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e9eb;
        uVar1 = func_0x00018025c2e0(iVar3, 0, in_R8, in_RDX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e9f2;
        func_0x0001802299d0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e9fa;
        func_0x000180215310(iVar3);
    }
    return uVar1;
}

// ============================================================
// Function: FUN_18022ea20
// Address: 0x18022ea20
// Size: 78 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

int64_t fcn.18022ea20(int64_t arg_28h)
{
    int32_t *piVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ea2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea3c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea54;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea66;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea78;
    iVar6 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if (iVar6 == 0) {
        return 0;
    }
    if (*in_RCX == 0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
code_r0x00018022ea9a:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eaab;
            iVar4 = fcn.18029e810(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar5));
            goto joined_r0x00018022ead5;
        }
    } else {
        if (*(int64_t *)(in_RCX + 0x18) != 0) goto code_r0x00018022ea9a;
        if ((*(int64_t *)(in_RCX + 2) == 0) ||
           (pcVar2 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x130), pcVar2 == (code *)0x0)) {
            if (*(int64_t *)(in_RCX + 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eae8;
                iVar4 = fcn.1802304b0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5));
                if (iVar4 != 0) goto code_r0x00018022eaec;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb2c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb44;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb56;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
            goto code_r0x00018022eb56;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ead3;
        iVar4 = (*pcVar2)(iVar6, in_RCX);
joined_r0x00018022ead5:
        if (iVar4 == 0) goto code_r0x00018022eb56;
    }
code_r0x00018022eaec:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eafe;
    iVar4 = fcn.180223d20(*(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x000000c0 + iVar5));
    if (iVar4 != 0) {
        if (*(int64_t *)(in_RCX + 0x10) == 0) {
            return iVar6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb10;
        iVar7 = fcn.1802a70c0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(int64_t *)(iVar6 + 0x40) = iVar7;
        if (iVar7 != 0) {
            return iVar6;
        }
    }
code_r0x00018022eb56:
    LOCK();
    piVar1 = (int32_t *)(iVar6 + 0x30);
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 < 2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb6d;
        fcn.180231190(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb7e;
        fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5));
        uVar3 = *(undefined8 *)(iVar6 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb87;
        fcn.1802227d0(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb97;
        fcn.180222050(*(int64_t *)(&stack0x00000068 + iVar5), *(int64_t *)(&stack0x00000070 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                      *(int64_t *)(&stack0x000000a0 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ebac;
        fcn.180224990(iVar6, 0x1804e1cf0, 0x73e);
    }
    return 0;
}

// ============================================================
// Function: FUN_18022ea6e
// Address: 0x18022ea6e
// Size: 185 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

int64_t fcn.18022ea20(int64_t arg_28h)
{
    int32_t *piVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ea2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea3c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea54;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea66;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea78;
    iVar6 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if (iVar6 == 0) {
        return 0;
    }
    if (*in_RCX == 0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
code_r0x00018022ea9a:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eaab;
            iVar4 = fcn.18029e810(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar5));
            goto joined_r0x00018022ead5;
        }
    } else {
        if (*(int64_t *)(in_RCX + 0x18) != 0) goto code_r0x00018022ea9a;
        if ((*(int64_t *)(in_RCX + 2) == 0) ||
           (pcVar2 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x130), pcVar2 == (code *)0x0)) {
            if (*(int64_t *)(in_RCX + 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eae8;
                iVar4 = fcn.1802304b0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5));
                if (iVar4 != 0) goto code_r0x00018022eaec;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb2c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb44;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb56;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
            goto code_r0x00018022eb56;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ead3;
        iVar4 = (*pcVar2)(iVar6, in_RCX);
joined_r0x00018022ead5:
        if (iVar4 == 0) goto code_r0x00018022eb56;
    }
code_r0x00018022eaec:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eafe;
    iVar4 = fcn.180223d20(*(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x000000c0 + iVar5));
    if (iVar4 != 0) {
        if (*(int64_t *)(in_RCX + 0x10) == 0) {
            return iVar6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb10;
        iVar7 = fcn.1802a70c0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(int64_t *)(iVar6 + 0x40) = iVar7;
        if (iVar7 != 0) {
            return iVar6;
        }
    }
code_r0x00018022eb56:
    LOCK();
    piVar1 = (int32_t *)(iVar6 + 0x30);
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 < 2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb6d;
        fcn.180231190(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb7e;
        fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5));
        uVar3 = *(undefined8 *)(iVar6 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb87;
        fcn.1802227d0(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb97;
        fcn.180222050(*(int64_t *)(&stack0x00000068 + iVar5), *(int64_t *)(&stack0x00000070 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                      *(int64_t *)(&stack0x000000a0 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ebac;
        fcn.180224990(iVar6, 0x1804e1cf0, 0x73e);
    }
    return 0;
}

// ============================================================
// Function: FUN_18022eb27
// Address: 0x18022eb27
// Size: 146 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

int64_t fcn.18022ea20(int64_t arg_28h)
{
    int32_t *piVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ea2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea3c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea54;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea66;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ea78;
    iVar6 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5));
    if (iVar6 == 0) {
        return 0;
    }
    if (*in_RCX == 0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
code_r0x00018022ea9a:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eaab;
            iVar4 = fcn.18029e810(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar5));
            goto joined_r0x00018022ead5;
        }
    } else {
        if (*(int64_t *)(in_RCX + 0x18) != 0) goto code_r0x00018022ea9a;
        if ((*(int64_t *)(in_RCX + 2) == 0) ||
           (pcVar2 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x130), pcVar2 == (code *)0x0)) {
            if (*(int64_t *)(in_RCX + 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eae8;
                iVar4 = fcn.1802304b0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5));
                if (iVar4 != 0) goto code_r0x00018022eaec;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb2c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb44;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb56;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
            goto code_r0x00018022eb56;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ead3;
        iVar4 = (*pcVar2)(iVar6, in_RCX);
joined_r0x00018022ead5:
        if (iVar4 == 0) goto code_r0x00018022eb56;
    }
code_r0x00018022eaec:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eafe;
    iVar4 = fcn.180223d20(*(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x000000c0 + iVar5));
    if (iVar4 != 0) {
        if (*(int64_t *)(in_RCX + 0x10) == 0) {
            return iVar6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb10;
        iVar7 = fcn.1802a70c0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(int64_t *)(iVar6 + 0x40) = iVar7;
        if (iVar7 != 0) {
            return iVar6;
        }
    }
code_r0x00018022eb56:
    LOCK();
    piVar1 = (int32_t *)(iVar6 + 0x30);
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 < 2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb6d;
        fcn.180231190(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb7e;
        fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5));
        uVar3 = *(undefined8 *)(iVar6 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb87;
        fcn.1802227d0(uVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022eb97;
        fcn.180222050(*(int64_t *)(&stack0x00000068 + iVar5), *(int64_t *)(&stack0x00000070 + iVar5), 
                      *(int64_t *)(&stack0x00000078 + iVar5), *(int64_t *)(&stack0x00000080 + iVar5), 
                      *(int64_t *)(&stack0x000000a0 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022ebac;
        fcn.180224990(iVar6, 0x1804e1cf0, 0x73e);
    }
    return 0;
}

// ============================================================
// Function: FUN_18022ebc0
// Address: 0x18022ebc0
// Size: 253 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18022ebc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_b8h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    int32_t *in_RDX;
    int64_t iVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t iVar12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ebd0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == in_RDX) {
        return 1;
    }
    if ((in_RCX == (int32_t *)0x0) || (in_RDX == (int32_t *)0x0)) {
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 0x18) == 0) && (*(int64_t *)(in_RDX + 0x18) == 0)) {
        if (*in_RCX != *in_RDX) {
            return 0xffffffff;
        }
        if (*(int64_t *)(in_RCX + 2) != 0) {
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x90);
            if (pcVar1 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022ec3c;
                uVar5 = (*pcVar1)();
                if ((int32_t)uVar5 < 1) {
                    return uVar5;
                }
            }
            if (*(code **)(*(int64_t *)(in_RCX + 2) + 0x30) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018022ec5d. Too many branches
    // WARNING: Treating indirect jump as call
                uVar5 = (**(code **)(*(int64_t *)(in_RCX + 2) + 0x30))(in_RCX, in_RDX);
                return uVar5;
            }
        }
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022ec7a;
    iVar3 = fcn.18029f040();
    if (iVar3 == 0) {
code_r0x00018022ec95:
        uVar11 = 7;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022ec8b;
        iVar3 = fcn.18029f040(in_RDX, 2);
        uVar11 = 6;
        if (iVar3 == 0) goto code_r0x00018022ec95;
    }
    uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = uVar5;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + -8) = unaff_R12;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + -0x10) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180230a8c;
    iVar6 = fcn.18045a350(in_RCX, in_RDX, uVar11);
    iVar6 = -iVar6;
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        if (*(int64_t *)(in_RDX + 0x18) == 0) {
            return 0xfffffffe;
        }
    } else if (*(int64_t *)(in_RDX + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar4) = 0x180230abc;
        uVar5 = fcn.18029f120(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + iVar4 + 0x10), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000070 + iVar6 + iVar4));
        return uVar5;
    }
    if ((*in_RCX != 0) && (*(int64_t *)(in_RCX + 0x18) == 0)) {
        uVar5 = *(undefined8 *)(in_RDX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar4) = 0x180230ad5;
        uVar7 = fcn.18022ccf0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar4) = 0x180230ae0;
        iVar3 = fcn.180257a60(uVar5, uVar7);
        if (iVar3 == 0) {
            return 0xffffffff;
        }
    }
    if ((*in_RDX != 0) && (*(int64_t *)(in_RDX + 0x18) == 0)) {
        uVar5 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar4) = 0x180230afa;
        uVar7 = fcn.18022ccf0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar4) = 0x180230b05;
        iVar3 = fcn.180257a60(uVar5, uVar7);
        if (iVar3 == 0) {
            return 0xffffffff;
        }
    }
    iVar8 = *(int64_t *)(in_RDX + 0x18);
    iVar10 = *(int64_t *)(in_RCX + 0x18);
    iVar12 = *(int64_t *)(in_RCX + 0x1a);
    iVar2 = *(int64_t *)(in_RDX + 0x1a);
    *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar4) = iVar10;
    *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4) = iVar8;
    if ((iVar8 != 0) && (*(int64_t *)(iVar8 + 0xc0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar4) = 0x180230b4e;
        iVar8 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x000000a0 + iVar6 + iVar4));
        if (iVar8 != 0) {
            iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4);
            iVar12 = iVar8;
            iVar9 = iVar2;
            goto code_r0x000180230b97;
        }
        iVar8 = *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4);
    }
    if ((iVar10 != 0) && (*(int64_t *)(iVar10 + 0xc0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar4) = 0x180230b83;
        iVar9 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x000000a0 + iVar6 + iVar4));
        iVar10 = *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar4);
        if (iVar9 != 0) goto code_r0x000180230b97;
    }
    iVar9 = iVar2;
    if (iVar10 != iVar8) {
        return 0xfffffffe;
    }
code_r0x000180230b97:
    if (iVar10 == 0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar4) = 0x180230bad;
    uVar5 = fcn.180257f70(iVar10, iVar12, iVar9, uVar11 & 0xffffffff);
    return uVar5;
}

// ============================================================
// Function: FUN_18022ecc0
// Address: 0x18022ecc0
// Size: 111 bytes
// ============================================================
void fcn.18022ecc0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18022ecd0;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x30);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022ecea;
            fcn.180231190(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022ecfb;
            fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x00000100 + iVar4));
            uVar3 = *(undefined8 *)(arg1 + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022ed04;
            fcn.1802227d0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022ed14;
            fcn.180222050(*(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                          *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                          *(int64_t *)(&stack0x000000a0 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18022ed29;
            fcn.180224990(arg1, 0x1804e1cf0, 0x73e);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18022ed30
// Address: 0x18022ed30
// Size: 90 bytes
// ============================================================
int64_t fcn.18022ed30(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                     int64_t arg_68h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 uStackX_18;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022ed3a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((*in_RCX != 0x1c) && (*in_RCX != 0x398)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022ed50;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022ed68;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar5));
        *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022ed7a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x1802313a5;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = 0;
    if ((in_RCX != (int32_t *)0x0) && ((*(int64_t *)(in_RCX + 8) != 0 || (*(int64_t *)(in_RCX + 0x1a) != 0)))) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) {
            return *(int64_t *)(in_RCX + 8);
        }
        uVar2 = *(undefined8 *)(in_RCX + 0xe);
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802313e1;
        iVar4 = fcn.180222850(uVar2);
        if (iVar4 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0xe);
            iVar3 = *(int64_t *)(in_RCX + 10);
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802313f6;
            iVar4 = fcn.180222910(uVar2);
            if (iVar4 != 0) {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RSI;
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180231428;
                    iVar4 = fcn.180230bd0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    iVar3 = *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5);
                    iVar7 = 0;
                    if (iVar4 != 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0xe);
                        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18023143a;
                        iVar4 = fcn.180222950(uVar2);
                        if (iVar4 != 0) {
                            iVar7 = *(int64_t *)(in_RCX + 10);
                            if (iVar7 == 0) {
                                iVar7 = *(int64_t *)(iVar3 + 0x20);
                                *(int64_t *)(in_RCX + 10) = iVar7;
                                *(undefined8 *)(iVar3 + 0x20) = 0;
                            }
                            uVar2 = *(undefined8 *)(in_RCX + 0xe);
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18023145c;
                            iVar4 = fcn.180222910(uVar2);
                            if (iVar4 == 0) {
                                iVar7 = 0;
                            }
                        }
                    }
                    if (iVar3 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar3 + 0x30);
                        iVar4 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar4 < 2) {
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18023147e;
                            fcn.180231190(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18023148f;
                            fcn.180223fb0(*(int64_t *)(&stack0x000000c0 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x00000128 + iVar6 + iVar5));
                            uVar2 = *(undefined8 *)(iVar3 + 0x38);
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180231498;
                            fcn.1802227d0(uVar2);
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802314a8;
                            fcn.180222050(*(int64_t *)(&stack0x00000090 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x00000098 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x000000a0 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x000000a8 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x000000c8 + iVar6 + iVar5));
                            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802314bd;
                            fcn.180224990(iVar3, 0x1804e1cf0, 0x73e);
                        }
                    }
                    return iVar7;
                }
                return iVar3;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022ed90
// Address: 0x18022ed90
// Size: 81 bytes
// ============================================================
int64_t fcn.18022ed90(int32_t *param_1)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar7;
    int64_t aiStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18022ed9a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*param_1 != 0x74) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022eda7;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022edbf;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                      *(int64_t *)(&stack0x00000050 + iVar5));
        *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x18022edd1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar5));
        return 0;
    }
    *(undefined8 *)(&stack0x00000040 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = 0x1802313a5;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)(&stack0x00000050 + iVar6 + iVar5) = 0;
    if ((param_1 != (int32_t *)0x0) && ((*(int64_t *)(param_1 + 8) != 0 || (*(int64_t *)(param_1 + 0x1a) != 0)))) {
        if (*(int64_t *)(param_1 + 0x18) == 0) {
            return *(int64_t *)(param_1 + 8);
        }
        uVar2 = *(undefined8 *)(param_1 + 0xe);
        *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x1802313e1;
        iVar4 = fcn.180222850(uVar2);
        if (iVar4 != 0) {
            uVar2 = *(undefined8 *)(param_1 + 0xe);
            iVar3 = *(int64_t *)(param_1 + 10);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x1802313f6;
            iVar4 = fcn.180222910(uVar2);
            if (iVar4 != 0) {
                if (iVar3 == 0) {
                    *(undefined8 *)(&stack0x00000058 + iVar6 + iVar5) = unaff_RSI;
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x180231428;
                    iVar4 = fcn.180230bd0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x00000058 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
                    iVar3 = *(int64_t *)(&stack0x00000050 + iVar6 + iVar5);
                    iVar7 = 0;
                    if (iVar4 != 0) {
                        uVar2 = *(undefined8 *)(param_1 + 0xe);
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x18023143a;
                        iVar4 = fcn.180222950(uVar2);
                        if (iVar4 != 0) {
                            iVar7 = *(int64_t *)(param_1 + 10);
                            if (iVar7 == 0) {
                                iVar7 = *(int64_t *)(iVar3 + 0x20);
                                *(int64_t *)(param_1 + 10) = iVar7;
                                *(undefined8 *)(iVar3 + 0x20) = 0;
                            }
                            uVar2 = *(undefined8 *)(param_1 + 0xe);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x18023145c;
                            iVar4 = fcn.180222910(uVar2);
                            if (iVar4 == 0) {
                                iVar7 = 0;
                            }
                        }
                    }
                    if (iVar3 != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(iVar3 + 0x30);
                        iVar4 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar4 < 2) {
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x18023147e;
                            fcn.180231190(*(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x18023148f;
                            fcn.180223fb0(*(int64_t *)(&stack0x000000c0 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x00000128 + iVar6 + iVar5));
                            uVar2 = *(undefined8 *)(iVar3 + 0x38);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x180231498;
                            fcn.1802227d0(uVar2);
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x1802314a8;
                            fcn.180222050(*(int64_t *)(&stack0x00000090 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x00000098 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x000000a0 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x000000a8 + iVar6 + iVar5), 
                                          *(int64_t *)(&stack0x000000c8 + iVar6 + iVar5));
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5) = 0x1802314bd;
                            fcn.180224990(iVar3, 0x1804e1cf0, 0x73e);
                        }
                    }
                    return iVar7;
                }
                return iVar3;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022edf0
// Address: 0x18022edf0
// Size: 130 bytes
// ============================================================
int64_t fcn.18022edf0(int32_t *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022edfa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*param_1 != 0x1c) && (*param_1 != 0x398)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022ee10;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022ee28;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022ee3a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022ee4d;
    iVar3 = fcn.180231390(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022ee5d;
        iVar1 = fcn.18021f5b0(iVar3);
        if (iVar1 == 0) {
            iVar3 = 0;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022ee80
// Address: 0x18022ee80
// Size: 111 bytes
// ============================================================
int64_t fcn.18022ee80(int32_t *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ee8c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*param_1 == 0x74) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022eed3;
        iVar3 = fcn.180231390(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022eee3;
            iVar1 = fcn.18029a8f0(iVar3);
            if (iVar1 == 0) {
                return 0;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ee99;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022eeb1;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022eec3;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        iVar3 = 0;
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022eef0
// Address: 0x18022eef0
// Size: 454 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18022eef0(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_90h, int64_t arg_a0h, int64_t arg_a8h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    int64_t *in_RDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ef10;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != (int32_t *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f0a6;
            iVar6 = func_0x0001802308f0(extraout_XMM0_Da, 10, 0, in_RDX);
            if (iVar6 < 1) {
                return 0;
            }
            return (int64_t)iVar6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022ef44;
        puVar8 = (undefined4 *)func_0x000180229c70((int64_t)&arg_28h + iVar7, 0x1804e1de8, 0, 0);
        uVar3 = puVar8[1];
        uVar4 = puVar8[2];
        uVar5 = puVar8[3];
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = *puVar8;
        *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
        *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
        *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
        uVar3 = puVar8[5];
        uVar4 = puVar8[6];
        uVar5 = puVar8[7];
        *(undefined4 *)((int64_t)&arg_68h + iVar7) = puVar8[4];
        *(undefined4 *)((int64_t)&arg_68h + iVar7 + 4) = uVar3;
        *(undefined4 *)(&stack0x00000070 + iVar7) = uVar4;
        *(undefined4 *)(&stack0x00000074 + iVar7) = uVar5;
        *(undefined8 *)((int64_t)&arg_78h + iVar7) = *(undefined8 *)(puVar8 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022ef6d;
        puVar8 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar7);
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        uVar3 = puVar8[1];
        uVar4 = puVar8[2];
        uVar5 = puVar8[3];
        *(undefined4 *)((int64_t)&arg_80h + iVar7) = *puVar8;
        *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
        *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
        *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
        uVar3 = puVar8[5];
        uVar4 = puVar8[6];
        uVar5 = puVar8[7];
        *(undefined4 *)((int64_t)&arg_90h + iVar7) = puVar8[4];
        *(undefined4 *)((int64_t)&arg_90h + iVar7 + 4) = uVar3;
        *(undefined4 *)(&stack0x00000098 + iVar7) = uVar4;
        *(undefined4 *)(&stack0x0000009c + iVar7) = uVar5;
        *(undefined8 *)((int64_t)&arg_a0h + iVar7) = *(undefined8 *)(puVar8 + 8);
        if (iVar1 == 0) {
            if (*in_RCX == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f06a;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f082;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar7));
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f094;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022efc1;
            iVar6 = func_0x0001802a2e70(in_RCX, (int64_t)&arg_58h + iVar7);
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022efa9;
            iVar6 = func_0x000180257e70(iVar1, uVar2, (int64_t)&arg_58h + iVar7);
        }
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022efd8;
            iVar6 = func_0x00018022aed0((int64_t)&arg_58h + iVar7);
            if ((iVar6 != 0) && (iVar1 = *(int64_t *)((int64_t)&arg_78h + iVar7), iVar1 != -1)) {
                *in_RDX = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f002;
                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                if (iVar9 != 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f024;
                    iVar6 = func_0x00018022fa20(in_RCX, 0x1804e1de8, iVar9, iVar1);
                    if (iVar6 != 0) {
                        *in_RDX = iVar9;
                        return iVar1;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f03d;
                    fcn.180224990(iVar9, 0x1804e1cf0, 0x5c0);
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022f0c0
// Address: 0x18022f0c0
// Size: 24 bytes
// ============================================================
undefined4 fcn.18022f0c0(undefined4 *param_1)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180299e8c;
    iVar3 = fcn.18045a350(uVar1);
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180299e9b;
    puVar4 = (undefined4 *)
             fcn.180247890(*(int64_t *)(&stack0x00000178 + iVar3 + iVar2), 
                           *(int64_t *)(&stack0x00000198 + iVar3 + iVar2), 
                           *(int64_t *)(&stack0x000001a0 + iVar3 + iVar2), 
                           *(int64_t *)(&stack0x000001c0 + iVar3 + iVar2));
    if (puVar4 != (undefined4 *)0x0) {
        uVar1 = *puVar4;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180299eac;
        fcn.18026aee0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
        return uVar1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180299ec0;
    fcn.18026aee0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_18022f0e0
// Address: 0x18022f0e0
// Size: 103 bytes
// ============================================================
uint64_t fcn.18022f0e0(int64_t param_1)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022f0ea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 != 0) {
        uVar3 = (uint64_t)*(uint32_t *)(param_1 + 0x88);
        if ((*(int64_t *)(param_1 + 8) != 0) &&
           (pcVar1 = *(code **)(*(int64_t *)(param_1 + 8) + 0x60), pcVar1 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022f10d;
            uVar3 = (*pcVar1)();
        }
        if (0 < (int32_t)uVar3) {
            return uVar3;
        }
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022f116;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022f12e;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                  *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                  *(int64_t *)(&stack0x00000050 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022f140;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_18022f150
// Address: 0x18022f150
// Size: 645 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18022f150(int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t iVar10;
    int64_t iStackX_8;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    int64_t var_848h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_40 = 0x18022f16d;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7);
    iVar9 = 0;
    if ((in_RDX == 0) || (in_R8 == 0)) goto code_r0x00018022f3b4;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f1b4;
    fcn.1804986e0(&var_848h, 0, 0x800);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f1cb;
    puVar8 = (undefined4 *)func_0x000180229b50((int64_t)&arg_38h + iVar7, in_RDX, &var_848h, 0x800);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&var_18h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&var_18h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0xfffffffffffffff0 + iVar7) = uVar4;
    *(undefined4 *)(&stack0xfffffffffffffff4 + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&var_8h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&var_8h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000000 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000004 + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&iStackX_8 + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f1f1;
    puVar8 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_38h + iVar7);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&uStackX_18 + iVar7 + -8) = *puVar8;
    *(undefined4 *)((int64_t)&uStackX_18 + iVar7 + -4) = uVar3;
    *(undefined4 *)((int64_t)&uStackX_18 + iVar7) = uVar4;
    *(undefined4 *)((int64_t)&uStackX_18 + iVar7 + 4) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&var_20h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&var_20h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000028 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000002c + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = *(undefined8 *)(puVar8 + 8);
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018022f24d:
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f252;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f26a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&uStackX_18 + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f27c;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_8 + iVar7));
code_r0x00018022f27c:
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f286;
        iVar6 = func_0x00018022aed0((int64_t)&var_18h + iVar7);
        if ((iVar6 == 0) || (iVar10 = *(int64_t *)((int64_t)&iStackX_8 + iVar7), iVar10 == 0))
        goto code_r0x00018022f3b4;
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f2b1;
        iVar9 = fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar7));
        if (iVar9 == 0) goto code_r0x00018022f3b4;
        *(int64_t *)((int64_t)&var_8h + iVar7) = iVar9;
        *(int64_t *)(&stack0x00000000 + iVar7) = iVar10;
        if (in_RCX == (int32_t *)0x0) {
code_r0x00018022f343:
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f348;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f360;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                          *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&uStackX_18 + iVar7));
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f372;
            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_8 + iVar7));
        } else {
            iVar2 = *(int64_t *)(in_RCX + 0x18);
            if (iVar2 == 0) {
                if (*in_RCX == 0) goto code_r0x00018022f343;
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f2f6;
                iVar6 = func_0x0001802a2e70(in_RCX, (int64_t)&var_18h + iVar7);
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x1a);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f2e3;
                iVar6 = func_0x000180257e70(iVar2, uVar1, (int64_t)&var_18h + iVar7);
            }
            if (0 < iVar6) goto code_r0x00018022f301;
        }
    } else {
        iVar10 = *(int64_t *)(in_RCX + 0x18);
        if (iVar10 == 0) {
            if (*in_RCX == 0) goto code_r0x00018022f24d;
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f23c;
            iVar6 = func_0x0001802a2e70(in_RCX, (int64_t)&var_18h + iVar7);
        } else {
            uVar1 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f229;
            iVar6 = func_0x000180257e70(iVar10, uVar1, (int64_t)&var_18h + iVar7);
        }
        iVar10 = iVar9;
        if (iVar6 < 1) goto code_r0x00018022f27c;
code_r0x00018022f301:
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f30b;
        iVar6 = func_0x00018022aed0((int64_t)&var_18h + iVar7);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f31c;
            func_0x000180229ec0((int64_t)&var_18h + iVar7, in_R8);
        }
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f32d;
            iVar6 = func_0x00018022aed0((int64_t)&var_18h + iVar7);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f33f;
                func_0x000180244fc0(&var_848h, *(undefined8 *)(&stack0x00000000 + iVar7));
            }
            goto code_r0x00018022f3b4;
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f37c;
    iVar6 = func_0x00018022aed0((int64_t)&var_18h + iVar7);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f3ae;
        fcn.180224990(iVar9, 0x1804e1cf0, 0x8cf);
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f398;
        func_0x000180224b90(iVar9, iVar10, 0x1804e1cf0, 0x8cd);
    }
code_r0x00018022f3b4:
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18022f3c3;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18022f3e0
// Address: 0x18022f3e0
// Size: 94 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_81h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_89h
// WARNING: [rz-ghidra] Detected overlap for variable arg_8dh
// WARNING: [rz-ghidra] Detected overlap for variable arg_8fh
// WARNING: [rz-ghidra] Detected overlap for variable arg_41h
// WARNING: [rz-ghidra] Removing arg arg_51h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_61h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_71h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_c5h
// WARNING: [rz-ghidra] Detected overlap for variable var_b7h
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel

undefined8 fcn.18022f3e0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_90h, int64_t arg_c8h)
{
    int64_t iVar1;
    code *UNRECOVERED_JUMPTABLE;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined4 extraout_XMM0_Da;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        return 0;
    }
    if (*(int64_t *)(in_RCX + 8) == 0) {
        iVar2 = 3;
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 0x10) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_10 + iVar3) = unaff_R14;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3) = 0x1802316a3;
        iVar4 = fcn.18045a350(extraout_XMM0_Da, 3, 0);
        iVar4 = -iVar4;
        *(uint64_t *)((int64_t)&arg_90h + iVar4 + iVar3) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar4 + iVar3;
        if ((*(int64_t *)(in_RCX + 0x60) != 0) && (iVar2 == 3)) {
            *(undefined *)((int64_t)&arg_40h + iVar4 + iVar3) = 0;
            *(undefined8 *)(&stack0x00000081 + iVar4 + iVar3) = 0;
            *(undefined4 *)(&stack0x00000089 + iVar4 + iVar3) = 0;
            *(undefined2 *)(&stack0x0000008d + iVar4 + iVar3) = 0;
            (&stack0x0000008f)[iVar4 + iVar3] = 0;
            iVar1 = *(int64_t *)(in_RCX + 8);
            *(undefined (*) [16])((int64_t)&arg_40h + iVar4 + iVar3 + 1) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000051 + iVar4 + iVar3) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000061 + iVar4 + iVar3) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000071 + iVar4 + iVar3) = ZEXT816(0);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180231727;
                iVar2 = fcn.18029ee90(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
            } else {
                *(undefined4 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0;
                UNRECOVERED_JUMPTABLE = *(code **)(iVar1 + 0xb0);
                if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
                    iVar2 = -2;
                } else {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180231759;
                    iVar2 = (*UNRECOVERED_JUMPTABLE)(in_RCX, 3, 0, (int64_t)&arg_30h + iVar4 + iVar3);
                    if (0 < iVar2) {
                        *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x180231768;
                        uVar5 = fcn.18022ccf0(*(undefined4 *)((int64_t)&arg_30h + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x18023177b;
                        fcn.180223790((int64_t)&arg_40h + iVar4 + iVar3, uVar5, 0x50);
                    }
                }
            }
            if (0 < iVar2) {
                uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x60) + 0x20);
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x18023178c;
                fcn.18027f1e0(uVar5);
                *(undefined4 *)((int64_t)&arg_30h + iVar4 + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x18023179c;
                fcn.180229b10();
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802317ac;
                uVar5 = fcn.180215540(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802317b4;
                fcn.1802299d0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802317bc;
                fcn.180299670(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802317c7;
                fcn.180215590(uVar5);
                *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802317d4;
                iVar2 = fcn.1802993f0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000098 + iVar4 + iVar3));
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x1802317ee;
                    iVar2 = fcn.180299310(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                          *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
                    if (iVar2 != 0) {
                        *in_RDX = *(undefined4 *)((int64_t)&arg_30h + iVar4 + iVar3);
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStackX_8 + iVar4 + iVar3) = 0x18023180f;
        uVar5 = fcn.180459870(*(uint64_t *)((int64_t)&arg_90h + iVar4 + iVar3) ^ (int64_t)auStackX_10 + iVar4 + iVar3);
        return uVar5;
    }
    UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 8) + 0xb0);
    if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018022f43b. Too many branches
    // WARNING: Treating indirect jump as call
        uVar5 = (*UNRECOVERED_JUMPTABLE)(extraout_XMM0_Da, 3, 0, in_RDX);
        return uVar5;
    }
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18022f440
// Address: 0x18022f440
// Size: 458 bytes
// ============================================================
void fcn.18022f440(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_98h, int64_t arg_e8h, int64_t arg_128h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    int32_t *in_RCX;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022f44c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_e8h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    if (in_RCX != (int32_t *)0x0) {
        if ((*(int64_t *)(in_RCX + 0x18) == 0) || (*(int64_t *)(in_RCX + 0x1a) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f5fb;
            iVar8 = func_0x000180299ed0();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f608;
                func_0x000180182b10(iVar8);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f4a2;
            puVar7 = (undefined4 *)
                     func_0x000180229e30((int64_t)&arg_68h + iVar6, 0x1804e1ef8, (int64_t)&arg_98h + iVar6, 0x50);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&uStackX_20 + iVar6 + -8) = *puVar7;
            *(undefined4 *)((int64_t)&uStackX_20 + iVar6 + -4) = uVar2;
            *(undefined4 *)((int64_t)&uStackX_20 + iVar6) = uVar3;
            *(undefined4 *)((int64_t)&uStackX_20 + iVar6 + 4) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_28h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000030 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x00000034 + iVar6) = uVar4;
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f4c8;
            puVar7 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_68h + iVar6);
            iVar8 = *(int64_t *)(in_RCX + 0x18);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_40h + iVar6) = *puVar7;
            *(undefined4 *)((int64_t)&arg_40h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000048 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x0000004c + iVar6) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_50h + iVar6) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_50h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000058 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x0000005c + iVar6) = uVar4;
            *(undefined8 *)((int64_t)&arg_60h + iVar6) = *(undefined8 *)(puVar7 + 8);
            if (iVar8 == 0) {
                if (*in_RCX == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f5b1;
                    fcn.180229480(*(int64_t *)((int64_t)&uStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&uStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f5c9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&uStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&uStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f5db;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                    goto code_r0x00018022f5dd;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f513;
                iVar5 = func_0x0001802a2e70(in_RCX, (int64_t)&uStackX_20 + iVar6 + -8);
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x1a);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f4fb;
                iVar5 = func_0x000180257e70(iVar8, uVar1, (int64_t)&uStackX_20 + iVar6 + -8);
            }
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f52e;
                iVar5 = func_0x00018022aed0((int64_t)&uStackX_20 + iVar6 + -8);
                if ((iVar5 != 0) && (*(int64_t *)((int64_t)&arg_38h + iVar6) != 0x50)) {
                    *(undefined *)((int64_t)&arg_98h + *(int64_t *)((int64_t)&arg_38h + iVar6) + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f560;
                    iVar5 = func_0x000180498f10((int64_t)&arg_98h + iVar6, 0x1804e1f08);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f57f;
                        iVar5 = func_0x000180498f10((int64_t)&arg_98h + iVar6, 0x1804e1f18);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f59e;
                            func_0x000180498f10((int64_t)&arg_98h + iVar6, 0x1804e1f24);
                        }
                    }
                }
            }
        }
    }
code_r0x00018022f5dd:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f5ed;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_18022f610
// Address: 0x18022f610
// Size: 428 bytes
// ============================================================
void fcn.18022f610(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_98h, int64_t arg_e8h, int64_t arg_128h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    int32_t *in_RCX;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022f61c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_e8h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    if (in_RCX != (int32_t *)0x0) {
        if ((*(int64_t *)(in_RCX + 0x18) == 0) || (*(int64_t *)(in_RCX + 0x1a) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f7a0;
            iVar8 = func_0x000180299ed0();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f7ad;
                iVar8 = func_0x00018021eaf0(iVar8);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f7ba;
                    func_0x000180266b40(iVar8);
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f672;
            puVar7 = (undefined4 *)
                     func_0x000180229e30((int64_t)&arg_68h + iVar6, 0x1804e1f30, (int64_t)&arg_98h + iVar6, 0x50);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&uStackX_20 + iVar6 + -8) = *puVar7;
            *(undefined4 *)((int64_t)&uStackX_20 + iVar6 + -4) = uVar2;
            *(undefined4 *)((int64_t)&uStackX_20 + iVar6) = uVar3;
            *(undefined4 *)((int64_t)&uStackX_20 + iVar6 + 4) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_28h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000030 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x00000034 + iVar6) = uVar4;
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f698;
            puVar7 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_68h + iVar6);
            iVar8 = *(int64_t *)(in_RCX + 0x18);
            uVar2 = puVar7[1];
            uVar3 = puVar7[2];
            uVar4 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_40h + iVar6) = *puVar7;
            *(undefined4 *)((int64_t)&arg_40h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000048 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x0000004c + iVar6) = uVar4;
            uVar2 = puVar7[5];
            uVar3 = puVar7[6];
            uVar4 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_50h + iVar6) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_50h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000058 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x0000005c + iVar6) = uVar4;
            *(undefined8 *)((int64_t)&arg_60h + iVar6) = *(undefined8 *)(puVar7 + 8);
            if (iVar8 == 0) {
                if (*in_RCX == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f756;
                    fcn.180229480(*(int64_t *)((int64_t)&uStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&uStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f76e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&uStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&uStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f780;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                    goto code_r0x00018022f782;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f6df;
                iVar5 = func_0x0001802a2e70(in_RCX, (int64_t)&uStackX_20 + iVar6 + -8);
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x1a);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f6cb;
                iVar5 = func_0x000180257e70(iVar8, uVar1, (int64_t)&uStackX_20 + iVar6 + -8);
            }
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f6f8;
                iVar5 = func_0x00018022aed0((int64_t)&uStackX_20 + iVar6 + -8);
                if ((iVar5 != 0) && (*(int64_t *)((int64_t)&arg_38h + iVar6) != 0x50)) {
                    *(undefined *)((int64_t)&arg_98h + *(int64_t *)((int64_t)&arg_38h + iVar6) + iVar6) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f727;
                    iVar5 = func_0x000180498f10((int64_t)&arg_98h + iVar6, 0x1804d87d8);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f746;
                        func_0x000180498f10((int64_t)&arg_98h + iVar6, 0x1804d87e8);
                    }
                }
            }
        }
    }
code_r0x00018022f782:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18022f792;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_18022f7c0
// Address: 0x18022f7c0
// Size: 317 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18022f7c0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022f7da;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f800;
    puVar8 = (undefined4 *)func_0x000180229e30((int64_t)&iStackX_20 + iVar7 + -8, 0x1804bb3d4, in_RDX, in_R8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f826;
    puVar8 = (undefined4 *)func_0x000180229ba0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar8 + 8);
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018022f8b3:
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f8b8;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f8d0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f8e2;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
    } else {
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 == 0) {
            if (*in_RCX == 0) goto code_r0x00018022f8b3;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f878;
            iVar6 = func_0x0001802a2e70(in_RCX, (int64_t)&arg_48h + iVar7);
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f864;
            iVar6 = func_0x000180257e70(iVar1, uVar2, (int64_t)&arg_48h + iVar7);
        }
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f88d;
            iVar6 = func_0x00018022aed0((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                iVar7 = *(int64_t *)((int64_t)&arg_68h + iVar7);
                if (in_R9 != (int64_t *)0x0) {
                    *in_R9 = iVar7;
                }
                if (iVar7 != in_R8) {
                    if (in_RDX != 0) {
                        *(undefined *)(iVar7 + in_RDX) = 0;
                    }
                    return 1;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022f900
// Address: 0x18022f900
// Size: 39 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h

undefined8
fcn.18022f900(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022f90c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f934;
    puVar8 = (undefined4 *)fcn.180229bc0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f95a;
    puVar8 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar8 + 8);
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018022f9de:
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9e3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9fb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa0d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
    } else {
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 == 0) {
            if (*in_RCX == 0) goto code_r0x00018022f9de;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9ad;
            iVar6 = fcn.1802a2e70(*(int64_t *)(&stack0x000000d8 + iVar7));
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f99a;
            iVar6 = fcn.180257e70(iVar1, uVar2, (int64_t)&arg_48h + iVar7);
        }
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9c2;
            iVar6 = fcn.18022aed0((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022f927
// Address: 0x18022f927
// Size: 183 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h

undefined8
fcn.18022f900(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022f90c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f934;
    puVar8 = (undefined4 *)fcn.180229bc0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f95a;
    puVar8 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar8 + 8);
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018022f9de:
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9e3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9fb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa0d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
    } else {
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 == 0) {
            if (*in_RCX == 0) goto code_r0x00018022f9de;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9ad;
            iVar6 = fcn.1802a2e70(*(int64_t *)(&stack0x000000d8 + iVar7));
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f99a;
            iVar6 = fcn.180257e70(iVar1, uVar2, (int64_t)&arg_48h + iVar7);
        }
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9c2;
            iVar6 = fcn.18022aed0((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022f9de
// Address: 0x18022f9de
// Size: 66 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h

undefined8
fcn.18022f900(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022f90c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f934;
    puVar8 = (undefined4 *)fcn.180229bc0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f95a;
    puVar8 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar8 + 8);
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018022f9de:
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9e3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9fb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa0d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
    } else {
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 == 0) {
            if (*in_RCX == 0) goto code_r0x00018022f9de;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9ad;
            iVar6 = fcn.1802a2e70(*(int64_t *)(&stack0x000000d8 + iVar7));
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f99a;
            iVar6 = fcn.180257e70(iVar1, uVar2, (int64_t)&arg_48h + iVar7);
        }
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022f9c2;
            iVar6 = fcn.18022aed0((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022fa20
// Address: 0x18022fa20
// Size: 39 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h

undefined8
fcn.18022fa20(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h, int64_t arg_c8h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022fa2c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa54;
    puVar8 = (undefined4 *)fcn.180229c70((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa7a;
    puVar8 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar8 + 8);
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018022fb13:
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb18;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb30;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb42;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
    } else {
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 == 0) {
            if (*in_RCX == 0) goto code_r0x00018022fb13;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022facd;
            iVar6 = fcn.1802a2e70(*(int64_t *)(&stack0x000000d8 + iVar7));
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022faba;
            iVar6 = fcn.180257e70(iVar1, uVar2, (int64_t)&arg_48h + iVar7);
        }
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fae2;
            iVar6 = fcn.18022aed0((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                if (*(undefined8 **)((int64_t)&arg_c8h + iVar7) != (undefined8 *)0x0) {
                    **(undefined8 **)((int64_t)&arg_c8h + iVar7) = *(undefined8 *)((int64_t)&arg_68h + iVar7);
                }
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022fa47
// Address: 0x18022fa47
// Size: 204 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h

undefined8
fcn.18022fa20(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h, int64_t arg_c8h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022fa2c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa54;
    puVar8 = (undefined4 *)fcn.180229c70((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa7a;
    puVar8 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar8 + 8);
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018022fb13:
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb18;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb30;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb42;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
    } else {
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 == 0) {
            if (*in_RCX == 0) goto code_r0x00018022fb13;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022facd;
            iVar6 = fcn.1802a2e70(*(int64_t *)(&stack0x000000d8 + iVar7));
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022faba;
            iVar6 = fcn.180257e70(iVar1, uVar2, (int64_t)&arg_48h + iVar7);
        }
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fae2;
            iVar6 = fcn.18022aed0((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                if (*(undefined8 **)((int64_t)&arg_c8h + iVar7) != (undefined8 *)0x0) {
                    **(undefined8 **)((int64_t)&arg_c8h + iVar7) = *(undefined8 *)((int64_t)&arg_68h + iVar7);
                }
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022fb13
// Address: 0x18022fb13
// Size: 66 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h

undefined8
fcn.18022fa20(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h, int64_t arg_c8h, int64_t arg_118h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022fa2c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa54;
    puVar8 = (undefined4 *)fcn.180229c70((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fa7a;
    puVar8 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar7 + -8);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar8;
    *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
    uVar3 = puVar8[5];
    uVar4 = puVar8[6];
    uVar5 = puVar8[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar8[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
    *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
    *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar8 + 8);
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018022fb13:
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb18;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb30;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fb42;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
    } else {
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 == 0) {
            if (*in_RCX == 0) goto code_r0x00018022fb13;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022facd;
            iVar6 = fcn.1802a2e70(*(int64_t *)(&stack0x000000d8 + iVar7));
        } else {
            uVar2 = *(undefined8 *)(in_RCX + 0x1a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022faba;
            iVar6 = fcn.180257e70(iVar1, uVar2, (int64_t)&arg_48h + iVar7);
        }
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022fae2;
            iVar6 = fcn.18022aed0((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                if (*(undefined8 **)((int64_t)&arg_c8h + iVar7) != (undefined8 *)0x0) {
                    **(undefined8 **)((int64_t)&arg_c8h + iVar7) = *(undefined8 *)((int64_t)&arg_68h + iVar7);
                }
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022fb60
// Address: 0x18022fb60
// Size: 103 bytes
// ============================================================
uint64_t fcn.18022fb60(int64_t param_1)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022fb6a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 != 0) {
        uVar3 = (uint64_t)*(uint32_t *)(param_1 + 0x8c);
        if ((*(int64_t *)(param_1 + 8) != 0) &&
           (pcVar1 = *(code **)(*(int64_t *)(param_1 + 8) + 0x68), pcVar1 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022fb8d;
            uVar3 = (*pcVar1)();
        }
        if (0 < (int32_t)uVar3) {
            return uVar3;
        }
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022fb96;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022fbae;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                  *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                  *(int64_t *)(&stack0x00000050 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022fbc0;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_18022fbd0
// Address: 0x18022fbd0
// Size: 103 bytes
// ============================================================
uint64_t fcn.18022fbd0(int64_t param_1)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022fbda;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 != 0) {
        uVar3 = (uint64_t)*(uint32_t *)(param_1 + 0x94);
        if ((*(int64_t *)(param_1 + 8) != 0) &&
           (pcVar1 = *(code **)(*(int64_t *)(param_1 + 8) + 0x58), pcVar1 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022fbfd;
            uVar3 = (*pcVar1)();
        }
        if (0 < (int32_t)uVar3) {
            return uVar3;
        }
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022fc06;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022fc1e;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                  *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                  *(int64_t *)(&stack0x00000050 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022fc30;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_18022fc40
// Address: 0x18022fc40
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18022fc40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    int64_t iVar4;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022fc50;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    iVar4 = *(int64_t *)(in_RCX + 0x18);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&iStackX_18 + iVar2) = 0x180257a6a;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&iStackX_18 + iVar3 + iVar2) = 0x180257a84;
            iVar1 = fcn.180280ea0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar2));
            if (iVar1 != 0) {
                return true;
            }
        }
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_R14;
    uVar5 = 0;
    do {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fc9f;
        iVar1 = fcn.180223670(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        if (iVar1 == 0) {
            iVar1 = *(int32_t *)(uVar5 * 0x10 + 0x1804e1c10);
            goto code_r0x00018022fce1;
        }
        uVar5 = uVar5 + 1;
    } while (uVar5 < 0xc);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcb8;
    fcn.18022d080(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcbf;
    iVar1 = fcn.180299e80(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fccb;
        fcn.18022ca40(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000068 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcd2;
        iVar1 = fcn.180299e80(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2));
    }
code_r0x00018022fce1:
    return *in_RCX == iVar1;
}

// ============================================================
// Function: FUN_18022fc78
// Address: 0x18022fc78
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18022fc40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    int64_t iVar4;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022fc50;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    iVar4 = *(int64_t *)(in_RCX + 0x18);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&iStackX_18 + iVar2) = 0x180257a6a;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&iStackX_18 + iVar3 + iVar2) = 0x180257a84;
            iVar1 = fcn.180280ea0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar2));
            if (iVar1 != 0) {
                return true;
            }
        }
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_R14;
    uVar5 = 0;
    do {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fc9f;
        iVar1 = fcn.180223670(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        if (iVar1 == 0) {
            iVar1 = *(int32_t *)(uVar5 * 0x10 + 0x1804e1c10);
            goto code_r0x00018022fce1;
        }
        uVar5 = uVar5 + 1;
    } while (uVar5 < 0xc);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcb8;
    fcn.18022d080(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcbf;
    iVar1 = fcn.180299e80(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fccb;
        fcn.18022ca40(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000068 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcd2;
        iVar1 = fcn.180299e80(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2));
    }
code_r0x00018022fce1:
    return *in_RCX == iVar1;
}

// ============================================================
// Function: FUN_18022fd05
// Address: 0x18022fd05
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18022fc40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    int64_t iVar4;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022fc50;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    iVar4 = *(int64_t *)(in_RCX + 0x18);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&iStackX_18 + iVar2) = 0x180257a6a;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&iStackX_18 + iVar3 + iVar2) = 0x180257a84;
            iVar1 = fcn.180280ea0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar2));
            if (iVar1 != 0) {
                return true;
            }
        }
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_R14;
    uVar5 = 0;
    do {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fc9f;
        iVar1 = fcn.180223670(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        if (iVar1 == 0) {
            iVar1 = *(int32_t *)(uVar5 * 0x10 + 0x1804e1c10);
            goto code_r0x00018022fce1;
        }
        uVar5 = uVar5 + 1;
    } while (uVar5 < 0xc);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcb8;
    fcn.18022d080(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcbf;
    iVar1 = fcn.180299e80(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fccb;
        fcn.18022ca40(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000068 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022fcd2;
        iVar1 = fcn.180299e80(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2));
    }
code_r0x00018022fce1:
    return *in_RCX == iVar1;
}

// ============================================================
// Function: FUN_18022fd20
// Address: 0x18022fd20
// Size: 84 bytes
// ============================================================
uint64_t fcn.18022fd20(int64_t param_1)
{
    code *UNRECOVERED_JUMPTABLE;
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022fd2a;
    iVar2 = fcn.18045a350();
    if (param_1 != 0) {
        if (*(int64_t *)(param_1 + 0x60) != 0) {
            *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x18022fd43;
            iVar1 = fcn.18029f040();
            return (uint64_t)(iVar1 == 0);
        }
        if ((*(int64_t *)(param_1 + 8) != 0) &&
           (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(param_1 + 8) + 0x80), UNRECOVERED_JUMPTABLE != (code *)0x0))
        {
    // WARNING: Could not recover jumptable at 0x00018022fd6a. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (*UNRECOVERED_JUMPTABLE)();
            return uVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022fd80
// Address: 0x18022fd80
// Size: 278 bytes
// ============================================================
undefined8 * fcn.18022fd80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022fd8c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022fda6;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (puVar4 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R12;
    *puVar4 = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_R14;
    *(undefined4 *)(puVar4 + 6) = 1;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022fde3;
    iVar5 = fcn.180222800();
    puVar4[7] = iVar5;
    if (iVar5 != 0) {
        *(undefined4 *)(puVar4 + 9) = 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022fe0c;
        iVar2 = fcn.180224430(*(int64_t *)(&stack0x00000058 + iVar3));
        if (iVar2 != 0) {
            return puVar4;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022fe33;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022fe41;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022fe4d;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    uVar1 = puVar4[7];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022fe56;
    fcn.1802227d0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022fe6b;
    fcn.180224990(puVar4, 0x1804e1cf0, 0x5f2);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18022fea0
// Address: 0x18022fea0
// Size: 58 bytes
// ============================================================
void fcn.18022fea0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022feaa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_38h + iVar1) = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022fed5;
    fcn.180231870(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)(&stack0x00000080 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18022fee0
// Address: 0x18022fee0
// Size: 96 bytes
// ============================================================
undefined8 fcn.18022fee0(int32_t *param_1, int32_t *param_2)
{
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 unaff_RBX;
    int64_t iVar9;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t iVar11;
    undefined8 unaff_R15;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022feea;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(int64_t *)(param_1 + 0x18) == 0) && (*(int64_t *)(param_2 + 0x18) == 0)) {
        if (*param_1 != *param_2) {
            return 0xffffffff;
        }
        if ((*(int64_t *)(param_1 + 2) != 0) &&
           (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(param_1 + 2) + 0x90), UNRECOVERED_JUMPTABLE != (code *)0x0))
        {
    // WARNING: Could not recover jumptable at 0x00018022ff24. Too many branches
    // WARNING: Treating indirect jump as call
            uVar4 = (*UNRECOVERED_JUMPTABLE)();
            return uVar4;
        }
        return 0xfffffffe;
    }
    uVar10 = 4;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000020 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar3) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar3) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar3) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar3 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180230a8c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*(int64_t *)(param_1 + 0x18) == 0) {
        if (*(int64_t *)(param_2 + 0x18) == 0) {
            return 0xfffffffe;
        }
    } else if (*(int64_t *)(param_2 + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar5 + iVar3) = 0x180230abc;
        uVar4 = fcn.18029f120(*(int64_t *)(&stack0x00000028 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000078 + iVar5 + iVar3));
        return uVar4;
    }
    if ((*param_1 != 0) && (*(int64_t *)(param_1 + 0x18) == 0)) {
        uVar4 = *(undefined8 *)(param_2 + 0x18);
        *(undefined8 *)((int64_t)&uStack_8 + iVar5 + iVar3) = 0x180230ad5;
        uVar6 = fcn.18022ccf0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar5 + iVar3) = 0x180230ae0;
        iVar2 = fcn.180257a60(uVar4, uVar6);
        if (iVar2 == 0) {
            return 0xffffffff;
        }
    }
    if ((*param_2 != 0) && (*(int64_t *)(param_2 + 0x18) == 0)) {
        uVar4 = *(undefined8 *)(param_1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_8 + iVar5 + iVar3) = 0x180230afa;
        uVar6 = fcn.18022ccf0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar5 + iVar3) = 0x180230b05;
        iVar2 = fcn.180257a60(uVar4, uVar6);
        if (iVar2 == 0) {
            return 0xffffffff;
        }
    }
    iVar7 = *(int64_t *)(param_2 + 0x18);
    iVar9 = *(int64_t *)(param_1 + 0x18);
    iVar11 = *(int64_t *)(param_1 + 0x1a);
    iVar1 = *(int64_t *)(param_2 + 0x1a);
    *(int64_t *)(&stack0x00000068 + iVar5 + iVar3) = iVar9;
    *(int64_t *)(&stack0x00000050 + iVar5 + iVar3) = iVar7;
    if ((iVar7 != 0) && (*(int64_t *)(iVar7 + 0xc0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar5 + iVar3) = 0x180230b4e;
        iVar7 = fcn.180230ea0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x000000a8 + iVar5 + iVar3));
        if (iVar7 != 0) {
            iVar9 = *(int64_t *)(&stack0x00000050 + iVar5 + iVar3);
            iVar11 = iVar7;
            iVar8 = iVar1;
            goto code_r0x000180230b97;
        }
        iVar7 = *(int64_t *)(&stack0x00000050 + iVar5 + iVar3);
    }
    if ((iVar9 != 0) && (*(int64_t *)(iVar9 + 0xc0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar5 + iVar3) = 0x180230b83;
        iVar8 = fcn.180230ea0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar3), 
                              *(int64_t *)(&stack0x000000a8 + iVar5 + iVar3));
        iVar9 = *(int64_t *)(&stack0x00000068 + iVar5 + iVar3);
        if (iVar8 != 0) goto code_r0x000180230b97;
    }
    iVar8 = iVar1;
    if (iVar9 != iVar7) {
        return 0xfffffffe;
    }
code_r0x000180230b97:
    if (iVar9 == 0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar5 + iVar3) = 0x180230bad;
    uVar4 = fcn.180257f70(iVar9, iVar11, iVar8, uVar10 & 0xffffffff);
    return uVar4;
}

// ============================================================
// Function: FUN_18022ff40
// Address: 0x18022ff40
// Size: 70 bytes
// ============================================================
void fcn.18022ff40(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RDX;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022ff4a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = *(int64_t *)(in_RDX + 8);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x38);
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = in_R9;
    *(int64_t *)((int64_t)&arg_28h + iVar1) = iVar2;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ff81;
    fcn.180231d30(*(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x000000b8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18022ff90
// Address: 0x18022ff90
// Size: 514 bytes
// ============================================================
uint64_t fcn.18022ff90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x18022ff9e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18022ffaf;
    iVar1 = func_0x0001802a3790(in_RDX);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18022ffc2;
        iVar7 = fcn.1801dd6c0(in_RDX);
        iVar1 = 0x398;
        if (iVar7 == 0) {
            iVar1 = 0x1c;
        }
    } else {
        iVar1 = 0x1c;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18022ffdc;
    uVar6 = fcn.18021f5b0(in_RDX);
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18022fff9;
    iVar2 = fcn.180299e80(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), *(int64_t *)(&stack0x00000040 + iVar5));
    if ((in_RDX != 0) && ((iVar2 == 0x198 || (iVar2 == 0x494)))) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023001a;
        iVar7 = func_0x00018021eaf0(in_RDX);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180230027;
            iVar3 = func_0x000180266ad0(iVar7);
            if (iVar3 == 0x494) {
                if (iVar2 == 0x198) {
                    iVar1 = 0x494;
                }
            } else if (iVar2 == 0x494) {
                iVar1 = 0x198;
            }
        }
    }
    uVar6 = 0;
    if (in_RCX == (int32_t *)0x0) goto code_r0x000180230176;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
    if ((*(int64_t *)(in_RCX + 8) != 0) || (*(int64_t *)(in_RCX + 0x1a) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180230065;
        fcn.180231190(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10));
    }
    if (((*in_RCX == 0) || (iVar1 != in_RCX[1])) || (iVar2 = *in_RCX, *(int64_t *)(in_RCX + 2) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023007f;
        fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)(in_RCX + 4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023008c;
        fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
        *(undefined8 *)(in_RCX + 6) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023009c;
        iVar7 = fcn.180247890(*(int64_t *)(&stack0x00000140 + iVar5), *(int64_t *)(&stack0x00000160 + iVar5), 
                              *(int64_t *)(&stack0x00000168 + iVar5), *(int64_t *)(&stack0x00000188 + iVar5));
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023014c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180230164;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180230176;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
            goto code_r0x000180230176;
        }
        *(int64_t *)(in_RCX + 2) = iVar7;
        *(undefined8 *)(in_RCX + 4) = *(undefined8 *)((int64_t)&arg_38h + iVar5);
        *(undefined8 *)(in_RCX + 0x18) = 0;
        in_RCX[1] = iVar1;
        *in_RCX = iVar1;
        iVar2 = iVar1;
    }
    *(int64_t *)(in_RCX + 8) = in_RDX;
    if (iVar2 < 0x199) {
        if (iVar2 == 0x198) {
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180230102;
                iVar1 = func_0x0001802a5150(in_RDX);
                goto code_r0x000180230127;
            }
        } else {
            if (iVar2 == 6) goto code_r0x00018023011a;
            if (iVar2 == 0x1c) {
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802300f3;
                    iVar1 = func_0x0001802a3990(in_RDX);
                    goto code_r0x000180230127;
                }
            } else {
                if (iVar2 != 0x74) goto code_r0x000180230114;
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802300e4;
                    iVar1 = func_0x0001802a3f60(in_RDX);
                    goto code_r0x000180230127;
                }
            }
        }
        goto code_r0x000180230130;
    }
    if (iVar2 == 0x390) {
code_r0x00018023011a:
        if (in_RDX == 0) {
code_r0x000180230130:
            uVar4 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180230127;
            iVar1 = func_0x0001802a63f0(in_RDX);
code_r0x000180230127:
            uVar4 = 1;
            if (iVar1 == 0) goto code_r0x000180230130;
        }
        in_RCX[0x13] = in_RCX[0x13] & 0xfffffffe;
        in_RCX[0x13] = in_RCX[0x13] | uVar4;
    } else if (iVar2 != 0x494) {
code_r0x000180230114:
        in_RCX[0x13] = in_RCX[0x13] & 0xfffffffe;
    }
    uVar6 = (uint64_t)(in_RDX != 0);
    if (in_RDX != 0) {
        return uVar6;
    }
code_r0x000180230176:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18023017e;
    func_0x00018029a130(in_RDX);
    return uVar6;
}

// ============================================================
// Function: FUN_1802301a0
// Address: 0x1802301a0
// Size: 481 bytes
// ============================================================
uint64_t fcn.1802301a0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1802301ad;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802301be;
    uVar6 = fcn.18029a8f0(in_RDX);
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
    iVar3 = 0x74;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802301e4;
    iVar1 = fcn.180299e80(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5));
    if ((in_RDX != 0) && ((iVar1 == 0x198 || (iVar1 == 0x494)))) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230205;
        iVar7 = fcn.18021eaf0(in_RDX);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230212;
            iVar2 = fcn.180266ad0(iVar7);
            if (iVar2 == 0x494) {
                if (iVar1 == 0x198) {
                    iVar3 = 0x494;
                }
            } else {
                iVar3 = 0x74;
                if (iVar1 == 0x494) {
                    iVar3 = 0x198;
                }
            }
        }
    }
    uVar6 = 0;
    if (in_RCX == (int32_t *)0x0) goto code_r0x000180230361;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
    if ((*(int64_t *)(in_RCX + 8) != 0) || (*(int64_t *)(in_RCX + 0x1a) != 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230250;
        fcn.180231190(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    }
    if (((*in_RCX == 0) || (iVar3 != in_RCX[1])) || (iVar1 = *in_RCX, *(int64_t *)(in_RCX + 2) == 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18023026a;
        fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
        *(undefined8 *)(in_RCX + 4) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230277;
        fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
        *(undefined8 *)(in_RCX + 6) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230287;
        iVar7 = fcn.180247890(*(int64_t *)(&stack0x00000148 + iVar5), *(int64_t *)(&stack0x00000168 + iVar5), 
                              *(int64_t *)(&stack0x00000170 + iVar5), *(int64_t *)(&stack0x00000190 + iVar5));
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230337;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar5));
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18023034f;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5));
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230361;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar5));
            goto code_r0x000180230361;
        }
        *(int64_t *)(in_RCX + 2) = iVar7;
        *(undefined8 *)(in_RCX + 4) = *(undefined8 *)((int64_t)&arg_40h + iVar5);
        *(undefined8 *)(in_RCX + 0x18) = 0;
        in_RCX[1] = iVar3;
        *in_RCX = iVar3;
        iVar1 = iVar3;
    }
    *(int64_t *)(in_RCX + 8) = in_RDX;
    if (iVar1 < 0x199) {
        if (iVar1 == 0x198) {
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802302ed;
                iVar3 = fcn.1802a5150(*(int64_t *)((int64_t)&arg_38h + iVar5));
                goto code_r0x000180230312;
            }
        } else {
            if (iVar1 == 6) goto code_r0x000180230305;
            if (iVar1 == 0x1c) {
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802302de;
                    iVar3 = fcn.1802a3990(*(int64_t *)((int64_t)&arg_38h + iVar5));
                    goto code_r0x000180230312;
                }
            } else {
                if (iVar1 != 0x74) goto code_r0x0001802302ff;
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1802302cf;
                    iVar3 = fcn.1802a3f60(*(int64_t *)((int64_t)&arg_38h + iVar5));
                    goto code_r0x000180230312;
                }
            }
        }
        goto code_r0x00018023031b;
    }
    if (iVar1 == 0x390) {
code_r0x000180230305:
        if (in_RDX == 0) {
code_r0x00018023031b:
            uVar4 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230312;
            iVar3 = fcn.1802a63f0(*(int64_t *)((int64_t)&arg_38h + iVar5));
code_r0x000180230312:
            uVar4 = 1;
            if (iVar3 == 0) goto code_r0x00018023031b;
        }
        in_RCX[0x13] = in_RCX[0x13] & 0xfffffffe;
        in_RCX[0x13] = in_RCX[0x13] | uVar4;
    } else if (iVar1 != 0x494) {
code_r0x0001802302ff:
        in_RCX[0x13] = in_RCX[0x13] & 0xfffffffe;
    }
    uVar6 = (uint64_t)(in_RDX != 0);
    if (in_RDX != 0) {
        return uVar6;
    }
code_r0x000180230361:
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x180230369;
    fcn.18029a6a0(in_RDX);
    return uVar6;
}

// ============================================================
// Function: FUN_180230390
// Address: 0x180230390
// Size: 280 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_59h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable arg_61h
// WARNING: [rz-ghidra] Removing arg arg_29h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_65h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_67h
// WARNING: [rz-ghidra] Removing arg arg_49h because it doesn't fit into ProtoModel

uint64_t fcn.180230390(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h,
                      int64_t arg_90h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023039c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x60) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802303cd;
            puVar8 = (undefined4 *)fcn.180229c70((int64_t)&iStackX_20 + iVar7 + -8, 0x1804e1de8, in_RDX, in_R8);
            uVar3 = puVar8[1];
            uVar4 = puVar8[2];
            uVar5 = puVar8[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
            *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000050 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x00000054 + iVar7) = uVar5;
            uVar3 = puVar8[5];
            uVar4 = puVar8[6];
            uVar5 = puVar8[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000060 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x00000064 + iVar7) = uVar5;
            *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802303f3;
            puVar8 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar7 + -8);
            iVar1 = *(int64_t *)(in_RCX + 0x60);
            uVar3 = puVar8[1];
            uVar4 = puVar8[2];
            uVar5 = puVar8[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar7) = *puVar8;
            *(undefined4 *)((int64_t)&arg_70h + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000078 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x0000007c + iVar7) = uVar5;
            uVar3 = puVar8[5];
            uVar4 = puVar8[6];
            uVar5 = puVar8[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar7) = puVar8[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar7 + 4) = uVar3;
            *(undefined4 *)(&stack0x00000088 + iVar7) = uVar4;
            *(undefined4 *)(&stack0x0000008c + iVar7) = uVar5;
            *(undefined8 *)((int64_t)&arg_90h + iVar7) = *(undefined8 *)(puVar8 + 8);
            if (iVar1 != 0) {
                *(int64_t *)(in_RCX + 0x70) = *(int64_t *)(in_RCX + 0x70) + 1;
                uVar2 = *(undefined8 *)(in_RCX + 0x68);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180230430;
                uVar9 = fcn.180257ff0(iVar1, uVar2, (int64_t)&arg_48h + iVar7);
                return uVar9;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023043e;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180230456;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180230468;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar7));
            return 0;
        }
        if (in_R8 < 0x80000000) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18023048b;
            iVar6 = fcn.1802308f0(*(int64_t *)((int64_t)&arg_58h + iVar7), *(int64_t *)((int64_t)&arg_68h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar7));
            return (uint64_t)(0 < iVar6);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802304b0
// Address: 0x1802304b0
// Size: 261 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802304b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t *piVar2;
    int32_t *in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802304ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    piVar2 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = 0;
    if (in_RCX != (int32_t *)0x0) {
        if ((*(int64_t *)(in_RCX + 8) != 0) || (*(int64_t *)(in_RCX + 0x1a) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802304f1;
            fcn.180231190(*(int64_t *)((int64_t)&iStackX_18 + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1));
        }
        if (((*in_RCX != 0) && (in_EDX == in_RCX[1])) && (*(int64_t *)(in_RCX + 2) != 0)) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023050d;
        fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)(in_RCX + 4) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023051a;
        fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)(in_RCX + 6) = 0;
    }
    if (in_EDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023052e;
        piVar2 = (int32_t *)
                 fcn.180247890(*(int64_t *)(&stack0x00000150 + iVar1), *(int64_t *)(&stack0x00000170 + iVar1), 
                               *(int64_t *)(&stack0x00000178 + iVar1), *(int64_t *)(&stack0x00000198 + iVar1));
    }
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180230540;
        fcn.18026aee0(*(int64_t *)((int64_t)&var_20h + iVar1));
    }
    if (piVar2 != (int32_t *)0x0) {
        if (in_RCX != (int32_t *)0x0) {
            *(undefined8 *)(in_RCX + 0x18) = 0;
            in_RCX[1] = in_EDX;
            *in_RCX = in_EDX;
            *(int32_t **)(in_RCX + 2) = piVar2;
            if (in_EDX == 0) {
                *in_RCX = *piVar2;
            }
            *(undefined8 *)(in_RCX + 4) = *(undefined8 *)((int64_t)&arg_38h + iVar1);
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023054a;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180230562;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180230574;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_1802305c0
// Address: 0x1802305c0
// Size: 71 bytes
// ============================================================
undefined8
fcn.1802305c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_78h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined4 uVar6;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1802305cd;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined (*) [16])((int64_t)&iStackX_18 + iVar4 + -8) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802305f3;
    iVar2 = func_0x000180257aa0(in_RDX, 0x1802315d0, (int64_t)&iStackX_18 + iVar4 + -8);
    if ((iVar2 == 0) || (*(int64_t *)((int64_t)&iStackX_18 + iVar4) != 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180230788;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802307a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802307b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    iVar1 = *(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8);
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R15;
    uVar6 = 0xffffffff;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R12;
    if (iVar1 == 0) {
        uVar3 = 0xffffffff;
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18023063d;
        uVar3 = func_0x000180498cd0(iVar1);
    }
    puVar5 = (undefined4 *)0x0;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = 0;
    if (in_RCX != (undefined8 *)0x0) {
        if ((in_RCX[4] != 0) || (in_RCX[0xd] != 0)) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180230662;
            fcn.180231190(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)&var_20h + iVar4));
        }
        if (((*(int32_t *)in_RCX != 0) && (*(int32_t *)((int64_t)in_RCX + 4) == 0)) && (in_RCX[1] != 0)) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18023067e;
        fcn.18026aee0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
        in_RCX[2] = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18023068b;
        fcn.18026aee0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
        in_RCX[3] = 0;
    }
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802306a4;
        puVar5 = (undefined4 *)func_0x0001802479a0((int64_t)&arg_60h + iVar4, iVar1, uVar3);
    }
    if (in_RCX == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802306b6;
        fcn.18026aee0(*(int64_t *)((int64_t)&iStackX_18 + iVar4));
    }
    if ((puVar5 == (undefined4 *)0x0) && (in_RDX == 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802306c5;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802306dd;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_18 + iVar4), 
                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802306ef;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    if (in_RCX != (undefined8 *)0x0) {
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180230703;
            iVar2 = func_0x000180257ae0(in_RDX);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18023070c;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar4));
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180230724;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4));
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180230736;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
                return 0;
            }
        }
        in_RCX[0xc] = in_RDX;
        *in_RCX = 0;
        if (in_RDX == 0) {
            in_RCX[1] = puVar5;
        }
        if (puVar5 != (undefined4 *)0x0) {
            uVar6 = *puVar5;
        }
        in_RCX[2] = *(undefined8 *)((int64_t)&arg_60h + iVar4);
        *(undefined4 *)in_RCX = uVar6;
    }
    return 1;
}

