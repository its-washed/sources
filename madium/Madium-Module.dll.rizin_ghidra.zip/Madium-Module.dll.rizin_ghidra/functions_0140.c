// Chunk 140 - 50 functions

// ============================================================
// Function: FUN_1801dfc90
// Address: 0x1801dfc90
// Size: 639 bytes
// ============================================================
undefined8
fcn.1801dfc90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_78h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint32_t in_EDX;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dfca8;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if ((char)in_EDX == '\n') {
        if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x200) != 0) {
            uVar8 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfcd3;
            iVar1 = func_0x0001801a6130(uVar8);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfcec;
                iVar4 = func_0x0001801fca50(10);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return 1;
                }
                uVar8 = 0x1805aadb1;
                iVar6 = 0x1805aadb1;
                if (iVar4 != 0) {
                    iVar6 = iVar4;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd12;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd2a;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar5 = 0x1805aadb1;
                uVar7 = 0x1804b64b8;
                if (iVar4 != 0) {
                    uVar5 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b64b8;
                *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
                if (iVar4 != 0) {
                    uVar8 = 0x1805ab2cc;
                }
                *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
                *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd7d;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd95;
                func_0x0001802295a0(0x1804b6360, 0x4ee, 0x1804b64a0);
                iVar4 = *(int64_t *)(in_RCX + 0x5d8);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfda6;
                    iVar4 = func_0x0001802542f0();
                    *(int64_t *)(in_RCX + 0x5d8) = iVar4;
                    if (iVar4 != 0) goto code_r0x0001801dfdb2;
                } else {
code_r0x0001801dfdb2:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfdba;
                    func_0x000180254600(iVar4);
                }
                *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x2e;
code_r0x0001801dfeda:
                *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar7;
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = 10;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff04;
                func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar3, 0);
                return 1;
            }
        }
    } else if (((char)in_EDX == '/') && ((*(uint32_t *)(in_RCX + 0x5d0) & 0x200) != 0)) {
        uVar8 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfdea;
        iVar1 = func_0x0001801a60f0(uVar8);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe03;
            iVar4 = func_0x0001801fca50(10);
            if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                return 1;
            }
            uVar8 = 0x1805aadb1;
            iVar6 = 0x1805aadb1;
            if (iVar4 != 0) {
                iVar6 = iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe29;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe41;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar5 = 0x1805aadb1;
            uVar7 = 0x1804b64e8;
            if (iVar4 != 0) {
                uVar5 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b64e8;
            *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
            if (iVar4 != 0) {
                uVar8 = 0x1805ab2cc;
            }
            *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe94;
            func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfeac;
            func_0x0001802295a0(0x1804b6360, 0x4fc, 0x1804b64a0);
            iVar4 = *(int64_t *)(in_RCX + 0x5d8);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfebd;
                iVar4 = func_0x0001802542f0();
                *(int64_t *)(in_RCX + 0x5d8) = iVar4;
                if (iVar4 != 0) goto code_r0x0001801dfec9;
            } else {
code_r0x0001801dfec9:
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfed1;
                func_0x000180254600(iVar4);
            }
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1b;
            goto code_r0x0001801dfeda;
        }
    }
    uVar2 = (in_EDX & 0xff) + 0x100;
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff27;
    iVar4 = func_0x0001801fca50(uVar2);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return 1;
    }
    uVar8 = 0x1805aadb1;
    iVar6 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar6 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff4d;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff65;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar5 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar5 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b6508;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffb5;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, uVar2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffcd;
    func_0x0001802295a0(0x1804b6360, 0x501, 0x1804b64a0);
    iVar4 = *(int64_t *)(in_RCX + 0x5d8);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffde;
        iVar4 = func_0x0001802542f0();
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801dfff2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfff2;
    func_0x000180254600(iVar4);
code_r0x0001801dfff2:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = (uint64_t)uVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x1804b6508;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0xf;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e0021;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar3, 0);
    return 1;
}

// ============================================================
// Function: FUN_1801dff0f
// Address: 0x1801dff0f
// Size: 282 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801dfc90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_78h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint32_t in_EDX;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dfca8;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if ((char)in_EDX == '\n') {
        if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x200) != 0) {
            uVar8 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfcd3;
            iVar1 = func_0x0001801a6130(uVar8);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfcec;
                iVar4 = func_0x0001801fca50(10);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return 1;
                }
                uVar8 = 0x1805aadb1;
                iVar6 = 0x1805aadb1;
                if (iVar4 != 0) {
                    iVar6 = iVar4;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd12;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd2a;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar5 = 0x1805aadb1;
                uVar7 = 0x1804b64b8;
                if (iVar4 != 0) {
                    uVar5 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b64b8;
                *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
                if (iVar4 != 0) {
                    uVar8 = 0x1805ab2cc;
                }
                *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
                *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd7d;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd95;
                func_0x0001802295a0(0x1804b6360, 0x4ee, 0x1804b64a0);
                iVar4 = *(int64_t *)(in_RCX + 0x5d8);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfda6;
                    iVar4 = func_0x0001802542f0();
                    *(int64_t *)(in_RCX + 0x5d8) = iVar4;
                    if (iVar4 != 0) goto code_r0x0001801dfdb2;
                } else {
code_r0x0001801dfdb2:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfdba;
                    func_0x000180254600(iVar4);
                }
                *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x2e;
code_r0x0001801dfeda:
                *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar7;
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = 10;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff04;
                func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar3, 0);
                return 1;
            }
        }
    } else if (((char)in_EDX == '/') && ((*(uint32_t *)(in_RCX + 0x5d0) & 0x200) != 0)) {
        uVar8 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfdea;
        iVar1 = func_0x0001801a60f0(uVar8);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe03;
            iVar4 = func_0x0001801fca50(10);
            if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                return 1;
            }
            uVar8 = 0x1805aadb1;
            iVar6 = 0x1805aadb1;
            if (iVar4 != 0) {
                iVar6 = iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe29;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe41;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar5 = 0x1805aadb1;
            uVar7 = 0x1804b64e8;
            if (iVar4 != 0) {
                uVar5 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b64e8;
            *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
            if (iVar4 != 0) {
                uVar8 = 0x1805ab2cc;
            }
            *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe94;
            func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfeac;
            func_0x0001802295a0(0x1804b6360, 0x4fc, 0x1804b64a0);
            iVar4 = *(int64_t *)(in_RCX + 0x5d8);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfebd;
                iVar4 = func_0x0001802542f0();
                *(int64_t *)(in_RCX + 0x5d8) = iVar4;
                if (iVar4 != 0) goto code_r0x0001801dfec9;
            } else {
code_r0x0001801dfec9:
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfed1;
                func_0x000180254600(iVar4);
            }
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1b;
            goto code_r0x0001801dfeda;
        }
    }
    uVar2 = (in_EDX & 0xff) + 0x100;
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff27;
    iVar4 = func_0x0001801fca50(uVar2);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return 1;
    }
    uVar8 = 0x1805aadb1;
    iVar6 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar6 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff4d;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff65;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar5 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar5 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b6508;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffb5;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, uVar2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffcd;
    func_0x0001802295a0(0x1804b6360, 0x501, 0x1804b64a0);
    iVar4 = *(int64_t *)(in_RCX + 0x5d8);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffde;
        iVar4 = func_0x0001802542f0();
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801dfff2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfff2;
    func_0x000180254600(iVar4);
code_r0x0001801dfff2:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = (uint64_t)uVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x1804b6508;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0xf;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e0021;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar3, 0);
    return 1;
}

// ============================================================
// Function: FUN_1801e0029
// Address: 0x1801e0029
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801dfc90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_78h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint32_t in_EDX;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dfca8;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if ((char)in_EDX == '\n') {
        if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x200) != 0) {
            uVar8 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfcd3;
            iVar1 = func_0x0001801a6130(uVar8);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfcec;
                iVar4 = func_0x0001801fca50(10);
                if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                    return 1;
                }
                uVar8 = 0x1805aadb1;
                iVar6 = 0x1805aadb1;
                if (iVar4 != 0) {
                    iVar6 = iVar4;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd12;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd2a;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar5 = 0x1805aadb1;
                uVar7 = 0x1804b64b8;
                if (iVar4 != 0) {
                    uVar5 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b64b8;
                *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
                if (iVar4 != 0) {
                    uVar8 = 0x1805ab2cc;
                }
                *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
                *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd7d;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfd95;
                func_0x0001802295a0(0x1804b6360, 0x4ee, 0x1804b64a0);
                iVar4 = *(int64_t *)(in_RCX + 0x5d8);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfda6;
                    iVar4 = func_0x0001802542f0();
                    *(int64_t *)(in_RCX + 0x5d8) = iVar4;
                    if (iVar4 != 0) goto code_r0x0001801dfdb2;
                } else {
code_r0x0001801dfdb2:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfdba;
                    func_0x000180254600(iVar4);
                }
                *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x2e;
code_r0x0001801dfeda:
                *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar7;
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = 10;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff04;
                func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar3, 0);
                return 1;
            }
        }
    } else if (((char)in_EDX == '/') && ((*(uint32_t *)(in_RCX + 0x5d0) & 0x200) != 0)) {
        uVar8 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfdea;
        iVar1 = func_0x0001801a60f0(uVar8);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe03;
            iVar4 = func_0x0001801fca50(10);
            if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
                return 1;
            }
            uVar8 = 0x1805aadb1;
            iVar6 = 0x1805aadb1;
            if (iVar4 != 0) {
                iVar6 = iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe29;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe41;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar5 = 0x1805aadb1;
            uVar7 = 0x1804b64e8;
            if (iVar4 != 0) {
                uVar5 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b64e8;
            *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
            if (iVar4 != 0) {
                uVar8 = 0x1805ab2cc;
            }
            *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfe94;
            func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfeac;
            func_0x0001802295a0(0x1804b6360, 0x4fc, 0x1804b64a0);
            iVar4 = *(int64_t *)(in_RCX + 0x5d8);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfebd;
                iVar4 = func_0x0001802542f0();
                *(int64_t *)(in_RCX + 0x5d8) = iVar4;
                if (iVar4 != 0) goto code_r0x0001801dfec9;
            } else {
code_r0x0001801dfec9:
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfed1;
                func_0x000180254600(iVar4);
            }
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1b;
            goto code_r0x0001801dfeda;
        }
    }
    uVar2 = (in_EDX & 0xff) + 0x100;
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff27;
    iVar4 = func_0x0001801fca50(uVar2);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return 1;
    }
    uVar8 = 0x1805aadb1;
    iVar6 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar6 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff4d;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dff65;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar5 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar5 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b6508;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar5;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_10h + iVar3) = iVar6;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffb5;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, uVar2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffcd;
    func_0x0001802295a0(0x1804b6360, 0x501, 0x1804b64a0);
    iVar4 = *(int64_t *)(in_RCX + 0x5d8);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dffde;
        iVar4 = func_0x0001802542f0();
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801dfff2;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfff2;
    func_0x000180254600(iVar4);
code_r0x0001801dfff2:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = (uint64_t)uVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x1804b6508;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0xf;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e0021;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar3, 0);
    return 1;
}

// ============================================================
// Function: FUN_1801e0050
// Address: 0x1801e0050
// Size: 118 bytes
// ============================================================
undefined8
fcn.1801e0050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar10;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e0061;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if ((*(uint32_t *)(in_RCX + 0x5d0) >> 9 & 1) != 0) {
        return 0;
    }
    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x1c000) != 0xc000) {
        return 0;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0093;
    func_0x000180208210(uVar8);
    if ((*(uint8_t *)(in_RCX + 0x5d0) & 0x80) == 0) {
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e00b5;
        iVar4 = func_0x0001801fca50(0x16d);
        if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_b0h + iVar3) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_R14;
        uVar10 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_R15;
        uVar8 = 0x1805aadb1;
        if (iVar4 != 0) {
            uVar8 = 0x1805ab2bc;
        }
        uVar9 = 0x1805aadb1;
        iVar7 = 0x1805aadb1;
        if (iVar4 != 0) {
            uVar9 = 0x1805ab2cc;
            iVar7 = iVar4;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0112;
        iVar5 = func_0x0001801fcb70(6);
        iVar4 = 0x1805aadb1;
        if (iVar5 != 0) {
            iVar4 = iVar5;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0124;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e013c;
        func_0x0001802295a0(0x1804b6360, 0xe01, 0x1804b7368);
        uVar6 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1804b6478;
        if (iVar5 != 0) {
            uVar6 = 0x1805ab2bc;
            uVar10 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar6;
        *(int64_t *)((int64_t)&var_20h + iVar3) = iVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar10;
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 6;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
        *(int64_t *)(&stack0x00000000 + iVar3) = iVar7;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = uVar9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01a0;
        func_0x0001802296d0(0x14, 0x17e, 0x1804b73a0, 0x16d);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01b8;
        func_0x0001802295a0(0x1804b6360, 0x4b0, 0x1804b6458);
        iVar4 = *(int64_t *)(in_RCX + 0x5d8);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01e1;
            iVar4 = func_0x0001802542f0();
            *(int64_t *)(in_RCX + 0x5d8) = iVar4;
            if (iVar4 == 0) goto code_r0x0001801e01f5;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01f5;
        func_0x000180254600(iVar4);
code_r0x0001801e01f5:
        *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x16d;
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = 6;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1804b6478;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x20;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e022d;
        func_0x0001801e2d20(in_RCX, (int64_t)&arg_38h + iVar3, 0);
        return 0;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0253;
    func_0x000180224990(uVar8, 0x1804b6360, 0x4b5);
    uVar8 = *(undefined8 *)(in_RCX + 0x3d8);
    *(undefined8 *)(in_RCX + 0x50) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0265;
    func_0x000180205100(uVar8);
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0271;
    func_0x000180207e80(uVar8);
    *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x200;
    iVar4 = *(int64_t *)(in_RCX + 0x58);
    if (iVar4 == 0) goto code_r0x0001801e0369;
    uVar8 = *(undefined8 *)(in_RCX + 0x60);
    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e029a;
    iVar7 = func_0x000180226610();
    if (iVar7 == 0) {
code_r0x0001801e0343:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e034b;
        func_0x000180226310(iVar7);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02b3;
        iVar2 = func_0x000180244300((int64_t)&arg_38h + iVar3, iVar7);
        if (iVar2 == 0) goto code_r0x0001801e0343;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02cb;
        iVar2 = func_0x0001801fe380((int64_t)&arg_38h + iVar3, iVar4, uVar8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02d9;
            func_0x000180243fb0();
            goto code_r0x0001801e0343;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02e0;
        func_0x000180244200((int64_t)&arg_38h + iVar3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02f2;
        iVar2 = func_0x0001802442e0((int64_t)&arg_38h + iVar3, (int64_t)&arg_a8h + iVar3);
        if (iVar2 == 0) goto code_r0x0001801e0343;
        uVar8 = *(undefined8 *)(in_RCX + 0x98);
        *(int64_t *)((int64_t)&var_18h + iVar3) = iVar7;
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x1801e3620;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = *(undefined8 *)((int64_t)&arg_a8h + iVar3);
        *(undefined8 *)(&stack0x00000000 + iVar3) = *(undefined8 *)(iVar7 + 8);
        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e033e;
        iVar4 = func_0x000180201cf0(uVar8, 1, 2, 7);
        if (iVar4 == 0) goto code_r0x0001801e0343;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0361;
    func_0x000180224990(uVar8, 0x1804b6360, 0x4cc);
    *(undefined8 *)(in_RCX + 0x58) = 0;
    *(undefined8 *)(in_RCX + 0x60) = 0;
code_r0x0001801e0369:
    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e037e;
        func_0x0001801e3ed0(in_RCX);
        uVar8 = *(undefined8 *)(in_RCX + 0x88);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e038a;
        func_0x000180207fd0(uVar8);
    }
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e039c;
    func_0x0001801e1a70(in_RCX, uVar1 & 7);
    return 1;
}

// ============================================================
// Function: FUN_1801e00c6
// Address: 0x1801e00c6
// Size: 278 bytes
// ============================================================
undefined8
fcn.1801e0050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar10;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e0061;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if ((*(uint32_t *)(in_RCX + 0x5d0) >> 9 & 1) != 0) {
        return 0;
    }
    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x1c000) != 0xc000) {
        return 0;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0093;
    func_0x000180208210(uVar8);
    if ((*(uint8_t *)(in_RCX + 0x5d0) & 0x80) == 0) {
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e00b5;
        iVar4 = func_0x0001801fca50(0x16d);
        if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_b0h + iVar3) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_R14;
        uVar10 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_R15;
        uVar8 = 0x1805aadb1;
        if (iVar4 != 0) {
            uVar8 = 0x1805ab2bc;
        }
        uVar9 = 0x1805aadb1;
        iVar7 = 0x1805aadb1;
        if (iVar4 != 0) {
            uVar9 = 0x1805ab2cc;
            iVar7 = iVar4;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0112;
        iVar5 = func_0x0001801fcb70(6);
        iVar4 = 0x1805aadb1;
        if (iVar5 != 0) {
            iVar4 = iVar5;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0124;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e013c;
        func_0x0001802295a0(0x1804b6360, 0xe01, 0x1804b7368);
        uVar6 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1804b6478;
        if (iVar5 != 0) {
            uVar6 = 0x1805ab2bc;
            uVar10 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar6;
        *(int64_t *)((int64_t)&var_20h + iVar3) = iVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar10;
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 6;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
        *(int64_t *)(&stack0x00000000 + iVar3) = iVar7;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = uVar9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01a0;
        func_0x0001802296d0(0x14, 0x17e, 0x1804b73a0, 0x16d);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01b8;
        func_0x0001802295a0(0x1804b6360, 0x4b0, 0x1804b6458);
        iVar4 = *(int64_t *)(in_RCX + 0x5d8);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01e1;
            iVar4 = func_0x0001802542f0();
            *(int64_t *)(in_RCX + 0x5d8) = iVar4;
            if (iVar4 == 0) goto code_r0x0001801e01f5;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01f5;
        func_0x000180254600(iVar4);
code_r0x0001801e01f5:
        *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x16d;
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = 6;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1804b6478;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x20;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e022d;
        func_0x0001801e2d20(in_RCX, (int64_t)&arg_38h + iVar3, 0);
        return 0;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0253;
    func_0x000180224990(uVar8, 0x1804b6360, 0x4b5);
    uVar8 = *(undefined8 *)(in_RCX + 0x3d8);
    *(undefined8 *)(in_RCX + 0x50) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0265;
    func_0x000180205100(uVar8);
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0271;
    func_0x000180207e80(uVar8);
    *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x200;
    iVar4 = *(int64_t *)(in_RCX + 0x58);
    if (iVar4 == 0) goto code_r0x0001801e0369;
    uVar8 = *(undefined8 *)(in_RCX + 0x60);
    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e029a;
    iVar7 = func_0x000180226610();
    if (iVar7 == 0) {
code_r0x0001801e0343:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e034b;
        func_0x000180226310(iVar7);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02b3;
        iVar2 = func_0x000180244300((int64_t)&arg_38h + iVar3, iVar7);
        if (iVar2 == 0) goto code_r0x0001801e0343;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02cb;
        iVar2 = func_0x0001801fe380((int64_t)&arg_38h + iVar3, iVar4, uVar8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02d9;
            func_0x000180243fb0();
            goto code_r0x0001801e0343;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02e0;
        func_0x000180244200((int64_t)&arg_38h + iVar3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02f2;
        iVar2 = func_0x0001802442e0((int64_t)&arg_38h + iVar3, (int64_t)&arg_a8h + iVar3);
        if (iVar2 == 0) goto code_r0x0001801e0343;
        uVar8 = *(undefined8 *)(in_RCX + 0x98);
        *(int64_t *)((int64_t)&var_18h + iVar3) = iVar7;
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x1801e3620;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = *(undefined8 *)((int64_t)&arg_a8h + iVar3);
        *(undefined8 *)(&stack0x00000000 + iVar3) = *(undefined8 *)(iVar7 + 8);
        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e033e;
        iVar4 = func_0x000180201cf0(uVar8, 1, 2, 7);
        if (iVar4 == 0) goto code_r0x0001801e0343;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0361;
    func_0x000180224990(uVar8, 0x1804b6360, 0x4cc);
    *(undefined8 *)(in_RCX + 0x58) = 0;
    *(undefined8 *)(in_RCX + 0x60) = 0;
code_r0x0001801e0369:
    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e037e;
        func_0x0001801e3ed0(in_RCX);
        uVar8 = *(undefined8 *)(in_RCX + 0x88);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e038a;
        func_0x000180207fd0(uVar8);
    }
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e039c;
    func_0x0001801e1a70(in_RCX, uVar1 & 7);
    return 1;
}

// ============================================================
// Function: FUN_1801e01dc
// Address: 0x1801e01dc
// Size: 467 bytes
// ============================================================
undefined8
fcn.1801e0050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 uVar10;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e0061;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if ((*(uint32_t *)(in_RCX + 0x5d0) >> 9 & 1) != 0) {
        return 0;
    }
    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x1c000) != 0xc000) {
        return 0;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0093;
    func_0x000180208210(uVar8);
    if ((*(uint8_t *)(in_RCX + 0x5d0) & 0x80) == 0) {
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e00b5;
        iVar4 = func_0x0001801fca50(0x16d);
        if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_b0h + iVar3) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_b8h + iVar3) = unaff_R14;
        uVar10 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_c0h + iVar3) = unaff_R15;
        uVar8 = 0x1805aadb1;
        if (iVar4 != 0) {
            uVar8 = 0x1805ab2bc;
        }
        uVar9 = 0x1805aadb1;
        iVar7 = 0x1805aadb1;
        if (iVar4 != 0) {
            uVar9 = 0x1805ab2cc;
            iVar7 = iVar4;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0112;
        iVar5 = func_0x0001801fcb70(6);
        iVar4 = 0x1805aadb1;
        if (iVar5 != 0) {
            iVar4 = iVar5;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0124;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e013c;
        func_0x0001802295a0(0x1804b6360, 0xe01, 0x1804b7368);
        uVar6 = 0x1805aadb1;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1804b6478;
        if (iVar5 != 0) {
            uVar6 = 0x1805ab2bc;
            uVar10 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar6;
        *(int64_t *)((int64_t)&var_20h + iVar3) = iVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = uVar10;
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 6;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar8;
        *(int64_t *)(&stack0x00000000 + iVar3) = iVar7;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = uVar9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01a0;
        func_0x0001802296d0(0x14, 0x17e, 0x1804b73a0, 0x16d);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01b8;
        func_0x0001802295a0(0x1804b6360, 0x4b0, 0x1804b6458);
        iVar4 = *(int64_t *)(in_RCX + 0x5d8);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01e1;
            iVar4 = func_0x0001802542f0();
            *(int64_t *)(in_RCX + 0x5d8) = iVar4;
            if (iVar4 == 0) goto code_r0x0001801e01f5;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e01f5;
        func_0x000180254600(iVar4);
code_r0x0001801e01f5:
        *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x16d;
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = 6;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1804b6478;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x20;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e022d;
        func_0x0001801e2d20(in_RCX, (int64_t)&arg_38h + iVar3, 0);
        return 0;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0253;
    func_0x000180224990(uVar8, 0x1804b6360, 0x4b5);
    uVar8 = *(undefined8 *)(in_RCX + 0x3d8);
    *(undefined8 *)(in_RCX + 0x50) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0265;
    func_0x000180205100(uVar8);
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0271;
    func_0x000180207e80(uVar8);
    *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x200;
    iVar4 = *(int64_t *)(in_RCX + 0x58);
    if (iVar4 == 0) goto code_r0x0001801e0369;
    uVar8 = *(undefined8 *)(in_RCX + 0x60);
    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e029a;
    iVar7 = func_0x000180226610();
    if (iVar7 == 0) {
code_r0x0001801e0343:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e034b;
        func_0x000180226310(iVar7);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02b3;
        iVar2 = func_0x000180244300((int64_t)&arg_38h + iVar3, iVar7);
        if (iVar2 == 0) goto code_r0x0001801e0343;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02cb;
        iVar2 = func_0x0001801fe380((int64_t)&arg_38h + iVar3, iVar4, uVar8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02d9;
            func_0x000180243fb0();
            goto code_r0x0001801e0343;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02e0;
        func_0x000180244200((int64_t)&arg_38h + iVar3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e02f2;
        iVar2 = func_0x0001802442e0((int64_t)&arg_38h + iVar3, (int64_t)&arg_a8h + iVar3);
        if (iVar2 == 0) goto code_r0x0001801e0343;
        uVar8 = *(undefined8 *)(in_RCX + 0x98);
        *(int64_t *)((int64_t)&var_18h + iVar3) = iVar7;
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x1801e3620;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = *(undefined8 *)((int64_t)&arg_a8h + iVar3);
        *(undefined8 *)(&stack0x00000000 + iVar3) = *(undefined8 *)(iVar7 + 8);
        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e033e;
        iVar4 = func_0x000180201cf0(uVar8, 1, 2, 7);
        if (iVar4 == 0) goto code_r0x0001801e0343;
    }
    uVar8 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e0361;
    func_0x000180224990(uVar8, 0x1804b6360, 0x4cc);
    *(undefined8 *)(in_RCX + 0x58) = 0;
    *(undefined8 *)(in_RCX + 0x60) = 0;
code_r0x0001801e0369:
    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e037e;
        func_0x0001801e3ed0(in_RCX);
        uVar8 = *(undefined8 *)(in_RCX + 0x88);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e038a;
        func_0x000180207fd0(uVar8);
    }
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e039c;
    func_0x0001801e1a70(in_RCX, uVar1 & 7);
    return 1;
}

// ============================================================
// Function: FUN_1801e03b0
// Address: 0x1801e03b0
// Size: 436 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801e03b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
             int64_t arg_c0h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t in_ECX;
    int32_t in_EDX;
    uint32_t uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    uint32_t uVar11;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 uVar12;
    undefined8 unaff_R15;
    undefined8 uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801e03c6;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_ECX != 1) {
        if (in_ECX == 2) {
            uVar8 = 2;
        } else {
            if (in_ECX != 3) {
                return 0;
            }
            uVar8 = 3;
        }
        iVar1 = *(int64_t *)((int64_t)&arg_c8h + iVar4);
        if (in_EDX == 0) {
            if ((*(uint32_t *)(iVar1 + 0x5d0) >> 0x11 & 7) < uVar8) {
                uVar11 = 0;
                do {
                    if (uVar11 == 0) {
                        iVar5 = 0x410;
                    } else if ((uVar11 == 1) || (uVar11 != 2)) {
                        iVar5 = 0x420;
                    } else {
                        iVar5 = 0x418;
                    }
                    iVar5 = *(int64_t *)(iVar5 + iVar1);
                    *(undefined8 *)((int64_t)&arg_c8h + iVar4) = 0;
                    *(undefined4 *)((int64_t)&arg_98h + iVar4) = 0;
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e04d1;
                        iVar3 = func_0x0001801e6a70(iVar5, (int64_t)&arg_c8h + iVar4, (int64_t)&arg_98h + iVar4);
                        if ((iVar3 == 0) || (*(int64_t *)((int64_t)&arg_c8h + iVar4) != 0)) {
                            *(undefined8 *)((int64_t)&arg_58h + iVar4) = 0;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0553;
                            iVar5 = func_0x0001801fca50(10);
                            if ((*(uint8_t *)(iVar1 + 0x5d4) & 0x40) != 0) {
                                return 0;
                            }
                            *(undefined8 *)((int64_t)&arg_a0h + iVar4) = unaff_R12;
                            uVar12 = 0x1805aadb1;
                            *(undefined8 *)((int64_t)&arg_a8h + iVar4) = unaff_R15;
                            uVar9 = 0x1805aadb1;
                            if (iVar5 != 0) {
                                uVar9 = 0x1805ab2bc;
                            }
                            uVar10 = 0x1805aadb1;
                            iVar2 = 0x1805aadb1;
                            if (iVar5 != 0) {
                                uVar10 = 0x1805ab2cc;
                                iVar2 = iVar5;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05a8;
                            iVar6 = func_0x0001801fcb70(6);
                            iVar5 = 0x1805aadb1;
                            if (iVar6 != 0) {
                                iVar5 = iVar6;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05ba;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05d2;
                            func_0x0001802295a0(0x1804b6360, 0xe01, 0x1804b7368);
                            uVar7 = 0x1805aadb1;
                            *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0x1804b6418;
                            if (iVar6 != 0) {
                                uVar7 = 0x1805ab2bc;
                                uVar12 = 0x1805ab2cc;
                            }
                            *(undefined8 *)((int64_t)&arg_28h + iVar4) = uVar7;
                            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar12;
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = 6;
                            *(undefined8 *)((int64_t)&uStackX_8 + iVar4) = uVar9;
                            *(int64_t *)(&stack0x00000000 + iVar4) = iVar2;
                            *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0636;
                            func_0x0001802296d0(0x14, 0x17e, 0x1804b73a0, 10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e064e;
                            func_0x0001802295a0(0x1804b6360, 0x488, 0x1804b6438);
                            iVar5 = *(int64_t *)(iVar1 + 0x5d8);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e066f;
                                iVar5 = func_0x0001802542f0();
                                *(int64_t *)(iVar1 + 0x5d8) = iVar5;
                                if (iVar5 == 0) goto code_r0x0001801e0683;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0683;
                            func_0x000180254600(iVar5);
code_r0x0001801e0683:
                            *(uint32_t *)(iVar1 + 0x5d4) = *(uint32_t *)(iVar1 + 0x5d4) | 0x40;
                            *(undefined8 *)((int64_t)&arg_38h + iVar4) = 10;
                            *(undefined8 *)((int64_t)&arg_40h + iVar4) = 6;
                            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0x1804b6418;
                            *(undefined8 *)((int64_t)&arg_50h + iVar4) = 0x1e;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e06bb;
                            func_0x0001801e2d20(iVar1, (int64_t)&arg_38h + iVar4, 0);
                            return 0;
                        }
                    }
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar8);
                uVar9 = *(undefined8 *)(iVar1 + 0x3d8);
                *(undefined8 *)(&stack0x00000000 + iVar4) = *(undefined8 *)((int64_t)&arg_c0h + iVar4);
                *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_b8h + iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0513;
                iVar3 = func_0x000180205530(uVar9, uVar8, in_R8 & 0xffffffff, in_R9);
                if (iVar3 != 0) {
                    *(uint32_t *)(iVar1 + 0x5d0) = *(uint32_t *)(iVar1 + 0x5d0) & 0xfff1ffff | (uVar8 | 0x200) << 0x11;
                    return 1;
                }
            }
        } else if ((*(uint32_t *)(iVar1 + 0x5d0) >> 0xe & 7) < uVar8) {
            uVar9 = *(undefined8 *)(iVar1 + 0x3d0);
            *(undefined8 *)(&stack0x00000000 + iVar4) = *(undefined8 *)((int64_t)&arg_c0h + iVar4);
            *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_b8h + iVar4);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e043b;
            iVar3 = func_0x0001801fb890(uVar9, uVar8);
            if (iVar3 != 0) {
                *(uint32_t *)(iVar1 + 0x5d0) = *(uint32_t *)(iVar1 + 0x5d0) & 0xfffe3fff | uVar8 << 0xe;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e0564
// Address: 0x1801e0564
// Size: 262 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801e03b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
             int64_t arg_c0h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t in_ECX;
    int32_t in_EDX;
    uint32_t uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    uint32_t uVar11;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 uVar12;
    undefined8 unaff_R15;
    undefined8 uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801e03c6;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_ECX != 1) {
        if (in_ECX == 2) {
            uVar8 = 2;
        } else {
            if (in_ECX != 3) {
                return 0;
            }
            uVar8 = 3;
        }
        iVar1 = *(int64_t *)((int64_t)&arg_c8h + iVar4);
        if (in_EDX == 0) {
            if ((*(uint32_t *)(iVar1 + 0x5d0) >> 0x11 & 7) < uVar8) {
                uVar11 = 0;
                do {
                    if (uVar11 == 0) {
                        iVar5 = 0x410;
                    } else if ((uVar11 == 1) || (uVar11 != 2)) {
                        iVar5 = 0x420;
                    } else {
                        iVar5 = 0x418;
                    }
                    iVar5 = *(int64_t *)(iVar5 + iVar1);
                    *(undefined8 *)((int64_t)&arg_c8h + iVar4) = 0;
                    *(undefined4 *)((int64_t)&arg_98h + iVar4) = 0;
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e04d1;
                        iVar3 = func_0x0001801e6a70(iVar5, (int64_t)&arg_c8h + iVar4, (int64_t)&arg_98h + iVar4);
                        if ((iVar3 == 0) || (*(int64_t *)((int64_t)&arg_c8h + iVar4) != 0)) {
                            *(undefined8 *)((int64_t)&arg_58h + iVar4) = 0;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0553;
                            iVar5 = func_0x0001801fca50(10);
                            if ((*(uint8_t *)(iVar1 + 0x5d4) & 0x40) != 0) {
                                return 0;
                            }
                            *(undefined8 *)((int64_t)&arg_a0h + iVar4) = unaff_R12;
                            uVar12 = 0x1805aadb1;
                            *(undefined8 *)((int64_t)&arg_a8h + iVar4) = unaff_R15;
                            uVar9 = 0x1805aadb1;
                            if (iVar5 != 0) {
                                uVar9 = 0x1805ab2bc;
                            }
                            uVar10 = 0x1805aadb1;
                            iVar2 = 0x1805aadb1;
                            if (iVar5 != 0) {
                                uVar10 = 0x1805ab2cc;
                                iVar2 = iVar5;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05a8;
                            iVar6 = func_0x0001801fcb70(6);
                            iVar5 = 0x1805aadb1;
                            if (iVar6 != 0) {
                                iVar5 = iVar6;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05ba;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05d2;
                            func_0x0001802295a0(0x1804b6360, 0xe01, 0x1804b7368);
                            uVar7 = 0x1805aadb1;
                            *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0x1804b6418;
                            if (iVar6 != 0) {
                                uVar7 = 0x1805ab2bc;
                                uVar12 = 0x1805ab2cc;
                            }
                            *(undefined8 *)((int64_t)&arg_28h + iVar4) = uVar7;
                            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar12;
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = 6;
                            *(undefined8 *)((int64_t)&uStackX_8 + iVar4) = uVar9;
                            *(int64_t *)(&stack0x00000000 + iVar4) = iVar2;
                            *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0636;
                            func_0x0001802296d0(0x14, 0x17e, 0x1804b73a0, 10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e064e;
                            func_0x0001802295a0(0x1804b6360, 0x488, 0x1804b6438);
                            iVar5 = *(int64_t *)(iVar1 + 0x5d8);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e066f;
                                iVar5 = func_0x0001802542f0();
                                *(int64_t *)(iVar1 + 0x5d8) = iVar5;
                                if (iVar5 == 0) goto code_r0x0001801e0683;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0683;
                            func_0x000180254600(iVar5);
code_r0x0001801e0683:
                            *(uint32_t *)(iVar1 + 0x5d4) = *(uint32_t *)(iVar1 + 0x5d4) | 0x40;
                            *(undefined8 *)((int64_t)&arg_38h + iVar4) = 10;
                            *(undefined8 *)((int64_t)&arg_40h + iVar4) = 6;
                            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0x1804b6418;
                            *(undefined8 *)((int64_t)&arg_50h + iVar4) = 0x1e;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e06bb;
                            func_0x0001801e2d20(iVar1, (int64_t)&arg_38h + iVar4, 0);
                            return 0;
                        }
                    }
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar8);
                uVar9 = *(undefined8 *)(iVar1 + 0x3d8);
                *(undefined8 *)(&stack0x00000000 + iVar4) = *(undefined8 *)((int64_t)&arg_c0h + iVar4);
                *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_b8h + iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0513;
                iVar3 = func_0x000180205530(uVar9, uVar8, in_R8 & 0xffffffff, in_R9);
                if (iVar3 != 0) {
                    *(uint32_t *)(iVar1 + 0x5d0) = *(uint32_t *)(iVar1 + 0x5d0) & 0xfff1ffff | (uVar8 | 0x200) << 0x11;
                    return 1;
                }
            }
        } else if ((*(uint32_t *)(iVar1 + 0x5d0) >> 0xe & 7) < uVar8) {
            uVar9 = *(undefined8 *)(iVar1 + 0x3d0);
            *(undefined8 *)(&stack0x00000000 + iVar4) = *(undefined8 *)((int64_t)&arg_c0h + iVar4);
            *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_b8h + iVar4);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e043b;
            iVar3 = func_0x0001801fb890(uVar9, uVar8);
            if (iVar3 != 0) {
                *(uint32_t *)(iVar1 + 0x5d0) = *(uint32_t *)(iVar1 + 0x5d0) & 0xfffe3fff | uVar8 << 0xe;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e066a
// Address: 0x1801e066a
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801e03b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
             int64_t arg_c0h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t in_ECX;
    int32_t in_EDX;
    uint32_t uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    uint32_t uVar11;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 uVar12;
    undefined8 unaff_R15;
    undefined8 uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801e03c6;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_ECX != 1) {
        if (in_ECX == 2) {
            uVar8 = 2;
        } else {
            if (in_ECX != 3) {
                return 0;
            }
            uVar8 = 3;
        }
        iVar1 = *(int64_t *)((int64_t)&arg_c8h + iVar4);
        if (in_EDX == 0) {
            if ((*(uint32_t *)(iVar1 + 0x5d0) >> 0x11 & 7) < uVar8) {
                uVar11 = 0;
                do {
                    if (uVar11 == 0) {
                        iVar5 = 0x410;
                    } else if ((uVar11 == 1) || (uVar11 != 2)) {
                        iVar5 = 0x420;
                    } else {
                        iVar5 = 0x418;
                    }
                    iVar5 = *(int64_t *)(iVar5 + iVar1);
                    *(undefined8 *)((int64_t)&arg_c8h + iVar4) = 0;
                    *(undefined4 *)((int64_t)&arg_98h + iVar4) = 0;
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e04d1;
                        iVar3 = func_0x0001801e6a70(iVar5, (int64_t)&arg_c8h + iVar4, (int64_t)&arg_98h + iVar4);
                        if ((iVar3 == 0) || (*(int64_t *)((int64_t)&arg_c8h + iVar4) != 0)) {
                            *(undefined8 *)((int64_t)&arg_58h + iVar4) = 0;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0553;
                            iVar5 = func_0x0001801fca50(10);
                            if ((*(uint8_t *)(iVar1 + 0x5d4) & 0x40) != 0) {
                                return 0;
                            }
                            *(undefined8 *)((int64_t)&arg_a0h + iVar4) = unaff_R12;
                            uVar12 = 0x1805aadb1;
                            *(undefined8 *)((int64_t)&arg_a8h + iVar4) = unaff_R15;
                            uVar9 = 0x1805aadb1;
                            if (iVar5 != 0) {
                                uVar9 = 0x1805ab2bc;
                            }
                            uVar10 = 0x1805aadb1;
                            iVar2 = 0x1805aadb1;
                            if (iVar5 != 0) {
                                uVar10 = 0x1805ab2cc;
                                iVar2 = iVar5;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05a8;
                            iVar6 = func_0x0001801fcb70(6);
                            iVar5 = 0x1805aadb1;
                            if (iVar6 != 0) {
                                iVar5 = iVar6;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05ba;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e05d2;
                            func_0x0001802295a0(0x1804b6360, 0xe01, 0x1804b7368);
                            uVar7 = 0x1805aadb1;
                            *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0x1804b6418;
                            if (iVar6 != 0) {
                                uVar7 = 0x1805ab2bc;
                                uVar12 = 0x1805ab2cc;
                            }
                            *(undefined8 *)((int64_t)&arg_28h + iVar4) = uVar7;
                            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar12;
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = 6;
                            *(undefined8 *)((int64_t)&uStackX_8 + iVar4) = uVar9;
                            *(int64_t *)(&stack0x00000000 + iVar4) = iVar2;
                            *(undefined8 *)((int64_t)&var_8h + iVar4) = uVar10;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0636;
                            func_0x0001802296d0(0x14, 0x17e, 0x1804b73a0, 10);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e064e;
                            func_0x0001802295a0(0x1804b6360, 0x488, 0x1804b6438);
                            iVar5 = *(int64_t *)(iVar1 + 0x5d8);
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e066f;
                                iVar5 = func_0x0001802542f0();
                                *(int64_t *)(iVar1 + 0x5d8) = iVar5;
                                if (iVar5 == 0) goto code_r0x0001801e0683;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0683;
                            func_0x000180254600(iVar5);
code_r0x0001801e0683:
                            *(uint32_t *)(iVar1 + 0x5d4) = *(uint32_t *)(iVar1 + 0x5d4) | 0x40;
                            *(undefined8 *)((int64_t)&arg_38h + iVar4) = 10;
                            *(undefined8 *)((int64_t)&arg_40h + iVar4) = 6;
                            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0x1804b6418;
                            *(undefined8 *)((int64_t)&arg_50h + iVar4) = 0x1e;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e06bb;
                            func_0x0001801e2d20(iVar1, (int64_t)&arg_38h + iVar4, 0);
                            return 0;
                        }
                    }
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar8);
                uVar9 = *(undefined8 *)(iVar1 + 0x3d8);
                *(undefined8 *)(&stack0x00000000 + iVar4) = *(undefined8 *)((int64_t)&arg_c0h + iVar4);
                *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_b8h + iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e0513;
                iVar3 = func_0x000180205530(uVar9, uVar8, in_R8 & 0xffffffff, in_R9);
                if (iVar3 != 0) {
                    *(uint32_t *)(iVar1 + 0x5d0) = *(uint32_t *)(iVar1 + 0x5d0) & 0xfff1ffff | (uVar8 | 0x200) << 0x11;
                    return 1;
                }
            }
        } else if ((*(uint32_t *)(iVar1 + 0x5d0) >> 0xe & 7) < uVar8) {
            uVar9 = *(undefined8 *)(iVar1 + 0x3d0);
            *(undefined8 *)(&stack0x00000000 + iVar4) = *(undefined8 *)((int64_t)&arg_c0h + iVar4);
            *(undefined8 *)((int64_t)&var_8h + iVar4) = *(undefined8 *)((int64_t)&arg_b8h + iVar4);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801e043b;
            iVar3 = func_0x0001801fb890(uVar9, uVar8);
            if (iVar3 != 0) {
                *(uint32_t *)(iVar1 + 0x5d0) = *(uint32_t *)(iVar1 + 0x5d0) & 0xfffe3fff | uVar8 << 0xe;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e06e0
// Address: 0x1801e06e0
// Size: 418 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801e06e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t **in_RCX;
    int64_t **ppiVar11;
    undefined4 *in_R8;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e06fe;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e0713;
    iVar9 = func_0x00018026be40(in_RCX + 0xd);
    if (iVar9 != 0) {
        uVar6 = in_R9[1];
        uVar7 = in_R9[2];
        uVar8 = in_R9[3];
        ppiVar1 = in_RCX + 0x85;
        *(undefined4 *)ppiVar1 = *in_R9;
        *(undefined4 *)((int64_t)in_RCX + 0x42c) = uVar6;
        *(undefined4 *)(in_RCX + 0x86) = uVar7;
        *(undefined4 *)((int64_t)in_RCX + 0x434) = uVar8;
        *(undefined4 *)(in_RCX + 0x87) = in_R9[4];
        ppiVar11 = *(int64_t ***)((int64_t)&arg_58h + iVar10);
        *(undefined *)((int64_t)in_RCX + 0x43c) = *(undefined *)(in_R9 + 5);
        uVar6 = in_R8[1];
        uVar7 = in_R8[2];
        uVar8 = in_R8[3];
        *(undefined4 *)((int64_t)in_RCX + 0x491) = *in_R8;
        *(undefined4 *)((int64_t)in_RCX + 0x495) = uVar6;
        *(undefined4 *)((int64_t)in_RCX + 0x499) = uVar7;
        *(undefined4 *)((int64_t)in_RCX + 0x49d) = uVar8;
        *(undefined4 *)((int64_t)in_RCX + 0x4a1) = in_R8[4];
        *(undefined *)((int64_t)in_RCX + 0x4a5) = *(undefined *)(in_R8 + 5);
        *(undefined *)((int64_t)in_RCX + 0x43d) = 0;
        if (ppiVar11 != (int64_t **)0x0) {
            uVar6 = *(undefined4 *)((int64_t)ppiVar11 + 4);
            uVar7 = *(undefined4 *)(ppiVar11 + 1);
            uVar8 = *(undefined4 *)((int64_t)ppiVar11 + 0xc);
            *(undefined4 *)((int64_t)in_RCX + 0x43d) = *(undefined4 *)ppiVar11;
            *(undefined4 *)((int64_t)in_RCX + 0x441) = uVar6;
            *(undefined4 *)((int64_t)in_RCX + 0x445) = uVar7;
            *(undefined4 *)((int64_t)in_RCX + 0x449) = uVar8;
            *(undefined4 *)((int64_t)in_RCX + 0x44d) = *(undefined4 *)(ppiVar11 + 2);
            *(undefined *)((int64_t)in_RCX + 0x451) = *(undefined *)((int64_t)ppiVar11 + 0x14);
        }
        piVar2 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e0794;
        iVar9 = func_0x0001802081b0(piVar2, in_RCX + 0xd);
        if (iVar9 != 0) {
            piVar2 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e07af;
            iVar9 = func_0x000180207ff0(piVar2, (int64_t)in_RCX + 0x491);
            if (iVar9 != 0) {
                piVar2 = in_RCX[0x11];
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e07ca;
                iVar9 = func_0x000180208060(piVar2, (int64_t)in_RCX + 0x47c);
                if (iVar9 != 0) {
                    piVar2 = in_RCX[0x7a];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e07e8;
                    func_0x0001801fb930(piVar2, 0x1801defe0, in_RCX);
                    piVar2 = in_RCX[0x11];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e07fe;
                    func_0x0001802081f0(piVar2, 0x1801defe0, in_RCX);
                    puVar3 = (undefined8 *)**in_RCX;
                    *(int64_t **)((int64_t)&var_10h + iVar10) = in_RCX[0x7a];
                    *(undefined8 *)((int64_t)&var_8h + iVar10) = 0;
                    uVar4 = puVar3[1];
                    uVar5 = *puVar3;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e082e;
                    iVar9 = func_0x0001801f9c30(uVar5, uVar4, ppiVar1, 1);
                    if (iVar9 != 0) {
                        piVar2 = in_RCX[7];
                        if (ppiVar11 == (int64_t **)0x0) {
                            ppiVar11 = ppiVar1;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e0848;
                        iVar9 = func_0x000180200d80(piVar2, in_RCX, ppiVar11);
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1801e0859;
                            func_0x0001801e1a70(in_RCX, 1);
                            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) & 0xffffffbf;
                            return 1;
                        }
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e0890
// Address: 0x1801e0890
// Size: 4504 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_6eh
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_87h

void fcn.1801e0890(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_118h
                  )
{
    uint8_t uVar1;
    undefined uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    bool bVar9;
    bool bVar10;
    bool bVar11;
    bool bVar12;
    bool bVar13;
    bool bVar14;
    int32_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    int32_t *piVar18;
    undefined8 uVar19;
    uint64_t uVar20;
    int64_t iVar21;
    undefined8 in_RCX;
    uint64_t uVar22;
    uint64_t in_RDX;
    int64_t iVar23;
    int64_t iVar24;
    int64_t in_R8;
    int32_t iVar25;
    undefined8 uVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_70h;
    undefined auStack_68 [16];
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_30h;
    
    var_30h = 0x1801e08b7;
    iVar17 = func_0x00018045a350();
    iVar17 = -iVar17;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar17);
    piVar18 = *(int32_t **)(in_R8 + 0x30);
    iVar23 = 0x1804b6518;
    bVar5 = false;
    *(undefined4 *)((int64_t)&arg_48h + iVar17 + 4) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar17) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar17) = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar17) = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar17 + 4) = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar17) = 0;
    bVar12 = false;
    bVar13 = false;
    *(undefined4 *)((int64_t)&arg_50h + iVar17 + 4) = 0;
    bVar8 = false;
    bVar10 = false;
    bVar9 = false;
    bVar11 = false;
    bVar14 = false;
    var_98h = 0;
    var_90h = 0;
    if (piVar18 == (int32_t *)0x0) {
code_r0x0001801e18aa:
        var_a0h = 0;
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e18b8;
        iVar23 = func_0x0001801fca50(1);
        if ((*(uint8_t *)(in_R8 + 0x5d4) & 0x40) != 0) goto code_r0x0001801e19b6;
        uVar26 = 0x1805aadb1;
        iVar21 = 0x1805aadb1;
        if (iVar23 != 0) {
            iVar21 = iVar23;
        }
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e18de;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e18f6;
        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
        uVar19 = 0x1805aadb1;
        iVar24 = 0x1804b6548;
        if (iVar23 != 0) {
            uVar19 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar17) = 0x1804b6548;
        *(undefined8 *)((int64_t)&var_8h + iVar17) = uVar19;
        if (iVar23 != 0) {
            uVar26 = 0x1805ab2cc;
        }
        *(int64_t *)(&stack0x00000000 + iVar17) = iVar21;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar17) = uVar26;
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1949;
        func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1961;
        func_0x0001802295a0(0x1804b6360, 0x565, 0x1804b6530);
        iVar23 = *(int64_t *)(in_R8 + 0x5d8);
        if (iVar23 == 0) {
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1972;
            iVar23 = func_0x0001802542f0();
            *(int64_t *)(in_R8 + 0x5d8) = iVar23;
            if (iVar23 != 0) goto code_r0x0001801e197e;
        } else {
code_r0x0001801e197e:
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1986;
            func_0x000180254600(iVar23);
        }
        var_a8h = 0x1c;
code_r0x0001801e1992:
        var_b8h = 0;
        var_c0h = 1;
        var_b0h = iVar24;
    } else {
        if (*piVar18 != 0) {
            if ((char)*piVar18 < '\0') {
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e093f;
                piVar18 = (int32_t *)func_0x0001801bda50(piVar18);
                if (piVar18 != (int32_t *)0x0) goto code_r0x0001801e094a;
            }
            goto code_r0x0001801e18aa;
        }
code_r0x0001801e094a:
        uVar3 = *(uint32_t *)(in_R8 + 0x5d0);
        if (((uVar3 >> 0x19 & 1) == 0) || (piVar18[0x232] == 0)) {
            if (-1 < (char)uVar3) goto code_r0x0001801e099f;
            iVar23 = 0x1804b6568;
            goto code_r0x0001801e17b1;
        }
        if ((char)uVar3 < '\0') {
            *(undefined8 *)(in_R8 + 0x508) = 0;
            *(uint32_t *)(in_R8 + 0x5d0) = uVar3 & 0xfffffeff;
            uVar26 = *(undefined8 *)(in_R8 + 0x50);
            *(undefined8 *)(in_R8 + 0x510) = 0;
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0999;
            func_0x000180224990(uVar26, 0x1804b6360, 0x571);
            *(undefined8 *)(in_R8 + 0x50) = 0;
        }
code_r0x0001801e099f:
        if (0x7fffffffffffffff < in_RDX) {
            var_a0h = 0;
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e09c0;
            iVar23 = func_0x0001801fca50(1);
            if ((*(uint8_t *)(in_R8 + 0x5d4) & 0x40) != 0) goto code_r0x0001801e19b6;
            uVar26 = 0x1805aadb1;
            iVar21 = 0x1805aadb1;
            if (iVar23 != 0) {
                iVar21 = iVar23;
            }
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e09e6;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e09fe;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar19 = 0x1805aadb1;
            iVar24 = 0x1804b6590;
            if (iVar23 != 0) {
                uVar19 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar17) = 0x1804b6590;
            *(undefined8 *)((int64_t)&var_8h + iVar17) = uVar19;
            if (iVar23 != 0) {
                uVar26 = 0x1805ab2cc;
            }
            *(int64_t *)(&stack0x00000000 + iVar17) = iVar21;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar17) = uVar26;
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0a51;
            func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0a69;
            func_0x0001802295a0(0x1804b6360, 0x57a, 0x1804b6530);
            iVar23 = *(int64_t *)(in_R8 + 0x5d8);
            if (iVar23 == 0) {
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0a7a;
                iVar23 = func_0x0001802542f0();
                *(int64_t *)(in_R8 + 0x5d8) = iVar23;
                if (iVar23 != 0) goto code_r0x0001801e0a86;
            } else {
code_r0x0001801e0a86:
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0a8e;
                func_0x000180254600(iVar23);
            }
            var_a8h = 0x20;
            goto code_r0x0001801e1992;
        }
        *(undefined8 *)((int64_t)&arg_30h + iVar17) = in_RCX;
        *(uint64_t *)((int64_t)&arg_38h + iVar17) = in_RDX;
        bVar6 = bVar5;
        bVar7 = bVar5;
        if (in_RDX == 0) {
code_r0x0001801e17aa:
            iVar23 = 0x1804b6d48;
        } else {
            do {
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0ae2;
                iVar15 = func_0x0001801fec10((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17);
                if (iVar15 == 0) goto code_r0x0001801e17b1;
    // switch table (17 cases) at 0x1801e19e4
                switch(*(undefined8 *)((int64_t)&arg_28h + iVar17)) {
                case 0:
                    if (bVar5) {
                        iVar23 = 0x1804b65b8;
                    } else if ((*(uint32_t *)(in_R8 + 0x5d0) & 0x2000000) == 0) {
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0b2e;
                        iVar15 = func_0x0001801fdb80((int64_t)&arg_30h + iVar17, 0, &var_88h);
                        if (iVar15 == 0) {
                            iVar23 = 0x1804b6608;
                        } else {
                            uVar1 = *(uint8_t *)(in_R8 + 0x428);
                            if ((uVar1 == (uint8_t)var_88h) && (uVar1 < 0x15)) {
                                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0b61;
                                iVar15 = func_0x000180497f30(in_R8 + 0x429, (int64_t)&var_88h + 1, uVar1);
                                if (iVar15 == 0) {
                                    bVar5 = true;
                                    break;
                                }
                            }
                            iVar23 = 0x1804b6620;
                        }
                    } else {
                        iVar23 = 0x1804b65e0;
                    }
                    goto code_r0x0001801e17b1;
                case 1:
                    if (bVar9) {
                        iVar23 = 0x1804b6a60;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0ef9;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if (iVar15 == 0) {
                        iVar23 = 0x1804b6a88;
                        goto code_r0x0001801e17b1;
                    }
                    uVar22 = *(uint64_t *)(in_R8 + 0x518);
                    uVar4 = *(uint64_t *)((int64_t)&var_20h + iVar17);
                    *(uint64_t *)(in_R8 + 0x520) = uVar4;
                    uVar20 = uVar4;
                    if (((uVar22 != 0) && (uVar20 = uVar22, uVar4 != 0)) && (uVar20 = uVar4, uVar22 < uVar4)) {
                        uVar20 = uVar22;
                    }
                    *(uint64_t *)(in_R8 + 0x528) = uVar20;
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0f39;
                    func_0x0001801e3460(in_R8);
                    var_98h = *(int64_t *)((int64_t)&var_20h + iVar17);
                    bVar9 = true;
                    break;
                case 2:
                    if (bVar12) {
                        iVar23 = 0x1804b6b58;
                        goto code_r0x0001801e17b1;
                    }
                    if ((*(uint32_t *)(in_R8 + 0x5d0) & 0x2000000) != 0) {
                        iVar23 = 0x1804b6b88;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e100d;
                    var_90h = func_0x0001801fdaa0((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, &var_c8h);
                    if ((var_90h == 0) || (var_c8h != 0x10)) {
                        iVar23 = 0x1804b6bc0;
                        goto code_r0x0001801e17b1;
                    }
                    uVar26 = *(undefined8 *)(in_R8 + 0x4a8);
                    uVar19 = *(undefined8 *)(in_R8 + 0x40);
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e103b;
                    iVar15 = func_0x000180201190(uVar19, in_R8, uVar26, var_90h);
                    if (iVar15 == 0) {
                        iVar23 = 0x1804b6be8;
                        goto code_r0x0001801e17b1;
                    }
                    bVar12 = true;
                    break;
                case 3:
                    if (bVar10) {
                        iVar23 = 0x1804b6aa8;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0f6c;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if ((iVar15 == 0) || (*(uint64_t *)((int64_t)&var_20h + iVar17) < 0x4b0)) {
                        iVar23 = 0x1804b6ad8;
                        goto code_r0x0001801e17b1;
                    }
                    *(uint64_t *)(in_R8 + 0x530) = *(uint64_t *)((int64_t)&var_20h + iVar17);
                    bVar10 = true;
                    break;
                case 4:
                    if (*(int32_t *)((int64_t)&arg_48h + iVar17 + 4) != 0) {
                        iVar23 = 0x1804b6788;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0c80;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if (iVar15 == 0) {
                        iVar23 = 0x1804b67b0;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0c99;
                    func_0x0001801e5b80(in_R8 + 0xa0, *(undefined8 *)((int64_t)&var_20h + iVar17));
                    *(undefined4 *)((int64_t)&arg_48h + iVar17 + 4) = 1;
                    break;
                case 5:
                    if (*(int32_t *)((int64_t)&var_18h + iVar17) == 0) {
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0cc5;
                        iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                     (int64_t)&var_20h + iVar17);
                        if (iVar15 != 0) {
                            iVar15 = 1;
                            *(undefined8 *)(in_R8 + 0x4e0) = *(undefined8 *)((int64_t)&var_20h + iVar17);
                            *(undefined4 *)((int64_t)&var_18h + iVar17) = 1;
                            goto code_r0x0001801e10fa;
                        }
                        iVar23 = 0x1804b6810;
                    } else {
                        iVar23 = 0x1804b67d0;
                    }
                    goto code_r0x0001801e17b1;
                case 6:
                    if (*(int32_t *)((int64_t)&arg_48h + iVar17) != 0) {
                        iVar23 = 0x1804b6840;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0d08;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if (iVar15 == 0) {
                        iVar23 = 0x1804b6880;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)(in_R8 + 0x4d8) = *(undefined8 *)((int64_t)&var_20h + iVar17);
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0d34;
                    func_0x0001801e82d0(in_R8 + 0x300, 0x1801e5830, (int64_t)&var_20h + iVar17);
                    *(undefined4 *)((int64_t)&arg_48h + iVar17) = 1;
                    break;
                case 7:
                    if (*(int32_t *)((int64_t)&arg_50h + iVar17) != 0) {
                        iVar23 = 0x1804b68b8;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0d60;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if (iVar15 == 0) {
                        iVar23 = 0x1804b68f0;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)(in_R8 + 0x4e8) = *(undefined8 *)((int64_t)&var_20h + iVar17);
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0d8c;
                    func_0x0001801e82d0(in_R8 + 0x300, 0x1801e5860, (int64_t)&var_20h + iVar17);
                    *(undefined4 *)((int64_t)&arg_50h + iVar17) = 1;
                    break;
                case 8:
                    if (*(int32_t *)((int64_t)&arg_40h + iVar17 + 4) != 0) {
                        iVar23 = 0x1804b69b0;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0e5e;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if ((iVar15 == 0) || (0x1000000000000000 < *(uint64_t *)((int64_t)&var_20h + iVar17))) {
                        iVar23 = 0x1804b69e0;
                        goto code_r0x0001801e17b1;
                    }
                    *(uint64_t *)(in_R8 + 0x508) = *(uint64_t *)((int64_t)&var_20h + iVar17);
                    *(undefined4 *)((int64_t)&arg_40h + iVar17 + 4) = 1;
                    break;
                case 9:
                    if (*(int32_t *)((int64_t)&arg_40h + iVar17) != 0) {
                        iVar23 = 0x1804b6a08;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0ea7;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if ((iVar15 == 0) || (0x1000000000000000 < *(uint64_t *)((int64_t)&var_20h + iVar17))) {
                        iVar23 = 0x1804b6a38;
                        goto code_r0x0001801e17b1;
                    }
                    *(uint64_t *)(in_R8 + 0x510) = *(uint64_t *)((int64_t)&var_20h + iVar17);
                    *(undefined4 *)((int64_t)&arg_40h + iVar17) = 1;
                    break;
                case 10:
                    if (*(int32_t *)((int64_t)&arg_50h + iVar17 + 4) != 0) {
                        iVar23 = 0x1804b6920;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0db8;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if ((iVar15 == 0) || (0x14 < *(uint64_t *)((int64_t)&var_20h + iVar17))) {
                        iVar23 = 0x1804b6948;
                        goto code_r0x0001801e17b1;
                    }
                    *(char *)(in_R8 + 0x4f8) = (char)*(uint64_t *)((int64_t)&var_20h + iVar17);
                    *(undefined4 *)((int64_t)&arg_50h + iVar17 + 4) = 1;
                    break;
                case 0xb:
                    if (bVar8) {
                        iVar23 = 0x1804b6968;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0e00;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if ((iVar15 == 0) || (uVar22 = *(uint64_t *)((int64_t)&var_20h + iVar17), 0x3fff < uVar22)) {
                        iVar23 = 0x1804b6990;
                        goto code_r0x0001801e17b1;
                    }
                    uVar26 = *(undefined8 *)(in_R8 + 0x3c8);
                    *(uint64_t *)(in_R8 + 0x4f0) = uVar22;
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0e33;
                    func_0x000180203890(uVar26, uVar22 * 1000000);
                    bVar8 = true;
                    break;
                case 0xc:
                    if (bVar14) {
                        iVar23 = 0x1804b6cf0;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e10bc;
                    iVar21 = func_0x0001801fdaa0((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, &var_c8h);
                    if ((iVar21 == 0) || (var_c8h != 0)) {
                        iVar23 = 0x1804b6d20;
                        goto code_r0x0001801e17b1;
                    }
                    bVar14 = true;
                    break;
                case 0xd:
                    if (bVar13) {
                        iVar23 = 0x1804b6c20;
                        goto code_r0x0001801e17b1;
                    }
                    if ((*(uint32_t *)(in_R8 + 0x5d0) & 0x2000000) != 0) {
                        iVar23 = 0x1804b6c48;
                        goto code_r0x0001801e17b1;
                    }
                    if (*(char *)(in_R8 + 0x491) == '\0') {
                        iVar23 = 0x1804b6c78;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1084;
                    iVar15 = func_0x0001801fdda0((int64_t)&arg_30h + iVar17, &var_70h);
                    if (iVar15 == 0) {
                        iVar23 = 0x1804b6ca8;
                        goto code_r0x0001801e17b1;
                    }
                    if ((char)var_48h == '\0') {
                        iVar23 = 0x1804b6cc8;
                        goto code_r0x0001801e17b1;
                    }
                    bVar13 = true;
                    break;
                case 0xe:
                    if (bVar11) {
                        iVar23 = 0x1804b6b00;
                        goto code_r0x0001801e17b1;
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0fb6;
                    iVar15 = func_0x0001801fdc80((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, 
                                                 (int64_t)&var_20h + iVar17);
                    if ((iVar15 == 0) || (*(uint64_t *)((int64_t)&var_20h + iVar17) < 2)) {
                        iVar23 = 0x1804b6b30;
                        goto code_r0x0001801e17b1;
                    }
                    *(uint64_t *)(in_R8 + 0x538) = *(uint64_t *)((int64_t)&var_20h + iVar17);
                    bVar11 = true;
                    break;
                case 0xf:
                    if (bVar6) {
                        iVar23 = 0x1804b6710;
                    } else {
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0c14;
                        iVar15 = func_0x0001801fdb80((int64_t)&arg_30h + iVar17, 0, &var_88h);
                        if (iVar15 == 0) {
                            iVar23 = 0x1804b6738;
                        } else {
                            uVar1 = *(uint8_t *)(in_R8 + 0x452);
                            if ((uVar1 == (uint8_t)var_88h) && (uVar1 < 0x15)) {
                                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0c47;
                                iVar15 = func_0x000180497f30(in_R8 + 0x453, (int64_t)&var_88h + 1, uVar1);
                                if (iVar15 == 0) {
                                    bVar6 = true;
                                    break;
                                }
                            }
                            iVar23 = 0x1804b6758;
                        }
                    }
                    goto code_r0x0001801e17b1;
                case 0x10:
                    if ((*(uint32_t *)(in_R8 + 0x5d0) >> 0x19 & 1) == 0) {
                        if (bVar7) {
                            iVar23 = 0x1804b6670;
                        } else if ((*(uint32_t *)(in_R8 + 0x5d0) >> 0xb & 1) == 0) {
                            iVar23 = 0x1804b6698;
                        } else {
                            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0bae;
                            iVar15 = func_0x0001801fdb80((int64_t)&arg_30h + iVar17, 0, &var_88h);
                            if (iVar15 == 0) {
                                iVar23 = 0x1804b66c8;
                            } else {
                                uVar1 = *(uint8_t *)(in_R8 + 0x467);
                                if ((uVar1 == (uint8_t)var_88h) && (uVar1 < 0x15)) {
                                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e0be1;
                                    iVar15 = func_0x000180497f30(in_R8 + 0x468, (int64_t)&var_88h + 1, uVar1);
                                    if (iVar15 == 0) {
                                        bVar7 = true;
                                        break;
                                    }
                                }
                                iVar23 = 0x1804b66e0;
                            }
                        }
                    } else {
                        iVar23 = 0x1804b6648;
                    }
                    goto code_r0x0001801e17b1;
                default:
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e10ec;
                    iVar21 = func_0x0001801fdaa0((int64_t)&arg_30h + iVar17, (int64_t)&arg_28h + iVar17, &var_c8h);
                    if (iVar21 == 0) goto code_r0x0001801e17b1;
                }
                iVar15 = *(int32_t *)((int64_t)&var_18h + iVar17);
code_r0x0001801e10fa:
            } while (*(int64_t *)((int64_t)&arg_38h + iVar17) != 0);
            if (!bVar6) goto code_r0x0001801e17aa;
            uVar3 = *(uint32_t *)(in_R8 + 0x5d0);
            if ((uVar3 >> 0x19 & 1) != 0) {
code_r0x0001801e1367:
                *(uint32_t *)(in_R8 + 0x5d0) = uVar3 | 0x80;
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1379;
                uVar26 = func_0x0001801deee0(in_R8);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar17) = 0x1804b6dc8;
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e13a3;
                iVar16 = func_0x0001801fa270(uVar26, 4, 0x1804b6df8, 0x1804b6de8);
                if (iVar16 == 0) {
                    iVar25 = *(int32_t *)((int64_t)&arg_40h + iVar17);
                    iVar16 = *(int32_t *)((int64_t)&arg_40h + iVar17 + 4);
                    iVar15 = *(int32_t *)((int64_t)&arg_48h + iVar17);
                } else {
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e13c1;
                    func_0x0001801fae90(uVar26, 0x1804b6e0c, 0x1804b6e04);
                    if (bVar5) {
                        uVar2 = *(undefined *)(in_R8 + 0x428);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e13e4;
                        func_0x0001801fa0e0(uVar26, 0x1804b6e18, in_R8 + 0x429, uVar2);
                    }
                    uVar2 = *(undefined *)(in_R8 + 0x428);
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1402;
                    func_0x0001801fa0e0(uVar26, 0x1804b6e40, in_R8 + 0x429, uVar2);
                    if (bVar7) {
                        uVar2 = *(undefined *)(in_R8 + 0x467);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1425;
                        func_0x0001801fa0e0(uVar26, 0x1804b6e60, in_R8 + 0x468, uVar2);
                    }
                    if (*(int32_t *)((int64_t)&arg_48h + iVar17 + 4) != 0) {
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1438;
                        uVar19 = func_0x0001801dd6c0(in_R8 + 0xa0);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e144a;
                        func_0x0001801faf20(uVar26, 0x1804b6e80, uVar19);
                    }
                    if (iVar15 != 0) {
                        uVar19 = *(undefined8 *)(in_R8 + 0x4d8);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1465;
                        func_0x0001801faf20(uVar26, 0x1804b6e98, uVar19);
                    }
                    iVar15 = *(int32_t *)((int64_t)&arg_48h + iVar17);
                    if (iVar15 != 0) {
                        uVar19 = *(undefined8 *)(in_R8 + 0x4e0);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1485;
                        func_0x0001801faf20(uVar26, 0x1804b6ec0, uVar19);
                    }
                    if (*(int32_t *)((int64_t)&arg_50h + iVar17) != 0) {
                        uVar19 = *(undefined8 *)(in_R8 + 0x4e8);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e14a2;
                        func_0x0001801faf20(uVar26, 0x1804b6ee8, uVar19);
                    }
                    iVar16 = *(int32_t *)((int64_t)&arg_40h + iVar17 + 4);
                    if (iVar16 != 0) {
                        uVar19 = *(undefined8 *)(in_R8 + 0x508);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e14c0;
                        func_0x0001801faf20(uVar26, 0x1804b6f08, uVar19);
                    }
                    iVar25 = *(int32_t *)((int64_t)&arg_40h + iVar17);
                    if (iVar25 != 0) {
                        uVar19 = *(undefined8 *)(in_R8 + 0x510);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e14e0;
                        func_0x0001801faf20(uVar26, 0x1804b6f28, uVar19);
                    }
                    if (*(int32_t *)((int64_t)&arg_50h + iVar17 + 4) != 0) {
                        uVar2 = *(undefined *)(in_R8 + 0x4f8);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e14fe;
                        func_0x0001801faf20(uVar26, 0x1804b6f40, uVar2);
                    }
                    if (bVar8) {
                        uVar19 = *(undefined8 *)(in_R8 + 0x4f0);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e151a;
                        func_0x0001801faf20(uVar26, 0x1804b6f58, uVar19);
                    }
                    if (bVar10) {
                        uVar19 = *(undefined8 *)(in_R8 + 0x530);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1536;
                        func_0x0001801faf20(uVar26, 0x1804b6f68, uVar19);
                    }
                    if (bVar9) {
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e154f;
                        func_0x0001801faf20(uVar26, 0x1804b6f80, var_98h);
                    }
                    if (bVar11) {
                        uVar19 = *(undefined8 *)(in_R8 + 0x538);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e156b;
                        func_0x0001801faf20(uVar26, 0x1804b6f98, uVar19);
                    }
                    if (bVar12) {
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e158a;
                        func_0x0001801fa0e0(uVar26, 0x1804b6fb8, var_90h, 0x10);
                    }
                    if (bVar13) {
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e15a3;
                        func_0x0001801fa430(uVar26, 0x1804b6fd0);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e15b7;
                        func_0x0001801faf20(uVar26, 0x1804b6fe0, (undefined2)var_70h);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e15cb;
                        func_0x0001801faf20(uVar26, 0x1804b6fe8, var_70h._2_2_);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e15e4;
                        func_0x0001801fa0e0(uVar26, 0x1804b6ff0, (int64_t)&var_70h + 4, 4);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e15fd;
                        func_0x0001801fa0e0(uVar26, 0x1804b6ff8, auStack_68, 0x10);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1616;
                        func_0x0001801fa0e0(uVar26, 0x1804b6fb8, &var_58h, 0x10);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e162e;
                        func_0x0001801fa0e0(uVar26, 0x1804b7000, (int64_t)&var_48h + 1, (char)var_48h);
                        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1636;
                        func_0x0001801fa460(uVar26);
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e164d;
                    func_0x0001801fa130(uVar26, 0x1804b7010, bVar14);
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1655;
                    func_0x0001801fa180(uVar26);
                }
                if ((((*(int32_t *)((int64_t)&arg_48h + iVar17 + 4) != 0) || (iVar15 != 0)) || (iVar16 != 0)) ||
                   (iVar25 != 0)) {
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1690;
                    func_0x0001801e82d0(in_R8 + 0x300, 0x1801e35f0, in_R8);
                }
                if ((*(uint32_t *)(in_R8 + 0x5d0) & 0x2000000) == 0) goto code_r0x0001801e19b6;
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e16a8;
                iVar15 = func_0x0001801de9b0(in_R8);
                if (iVar15 != 0) goto code_r0x0001801e19b6;
                var_a0h = 0;
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e16c1;
                iVar23 = func_0x0001801fca50(1);
                if ((*(uint8_t *)(in_R8 + 0x5d4) & 0x40) != 0) goto code_r0x0001801e19b6;
                uVar26 = 0x1805aadb1;
                iVar21 = 0x1805aadb1;
                if (iVar23 != 0) {
                    iVar21 = iVar23;
                }
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e16e7;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e16ff;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                iVar24 = 0x1804adc38;
                if (iVar23 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&var_10h + iVar17) = 0x1804adc38;
                *(undefined8 *)((int64_t)&var_8h + iVar17) = uVar19;
                if (iVar23 != 0) {
                    uVar26 = 0x1805ab2cc;
                }
                *(int64_t *)(&stack0x00000000 + iVar17) = iVar21;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar17) = uVar26;
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1752;
                func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
                *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e176a;
                func_0x0001802295a0(0x1804b6360, 0x761, 0x1804b6530);
                iVar23 = *(int64_t *)(in_R8 + 0x5d8);
                if (iVar23 == 0) {
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e177b;
                    iVar23 = func_0x0001802542f0();
                    *(int64_t *)(in_R8 + 0x5d8) = iVar23;
                    if (iVar23 != 0) goto code_r0x0001801e1787;
                } else {
code_r0x0001801e1787:
                    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e178f;
                    func_0x000180254600(iVar23);
                }
                var_a8h = 0xe;
                goto code_r0x0001801e1992;
            }
            if (bVar5) {
                if (((uVar3 >> 0xb & 1) == 0) || (bVar7)) goto code_r0x0001801e1367;
                iVar23 = 0x1804b6da0;
            } else {
                iVar23 = 0x1804b6d78;
            }
        }
code_r0x0001801e17b1:
        var_a0h = 0;
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e17c2;
        iVar21 = func_0x0001801fca50(8);
        if ((*(uint8_t *)(in_R8 + 0x5d4) & 0x40) != 0) goto code_r0x0001801e19b6;
        uVar26 = 0x1805aadb1;
        iVar24 = 0x1805aadb1;
        if (iVar21 != 0) {
            iVar24 = iVar21;
        }
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e17e8;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1800;
        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
        *(int64_t *)((int64_t)&var_10h + iVar17) = iVar23;
        uVar19 = 0x1805aadb1;
        if (iVar21 != 0) {
            uVar19 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&var_8h + iVar17) = uVar19;
        if (iVar21 != 0) {
            uVar26 = 0x1805ab2cc;
        }
        *(int64_t *)(&stack0x00000000 + iVar17) = iVar24;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar17) = uVar26;
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e184c;
        func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 8);
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1864;
        func_0x0001802295a0(0x1804b6360, 0x769, 0x1804b6530);
        iVar21 = *(int64_t *)(in_R8 + 0x5d8);
        if (iVar21 == 0) {
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1875;
            iVar21 = func_0x0001802542f0();
            *(int64_t *)(in_R8 + 0x5d8) = iVar21;
            if (iVar21 != 0) goto code_r0x0001801e1881;
        } else {
code_r0x0001801e1881:
            *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e1889;
            func_0x000180254600(iVar21);
        }
        var_c0h = 8;
        var_b8h = 0;
        *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e18a1;
        var_b0h = iVar23;
        var_a8h = func_0x000180498cd0(iVar23);
    }
    *(uint32_t *)(in_R8 + 0x5d4) = *(uint32_t *)(in_R8 + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e19b4;
    func_0x0001801e2d20(in_R8, &var_c0h, 0);
code_r0x0001801e19b6:
    uVar22 = var_30h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar17);
    *(undefined8 *)((int64_t)&var_30h + iVar17) = 0x1801e19c2;
    func_0x000180459870(uVar22);
    return;
}

// ============================================================
// Function: FUN_1801e1a30
// Address: 0x1801e1a30
// Size: 61 bytes
// ============================================================
void fcn.1801e1a30(undefined8 placeholder_0, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_R8;
    undefined8 uStack_10;
    
    if ((int32_t)arg2 == 2) {
        uStack_10 = 0x1801e1a40;
        iVar2 = fcn.18045a350();
        if ((*(uint8_t *)(in_R8 + 0x5d4) & 4) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801e1a5c;
            iVar1 = fcn.1801fcb40();
            if (iVar1 != 0) {
                *(uint32_t *)(in_R8 + 0x5d4) = *(uint32_t *)(in_R8 + 0x5d4) | 8;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e1a70
// Address: 0x1801e1a70
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.1801e1a70(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint32_t in_EDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e1a8a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
    *(uint32_t *)(in_RCX + 0x5d0) = (uVar1 ^ in_EDX) & 7 ^ uVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e1aba;
    fcn.1801deee0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                  *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                  *(int64_t *)(&stack0x00000068 + iVar2));
    *(uint32_t *)((int64_t)&iStackX_20 + iVar2 + -8) = uVar1 >> 10 & 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e1ace;
    fcn.180204d80(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    return;
}

// ============================================================
// Function: FUN_1801e1af0
// Address: 0x1801e1af0
// Size: 199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801e1af0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
                  int64_t arg_78h, int64_t arg_98h)
{
    uint8_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t **in_RCX;
    undefined8 in_RDX;
    int64_t iVar11;
    undefined8 uVar12;
    undefined8 in_R8;
    undefined4 *in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e1b08;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *(uint8_t *)(in_RCX + 0x85);
    if ((uVar1 == *(uint8_t *)in_R9) && (uVar1 < 0x15)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b3c;
        iVar5 = func_0x000180497f30((int64_t)in_RCX + 0x429, (uint8_t *)((int64_t)in_R9 + 1), uVar1);
        if (iVar5 == 0) {
            return true;
        }
    }
    piVar10 = in_RCX[0x11];
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b60;
    iVar5 = func_0x000180207ff0(piVar10, in_R9);
    if (iVar5 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b80;
    iVar7 = func_0x000180223170(in_RDX, in_R8, 0x1804b6360, 0xbdd);
    if (iVar7 == 0) {
        return false;
    }
    piVar10 = in_RCX[0x11];
    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1baa;
    iVar5 = func_0x0001802080d0(piVar10, iVar7, in_R8, 0x1801e3690);
    if (iVar5 != 0) {
        uVar2 = in_R9[1];
        uVar3 = in_R9[2];
        uVar4 = in_R9[3];
        piVar10 = in_RCX[0x79];
        *(undefined4 *)((int64_t)in_RCX + 0x467) = *in_R9;
        *(undefined4 *)((int64_t)in_RCX + 0x46b) = uVar2;
        *(undefined4 *)((int64_t)in_RCX + 0x46f) = uVar3;
        *(undefined4 *)((int64_t)in_RCX + 0x473) = uVar4;
        *(undefined4 *)((int64_t)in_RCX + 0x477) = in_R9[4];
        uVar1 = *(uint8_t *)(in_R9 + 5);
        *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x800;
        iVar5 = *(int32_t *)((int64_t)&arg_98h + iVar6);
        *(uint8_t *)((int64_t)in_RCX + 0x47b) = uVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1d42;
        iVar5 = func_0x0001802029e0(piVar10, 0, iVar5 == 1);
        if (iVar5 == 0) {
            return false;
        }
        piVar10 = *in_RCX;
        *(int64_t **)((int64_t)&var_10h + iVar6) = in_RCX[0x7a];
        *(int64_t **)((int64_t)&var_8h + iVar6) = in_RCX[0x7b];
        uVar12 = ((undefined8 *)*piVar10)[1];
        uVar9 = *(undefined8 *)*piVar10;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1d7a;
        iVar5 = func_0x0001801f9c30(uVar9, uVar12, (int64_t)in_RCX + 0x467, 0);
        return iVar5 != 0;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1bc9;
    iVar8 = func_0x0001801fca50(0xb);
    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) goto code_r0x0001801e1cca;
    uVar12 = 0x1805aadb1;
    iVar11 = 0x1805aadb1;
    if (iVar8 != 0) {
        iVar11 = iVar8;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1bef;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c07;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar9 = 0x1805aadb1;
    if (iVar8 != 0) {
        uVar9 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0x1804b71b8;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = uVar9;
    if (iVar8 != 0) {
        uVar12 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_10h + iVar6) = iVar11;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c5a;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xb);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c72;
    func_0x0001802295a0(0x1804b6360, 0xbe8, 0x1804b71a8);
    piVar10 = in_RCX[0xbb];
    if (piVar10 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c83;
        piVar10 = (int64_t *)func_0x0001802542f0();
        in_RCX[0xbb] = piVar10;
        if (piVar10 != (int64_t *)0x0) goto code_r0x0001801e1c8f;
    } else {
code_r0x0001801e1c8f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c97;
        func_0x000180254600(piVar10);
    }
    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0xb;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0x1804b71b8;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0x17;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1cca;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar6, 0);
code_r0x0001801e1cca:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1cdf;
    func_0x000180224990(iVar7, 0x1804b6360, 0xbe9);
    return false;
}

// ============================================================
// Function: FUN_1801e1bb7
// Address: 0x1801e1bb7
// Size: 304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801e1af0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
                  int64_t arg_78h, int64_t arg_98h)
{
    uint8_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t **in_RCX;
    undefined8 in_RDX;
    int64_t iVar11;
    undefined8 uVar12;
    undefined8 in_R8;
    undefined4 *in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e1b08;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *(uint8_t *)(in_RCX + 0x85);
    if ((uVar1 == *(uint8_t *)in_R9) && (uVar1 < 0x15)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b3c;
        iVar5 = func_0x000180497f30((int64_t)in_RCX + 0x429, (uint8_t *)((int64_t)in_R9 + 1), uVar1);
        if (iVar5 == 0) {
            return true;
        }
    }
    piVar10 = in_RCX[0x11];
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b60;
    iVar5 = func_0x000180207ff0(piVar10, in_R9);
    if (iVar5 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b80;
    iVar7 = func_0x000180223170(in_RDX, in_R8, 0x1804b6360, 0xbdd);
    if (iVar7 == 0) {
        return false;
    }
    piVar10 = in_RCX[0x11];
    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1baa;
    iVar5 = func_0x0001802080d0(piVar10, iVar7, in_R8, 0x1801e3690);
    if (iVar5 != 0) {
        uVar2 = in_R9[1];
        uVar3 = in_R9[2];
        uVar4 = in_R9[3];
        piVar10 = in_RCX[0x79];
        *(undefined4 *)((int64_t)in_RCX + 0x467) = *in_R9;
        *(undefined4 *)((int64_t)in_RCX + 0x46b) = uVar2;
        *(undefined4 *)((int64_t)in_RCX + 0x46f) = uVar3;
        *(undefined4 *)((int64_t)in_RCX + 0x473) = uVar4;
        *(undefined4 *)((int64_t)in_RCX + 0x477) = in_R9[4];
        uVar1 = *(uint8_t *)(in_R9 + 5);
        *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x800;
        iVar5 = *(int32_t *)((int64_t)&arg_98h + iVar6);
        *(uint8_t *)((int64_t)in_RCX + 0x47b) = uVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1d42;
        iVar5 = func_0x0001802029e0(piVar10, 0, iVar5 == 1);
        if (iVar5 == 0) {
            return false;
        }
        piVar10 = *in_RCX;
        *(int64_t **)((int64_t)&var_10h + iVar6) = in_RCX[0x7a];
        *(int64_t **)((int64_t)&var_8h + iVar6) = in_RCX[0x7b];
        uVar12 = ((undefined8 *)*piVar10)[1];
        uVar9 = *(undefined8 *)*piVar10;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1d7a;
        iVar5 = func_0x0001801f9c30(uVar9, uVar12, (int64_t)in_RCX + 0x467, 0);
        return iVar5 != 0;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1bc9;
    iVar8 = func_0x0001801fca50(0xb);
    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) goto code_r0x0001801e1cca;
    uVar12 = 0x1805aadb1;
    iVar11 = 0x1805aadb1;
    if (iVar8 != 0) {
        iVar11 = iVar8;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1bef;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c07;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar9 = 0x1805aadb1;
    if (iVar8 != 0) {
        uVar9 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0x1804b71b8;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = uVar9;
    if (iVar8 != 0) {
        uVar12 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_10h + iVar6) = iVar11;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c5a;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xb);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c72;
    func_0x0001802295a0(0x1804b6360, 0xbe8, 0x1804b71a8);
    piVar10 = in_RCX[0xbb];
    if (piVar10 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c83;
        piVar10 = (int64_t *)func_0x0001802542f0();
        in_RCX[0xbb] = piVar10;
        if (piVar10 != (int64_t *)0x0) goto code_r0x0001801e1c8f;
    } else {
code_r0x0001801e1c8f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c97;
        func_0x000180254600(piVar10);
    }
    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0xb;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0x1804b71b8;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0x17;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1cca;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar6, 0);
code_r0x0001801e1cca:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1cdf;
    func_0x000180224990(iVar7, 0x1804b6360, 0xbe9);
    return false;
}

// ============================================================
// Function: FUN_1801e1ce7
// Address: 0x1801e1ce7
// Size: 160 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801e1af0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
                  int64_t arg_78h, int64_t arg_98h)
{
    uint8_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t **in_RCX;
    undefined8 in_RDX;
    int64_t iVar11;
    undefined8 uVar12;
    undefined8 in_R8;
    undefined4 *in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e1b08;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *(uint8_t *)(in_RCX + 0x85);
    if ((uVar1 == *(uint8_t *)in_R9) && (uVar1 < 0x15)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b3c;
        iVar5 = func_0x000180497f30((int64_t)in_RCX + 0x429, (uint8_t *)((int64_t)in_R9 + 1), uVar1);
        if (iVar5 == 0) {
            return true;
        }
    }
    piVar10 = in_RCX[0x11];
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b60;
    iVar5 = func_0x000180207ff0(piVar10, in_R9);
    if (iVar5 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1b80;
    iVar7 = func_0x000180223170(in_RDX, in_R8, 0x1804b6360, 0xbdd);
    if (iVar7 == 0) {
        return false;
    }
    piVar10 = in_RCX[0x11];
    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1baa;
    iVar5 = func_0x0001802080d0(piVar10, iVar7, in_R8, 0x1801e3690);
    if (iVar5 != 0) {
        uVar2 = in_R9[1];
        uVar3 = in_R9[2];
        uVar4 = in_R9[3];
        piVar10 = in_RCX[0x79];
        *(undefined4 *)((int64_t)in_RCX + 0x467) = *in_R9;
        *(undefined4 *)((int64_t)in_RCX + 0x46b) = uVar2;
        *(undefined4 *)((int64_t)in_RCX + 0x46f) = uVar3;
        *(undefined4 *)((int64_t)in_RCX + 0x473) = uVar4;
        *(undefined4 *)((int64_t)in_RCX + 0x477) = in_R9[4];
        uVar1 = *(uint8_t *)(in_R9 + 5);
        *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x800;
        iVar5 = *(int32_t *)((int64_t)&arg_98h + iVar6);
        *(uint8_t *)((int64_t)in_RCX + 0x47b) = uVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1d42;
        iVar5 = func_0x0001802029e0(piVar10, 0, iVar5 == 1);
        if (iVar5 == 0) {
            return false;
        }
        piVar10 = *in_RCX;
        *(int64_t **)((int64_t)&var_10h + iVar6) = in_RCX[0x7a];
        *(int64_t **)((int64_t)&var_8h + iVar6) = in_RCX[0x7b];
        uVar12 = ((undefined8 *)*piVar10)[1];
        uVar9 = *(undefined8 *)*piVar10;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1d7a;
        iVar5 = func_0x0001801f9c30(uVar9, uVar12, (int64_t)in_RCX + 0x467, 0);
        return iVar5 != 0;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1bc9;
    iVar8 = func_0x0001801fca50(0xb);
    if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) goto code_r0x0001801e1cca;
    uVar12 = 0x1805aadb1;
    iVar11 = 0x1805aadb1;
    if (iVar8 != 0) {
        iVar11 = iVar8;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1bef;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c07;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar9 = 0x1805aadb1;
    if (iVar8 != 0) {
        uVar9 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar6) = 0x1804b71b8;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = uVar9;
    if (iVar8 != 0) {
        uVar12 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_10h + iVar6) = iVar11;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = uVar12;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c5a;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xb);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c72;
    func_0x0001802295a0(0x1804b6360, 0xbe8, 0x1804b71a8);
    piVar10 = in_RCX[0xbb];
    if (piVar10 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c83;
        piVar10 = (int64_t *)func_0x0001802542f0();
        in_RCX[0xbb] = piVar10;
        if (piVar10 != (int64_t *)0x0) goto code_r0x0001801e1c8f;
    } else {
code_r0x0001801e1c8f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1c97;
        func_0x000180254600(piVar10);
    }
    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0xb;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0x1804b71b8;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0x17;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1cca;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_28h + iVar6, 0);
code_r0x0001801e1cca:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801e1cdf;
    func_0x000180224990(iVar7, 0x1804b6360, 0xbe9);
    return false;
}

// ============================================================
// Function: FUN_1801e1d90
// Address: 0x1801e1d90
// Size: 61 bytes
// ============================================================
undefined8
fcn.1801e1d90(undefined8 *placeholder_0, uint64_t placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h
             , int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
             int64_t arg_118h)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t iVar9;
    uint32_t uVar10;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e1da7;
    var_18h = arg3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    bVar1 = false;
    uVar13 = *(uint32_t *)(placeholder_0 + 0xba) & 7;
    if ((*(uint32_t *)(placeholder_0 + 0xba) & 0x2000020) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_RBX;
    uVar12 = placeholder_0[0x7b];
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1df8;
    iVar2 = func_0x0001802055c0(uVar12, placeholder_0 + 0xa0);
    uVar11 = 0xffffffffffffffff;
    if (iVar2 != 0) {
        do {
            if (uVar13 == 2) {
                uVar12 = placeholder_0[0x11];
                uVar6 = *(undefined8 *)(*(int64_t *)placeholder_0[0xa0] + 0x48);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e31;
                func_0x000180207e90(uVar12, uVar6);
            }
            if (!bVar1) {
                uVar12 = *placeholder_0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e42;
                iVar4 = func_0x0001801e8e50(uVar12);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e4d;
                uVar5 = func_0x0001801dee70(placeholder_0);
                if (-iVar4 - 1U < uVar5) {
                    iVar4 = -1;
                } else {
                    iVar4 = uVar5 + iVar4;
                }
                placeholder_0[0xb4] = iVar4;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e6f;
                uVar5 = func_0x0001801dee70(placeholder_0);
                if (uVar5 == 0xffffffffffffffff) {
                    placeholder_0[0xb5] = 0xffffffffffffffff;
                } else {
                    uVar12 = *placeholder_0;
                    uVar8 = 25000000000;
                    if (uVar5 >> 1 < 25000000000) {
                        uVar8 = uVar5 >> 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e8a;
                    iVar4 = func_0x0001801e8e50(uVar12);
                    if (-iVar4 - 1U < uVar8) {
                        placeholder_0[0xb5] = 0xffffffffffffffff;
                    } else {
                        placeholder_0[0xb5] = iVar4 + uVar8;
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1ebe;
            func_0x0001801e20e0(placeholder_0, placeholder_1 & 0xffffffff);
            uVar12 = placeholder_0[0xa0];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1eca;
            func_0x0001802054c0(uVar12);
            *(uint32_t *)(placeholder_0 + 0xba) = *(uint32_t *)(placeholder_0 + 0xba) & 0xdfffffff;
            placeholder_0[0xa0] = 0;
            bVar1 = true;
            uVar12 = placeholder_0[0x7b];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1ef8;
            iVar2 = func_0x0001802055c0(uVar12, placeholder_0 + 0xa0);
        } while (iVar2 != 0);
        arg3 = *(undefined8 *)((int64_t)&arg_88h + iVar3);
    }
    uVar10 = 0;
    uVar7 = 1;
    do {
        if ((*(uint32_t *)(placeholder_0 + 0xba) >> 0x14 & uVar7 & 0xf) == 0) {
            if ((*(uint32_t *)(placeholder_0 + 0xba) >> 0x11 & 7) < uVar10) break;
            uVar12 = placeholder_0[0x7b];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f49;
            uVar5 = func_0x000180205240(uVar12, uVar10);
            if (uVar5 < uVar11) {
                uVar11 = uVar5;
            }
        }
        uVar10 = uVar10 + 1;
        uVar7 = uVar7 << 1 | (uint32_t)((int32_t)uVar7 < 0);
    } while (uVar10 < 4);
    uVar12 = placeholder_0[0x7b];
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f65;
    uVar5 = func_0x0001802051f0(uVar12);
    if (uVar5 < uVar11) goto code_r0x0001801e207e;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f7d;
    iVar4 = func_0x0001801fca50(0xf);
    if ((*(uint8_t *)((int64_t)placeholder_0 + 0x5d4) & 0x40) != 0) goto code_r0x0001801e207e;
    uVar12 = 0x1805aadb1;
    iVar9 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar9 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1fa3;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1fbb;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar6 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x1804b7080;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar6;
    if (iVar4 != 0) {
        uVar12 = 0x1805ab2cc;
    }
    *(int64_t *)(&stack0x00000000 + iVar3) = iVar9;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = uVar12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e200e;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xf);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e2026;
    func_0x0001802295a0(0x1804b6360, 0x8db, 0x1804b7060);
    iVar4 = placeholder_0[0xbb];
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e2037;
        iVar4 = func_0x0001802542f0();
        placeholder_0[0xbb] = iVar4;
        if (iVar4 != 0) goto code_r0x0001801e2043;
    } else {
code_r0x0001801e2043:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e204b;
        func_0x000180254600(iVar4);
    }
    *(uint32_t *)((int64_t)placeholder_0 + 0x5d4) = *(uint32_t *)((int64_t)placeholder_0 + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0xf;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7080;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0xd;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e207e;
    func_0x0001801e2d20(placeholder_0, (int64_t)&var_18h + iVar3, 0);
code_r0x0001801e207e:
    if (bVar1) {
        if ((undefined4 *)arg3 != (undefined4 *)0x0) {
            *(undefined4 *)arg3 = 1;
        }
        if (uVar13 == 2) {
            *(uint32_t *)(placeholder_0 + 0xba) = *(uint32_t *)(placeholder_0 + 0xba) | 0x1000000;
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801e1dcd
// Address: 0x1801e1dcd
// Size: 718 bytes
// ============================================================
undefined8
fcn.1801e1d90(undefined8 *placeholder_0, uint64_t placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h
             , int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
             int64_t arg_118h)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t iVar9;
    uint32_t uVar10;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e1da7;
    var_18h = arg3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    bVar1 = false;
    uVar13 = *(uint32_t *)(placeholder_0 + 0xba) & 7;
    if ((*(uint32_t *)(placeholder_0 + 0xba) & 0x2000020) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_RBX;
    uVar12 = placeholder_0[0x7b];
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1df8;
    iVar2 = func_0x0001802055c0(uVar12, placeholder_0 + 0xa0);
    uVar11 = 0xffffffffffffffff;
    if (iVar2 != 0) {
        do {
            if (uVar13 == 2) {
                uVar12 = placeholder_0[0x11];
                uVar6 = *(undefined8 *)(*(int64_t *)placeholder_0[0xa0] + 0x48);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e31;
                func_0x000180207e90(uVar12, uVar6);
            }
            if (!bVar1) {
                uVar12 = *placeholder_0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e42;
                iVar4 = func_0x0001801e8e50(uVar12);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e4d;
                uVar5 = func_0x0001801dee70(placeholder_0);
                if (-iVar4 - 1U < uVar5) {
                    iVar4 = -1;
                } else {
                    iVar4 = uVar5 + iVar4;
                }
                placeholder_0[0xb4] = iVar4;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e6f;
                uVar5 = func_0x0001801dee70(placeholder_0);
                if (uVar5 == 0xffffffffffffffff) {
                    placeholder_0[0xb5] = 0xffffffffffffffff;
                } else {
                    uVar12 = *placeholder_0;
                    uVar8 = 25000000000;
                    if (uVar5 >> 1 < 25000000000) {
                        uVar8 = uVar5 >> 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e8a;
                    iVar4 = func_0x0001801e8e50(uVar12);
                    if (-iVar4 - 1U < uVar8) {
                        placeholder_0[0xb5] = 0xffffffffffffffff;
                    } else {
                        placeholder_0[0xb5] = iVar4 + uVar8;
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1ebe;
            func_0x0001801e20e0(placeholder_0, placeholder_1 & 0xffffffff);
            uVar12 = placeholder_0[0xa0];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1eca;
            func_0x0001802054c0(uVar12);
            *(uint32_t *)(placeholder_0 + 0xba) = *(uint32_t *)(placeholder_0 + 0xba) & 0xdfffffff;
            placeholder_0[0xa0] = 0;
            bVar1 = true;
            uVar12 = placeholder_0[0x7b];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1ef8;
            iVar2 = func_0x0001802055c0(uVar12, placeholder_0 + 0xa0);
        } while (iVar2 != 0);
        arg3 = *(undefined8 *)((int64_t)&arg_88h + iVar3);
    }
    uVar10 = 0;
    uVar7 = 1;
    do {
        if ((*(uint32_t *)(placeholder_0 + 0xba) >> 0x14 & uVar7 & 0xf) == 0) {
            if ((*(uint32_t *)(placeholder_0 + 0xba) >> 0x11 & 7) < uVar10) break;
            uVar12 = placeholder_0[0x7b];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f49;
            uVar5 = func_0x000180205240(uVar12, uVar10);
            if (uVar5 < uVar11) {
                uVar11 = uVar5;
            }
        }
        uVar10 = uVar10 + 1;
        uVar7 = uVar7 << 1 | (uint32_t)((int32_t)uVar7 < 0);
    } while (uVar10 < 4);
    uVar12 = placeholder_0[0x7b];
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f65;
    uVar5 = func_0x0001802051f0(uVar12);
    if (uVar5 < uVar11) goto code_r0x0001801e207e;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f7d;
    iVar4 = func_0x0001801fca50(0xf);
    if ((*(uint8_t *)((int64_t)placeholder_0 + 0x5d4) & 0x40) != 0) goto code_r0x0001801e207e;
    uVar12 = 0x1805aadb1;
    iVar9 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar9 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1fa3;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1fbb;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar6 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x1804b7080;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar6;
    if (iVar4 != 0) {
        uVar12 = 0x1805ab2cc;
    }
    *(int64_t *)(&stack0x00000000 + iVar3) = iVar9;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = uVar12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e200e;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xf);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e2026;
    func_0x0001802295a0(0x1804b6360, 0x8db, 0x1804b7060);
    iVar4 = placeholder_0[0xbb];
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e2037;
        iVar4 = func_0x0001802542f0();
        placeholder_0[0xbb] = iVar4;
        if (iVar4 != 0) goto code_r0x0001801e2043;
    } else {
code_r0x0001801e2043:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e204b;
        func_0x000180254600(iVar4);
    }
    *(uint32_t *)((int64_t)placeholder_0 + 0x5d4) = *(uint32_t *)((int64_t)placeholder_0 + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0xf;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7080;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0xd;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e207e;
    func_0x0001801e2d20(placeholder_0, (int64_t)&var_18h + iVar3, 0);
code_r0x0001801e207e:
    if (bVar1) {
        if ((undefined4 *)arg3 != (undefined4 *)0x0) {
            *(undefined4 *)arg3 = 1;
        }
        if (uVar13 == 2) {
            *(uint32_t *)(placeholder_0 + 0xba) = *(uint32_t *)(placeholder_0 + 0xba) | 0x1000000;
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801e209b
// Address: 0x1801e209b
// Size: 65 bytes
// ============================================================
undefined8
fcn.1801e1d90(undefined8 *placeholder_0, uint64_t placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h
             , int64_t arg_30h, int64_t arg_38h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
             int64_t arg_118h)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t iVar9;
    uint32_t uVar10;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e1da7;
    var_18h = arg3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    bVar1 = false;
    uVar13 = *(uint32_t *)(placeholder_0 + 0xba) & 7;
    if ((*(uint32_t *)(placeholder_0 + 0xba) & 0x2000020) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_RBX;
    uVar12 = placeholder_0[0x7b];
    *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_90h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1df8;
    iVar2 = func_0x0001802055c0(uVar12, placeholder_0 + 0xa0);
    uVar11 = 0xffffffffffffffff;
    if (iVar2 != 0) {
        do {
            if (uVar13 == 2) {
                uVar12 = placeholder_0[0x11];
                uVar6 = *(undefined8 *)(*(int64_t *)placeholder_0[0xa0] + 0x48);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e31;
                func_0x000180207e90(uVar12, uVar6);
            }
            if (!bVar1) {
                uVar12 = *placeholder_0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e42;
                iVar4 = func_0x0001801e8e50(uVar12);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e4d;
                uVar5 = func_0x0001801dee70(placeholder_0);
                if (-iVar4 - 1U < uVar5) {
                    iVar4 = -1;
                } else {
                    iVar4 = uVar5 + iVar4;
                }
                placeholder_0[0xb4] = iVar4;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e6f;
                uVar5 = func_0x0001801dee70(placeholder_0);
                if (uVar5 == 0xffffffffffffffff) {
                    placeholder_0[0xb5] = 0xffffffffffffffff;
                } else {
                    uVar12 = *placeholder_0;
                    uVar8 = 25000000000;
                    if (uVar5 >> 1 < 25000000000) {
                        uVar8 = uVar5 >> 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1e8a;
                    iVar4 = func_0x0001801e8e50(uVar12);
                    if (-iVar4 - 1U < uVar8) {
                        placeholder_0[0xb5] = 0xffffffffffffffff;
                    } else {
                        placeholder_0[0xb5] = iVar4 + uVar8;
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1ebe;
            func_0x0001801e20e0(placeholder_0, placeholder_1 & 0xffffffff);
            uVar12 = placeholder_0[0xa0];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1eca;
            func_0x0001802054c0(uVar12);
            *(uint32_t *)(placeholder_0 + 0xba) = *(uint32_t *)(placeholder_0 + 0xba) & 0xdfffffff;
            placeholder_0[0xa0] = 0;
            bVar1 = true;
            uVar12 = placeholder_0[0x7b];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1ef8;
            iVar2 = func_0x0001802055c0(uVar12, placeholder_0 + 0xa0);
        } while (iVar2 != 0);
        arg3 = *(undefined8 *)((int64_t)&arg_88h + iVar3);
    }
    uVar10 = 0;
    uVar7 = 1;
    do {
        if ((*(uint32_t *)(placeholder_0 + 0xba) >> 0x14 & uVar7 & 0xf) == 0) {
            if ((*(uint32_t *)(placeholder_0 + 0xba) >> 0x11 & 7) < uVar10) break;
            uVar12 = placeholder_0[0x7b];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f49;
            uVar5 = func_0x000180205240(uVar12, uVar10);
            if (uVar5 < uVar11) {
                uVar11 = uVar5;
            }
        }
        uVar10 = uVar10 + 1;
        uVar7 = uVar7 << 1 | (uint32_t)((int32_t)uVar7 < 0);
    } while (uVar10 < 4);
    uVar12 = placeholder_0[0x7b];
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f65;
    uVar5 = func_0x0001802051f0(uVar12);
    if (uVar5 < uVar11) goto code_r0x0001801e207e;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1f7d;
    iVar4 = func_0x0001801fca50(0xf);
    if ((*(uint8_t *)((int64_t)placeholder_0 + 0x5d4) & 0x40) != 0) goto code_r0x0001801e207e;
    uVar12 = 0x1805aadb1;
    iVar9 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar9 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1fa3;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e1fbb;
    func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
    uVar6 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x1804b7080;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = uVar6;
    if (iVar4 != 0) {
        uVar12 = 0x1805ab2cc;
    }
    *(int64_t *)(&stack0x00000000 + iVar3) = iVar9;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = uVar12;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e200e;
    func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xf);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e2026;
    func_0x0001802295a0(0x1804b6360, 0x8db, 0x1804b7060);
    iVar4 = placeholder_0[0xbb];
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e2037;
        iVar4 = func_0x0001802542f0();
        placeholder_0[0xbb] = iVar4;
        if (iVar4 != 0) goto code_r0x0001801e2043;
    } else {
code_r0x0001801e2043:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e204b;
        func_0x000180254600(iVar4);
    }
    *(uint32_t *)((int64_t)placeholder_0 + 0x5d4) = *(uint32_t *)((int64_t)placeholder_0 + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0xf;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7080;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0xd;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e207e;
    func_0x0001801e2d20(placeholder_0, (int64_t)&var_18h + iVar3, 0);
code_r0x0001801e207e:
    if (bVar1) {
        if ((undefined4 *)arg3 != (undefined4 *)0x0) {
            *(undefined4 *)arg3 = 1;
        }
        if (uVar13 == 2) {
            *(uint32_t *)(placeholder_0 + 0xba) = *(uint32_t *)(placeholder_0 + 0xba) | 0x1000000;
            return 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801e20e0
// Address: 0x1801e20e0
// Size: 70 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.1801e20e0(int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined *puVar3;
    char cVar4;
    undefined uVar5;
    uint32_t *puVar6;
    char *pcVar7;
    uint32_t *puVar8;
    uint32_t *puVar9;
    char **ppcVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t iVar18;
    undefined8 uVar19;
    int64_t *piVar20;
    char *pcVar21;
    int64_t **in_RCX;
    uint64_t in_RDX;
    uint32_t **ppuVar22;
    undefined *puVar23;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t iVar24;
    undefined8 unaff_RDI;
    undefined8 uVar25;
    uint32_t uVar26;
    uint64_t uVar27;
    undefined8 unaff_R13;
    uint32_t uVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1801e20f7;
    iVar17 = fcn.18045a350();
    iVar17 = -iVar17;
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    uVar28 = uVar26 >> 4 & 1;
    if (((uint8_t)uVar26 & 7) != 1) {
        return;
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    *(undefined8 *)((int64_t)&arg_60h + iVar17) = unaff_R13;
    puVar6 = *ppuVar22;
    uVar16 = 0;
    if (((*puVar6 & 0xff) != 4) && ((*puVar6 & 0xff) != 6)) {
        if ((uVar26 & 8) == 0) {
            uVar11 = *(undefined4 *)((int64_t)puVar6 + 0x21);
            uVar12 = *(undefined4 *)((int64_t)puVar6 + 0x25);
            uVar13 = *(undefined4 *)((int64_t)puVar6 + 0x29);
            *(undefined4 *)((int64_t)in_RCX + 0x452) = *(undefined4 *)((int64_t)puVar6 + 0x1d);
            *(undefined4 *)((int64_t)in_RCX + 0x456) = uVar11;
            *(undefined4 *)((int64_t)in_RCX + 0x45a) = uVar12;
            *(undefined4 *)((int64_t)in_RCX + 0x45e) = uVar13;
            *(undefined4 *)((int64_t)in_RCX + 0x462) = *(undefined4 *)((int64_t)puVar6 + 0x2d);
            piVar20 = in_RCX[0x11];
            *(char *)((int64_t)in_RCX + 0x466) = *(char *)((int64_t)puVar6 + 0x31);
            *(uint32_t *)(in_RCX + 0xba) = uVar26 | 8;
            *(undefined4 *)((int64_t)in_RCX + 0x491) = *(undefined4 *)((int64_t)in_RCX + 0x452);
            *(undefined4 *)((int64_t)in_RCX + 0x495) = *(undefined4 *)((int64_t)in_RCX + 0x456);
            *(undefined4 *)((int64_t)in_RCX + 0x499) = *(undefined4 *)((int64_t)in_RCX + 0x45a);
            *(undefined4 *)((int64_t)in_RCX + 0x49d) = *(undefined4 *)((int64_t)in_RCX + 0x45e);
            *(undefined4 *)((int64_t)in_RCX + 0x4a1) = *(undefined4 *)((int64_t)in_RCX + 0x462);
            *(undefined *)((int64_t)in_RCX + 0x4a5) = *(undefined *)((int64_t)in_RCX + 0x466);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e21a3;
            func_0x000180207ff0(piVar20);
            uVar26 = *(uint32_t *)(in_RCX + 0xba);
        }
        ppuVar22 = (uint32_t **)in_RCX[0xa0];
        cVar4 = *(char *)*ppuVar22;
        if (cVar4 == '\x01') {
            uVar16 = 1;
        } else if (cVar4 == '\x02') {
            uVar16 = 2;
        } else if (cVar4 == '\x03') {
            uVar16 = 4;
        } else if (cVar4 == '\x05') {
            uVar16 = 8;
        }
        if ((uVar16 & uVar26 >> 0x14) != 0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_98h + iVar17) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar17) = unaff_RDI;
    if (((uVar26 >> 0x19 & 1) == 0) && (ppuVar22[1] != (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e222e;
        iVar14 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != 2) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e223c;
            iVar14 = func_0x00018026bea0(in_RCX + 0xd);
            if (iVar14 != 0x17) goto code_r0x0001801e22b1;
        }
        iVar18 = in_RCX[0xa0][1];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2254;
        iVar14 = func_0x00018026bea0(iVar18);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e225f;
        iVar15 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != iVar15) {
            return;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e226f;
        iVar14 = func_0x00018026bea0(iVar18);
        if (iVar14 == 2) {
            bVar29 = *(int32_t *)(iVar18 + 4) == *(int32_t *)((int64_t)in_RCX + 0x6c);
        } else {
            if (iVar14 != 0x17) {
                return;
            }
            if (*(int64_t **)(iVar18 + 8) != in_RCX[0xe]) {
                return;
            }
            bVar29 = *(int64_t **)(iVar18 + 0x10) == in_RCX[0xf];
        }
        if (!bVar29) {
            return;
        }
        if (*(int16_t *)(iVar18 + 2) != *(int16_t *)((int64_t)in_RCX + 0x6a)) {
            return;
        }
    }
code_r0x0001801e22b1:
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    if (((uVar26 & 0x2000008) == 8) && (pcVar7 = (char *)*in_RCX[0xa0], *pcVar7 != '\x05')) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e22e3;
        iVar14 = func_0x0001801e55b0(pcVar7 + 0x1d, (int64_t)in_RCX + 0x452);
        if (iVar14 == 0) {
            return;
        }
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    puVar6 = *ppuVar22;
    uVar16 = *puVar6 & 0xff;
    if (uVar16 == 5) {
code_r0x0001801e2600:
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar26 = **ppuVar22;
        uVar16 = uVar26 & 0xff;
        if (((uVar16 == 4) || (uVar16 == 6)) || ((uVar26 & 0x300000) == 0)) {
            var_68h = *(int64_t *)(*ppuVar22 + 0x14);
            var_60h = *(int64_t *)(*ppuVar22 + 0x12);
            puVar6 = ppuVar22[8];
            puVar8 = ppuVar22[4];
            puVar9 = *ppuVar22;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2776;
            uVar25 = fcn.1801deee0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                   *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&iStackX_20 + iVar17)
                                   , *(int64_t *)(&stack0x00000028 + iVar17), *(int64_t *)(&stack0x00000030 + iVar17), 
                                   *(int64_t *)(&stack0x00000040 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17));
            *(uint32_t **)((int64_t)&var_8h + iVar17) = puVar6;
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = 1;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2796;
            func_0x000180204f00(uVar25, puVar9, puVar8, &var_68h);
            puVar6 = (uint32_t *)*in_RCX[0xa0];
    // switch table (6 cases) at 0x1801e2cfc
            switch(*puVar6 & 0xff) {
            case 1:
            case 3:
            case 5:
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) && ((*puVar6 & 0xff) == 3)) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e297d;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) &&
                    (ppcVar10 = (char **)in_RCX[0xa0], **ppcVar10 == '\x05')) && (in_RCX[0xb9] <= ppcVar10[4])) {
                    pcVar7 = ppcVar10[7];
                    piVar20 = in_RCX[0x7b];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29c2;
                    pcVar21 = (char *)func_0x000180205200(piVar20);
                    if (pcVar7 < pcVar21) {
                        var_38h = 0;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29d9;
                        iVar18 = func_0x0001801fca50(0xe);
                        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                            return;
                        }
                        uVar25 = 0x1805aadb1;
                        iVar24 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            iVar24 = iVar18;
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a00;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a18;
                        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                        uVar19 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            uVar19 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7120;
                        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                        if (iVar18 != 0) {
                            uVar25 = 0x1805ab2cc;
                        }
                        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a6b;
                        func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xe);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a83;
                        func_0x0001802295a0(0x1804b6360, 0xa35, 0x1804b7090);
                        piVar20 = in_RCX[0xbb];
                        if (piVar20 == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a94;
                            piVar20 = (int64_t *)func_0x0001802542f0();
                            in_RCX[0xbb] = piVar20;
                            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2aa0;
                        } else {
code_r0x0001801e2aa0:
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2aa8;
                            func_0x000180254600(piVar20);
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        uVar25 = 0;
                        var_58h = 0xe;
                        var_48h = 0x1804b7120;
                        var_40h = 0x18;
                        break;
                    }
                }
                if ((((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) || (*(char *)*in_RCX[0xa0] != '\x01')) ||
                   (*(int64_t *)((char *)*in_RCX[0xa0] + 0x40) == 0)) {
                    piVar20 = in_RCX[0xa0];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c12;
                    func_0x0001802004d0(in_RCX, piVar20);
                    if ((*(uint32_t *)(in_RCX + 0xba) & 0x10000000) == 0) {
                        return;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c31;
                    func_0x0001801e2eb0(in_RCX, in_RDX & 0xffffffff, 0);
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b0c;
                iVar18 = func_0x0001801fca50(10);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = 0x1805aadb1;
                if (iVar18 != 0) {
                    iVar24 = iVar18;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b33;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b4b;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7140;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b9e;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bb6;
                func_0x0001802295a0(0x1804b6360, 0xa4e, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bc7;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2bd3;
                } else {
code_r0x0001801e2bd3:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bdb;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 10;
                var_48h = 0x1804b7140;
                var_40h = 0x1d;
                break;
            default:
                goto code_r0x0001801e2ceb;
            case 4:
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000800) != 0) {
                    return;
                }
                if ((*(uint32_t *)(in_RCX + 0xba) & 8) != 0) {
                    return;
                }
                if (*(uint64_t *)(puVar6 + 0x12) < 0x11) {
                    return;
                }
                uVar25 = ((undefined8 *)**in_RCX)[1];
                uVar19 = *(undefined8 *)**in_RCX;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2809;
                iVar14 = func_0x0001801f8c80(uVar19, uVar25, puVar6, in_RCX + 0x85);
                if (iVar14 == 0) {
                    return;
                }
                *(uint32_t *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar28;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2838;
                iVar14 = fcn.1801e1af0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                       *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&var_10h + iVar17)
                                       , *(int64_t *)((int64_t)&iStackX_20 + iVar17 + -8), 
                                       *(int64_t *)((int64_t)&iStackX_20 + iVar17), 
                                       *(int64_t *)(&stack0x00000030 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17)
                                       , *(int64_t *)(&stack0x00000070 + iVar17));
                if (iVar14 != 0) {
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e284e;
                iVar18 = func_0x0001801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2885;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e289d;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7108;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e28f3;
                func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e290b;
                func_0x0001802295a0(0x1804b6360, 0xa0f, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e291f;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e292e;
                } else {
code_r0x0001801e292e:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2936;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 1;
                var_48h = 0x1804b7108;
                var_40h = 0x15;
                break;
            case 6:
                if (uVar28 != 0) {
                    return;
                }
                uVar27 = *(uint64_t *)(puVar6 + 0x12);
                if (0x7fffffffffffffff < uVar27) {
                    return;
                }
                puVar23 = *(undefined **)(puVar6 + 0x14);
                while ((uVar27 != 0 && (3 < uVar27))) {
                    uVar5 = *puVar23;
                    uVar27 = uVar27 - 4;
                    puVar1 = puVar23 + 1;
                    puVar2 = puVar23 + 2;
                    puVar3 = puVar23 + 3;
                    puVar23 = puVar23 + 4;
                    if (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) == 1) {
                        return;
                    }
                }
                var_48h = 0x1804b7160;
                uVar25 = 1;
                var_38h = 0;
                var_40h = 0x1b;
code_r0x0001801e2cb7:
                var_58h = 2;
            }
        } else {
            var_38h = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e263e;
            iVar18 = func_0x0001801fca50(10);
            if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                return;
            }
            uVar25 = 0x1805aadb1;
            iVar24 = iVar18;
            if (iVar18 == 0) {
                iVar24 = 0x1805aadb1;
            }
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2675;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e268d;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar19 = 0x1805aadb1;
            if (iVar18 != 0) {
                uVar19 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70e8;
            *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
            *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
            if (iVar18 != 0) {
                uVar25 = 0x1805ab2cc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26e3;
            func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26fb;
            func_0x0001802295a0(0x1804b6360, 0x9db, 0x1804b7090);
            piVar20 = in_RCX[0xbb];
            if (piVar20 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e270f;
                piVar20 = (int64_t *)func_0x0001802542f0();
                in_RCX[0xbb] = piVar20;
                if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e271e;
            } else {
code_r0x0001801e271e:
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2726;
                func_0x000180254600(piVar20);
            }
            *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
            uVar25 = 0;
            var_58h = 10;
            var_48h = 0x1804b70e8;
            var_40h = 0x1b;
        }
    } else {
        if (uVar16 != 6) {
            if (puVar6[1] != 1) {
                return;
            }
            if (uVar16 != 6) goto code_r0x0001801e2600;
        }
        if (puVar6[1] != 0) {
            return;
        }
        if (uVar28 != 0) {
            return;
        }
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar27 = *(uint64_t *)(*ppuVar22 + 0x12);
        if (0x7fffffffffffffff < uVar27) {
            return;
        }
        puVar23 = *(undefined **)(*ppuVar22 + 0x14);
        do {
            if (uVar27 == 0) {
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23ac;
                iVar18 = func_0x0001801fca50(2);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23e3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23fb;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70c8;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2451;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 2);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2469;
                func_0x0001802295a0(0x1804b6360, 0x9cd, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e247d;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e248c;
                } else {
code_r0x0001801e248c:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2494;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_48h = 0x1804b70c8;
                var_40h = 0x1c;
                goto code_r0x0001801e2cb7;
            }
            if (uVar27 < 4) {
                return;
            }
            uVar5 = *puVar23;
            uVar27 = uVar27 - 4;
            puVar1 = puVar23 + 1;
            puVar2 = puVar23 + 2;
            puVar3 = puVar23 + 3;
            puVar23 = puVar23 + 4;
        } while (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) != 1);
        piVar20 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24c7;
        func_0x0001802081e0(piVar20, 1);
        piVar20 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24d8;
        iVar14 = func_0x0001802029e0(piVar20, 0, 0);
        if (iVar14 != 0) {
            return;
        }
        var_38h = 0;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24ee;
        iVar18 = func_0x0001801fca50(1);
        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
            return;
        }
        uVar25 = 0x1805aadb1;
        iVar24 = iVar18;
        if (iVar18 == 0) {
            iVar24 = 0x1805aadb1;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2525;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e253d;
        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
        uVar19 = 0x1805aadb1;
        if (iVar18 != 0) {
            uVar19 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70a8;
        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
        if (iVar18 != 0) {
            uVar25 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2593;
        func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25ab;
        func_0x0001802295a0(0x1804b6360, 0x9c3, 0x1804b7090);
        piVar20 = in_RCX[0xbb];
        if (piVar20 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25bf;
            piVar20 = (int64_t *)func_0x0001802542f0();
            in_RCX[0xbb] = piVar20;
            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e25ce;
        } else {
code_r0x0001801e25ce:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25d6;
            func_0x000180254600(piVar20);
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
        uVar25 = 0;
        var_58h = 1;
        var_48h = 0x1804b70a8;
        var_40h = 0x1f;
    }
    var_50h = 0;
    *(code **)((int64_t)&pcStack_28 + iVar17) = case.0x1801e27c6.2;
    func_0x0001801e2d20(in_RCX, &var_58h, uVar25);
code_r0x0001801e2ceb:
    return;
}

// ============================================================
// Function: FUN_1801e2126
// Address: 0x1801e2126
// Size: 210 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.1801e20e0(int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined *puVar3;
    char cVar4;
    undefined uVar5;
    uint32_t *puVar6;
    char *pcVar7;
    uint32_t *puVar8;
    uint32_t *puVar9;
    char **ppcVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t iVar18;
    undefined8 uVar19;
    int64_t *piVar20;
    char *pcVar21;
    int64_t **in_RCX;
    uint64_t in_RDX;
    uint32_t **ppuVar22;
    undefined *puVar23;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t iVar24;
    undefined8 unaff_RDI;
    undefined8 uVar25;
    uint32_t uVar26;
    uint64_t uVar27;
    undefined8 unaff_R13;
    uint32_t uVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1801e20f7;
    iVar17 = fcn.18045a350();
    iVar17 = -iVar17;
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    uVar28 = uVar26 >> 4 & 1;
    if (((uint8_t)uVar26 & 7) != 1) {
        return;
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    *(undefined8 *)((int64_t)&arg_60h + iVar17) = unaff_R13;
    puVar6 = *ppuVar22;
    uVar16 = 0;
    if (((*puVar6 & 0xff) != 4) && ((*puVar6 & 0xff) != 6)) {
        if ((uVar26 & 8) == 0) {
            uVar11 = *(undefined4 *)((int64_t)puVar6 + 0x21);
            uVar12 = *(undefined4 *)((int64_t)puVar6 + 0x25);
            uVar13 = *(undefined4 *)((int64_t)puVar6 + 0x29);
            *(undefined4 *)((int64_t)in_RCX + 0x452) = *(undefined4 *)((int64_t)puVar6 + 0x1d);
            *(undefined4 *)((int64_t)in_RCX + 0x456) = uVar11;
            *(undefined4 *)((int64_t)in_RCX + 0x45a) = uVar12;
            *(undefined4 *)((int64_t)in_RCX + 0x45e) = uVar13;
            *(undefined4 *)((int64_t)in_RCX + 0x462) = *(undefined4 *)((int64_t)puVar6 + 0x2d);
            piVar20 = in_RCX[0x11];
            *(char *)((int64_t)in_RCX + 0x466) = *(char *)((int64_t)puVar6 + 0x31);
            *(uint32_t *)(in_RCX + 0xba) = uVar26 | 8;
            *(undefined4 *)((int64_t)in_RCX + 0x491) = *(undefined4 *)((int64_t)in_RCX + 0x452);
            *(undefined4 *)((int64_t)in_RCX + 0x495) = *(undefined4 *)((int64_t)in_RCX + 0x456);
            *(undefined4 *)((int64_t)in_RCX + 0x499) = *(undefined4 *)((int64_t)in_RCX + 0x45a);
            *(undefined4 *)((int64_t)in_RCX + 0x49d) = *(undefined4 *)((int64_t)in_RCX + 0x45e);
            *(undefined4 *)((int64_t)in_RCX + 0x4a1) = *(undefined4 *)((int64_t)in_RCX + 0x462);
            *(undefined *)((int64_t)in_RCX + 0x4a5) = *(undefined *)((int64_t)in_RCX + 0x466);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e21a3;
            func_0x000180207ff0(piVar20);
            uVar26 = *(uint32_t *)(in_RCX + 0xba);
        }
        ppuVar22 = (uint32_t **)in_RCX[0xa0];
        cVar4 = *(char *)*ppuVar22;
        if (cVar4 == '\x01') {
            uVar16 = 1;
        } else if (cVar4 == '\x02') {
            uVar16 = 2;
        } else if (cVar4 == '\x03') {
            uVar16 = 4;
        } else if (cVar4 == '\x05') {
            uVar16 = 8;
        }
        if ((uVar16 & uVar26 >> 0x14) != 0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_98h + iVar17) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar17) = unaff_RDI;
    if (((uVar26 >> 0x19 & 1) == 0) && (ppuVar22[1] != (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e222e;
        iVar14 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != 2) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e223c;
            iVar14 = func_0x00018026bea0(in_RCX + 0xd);
            if (iVar14 != 0x17) goto code_r0x0001801e22b1;
        }
        iVar18 = in_RCX[0xa0][1];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2254;
        iVar14 = func_0x00018026bea0(iVar18);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e225f;
        iVar15 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != iVar15) {
            return;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e226f;
        iVar14 = func_0x00018026bea0(iVar18);
        if (iVar14 == 2) {
            bVar29 = *(int32_t *)(iVar18 + 4) == *(int32_t *)((int64_t)in_RCX + 0x6c);
        } else {
            if (iVar14 != 0x17) {
                return;
            }
            if (*(int64_t **)(iVar18 + 8) != in_RCX[0xe]) {
                return;
            }
            bVar29 = *(int64_t **)(iVar18 + 0x10) == in_RCX[0xf];
        }
        if (!bVar29) {
            return;
        }
        if (*(int16_t *)(iVar18 + 2) != *(int16_t *)((int64_t)in_RCX + 0x6a)) {
            return;
        }
    }
code_r0x0001801e22b1:
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    if (((uVar26 & 0x2000008) == 8) && (pcVar7 = (char *)*in_RCX[0xa0], *pcVar7 != '\x05')) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e22e3;
        iVar14 = func_0x0001801e55b0(pcVar7 + 0x1d, (int64_t)in_RCX + 0x452);
        if (iVar14 == 0) {
            return;
        }
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    puVar6 = *ppuVar22;
    uVar16 = *puVar6 & 0xff;
    if (uVar16 == 5) {
code_r0x0001801e2600:
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar26 = **ppuVar22;
        uVar16 = uVar26 & 0xff;
        if (((uVar16 == 4) || (uVar16 == 6)) || ((uVar26 & 0x300000) == 0)) {
            var_68h = *(int64_t *)(*ppuVar22 + 0x14);
            var_60h = *(int64_t *)(*ppuVar22 + 0x12);
            puVar6 = ppuVar22[8];
            puVar8 = ppuVar22[4];
            puVar9 = *ppuVar22;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2776;
            uVar25 = fcn.1801deee0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                   *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&iStackX_20 + iVar17)
                                   , *(int64_t *)(&stack0x00000028 + iVar17), *(int64_t *)(&stack0x00000030 + iVar17), 
                                   *(int64_t *)(&stack0x00000040 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17));
            *(uint32_t **)((int64_t)&var_8h + iVar17) = puVar6;
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = 1;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2796;
            func_0x000180204f00(uVar25, puVar9, puVar8, &var_68h);
            puVar6 = (uint32_t *)*in_RCX[0xa0];
    // switch table (6 cases) at 0x1801e2cfc
            switch(*puVar6 & 0xff) {
            case 1:
            case 3:
            case 5:
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) && ((*puVar6 & 0xff) == 3)) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e297d;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) &&
                    (ppcVar10 = (char **)in_RCX[0xa0], **ppcVar10 == '\x05')) && (in_RCX[0xb9] <= ppcVar10[4])) {
                    pcVar7 = ppcVar10[7];
                    piVar20 = in_RCX[0x7b];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29c2;
                    pcVar21 = (char *)func_0x000180205200(piVar20);
                    if (pcVar7 < pcVar21) {
                        var_38h = 0;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29d9;
                        iVar18 = func_0x0001801fca50(0xe);
                        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                            return;
                        }
                        uVar25 = 0x1805aadb1;
                        iVar24 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            iVar24 = iVar18;
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a00;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a18;
                        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                        uVar19 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            uVar19 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7120;
                        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                        if (iVar18 != 0) {
                            uVar25 = 0x1805ab2cc;
                        }
                        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a6b;
                        func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xe);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a83;
                        func_0x0001802295a0(0x1804b6360, 0xa35, 0x1804b7090);
                        piVar20 = in_RCX[0xbb];
                        if (piVar20 == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a94;
                            piVar20 = (int64_t *)func_0x0001802542f0();
                            in_RCX[0xbb] = piVar20;
                            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2aa0;
                        } else {
code_r0x0001801e2aa0:
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2aa8;
                            func_0x000180254600(piVar20);
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        uVar25 = 0;
                        var_58h = 0xe;
                        var_48h = 0x1804b7120;
                        var_40h = 0x18;
                        break;
                    }
                }
                if ((((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) || (*(char *)*in_RCX[0xa0] != '\x01')) ||
                   (*(int64_t *)((char *)*in_RCX[0xa0] + 0x40) == 0)) {
                    piVar20 = in_RCX[0xa0];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c12;
                    func_0x0001802004d0(in_RCX, piVar20);
                    if ((*(uint32_t *)(in_RCX + 0xba) & 0x10000000) == 0) {
                        return;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c31;
                    func_0x0001801e2eb0(in_RCX, in_RDX & 0xffffffff, 0);
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b0c;
                iVar18 = func_0x0001801fca50(10);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = 0x1805aadb1;
                if (iVar18 != 0) {
                    iVar24 = iVar18;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b33;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b4b;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7140;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b9e;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bb6;
                func_0x0001802295a0(0x1804b6360, 0xa4e, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bc7;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2bd3;
                } else {
code_r0x0001801e2bd3:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bdb;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 10;
                var_48h = 0x1804b7140;
                var_40h = 0x1d;
                break;
            default:
                goto code_r0x0001801e2ceb;
            case 4:
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000800) != 0) {
                    return;
                }
                if ((*(uint32_t *)(in_RCX + 0xba) & 8) != 0) {
                    return;
                }
                if (*(uint64_t *)(puVar6 + 0x12) < 0x11) {
                    return;
                }
                uVar25 = ((undefined8 *)**in_RCX)[1];
                uVar19 = *(undefined8 *)**in_RCX;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2809;
                iVar14 = func_0x0001801f8c80(uVar19, uVar25, puVar6, in_RCX + 0x85);
                if (iVar14 == 0) {
                    return;
                }
                *(uint32_t *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar28;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2838;
                iVar14 = fcn.1801e1af0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                       *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&var_10h + iVar17)
                                       , *(int64_t *)((int64_t)&iStackX_20 + iVar17 + -8), 
                                       *(int64_t *)((int64_t)&iStackX_20 + iVar17), 
                                       *(int64_t *)(&stack0x00000030 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17)
                                       , *(int64_t *)(&stack0x00000070 + iVar17));
                if (iVar14 != 0) {
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e284e;
                iVar18 = func_0x0001801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2885;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e289d;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7108;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e28f3;
                func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e290b;
                func_0x0001802295a0(0x1804b6360, 0xa0f, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e291f;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e292e;
                } else {
code_r0x0001801e292e:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2936;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 1;
                var_48h = 0x1804b7108;
                var_40h = 0x15;
                break;
            case 6:
                if (uVar28 != 0) {
                    return;
                }
                uVar27 = *(uint64_t *)(puVar6 + 0x12);
                if (0x7fffffffffffffff < uVar27) {
                    return;
                }
                puVar23 = *(undefined **)(puVar6 + 0x14);
                while ((uVar27 != 0 && (3 < uVar27))) {
                    uVar5 = *puVar23;
                    uVar27 = uVar27 - 4;
                    puVar1 = puVar23 + 1;
                    puVar2 = puVar23 + 2;
                    puVar3 = puVar23 + 3;
                    puVar23 = puVar23 + 4;
                    if (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) == 1) {
                        return;
                    }
                }
                var_48h = 0x1804b7160;
                uVar25 = 1;
                var_38h = 0;
                var_40h = 0x1b;
code_r0x0001801e2cb7:
                var_58h = 2;
            }
        } else {
            var_38h = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e263e;
            iVar18 = func_0x0001801fca50(10);
            if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                return;
            }
            uVar25 = 0x1805aadb1;
            iVar24 = iVar18;
            if (iVar18 == 0) {
                iVar24 = 0x1805aadb1;
            }
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2675;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e268d;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar19 = 0x1805aadb1;
            if (iVar18 != 0) {
                uVar19 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70e8;
            *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
            *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
            if (iVar18 != 0) {
                uVar25 = 0x1805ab2cc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26e3;
            func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26fb;
            func_0x0001802295a0(0x1804b6360, 0x9db, 0x1804b7090);
            piVar20 = in_RCX[0xbb];
            if (piVar20 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e270f;
                piVar20 = (int64_t *)func_0x0001802542f0();
                in_RCX[0xbb] = piVar20;
                if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e271e;
            } else {
code_r0x0001801e271e:
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2726;
                func_0x000180254600(piVar20);
            }
            *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
            uVar25 = 0;
            var_58h = 10;
            var_48h = 0x1804b70e8;
            var_40h = 0x1b;
        }
    } else {
        if (uVar16 != 6) {
            if (puVar6[1] != 1) {
                return;
            }
            if (uVar16 != 6) goto code_r0x0001801e2600;
        }
        if (puVar6[1] != 0) {
            return;
        }
        if (uVar28 != 0) {
            return;
        }
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar27 = *(uint64_t *)(*ppuVar22 + 0x12);
        if (0x7fffffffffffffff < uVar27) {
            return;
        }
        puVar23 = *(undefined **)(*ppuVar22 + 0x14);
        do {
            if (uVar27 == 0) {
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23ac;
                iVar18 = func_0x0001801fca50(2);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23e3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23fb;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70c8;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2451;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 2);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2469;
                func_0x0001802295a0(0x1804b6360, 0x9cd, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e247d;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e248c;
                } else {
code_r0x0001801e248c:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2494;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_48h = 0x1804b70c8;
                var_40h = 0x1c;
                goto code_r0x0001801e2cb7;
            }
            if (uVar27 < 4) {
                return;
            }
            uVar5 = *puVar23;
            uVar27 = uVar27 - 4;
            puVar1 = puVar23 + 1;
            puVar2 = puVar23 + 2;
            puVar3 = puVar23 + 3;
            puVar23 = puVar23 + 4;
        } while (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) != 1);
        piVar20 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24c7;
        func_0x0001802081e0(piVar20, 1);
        piVar20 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24d8;
        iVar14 = func_0x0001802029e0(piVar20, 0, 0);
        if (iVar14 != 0) {
            return;
        }
        var_38h = 0;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24ee;
        iVar18 = func_0x0001801fca50(1);
        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
            return;
        }
        uVar25 = 0x1805aadb1;
        iVar24 = iVar18;
        if (iVar18 == 0) {
            iVar24 = 0x1805aadb1;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2525;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e253d;
        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
        uVar19 = 0x1805aadb1;
        if (iVar18 != 0) {
            uVar19 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70a8;
        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
        if (iVar18 != 0) {
            uVar25 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2593;
        func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25ab;
        func_0x0001802295a0(0x1804b6360, 0x9c3, 0x1804b7090);
        piVar20 = in_RCX[0xbb];
        if (piVar20 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25bf;
            piVar20 = (int64_t *)func_0x0001802542f0();
            in_RCX[0xbb] = piVar20;
            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e25ce;
        } else {
code_r0x0001801e25ce:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25d6;
            func_0x000180254600(piVar20);
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
        uVar25 = 0;
        var_58h = 1;
        var_48h = 0x1804b70a8;
        var_40h = 0x1f;
    }
    var_50h = 0;
    *(code **)((int64_t)&pcStack_28 + iVar17) = case.0x1801e27c6.2;
    func_0x0001801e2d20(in_RCX, &var_58h, uVar25);
code_r0x0001801e2ceb:
    return;
}

// ============================================================
// Function: FUN_1801e21f8
// Address: 0x1801e21f8
// Size: 2795 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.1801e20e0(int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined *puVar3;
    char cVar4;
    undefined uVar5;
    uint32_t *puVar6;
    char *pcVar7;
    uint32_t *puVar8;
    uint32_t *puVar9;
    char **ppcVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t iVar18;
    undefined8 uVar19;
    int64_t *piVar20;
    char *pcVar21;
    int64_t **in_RCX;
    uint64_t in_RDX;
    uint32_t **ppuVar22;
    undefined *puVar23;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t iVar24;
    undefined8 unaff_RDI;
    undefined8 uVar25;
    uint32_t uVar26;
    uint64_t uVar27;
    undefined8 unaff_R13;
    uint32_t uVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1801e20f7;
    iVar17 = fcn.18045a350();
    iVar17 = -iVar17;
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    uVar28 = uVar26 >> 4 & 1;
    if (((uint8_t)uVar26 & 7) != 1) {
        return;
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    *(undefined8 *)((int64_t)&arg_60h + iVar17) = unaff_R13;
    puVar6 = *ppuVar22;
    uVar16 = 0;
    if (((*puVar6 & 0xff) != 4) && ((*puVar6 & 0xff) != 6)) {
        if ((uVar26 & 8) == 0) {
            uVar11 = *(undefined4 *)((int64_t)puVar6 + 0x21);
            uVar12 = *(undefined4 *)((int64_t)puVar6 + 0x25);
            uVar13 = *(undefined4 *)((int64_t)puVar6 + 0x29);
            *(undefined4 *)((int64_t)in_RCX + 0x452) = *(undefined4 *)((int64_t)puVar6 + 0x1d);
            *(undefined4 *)((int64_t)in_RCX + 0x456) = uVar11;
            *(undefined4 *)((int64_t)in_RCX + 0x45a) = uVar12;
            *(undefined4 *)((int64_t)in_RCX + 0x45e) = uVar13;
            *(undefined4 *)((int64_t)in_RCX + 0x462) = *(undefined4 *)((int64_t)puVar6 + 0x2d);
            piVar20 = in_RCX[0x11];
            *(char *)((int64_t)in_RCX + 0x466) = *(char *)((int64_t)puVar6 + 0x31);
            *(uint32_t *)(in_RCX + 0xba) = uVar26 | 8;
            *(undefined4 *)((int64_t)in_RCX + 0x491) = *(undefined4 *)((int64_t)in_RCX + 0x452);
            *(undefined4 *)((int64_t)in_RCX + 0x495) = *(undefined4 *)((int64_t)in_RCX + 0x456);
            *(undefined4 *)((int64_t)in_RCX + 0x499) = *(undefined4 *)((int64_t)in_RCX + 0x45a);
            *(undefined4 *)((int64_t)in_RCX + 0x49d) = *(undefined4 *)((int64_t)in_RCX + 0x45e);
            *(undefined4 *)((int64_t)in_RCX + 0x4a1) = *(undefined4 *)((int64_t)in_RCX + 0x462);
            *(undefined *)((int64_t)in_RCX + 0x4a5) = *(undefined *)((int64_t)in_RCX + 0x466);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e21a3;
            func_0x000180207ff0(piVar20);
            uVar26 = *(uint32_t *)(in_RCX + 0xba);
        }
        ppuVar22 = (uint32_t **)in_RCX[0xa0];
        cVar4 = *(char *)*ppuVar22;
        if (cVar4 == '\x01') {
            uVar16 = 1;
        } else if (cVar4 == '\x02') {
            uVar16 = 2;
        } else if (cVar4 == '\x03') {
            uVar16 = 4;
        } else if (cVar4 == '\x05') {
            uVar16 = 8;
        }
        if ((uVar16 & uVar26 >> 0x14) != 0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_98h + iVar17) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar17) = unaff_RDI;
    if (((uVar26 >> 0x19 & 1) == 0) && (ppuVar22[1] != (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e222e;
        iVar14 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != 2) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e223c;
            iVar14 = func_0x00018026bea0(in_RCX + 0xd);
            if (iVar14 != 0x17) goto code_r0x0001801e22b1;
        }
        iVar18 = in_RCX[0xa0][1];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2254;
        iVar14 = func_0x00018026bea0(iVar18);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e225f;
        iVar15 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != iVar15) {
            return;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e226f;
        iVar14 = func_0x00018026bea0(iVar18);
        if (iVar14 == 2) {
            bVar29 = *(int32_t *)(iVar18 + 4) == *(int32_t *)((int64_t)in_RCX + 0x6c);
        } else {
            if (iVar14 != 0x17) {
                return;
            }
            if (*(int64_t **)(iVar18 + 8) != in_RCX[0xe]) {
                return;
            }
            bVar29 = *(int64_t **)(iVar18 + 0x10) == in_RCX[0xf];
        }
        if (!bVar29) {
            return;
        }
        if (*(int16_t *)(iVar18 + 2) != *(int16_t *)((int64_t)in_RCX + 0x6a)) {
            return;
        }
    }
code_r0x0001801e22b1:
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    if (((uVar26 & 0x2000008) == 8) && (pcVar7 = (char *)*in_RCX[0xa0], *pcVar7 != '\x05')) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e22e3;
        iVar14 = func_0x0001801e55b0(pcVar7 + 0x1d, (int64_t)in_RCX + 0x452);
        if (iVar14 == 0) {
            return;
        }
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    puVar6 = *ppuVar22;
    uVar16 = *puVar6 & 0xff;
    if (uVar16 == 5) {
code_r0x0001801e2600:
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar26 = **ppuVar22;
        uVar16 = uVar26 & 0xff;
        if (((uVar16 == 4) || (uVar16 == 6)) || ((uVar26 & 0x300000) == 0)) {
            var_68h = *(int64_t *)(*ppuVar22 + 0x14);
            var_60h = *(int64_t *)(*ppuVar22 + 0x12);
            puVar6 = ppuVar22[8];
            puVar8 = ppuVar22[4];
            puVar9 = *ppuVar22;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2776;
            uVar25 = fcn.1801deee0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                   *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&iStackX_20 + iVar17)
                                   , *(int64_t *)(&stack0x00000028 + iVar17), *(int64_t *)(&stack0x00000030 + iVar17), 
                                   *(int64_t *)(&stack0x00000040 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17));
            *(uint32_t **)((int64_t)&var_8h + iVar17) = puVar6;
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = 1;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2796;
            func_0x000180204f00(uVar25, puVar9, puVar8, &var_68h);
            puVar6 = (uint32_t *)*in_RCX[0xa0];
    // switch table (6 cases) at 0x1801e2cfc
            switch(*puVar6 & 0xff) {
            case 1:
            case 3:
            case 5:
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) && ((*puVar6 & 0xff) == 3)) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e297d;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) &&
                    (ppcVar10 = (char **)in_RCX[0xa0], **ppcVar10 == '\x05')) && (in_RCX[0xb9] <= ppcVar10[4])) {
                    pcVar7 = ppcVar10[7];
                    piVar20 = in_RCX[0x7b];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29c2;
                    pcVar21 = (char *)func_0x000180205200(piVar20);
                    if (pcVar7 < pcVar21) {
                        var_38h = 0;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29d9;
                        iVar18 = func_0x0001801fca50(0xe);
                        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                            return;
                        }
                        uVar25 = 0x1805aadb1;
                        iVar24 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            iVar24 = iVar18;
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a00;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a18;
                        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                        uVar19 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            uVar19 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7120;
                        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                        if (iVar18 != 0) {
                            uVar25 = 0x1805ab2cc;
                        }
                        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a6b;
                        func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xe);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a83;
                        func_0x0001802295a0(0x1804b6360, 0xa35, 0x1804b7090);
                        piVar20 = in_RCX[0xbb];
                        if (piVar20 == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a94;
                            piVar20 = (int64_t *)func_0x0001802542f0();
                            in_RCX[0xbb] = piVar20;
                            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2aa0;
                        } else {
code_r0x0001801e2aa0:
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2aa8;
                            func_0x000180254600(piVar20);
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        uVar25 = 0;
                        var_58h = 0xe;
                        var_48h = 0x1804b7120;
                        var_40h = 0x18;
                        break;
                    }
                }
                if ((((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) || (*(char *)*in_RCX[0xa0] != '\x01')) ||
                   (*(int64_t *)((char *)*in_RCX[0xa0] + 0x40) == 0)) {
                    piVar20 = in_RCX[0xa0];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c12;
                    func_0x0001802004d0(in_RCX, piVar20);
                    if ((*(uint32_t *)(in_RCX + 0xba) & 0x10000000) == 0) {
                        return;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c31;
                    func_0x0001801e2eb0(in_RCX, in_RDX & 0xffffffff, 0);
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b0c;
                iVar18 = func_0x0001801fca50(10);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = 0x1805aadb1;
                if (iVar18 != 0) {
                    iVar24 = iVar18;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b33;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b4b;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7140;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b9e;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bb6;
                func_0x0001802295a0(0x1804b6360, 0xa4e, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bc7;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2bd3;
                } else {
code_r0x0001801e2bd3:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bdb;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 10;
                var_48h = 0x1804b7140;
                var_40h = 0x1d;
                break;
            default:
                goto code_r0x0001801e2ceb;
            case 4:
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000800) != 0) {
                    return;
                }
                if ((*(uint32_t *)(in_RCX + 0xba) & 8) != 0) {
                    return;
                }
                if (*(uint64_t *)(puVar6 + 0x12) < 0x11) {
                    return;
                }
                uVar25 = ((undefined8 *)**in_RCX)[1];
                uVar19 = *(undefined8 *)**in_RCX;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2809;
                iVar14 = func_0x0001801f8c80(uVar19, uVar25, puVar6, in_RCX + 0x85);
                if (iVar14 == 0) {
                    return;
                }
                *(uint32_t *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar28;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2838;
                iVar14 = fcn.1801e1af0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                       *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&var_10h + iVar17)
                                       , *(int64_t *)((int64_t)&iStackX_20 + iVar17 + -8), 
                                       *(int64_t *)((int64_t)&iStackX_20 + iVar17), 
                                       *(int64_t *)(&stack0x00000030 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17)
                                       , *(int64_t *)(&stack0x00000070 + iVar17));
                if (iVar14 != 0) {
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e284e;
                iVar18 = func_0x0001801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2885;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e289d;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7108;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e28f3;
                func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e290b;
                func_0x0001802295a0(0x1804b6360, 0xa0f, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e291f;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e292e;
                } else {
code_r0x0001801e292e:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2936;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 1;
                var_48h = 0x1804b7108;
                var_40h = 0x15;
                break;
            case 6:
                if (uVar28 != 0) {
                    return;
                }
                uVar27 = *(uint64_t *)(puVar6 + 0x12);
                if (0x7fffffffffffffff < uVar27) {
                    return;
                }
                puVar23 = *(undefined **)(puVar6 + 0x14);
                while ((uVar27 != 0 && (3 < uVar27))) {
                    uVar5 = *puVar23;
                    uVar27 = uVar27 - 4;
                    puVar1 = puVar23 + 1;
                    puVar2 = puVar23 + 2;
                    puVar3 = puVar23 + 3;
                    puVar23 = puVar23 + 4;
                    if (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) == 1) {
                        return;
                    }
                }
                var_48h = 0x1804b7160;
                uVar25 = 1;
                var_38h = 0;
                var_40h = 0x1b;
code_r0x0001801e2cb7:
                var_58h = 2;
            }
        } else {
            var_38h = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e263e;
            iVar18 = func_0x0001801fca50(10);
            if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                return;
            }
            uVar25 = 0x1805aadb1;
            iVar24 = iVar18;
            if (iVar18 == 0) {
                iVar24 = 0x1805aadb1;
            }
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2675;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e268d;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar19 = 0x1805aadb1;
            if (iVar18 != 0) {
                uVar19 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70e8;
            *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
            *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
            if (iVar18 != 0) {
                uVar25 = 0x1805ab2cc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26e3;
            func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26fb;
            func_0x0001802295a0(0x1804b6360, 0x9db, 0x1804b7090);
            piVar20 = in_RCX[0xbb];
            if (piVar20 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e270f;
                piVar20 = (int64_t *)func_0x0001802542f0();
                in_RCX[0xbb] = piVar20;
                if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e271e;
            } else {
code_r0x0001801e271e:
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2726;
                func_0x000180254600(piVar20);
            }
            *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
            uVar25 = 0;
            var_58h = 10;
            var_48h = 0x1804b70e8;
            var_40h = 0x1b;
        }
    } else {
        if (uVar16 != 6) {
            if (puVar6[1] != 1) {
                return;
            }
            if (uVar16 != 6) goto code_r0x0001801e2600;
        }
        if (puVar6[1] != 0) {
            return;
        }
        if (uVar28 != 0) {
            return;
        }
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar27 = *(uint64_t *)(*ppuVar22 + 0x12);
        if (0x7fffffffffffffff < uVar27) {
            return;
        }
        puVar23 = *(undefined **)(*ppuVar22 + 0x14);
        do {
            if (uVar27 == 0) {
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23ac;
                iVar18 = func_0x0001801fca50(2);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23e3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23fb;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70c8;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2451;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 2);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2469;
                func_0x0001802295a0(0x1804b6360, 0x9cd, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e247d;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e248c;
                } else {
code_r0x0001801e248c:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2494;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_48h = 0x1804b70c8;
                var_40h = 0x1c;
                goto code_r0x0001801e2cb7;
            }
            if (uVar27 < 4) {
                return;
            }
            uVar5 = *puVar23;
            uVar27 = uVar27 - 4;
            puVar1 = puVar23 + 1;
            puVar2 = puVar23 + 2;
            puVar3 = puVar23 + 3;
            puVar23 = puVar23 + 4;
        } while (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) != 1);
        piVar20 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24c7;
        func_0x0001802081e0(piVar20, 1);
        piVar20 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24d8;
        iVar14 = func_0x0001802029e0(piVar20, 0, 0);
        if (iVar14 != 0) {
            return;
        }
        var_38h = 0;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24ee;
        iVar18 = func_0x0001801fca50(1);
        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
            return;
        }
        uVar25 = 0x1805aadb1;
        iVar24 = iVar18;
        if (iVar18 == 0) {
            iVar24 = 0x1805aadb1;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2525;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e253d;
        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
        uVar19 = 0x1805aadb1;
        if (iVar18 != 0) {
            uVar19 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70a8;
        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
        if (iVar18 != 0) {
            uVar25 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2593;
        func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25ab;
        func_0x0001802295a0(0x1804b6360, 0x9c3, 0x1804b7090);
        piVar20 = in_RCX[0xbb];
        if (piVar20 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25bf;
            piVar20 = (int64_t *)func_0x0001802542f0();
            in_RCX[0xbb] = piVar20;
            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e25ce;
        } else {
code_r0x0001801e25ce:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25d6;
            func_0x000180254600(piVar20);
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
        uVar25 = 0;
        var_58h = 1;
        var_48h = 0x1804b70a8;
        var_40h = 0x1f;
    }
    var_50h = 0;
    *(code **)((int64_t)&pcStack_28 + iVar17) = case.0x1801e27c6.2;
    func_0x0001801e2d20(in_RCX, &var_58h, uVar25);
code_r0x0001801e2ceb:
    return;
}

// ============================================================
// Function: FUN_1801e2ce3
// Address: 0x1801e2ce3
// Size: 8 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.1801e20e0(int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined *puVar3;
    char cVar4;
    undefined uVar5;
    uint32_t *puVar6;
    char *pcVar7;
    uint32_t *puVar8;
    uint32_t *puVar9;
    char **ppcVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t iVar18;
    undefined8 uVar19;
    int64_t *piVar20;
    char *pcVar21;
    int64_t **in_RCX;
    uint64_t in_RDX;
    uint32_t **ppuVar22;
    undefined *puVar23;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t iVar24;
    undefined8 unaff_RDI;
    undefined8 uVar25;
    uint32_t uVar26;
    uint64_t uVar27;
    undefined8 unaff_R13;
    uint32_t uVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1801e20f7;
    iVar17 = fcn.18045a350();
    iVar17 = -iVar17;
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    uVar28 = uVar26 >> 4 & 1;
    if (((uint8_t)uVar26 & 7) != 1) {
        return;
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    *(undefined8 *)((int64_t)&arg_60h + iVar17) = unaff_R13;
    puVar6 = *ppuVar22;
    uVar16 = 0;
    if (((*puVar6 & 0xff) != 4) && ((*puVar6 & 0xff) != 6)) {
        if ((uVar26 & 8) == 0) {
            uVar11 = *(undefined4 *)((int64_t)puVar6 + 0x21);
            uVar12 = *(undefined4 *)((int64_t)puVar6 + 0x25);
            uVar13 = *(undefined4 *)((int64_t)puVar6 + 0x29);
            *(undefined4 *)((int64_t)in_RCX + 0x452) = *(undefined4 *)((int64_t)puVar6 + 0x1d);
            *(undefined4 *)((int64_t)in_RCX + 0x456) = uVar11;
            *(undefined4 *)((int64_t)in_RCX + 0x45a) = uVar12;
            *(undefined4 *)((int64_t)in_RCX + 0x45e) = uVar13;
            *(undefined4 *)((int64_t)in_RCX + 0x462) = *(undefined4 *)((int64_t)puVar6 + 0x2d);
            piVar20 = in_RCX[0x11];
            *(char *)((int64_t)in_RCX + 0x466) = *(char *)((int64_t)puVar6 + 0x31);
            *(uint32_t *)(in_RCX + 0xba) = uVar26 | 8;
            *(undefined4 *)((int64_t)in_RCX + 0x491) = *(undefined4 *)((int64_t)in_RCX + 0x452);
            *(undefined4 *)((int64_t)in_RCX + 0x495) = *(undefined4 *)((int64_t)in_RCX + 0x456);
            *(undefined4 *)((int64_t)in_RCX + 0x499) = *(undefined4 *)((int64_t)in_RCX + 0x45a);
            *(undefined4 *)((int64_t)in_RCX + 0x49d) = *(undefined4 *)((int64_t)in_RCX + 0x45e);
            *(undefined4 *)((int64_t)in_RCX + 0x4a1) = *(undefined4 *)((int64_t)in_RCX + 0x462);
            *(undefined *)((int64_t)in_RCX + 0x4a5) = *(undefined *)((int64_t)in_RCX + 0x466);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e21a3;
            func_0x000180207ff0(piVar20);
            uVar26 = *(uint32_t *)(in_RCX + 0xba);
        }
        ppuVar22 = (uint32_t **)in_RCX[0xa0];
        cVar4 = *(char *)*ppuVar22;
        if (cVar4 == '\x01') {
            uVar16 = 1;
        } else if (cVar4 == '\x02') {
            uVar16 = 2;
        } else if (cVar4 == '\x03') {
            uVar16 = 4;
        } else if (cVar4 == '\x05') {
            uVar16 = 8;
        }
        if ((uVar16 & uVar26 >> 0x14) != 0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_98h + iVar17) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar17) = unaff_RDI;
    if (((uVar26 >> 0x19 & 1) == 0) && (ppuVar22[1] != (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e222e;
        iVar14 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != 2) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e223c;
            iVar14 = func_0x00018026bea0(in_RCX + 0xd);
            if (iVar14 != 0x17) goto code_r0x0001801e22b1;
        }
        iVar18 = in_RCX[0xa0][1];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2254;
        iVar14 = func_0x00018026bea0(iVar18);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e225f;
        iVar15 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != iVar15) {
            return;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e226f;
        iVar14 = func_0x00018026bea0(iVar18);
        if (iVar14 == 2) {
            bVar29 = *(int32_t *)(iVar18 + 4) == *(int32_t *)((int64_t)in_RCX + 0x6c);
        } else {
            if (iVar14 != 0x17) {
                return;
            }
            if (*(int64_t **)(iVar18 + 8) != in_RCX[0xe]) {
                return;
            }
            bVar29 = *(int64_t **)(iVar18 + 0x10) == in_RCX[0xf];
        }
        if (!bVar29) {
            return;
        }
        if (*(int16_t *)(iVar18 + 2) != *(int16_t *)((int64_t)in_RCX + 0x6a)) {
            return;
        }
    }
code_r0x0001801e22b1:
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    if (((uVar26 & 0x2000008) == 8) && (pcVar7 = (char *)*in_RCX[0xa0], *pcVar7 != '\x05')) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e22e3;
        iVar14 = func_0x0001801e55b0(pcVar7 + 0x1d, (int64_t)in_RCX + 0x452);
        if (iVar14 == 0) {
            return;
        }
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    puVar6 = *ppuVar22;
    uVar16 = *puVar6 & 0xff;
    if (uVar16 == 5) {
code_r0x0001801e2600:
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar26 = **ppuVar22;
        uVar16 = uVar26 & 0xff;
        if (((uVar16 == 4) || (uVar16 == 6)) || ((uVar26 & 0x300000) == 0)) {
            var_68h = *(int64_t *)(*ppuVar22 + 0x14);
            var_60h = *(int64_t *)(*ppuVar22 + 0x12);
            puVar6 = ppuVar22[8];
            puVar8 = ppuVar22[4];
            puVar9 = *ppuVar22;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2776;
            uVar25 = fcn.1801deee0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                   *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&iStackX_20 + iVar17)
                                   , *(int64_t *)(&stack0x00000028 + iVar17), *(int64_t *)(&stack0x00000030 + iVar17), 
                                   *(int64_t *)(&stack0x00000040 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17));
            *(uint32_t **)((int64_t)&var_8h + iVar17) = puVar6;
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = 1;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2796;
            func_0x000180204f00(uVar25, puVar9, puVar8, &var_68h);
            puVar6 = (uint32_t *)*in_RCX[0xa0];
    // switch table (6 cases) at 0x1801e2cfc
            switch(*puVar6 & 0xff) {
            case 1:
            case 3:
            case 5:
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) && ((*puVar6 & 0xff) == 3)) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e297d;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) &&
                    (ppcVar10 = (char **)in_RCX[0xa0], **ppcVar10 == '\x05')) && (in_RCX[0xb9] <= ppcVar10[4])) {
                    pcVar7 = ppcVar10[7];
                    piVar20 = in_RCX[0x7b];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29c2;
                    pcVar21 = (char *)func_0x000180205200(piVar20);
                    if (pcVar7 < pcVar21) {
                        var_38h = 0;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29d9;
                        iVar18 = func_0x0001801fca50(0xe);
                        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                            return;
                        }
                        uVar25 = 0x1805aadb1;
                        iVar24 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            iVar24 = iVar18;
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a00;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a18;
                        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                        uVar19 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            uVar19 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7120;
                        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                        if (iVar18 != 0) {
                            uVar25 = 0x1805ab2cc;
                        }
                        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a6b;
                        func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xe);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a83;
                        func_0x0001802295a0(0x1804b6360, 0xa35, 0x1804b7090);
                        piVar20 = in_RCX[0xbb];
                        if (piVar20 == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a94;
                            piVar20 = (int64_t *)func_0x0001802542f0();
                            in_RCX[0xbb] = piVar20;
                            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2aa0;
                        } else {
code_r0x0001801e2aa0:
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2aa8;
                            func_0x000180254600(piVar20);
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        uVar25 = 0;
                        var_58h = 0xe;
                        var_48h = 0x1804b7120;
                        var_40h = 0x18;
                        break;
                    }
                }
                if ((((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) || (*(char *)*in_RCX[0xa0] != '\x01')) ||
                   (*(int64_t *)((char *)*in_RCX[0xa0] + 0x40) == 0)) {
                    piVar20 = in_RCX[0xa0];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c12;
                    func_0x0001802004d0(in_RCX, piVar20);
                    if ((*(uint32_t *)(in_RCX + 0xba) & 0x10000000) == 0) {
                        return;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c31;
                    func_0x0001801e2eb0(in_RCX, in_RDX & 0xffffffff, 0);
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b0c;
                iVar18 = func_0x0001801fca50(10);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = 0x1805aadb1;
                if (iVar18 != 0) {
                    iVar24 = iVar18;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b33;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b4b;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7140;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b9e;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bb6;
                func_0x0001802295a0(0x1804b6360, 0xa4e, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bc7;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2bd3;
                } else {
code_r0x0001801e2bd3:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bdb;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 10;
                var_48h = 0x1804b7140;
                var_40h = 0x1d;
                break;
            default:
                goto code_r0x0001801e2ceb;
            case 4:
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000800) != 0) {
                    return;
                }
                if ((*(uint32_t *)(in_RCX + 0xba) & 8) != 0) {
                    return;
                }
                if (*(uint64_t *)(puVar6 + 0x12) < 0x11) {
                    return;
                }
                uVar25 = ((undefined8 *)**in_RCX)[1];
                uVar19 = *(undefined8 *)**in_RCX;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2809;
                iVar14 = func_0x0001801f8c80(uVar19, uVar25, puVar6, in_RCX + 0x85);
                if (iVar14 == 0) {
                    return;
                }
                *(uint32_t *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar28;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2838;
                iVar14 = fcn.1801e1af0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                       *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&var_10h + iVar17)
                                       , *(int64_t *)((int64_t)&iStackX_20 + iVar17 + -8), 
                                       *(int64_t *)((int64_t)&iStackX_20 + iVar17), 
                                       *(int64_t *)(&stack0x00000030 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17)
                                       , *(int64_t *)(&stack0x00000070 + iVar17));
                if (iVar14 != 0) {
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e284e;
                iVar18 = func_0x0001801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2885;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e289d;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7108;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e28f3;
                func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e290b;
                func_0x0001802295a0(0x1804b6360, 0xa0f, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e291f;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e292e;
                } else {
code_r0x0001801e292e:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2936;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 1;
                var_48h = 0x1804b7108;
                var_40h = 0x15;
                break;
            case 6:
                if (uVar28 != 0) {
                    return;
                }
                uVar27 = *(uint64_t *)(puVar6 + 0x12);
                if (0x7fffffffffffffff < uVar27) {
                    return;
                }
                puVar23 = *(undefined **)(puVar6 + 0x14);
                while ((uVar27 != 0 && (3 < uVar27))) {
                    uVar5 = *puVar23;
                    uVar27 = uVar27 - 4;
                    puVar1 = puVar23 + 1;
                    puVar2 = puVar23 + 2;
                    puVar3 = puVar23 + 3;
                    puVar23 = puVar23 + 4;
                    if (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) == 1) {
                        return;
                    }
                }
                var_48h = 0x1804b7160;
                uVar25 = 1;
                var_38h = 0;
                var_40h = 0x1b;
code_r0x0001801e2cb7:
                var_58h = 2;
            }
        } else {
            var_38h = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e263e;
            iVar18 = func_0x0001801fca50(10);
            if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                return;
            }
            uVar25 = 0x1805aadb1;
            iVar24 = iVar18;
            if (iVar18 == 0) {
                iVar24 = 0x1805aadb1;
            }
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2675;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e268d;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar19 = 0x1805aadb1;
            if (iVar18 != 0) {
                uVar19 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70e8;
            *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
            *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
            if (iVar18 != 0) {
                uVar25 = 0x1805ab2cc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26e3;
            func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26fb;
            func_0x0001802295a0(0x1804b6360, 0x9db, 0x1804b7090);
            piVar20 = in_RCX[0xbb];
            if (piVar20 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e270f;
                piVar20 = (int64_t *)func_0x0001802542f0();
                in_RCX[0xbb] = piVar20;
                if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e271e;
            } else {
code_r0x0001801e271e:
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2726;
                func_0x000180254600(piVar20);
            }
            *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
            uVar25 = 0;
            var_58h = 10;
            var_48h = 0x1804b70e8;
            var_40h = 0x1b;
        }
    } else {
        if (uVar16 != 6) {
            if (puVar6[1] != 1) {
                return;
            }
            if (uVar16 != 6) goto code_r0x0001801e2600;
        }
        if (puVar6[1] != 0) {
            return;
        }
        if (uVar28 != 0) {
            return;
        }
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar27 = *(uint64_t *)(*ppuVar22 + 0x12);
        if (0x7fffffffffffffff < uVar27) {
            return;
        }
        puVar23 = *(undefined **)(*ppuVar22 + 0x14);
        do {
            if (uVar27 == 0) {
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23ac;
                iVar18 = func_0x0001801fca50(2);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23e3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23fb;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70c8;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2451;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 2);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2469;
                func_0x0001802295a0(0x1804b6360, 0x9cd, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e247d;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e248c;
                } else {
code_r0x0001801e248c:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2494;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_48h = 0x1804b70c8;
                var_40h = 0x1c;
                goto code_r0x0001801e2cb7;
            }
            if (uVar27 < 4) {
                return;
            }
            uVar5 = *puVar23;
            uVar27 = uVar27 - 4;
            puVar1 = puVar23 + 1;
            puVar2 = puVar23 + 2;
            puVar3 = puVar23 + 3;
            puVar23 = puVar23 + 4;
        } while (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) != 1);
        piVar20 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24c7;
        func_0x0001802081e0(piVar20, 1);
        piVar20 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24d8;
        iVar14 = func_0x0001802029e0(piVar20, 0, 0);
        if (iVar14 != 0) {
            return;
        }
        var_38h = 0;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24ee;
        iVar18 = func_0x0001801fca50(1);
        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
            return;
        }
        uVar25 = 0x1805aadb1;
        iVar24 = iVar18;
        if (iVar18 == 0) {
            iVar24 = 0x1805aadb1;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2525;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e253d;
        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
        uVar19 = 0x1805aadb1;
        if (iVar18 != 0) {
            uVar19 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70a8;
        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
        if (iVar18 != 0) {
            uVar25 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2593;
        func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25ab;
        func_0x0001802295a0(0x1804b6360, 0x9c3, 0x1804b7090);
        piVar20 = in_RCX[0xbb];
        if (piVar20 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25bf;
            piVar20 = (int64_t *)func_0x0001802542f0();
            in_RCX[0xbb] = piVar20;
            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e25ce;
        } else {
code_r0x0001801e25ce:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25d6;
            func_0x000180254600(piVar20);
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
        uVar25 = 0;
        var_58h = 1;
        var_48h = 0x1804b70a8;
        var_40h = 0x1f;
    }
    var_50h = 0;
    *(code **)((int64_t)&pcStack_28 + iVar17) = case.0x1801e27c6.2;
    func_0x0001801e2d20(in_RCX, &var_58h, uVar25);
code_r0x0001801e2ceb:
    return;
}

// ============================================================
// Function: FUN_1801e2ceb
// Address: 0x1801e2ceb
// Size: 41 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.1801e20e0(int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined *puVar3;
    char cVar4;
    undefined uVar5;
    uint32_t *puVar6;
    char *pcVar7;
    uint32_t *puVar8;
    uint32_t *puVar9;
    char **ppcVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t iVar18;
    undefined8 uVar19;
    int64_t *piVar20;
    char *pcVar21;
    int64_t **in_RCX;
    uint64_t in_RDX;
    uint32_t **ppuVar22;
    undefined *puVar23;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t iVar24;
    undefined8 unaff_RDI;
    undefined8 uVar25;
    uint32_t uVar26;
    uint64_t uVar27;
    undefined8 unaff_R13;
    uint32_t uVar28;
    bool bVar29;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    code *pcStack_28;
    
    pcStack_28 = (code *)0x1801e20f7;
    iVar17 = fcn.18045a350();
    iVar17 = -iVar17;
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    uVar28 = uVar26 >> 4 & 1;
    if (((uint8_t)uVar26 & 7) != 1) {
        return;
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    *(undefined8 *)((int64_t)&arg_60h + iVar17) = unaff_R13;
    puVar6 = *ppuVar22;
    uVar16 = 0;
    if (((*puVar6 & 0xff) != 4) && ((*puVar6 & 0xff) != 6)) {
        if ((uVar26 & 8) == 0) {
            uVar11 = *(undefined4 *)((int64_t)puVar6 + 0x21);
            uVar12 = *(undefined4 *)((int64_t)puVar6 + 0x25);
            uVar13 = *(undefined4 *)((int64_t)puVar6 + 0x29);
            *(undefined4 *)((int64_t)in_RCX + 0x452) = *(undefined4 *)((int64_t)puVar6 + 0x1d);
            *(undefined4 *)((int64_t)in_RCX + 0x456) = uVar11;
            *(undefined4 *)((int64_t)in_RCX + 0x45a) = uVar12;
            *(undefined4 *)((int64_t)in_RCX + 0x45e) = uVar13;
            *(undefined4 *)((int64_t)in_RCX + 0x462) = *(undefined4 *)((int64_t)puVar6 + 0x2d);
            piVar20 = in_RCX[0x11];
            *(char *)((int64_t)in_RCX + 0x466) = *(char *)((int64_t)puVar6 + 0x31);
            *(uint32_t *)(in_RCX + 0xba) = uVar26 | 8;
            *(undefined4 *)((int64_t)in_RCX + 0x491) = *(undefined4 *)((int64_t)in_RCX + 0x452);
            *(undefined4 *)((int64_t)in_RCX + 0x495) = *(undefined4 *)((int64_t)in_RCX + 0x456);
            *(undefined4 *)((int64_t)in_RCX + 0x499) = *(undefined4 *)((int64_t)in_RCX + 0x45a);
            *(undefined4 *)((int64_t)in_RCX + 0x49d) = *(undefined4 *)((int64_t)in_RCX + 0x45e);
            *(undefined4 *)((int64_t)in_RCX + 0x4a1) = *(undefined4 *)((int64_t)in_RCX + 0x462);
            *(undefined *)((int64_t)in_RCX + 0x4a5) = *(undefined *)((int64_t)in_RCX + 0x466);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e21a3;
            func_0x000180207ff0(piVar20);
            uVar26 = *(uint32_t *)(in_RCX + 0xba);
        }
        ppuVar22 = (uint32_t **)in_RCX[0xa0];
        cVar4 = *(char *)*ppuVar22;
        if (cVar4 == '\x01') {
            uVar16 = 1;
        } else if (cVar4 == '\x02') {
            uVar16 = 2;
        } else if (cVar4 == '\x03') {
            uVar16 = 4;
        } else if (cVar4 == '\x05') {
            uVar16 = 8;
        }
        if ((uVar16 & uVar26 >> 0x14) != 0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar17) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_98h + iVar17) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_a0h + iVar17) = unaff_RDI;
    if (((uVar26 >> 0x19 & 1) == 0) && (ppuVar22[1] != (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e222e;
        iVar14 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != 2) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e223c;
            iVar14 = func_0x00018026bea0(in_RCX + 0xd);
            if (iVar14 != 0x17) goto code_r0x0001801e22b1;
        }
        iVar18 = in_RCX[0xa0][1];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2254;
        iVar14 = func_0x00018026bea0(iVar18);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e225f;
        iVar15 = func_0x00018026bea0(in_RCX + 0xd);
        if (iVar14 != iVar15) {
            return;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e226f;
        iVar14 = func_0x00018026bea0(iVar18);
        if (iVar14 == 2) {
            bVar29 = *(int32_t *)(iVar18 + 4) == *(int32_t *)((int64_t)in_RCX + 0x6c);
        } else {
            if (iVar14 != 0x17) {
                return;
            }
            if (*(int64_t **)(iVar18 + 8) != in_RCX[0xe]) {
                return;
            }
            bVar29 = *(int64_t **)(iVar18 + 0x10) == in_RCX[0xf];
        }
        if (!bVar29) {
            return;
        }
        if (*(int16_t *)(iVar18 + 2) != *(int16_t *)((int64_t)in_RCX + 0x6a)) {
            return;
        }
    }
code_r0x0001801e22b1:
    uVar26 = *(uint32_t *)(in_RCX + 0xba);
    if (((uVar26 & 0x2000008) == 8) && (pcVar7 = (char *)*in_RCX[0xa0], *pcVar7 != '\x05')) {
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e22e3;
        iVar14 = func_0x0001801e55b0(pcVar7 + 0x1d, (int64_t)in_RCX + 0x452);
        if (iVar14 == 0) {
            return;
        }
    }
    ppuVar22 = (uint32_t **)in_RCX[0xa0];
    puVar6 = *ppuVar22;
    uVar16 = *puVar6 & 0xff;
    if (uVar16 == 5) {
code_r0x0001801e2600:
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar26 = **ppuVar22;
        uVar16 = uVar26 & 0xff;
        if (((uVar16 == 4) || (uVar16 == 6)) || ((uVar26 & 0x300000) == 0)) {
            var_68h = *(int64_t *)(*ppuVar22 + 0x14);
            var_60h = *(int64_t *)(*ppuVar22 + 0x12);
            puVar6 = ppuVar22[8];
            puVar8 = ppuVar22[4];
            puVar9 = *ppuVar22;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2776;
            uVar25 = fcn.1801deee0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                   *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&iStackX_20 + iVar17)
                                   , *(int64_t *)(&stack0x00000028 + iVar17), *(int64_t *)(&stack0x00000030 + iVar17), 
                                   *(int64_t *)(&stack0x00000040 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17));
            *(uint32_t **)((int64_t)&var_8h + iVar17) = puVar6;
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = 1;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2796;
            func_0x000180204f00(uVar25, puVar9, puVar8, &var_68h);
            puVar6 = (uint32_t *)*in_RCX[0xa0];
    // switch table (6 cases) at 0x1801e2cfc
            switch(*puVar6 & 0xff) {
            case 1:
            case 3:
            case 5:
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) && ((*puVar6 & 0xff) == 3)) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e297d;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 2) != 0) &&
                    (ppcVar10 = (char **)in_RCX[0xa0], **ppcVar10 == '\x05')) && (in_RCX[0xb9] <= ppcVar10[4])) {
                    pcVar7 = ppcVar10[7];
                    piVar20 = in_RCX[0x7b];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29c2;
                    pcVar21 = (char *)func_0x000180205200(piVar20);
                    if (pcVar7 < pcVar21) {
                        var_38h = 0;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e29d9;
                        iVar18 = func_0x0001801fca50(0xe);
                        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                            return;
                        }
                        uVar25 = 0x1805aadb1;
                        iVar24 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            iVar24 = iVar18;
                        }
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a00;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a18;
                        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                        uVar19 = 0x1805aadb1;
                        if (iVar18 != 0) {
                            uVar19 = 0x1805ab2bc;
                        }
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7120;
                        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                        if (iVar18 != 0) {
                            uVar25 = 0x1805ab2cc;
                        }
                        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a6b;
                        func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 0xe);
                        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a83;
                        func_0x0001802295a0(0x1804b6360, 0xa35, 0x1804b7090);
                        piVar20 = in_RCX[0xbb];
                        if (piVar20 == (int64_t *)0x0) {
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2a94;
                            piVar20 = (int64_t *)func_0x0001802542f0();
                            in_RCX[0xbb] = piVar20;
                            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2aa0;
                        } else {
code_r0x0001801e2aa0:
                            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2aa8;
                            func_0x000180254600(piVar20);
                        }
                        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                        uVar25 = 0;
                        var_58h = 0xe;
                        var_48h = 0x1804b7120;
                        var_40h = 0x18;
                        break;
                    }
                }
                if ((((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) || (*(char *)*in_RCX[0xa0] != '\x01')) ||
                   (*(int64_t *)((char *)*in_RCX[0xa0] + 0x40) == 0)) {
                    piVar20 = in_RCX[0xa0];
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c12;
                    func_0x0001802004d0(in_RCX, piVar20);
                    if ((*(uint32_t *)(in_RCX + 0xba) & 0x10000000) == 0) {
                        return;
                    }
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2c31;
                    func_0x0001801e2eb0(in_RCX, in_RDX & 0xffffffff, 0);
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b0c;
                iVar18 = func_0x0001801fca50(10);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = 0x1805aadb1;
                if (iVar18 != 0) {
                    iVar24 = iVar18;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b33;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b4b;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7140;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2b9e;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bb6;
                func_0x0001802295a0(0x1804b6360, 0xa4e, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bc7;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e2bd3;
                } else {
code_r0x0001801e2bd3:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2bdb;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 10;
                var_48h = 0x1804b7140;
                var_40h = 0x1d;
                break;
            default:
                goto code_r0x0001801e2ceb;
            case 4:
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000800) != 0) {
                    return;
                }
                if ((*(uint32_t *)(in_RCX + 0xba) & 8) != 0) {
                    return;
                }
                if (*(uint64_t *)(puVar6 + 0x12) < 0x11) {
                    return;
                }
                uVar25 = ((undefined8 *)**in_RCX)[1];
                uVar19 = *(undefined8 *)**in_RCX;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2809;
                iVar14 = func_0x0001801f8c80(uVar19, uVar25, puVar6, in_RCX + 0x85);
                if (iVar14 == 0) {
                    return;
                }
                *(uint32_t *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar28;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2838;
                iVar14 = fcn.1801e1af0(*(int64_t *)((int64_t)&iStackX_20 + iVar17 + -0x20), 
                                       *(int64_t *)((int64_t)&var_8h + iVar17), *(int64_t *)((int64_t)&var_10h + iVar17)
                                       , *(int64_t *)((int64_t)&iStackX_20 + iVar17 + -8), 
                                       *(int64_t *)((int64_t)&iStackX_20 + iVar17), 
                                       *(int64_t *)(&stack0x00000030 + iVar17), *(int64_t *)(&stack0x00000050 + iVar17)
                                       , *(int64_t *)(&stack0x00000070 + iVar17));
                if (iVar14 != 0) {
                    return;
                }
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e284e;
                iVar18 = func_0x0001801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2885;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e289d;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b7108;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e28f3;
                func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e290b;
                func_0x0001802295a0(0x1804b6360, 0xa0f, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e291f;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e292e;
                } else {
code_r0x0001801e292e:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2936;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_58h = 1;
                var_48h = 0x1804b7108;
                var_40h = 0x15;
                break;
            case 6:
                if (uVar28 != 0) {
                    return;
                }
                uVar27 = *(uint64_t *)(puVar6 + 0x12);
                if (0x7fffffffffffffff < uVar27) {
                    return;
                }
                puVar23 = *(undefined **)(puVar6 + 0x14);
                while ((uVar27 != 0 && (3 < uVar27))) {
                    uVar5 = *puVar23;
                    uVar27 = uVar27 - 4;
                    puVar1 = puVar23 + 1;
                    puVar2 = puVar23 + 2;
                    puVar3 = puVar23 + 3;
                    puVar23 = puVar23 + 4;
                    if (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) == 1) {
                        return;
                    }
                }
                var_48h = 0x1804b7160;
                uVar25 = 1;
                var_38h = 0;
                var_40h = 0x1b;
code_r0x0001801e2cb7:
                var_58h = 2;
            }
        } else {
            var_38h = 0;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e263e;
            iVar18 = func_0x0001801fca50(10);
            if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                return;
            }
            uVar25 = 0x1805aadb1;
            iVar24 = iVar18;
            if (iVar18 == 0) {
                iVar24 = 0x1805aadb1;
            }
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2675;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e268d;
            func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
            uVar19 = 0x1805aadb1;
            if (iVar18 != 0) {
                uVar19 = 0x1805ab2bc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70e8;
            *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
            *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
            if (iVar18 != 0) {
                uVar25 = 0x1805ab2cc;
            }
            *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26e3;
            func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 10);
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e26fb;
            func_0x0001802295a0(0x1804b6360, 0x9db, 0x1804b7090);
            piVar20 = in_RCX[0xbb];
            if (piVar20 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e270f;
                piVar20 = (int64_t *)func_0x0001802542f0();
                in_RCX[0xbb] = piVar20;
                if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e271e;
            } else {
code_r0x0001801e271e:
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2726;
                func_0x000180254600(piVar20);
            }
            *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
            uVar25 = 0;
            var_58h = 10;
            var_48h = 0x1804b70e8;
            var_40h = 0x1b;
        }
    } else {
        if (uVar16 != 6) {
            if (puVar6[1] != 1) {
                return;
            }
            if (uVar16 != 6) goto code_r0x0001801e2600;
        }
        if (puVar6[1] != 0) {
            return;
        }
        if (uVar28 != 0) {
            return;
        }
        *(uint32_t *)(in_RCX + 0xba) = uVar26 | 0x10;
        uVar27 = *(uint64_t *)(*ppuVar22 + 0x12);
        if (0x7fffffffffffffff < uVar27) {
            return;
        }
        puVar23 = *(undefined **)(*ppuVar22 + 0x14);
        do {
            if (uVar27 == 0) {
                var_38h = 0;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23ac;
                iVar18 = func_0x0001801fca50(2);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
                    return;
                }
                uVar25 = 0x1805aadb1;
                iVar24 = iVar18;
                if (iVar18 == 0) {
                    iVar24 = 0x1805aadb1;
                }
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23e3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e23fb;
                func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
                uVar19 = 0x1805aadb1;
                if (iVar18 != 0) {
                    uVar19 = 0x1805ab2bc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70c8;
                *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
                *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
                if (iVar18 != 0) {
                    uVar25 = 0x1805ab2cc;
                }
                *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2451;
                func_0x0001802296d0(0x14, 0x17e, 0x1804b73f8, 2);
                *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2469;
                func_0x0001802295a0(0x1804b6360, 0x9cd, 0x1804b7090);
                piVar20 = in_RCX[0xbb];
                if (piVar20 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e247d;
                    piVar20 = (int64_t *)func_0x0001802542f0();
                    in_RCX[0xbb] = piVar20;
                    if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e248c;
                } else {
code_r0x0001801e248c:
                    *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2494;
                    func_0x000180254600(piVar20);
                }
                *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                uVar25 = 0;
                var_48h = 0x1804b70c8;
                var_40h = 0x1c;
                goto code_r0x0001801e2cb7;
            }
            if (uVar27 < 4) {
                return;
            }
            uVar5 = *puVar23;
            uVar27 = uVar27 - 4;
            puVar1 = puVar23 + 1;
            puVar2 = puVar23 + 2;
            puVar3 = puVar23 + 3;
            puVar23 = puVar23 + 4;
        } while (CONCAT31(CONCAT21(CONCAT11(uVar5, *puVar1), *puVar2), *puVar3) != 1);
        piVar20 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24c7;
        func_0x0001802081e0(piVar20, 1);
        piVar20 = in_RCX[0x79];
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24d8;
        iVar14 = func_0x0001802029e0(piVar20, 0, 0);
        if (iVar14 != 0) {
            return;
        }
        var_38h = 0;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e24ee;
        iVar18 = func_0x0001801fca50(1);
        if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) != 0) {
            return;
        }
        uVar25 = 0x1805aadb1;
        iVar24 = iVar18;
        if (iVar18 == 0) {
            iVar24 = 0x1805aadb1;
        }
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2525;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e253d;
        func_0x0001802295a0(0x1804b6360, 0xe0a, 0x1804b7368);
        uVar19 = 0x1805aadb1;
        if (iVar18 != 0) {
            uVar19 = 0x1805ab2bc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -8) = 0x1804b70a8;
        *(undefined8 *)((int64_t)&var_10h + iVar17) = uVar19;
        *(int64_t *)((int64_t)&var_8h + iVar17) = iVar24;
        if (iVar18 != 0) {
            uVar25 = 0x1805ab2cc;
        }
        *(undefined8 *)((int64_t)&iStackX_20 + iVar17 + -0x20) = uVar25;
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e2593;
        func_0x0001802296d0(0x14, 0xc0103, 0x1804b73f8, 1);
        *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25ab;
        func_0x0001802295a0(0x1804b6360, 0x9c3, 0x1804b7090);
        piVar20 = in_RCX[0xbb];
        if (piVar20 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25bf;
            piVar20 = (int64_t *)func_0x0001802542f0();
            in_RCX[0xbb] = piVar20;
            if (piVar20 != (int64_t *)0x0) goto code_r0x0001801e25ce;
        } else {
code_r0x0001801e25ce:
            *(undefined8 *)((int64_t)&pcStack_28 + iVar17) = 0x1801e25d6;
            func_0x000180254600(piVar20);
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
        uVar25 = 0;
        var_58h = 1;
        var_48h = 0x1804b70a8;
        var_40h = 0x1f;
    }
    var_50h = 0;
    *(code **)((int64_t)&pcStack_28 + iVar17) = case.0x1801e27c6.2;
    func_0x0001801e2d20(in_RCX, &var_58h, uVar25);
code_r0x0001801e2ceb:
    return;
}

// ============================================================
// Function: FUN_1801e2d20
// Address: 0x1801e2d20
// Size: 388 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.1801e2d20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    int64_t in_RDX;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e2d3b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(uint32_t *)(in_RCX + 0xba) & 0x20) == 0) {
        in_R8D = 1;
    }
    uVar2 = *(uint32_t *)(in_RCX + 0xba) & 7;
    if (uVar2 != 0) {
        if (uVar2 == 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2dbe;
            func_0x0001801e3550(in_RCX + 0xae);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2dc6;
            uVar4 = fcn.1801deee0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                                  *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2dd1;
            func_0x0001802049c0(uVar4, in_RDX);
            if (in_R8D == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2deb;
                fcn.1801e1a70(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                uVar4 = in_RCX[0x79];
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2df7;
                uVar5 = func_0x000180202870(uVar4);
                iVar7 = -1;
                uVar8 = 0xffffffffffffffff;
                if (uVar5 < 0x5555555555555556) {
                    uVar8 = uVar5 * 3;
                }
                uVar4 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2e1c;
                iVar6 = func_0x0001801e8e50(uVar4);
                if (uVar8 <= -iVar6 - 1U) {
                    iVar7 = iVar6 + uVar8;
                }
                uVar2 = *(uint32_t *)(in_RCX + 0xb2);
                in_RCX[0xb3] = iVar7;
                if ((uVar2 & 2) != 0) {
                    return;
                }
                *(undefined8 *)((int64_t)&var_20h + iVar3) = in_RCX[0xae];
                uVar4 = in_RCX[0xaf];
                *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar4;
                uVar4 = in_RCX[0x11];
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = in_RCX[0xb0];
                uVar1 = in_RCX[0xb1];
                *(uint32_t *)((int64_t)&var_18h + iVar3) = uVar2 & 1;
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = uVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2e95;
                func_0x000180207f00(uVar4, (int64_t)&var_18h + iVar3);
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x1000000;
                return;
            }
            goto code_r0x0001801e2d7d;
        }
        if (uVar2 == 2) {
            if ((in_R8D == 0) && ((*(uint8_t *)(in_RDX + 0x20) & 2) == 0)) {
                return;
            }
            goto code_r0x0001801e2d7d;
        }
        if (uVar2 == 3) {
            if (in_R8D == 0) {
                return;
            }
            goto code_r0x0001801e2d7d;
        }
        if (uVar2 == 4) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2d78;
    func_0x0001801e3550(in_RCX + 0xae);
code_r0x0001801e2d7d:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2d85;
    fcn.1801e1a70(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801e2eb0
// Address: 0x1801e2eb0
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801e2eb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 *in_R8;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e2ec0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_70h + iVar3) = 0;
    if (in_EDX == 0) {
        *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) | 0x8000000;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2eed;
        fcn.1801a62c0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2f05;
        iVar2 = fcn.1801a60b0(uVar1, (int64_t)&arg_40h + iVar3, (int64_t)&arg_38h + iVar3, (int64_t)&arg_70h + iVar3);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0x1804b7050;
            *(undefined4 *)((int64_t)&arg_28h + iVar3) = 0x8b4;
            *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804b6360;
            *(undefined8 *)((int64_t)&var_18h + iVar3) = *(undefined8 *)((int64_t)&arg_70h + iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e2f48;
            fcn.1801e4990(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)(&stack0x00000098 + iVar3), *(int64_t *)(&stack0x000000a0 + iVar3), 
                          *(int64_t *)(&stack0x000000a8 + iVar3), *(int64_t *)(&stack0x000000b8 + iVar3), 
                          *(int64_t *)(&stack0x000000c0 + iVar3), *(int64_t *)(&stack0x000000c8 + iVar3), 
                          *(int64_t *)(&stack0x000000d0 + iVar3), *(int64_t *)(&stack0x00000178 + iVar3));
            if (in_R8 != (undefined4 *)0x0) {
                *in_R8 = 1;
            }
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801e2f70
// Address: 0x1801e2f70
// Size: 171 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e2f70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801e2f80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e2f97;
    uVar3 = fcn.180207c20(uVar8, 2);
    if (uVar3 < 0x4000000000000000) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e2fb5;
        iVar1 = fcn.1801fb940(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2), 
                              *(int64_t *)((int64_t)&arg_58h + iVar2), *(int64_t *)((int64_t)&arg_78h + iVar2), 
                              *(int64_t *)(&stack0x000000b8 + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2), 
                              *(int64_t *)(&stack0x000000f8 + iVar2), *(int64_t *)(&stack0x00000100 + iVar2));
        if (iVar1 != 0) {
            uVar6 = *(uint32_t *)(in_RCX + 0x5d4) | 1;
            *(uint64_t *)(in_RCX + 0x5c0) = uVar3;
            *(uint32_t *)(in_RCX + 0x5d4) = (*(uint32_t *)(in_RCX + 0x5d0) >> 0x1b ^ uVar6) & 0x10 ^ uVar6;
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3008;
    iVar4 = fcn.1801fca50(1);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar2) = unaff_RDI;
    uVar8 = 0x1805aadb1;
    iVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar7 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3036;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e304e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    uVar5 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar5 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0x1804b6388;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = uVar5;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_20h + iVar2) = iVar7;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = uVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30a1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30b9;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30d2;
        iVar4 = fcn.1802542f0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2));
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801e30e6;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30e6;
    fcn.180254600(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
code_r0x0001801e30e6:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 1;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0x1804b6388;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 10;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e311d;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                  *(int64_t *)((int64_t)&arg_50h + iVar2), *(int64_t *)((int64_t)&arg_58h + iVar2));
    return;
}

// ============================================================
// Function: FUN_1801e301b
// Address: 0x1801e301b
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e2f70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801e2f80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e2f97;
    uVar3 = fcn.180207c20(uVar8, 2);
    if (uVar3 < 0x4000000000000000) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e2fb5;
        iVar1 = fcn.1801fb940(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2), 
                              *(int64_t *)((int64_t)&arg_58h + iVar2), *(int64_t *)((int64_t)&arg_78h + iVar2), 
                              *(int64_t *)(&stack0x000000b8 + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2), 
                              *(int64_t *)(&stack0x000000f8 + iVar2), *(int64_t *)(&stack0x00000100 + iVar2));
        if (iVar1 != 0) {
            uVar6 = *(uint32_t *)(in_RCX + 0x5d4) | 1;
            *(uint64_t *)(in_RCX + 0x5c0) = uVar3;
            *(uint32_t *)(in_RCX + 0x5d4) = (*(uint32_t *)(in_RCX + 0x5d0) >> 0x1b ^ uVar6) & 0x10 ^ uVar6;
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3008;
    iVar4 = fcn.1801fca50(1);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar2) = unaff_RDI;
    uVar8 = 0x1805aadb1;
    iVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar7 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3036;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e304e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    uVar5 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar5 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0x1804b6388;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = uVar5;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_20h + iVar2) = iVar7;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = uVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30a1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30b9;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30d2;
        iVar4 = fcn.1802542f0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2));
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801e30e6;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30e6;
    fcn.180254600(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
code_r0x0001801e30e6:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 1;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0x1804b6388;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 10;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e311d;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                  *(int64_t *)((int64_t)&arg_50h + iVar2), *(int64_t *)((int64_t)&arg_58h + iVar2));
    return;
}

// ============================================================
// Function: FUN_1801e30cd
// Address: 0x1801e30cd
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e2f70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801e2f80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar8 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e2f97;
    uVar3 = fcn.180207c20(uVar8, 2);
    if (uVar3 < 0x4000000000000000) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e2fb5;
        iVar1 = fcn.1801fb940(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2), 
                              *(int64_t *)((int64_t)&arg_58h + iVar2), *(int64_t *)((int64_t)&arg_78h + iVar2), 
                              *(int64_t *)(&stack0x000000b8 + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2), 
                              *(int64_t *)(&stack0x000000f8 + iVar2), *(int64_t *)(&stack0x00000100 + iVar2));
        if (iVar1 != 0) {
            uVar6 = *(uint32_t *)(in_RCX + 0x5d4) | 1;
            *(uint64_t *)(in_RCX + 0x5c0) = uVar3;
            *(uint32_t *)(in_RCX + 0x5d4) = (*(uint32_t *)(in_RCX + 0x5d0) >> 0x1b ^ uVar6) & 0x10 ^ uVar6;
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3008;
    iVar4 = fcn.1801fca50(1);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) {
        return;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar2) = unaff_RDI;
    uVar8 = 0x1805aadb1;
    iVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        iVar7 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3036;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e304e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    uVar5 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar5 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0x1804b6388;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = uVar5;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
    }
    *(int64_t *)((int64_t)&var_20h + iVar2) = iVar7;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = uVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30a1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30b9;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2));
    if (*(int64_t *)(in_RCX + 0x5d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30d2;
        iVar4 = fcn.1802542f0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2));
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 == 0) goto code_r0x0001801e30e6;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e30e6;
    fcn.180254600(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
code_r0x0001801e30e6:
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 1;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0x1804b6388;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 10;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e311d;
    fcn.1801e2d20(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                  *(int64_t *)((int64_t)&arg_50h + iVar2), *(int64_t *)((int64_t)&arg_58h + iVar2));
    return;
}

// ============================================================
// Function: FUN_1801e3140
// Address: 0x1801e3140
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch

void fcn.1801e3140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a0h, int64_t arg_a8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801e314e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_10h + iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0xba);
    if ((uVar1 & 7) != 3) {
        if ((uVar1 & 7) == 2) {
            if ((uVar1 >> 0x18 & 1) == 0) goto code_r0x0001801e3443;
            *(uint32_t *)(in_RCX + 0xba) = uVar1 & 0xfeffffff;
        }
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31a3;
        iVar2 = func_0x0001801e5890(in_RCX);
        if (iVar2 != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31af;
            uVar4 = func_0x0001801e8e50(iVar8);
            if ((((uint64_t)in_RCX[0xb6] < uVar4) || ((uint64_t)in_RCX[0xb6] <= uVar4)) &&
               ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 6) == 0)) {
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31d4;
                uVar5 = func_0x0001801fb740(iVar8, 3);
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31e8;
                uVar6 = func_0x0001801fb780(iVar8, 3);
                uVar4 = in_RCX[0xad];
                if (in_RCX[0xad] == 0xffffffffffffffff) {
                    uVar4 = uVar6 >> 1;
                }
                if (uVar4 <= uVar5) {
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x80000000;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3211;
                    fcn.1801e2f70(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffff7;
        do {
            iVar8 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3231;
            iVar2 = func_0x000180207410(iVar8, (int64_t)&arg_58h + iVar3);
            iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            if (iVar8 != 0) {
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20;
                *(uint32_t *)(*in_RCX + 0x9c) = *(uint32_t *)(*in_RCX + 0x9c) | 8;
                if ((*(int32_t *)((int64_t)&arg_58h + iVar3) != 0) && ((*(uint32_t *)(in_RCX + 0xba) & 0x20000000) == 0)
                   ) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3269;
                    func_0x0001801e3460(in_RCX);
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20000000;
                }
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) &&
                   (*(int32_t *)((int64_t)&arg_58h + iVar3 + 4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3290;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 8) != 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffb;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32ab;
                func_0x0001801e34d0(in_RCX);
                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            }
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32dd;
                iVar8 = fcn.1801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = unaff_RSI;
                    uVar9 = 0x1805aadb1;
                    iVar10 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        iVar10 = iVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e330b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3323;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    uVar7 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        uVar7 = 0x1805ab2bc;
                    }
                    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar7;
                    if (iVar8 != 0) {
                        uVar9 = 0x1805ab2cc;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar3) = uVar9;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3376;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e338e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    if (in_RCX[0xbb] == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33a7;
                        iVar8 = fcn.1802542f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                        in_RCX[0xbb] = iVar8;
                        if (iVar8 != 0) goto code_r0x0001801e33b3;
                    } else {
code_r0x0001801e33b3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33bb;
                        fcn.180254600(*(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
                    }
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1d;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33f2;
                    fcn.1801e2d20(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3));
                }
                break;
            }
        } while (iVar8 != 0);
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3406;
        iVar2 = func_0x0001801fb440(iVar8);
        if ((iVar2 + 1U & 0xfffffffd) != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3422;
            func_0x0001801e8f60(iVar8, in_RCX);
        }
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e342e;
        iVar8 = func_0x0001801fb7d0(iVar8);
        if (iVar8 != 0) {
            *in_RDX = 1;
        }
    }
code_r0x0001801e3443:
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3450;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (int64_t)&var_10h + iVar3);
    return;
}

// ============================================================
// Function: FUN_1801e3196
// Address: 0x1801e3196
// Size: 305 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch

void fcn.1801e3140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a0h, int64_t arg_a8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801e314e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_10h + iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0xba);
    if ((uVar1 & 7) != 3) {
        if ((uVar1 & 7) == 2) {
            if ((uVar1 >> 0x18 & 1) == 0) goto code_r0x0001801e3443;
            *(uint32_t *)(in_RCX + 0xba) = uVar1 & 0xfeffffff;
        }
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31a3;
        iVar2 = func_0x0001801e5890(in_RCX);
        if (iVar2 != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31af;
            uVar4 = func_0x0001801e8e50(iVar8);
            if ((((uint64_t)in_RCX[0xb6] < uVar4) || ((uint64_t)in_RCX[0xb6] <= uVar4)) &&
               ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 6) == 0)) {
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31d4;
                uVar5 = func_0x0001801fb740(iVar8, 3);
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31e8;
                uVar6 = func_0x0001801fb780(iVar8, 3);
                uVar4 = in_RCX[0xad];
                if (in_RCX[0xad] == 0xffffffffffffffff) {
                    uVar4 = uVar6 >> 1;
                }
                if (uVar4 <= uVar5) {
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x80000000;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3211;
                    fcn.1801e2f70(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffff7;
        do {
            iVar8 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3231;
            iVar2 = func_0x000180207410(iVar8, (int64_t)&arg_58h + iVar3);
            iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            if (iVar8 != 0) {
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20;
                *(uint32_t *)(*in_RCX + 0x9c) = *(uint32_t *)(*in_RCX + 0x9c) | 8;
                if ((*(int32_t *)((int64_t)&arg_58h + iVar3) != 0) && ((*(uint32_t *)(in_RCX + 0xba) & 0x20000000) == 0)
                   ) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3269;
                    func_0x0001801e3460(in_RCX);
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20000000;
                }
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) &&
                   (*(int32_t *)((int64_t)&arg_58h + iVar3 + 4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3290;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 8) != 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffb;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32ab;
                func_0x0001801e34d0(in_RCX);
                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            }
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32dd;
                iVar8 = fcn.1801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = unaff_RSI;
                    uVar9 = 0x1805aadb1;
                    iVar10 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        iVar10 = iVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e330b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3323;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    uVar7 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        uVar7 = 0x1805ab2bc;
                    }
                    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar7;
                    if (iVar8 != 0) {
                        uVar9 = 0x1805ab2cc;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar3) = uVar9;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3376;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e338e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    if (in_RCX[0xbb] == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33a7;
                        iVar8 = fcn.1802542f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                        in_RCX[0xbb] = iVar8;
                        if (iVar8 != 0) goto code_r0x0001801e33b3;
                    } else {
code_r0x0001801e33b3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33bb;
                        fcn.180254600(*(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
                    }
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1d;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33f2;
                    fcn.1801e2d20(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3));
                }
                break;
            }
        } while (iVar8 != 0);
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3406;
        iVar2 = func_0x0001801fb440(iVar8);
        if ((iVar2 + 1U & 0xfffffffd) != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3422;
            func_0x0001801e8f60(iVar8, in_RCX);
        }
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e342e;
        iVar8 = func_0x0001801fb7d0(iVar8);
        if (iVar8 != 0) {
            *in_RDX = 1;
        }
    }
code_r0x0001801e3443:
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3450;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (int64_t)&var_10h + iVar3);
    return;
}

// ============================================================
// Function: FUN_1801e32c7
// Address: 0x1801e32c7
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch

void fcn.1801e3140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a0h, int64_t arg_a8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801e314e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_10h + iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0xba);
    if ((uVar1 & 7) != 3) {
        if ((uVar1 & 7) == 2) {
            if ((uVar1 >> 0x18 & 1) == 0) goto code_r0x0001801e3443;
            *(uint32_t *)(in_RCX + 0xba) = uVar1 & 0xfeffffff;
        }
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31a3;
        iVar2 = func_0x0001801e5890(in_RCX);
        if (iVar2 != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31af;
            uVar4 = func_0x0001801e8e50(iVar8);
            if ((((uint64_t)in_RCX[0xb6] < uVar4) || ((uint64_t)in_RCX[0xb6] <= uVar4)) &&
               ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 6) == 0)) {
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31d4;
                uVar5 = func_0x0001801fb740(iVar8, 3);
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31e8;
                uVar6 = func_0x0001801fb780(iVar8, 3);
                uVar4 = in_RCX[0xad];
                if (in_RCX[0xad] == 0xffffffffffffffff) {
                    uVar4 = uVar6 >> 1;
                }
                if (uVar4 <= uVar5) {
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x80000000;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3211;
                    fcn.1801e2f70(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffff7;
        do {
            iVar8 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3231;
            iVar2 = func_0x000180207410(iVar8, (int64_t)&arg_58h + iVar3);
            iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            if (iVar8 != 0) {
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20;
                *(uint32_t *)(*in_RCX + 0x9c) = *(uint32_t *)(*in_RCX + 0x9c) | 8;
                if ((*(int32_t *)((int64_t)&arg_58h + iVar3) != 0) && ((*(uint32_t *)(in_RCX + 0xba) & 0x20000000) == 0)
                   ) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3269;
                    func_0x0001801e3460(in_RCX);
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20000000;
                }
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) &&
                   (*(int32_t *)((int64_t)&arg_58h + iVar3 + 4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3290;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 8) != 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffb;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32ab;
                func_0x0001801e34d0(in_RCX);
                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            }
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32dd;
                iVar8 = fcn.1801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = unaff_RSI;
                    uVar9 = 0x1805aadb1;
                    iVar10 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        iVar10 = iVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e330b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3323;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    uVar7 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        uVar7 = 0x1805ab2bc;
                    }
                    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar7;
                    if (iVar8 != 0) {
                        uVar9 = 0x1805ab2cc;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar3) = uVar9;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3376;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e338e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    if (in_RCX[0xbb] == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33a7;
                        iVar8 = fcn.1802542f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                        in_RCX[0xbb] = iVar8;
                        if (iVar8 != 0) goto code_r0x0001801e33b3;
                    } else {
code_r0x0001801e33b3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33bb;
                        fcn.180254600(*(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
                    }
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1d;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33f2;
                    fcn.1801e2d20(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3));
                }
                break;
            }
        } while (iVar8 != 0);
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3406;
        iVar2 = func_0x0001801fb440(iVar8);
        if ((iVar2 + 1U & 0xfffffffd) != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3422;
            func_0x0001801e8f60(iVar8, in_RCX);
        }
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e342e;
        iVar8 = func_0x0001801fb7d0(iVar8);
        if (iVar8 != 0) {
            *in_RDX = 1;
        }
    }
code_r0x0001801e3443:
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3450;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (int64_t)&var_10h + iVar3);
    return;
}

// ============================================================
// Function: FUN_1801e32f0
// Address: 0x1801e32f0
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch

void fcn.1801e3140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a0h, int64_t arg_a8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801e314e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_10h + iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0xba);
    if ((uVar1 & 7) != 3) {
        if ((uVar1 & 7) == 2) {
            if ((uVar1 >> 0x18 & 1) == 0) goto code_r0x0001801e3443;
            *(uint32_t *)(in_RCX + 0xba) = uVar1 & 0xfeffffff;
        }
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31a3;
        iVar2 = func_0x0001801e5890(in_RCX);
        if (iVar2 != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31af;
            uVar4 = func_0x0001801e8e50(iVar8);
            if ((((uint64_t)in_RCX[0xb6] < uVar4) || ((uint64_t)in_RCX[0xb6] <= uVar4)) &&
               ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 6) == 0)) {
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31d4;
                uVar5 = func_0x0001801fb740(iVar8, 3);
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31e8;
                uVar6 = func_0x0001801fb780(iVar8, 3);
                uVar4 = in_RCX[0xad];
                if (in_RCX[0xad] == 0xffffffffffffffff) {
                    uVar4 = uVar6 >> 1;
                }
                if (uVar4 <= uVar5) {
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x80000000;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3211;
                    fcn.1801e2f70(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffff7;
        do {
            iVar8 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3231;
            iVar2 = func_0x000180207410(iVar8, (int64_t)&arg_58h + iVar3);
            iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            if (iVar8 != 0) {
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20;
                *(uint32_t *)(*in_RCX + 0x9c) = *(uint32_t *)(*in_RCX + 0x9c) | 8;
                if ((*(int32_t *)((int64_t)&arg_58h + iVar3) != 0) && ((*(uint32_t *)(in_RCX + 0xba) & 0x20000000) == 0)
                   ) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3269;
                    func_0x0001801e3460(in_RCX);
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20000000;
                }
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) &&
                   (*(int32_t *)((int64_t)&arg_58h + iVar3 + 4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3290;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 8) != 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffb;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32ab;
                func_0x0001801e34d0(in_RCX);
                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            }
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32dd;
                iVar8 = fcn.1801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = unaff_RSI;
                    uVar9 = 0x1805aadb1;
                    iVar10 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        iVar10 = iVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e330b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3323;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    uVar7 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        uVar7 = 0x1805ab2bc;
                    }
                    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar7;
                    if (iVar8 != 0) {
                        uVar9 = 0x1805ab2cc;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar3) = uVar9;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3376;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e338e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    if (in_RCX[0xbb] == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33a7;
                        iVar8 = fcn.1802542f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                        in_RCX[0xbb] = iVar8;
                        if (iVar8 != 0) goto code_r0x0001801e33b3;
                    } else {
code_r0x0001801e33b3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33bb;
                        fcn.180254600(*(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
                    }
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1d;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33f2;
                    fcn.1801e2d20(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3));
                }
                break;
            }
        } while (iVar8 != 0);
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3406;
        iVar2 = func_0x0001801fb440(iVar8);
        if ((iVar2 + 1U & 0xfffffffd) != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3422;
            func_0x0001801e8f60(iVar8, in_RCX);
        }
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e342e;
        iVar8 = func_0x0001801fb7d0(iVar8);
        if (iVar8 != 0) {
            *in_RDX = 1;
        }
    }
code_r0x0001801e3443:
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3450;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (int64_t)&var_10h + iVar3);
    return;
}

// ============================================================
// Function: FUN_1801e33a2
// Address: 0x1801e33a2
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch

void fcn.1801e3140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a0h, int64_t arg_a8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801e314e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_10h + iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0xba);
    if ((uVar1 & 7) != 3) {
        if ((uVar1 & 7) == 2) {
            if ((uVar1 >> 0x18 & 1) == 0) goto code_r0x0001801e3443;
            *(uint32_t *)(in_RCX + 0xba) = uVar1 & 0xfeffffff;
        }
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31a3;
        iVar2 = func_0x0001801e5890(in_RCX);
        if (iVar2 != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31af;
            uVar4 = func_0x0001801e8e50(iVar8);
            if ((((uint64_t)in_RCX[0xb6] < uVar4) || ((uint64_t)in_RCX[0xb6] <= uVar4)) &&
               ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 6) == 0)) {
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31d4;
                uVar5 = func_0x0001801fb740(iVar8, 3);
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31e8;
                uVar6 = func_0x0001801fb780(iVar8, 3);
                uVar4 = in_RCX[0xad];
                if (in_RCX[0xad] == 0xffffffffffffffff) {
                    uVar4 = uVar6 >> 1;
                }
                if (uVar4 <= uVar5) {
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x80000000;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3211;
                    fcn.1801e2f70(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffff7;
        do {
            iVar8 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3231;
            iVar2 = func_0x000180207410(iVar8, (int64_t)&arg_58h + iVar3);
            iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            if (iVar8 != 0) {
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20;
                *(uint32_t *)(*in_RCX + 0x9c) = *(uint32_t *)(*in_RCX + 0x9c) | 8;
                if ((*(int32_t *)((int64_t)&arg_58h + iVar3) != 0) && ((*(uint32_t *)(in_RCX + 0xba) & 0x20000000) == 0)
                   ) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3269;
                    func_0x0001801e3460(in_RCX);
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20000000;
                }
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) &&
                   (*(int32_t *)((int64_t)&arg_58h + iVar3 + 4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3290;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 8) != 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffb;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32ab;
                func_0x0001801e34d0(in_RCX);
                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            }
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32dd;
                iVar8 = fcn.1801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = unaff_RSI;
                    uVar9 = 0x1805aadb1;
                    iVar10 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        iVar10 = iVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e330b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3323;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    uVar7 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        uVar7 = 0x1805ab2bc;
                    }
                    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar7;
                    if (iVar8 != 0) {
                        uVar9 = 0x1805ab2cc;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar3) = uVar9;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3376;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e338e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    if (in_RCX[0xbb] == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33a7;
                        iVar8 = fcn.1802542f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                        in_RCX[0xbb] = iVar8;
                        if (iVar8 != 0) goto code_r0x0001801e33b3;
                    } else {
code_r0x0001801e33b3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33bb;
                        fcn.180254600(*(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
                    }
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1d;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33f2;
                    fcn.1801e2d20(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3));
                }
                break;
            }
        } while (iVar8 != 0);
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3406;
        iVar2 = func_0x0001801fb440(iVar8);
        if ((iVar2 + 1U & 0xfffffffd) != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3422;
            func_0x0001801e8f60(iVar8, in_RCX);
        }
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e342e;
        iVar8 = func_0x0001801fb7d0(iVar8);
        if (iVar8 != 0) {
            *in_RDX = 1;
        }
    }
code_r0x0001801e3443:
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3450;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (int64_t)&var_10h + iVar3);
    return;
}

// ============================================================
// Function: FUN_1801e33fa
// Address: 0x1801e33fa
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch

void fcn.1801e3140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a0h, int64_t arg_a8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801e314e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_10h + iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0xba);
    if ((uVar1 & 7) != 3) {
        if ((uVar1 & 7) == 2) {
            if ((uVar1 >> 0x18 & 1) == 0) goto code_r0x0001801e3443;
            *(uint32_t *)(in_RCX + 0xba) = uVar1 & 0xfeffffff;
        }
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31a3;
        iVar2 = func_0x0001801e5890(in_RCX);
        if (iVar2 != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31af;
            uVar4 = func_0x0001801e8e50(iVar8);
            if ((((uint64_t)in_RCX[0xb6] < uVar4) || ((uint64_t)in_RCX[0xb6] <= uVar4)) &&
               ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 6) == 0)) {
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31d4;
                uVar5 = func_0x0001801fb740(iVar8, 3);
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31e8;
                uVar6 = func_0x0001801fb780(iVar8, 3);
                uVar4 = in_RCX[0xad];
                if (in_RCX[0xad] == 0xffffffffffffffff) {
                    uVar4 = uVar6 >> 1;
                }
                if (uVar4 <= uVar5) {
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x80000000;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3211;
                    fcn.1801e2f70(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffff7;
        do {
            iVar8 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3231;
            iVar2 = func_0x000180207410(iVar8, (int64_t)&arg_58h + iVar3);
            iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            if (iVar8 != 0) {
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20;
                *(uint32_t *)(*in_RCX + 0x9c) = *(uint32_t *)(*in_RCX + 0x9c) | 8;
                if ((*(int32_t *)((int64_t)&arg_58h + iVar3) != 0) && ((*(uint32_t *)(in_RCX + 0xba) & 0x20000000) == 0)
                   ) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3269;
                    func_0x0001801e3460(in_RCX);
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20000000;
                }
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) &&
                   (*(int32_t *)((int64_t)&arg_58h + iVar3 + 4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3290;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 8) != 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffb;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32ab;
                func_0x0001801e34d0(in_RCX);
                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            }
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32dd;
                iVar8 = fcn.1801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = unaff_RSI;
                    uVar9 = 0x1805aadb1;
                    iVar10 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        iVar10 = iVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e330b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3323;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    uVar7 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        uVar7 = 0x1805ab2bc;
                    }
                    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar7;
                    if (iVar8 != 0) {
                        uVar9 = 0x1805ab2cc;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar3) = uVar9;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3376;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e338e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    if (in_RCX[0xbb] == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33a7;
                        iVar8 = fcn.1802542f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                        in_RCX[0xbb] = iVar8;
                        if (iVar8 != 0) goto code_r0x0001801e33b3;
                    } else {
code_r0x0001801e33b3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33bb;
                        fcn.180254600(*(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
                    }
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1d;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33f2;
                    fcn.1801e2d20(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3));
                }
                break;
            }
        } while (iVar8 != 0);
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3406;
        iVar2 = func_0x0001801fb440(iVar8);
        if ((iVar2 + 1U & 0xfffffffd) != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3422;
            func_0x0001801e8f60(iVar8, in_RCX);
        }
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e342e;
        iVar8 = func_0x0001801fb7d0(iVar8);
        if (iVar8 != 0) {
            *in_RDX = 1;
        }
    }
code_r0x0001801e3443:
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3450;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (int64_t)&var_10h + iVar3);
    return;
}

// ============================================================
// Function: FUN_1801e3417
// Address: 0x1801e3417
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch

void fcn.1801e3140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_a0h, int64_t arg_a8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    undefined8 unaff_RDI;
    int64_t iVar10;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801e314e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_10h + iVar3;
    uVar1 = *(uint32_t *)(in_RCX + 0xba);
    if ((uVar1 & 7) != 3) {
        if ((uVar1 & 7) == 2) {
            if ((uVar1 >> 0x18 & 1) == 0) goto code_r0x0001801e3443;
            *(uint32_t *)(in_RCX + 0xba) = uVar1 & 0xfeffffff;
        }
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31a3;
        iVar2 = func_0x0001801e5890(in_RCX);
        if (iVar2 != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31af;
            uVar4 = func_0x0001801e8e50(iVar8);
            if ((((uint64_t)in_RCX[0xb6] < uVar4) || ((uint64_t)in_RCX[0xb6] <= uVar4)) &&
               ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 6) == 0)) {
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31d4;
                uVar5 = func_0x0001801fb740(iVar8, 3);
                iVar8 = in_RCX[0x7a];
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e31e8;
                uVar6 = func_0x0001801fb780(iVar8, 3);
                uVar4 = in_RCX[0xad];
                if (in_RCX[0xad] == 0xffffffffffffffff) {
                    uVar4 = uVar6 >> 1;
                }
                if (uVar4 <= uVar5) {
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x80000000;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3211;
                    fcn.1801e2f70(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3), *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffff7;
        do {
            iVar8 = in_RCX[0x11];
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3231;
            iVar2 = func_0x000180207410(iVar8, (int64_t)&arg_58h + iVar3);
            iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            if (iVar8 != 0) {
                *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20;
                *(uint32_t *)(*in_RCX + 0x9c) = *(uint32_t *)(*in_RCX + 0x9c) | 8;
                if ((*(int32_t *)((int64_t)&arg_58h + iVar3) != 0) && ((*(uint32_t *)(in_RCX + 0xba) & 0x20000000) == 0)
                   ) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3269;
                    func_0x0001801e3460(in_RCX);
                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x20000000;
                }
                if (((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) &&
                   (*(int32_t *)((int64_t)&arg_58h + iVar3 + 4) != 0)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3290;
                    func_0x0001801de5b0(in_RCX, 0);
                }
                if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 8) != 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffffb;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32ab;
                func_0x0001801e34d0(in_RCX);
                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar3);
            }
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e32dd;
                iVar8 = fcn.1801fca50(1);
                if ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x40) == 0) {
                    *(undefined8 *)((int64_t)&arg_a8h + iVar3) = unaff_RSI;
                    uVar9 = 0x1805aadb1;
                    iVar10 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        iVar10 = iVar8;
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e330b;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3323;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    uVar7 = 0x1805aadb1;
                    if (iVar8 != 0) {
                        uVar7 = 0x1805ab2bc;
                    }
                    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar7;
                    if (iVar8 != 0) {
                        uVar9 = 0x1805ab2cc;
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar3) = uVar9;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3376;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e338e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    if (in_RCX[0xbb] == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33a7;
                        iVar8 = fcn.1802542f0(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                        in_RCX[0xbb] = iVar8;
                        if (iVar8 != 0) goto code_r0x0001801e33b3;
                    } else {
code_r0x0001801e33b3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33bb;
                        fcn.180254600(*(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                                      *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
                    }
                    *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x40;
                    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 0x1804b7188;
                    *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1d;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e33f2;
                    fcn.1801e2d20(*(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3));
                }
                break;
            }
        } while (iVar8 != 0);
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3406;
        iVar2 = func_0x0001801fb440(iVar8);
        if ((iVar2 + 1U & 0xfffffffd) != 0) {
            iVar8 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3422;
            func_0x0001801e8f60(iVar8, in_RCX);
        }
        iVar8 = in_RCX[0x7a];
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e342e;
        iVar8 = func_0x0001801fb7d0(iVar8);
        if (iVar8 != 0) {
            *in_RDX = 1;
        }
    }
code_r0x0001801e3443:
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1801e3450;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (int64_t)&var_10h + iVar3);
    return;
}

// ============================================================
// Function: FUN_1801e3460
// Address: 0x1801e3460
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e3460(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e3470;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e347e;
    iVar2 = fcn.1801e8e50(*(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1), 
                          *(int64_t *)(&stack0x00000078 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e3489;
    uVar3 = fcn.1801dee70(in_RCX);
    if (-iVar2 - 1U < uVar3) {
        *(undefined8 *)(in_RCX + 0x5a0) = 0xffffffffffffffff;
        return;
    }
    *(uint64_t *)(in_RCX + 0x5a0) = uVar3 + iVar2;
    return;
}

// ============================================================
// Function: FUN_1801e34d0
// Address: 0x1801e34d0
// Size: 115 bytes
// ============================================================
void fcn.1801e34d0(int64_t arg_28h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    uint64_t uVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e34dc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e34e7;
    uVar2 = fcn.1801dee70();
    if (uVar2 == 0xffffffffffffffff) {
        *(undefined8 *)(in_RCX + 0x5a8) = 0xffffffffffffffff;
        return;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
    uVar4 = 25000000000;
    if (uVar2 >> 1 < 25000000000) {
        uVar4 = uVar2 >> 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e351b;
    iVar3 = fcn.1801e8e50(*(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1), 
                          *(int64_t *)(&stack0x00000078 + iVar1));
    iVar1 = -1;
    if (uVar4 <= -iVar3 - 1U) {
        iVar1 = iVar3 + uVar4;
    }
    *(int64_t *)(in_RCX + 0x5a8) = iVar1;
    return;
}

// ============================================================
// Function: FUN_1801e3550
// Address: 0x1801e3550
// Size: 90 bytes
// ============================================================
void fcn.1801e3550(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 *in_RCX;
    uint32_t uVar3;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e355c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX[2] == 0) {
        *in_RCX = *in_RDX;
        in_RCX[1] = in_RDX[1];
        uVar3 = (*(uint32_t *)(in_RCX + 4) ^ *(uint32_t *)(in_RDX + 4)) & 1 ^ *(uint32_t *)(in_RCX + 4);
        *(uint32_t *)(in_RCX + 4) = uVar3;
        *(uint32_t *)(in_RCX + 4) = (uVar3 ^ *(uint32_t *)(in_RDX + 4)) & 2 ^ uVar3;
        if ((in_RDX[2] != 0) && (iVar1 = in_RDX[3], iVar1 != 0)) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            iVar4 = iVar1 + -1;
            if (iVar1 != -1) {
                iVar4 = iVar1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e35d1;
            iVar2 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
            in_RCX[2] = iVar2;
            if (iVar2 != 0) {
                *(undefined *)(iVar4 + iVar2) = 0;
                in_RCX[3] = iVar4;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e35aa
// Address: 0x1801e35aa
// Size: 61 bytes
// ============================================================
void fcn.1801e3550(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 *in_RCX;
    uint32_t uVar3;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e355c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX[2] == 0) {
        *in_RCX = *in_RDX;
        in_RCX[1] = in_RDX[1];
        uVar3 = (*(uint32_t *)(in_RCX + 4) ^ *(uint32_t *)(in_RDX + 4)) & 1 ^ *(uint32_t *)(in_RCX + 4);
        *(uint32_t *)(in_RCX + 4) = uVar3;
        *(uint32_t *)(in_RCX + 4) = (uVar3 ^ *(uint32_t *)(in_RDX + 4)) & 2 ^ uVar3;
        if ((in_RDX[2] != 0) && (iVar1 = in_RDX[3], iVar1 != 0)) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            iVar4 = iVar1 + -1;
            if (iVar1 != -1) {
                iVar4 = iVar1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e35d1;
            iVar2 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
            in_RCX[2] = iVar2;
            if (iVar2 != 0) {
                *(undefined *)(iVar4 + iVar2) = 0;
                in_RCX[3] = iVar4;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e35e7
// Address: 0x1801e35e7
// Size: 6 bytes
// ============================================================
void fcn.1801e3550(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 *in_RCX;
    uint32_t uVar3;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e355c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX[2] == 0) {
        *in_RCX = *in_RDX;
        in_RCX[1] = in_RDX[1];
        uVar3 = (*(uint32_t *)(in_RCX + 4) ^ *(uint32_t *)(in_RDX + 4)) & 1 ^ *(uint32_t *)(in_RCX + 4);
        *(uint32_t *)(in_RCX + 4) = uVar3;
        *(uint32_t *)(in_RCX + 4) = (uVar3 ^ *(uint32_t *)(in_RDX + 4)) & 2 ^ uVar3;
        if ((in_RDX[2] != 0) && (iVar1 = in_RDX[3], iVar1 != 0)) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            iVar4 = iVar1 + -1;
            if (iVar1 != -1) {
                iVar4 = iVar1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e35d1;
            iVar2 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
            in_RCX[2] = iVar2;
            if (iVar2 != 0) {
                *(undefined *)(iVar4 + iVar2) = 0;
                in_RCX[3] = iVar4;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e35f0
// Address: 0x1801e35f0
// Size: 35 bytes
// ============================================================
void fcn.1801e35f0(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_80h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t *in_RCX;
    int64_t *piVar15;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    in_RDX = in_RDX + 0x300;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar9 + -8) = unaff_R15;
    *(undefined8 *)((int64_t)&var_8h + iVar9) = 0x1801e7fc3;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar8 = *(uint32_t *)(in_RCX + 0x20);
    uVar3 = *(undefined8 *)(in_RDX + 8);
    *(undefined8 *)((int64_t)&arg_c0h + iVar10 + iVar9) = unaff_R14;
    bVar16 = true;
    *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(in_RCX + 0x20);
        uVar4 = in_RCX[7];
        pcVar5 = *(code **)(in_RDX + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RDX + 0x78);
            *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e801c;
            uVar11 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar16 = uVar4 >> 2 < uVar11;
        }
    }
    cVar2 = *(char *)((int64_t)in_RCX + 0x101);
    *(undefined8 *)((int64_t)&arg_b8h + iVar10 + iVar9) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar12 = in_RCX[0xe];
        *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar12);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)in_RCX + 0x101) != '\0') && (*(char *)((int64_t)in_RCX + 0x101) == '\x03')) {
            iVar12 = in_RCX[0xe];
            *(undefined *)((int64_t)in_RCX + 0x101) = 4;
            *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e8063;
            func_0x0001801e6180(iVar12);
            in_RCX[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)in_RCX + 0x104) < '\0') {
                *(uint32_t *)((int64_t)in_RCX + 0x104) = *(uint32_t *)((int64_t)in_RCX + 0x104) & 0xffffff7f;
                piVar15 = (int64_t *)(in_RDX + 0x60);
                *piVar15 = *piVar15 + -1;
                if (*piVar15 == 0) {
                    uVar3 = *(undefined8 *)(in_RDX + 8);
                    *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)in_RCX + 0x104) & 0x80) != 0) && (*(char *)((int64_t)in_RCX + 0x101) == '\x02')) {
            iVar12 = in_RCX[0xe];
            *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar12);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e80c1;
                func_0x0001801e8310(in_RDX, in_RCX);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)in_RCX + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)in_RCX + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)in_RCX + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)in_RCX + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar15 = in_RCX + 4;
            *(uint32_t *)((int64_t)in_RCX + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(in_RDX + 0x30);
            piVar14 = *ppiVar1;
            *piVar15 = (int64_t)piVar14;
            piVar14[1] = (int64_t)piVar15;
            *ppiVar1 = piVar15;
            in_RCX[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar16) && ((*(uint32_t *)((int64_t)in_RCX + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)in_RCX + 0x102) == '\0') || (*(char *)((int64_t)in_RCX + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)in_RCX + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(in_RCX + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(in_RCX + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3)))) {
                    iVar12 = in_RCX[0xe];
                    *(int64_t *)((int64_t)&arg_30h + iVar10 + iVar9) = (int64_t)&arg_b0h + iVar10 + iVar9;
                    *(undefined8 *)((int64_t)&arg_b0h + iVar10 + iVar9) = 2;
                    *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar12, 0, (int64_t)&arg_60h + iVar10 + iVar9, 
                                                (int64_t)&arg_40h + iVar10 + iVar9);
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e81e2;
                        iVar12 = func_0x0001801e5c20(in_RCX + 0x10, 0);
                        *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e81f1;
                        iVar13 = func_0x0001801bc820(in_RCX + 0x10);
                        if ((((*(uint8_t *)((int64_t)&arg_80h + iVar10 + iVar9) & 2) != 0) &&
                            (*(int64_t *)((int64_t)&arg_70h + iVar10 + iVar9) == 0)) ||
                           (*(uint64_t *)((int64_t)&arg_68h + iVar10 + iVar9) < (uint64_t)(iVar13 + iVar12)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)in_RCX + 0x104) & 2) == 0) {
            *(undefined8 *)((int64_t)&var_8h + iVar10 + iVar9) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(in_RCX + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(in_RCX + 0x20) & 0x1000000) == 0) {
            iVar9 = *(int64_t *)(in_RDX + 0x10);
            *in_RCX = iVar9;
            *(int64_t **)(iVar9 + 8) = in_RCX;
            *(int64_t **)(in_RDX + 0x10) = in_RCX;
            in_RCX[1] = (int64_t)(int64_t **)(in_RDX + 0x10);
            if (*(int64_t *)(in_RDX + 0x68) == 0) {
                *(int64_t **)(in_RDX + 0x68) = in_RCX;
            }
            *(uint32_t *)(in_RCX + 0x20) = *(uint32_t *)(in_RCX + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(in_RCX + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(in_RDX + 0x68) == in_RCX) {
                piVar15 = (int64_t *)in_RCX[1];
                if (piVar15 == (int64_t *)(in_RDX + 0x10)) {
                    piVar15 = (int64_t *)piVar15[1];
                }
                piVar14 = (int64_t *)0x0;
                if (piVar15 != (int64_t *)(in_RDX + 0x10)) {
                    piVar14 = piVar15;
                }
                *(int64_t **)(in_RDX + 0x68) = piVar14;
                if (piVar14 == in_RCX) {
                    *(undefined8 *)(in_RDX + 0x68) = 0;
                }
            }
            *(int64_t *)(*in_RCX + 8) = in_RCX[1];
            *(int64_t *)in_RCX[1] = *in_RCX;
            *(uint32_t *)(in_RCX + 0x20) = *(uint32_t *)(in_RCX + 0x20) & 0xfeffffff;
            *in_RCX = 0;
            in_RCX[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e3620
// Address: 0x1801e3620
// Size: 25 bytes
// ============================================================
void fcn.1801e3620(undefined8 param_1, undefined8 param_2, int64_t param_3)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_3 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180226320;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        iVar1 = *(int64_t *)(param_3 + 8);
        if (iVar1 != 0) {
            uVar2 = *(undefined8 *)(param_3 + 0x10);
            if ((*(uint8_t *)(param_3 + 0x18) & 1) == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180226358;
                func_0x000180224b90(iVar1, uVar2, 0x1804bfe08, 0x31);
            } else {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18022634b;
                func_0x000180225130();
            }
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18022636d;
        func_0x000180224990(param_3, 0x1804bfe08, 0x33);
    }
    return;
}

// ============================================================
// Function: FUN_1801e3640
// Address: 0x1801e3640
// Size: 35 bytes
// ============================================================
void fcn.1801e3640(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801e3670
// Address: 0x1801e3670
// Size: 25 bytes
// ============================================================
void fcn.1801e3670(undefined8 param_1, undefined8 param_2, int32_t *param_3)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x1801bf15a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    LOCK();
    iVar1 = *param_3;
    *param_3 = *param_3 + -1;
    UNLOCK();
    if (1 < iVar1) {
        return;
    }
    *(undefined8 *)(&stack0x00000048 + iVar3 + iVar4) = 0x18022499a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_3 != (int32_t *)0x0) {
            *(undefined8 *)(&stack0x00000070 + iVar5 + iVar3 + iVar4) = unaff_RBX;
            *(undefined8 *)(&stack0x00000048 + iVar5 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_3);
            if (iVar1 == 0) {
                *(undefined8 *)(&stack0x00000048 + iVar5 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)(&stack0x00000048 + iVar5 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)(&stack0x00000048 + iVar5 + iVar3 + iVar4) = 0x18047ca54;
                puVar6 = (undefined4 *)fcn.18046b77c();
                *puVar6 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801e3690
// Address: 0x1801e3690
// Size: 35 bytes
// ============================================================
void fcn.1801e3690(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801e36e0
// Address: 0x1801e36e0
// Size: 25 bytes
// ============================================================
void fcn.1801e36e0(int64_t **param_1)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar6 = *param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1801e8e5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *piVar6;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = 0x1801dd6ea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(code **)(iVar5 + 0x18) == (code *)0x0) {
        *(undefined8 *)(&stack0x00000070 + iVar2 + iVar4 + iVar3) = 0x1802450ca;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        *(uint64_t *)(&stack0x000000b0 + iVar5 + iVar2 + iVar4 + iVar3) =
             *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000078 + iVar5 + iVar2 + iVar4 + iVar3);
        *(undefined8 *)(&stack0x00000070 + iVar5 + iVar2 + iVar4 + iVar3) = 0x1802450e7;
        (*(code *)0x69a176)(&stack0x000000a0 + iVar5 + iVar2 + iVar4 + iVar3);
        *(undefined8 *)(&stack0x00000070 + iVar5 + iVar2 + iVar4 + iVar3) = 0x1802450f7;
        (*(code *)0x69a186)(&stack0x000000a0 + iVar5 + iVar2 + iVar4 + iVar3, 
                            &stack0x00000098 + iVar5 + iVar2 + iVar4 + iVar3);
        uVar1 = *(uint64_t *)(&stack0x000000b0 + iVar5 + iVar2 + iVar4 + iVar3);
        *(undefined8 *)(&stack0x00000070 + iVar5 + iVar2 + iVar4 + iVar3) = 0x180245117;
        fcn.180459870(uVar1 ^ (uint64_t)(&stack0x00000078 + iVar5 + iVar2 + iVar4 + iVar3));
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001801dd707. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(iVar5 + 0x18))(*(undefined8 *)(iVar5 + 0x20));
    return;
}

// ============================================================
// Function: FUN_1801e3700
// Address: 0x1801e3700
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801e3700(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e371a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_R9 != (undefined4 *)0x0) && ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000007) == 0x2000000)) {
        uVar1 = in_R9[1];
        uVar2 = in_R9[2];
        uVar3 = in_R9[3];
        *(undefined4 *)(in_RCX + 0x47c) = *in_R9;
        *(undefined4 *)(in_RCX + 0x480) = uVar1;
        *(undefined4 *)(in_RCX + 0x484) = uVar2;
        *(undefined4 *)(in_RCX + 0x488) = uVar3;
        *(undefined4 *)(in_RCX + 0x48c) = in_R9[4];
        *(undefined *)(in_RCX + 0x490) = *(undefined *)(in_R9 + 5);
        uVar6 = *(undefined8 *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801e376f;
        iVar4 = func_0x000180200c80(uVar6, in_RCX, in_R9);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar5) = *(undefined8 *)((int64_t)&arg_58h + iVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801e378e;
            uVar6 = fcn.1801e06e0(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5));
            return uVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e37b0
// Address: 0x1801e37b0
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1801e37b0(int64_t arg_28h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    undefined8 *in_RCX;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e37c0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e37dd;
    puVar3 = (undefined8 *)
             fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000040 + iVar2));
    if (puVar3 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *puVar3 = *in_RCX;
    *(uint32_t *)(puVar3 + 0xba) =
         (*(int32_t *)(in_RCX + 4) << 0x19 ^ *(uint32_t *)(puVar3 + 0xba)) & 0x2000000 ^ *(uint32_t *)(puVar3 + 0xba);
    puVar3[6] = in_RCX[5];
    puVar3[7] = in_RCX[1];
    puVar3[8] = in_RCX[2];
    puVar3[0x7b] = in_RCX[3];
    uVar5 = (*(int32_t *)((int64_t)in_RCX + 0x34) << 10 ^ *(uint32_t *)((int64_t)puVar3 + 0x5d4)) & 0x400 ^
            *(uint32_t *)((int64_t)puVar3 + 0x5d4);
    *(uint32_t *)((int64_t)puVar3 + 0x5d4) = uVar5;
    uVar1 = *(uint32_t *)(in_RCX + 6);
    *(uint32_t *)((int64_t)puVar3 + 0x5d4) = (uVar1 << 9 ^ uVar5) & 0x200 ^ uVar5;
    if (((uVar1 & 1) != 0) && (in_RCX[7] != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e3881;
        iVar4 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        puVar3[0xbe] = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e38a2;
            fcn.180224990(puVar3, 0x1804b6360, 0x1e5);
            return (undefined8 *)0x0;
        }
    }
    return puVar3;
}

// ============================================================
// Function: FUN_1801e38c0
// Address: 0x1801e38c0
// Size: 101 bytes
// ============================================================
undefined8 fcn.1801e38c0(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e38cc;
    iVar1 = fcn.18045a350();
    if ((*(int64_t *)(param_1 + 0x3d8) == 0) && ((*(uint32_t *)(param_1 + 0x5d4) & 0x400) != 0)) {
        *(undefined8 *)(param_1 + 0x3d8) = param_2;
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1801e3904;
        fcn.180205740(param_2, 0x1801e55f0, param_1);
        iVar1 = *(int64_t *)(param_1 + 0x3d8);
        *(undefined8 *)(iVar1 + 0x410) = 0x1801e5620;
        *(int64_t *)(iVar1 + 0x418) = param_1;
        return 1;
    }
    return param_2;
}

