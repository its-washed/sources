// Chunk 122 - 50 functions

// ============================================================
// Function: FUN_1801a25e0
// Address: 0x1801a25e0
// Size: 73 bytes
// ============================================================
void fcn.1801a25e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_70h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    undefined4 in_R9D;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a25ea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x158) + 0x90);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)(*(int64_t *)(in_RCX + 0x158) + 0xa0);
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)((int64_t)&arg_70h + iVar2);
    *(undefined4 *)((int64_t)&var_20h + iVar2) = in_R9D;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801a2624;
    (*pcVar1)(0, in_RCX, in_RDX & 0xffffffff, in_R8 & 0xffffffff);
    return;
}

// ============================================================
// Function: FUN_1801a2630
// Address: 0x1801a2630
// Size: 82 bytes
// ============================================================
undefined4 fcn.1801a2630(undefined8 param_1, int64_t param_2, int32_t *param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a263c;
    iVar2 = fcn.18045a350();
    if (param_2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801a2656;
        iVar1 = func_0x000180193ca0();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801a264f;
        iVar1 = func_0x000180192490();
    }
    if (iVar1 < 6) {
        if (iVar1 < 0) {
            iVar1 = 0;
        }
    } else {
        iVar1 = 5;
    }
    if (param_3 != (int32_t *)0x0) {
        *param_3 = iVar1;
    }
    return *(undefined4 *)((int64_t)iVar1 * 4 + 0x1804ad6b8);
}

// ============================================================
// Function: FUN_1801a2690
// Address: 0x1801a2690
// Size: 74 bytes
// ============================================================
void fcn.1801a2690(int64_t arg_28h, int64_t arg_30h, int64_t arg_70h)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    undefined4 in_R9D;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a269a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(in_RCX + 0x40);
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x90);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = *(undefined8 *)(*(int64_t *)(in_RCX + 0x878) + 0xa0);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_70h + iVar3);
    *(undefined4 *)((int64_t)&var_20h + iVar3) = in_R9D;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801a26d5;
    (*pcVar2)(uVar1, 0, in_RDX & 0xffffffff, in_R8 & 0xffffffff);
    return;
}

// ============================================================
// Function: FUN_1801a26e0
// Address: 0x1801a26e0
// Size: 411 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801a26e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t *in_RCX;
    int64_t in_RDX;
    int32_t in_R8D;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a26fa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a271a;
        uVar1 = func_0x000180193ca0();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a2713;
        uVar1 = func_0x000180192490(in_RDX);
    }
    if ((int32_t)uVar1 < 6) {
        if (((int32_t)uVar1 < 0) || (iVar3 = *(int32_t *)((int64_t)(int32_t)uVar1 * 4 + 0x1804ad6b8), uVar1 == 0)) {
            if (in_R8D != 0x40007) {
                return true;
            }
            if (in_R9D < 0x50) {
                return false;
            }
            return true;
        }
    } else {
        iVar3 = 0x100;
        uVar1 = 5;
    }
    if (in_R8D < 0x10002) {
        if (in_R8D == 0x10001) {
code_r0x0001801a2819:
            if (in_R9D < iVar3) {
                return false;
            }
            iVar2 = *(int64_t *)((int64_t)&arg_50h + iVar2);
            if ((*(uint8_t *)(iVar2 + 0x20) & 4) != 0) {
                return false;
            }
            if ((*(uint32_t *)(iVar2 + 0x28) & 1) != 0) {
                return false;
            }
            if ((0xa0 < iVar3) && ((*(uint32_t *)(iVar2 + 0x28) & 2) != 0)) {
                return false;
            }
            if (uVar1 < 3) {
                return true;
            }
            if (*(int32_t *)(iVar2 + 0x2c) == 0x304) {
                return true;
            }
            return (*(uint32_t *)(iVar2 + 0x1c) & 0x186) != 0;
        }
        if (in_R8D == 9) {
            if (in_RCX == (int32_t *)0x0) {
                return false;
            }
            if (*in_RCX != 0) {
                if (-1 < (char)*in_RCX) {
                    return false;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a27a3;
                in_RCX = (int32_t *)func_0x0001801bda50(in_RCX);
                if (in_RCX == (int32_t *)0x0) {
                    return false;
                }
            }
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 6) + 0xd8) + 0x50) & 8) == 0) {
                if (0x302 < *(int32_t *)((int64_t)&arg_48h + iVar2)) {
                    return true;
                }
            } else {
                iVar3 = *(int32_t *)((int64_t)&arg_48h + iVar2);
                if (iVar3 == 0x100) {
                    iVar3 = 0xff00;
                }
                if (iVar3 < 0xfefe) {
                    return true;
                }
            }
            if (uVar1 != 0) {
                return false;
            }
            return true;
        }
        if (in_R8D == 10) {
            if (uVar1 < 3) {
                return true;
            }
            return false;
        }
        if (in_R8D == 0xf) {
            if (1 < uVar1) {
                return false;
            }
            return true;
        }
    } else if ((in_R8D == 0x10002) || (in_R8D == 0x10003)) goto code_r0x0001801a2819;
    if (in_R9D < iVar3) {
        return false;
    }
    return true;
}

// ============================================================
// Function: FUN_1801a2880
// Address: 0x1801a2880
// Size: 25 bytes
// ============================================================
int32_t fcn.1801a2880(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a288a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar11 = 0;
    *(undefined8 *)(&stack0x00000020 + iVar7) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000020 + iVar7 + -0x20) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x1801a28b2;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_RDX == 0) {
code_r0x0001801a28d5:
        if (iVar11 == 0) {
            return 0;
        }
        if (in_RDX == 0) goto code_r0x0001801a28ec;
    } else {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a28d1;
        iVar4 = func_0x000180222010(in_RDX);
        if (iVar4 == 0) goto code_r0x0001801a28d5;
    }
    if (iVar11 != 0) {
        return 0;
    }
code_r0x0001801a28ec:
    iVar13 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R15;
    iVar13 = *(int64_t *)(iVar13 + 0x78);
    if (iVar13 == 0) {
        iVar13 = puVar2[5];
    }
    uVar10 = puVar2[0x8c];
    uVar12 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2922;
    iVar9 = func_0x00018024c080(uVar12, uVar10);
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a292f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2947;
        func_0x0001802295a0(0x1804ad6e8, 0x1c9, 0x1804ad740);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2959;
        func_0x0001802296d0(0x14, 0x8000b, 0);
        iVar4 = 0;
    } else {
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29e7;
            iVar4 = func_0x00018024bff0(iVar9, iVar13, iVar11);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29f0;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a08;
                func_0x0001802295a0(0x1804ad6e8, 0x1d5, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a1a;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a22;
                func_0x00018024b910(iVar9);
                return 0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2985;
            uVar10 = func_0x000180222340(in_RDX, 0);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2996;
            iVar4 = func_0x00018024bbe0(iVar9, iVar13, uVar10, in_RDX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29a3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29bb;
                func_0x0001802295a0(0x1804ad6e8, 0x1d0, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29cd;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29d5;
                func_0x00018024b910(iVar9);
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a31;
        uVar10 = func_0x000180192480(iVar9);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a3c;
        uVar5 = func_0x000180193ca0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a46;
        func_0x000180234260(uVar10, uVar5);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a5e;
        func_0x00018024c330(iVar9, uVar1 & 0x30000);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a71;
        iVar6 = func_0x000180222870(0x18077e284, 0x1801a2c40);
        iVar4 = 0;
        if (iVar6 != 0) {
            iVar4 = *(int32_t *)0x18077e288;
        }
        uVar5 = 0xffffffff;
        if (iVar4 != 0) {
            uVar5 = *(undefined4 *)0x18069c680;
        }
        uVar12 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a98;
        iVar6 = func_0x00018024c310(iVar9, uVar5, uVar12);
        iVar4 = 0;
        if (iVar6 != 0) {
            if (in_RCX + 0x518 != 0) {
                uVar12 = *(undefined8 *)(in_RCX + 0x520);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ab8;
                iVar4 = func_0x000180222010(uVar12);
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ac7;
                    func_0x000180174310(iVar9, in_RCX + 0x518);
                }
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2acf;
            iVar4 = func_0x000180193fe0(in_RCX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2adb;
                iVar4 = func_0x000180194ed0(in_RCX);
                if (0x303 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2af5;
                    iVar4 = func_0x000180193380(in_RCX, 0x7f, 0, 0);
                    if (iVar4 == 1) {
                        uVar12 = *(undefined8 *)(in_RCX + 0xa58);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b09;
                        func_0x00018024c350(iVar9, uVar12);
                    }
                }
            }
            uVar12 = 0x1804ad768;
            if (*(int32_t *)(in_RCX + 0x78) != 0) {
                uVar12 = 0x1804ad758;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b27;
            func_0x00018024c290(iVar9, uVar12);
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b36;
            func_0x0001802340a0(uVar10, uVar12);
            if (*(int64_t *)(in_RCX + 0x950) != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b4a;
                func_0x00018021b240(iVar9);
            }
            pcVar3 = (code *)puVar2[0x15];
            if (pcVar3 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b6b;
                iVar4 = func_0x00018024c740(iVar9);
                if (iVar4 < 0) {
                    iVar4 = 0;
                }
            } else {
                uVar12 = puVar2[0x16];
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b62;
                iVar4 = (*pcVar3)(iVar9, uVar12);
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b7b;
            uVar5 = func_0x00018024bbd0(iVar9);
            uVar12 = *(undefined8 *)(in_RCX + 0x988);
            *(undefined4 *)(in_RCX + 0x990) = uVar5;
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b8d;
            func_0x000180238640(uVar12);
            *(undefined8 *)(in_RCX + 0x988) = 0;
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ba1;
                iVar11 = func_0x00018024b960(iVar9);
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bae;
                    iVar11 = func_0x00018024b970(iVar9);
                    *(int64_t *)(in_RCX + 0x988) = iVar11;
                    if (iVar11 == 0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bbf;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bd7;
                        func_0x0001802295a0(0x1804ad6e8, 0x220, 0x1804ad740);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2be9;
                        func_0x0001802296d0(0x14, 0x8000b, 0);
                        iVar4 = 0;
                    }
                }
            }
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bfb;
            func_0x000180233fe0(uVar12, uVar10);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2c03;
        func_0x00018024b910(iVar9);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1801a28a0
// Address: 0x1801a28a0
// Size: 83 bytes
// ============================================================
int32_t fcn.1801a2880(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a288a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar11 = 0;
    *(undefined8 *)(&stack0x00000020 + iVar7) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000020 + iVar7 + -0x20) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x1801a28b2;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_RDX == 0) {
code_r0x0001801a28d5:
        if (iVar11 == 0) {
            return 0;
        }
        if (in_RDX == 0) goto code_r0x0001801a28ec;
    } else {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a28d1;
        iVar4 = func_0x000180222010(in_RDX);
        if (iVar4 == 0) goto code_r0x0001801a28d5;
    }
    if (iVar11 != 0) {
        return 0;
    }
code_r0x0001801a28ec:
    iVar13 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R15;
    iVar13 = *(int64_t *)(iVar13 + 0x78);
    if (iVar13 == 0) {
        iVar13 = puVar2[5];
    }
    uVar10 = puVar2[0x8c];
    uVar12 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2922;
    iVar9 = func_0x00018024c080(uVar12, uVar10);
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a292f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2947;
        func_0x0001802295a0(0x1804ad6e8, 0x1c9, 0x1804ad740);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2959;
        func_0x0001802296d0(0x14, 0x8000b, 0);
        iVar4 = 0;
    } else {
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29e7;
            iVar4 = func_0x00018024bff0(iVar9, iVar13, iVar11);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29f0;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a08;
                func_0x0001802295a0(0x1804ad6e8, 0x1d5, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a1a;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a22;
                func_0x00018024b910(iVar9);
                return 0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2985;
            uVar10 = func_0x000180222340(in_RDX, 0);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2996;
            iVar4 = func_0x00018024bbe0(iVar9, iVar13, uVar10, in_RDX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29a3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29bb;
                func_0x0001802295a0(0x1804ad6e8, 0x1d0, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29cd;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29d5;
                func_0x00018024b910(iVar9);
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a31;
        uVar10 = func_0x000180192480(iVar9);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a3c;
        uVar5 = func_0x000180193ca0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a46;
        func_0x000180234260(uVar10, uVar5);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a5e;
        func_0x00018024c330(iVar9, uVar1 & 0x30000);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a71;
        iVar6 = func_0x000180222870(0x18077e284, 0x1801a2c40);
        iVar4 = 0;
        if (iVar6 != 0) {
            iVar4 = *(int32_t *)0x18077e288;
        }
        uVar5 = 0xffffffff;
        if (iVar4 != 0) {
            uVar5 = *(undefined4 *)0x18069c680;
        }
        uVar12 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a98;
        iVar6 = func_0x00018024c310(iVar9, uVar5, uVar12);
        iVar4 = 0;
        if (iVar6 != 0) {
            if (in_RCX + 0x518 != 0) {
                uVar12 = *(undefined8 *)(in_RCX + 0x520);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ab8;
                iVar4 = func_0x000180222010(uVar12);
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ac7;
                    func_0x000180174310(iVar9, in_RCX + 0x518);
                }
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2acf;
            iVar4 = func_0x000180193fe0(in_RCX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2adb;
                iVar4 = func_0x000180194ed0(in_RCX);
                if (0x303 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2af5;
                    iVar4 = func_0x000180193380(in_RCX, 0x7f, 0, 0);
                    if (iVar4 == 1) {
                        uVar12 = *(undefined8 *)(in_RCX + 0xa58);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b09;
                        func_0x00018024c350(iVar9, uVar12);
                    }
                }
            }
            uVar12 = 0x1804ad768;
            if (*(int32_t *)(in_RCX + 0x78) != 0) {
                uVar12 = 0x1804ad758;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b27;
            func_0x00018024c290(iVar9, uVar12);
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b36;
            func_0x0001802340a0(uVar10, uVar12);
            if (*(int64_t *)(in_RCX + 0x950) != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b4a;
                func_0x00018021b240(iVar9);
            }
            pcVar3 = (code *)puVar2[0x15];
            if (pcVar3 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b6b;
                iVar4 = func_0x00018024c740(iVar9);
                if (iVar4 < 0) {
                    iVar4 = 0;
                }
            } else {
                uVar12 = puVar2[0x16];
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b62;
                iVar4 = (*pcVar3)(iVar9, uVar12);
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b7b;
            uVar5 = func_0x00018024bbd0(iVar9);
            uVar12 = *(undefined8 *)(in_RCX + 0x988);
            *(undefined4 *)(in_RCX + 0x990) = uVar5;
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b8d;
            func_0x000180238640(uVar12);
            *(undefined8 *)(in_RCX + 0x988) = 0;
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ba1;
                iVar11 = func_0x00018024b960(iVar9);
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bae;
                    iVar11 = func_0x00018024b970(iVar9);
                    *(int64_t *)(in_RCX + 0x988) = iVar11;
                    if (iVar11 == 0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bbf;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bd7;
                        func_0x0001802295a0(0x1804ad6e8, 0x220, 0x1804ad740);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2be9;
                        func_0x0001802296d0(0x14, 0x8000b, 0);
                        iVar4 = 0;
                    }
                }
            }
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bfb;
            func_0x000180233fe0(uVar12, uVar10);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2c03;
        func_0x00018024b910(iVar9);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1801a28f3
// Address: 0x1801a28f3
// Size: 131 bytes
// ============================================================
int32_t fcn.1801a2880(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a288a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar11 = 0;
    *(undefined8 *)(&stack0x00000020 + iVar7) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000020 + iVar7 + -0x20) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x1801a28b2;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_RDX == 0) {
code_r0x0001801a28d5:
        if (iVar11 == 0) {
            return 0;
        }
        if (in_RDX == 0) goto code_r0x0001801a28ec;
    } else {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a28d1;
        iVar4 = func_0x000180222010(in_RDX);
        if (iVar4 == 0) goto code_r0x0001801a28d5;
    }
    if (iVar11 != 0) {
        return 0;
    }
code_r0x0001801a28ec:
    iVar13 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R15;
    iVar13 = *(int64_t *)(iVar13 + 0x78);
    if (iVar13 == 0) {
        iVar13 = puVar2[5];
    }
    uVar10 = puVar2[0x8c];
    uVar12 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2922;
    iVar9 = func_0x00018024c080(uVar12, uVar10);
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a292f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2947;
        func_0x0001802295a0(0x1804ad6e8, 0x1c9, 0x1804ad740);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2959;
        func_0x0001802296d0(0x14, 0x8000b, 0);
        iVar4 = 0;
    } else {
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29e7;
            iVar4 = func_0x00018024bff0(iVar9, iVar13, iVar11);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29f0;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a08;
                func_0x0001802295a0(0x1804ad6e8, 0x1d5, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a1a;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a22;
                func_0x00018024b910(iVar9);
                return 0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2985;
            uVar10 = func_0x000180222340(in_RDX, 0);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2996;
            iVar4 = func_0x00018024bbe0(iVar9, iVar13, uVar10, in_RDX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29a3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29bb;
                func_0x0001802295a0(0x1804ad6e8, 0x1d0, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29cd;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29d5;
                func_0x00018024b910(iVar9);
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a31;
        uVar10 = func_0x000180192480(iVar9);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a3c;
        uVar5 = func_0x000180193ca0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a46;
        func_0x000180234260(uVar10, uVar5);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a5e;
        func_0x00018024c330(iVar9, uVar1 & 0x30000);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a71;
        iVar6 = func_0x000180222870(0x18077e284, 0x1801a2c40);
        iVar4 = 0;
        if (iVar6 != 0) {
            iVar4 = *(int32_t *)0x18077e288;
        }
        uVar5 = 0xffffffff;
        if (iVar4 != 0) {
            uVar5 = *(undefined4 *)0x18069c680;
        }
        uVar12 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a98;
        iVar6 = func_0x00018024c310(iVar9, uVar5, uVar12);
        iVar4 = 0;
        if (iVar6 != 0) {
            if (in_RCX + 0x518 != 0) {
                uVar12 = *(undefined8 *)(in_RCX + 0x520);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ab8;
                iVar4 = func_0x000180222010(uVar12);
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ac7;
                    func_0x000180174310(iVar9, in_RCX + 0x518);
                }
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2acf;
            iVar4 = func_0x000180193fe0(in_RCX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2adb;
                iVar4 = func_0x000180194ed0(in_RCX);
                if (0x303 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2af5;
                    iVar4 = func_0x000180193380(in_RCX, 0x7f, 0, 0);
                    if (iVar4 == 1) {
                        uVar12 = *(undefined8 *)(in_RCX + 0xa58);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b09;
                        func_0x00018024c350(iVar9, uVar12);
                    }
                }
            }
            uVar12 = 0x1804ad768;
            if (*(int32_t *)(in_RCX + 0x78) != 0) {
                uVar12 = 0x1804ad758;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b27;
            func_0x00018024c290(iVar9, uVar12);
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b36;
            func_0x0001802340a0(uVar10, uVar12);
            if (*(int64_t *)(in_RCX + 0x950) != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b4a;
                func_0x00018021b240(iVar9);
            }
            pcVar3 = (code *)puVar2[0x15];
            if (pcVar3 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b6b;
                iVar4 = func_0x00018024c740(iVar9);
                if (iVar4 < 0) {
                    iVar4 = 0;
                }
            } else {
                uVar12 = puVar2[0x16];
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b62;
                iVar4 = (*pcVar3)(iVar9, uVar12);
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b7b;
            uVar5 = func_0x00018024bbd0(iVar9);
            uVar12 = *(undefined8 *)(in_RCX + 0x988);
            *(undefined4 *)(in_RCX + 0x990) = uVar5;
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b8d;
            func_0x000180238640(uVar12);
            *(undefined8 *)(in_RCX + 0x988) = 0;
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ba1;
                iVar11 = func_0x00018024b960(iVar9);
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bae;
                    iVar11 = func_0x00018024b970(iVar9);
                    *(int64_t *)(in_RCX + 0x988) = iVar11;
                    if (iVar11 == 0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bbf;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bd7;
                        func_0x0001802295a0(0x1804ad6e8, 0x220, 0x1804ad740);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2be9;
                        func_0x0001802296d0(0x14, 0x8000b, 0);
                        iVar4 = 0;
                    }
                }
            }
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bfb;
            func_0x000180233fe0(uVar12, uVar10);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2c03;
        func_0x00018024b910(iVar9);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1801a2976
// Address: 0x1801a2976
// Size: 660 bytes
// ============================================================
int32_t fcn.1801a2880(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a288a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar11 = 0;
    *(undefined8 *)(&stack0x00000020 + iVar7) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000020 + iVar7 + -0x20) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x1801a28b2;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_RDX == 0) {
code_r0x0001801a28d5:
        if (iVar11 == 0) {
            return 0;
        }
        if (in_RDX == 0) goto code_r0x0001801a28ec;
    } else {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a28d1;
        iVar4 = func_0x000180222010(in_RDX);
        if (iVar4 == 0) goto code_r0x0001801a28d5;
    }
    if (iVar11 != 0) {
        return 0;
    }
code_r0x0001801a28ec:
    iVar13 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R15;
    iVar13 = *(int64_t *)(iVar13 + 0x78);
    if (iVar13 == 0) {
        iVar13 = puVar2[5];
    }
    uVar10 = puVar2[0x8c];
    uVar12 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2922;
    iVar9 = func_0x00018024c080(uVar12, uVar10);
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a292f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2947;
        func_0x0001802295a0(0x1804ad6e8, 0x1c9, 0x1804ad740);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2959;
        func_0x0001802296d0(0x14, 0x8000b, 0);
        iVar4 = 0;
    } else {
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29e7;
            iVar4 = func_0x00018024bff0(iVar9, iVar13, iVar11);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29f0;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a08;
                func_0x0001802295a0(0x1804ad6e8, 0x1d5, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a1a;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a22;
                func_0x00018024b910(iVar9);
                return 0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2985;
            uVar10 = func_0x000180222340(in_RDX, 0);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2996;
            iVar4 = func_0x00018024bbe0(iVar9, iVar13, uVar10, in_RDX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29a3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29bb;
                func_0x0001802295a0(0x1804ad6e8, 0x1d0, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29cd;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29d5;
                func_0x00018024b910(iVar9);
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a31;
        uVar10 = func_0x000180192480(iVar9);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a3c;
        uVar5 = func_0x000180193ca0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a46;
        func_0x000180234260(uVar10, uVar5);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a5e;
        func_0x00018024c330(iVar9, uVar1 & 0x30000);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a71;
        iVar6 = func_0x000180222870(0x18077e284, 0x1801a2c40);
        iVar4 = 0;
        if (iVar6 != 0) {
            iVar4 = *(int32_t *)0x18077e288;
        }
        uVar5 = 0xffffffff;
        if (iVar4 != 0) {
            uVar5 = *(undefined4 *)0x18069c680;
        }
        uVar12 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a98;
        iVar6 = func_0x00018024c310(iVar9, uVar5, uVar12);
        iVar4 = 0;
        if (iVar6 != 0) {
            if (in_RCX + 0x518 != 0) {
                uVar12 = *(undefined8 *)(in_RCX + 0x520);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ab8;
                iVar4 = func_0x000180222010(uVar12);
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ac7;
                    func_0x000180174310(iVar9, in_RCX + 0x518);
                }
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2acf;
            iVar4 = func_0x000180193fe0(in_RCX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2adb;
                iVar4 = func_0x000180194ed0(in_RCX);
                if (0x303 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2af5;
                    iVar4 = func_0x000180193380(in_RCX, 0x7f, 0, 0);
                    if (iVar4 == 1) {
                        uVar12 = *(undefined8 *)(in_RCX + 0xa58);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b09;
                        func_0x00018024c350(iVar9, uVar12);
                    }
                }
            }
            uVar12 = 0x1804ad768;
            if (*(int32_t *)(in_RCX + 0x78) != 0) {
                uVar12 = 0x1804ad758;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b27;
            func_0x00018024c290(iVar9, uVar12);
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b36;
            func_0x0001802340a0(uVar10, uVar12);
            if (*(int64_t *)(in_RCX + 0x950) != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b4a;
                func_0x00018021b240(iVar9);
            }
            pcVar3 = (code *)puVar2[0x15];
            if (pcVar3 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b6b;
                iVar4 = func_0x00018024c740(iVar9);
                if (iVar4 < 0) {
                    iVar4 = 0;
                }
            } else {
                uVar12 = puVar2[0x16];
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b62;
                iVar4 = (*pcVar3)(iVar9, uVar12);
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b7b;
            uVar5 = func_0x00018024bbd0(iVar9);
            uVar12 = *(undefined8 *)(in_RCX + 0x988);
            *(undefined4 *)(in_RCX + 0x990) = uVar5;
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b8d;
            func_0x000180238640(uVar12);
            *(undefined8 *)(in_RCX + 0x988) = 0;
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ba1;
                iVar11 = func_0x00018024b960(iVar9);
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bae;
                    iVar11 = func_0x00018024b970(iVar9);
                    *(int64_t *)(in_RCX + 0x988) = iVar11;
                    if (iVar11 == 0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bbf;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bd7;
                        func_0x0001802295a0(0x1804ad6e8, 0x220, 0x1804ad740);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2be9;
                        func_0x0001802296d0(0x14, 0x8000b, 0);
                        iVar4 = 0;
                    }
                }
            }
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bfb;
            func_0x000180233fe0(uVar12, uVar10);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2c03;
        func_0x00018024b910(iVar9);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1801a2c0a
// Address: 0x1801a2c0a
// Size: 14 bytes
// ============================================================
int32_t fcn.1801a2880(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar13;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a288a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar11 = 0;
    *(undefined8 *)(&stack0x00000020 + iVar7) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000020 + iVar7 + -0x20) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x1801a28b2;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_RDX == 0) {
code_r0x0001801a28d5:
        if (iVar11 == 0) {
            return 0;
        }
        if (in_RDX == 0) goto code_r0x0001801a28ec;
    } else {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a28d1;
        iVar4 = func_0x000180222010(in_RDX);
        if (iVar4 == 0) goto code_r0x0001801a28d5;
    }
    if (iVar11 != 0) {
        return 0;
    }
code_r0x0001801a28ec:
    iVar13 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R15;
    iVar13 = *(int64_t *)(iVar13 + 0x78);
    if (iVar13 == 0) {
        iVar13 = puVar2[5];
    }
    uVar10 = puVar2[0x8c];
    uVar12 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2922;
    iVar9 = func_0x00018024c080(uVar12, uVar10);
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a292f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2947;
        func_0x0001802295a0(0x1804ad6e8, 0x1c9, 0x1804ad740);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2959;
        func_0x0001802296d0(0x14, 0x8000b, 0);
        iVar4 = 0;
    } else {
        if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29e7;
            iVar4 = func_0x00018024bff0(iVar9, iVar13, iVar11);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29f0;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a08;
                func_0x0001802295a0(0x1804ad6e8, 0x1d5, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a1a;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a22;
                func_0x00018024b910(iVar9);
                return 0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2985;
            uVar10 = func_0x000180222340(in_RDX, 0);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2996;
            iVar4 = func_0x00018024bbe0(iVar9, iVar13, uVar10, in_RDX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29a3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29bb;
                func_0x0001802295a0(0x1804ad6e8, 0x1d0, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29cd;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a29d5;
                func_0x00018024b910(iVar9);
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a31;
        uVar10 = func_0x000180192480(iVar9);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a3c;
        uVar5 = func_0x000180193ca0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a46;
        func_0x000180234260(uVar10, uVar5);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x878) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a5e;
        func_0x00018024c330(iVar9, uVar1 & 0x30000);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a71;
        iVar6 = func_0x000180222870(0x18077e284, 0x1801a2c40);
        iVar4 = 0;
        if (iVar6 != 0) {
            iVar4 = *(int32_t *)0x18077e288;
        }
        uVar5 = 0xffffffff;
        if (iVar4 != 0) {
            uVar5 = *(undefined4 *)0x18069c680;
        }
        uVar12 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2a98;
        iVar6 = func_0x00018024c310(iVar9, uVar5, uVar12);
        iVar4 = 0;
        if (iVar6 != 0) {
            if (in_RCX + 0x518 != 0) {
                uVar12 = *(undefined8 *)(in_RCX + 0x520);
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ab8;
                iVar4 = func_0x000180222010(uVar12);
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ac7;
                    func_0x000180174310(iVar9, in_RCX + 0x518);
                }
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2acf;
            iVar4 = func_0x000180193fe0(in_RCX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2adb;
                iVar4 = func_0x000180194ed0(in_RCX);
                if (0x303 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2af5;
                    iVar4 = func_0x000180193380(in_RCX, 0x7f, 0, 0);
                    if (iVar4 == 1) {
                        uVar12 = *(undefined8 *)(in_RCX + 0xa58);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b09;
                        func_0x00018024c350(iVar9, uVar12);
                    }
                }
            }
            uVar12 = 0x1804ad768;
            if (*(int32_t *)(in_RCX + 0x78) != 0) {
                uVar12 = 0x1804ad758;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b27;
            func_0x00018024c290(iVar9, uVar12);
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b36;
            func_0x0001802340a0(uVar10, uVar12);
            if (*(int64_t *)(in_RCX + 0x950) != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b4a;
                func_0x00018021b240(iVar9);
            }
            pcVar3 = (code *)puVar2[0x15];
            if (pcVar3 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b6b;
                iVar4 = func_0x00018024c740(iVar9);
                if (iVar4 < 0) {
                    iVar4 = 0;
                }
            } else {
                uVar12 = puVar2[0x16];
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b62;
                iVar4 = (*pcVar3)(iVar9, uVar12);
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b7b;
            uVar5 = func_0x00018024bbd0(iVar9);
            uVar12 = *(undefined8 *)(in_RCX + 0x988);
            *(undefined4 *)(in_RCX + 0x990) = uVar5;
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2b8d;
            func_0x000180238640(uVar12);
            *(undefined8 *)(in_RCX + 0x988) = 0;
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2ba1;
                iVar11 = func_0x00018024b960(iVar9);
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bae;
                    iVar11 = func_0x00018024b970(iVar9);
                    *(int64_t *)(in_RCX + 0x988) = iVar11;
                    if (iVar11 == 0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bbf;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bd7;
                        func_0x0001802295a0(0x1804ad6e8, 0x220, 0x1804ad740);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2be9;
                        func_0x0001802296d0(0x14, 0x8000b, 0);
                        iVar4 = 0;
                    }
                }
            }
            uVar12 = *(undefined8 *)(in_RCX + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2bfb;
            func_0x000180233fe0(uVar12, uVar10);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar8 + iVar7) = 0x1801a2c03;
        func_0x00018024b910(iVar9);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1801a2c20
// Address: 0x1801a2c20
// Size: 27 bytes
// ============================================================
int32_t fcn.1801a2c20(int64_t param_1, int64_t param_2)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iVar13;
    undefined8 unaff_R15;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a2c2a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar10 = 0;
    *(undefined8 *)(&stack0x00000020 + iVar11) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar11) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_R12;
    *(undefined8 *)(&stack0x00000020 + iVar11 + -0x20) = unaff_R13;
    *(undefined8 *)((int64_t)&uStack_8 + iVar11) = 0x1801a28b2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (iVar10 == 0) {
code_r0x0001801a28d5:
        if (param_2 == 0) {
            return 0;
        }
        if (iVar10 == 0) goto code_r0x0001801a28ec;
    } else {
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a28d1;
        iVar4 = func_0x000180222010(iVar10);
        if (iVar4 == 0) goto code_r0x0001801a28d5;
    }
    if (param_2 != 0) {
        return 0;
    }
code_r0x0001801a28ec:
    iVar13 = *(int64_t *)(param_1 + 0x878);
    *(undefined8 *)(&stack0x00000050 + iVar7 + iVar11) = unaff_RDI;
    *(undefined8 *)(&stack0x00000058 + iVar7 + iVar11) = unaff_R14;
    puVar2 = *(undefined8 **)(param_1 + 8);
    *(undefined8 *)(&stack0x00000060 + iVar7 + iVar11) = unaff_R15;
    iVar13 = *(int64_t *)(iVar13 + 0x78);
    if (iVar13 == 0) {
        iVar13 = puVar2[5];
    }
    uVar9 = puVar2[0x8c];
    uVar12 = *puVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2922;
    iVar8 = func_0x00018024c080(uVar12, uVar9);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a292f;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2947;
        func_0x0001802295a0(0x1804ad6e8, 0x1c9, 0x1804ad740);
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2959;
        func_0x0001802296d0(0x14, 0x8000b, 0);
        iVar4 = 0;
    } else {
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a29e7;
            iVar4 = func_0x00018024bff0(iVar8, iVar13, param_2);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a29f0;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a08;
                func_0x0001802295a0(0x1804ad6e8, 0x1d5, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a1a;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a22;
                func_0x00018024b910(iVar8);
                return 0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2985;
            uVar9 = func_0x000180222340(iVar10, 0);
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2996;
            iVar4 = func_0x00018024bbe0(iVar8, iVar13, uVar9, iVar10);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a29a3;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a29bb;
                func_0x0001802295a0(0x1804ad6e8, 0x1d0, 0x1804ad740);
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a29cd;
                func_0x0001802296d0(0x14, 0x8000b, 0);
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a29d5;
                func_0x00018024b910(iVar8);
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a31;
        uVar9 = func_0x000180192480(iVar8);
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a3c;
        uVar5 = func_0x000180193ca0(param_1);
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a46;
        func_0x000180234260(uVar9, uVar5);
        uVar1 = *(uint32_t *)(*(int64_t *)(param_1 + 0x878) + 0x1c);
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a5e;
        func_0x00018024c330(iVar8, uVar1 & 0x30000);
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a71;
        iVar6 = func_0x000180222870(0x18077e284, 0x1801a2c40);
        iVar4 = 0;
        if (iVar6 != 0) {
            iVar4 = *(int32_t *)0x18077e288;
        }
        uVar5 = 0xffffffff;
        if (iVar4 != 0) {
            uVar5 = *(undefined4 *)0x18069c680;
        }
        uVar12 = *(undefined8 *)(param_1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2a98;
        iVar6 = func_0x00018024c310(iVar8, uVar5, uVar12);
        iVar4 = 0;
        if (iVar6 != 0) {
            if (param_1 + 0x518 != 0) {
                uVar12 = *(undefined8 *)(param_1 + 0x520);
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2ab8;
                iVar4 = func_0x000180222010(uVar12);
                if (0 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2ac7;
                    func_0x000180174310(iVar8, param_1 + 0x518);
                }
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2acf;
            iVar4 = func_0x000180193fe0(param_1);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2adb;
                iVar4 = func_0x000180194ed0(param_1);
                if (0x303 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2af5;
                    iVar4 = func_0x000180193380(param_1, 0x7f, 0, 0);
                    if (iVar4 == 1) {
                        uVar12 = *(undefined8 *)(param_1 + 0xa58);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2b09;
                        func_0x00018024c350(iVar8, uVar12);
                    }
                }
            }
            uVar12 = 0x1804ad768;
            if (*(int32_t *)(param_1 + 0x78) != 0) {
                uVar12 = 0x1804ad758;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2b27;
            func_0x00018024c290(iVar8, uVar12);
            uVar12 = *(undefined8 *)(param_1 + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2b36;
            func_0x0001802340a0(uVar9, uVar12);
            if (*(int64_t *)(param_1 + 0x950) != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2b4a;
                func_0x00018021b240(iVar8);
            }
            pcVar3 = (code *)puVar2[0x15];
            if (pcVar3 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2b6b;
                iVar4 = func_0x00018024c740(iVar8);
                if (iVar4 < 0) {
                    iVar4 = 0;
                }
            } else {
                uVar12 = puVar2[0x16];
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2b62;
                iVar4 = (*pcVar3)(iVar8, uVar12);
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2b7b;
            uVar5 = func_0x00018024bbd0(iVar8);
            uVar12 = *(undefined8 *)(param_1 + 0x988);
            *(undefined4 *)(param_1 + 0x990) = uVar5;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2b8d;
            func_0x000180238640(uVar12);
            *(undefined8 *)(param_1 + 0x988) = 0;
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2ba1;
                iVar10 = func_0x00018024b960(iVar8);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2bae;
                    iVar10 = func_0x00018024b970(iVar8);
                    *(int64_t *)(param_1 + 0x988) = iVar10;
                    if (iVar10 == 0) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2bbf;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2bd7;
                        func_0x0001802295a0(0x1804ad6e8, 0x220, 0x1804ad740);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2be9;
                        func_0x0001802296d0(0x14, 0x8000b, 0);
                        iVar4 = 0;
                    }
                }
            }
            uVar12 = *(undefined8 *)(param_1 + 0x510);
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2bfb;
            func_0x000180233fe0(uVar12, uVar9);
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar11) = 0x1801a2c03;
        func_0x00018024b910(iVar8);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1801a2c40
// Address: 0x1801a2c40
// Size: 75 bytes
// ============================================================
void fcn.1801a2c40(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a2c4a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801a2c6f;
    *(uint32_t *)0x18069c680 =
         fcn.180224220(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                       *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                       *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
    *(uint32_t *)0x18077e288 = ~*(uint32_t *)0x18069c680 >> 0x1f;
    return;
}

// ============================================================
// Function: FUN_1801a2c90
// Address: 0x1801a2c90
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801a2c90(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a2ca0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2cbc;
    iVar2 = func_0x000180234b40();
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2ccc;
    iVar3 = func_0x000180234b40(in_RDX, (int64_t)&arg_38h + iVar4);
    uVar1 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
    if ((iVar2 < 0) || (iVar3 < 0)) {
        iVar2 = -2;
    } else if (iVar2 == iVar3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2cf1;
        iVar2 = func_0x000180497f30(uVar1, *(undefined8 *)((int64_t)&arg_38h + iVar4), (int64_t)iVar2);
    } else {
        iVar2 = iVar2 - iVar3;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2d0f;
    func_0x000180224990(uVar1, 0x1804ad6e8, 0x2f4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2d26;
    func_0x000180224990(*(undefined8 *)((int64_t)&arg_38h + iVar4), 0x1804ad6e8, 0x2f5);
    return iVar2;
}

// ============================================================
// Function: FUN_1801a2d40
// Address: 0x1801a2d40
// Size: 30 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_3bh
// WARNING: [rz-ghidra] Detected overlap for variable arg_39h

void fcn.1801a2d40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 *puVar6;
    undefined8 auStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar6 = (undefined4 *)0x0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar2) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar2) = 0x1802379cf;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_50h + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_8 + iVar3 + iVar2;
    *(undefined8 *)(&stack0x00000000 + iVar3 + iVar2) = 0x1802379fb;
    iVar4 = func_0x000180215540(uVar5, 0x1804ad35c);
    *(undefined8 *)(&stack0x00000000 + iVar3 + iVar2) = 0x180237a08;
    iVar1 = func_0x000180234b40(in_RCX, 0);
    if (puVar6 != (undefined4 *)0x0) {
        *puVar6 = 0;
    }
    if ((-1 < iVar1) && (iVar4 != 0)) {
        iVar1 = *(int32_t *)(in_RCX + 0x20);
        uVar5 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&arg_30h + iVar3 + iVar2) = 0;
        *(int64_t *)((int64_t)&arg_28h + iVar3 + iVar2) = iVar4;
        *(undefined8 *)(&stack0x00000000 + iVar3 + iVar2) = 0x180237a37;
        iVar1 = func_0x000180214220(uVar5, (int64_t)iVar1, (int64_t)&arg_38h + iVar3 + iVar2, 0);
        if ((iVar1 != 0) && (puVar6 != (undefined4 *)0x0)) {
            *puVar6 = 1;
        }
    }
    *(undefined8 *)(&stack0x00000000 + iVar3 + iVar2) = 0x180237a71;
    func_0x000180215590(iVar4);
    *(undefined8 *)(&stack0x00000000 + iVar3 + iVar2) = 0x180237a80;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar3 + iVar2) ^ (int64_t)auStackX_8 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_1801a2d60
// Address: 0x1801a2d60
// Size: 28 bytes
// ============================================================
int32_t fcn.1801a2d60(undefined8 *param_1, undefined8 *param_2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar6 = *param_2;
    uVar1 = *param_1;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x1801a2ca0;
    iVar4 = fcn.18045a350(uVar1, uVar6);
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000068 + iVar4 + iVar5) = 0;
    *(undefined8 *)(&stack0x00000060 + iVar4 + iVar5) = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1801a2cbc;
    iVar2 = func_0x000180234b40();
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1801a2ccc;
    iVar3 = func_0x000180234b40(uVar6, &stack0x00000060 + iVar4 + iVar5);
    uVar6 = *(undefined8 *)(&stack0x00000068 + iVar4 + iVar5);
    if ((iVar2 < 0) || (iVar3 < 0)) {
        iVar2 = -2;
    } else if (iVar2 == iVar3) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1801a2cf1;
        iVar2 = func_0x000180497f30(uVar6, *(undefined8 *)(&stack0x00000060 + iVar4 + iVar5), (int64_t)iVar2);
    } else {
        iVar2 = iVar2 - iVar3;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1801a2d0f;
    func_0x000180224990(uVar6, 0x1804ad6e8, 0x2f4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1801a2d26;
    func_0x000180224990(*(undefined8 *)(&stack0x00000060 + iVar4 + iVar5), 0x1804ad6e8, 0x2f5);
    return iVar2;
}

// ============================================================
// Function: FUN_1801a2d80
// Address: 0x1801a2d80
// Size: 69 bytes
// ============================================================
void fcn.1801a2d80(int64_t arg_28h, int64_t arg_30h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a2d8a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)((int64_t)&arg_78h + iVar3);
    pcVar2 = *(code **)(iVar1 + 0x4f8);
    if (pcVar2 != (code *)0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = *(undefined8 *)(iVar1 + 0x500);
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)(iVar1 + 0x40);
        *(undefined8 *)((int64_t)&var_20h + iVar3) = *(undefined8 *)((int64_t)&arg_70h + iVar3);
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801a2dc0;
        (*pcVar2)();
    }
    return;
}

// ============================================================
// Function: FUN_1801a2dd0
// Address: 0x1801a2dd0
// Size: 22 bytes
// ============================================================
void fcn.1801a2dd0(int64_t param_1, undefined4 param_2, undefined4 param_3, undefined4 param_4)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000030 + iVar4) = 0x1801a269a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(param_1 + 0x40);
    pcVar2 = *(code **)(*(int64_t *)(param_1 + 0x878) + 0x90);
    *(undefined8 *)(&stack0x00000068 + iVar3 + iVar4) = *(undefined8 *)(*(int64_t *)(param_1 + 0x878) + 0xa0);
    *(undefined8 *)(&stack0x00000060 + iVar3 + iVar4) = *(undefined8 *)(&stack0x000000a8 + iVar3 + iVar4);
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar4) = param_4;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar4) = 0x1801a26d5;
    (*pcVar2)(uVar1, 0, param_2, param_3);
    return;
}

// ============================================================
// Function: FUN_1801a2df0
// Address: 0x1801a2df0
// Size: 38 bytes
// ============================================================
void fcn.1801a2df0(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x0001801a2e13. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(param_1 + 0xce0))(*(undefined8 *)(param_1 + 0x40), param_2, param_3, *(undefined8 *)(param_1 + 0xce8));
    return;
}

// ============================================================
// Function: FUN_1801a2e20
// Address: 0x1801a2e20
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint32_t fcn.1801a2e20(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 *in_RCX;
    uint64_t uVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a2e35;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = 1;
    uVar5 = in_RCX[0x17];
    if (uVar5 < (uint64_t)in_RCX[0x16]) {
        do {
            uVar1 = *in_RCX;
            in_RCX[0x17] = uVar5 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2e71;
            uVar3 = func_0x0001801a4880(uVar1, in_RCX + (uVar5 + 3) * 8, 0);
            uVar5 = in_RCX[0x17];
            uVar6 = uVar6 & uVar3;
        } while (uVar5 < (uint64_t)in_RCX[0x16]);
    }
    in_RCX[10] = 0;
    *(undefined4 *)(in_RCX + 0xb) = 0;
    uVar1 = in_RCX[7];
    in_RCX[0xc] = 0;
    in_RCX[0xd] = 0;
    *(undefined *)(in_RCX + 0xe) = 0;
    in_RCX[0xf] = 0;
    *(undefined4 *)(in_RCX + 0x10) = 0;
    in_RCX[0x16] = 0;
    in_RCX[0x17] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2eba;
    func_0x000180219f80(uVar1);
    in_RCX[7] = 0;
    if (in_RCX[3] != 0) {
        pcVar2 = *(code **)(in_RCX[3] + 8);
        uVar1 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2ed1;
        (*pcVar2)(uVar1);
    }
    if (in_RCX[4] != 0) {
        pcVar2 = *(code **)(in_RCX[4] + 8);
        uVar1 = in_RCX[6];
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2ee4;
        (*pcVar2)(uVar1);
    }
    uVar1 = in_RCX[7];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2eed;
    func_0x000180219f80(uVar1);
    in_RCX[3] = 0;
    in_RCX[4] = 0;
    in_RCX[7] = 0;
    in_RCX[5] = 0;
    in_RCX[6] = 0;
    if (in_RCX[0x11] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a2f12;
        func_0x0001801c71d0(in_RCX);
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801a2f70
// Address: 0x1801a2f70
// Size: 62 bytes
// ============================================================
undefined8 fcn.1801a2f70(int64_t param_1)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a2f7a;
    iVar2 = fcn.18045a350();
    if (*(uint64_t *)(param_1 + 0xb0) <= *(uint64_t *)(param_1 + 0xb8)) {
        uVar3 = *(undefined8 *)(param_1 + 0x28);
        pcVar1 = *(code **)(*(int64_t *)(param_1 + 0x18) + 0x18);
        *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x1801a2f9b;
        uVar3 = (*pcVar1)(uVar3);
        if ((int32_t)uVar3 == 0) {
            return uVar3;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a2fb0
// Address: 0x1801a2fb0
// Size: 32 bytes
// ============================================================
void fcn.1801a2fb0(int64_t param_1)
{
    code *UNRECOVERED_JUMPTABLE;
    
    fcn.18045a350();
    UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(param_1 + 0x18) + 0x10);
    // WARNING: Could not recover jumptable at 0x0001801a2fcd. Too many branches
    // WARNING: Treating indirect jump as call
    (*UNRECOVERED_JUMPTABLE)(*(undefined8 *)(param_1 + 0x28), UNRECOVERED_JUMPTABLE);
    return;
}

// ============================================================
// Function: FUN_1801a2fd0
// Address: 0x1801a2fd0
// Size: 537 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint32_t fcn.1801a2fd0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    undefined8 uVar9;
    uint32_t uVar10;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801a2fee;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar10 = 1;
    uVar8 = in_RCX[0x17];
    if (uVar8 < (uint64_t)in_RCX[0x16]) {
        do {
            iVar2 = *in_RCX;
            in_RCX[0x17] = uVar8 + 1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a3031;
            uVar5 = func_0x0001801a4880(iVar2, in_RCX + (uVar8 + 3) * 8, 0);
            uVar8 = in_RCX[0x17];
            uVar10 = uVar10 & uVar5;
        } while (uVar8 < (uint64_t)in_RCX[0x16]);
    }
    in_RCX[10] = 0;
    *(undefined4 *)(in_RCX + 0xb) = 0;
    iVar2 = in_RCX[7];
    in_RCX[0xc] = 0;
    in_RCX[0xd] = 0;
    *(undefined *)(in_RCX + 0xe) = 0;
    in_RCX[0xf] = 0;
    *(undefined4 *)(in_RCX + 0x10) = 0;
    in_RCX[0x16] = 0;
    in_RCX[0x17] = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a307c;
    func_0x000180219f80(iVar2);
    in_RCX[7] = 0;
    if (in_RCX[3] != 0) {
        pcVar3 = *(code **)(in_RCX[3] + 8);
        iVar2 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a3093;
        (*pcVar3)(iVar2);
    }
    if (in_RCX[4] != 0) {
        pcVar3 = *(code **)(in_RCX[4] + 8);
        iVar2 = in_RCX[6];
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a30a6;
        (*pcVar3)(iVar2);
    }
    iVar2 = in_RCX[7];
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a30af;
    func_0x000180219f80(iVar2);
    in_RCX[3] = 0;
    in_RCX[4] = 0;
    in_RCX[7] = 0;
    in_RCX[5] = 0;
    in_RCX[6] = 0;
    if (in_RCX[0x11] != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a30d4;
        func_0x0001801c71d0(in_RCX);
    }
    iVar2 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
    uVar11 = 0x10000;
    uVar9 = 0x10000;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
    iVar4 = *(int64_t *)(iVar2 + 0x18);
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    iVar4 = *(int64_t *)(iVar4 + 0xd8);
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = 0;
    uVar1 = *(uint8_t *)(iVar4 + 0x50);
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
    if ((uVar1 & 8) != 0) {
        uVar9 = 0x1ffff;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a3151;
    uVar5 = func_0x0001801a4960(iVar2, uVar9, 0, 0);
    iVar2 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
    iVar4 = *(int64_t *)(iVar2 + 0x18);
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    iVar4 = *(int64_t *)(iVar4 + 0xd8);
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = 0;
    uVar1 = *(uint8_t *)(iVar4 + 0x50);
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = 0;
    if ((uVar1 & 8) != 0) {
        uVar11 = 0x1ffff;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801a31ca;
    uVar6 = func_0x0001801a4960(iVar2, uVar11, 1, 0);
    return uVar6 & uVar5 & uVar10;
}

// ============================================================
// Function: FUN_1801a3200
// Address: 0x1801a3200
// Size: 176 bytes
// ============================================================
uint32_t fcn.1801a3200(int64_t param_1)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a320c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar3 = *(int64_t *)(param_1 + 0x8f8);
    if (*(int32_t *)(param_1 + 0x78) != 0) {
        if (*(int32_t *)(param_1 + 0xb18) != 2) {
            return *(uint32_t *)(param_1 + 0x153c);
        }
        uVar1 = *(uint32_t *)(iVar3 + 0x338);
        if (*(uint32_t *)(param_1 + 0x153c) < *(uint32_t *)(iVar3 + 0x338)) {
            uVar1 = *(uint32_t *)(param_1 + 0x153c);
        }
        return uVar1;
    }
    if ((*(int32_t *)(iVar3 + 0x338) == 0) &&
       ((iVar3 = *(int64_t *)(param_1 + 0x900), iVar3 == 0 || (*(int32_t *)(iVar3 + 0x338) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a3242;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a325a;
        func_0x0001802295a0(0x1804ad8a8, 0x83, 0x1804ad890);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a3270;
        func_0x00018019b5e0(param_1, 0x50, 0xc0103, 0);
        return 0;
    }
    return *(uint32_t *)(iVar3 + 0x338);
}

// ============================================================
// Function: FUN_1801a32c0
// Address: 0x1801a32c0
// Size: 252 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1801a32c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_60h)
{
    int64_t iVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a32d0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = (int32_t)in_R8;
    if (iVar4 == 0) {
        *(uint32_t *)(in_RCX + 0x68) = 3 - (uint32_t)(in_EDX != 0);
        return 0xffffffff;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar4 != -3) {
        if (iVar4 == -2) {
            iVar1 = *(int64_t *)(in_RCX + 0xc68);
            uVar2 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
            pcVar3 = *(code **)(iVar1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33c7;
            iVar4 = (*pcVar3)(uVar2);
            if (iVar4 != -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33d3;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33e2;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33f5;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
            }
        } else {
            if (iVar4 == -1) {
                return 0;
            }
            if (-2 < iVar4) {
                return in_R8 & 0xffffffff;
            }
        }
        return 0xffffffff;
    }
    if (in_EDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3312;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3321;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3337;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0xffffffff;
    }
    if ((*(uint8_t *)(in_RCX + 0x9a8) & 0x80) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a335a;
        fcn.180194c30();
        *(undefined4 *)(in_RCX + 0x1bc) = 0;
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3376;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3385;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a339b;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801a33bc
// Address: 0x1801a33bc
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1801a32c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_60h)
{
    int64_t iVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a32d0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = (int32_t)in_R8;
    if (iVar4 == 0) {
        *(uint32_t *)(in_RCX + 0x68) = 3 - (uint32_t)(in_EDX != 0);
        return 0xffffffff;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar4 != -3) {
        if (iVar4 == -2) {
            iVar1 = *(int64_t *)(in_RCX + 0xc68);
            uVar2 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
            pcVar3 = *(code **)(iVar1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33c7;
            iVar4 = (*pcVar3)(uVar2);
            if (iVar4 != -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33d3;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33e2;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33f5;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
            }
        } else {
            if (iVar4 == -1) {
                return 0;
            }
            if (-2 < iVar4) {
                return in_R8 & 0xffffffff;
            }
        }
        return 0xffffffff;
    }
    if (in_EDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3312;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3321;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3337;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0xffffffff;
    }
    if ((*(uint8_t *)(in_RCX + 0x9a8) & 0x80) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a335a;
        fcn.180194c30();
        *(undefined4 *)(in_RCX + 0x1bc) = 0;
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3376;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3385;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a339b;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801a33fa
// Address: 0x1801a33fa
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1801a32c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_60h)
{
    int64_t iVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a32d0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = (int32_t)in_R8;
    if (iVar4 == 0) {
        *(uint32_t *)(in_RCX + 0x68) = 3 - (uint32_t)(in_EDX != 0);
        return 0xffffffff;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar4 != -3) {
        if (iVar4 == -2) {
            iVar1 = *(int64_t *)(in_RCX + 0xc68);
            uVar2 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
            pcVar3 = *(code **)(iVar1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33c7;
            iVar4 = (*pcVar3)(uVar2);
            if (iVar4 != -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33d3;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33e2;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a33f5;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
            }
        } else {
            if (iVar4 == -1) {
                return 0;
            }
            if (-2 < iVar4) {
                return in_R8 & 0xffffffff;
            }
        }
        return 0xffffffff;
    }
    if (in_EDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3312;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3321;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3337;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0xffffffff;
    }
    if ((*(uint8_t *)(in_RCX + 0x9a8) & 0x80) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a335a;
        fcn.180194c30();
        *(undefined4 *)(in_RCX + 0x1bc) = 0;
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3376;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a3385;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801a339b;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801a3430
// Address: 0x1801a3430
// Size: 273 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801a3430(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *in_RCX;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a3445;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar7 = 0;
    if (in_RCX != (int32_t *)0x0) {
        if (*in_RCX == 0) {
code_r0x0001801a3477:
            uVar6 = uVar7;
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 6) + 0xd8) + 0x50) & 8) != 0) {
                uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x336) + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a3498;
                uVar3 = func_0x00018001ed90(uVar3);
                *(undefined8 *)((int64_t)&arg_28h + iVar2) = uVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a34a7;
                iVar4 = func_0x0001801a67e0((int64_t)&arg_28h + iVar2);
                uVar6 = 0;
                while (iVar4 != 0) {
                    uVar6 = uVar6 + *(int64_t *)(*(int64_t *)(iVar4 + 8) + 0x20);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a34c2;
                    iVar4 = func_0x0001801a67e0((int64_t)&arg_28h + iVar2);
                }
            }
            if (*(uint64_t *)(in_RCX + 0x340) != 0) {
                piVar5 = (int64_t *)(in_RCX + 0x34c);
                do {
                    if (*(char *)((int64_t)piVar5 + -0x14) != '\x17') {
                        return uVar6;
                    }
                    uVar6 = uVar6 + *piVar5;
                    uVar7 = uVar7 + 1;
                    piVar5 = piVar5 + 8;
                } while (uVar7 < *(uint64_t *)(in_RCX + 0x340));
            }
            uVar3 = *(undefined8 *)(in_RCX + 0x31e);
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x31a) + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a3509;
            iVar2 = (*pcVar1)(uVar3);
            return iVar2 + uVar6;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801a346b;
            in_RCX = (int32_t *)func_0x0001801bda50();
            if (in_RCX != (int32_t *)0x0) goto code_r0x0001801a3477;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a3550
// Address: 0x1801a3550
// Size: 398 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel

uint64_t fcn.1801a3550(int32_t *placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_60h,
                      int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                      int64_t arg_90h)
{
    undefined uVar1;
    char cVar2;
    uint8_t uVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int32_t *piVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    int32_t *piVar16;
    int64_t iVar17;
    int32_t *piVar18;
    uint32_t uVar19;
    int32_t *piVar20;
    undefined8 unaff_RSI;
    uint64_t uVar21;
    undefined8 unaff_RDI;
    uint64_t *puVar22;
    int32_t *piVar23;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_38 = 0x1801a356e;
    var_18h = arg3;
    var_20h = arg4;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar23 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&arg_60h + iVar10) = 0;
    piVar18 = piVar23;
    if ((placeholder_0 != (int32_t *)0x0) && (piVar18 = (int32_t *)0x0, *placeholder_0 == 0)) {
        piVar18 = placeholder_0;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) != 0) ||
        (iVar8 = **(int32_t **)(piVar18 + 6), iVar8 < 0x304)) ||
       (*(undefined4 *)((int64_t)&arg_68h + iVar10) = 1, iVar8 == 0x10000)) {
        *(undefined4 *)((int64_t)&arg_68h + iVar10) = 0;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_RDI;
    if (((char)placeholder_1 != '\0') && (1 < (uint8_t)((char)placeholder_1 - 0x16U))) {
code_r0x0001801a35f4:
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a35f9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3611;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3627;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
        return 0xffffffff;
    }
    if (*(int32_t *)((int64_t)&arg_88h + iVar10) == 0) {
        if (((char)placeholder_1 == '\x16') && (iVar11 = *(int64_t *)(piVar18 + 0x32c), iVar11 != 0)) {
            iVar17 = *(int64_t *)((int64_t)&arg_80h + iVar10);
            piVar16 = piVar18 + 0x32a;
            piVar20 = piVar23;
            if (iVar17 != 0) {
                arg4 = arg4 - (int64_t)piVar16;
                do {
                    if (iVar11 == 0) break;
                    piVar20 = (int32_t *)((int64_t)piVar20 + 1);
                    *(undefined *)(arg4 + (int64_t)piVar16) = *(undefined *)piVar16;
                    piVar16 = (int32_t *)((int64_t)piVar16 + 1);
                    *(int64_t *)(piVar18 + 0x32c) = *(int64_t *)(piVar18 + 0x32c) + -1;
                    iVar11 = *(int64_t *)(piVar18 + 0x32c);
                    iVar17 = iVar17 + -1;
                } while (iVar17 != 0);
            }
            if (iVar11 != 0) {
                do {
                    uVar1 = *(undefined *)piVar16;
                    piVar16 = (int32_t *)((int64_t)piVar16 + 1);
                    piVar13 = (int32_t *)(uint64_t)((int32_t)piVar23 + 1);
                    *(undefined *)((int64_t)(piVar23 + 0x32a) + (int64_t)piVar18) = uVar1;
                    piVar23 = piVar13;
                } while (piVar13 < *(int32_t **)(piVar18 + 0x32c));
            }
            if ((undefined *)arg3 != (undefined *)0x0) {
                *(undefined *)arg3 = 0x16;
            }
            **(int32_t ***)((int64_t)&arg_90h + iVar10) = piVar20;
            return 1;
        }
    } else if ((char)placeholder_1 != '\x17') goto code_r0x0001801a35f4;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a36e8;
    iVar8 = func_0x00018019b680(piVar18);
    piVar16 = piVar23;
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a36f8;
        iVar8 = func_0x00018019b2a0(placeholder_0);
        piVar16 = (int32_t *)0x0;
        if (iVar8 != 0) {
            pcVar4 = *(code **)(piVar18 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3709;
            uVar12 = (*pcVar4)(placeholder_0);
            if ((int32_t)uVar12 < 0) {
                return uVar12;
            }
            piVar16 = piVar23;
            if ((int32_t)uVar12 == 0) {
                return 0xffffffff;
            }
        }
    }
code_r0x0001801a3740:
    while( true ) {
        piVar18[0x1a] = 1;
        if (*(uint64_t *)(piVar18 + 0x340) <= *(uint64_t *)(piVar18 + 0x342)) {
            *(undefined8 *)(piVar18 + 0x340) = 0;
            *(undefined8 *)(piVar18 + 0x342) = 0;
            piVar20 = piVar23;
            do {
                *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
                *(undefined8 *)(&stack0x00000000 + iVar10) = 0;
                piVar20 = piVar18 + (int64_t)piVar20 * 0x10 + 0x344;
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x40);
                *(int32_t **)((int64_t)&var_8h + iVar10) = piVar20 + 8;
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                *(int32_t **)((int64_t)&var_10h + iVar10) = piVar20 + 4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a37ba;
                uVar12 = (*pcVar4)(uVar15, piVar20, piVar20 + 2, piVar20 + 3);
                iVar8 = (int32_t)uVar12;
                if (iVar8 == 0) {
                    piVar18[0x1a] = 3;
                    return 0xffffffff;
                }
                piVar18[0x1a] = 1;
                if (iVar8 == -3) {
                    if ((*(uint8_t *)(piVar18 + 0x26a) & 0x80) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ee5;
                        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10))
                        ;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ef9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10)
                                      , *(int64_t *)(&stack0x00000000 + iVar10), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                      *(int64_t *)((int64_t)&var_20h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f0f;
                        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ed1;
                    fcn.180194c30(piVar18, 2);
                    piVar18[0x6f] = 0;
                    return 0;
                }
                if (iVar8 == -2) {
                    uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                    pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e8a;
                    iVar8 = (*pcVar4)(uVar15);
                    if (iVar8 == -1) {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e9a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3eae;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                  *(int64_t *)((int64_t)&var_20h + iVar10));
                    goto code_r0x0001801a421b;
                }
                if (iVar8 == -1) {
                    return 0;
                }
                if (iVar8 < -1) {
                    return 0xffffffff;
                }
                if (iVar8 < 1) {
                    return uVar12;
                }
                *(undefined8 *)(piVar20 + 10) = 0;
                *(int64_t *)(piVar18 + 0x340) = *(int64_t *)(piVar18 + 0x340) + 1;
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x18);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3811;
                iVar8 = (*pcVar4)(uVar15);
            } while ((iVar8 != 0) && (piVar20 = *(int32_t **)(piVar18 + 0x340), piVar20 < (int32_t *)0x20));
        }
        piVar20 = piVar18 + *(int64_t *)(piVar18 + 0x342) * 0x10 + 0x344;
        if ((*(int64_t *)(piVar18 + 0x32c) != 0) &&
           ((((*(char *)(piVar20 + 3) != '\x16' &&
              ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) == 0)) &&
             (iVar8 = **(int32_t **)(piVar18 + 6), 0x303 < iVar8)) && (iVar8 != 0x10000)))) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f2d;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f45;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        if ((*(char *)(piVar20 + 3) != '\x15') && (*(int64_t *)(piVar20 + 8) != 0)) {
            piVar18[0x334] = 0;
        }
        if ((piVar18[0x6e] != 0) && (*(char *)(piVar20 + 3) != '\x16')) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f55;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f6d;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        if ((piVar18[0x21] & 2U) != 0) {
            *(int64_t *)(piVar18 + 0x342) = *(int64_t *)(piVar18 + 0x342) + 1;
            piVar18[0x1a] = 1;
            return 0;
        }
        cVar2 = *(char *)(piVar20 + 3);
        if (((char)placeholder_1 != cVar2) &&
           ((((cVar2 != '\x14' || ((char)placeholder_1 != '\x16')) || ((undefined *)arg3 == (undefined *)0x0)) ||
            (*(int32_t *)((int64_t)&arg_68h + iVar10) != 0)))) break;
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d09;
        iVar8 = func_0x00018019b2a0(placeholder_0);
        if ((iVar8 == 0) || ((char)placeholder_1 != '\x17')) {
            if (((char)placeholder_1 == '\x16') &&
               ((*(char *)(piVar20 + 3) == '\x14' && (*(int64_t *)(piVar18 + 0x32c) != 0)))) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41f8;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
code_r0x0001801a41fd:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4210;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
        } else if ((*(int64_t *)(piVar18 + 0x98) == 0) || (*(int64_t *)(piVar18 + 0xba) == 0)) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d2a;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d42;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d58;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            return 0xffffffff;
        }
        if ((undefined *)arg3 != (undefined *)0x0) {
            *(undefined *)arg3 = *(undefined *)(piVar20 + 3);
        }
        piVar16 = *(int32_t **)((int64_t)&arg_80h + iVar10);
        if (piVar16 == (int32_t *)0x0) {
            if (*(int64_t *)(piVar20 + 8) != 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4253;
            iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
            return (uint64_t)((iVar8 != 0) - 1);
        }
        uVar12 = *(uint64_t *)(piVar18 + 0x342);
        puVar22 = (uint64_t *)(piVar20 + 8);
        piVar20 = piVar23;
        do {
            uVar14 = puVar22[1];
            uVar21 = *puVar22;
            if ((uint64_t)((int64_t)piVar16 - (int64_t)piVar20) <= *puVar22) {
                uVar21 = (int64_t)piVar16 - (int64_t)piVar20;
            }
            uVar6 = puVar22[-2];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3dd8;
            func_0x000180498030(*(undefined8 *)((int64_t)&arg_78h + iVar10), uVar14 + uVar6, uVar21);
            *(int64_t *)((int64_t)&arg_78h + iVar10) = *(int64_t *)((int64_t)&arg_78h + iVar10) + uVar21;
            iVar8 = *(int32_t *)((int64_t)&arg_88h + iVar10);
            uVar14 = uVar21;
            if (iVar8 == 0) {
code_r0x0001801a3df8:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e04;
                iVar8 = func_0x0001801a4880(piVar18, puVar22 + -4, uVar14);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                iVar8 = *(int32_t *)((int64_t)&arg_88h + iVar10);
            } else if (*puVar22 == 0) {
                uVar14 = 0;
                goto code_r0x0001801a3df8;
            }
            if ((*puVar22 == 0) || ((iVar8 != 0 && (uVar21 == *puVar22)))) {
                puVar22 = puVar22 + 8;
                uVar12 = uVar12 + 1;
            }
            piVar20 = (int32_t *)((int64_t)piVar20 + uVar21);
        } while ((((char)placeholder_1 == '\x17') && (uVar12 < *(uint64_t *)(piVar18 + 0x340))) &&
                (piVar16 = *(int32_t **)((int64_t)&arg_80h + iVar10), piVar20 < piVar16));
        if (piVar20 != (int32_t *)0x0) {
            **(int32_t ***)((int64_t)&arg_90h + iVar10) = piVar20;
            return 1;
        }
code_r0x0001801a3e57:
        piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
        arg3 = *(undefined8 *)((int64_t)&arg_70h + iVar10);
    }
    if (piVar20[2] == 2) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41ce;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41e6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
        goto code_r0x0001801a421b;
    }
    if (**(int32_t **)(placeholder_0 + 6) == 0x10000) {
        if ((piVar18[0x1e] != 0) || (cVar2 != '\x15')) {
            piVar18[0x12] = piVar20[2];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3906;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a391e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
code_r0x0001801a3932:
        uVar12 = *(uint64_t *)(piVar20 + 8);
        if (((0x7fffffffffffffff < uVar12) || (uVar12 == 0)) ||
           ((cVar2 = *(char *)(*(int64_t *)(piVar20 + 10) + *(int64_t *)(piVar20 + 4)), uVar12 == 1 ||
            (uVar3 = ((char *)(*(int64_t *)(piVar20 + 10) + *(int64_t *)(piVar20 + 4)))[1], uVar12 != 2)))) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a405c;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4074;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        pcVar4 = *(code **)(piVar18 + 0x13e);
        if (pcVar4 != (code *)0x0) {
            iVar8 = piVar18[0x12];
            *(undefined8 *)(&stack0x00000000 + iVar10) = *(undefined8 *)(piVar18 + 0x140);
            *(int32_t **)((int64_t)&var_8h + iVar10) = placeholder_0;
            *(undefined8 *)((int64_t)&var_10h + iVar10) = 2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a39a1;
            (*pcVar4)(0, iVar8, 0x15);
        }
        piVar13 = *(int32_t **)(piVar18 + 0x256);
        *(int32_t **)((int64_t)&arg_60h + iVar10) = piVar13;
        uVar19 = (uint32_t)uVar3;
        if (piVar13 == (int32_t *)0x0) {
            piVar13 = *(int32_t **)(*(int64_t *)(placeholder_0 + 2) + 0x120);
            *(int32_t **)((int64_t)&arg_60h + iVar10) = piVar13;
            if ((piVar13 != (int32_t *)0x0) ||
               (*(int32_t **)((int64_t)&arg_60h + iVar10) = piVar16, piVar13 = piVar16, piVar16 != (int32_t *)0x0))
            goto code_r0x0001801a39dd;
        } else {
code_r0x0001801a39dd:
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a39f1;
            (*(code *)piVar13)(placeholder_0, 0x4004, CONCAT11(cVar2, uVar3));
        }
        iVar8 = *(int32_t *)((int64_t)&arg_68h + iVar10);
        if (iVar8 == 0) {
            if (cVar2 == '\x01') {
code_r0x0001801a3a0a:
                piVar18[0x6f] = uVar19;
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3a1e;
                iVar9 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar9 == 0) {
                    return 0xffffffff;
                }
                piVar18[0x334] = piVar18[0x334] + 1;
                if (piVar18[0x334] == 5) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f7d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f95;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                  *(int64_t *)((int64_t)&var_20h + iVar10));
                    goto code_r0x0001801a421b;
                }
                if (iVar8 != 0) goto code_r0x0001801a3a41;
            }
        } else {
            if (uVar19 == 0x5a) goto code_r0x0001801a3a0a;
code_r0x0001801a3a41:
            if (uVar19 == 0x5a) {
                arg3 = *(undefined8 *)((int64_t)&arg_70h + iVar10);
                piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                goto code_r0x0001801a3740;
            }
            iVar8 = *(int32_t *)((int64_t)&arg_68h + iVar10);
        }
        if ((uVar19 == 0) && ((iVar8 != 0 || (cVar2 == '\x01')))) {
            piVar18[0x21] = piVar18[0x21] | 2;
            return 0;
        }
        if ((cVar2 == '\x02') || (iVar8 != 0)) {
            piVar18[0x1a] = 1;
            piVar18[0x70] = uVar19;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3feb;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4003;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            *(uint32_t *)((int64_t)&var_10h + iVar10) = uVar19;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4022;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            piVar18[0x21] = piVar18[0x21] | 2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4037;
            iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
            if (iVar8 == 0) {
                return 0xffffffff;
            }
            uVar15 = *(undefined8 *)(piVar18 + 0x23e);
            uVar7 = *(undefined8 *)(piVar18 + 0x2e2);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4052;
            func_0x00018019c8a0(uVar7, uVar15);
            return 0;
        }
        if (uVar19 != 100) {
            if (cVar2 != '\x01') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3aa0;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ab8;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
            goto code_r0x0001801a3e57;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3fb1;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3fc9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
    } else {
        if (cVar2 == '\x15') goto code_r0x0001801a3932;
        if ((piVar18[0x21] & 1U) != 0) {
            if (cVar2 != '\x16') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a408d;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a409a;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40b2;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) != 0) ||
                (iVar8 = **(int32_t **)(piVar18 + 6), iVar8 < 0x304)) || (iVar8 == 0x10000)) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b06;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                if ((*(uint8_t *)(piVar18 + 0x26c) & 4) == 0) goto code_r0x0001801a40c2;
                piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                goto code_r0x0001801a3740;
            }
        }
        if (*(char *)(piVar20 + 3) == '\x16') {
            iVar11 = *(int64_t *)(piVar18 + 0x32c);
            uVar14 = 4 - iVar11;
            uVar12 = *(uint64_t *)(piVar20 + 8);
            if (uVar14 <= *(uint64_t *)(piVar20 + 8)) {
                uVar12 = uVar14;
            }
            if (uVar12 == 0) {
                if (*(int64_t *)(piVar20 + 8) == 0) goto code_r0x0001801a3b80;
            } else {
                iVar17 = *(int64_t *)(piVar20 + 10);
                iVar5 = *(int64_t *)(piVar20 + 4);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b71;
                func_0x000180498030(iVar11 + 0xca8 + (int64_t)piVar18, iVar17 + iVar5, uVar12);
                *(uint64_t *)(piVar18 + 0x32c) = *(int64_t *)(piVar18 + 0x32c) + uVar12;
code_r0x0001801a3b80:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b8e;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, uVar12);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
            }
            piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
            if (*(uint64_t *)(piVar18 + 0x32c) < 4) goto code_r0x0001801a3740;
        }
        if (*(char *)(piVar20 + 3) == '\x14') {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41c2;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            goto code_r0x0001801a41fd;
        }
        if (3 < *(uint64_t *)(piVar18 + 0x32c)) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bd6;
            iVar8 = func_0x00018019b680(piVar18);
            if (iVar8 != 0) goto code_r0x0001801a3c57;
            iVar8 = piVar18[0x3c];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bed;
            func_0x00018019b750(piVar18, 1);
            pcVar4 = *(code **)(piVar18 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bf6;
            uVar12 = (*pcVar4)(placeholder_0);
            if ((int32_t)uVar12 < 0) {
                return uVar12;
            }
            if ((int32_t)uVar12 == 0) {
                return 0xffffffff;
            }
            if (iVar8 == 0xb) {
                return 0xffffffff;
            }
            piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
            if ((*(uint8_t *)(piVar18 + 0x26c) & 4) == 0) {
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x10);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c40;
                iVar8 = (*pcVar4)(uVar15);
                if (iVar8 == 0) {
code_r0x0001801a40c2:
                    piVar18[0x1a] = 3;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40d1;
                    uVar15 = func_0x000180193c40(placeholder_0);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40e1;
                    func_0x000180219ce0(uVar15, 0xf);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40ee;
                    func_0x00018021b250(uVar15, 9);
                    return 0xffffffff;
                }
            }
            goto code_r0x0001801a3740;
        }
code_r0x0001801a3c57:
        cVar2 = *(char *)(piVar20 + 3);
        if (((cVar2 != '\x14') && (cVar2 != '\x15')) && (cVar2 != '\x16')) {
            if (cVar2 == '\x17') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c87;
                iVar8 = func_0x00018019b380(piVar18);
                if (iVar8 != 0) {
                    piVar18[0x76] = 2;
                    return 0xffffffff;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c97;
                iVar8 = func_0x00018019b800(piVar18);
                if (iVar8 != 0) {
                    iVar11 = *(int64_t *)(piVar20 + 8);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3cab;
                    iVar8 = fcn.1801a3200(piVar18);
                    if ((iVar8 == 0) || ((uint64_t)(iVar8 + 0x68) < iVar11 + (uint64_t)(uint32_t)piVar18[0x550])) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4123;
                        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10))
                        ;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4131;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10)
                                      , *(int64_t *)(&stack0x00000000 + iVar10), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                      *(int64_t *)((int64_t)&var_20h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4141;
                        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
                        return 0xffffffff;
                    }
                    piVar18[0x550] = piVar18[0x550] + (int32_t)iVar11;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ce2;
                    iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                    if (iVar8 == 0) {
                        return 0xffffffff;
                    }
                    piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                    goto code_r0x0001801a3740;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4150;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a418c;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4168;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4198;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41b0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
    }
code_r0x0001801a421b:
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4226;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801a36de
// Address: 0x1801a36de
// Size: 2964 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel

uint64_t fcn.1801a3550(int32_t *placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_60h,
                      int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                      int64_t arg_90h)
{
    undefined uVar1;
    char cVar2;
    uint8_t uVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int32_t *piVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    int32_t *piVar16;
    int64_t iVar17;
    int32_t *piVar18;
    uint32_t uVar19;
    int32_t *piVar20;
    undefined8 unaff_RSI;
    uint64_t uVar21;
    undefined8 unaff_RDI;
    uint64_t *puVar22;
    int32_t *piVar23;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_38 = 0x1801a356e;
    var_18h = arg3;
    var_20h = arg4;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar23 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&arg_60h + iVar10) = 0;
    piVar18 = piVar23;
    if ((placeholder_0 != (int32_t *)0x0) && (piVar18 = (int32_t *)0x0, *placeholder_0 == 0)) {
        piVar18 = placeholder_0;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) != 0) ||
        (iVar8 = **(int32_t **)(piVar18 + 6), iVar8 < 0x304)) ||
       (*(undefined4 *)((int64_t)&arg_68h + iVar10) = 1, iVar8 == 0x10000)) {
        *(undefined4 *)((int64_t)&arg_68h + iVar10) = 0;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_RDI;
    if (((char)placeholder_1 != '\0') && (1 < (uint8_t)((char)placeholder_1 - 0x16U))) {
code_r0x0001801a35f4:
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a35f9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3611;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3627;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
        return 0xffffffff;
    }
    if (*(int32_t *)((int64_t)&arg_88h + iVar10) == 0) {
        if (((char)placeholder_1 == '\x16') && (iVar11 = *(int64_t *)(piVar18 + 0x32c), iVar11 != 0)) {
            iVar17 = *(int64_t *)((int64_t)&arg_80h + iVar10);
            piVar16 = piVar18 + 0x32a;
            piVar20 = piVar23;
            if (iVar17 != 0) {
                arg4 = arg4 - (int64_t)piVar16;
                do {
                    if (iVar11 == 0) break;
                    piVar20 = (int32_t *)((int64_t)piVar20 + 1);
                    *(undefined *)(arg4 + (int64_t)piVar16) = *(undefined *)piVar16;
                    piVar16 = (int32_t *)((int64_t)piVar16 + 1);
                    *(int64_t *)(piVar18 + 0x32c) = *(int64_t *)(piVar18 + 0x32c) + -1;
                    iVar11 = *(int64_t *)(piVar18 + 0x32c);
                    iVar17 = iVar17 + -1;
                } while (iVar17 != 0);
            }
            if (iVar11 != 0) {
                do {
                    uVar1 = *(undefined *)piVar16;
                    piVar16 = (int32_t *)((int64_t)piVar16 + 1);
                    piVar13 = (int32_t *)(uint64_t)((int32_t)piVar23 + 1);
                    *(undefined *)((int64_t)(piVar23 + 0x32a) + (int64_t)piVar18) = uVar1;
                    piVar23 = piVar13;
                } while (piVar13 < *(int32_t **)(piVar18 + 0x32c));
            }
            if ((undefined *)arg3 != (undefined *)0x0) {
                *(undefined *)arg3 = 0x16;
            }
            **(int32_t ***)((int64_t)&arg_90h + iVar10) = piVar20;
            return 1;
        }
    } else if ((char)placeholder_1 != '\x17') goto code_r0x0001801a35f4;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a36e8;
    iVar8 = func_0x00018019b680(piVar18);
    piVar16 = piVar23;
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a36f8;
        iVar8 = func_0x00018019b2a0(placeholder_0);
        piVar16 = (int32_t *)0x0;
        if (iVar8 != 0) {
            pcVar4 = *(code **)(piVar18 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3709;
            uVar12 = (*pcVar4)(placeholder_0);
            if ((int32_t)uVar12 < 0) {
                return uVar12;
            }
            piVar16 = piVar23;
            if ((int32_t)uVar12 == 0) {
                return 0xffffffff;
            }
        }
    }
code_r0x0001801a3740:
    while( true ) {
        piVar18[0x1a] = 1;
        if (*(uint64_t *)(piVar18 + 0x340) <= *(uint64_t *)(piVar18 + 0x342)) {
            *(undefined8 *)(piVar18 + 0x340) = 0;
            *(undefined8 *)(piVar18 + 0x342) = 0;
            piVar20 = piVar23;
            do {
                *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
                *(undefined8 *)(&stack0x00000000 + iVar10) = 0;
                piVar20 = piVar18 + (int64_t)piVar20 * 0x10 + 0x344;
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x40);
                *(int32_t **)((int64_t)&var_8h + iVar10) = piVar20 + 8;
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                *(int32_t **)((int64_t)&var_10h + iVar10) = piVar20 + 4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a37ba;
                uVar12 = (*pcVar4)(uVar15, piVar20, piVar20 + 2, piVar20 + 3);
                iVar8 = (int32_t)uVar12;
                if (iVar8 == 0) {
                    piVar18[0x1a] = 3;
                    return 0xffffffff;
                }
                piVar18[0x1a] = 1;
                if (iVar8 == -3) {
                    if ((*(uint8_t *)(piVar18 + 0x26a) & 0x80) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ee5;
                        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10))
                        ;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ef9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10)
                                      , *(int64_t *)(&stack0x00000000 + iVar10), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                      *(int64_t *)((int64_t)&var_20h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f0f;
                        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ed1;
                    fcn.180194c30(piVar18, 2);
                    piVar18[0x6f] = 0;
                    return 0;
                }
                if (iVar8 == -2) {
                    uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                    pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e8a;
                    iVar8 = (*pcVar4)(uVar15);
                    if (iVar8 == -1) {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e9a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3eae;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                  *(int64_t *)((int64_t)&var_20h + iVar10));
                    goto code_r0x0001801a421b;
                }
                if (iVar8 == -1) {
                    return 0;
                }
                if (iVar8 < -1) {
                    return 0xffffffff;
                }
                if (iVar8 < 1) {
                    return uVar12;
                }
                *(undefined8 *)(piVar20 + 10) = 0;
                *(int64_t *)(piVar18 + 0x340) = *(int64_t *)(piVar18 + 0x340) + 1;
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x18);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3811;
                iVar8 = (*pcVar4)(uVar15);
            } while ((iVar8 != 0) && (piVar20 = *(int32_t **)(piVar18 + 0x340), piVar20 < (int32_t *)0x20));
        }
        piVar20 = piVar18 + *(int64_t *)(piVar18 + 0x342) * 0x10 + 0x344;
        if ((*(int64_t *)(piVar18 + 0x32c) != 0) &&
           ((((*(char *)(piVar20 + 3) != '\x16' &&
              ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) == 0)) &&
             (iVar8 = **(int32_t **)(piVar18 + 6), 0x303 < iVar8)) && (iVar8 != 0x10000)))) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f2d;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f45;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        if ((*(char *)(piVar20 + 3) != '\x15') && (*(int64_t *)(piVar20 + 8) != 0)) {
            piVar18[0x334] = 0;
        }
        if ((piVar18[0x6e] != 0) && (*(char *)(piVar20 + 3) != '\x16')) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f55;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f6d;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        if ((piVar18[0x21] & 2U) != 0) {
            *(int64_t *)(piVar18 + 0x342) = *(int64_t *)(piVar18 + 0x342) + 1;
            piVar18[0x1a] = 1;
            return 0;
        }
        cVar2 = *(char *)(piVar20 + 3);
        if (((char)placeholder_1 != cVar2) &&
           ((((cVar2 != '\x14' || ((char)placeholder_1 != '\x16')) || ((undefined *)arg3 == (undefined *)0x0)) ||
            (*(int32_t *)((int64_t)&arg_68h + iVar10) != 0)))) break;
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d09;
        iVar8 = func_0x00018019b2a0(placeholder_0);
        if ((iVar8 == 0) || ((char)placeholder_1 != '\x17')) {
            if (((char)placeholder_1 == '\x16') &&
               ((*(char *)(piVar20 + 3) == '\x14' && (*(int64_t *)(piVar18 + 0x32c) != 0)))) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41f8;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
code_r0x0001801a41fd:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4210;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
        } else if ((*(int64_t *)(piVar18 + 0x98) == 0) || (*(int64_t *)(piVar18 + 0xba) == 0)) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d2a;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d42;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d58;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            return 0xffffffff;
        }
        if ((undefined *)arg3 != (undefined *)0x0) {
            *(undefined *)arg3 = *(undefined *)(piVar20 + 3);
        }
        piVar16 = *(int32_t **)((int64_t)&arg_80h + iVar10);
        if (piVar16 == (int32_t *)0x0) {
            if (*(int64_t *)(piVar20 + 8) != 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4253;
            iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
            return (uint64_t)((iVar8 != 0) - 1);
        }
        uVar12 = *(uint64_t *)(piVar18 + 0x342);
        puVar22 = (uint64_t *)(piVar20 + 8);
        piVar20 = piVar23;
        do {
            uVar14 = puVar22[1];
            uVar21 = *puVar22;
            if ((uint64_t)((int64_t)piVar16 - (int64_t)piVar20) <= *puVar22) {
                uVar21 = (int64_t)piVar16 - (int64_t)piVar20;
            }
            uVar6 = puVar22[-2];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3dd8;
            func_0x000180498030(*(undefined8 *)((int64_t)&arg_78h + iVar10), uVar14 + uVar6, uVar21);
            *(int64_t *)((int64_t)&arg_78h + iVar10) = *(int64_t *)((int64_t)&arg_78h + iVar10) + uVar21;
            iVar8 = *(int32_t *)((int64_t)&arg_88h + iVar10);
            uVar14 = uVar21;
            if (iVar8 == 0) {
code_r0x0001801a3df8:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e04;
                iVar8 = func_0x0001801a4880(piVar18, puVar22 + -4, uVar14);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                iVar8 = *(int32_t *)((int64_t)&arg_88h + iVar10);
            } else if (*puVar22 == 0) {
                uVar14 = 0;
                goto code_r0x0001801a3df8;
            }
            if ((*puVar22 == 0) || ((iVar8 != 0 && (uVar21 == *puVar22)))) {
                puVar22 = puVar22 + 8;
                uVar12 = uVar12 + 1;
            }
            piVar20 = (int32_t *)((int64_t)piVar20 + uVar21);
        } while ((((char)placeholder_1 == '\x17') && (uVar12 < *(uint64_t *)(piVar18 + 0x340))) &&
                (piVar16 = *(int32_t **)((int64_t)&arg_80h + iVar10), piVar20 < piVar16));
        if (piVar20 != (int32_t *)0x0) {
            **(int32_t ***)((int64_t)&arg_90h + iVar10) = piVar20;
            return 1;
        }
code_r0x0001801a3e57:
        piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
        arg3 = *(undefined8 *)((int64_t)&arg_70h + iVar10);
    }
    if (piVar20[2] == 2) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41ce;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41e6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
        goto code_r0x0001801a421b;
    }
    if (**(int32_t **)(placeholder_0 + 6) == 0x10000) {
        if ((piVar18[0x1e] != 0) || (cVar2 != '\x15')) {
            piVar18[0x12] = piVar20[2];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3906;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a391e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
code_r0x0001801a3932:
        uVar12 = *(uint64_t *)(piVar20 + 8);
        if (((0x7fffffffffffffff < uVar12) || (uVar12 == 0)) ||
           ((cVar2 = *(char *)(*(int64_t *)(piVar20 + 10) + *(int64_t *)(piVar20 + 4)), uVar12 == 1 ||
            (uVar3 = ((char *)(*(int64_t *)(piVar20 + 10) + *(int64_t *)(piVar20 + 4)))[1], uVar12 != 2)))) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a405c;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4074;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        pcVar4 = *(code **)(piVar18 + 0x13e);
        if (pcVar4 != (code *)0x0) {
            iVar8 = piVar18[0x12];
            *(undefined8 *)(&stack0x00000000 + iVar10) = *(undefined8 *)(piVar18 + 0x140);
            *(int32_t **)((int64_t)&var_8h + iVar10) = placeholder_0;
            *(undefined8 *)((int64_t)&var_10h + iVar10) = 2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a39a1;
            (*pcVar4)(0, iVar8, 0x15);
        }
        piVar13 = *(int32_t **)(piVar18 + 0x256);
        *(int32_t **)((int64_t)&arg_60h + iVar10) = piVar13;
        uVar19 = (uint32_t)uVar3;
        if (piVar13 == (int32_t *)0x0) {
            piVar13 = *(int32_t **)(*(int64_t *)(placeholder_0 + 2) + 0x120);
            *(int32_t **)((int64_t)&arg_60h + iVar10) = piVar13;
            if ((piVar13 != (int32_t *)0x0) ||
               (*(int32_t **)((int64_t)&arg_60h + iVar10) = piVar16, piVar13 = piVar16, piVar16 != (int32_t *)0x0))
            goto code_r0x0001801a39dd;
        } else {
code_r0x0001801a39dd:
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a39f1;
            (*(code *)piVar13)(placeholder_0, 0x4004, CONCAT11(cVar2, uVar3));
        }
        iVar8 = *(int32_t *)((int64_t)&arg_68h + iVar10);
        if (iVar8 == 0) {
            if (cVar2 == '\x01') {
code_r0x0001801a3a0a:
                piVar18[0x6f] = uVar19;
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3a1e;
                iVar9 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar9 == 0) {
                    return 0xffffffff;
                }
                piVar18[0x334] = piVar18[0x334] + 1;
                if (piVar18[0x334] == 5) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f7d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f95;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                  *(int64_t *)((int64_t)&var_20h + iVar10));
                    goto code_r0x0001801a421b;
                }
                if (iVar8 != 0) goto code_r0x0001801a3a41;
            }
        } else {
            if (uVar19 == 0x5a) goto code_r0x0001801a3a0a;
code_r0x0001801a3a41:
            if (uVar19 == 0x5a) {
                arg3 = *(undefined8 *)((int64_t)&arg_70h + iVar10);
                piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                goto code_r0x0001801a3740;
            }
            iVar8 = *(int32_t *)((int64_t)&arg_68h + iVar10);
        }
        if ((uVar19 == 0) && ((iVar8 != 0 || (cVar2 == '\x01')))) {
            piVar18[0x21] = piVar18[0x21] | 2;
            return 0;
        }
        if ((cVar2 == '\x02') || (iVar8 != 0)) {
            piVar18[0x1a] = 1;
            piVar18[0x70] = uVar19;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3feb;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4003;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            *(uint32_t *)((int64_t)&var_10h + iVar10) = uVar19;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4022;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            piVar18[0x21] = piVar18[0x21] | 2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4037;
            iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
            if (iVar8 == 0) {
                return 0xffffffff;
            }
            uVar15 = *(undefined8 *)(piVar18 + 0x23e);
            uVar7 = *(undefined8 *)(piVar18 + 0x2e2);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4052;
            func_0x00018019c8a0(uVar7, uVar15);
            return 0;
        }
        if (uVar19 != 100) {
            if (cVar2 != '\x01') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3aa0;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ab8;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
            goto code_r0x0001801a3e57;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3fb1;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3fc9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
    } else {
        if (cVar2 == '\x15') goto code_r0x0001801a3932;
        if ((piVar18[0x21] & 1U) != 0) {
            if (cVar2 != '\x16') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a408d;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a409a;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40b2;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) != 0) ||
                (iVar8 = **(int32_t **)(piVar18 + 6), iVar8 < 0x304)) || (iVar8 == 0x10000)) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b06;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                if ((*(uint8_t *)(piVar18 + 0x26c) & 4) == 0) goto code_r0x0001801a40c2;
                piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                goto code_r0x0001801a3740;
            }
        }
        if (*(char *)(piVar20 + 3) == '\x16') {
            iVar11 = *(int64_t *)(piVar18 + 0x32c);
            uVar14 = 4 - iVar11;
            uVar12 = *(uint64_t *)(piVar20 + 8);
            if (uVar14 <= *(uint64_t *)(piVar20 + 8)) {
                uVar12 = uVar14;
            }
            if (uVar12 == 0) {
                if (*(int64_t *)(piVar20 + 8) == 0) goto code_r0x0001801a3b80;
            } else {
                iVar17 = *(int64_t *)(piVar20 + 10);
                iVar5 = *(int64_t *)(piVar20 + 4);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b71;
                func_0x000180498030(iVar11 + 0xca8 + (int64_t)piVar18, iVar17 + iVar5, uVar12);
                *(uint64_t *)(piVar18 + 0x32c) = *(int64_t *)(piVar18 + 0x32c) + uVar12;
code_r0x0001801a3b80:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b8e;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, uVar12);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
            }
            piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
            if (*(uint64_t *)(piVar18 + 0x32c) < 4) goto code_r0x0001801a3740;
        }
        if (*(char *)(piVar20 + 3) == '\x14') {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41c2;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            goto code_r0x0001801a41fd;
        }
        if (3 < *(uint64_t *)(piVar18 + 0x32c)) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bd6;
            iVar8 = func_0x00018019b680(piVar18);
            if (iVar8 != 0) goto code_r0x0001801a3c57;
            iVar8 = piVar18[0x3c];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bed;
            func_0x00018019b750(piVar18, 1);
            pcVar4 = *(code **)(piVar18 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bf6;
            uVar12 = (*pcVar4)(placeholder_0);
            if ((int32_t)uVar12 < 0) {
                return uVar12;
            }
            if ((int32_t)uVar12 == 0) {
                return 0xffffffff;
            }
            if (iVar8 == 0xb) {
                return 0xffffffff;
            }
            piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
            if ((*(uint8_t *)(piVar18 + 0x26c) & 4) == 0) {
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x10);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c40;
                iVar8 = (*pcVar4)(uVar15);
                if (iVar8 == 0) {
code_r0x0001801a40c2:
                    piVar18[0x1a] = 3;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40d1;
                    uVar15 = func_0x000180193c40(placeholder_0);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40e1;
                    func_0x000180219ce0(uVar15, 0xf);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40ee;
                    func_0x00018021b250(uVar15, 9);
                    return 0xffffffff;
                }
            }
            goto code_r0x0001801a3740;
        }
code_r0x0001801a3c57:
        cVar2 = *(char *)(piVar20 + 3);
        if (((cVar2 != '\x14') && (cVar2 != '\x15')) && (cVar2 != '\x16')) {
            if (cVar2 == '\x17') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c87;
                iVar8 = func_0x00018019b380(piVar18);
                if (iVar8 != 0) {
                    piVar18[0x76] = 2;
                    return 0xffffffff;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c97;
                iVar8 = func_0x00018019b800(piVar18);
                if (iVar8 != 0) {
                    iVar11 = *(int64_t *)(piVar20 + 8);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3cab;
                    iVar8 = fcn.1801a3200(piVar18);
                    if ((iVar8 == 0) || ((uint64_t)(iVar8 + 0x68) < iVar11 + (uint64_t)(uint32_t)piVar18[0x550])) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4123;
                        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10))
                        ;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4131;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10)
                                      , *(int64_t *)(&stack0x00000000 + iVar10), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                      *(int64_t *)((int64_t)&var_20h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4141;
                        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
                        return 0xffffffff;
                    }
                    piVar18[0x550] = piVar18[0x550] + (int32_t)iVar11;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ce2;
                    iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                    if (iVar8 == 0) {
                        return 0xffffffff;
                    }
                    piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                    goto code_r0x0001801a3740;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4150;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a418c;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4168;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4198;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41b0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
    }
code_r0x0001801a421b:
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4226;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801a4272
// Address: 0x1801a4272
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel

uint64_t fcn.1801a3550(int32_t *placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_60h,
                      int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h,
                      int64_t arg_90h)
{
    undefined uVar1;
    char cVar2;
    uint8_t uVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int32_t *piVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    int32_t *piVar16;
    int64_t iVar17;
    int32_t *piVar18;
    uint32_t uVar19;
    int32_t *piVar20;
    undefined8 unaff_RSI;
    uint64_t uVar21;
    undefined8 unaff_RDI;
    uint64_t *puVar22;
    int32_t *piVar23;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_38 = 0x1801a356e;
    var_18h = arg3;
    var_20h = arg4;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar23 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&arg_60h + iVar10) = 0;
    piVar18 = piVar23;
    if ((placeholder_0 != (int32_t *)0x0) && (piVar18 = (int32_t *)0x0, *placeholder_0 == 0)) {
        piVar18 = placeholder_0;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) != 0) ||
        (iVar8 = **(int32_t **)(piVar18 + 6), iVar8 < 0x304)) ||
       (*(undefined4 *)((int64_t)&arg_68h + iVar10) = 1, iVar8 == 0x10000)) {
        *(undefined4 *)((int64_t)&arg_68h + iVar10) = 0;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_RDI;
    if (((char)placeholder_1 != '\0') && (1 < (uint8_t)((char)placeholder_1 - 0x16U))) {
code_r0x0001801a35f4:
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a35f9;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3611;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3627;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
        return 0xffffffff;
    }
    if (*(int32_t *)((int64_t)&arg_88h + iVar10) == 0) {
        if (((char)placeholder_1 == '\x16') && (iVar11 = *(int64_t *)(piVar18 + 0x32c), iVar11 != 0)) {
            iVar17 = *(int64_t *)((int64_t)&arg_80h + iVar10);
            piVar16 = piVar18 + 0x32a;
            piVar20 = piVar23;
            if (iVar17 != 0) {
                arg4 = arg4 - (int64_t)piVar16;
                do {
                    if (iVar11 == 0) break;
                    piVar20 = (int32_t *)((int64_t)piVar20 + 1);
                    *(undefined *)(arg4 + (int64_t)piVar16) = *(undefined *)piVar16;
                    piVar16 = (int32_t *)((int64_t)piVar16 + 1);
                    *(int64_t *)(piVar18 + 0x32c) = *(int64_t *)(piVar18 + 0x32c) + -1;
                    iVar11 = *(int64_t *)(piVar18 + 0x32c);
                    iVar17 = iVar17 + -1;
                } while (iVar17 != 0);
            }
            if (iVar11 != 0) {
                do {
                    uVar1 = *(undefined *)piVar16;
                    piVar16 = (int32_t *)((int64_t)piVar16 + 1);
                    piVar13 = (int32_t *)(uint64_t)((int32_t)piVar23 + 1);
                    *(undefined *)((int64_t)(piVar23 + 0x32a) + (int64_t)piVar18) = uVar1;
                    piVar23 = piVar13;
                } while (piVar13 < *(int32_t **)(piVar18 + 0x32c));
            }
            if ((undefined *)arg3 != (undefined *)0x0) {
                *(undefined *)arg3 = 0x16;
            }
            **(int32_t ***)((int64_t)&arg_90h + iVar10) = piVar20;
            return 1;
        }
    } else if ((char)placeholder_1 != '\x17') goto code_r0x0001801a35f4;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a36e8;
    iVar8 = func_0x00018019b680(piVar18);
    piVar16 = piVar23;
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a36f8;
        iVar8 = func_0x00018019b2a0(placeholder_0);
        piVar16 = (int32_t *)0x0;
        if (iVar8 != 0) {
            pcVar4 = *(code **)(piVar18 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3709;
            uVar12 = (*pcVar4)(placeholder_0);
            if ((int32_t)uVar12 < 0) {
                return uVar12;
            }
            piVar16 = piVar23;
            if ((int32_t)uVar12 == 0) {
                return 0xffffffff;
            }
        }
    }
code_r0x0001801a3740:
    while( true ) {
        piVar18[0x1a] = 1;
        if (*(uint64_t *)(piVar18 + 0x340) <= *(uint64_t *)(piVar18 + 0x342)) {
            *(undefined8 *)(piVar18 + 0x340) = 0;
            *(undefined8 *)(piVar18 + 0x342) = 0;
            piVar20 = piVar23;
            do {
                *(undefined8 *)((int64_t)aiStackX_8 + iVar10) = 0;
                *(undefined8 *)(&stack0x00000000 + iVar10) = 0;
                piVar20 = piVar18 + (int64_t)piVar20 * 0x10 + 0x344;
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x40);
                *(int32_t **)((int64_t)&var_8h + iVar10) = piVar20 + 8;
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                *(int32_t **)((int64_t)&var_10h + iVar10) = piVar20 + 4;
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a37ba;
                uVar12 = (*pcVar4)(uVar15, piVar20, piVar20 + 2, piVar20 + 3);
                iVar8 = (int32_t)uVar12;
                if (iVar8 == 0) {
                    piVar18[0x1a] = 3;
                    return 0xffffffff;
                }
                piVar18[0x1a] = 1;
                if (iVar8 == -3) {
                    if ((*(uint8_t *)(piVar18 + 0x26a) & 0x80) == 0) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ee5;
                        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10))
                        ;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ef9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10)
                                      , *(int64_t *)(&stack0x00000000 + iVar10), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                      *(int64_t *)((int64_t)&var_20h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f0f;
                        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ed1;
                    fcn.180194c30(piVar18, 2);
                    piVar18[0x6f] = 0;
                    return 0;
                }
                if (iVar8 == -2) {
                    uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                    pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e8a;
                    iVar8 = (*pcVar4)(uVar15);
                    if (iVar8 == -1) {
                        return 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e9a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3eae;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                  *(int64_t *)((int64_t)&var_20h + iVar10));
                    goto code_r0x0001801a421b;
                }
                if (iVar8 == -1) {
                    return 0;
                }
                if (iVar8 < -1) {
                    return 0xffffffff;
                }
                if (iVar8 < 1) {
                    return uVar12;
                }
                *(undefined8 *)(piVar20 + 10) = 0;
                *(int64_t *)(piVar18 + 0x340) = *(int64_t *)(piVar18 + 0x340) + 1;
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x18);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3811;
                iVar8 = (*pcVar4)(uVar15);
            } while ((iVar8 != 0) && (piVar20 = *(int32_t **)(piVar18 + 0x340), piVar20 < (int32_t *)0x20));
        }
        piVar20 = piVar18 + *(int64_t *)(piVar18 + 0x342) * 0x10 + 0x344;
        if ((*(int64_t *)(piVar18 + 0x32c) != 0) &&
           ((((*(char *)(piVar20 + 3) != '\x16' &&
              ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) == 0)) &&
             (iVar8 = **(int32_t **)(piVar18 + 6), 0x303 < iVar8)) && (iVar8 != 0x10000)))) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f2d;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f45;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        if ((*(char *)(piVar20 + 3) != '\x15') && (*(int64_t *)(piVar20 + 8) != 0)) {
            piVar18[0x334] = 0;
        }
        if ((piVar18[0x6e] != 0) && (*(char *)(piVar20 + 3) != '\x16')) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f55;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f6d;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        if ((piVar18[0x21] & 2U) != 0) {
            *(int64_t *)(piVar18 + 0x342) = *(int64_t *)(piVar18 + 0x342) + 1;
            piVar18[0x1a] = 1;
            return 0;
        }
        cVar2 = *(char *)(piVar20 + 3);
        if (((char)placeholder_1 != cVar2) &&
           ((((cVar2 != '\x14' || ((char)placeholder_1 != '\x16')) || ((undefined *)arg3 == (undefined *)0x0)) ||
            (*(int32_t *)((int64_t)&arg_68h + iVar10) != 0)))) break;
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d09;
        iVar8 = func_0x00018019b2a0(placeholder_0);
        if ((iVar8 == 0) || ((char)placeholder_1 != '\x17')) {
            if (((char)placeholder_1 == '\x16') &&
               ((*(char *)(piVar20 + 3) == '\x14' && (*(int64_t *)(piVar18 + 0x32c) != 0)))) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41f8;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
code_r0x0001801a41fd:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4210;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
        } else if ((*(int64_t *)(piVar18 + 0x98) == 0) || (*(int64_t *)(piVar18 + 0xba) == 0)) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d2a;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d42;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3d58;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            return 0xffffffff;
        }
        if ((undefined *)arg3 != (undefined *)0x0) {
            *(undefined *)arg3 = *(undefined *)(piVar20 + 3);
        }
        piVar16 = *(int32_t **)((int64_t)&arg_80h + iVar10);
        if (piVar16 == (int32_t *)0x0) {
            if (*(int64_t *)(piVar20 + 8) != 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4253;
            iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
            return (uint64_t)((iVar8 != 0) - 1);
        }
        uVar12 = *(uint64_t *)(piVar18 + 0x342);
        puVar22 = (uint64_t *)(piVar20 + 8);
        piVar20 = piVar23;
        do {
            uVar14 = puVar22[1];
            uVar21 = *puVar22;
            if ((uint64_t)((int64_t)piVar16 - (int64_t)piVar20) <= *puVar22) {
                uVar21 = (int64_t)piVar16 - (int64_t)piVar20;
            }
            uVar6 = puVar22[-2];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3dd8;
            func_0x000180498030(*(undefined8 *)((int64_t)&arg_78h + iVar10), uVar14 + uVar6, uVar21);
            *(int64_t *)((int64_t)&arg_78h + iVar10) = *(int64_t *)((int64_t)&arg_78h + iVar10) + uVar21;
            iVar8 = *(int32_t *)((int64_t)&arg_88h + iVar10);
            uVar14 = uVar21;
            if (iVar8 == 0) {
code_r0x0001801a3df8:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3e04;
                iVar8 = func_0x0001801a4880(piVar18, puVar22 + -4, uVar14);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                iVar8 = *(int32_t *)((int64_t)&arg_88h + iVar10);
            } else if (*puVar22 == 0) {
                uVar14 = 0;
                goto code_r0x0001801a3df8;
            }
            if ((*puVar22 == 0) || ((iVar8 != 0 && (uVar21 == *puVar22)))) {
                puVar22 = puVar22 + 8;
                uVar12 = uVar12 + 1;
            }
            piVar20 = (int32_t *)((int64_t)piVar20 + uVar21);
        } while ((((char)placeholder_1 == '\x17') && (uVar12 < *(uint64_t *)(piVar18 + 0x340))) &&
                (piVar16 = *(int32_t **)((int64_t)&arg_80h + iVar10), piVar20 < piVar16));
        if (piVar20 != (int32_t *)0x0) {
            **(int32_t ***)((int64_t)&arg_90h + iVar10) = piVar20;
            return 1;
        }
code_r0x0001801a3e57:
        piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
        arg3 = *(undefined8 *)((int64_t)&arg_70h + iVar10);
    }
    if (piVar20[2] == 2) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41ce;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41e6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
        goto code_r0x0001801a421b;
    }
    if (**(int32_t **)(placeholder_0 + 6) == 0x10000) {
        if ((piVar18[0x1e] != 0) || (cVar2 != '\x15')) {
            piVar18[0x12] = piVar20[2];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3906;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a391e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
code_r0x0001801a3932:
        uVar12 = *(uint64_t *)(piVar20 + 8);
        if (((0x7fffffffffffffff < uVar12) || (uVar12 == 0)) ||
           ((cVar2 = *(char *)(*(int64_t *)(piVar20 + 10) + *(int64_t *)(piVar20 + 4)), uVar12 == 1 ||
            (uVar3 = ((char *)(*(int64_t *)(piVar20 + 10) + *(int64_t *)(piVar20 + 4)))[1], uVar12 != 2)))) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a405c;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4074;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        pcVar4 = *(code **)(piVar18 + 0x13e);
        if (pcVar4 != (code *)0x0) {
            iVar8 = piVar18[0x12];
            *(undefined8 *)(&stack0x00000000 + iVar10) = *(undefined8 *)(piVar18 + 0x140);
            *(int32_t **)((int64_t)&var_8h + iVar10) = placeholder_0;
            *(undefined8 *)((int64_t)&var_10h + iVar10) = 2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a39a1;
            (*pcVar4)(0, iVar8, 0x15);
        }
        piVar13 = *(int32_t **)(piVar18 + 0x256);
        *(int32_t **)((int64_t)&arg_60h + iVar10) = piVar13;
        uVar19 = (uint32_t)uVar3;
        if (piVar13 == (int32_t *)0x0) {
            piVar13 = *(int32_t **)(*(int64_t *)(placeholder_0 + 2) + 0x120);
            *(int32_t **)((int64_t)&arg_60h + iVar10) = piVar13;
            if ((piVar13 != (int32_t *)0x0) ||
               (*(int32_t **)((int64_t)&arg_60h + iVar10) = piVar16, piVar13 = piVar16, piVar16 != (int32_t *)0x0))
            goto code_r0x0001801a39dd;
        } else {
code_r0x0001801a39dd:
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a39f1;
            (*(code *)piVar13)(placeholder_0, 0x4004, CONCAT11(cVar2, uVar3));
        }
        iVar8 = *(int32_t *)((int64_t)&arg_68h + iVar10);
        if (iVar8 == 0) {
            if (cVar2 == '\x01') {
code_r0x0001801a3a0a:
                piVar18[0x6f] = uVar19;
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3a1e;
                iVar9 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar9 == 0) {
                    return 0xffffffff;
                }
                piVar18[0x334] = piVar18[0x334] + 1;
                if (piVar18[0x334] == 5) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f7d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3f95;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                  *(int64_t *)((int64_t)&var_20h + iVar10));
                    goto code_r0x0001801a421b;
                }
                if (iVar8 != 0) goto code_r0x0001801a3a41;
            }
        } else {
            if (uVar19 == 0x5a) goto code_r0x0001801a3a0a;
code_r0x0001801a3a41:
            if (uVar19 == 0x5a) {
                arg3 = *(undefined8 *)((int64_t)&arg_70h + iVar10);
                piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                goto code_r0x0001801a3740;
            }
            iVar8 = *(int32_t *)((int64_t)&arg_68h + iVar10);
        }
        if ((uVar19 == 0) && ((iVar8 != 0 || (cVar2 == '\x01')))) {
            piVar18[0x21] = piVar18[0x21] | 2;
            return 0;
        }
        if ((cVar2 == '\x02') || (iVar8 != 0)) {
            piVar18[0x1a] = 1;
            piVar18[0x70] = uVar19;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3feb;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4003;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            *(uint32_t *)((int64_t)&var_10h + iVar10) = uVar19;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4022;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            piVar18[0x21] = piVar18[0x21] | 2;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4037;
            iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
            if (iVar8 == 0) {
                return 0xffffffff;
            }
            uVar15 = *(undefined8 *)(piVar18 + 0x23e);
            uVar7 = *(undefined8 *)(piVar18 + 0x2e2);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4052;
            func_0x00018019c8a0(uVar7, uVar15);
            return 0;
        }
        if (uVar19 != 100) {
            if (cVar2 != '\x01') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3aa0;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ab8;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
            goto code_r0x0001801a3e57;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3fb1;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3fc9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
    } else {
        if (cVar2 == '\x15') goto code_r0x0001801a3932;
        if ((piVar18[0x21] & 1U) != 0) {
            if (cVar2 != '\x16') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a408d;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a409a;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40b2;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                              *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                              *(int64_t *)((int64_t)&var_20h + iVar10));
                goto code_r0x0001801a421b;
            }
            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar18 + 6) + 0x36) + 0x50) & 8) != 0) ||
                (iVar8 = **(int32_t **)(piVar18 + 6), iVar8 < 0x304)) || (iVar8 == 0x10000)) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b06;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
                if ((*(uint8_t *)(piVar18 + 0x26c) & 4) == 0) goto code_r0x0001801a40c2;
                piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                goto code_r0x0001801a3740;
            }
        }
        if (*(char *)(piVar20 + 3) == '\x16') {
            iVar11 = *(int64_t *)(piVar18 + 0x32c);
            uVar14 = 4 - iVar11;
            uVar12 = *(uint64_t *)(piVar20 + 8);
            if (uVar14 <= *(uint64_t *)(piVar20 + 8)) {
                uVar12 = uVar14;
            }
            if (uVar12 == 0) {
                if (*(int64_t *)(piVar20 + 8) == 0) goto code_r0x0001801a3b80;
            } else {
                iVar17 = *(int64_t *)(piVar20 + 10);
                iVar5 = *(int64_t *)(piVar20 + 4);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b71;
                func_0x000180498030(iVar11 + 0xca8 + (int64_t)piVar18, iVar17 + iVar5, uVar12);
                *(uint64_t *)(piVar18 + 0x32c) = *(int64_t *)(piVar18 + 0x32c) + uVar12;
code_r0x0001801a3b80:
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3b8e;
                iVar8 = func_0x0001801a4880(piVar18, piVar20, uVar12);
                if (iVar8 == 0) {
                    return 0xffffffff;
                }
            }
            piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
            if (*(uint64_t *)(piVar18 + 0x32c) < 4) goto code_r0x0001801a3740;
        }
        if (*(char *)(piVar20 + 3) == '\x14') {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41c2;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            goto code_r0x0001801a41fd;
        }
        if (3 < *(uint64_t *)(piVar18 + 0x32c)) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bd6;
            iVar8 = func_0x00018019b680(piVar18);
            if (iVar8 != 0) goto code_r0x0001801a3c57;
            iVar8 = piVar18[0x3c];
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bed;
            func_0x00018019b750(piVar18, 1);
            pcVar4 = *(code **)(piVar18 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3bf6;
            uVar12 = (*pcVar4)(placeholder_0);
            if ((int32_t)uVar12 < 0) {
                return uVar12;
            }
            if ((int32_t)uVar12 == 0) {
                return 0xffffffff;
            }
            if (iVar8 == 0xb) {
                return 0xffffffff;
            }
            piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
            if ((*(uint8_t *)(piVar18 + 0x26c) & 4) == 0) {
                uVar15 = *(undefined8 *)(piVar18 + 0x31e);
                pcVar4 = *(code **)(*(int64_t *)(piVar18 + 0x31a) + 0x10);
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c40;
                iVar8 = (*pcVar4)(uVar15);
                if (iVar8 == 0) {
code_r0x0001801a40c2:
                    piVar18[0x1a] = 3;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40d1;
                    uVar15 = func_0x000180193c40(placeholder_0);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40e1;
                    func_0x000180219ce0(uVar15, 0xf);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a40ee;
                    func_0x00018021b250(uVar15, 9);
                    return 0xffffffff;
                }
            }
            goto code_r0x0001801a3740;
        }
code_r0x0001801a3c57:
        cVar2 = *(char *)(piVar20 + 3);
        if (((cVar2 != '\x14') && (cVar2 != '\x15')) && (cVar2 != '\x16')) {
            if (cVar2 == '\x17') {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c87;
                iVar8 = func_0x00018019b380(piVar18);
                if (iVar8 != 0) {
                    piVar18[0x76] = 2;
                    return 0xffffffff;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3c97;
                iVar8 = func_0x00018019b800(piVar18);
                if (iVar8 != 0) {
                    iVar11 = *(int64_t *)(piVar20 + 8);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3cab;
                    iVar8 = fcn.1801a3200(piVar18);
                    if ((iVar8 == 0) || ((uint64_t)(iVar8 + 0x68) < iVar11 + (uint64_t)(uint32_t)piVar18[0x550])) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4123;
                        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10))
                        ;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4131;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10)
                                      , *(int64_t *)(&stack0x00000000 + iVar10), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                                      *(int64_t *)((int64_t)&var_20h + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4141;
                        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
                        return 0xffffffff;
                    }
                    piVar18[0x550] = piVar18[0x550] + (int32_t)iVar11;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a3ce2;
                    iVar8 = func_0x0001801a4880(piVar18, piVar20, 0);
                    if (iVar8 == 0) {
                        return 0xffffffff;
                    }
                    piVar16 = *(int32_t **)((int64_t)&arg_60h + iVar10);
                    goto code_r0x0001801a3740;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4150;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a418c;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4168;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                          *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                          *(int64_t *)((int64_t)&var_20h + iVar10));
            goto code_r0x0001801a421b;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4198;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a41b0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)((int64_t)&var_8h + iVar10), 
                      *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10), 
                      *(int64_t *)((int64_t)&var_20h + iVar10));
    }
code_r0x0001801a421b:
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801a4226;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801a4290
// Address: 0x1801a4290
// Size: 1509 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_318h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_388h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_378h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1801a4290(int32_t *param_1, uint64_t param_2, int64_t param_3, uint64_t param_4)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int32_t *piVar9;
    uint64_t uVar10;
    int32_t *piVar11;
    int64_t iVar12;
    int64_t iVar13;
    char cVar14;
    int32_t *piVar15;
    uint64_t uVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    int32_t *piVar19;
    int32_t *piVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801a42aa;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)(&stack0x00000318 + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7);
    *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)(&stack0x00000388 + iVar7);
    *(int64_t *)((int64_t)&var_8h + iVar7) = param_3;
    cVar14 = (char)param_2;
    if (param_1 == (int32_t *)0x0) goto code_r0x0001801a484a;
    piVar20 = (int32_t *)0x0;
    piVar17 = piVar20;
    if (*param_1 == 0) {
        piVar17 = param_1;
    }
    if (piVar17 == (int32_t *)0x0) goto code_r0x0001801a484a;
    uVar18 = *(uint64_t *)(piVar17 + 0x328);
    piVar17[0x1a] = 1;
    if ((param_4 < uVar18) ||
       ((*(int64_t *)(piVar17 + 0x32e) != 0 && (param_4 < *(int64_t *)(piVar17 + 0x32e) + uVar18)))) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a4817;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a482f;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -0x20)
                      , *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8));
    } else {
        if (piVar17[0x3c] == 4) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a433c;
            uVar4 = fcn.1801a3200(piVar17);
            if ((uVar4 == 0) || ((uint64_t)uVar4 < param_4 + (uint32_t)piVar17[0x550])) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a437c;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a438a;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8));
                goto code_r0x0001801a483d;
            }
            piVar17[0x550] = piVar17[0x550] + (int32_t)param_4;
        }
        *(undefined8 *)(piVar17 + 0x328) = 0;
        if ((*(int64_t *)(piVar17 + 0x32e) == 0) && ((piVar17[0x2e9] != -1 || (0 < piVar17[0x299])))) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a43d0;
            func_0x00018019b750(piVar17, 1);
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a43d8;
        iVar5 = func_0x00018019b2a0(param_1);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a43e4;
            iVar5 = func_0x00018019b680(piVar17);
            if ((iVar5 == 0) && (piVar17[0x3c] != 6)) {
                pcVar1 = *(code **)(piVar17 + 0x1c);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a43fa;
                iVar5 = (*pcVar1)(param_1);
                if ((iVar5 < 0) || (iVar5 == 0)) goto code_r0x0001801a484a;
            }
        }
        if (*(uint64_t *)(piVar17 + 0x32e) == 0) {
code_r0x0001801a448c:
            if (uVar18 == 0) {
                *(undefined8 *)(piVar17 + 0x32e) = 0;
                *(char *)(piVar17 + 0x330) = cVar14;
                *(int64_t *)(piVar17 + 0x332) = param_3;
            }
            if (uVar18 == param_4) {
                **(uint64_t **)((int64_t)&var_10h + iVar7) = uVar18;
                goto code_r0x0001801a484a;
            }
            if (0 < piVar17[0x71]) {
                pcVar1 = *(code **)(*(int64_t *)(param_1 + 6) + 0x90);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a44d6;
                iVar5 = (*pcVar1)(param_1);
                if (iVar5 < 1) goto code_r0x0001801a47b8;
            }
            param_4 = param_4 - uVar18;
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a44e9;
            uVar4 = func_0x0001801976c0(piVar17);
            uVar10 = (uint64_t)uVar4;
            *(uint64_t *)((int64_t)&iStackX_20 + iVar7 + -0x20) = uVar10;
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a44f8;
            uVar4 = func_0x000180197720(piVar17);
            uVar8 = (uint64_t)uVar4;
            *(uint64_t *)(&stack0xfffffffffffffff8 + iVar7) = uVar8;
            if (((uVar10 != 0) && (uVar8 != 0)) && (uVar8 <= uVar10)) {
                iVar5 = piVar17[0x12];
                if (iVar5 == 0x304) {
                    iVar5 = 0x303;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a4533;
                iVar6 = func_0x00018019b210(param_1);
                if ((iVar6 == 0xd) && (piVar17[0x2e8] == 0)) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a4549;
                    uVar4 = func_0x000180194ed0(param_1);
                    if ((uVar4 & 0xffffff00) == 0x300) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a455d;
                        iVar6 = func_0x000180194ed0(param_1);
                        if ((0x301 < iVar6) && (piVar17[0x232] == 0)) {
                            iVar5 = 0x301;
                        }
                    }
                }
                while( true ) {
                    uVar2 = *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + -0x20);
                    uVar3 = *(undefined8 *)(piVar17 + 800);
                    pcVar1 = *(code **)(*(int64_t *)(piVar17 + 0x31c) + 0x28);
                    *(undefined **)(&stack0xffffffffffffffe8 + iVar7) = &stack0xfffffffffffffff8 + iVar7;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a459e;
                    piVar9 = (int32_t *)(*pcVar1)(uVar3, param_2 & 0xff, param_4, uVar2);
                    piVar11 = *(int32_t **)(piVar17 + 0x278);
                    if ((piVar11 != (int32_t *)0x0) && (piVar11 < piVar9)) {
                        piVar9 = piVar11;
                    }
                    uVar8 = *(uint64_t *)(&stack0xfffffffffffffff8 + iVar7);
                    if ((int32_t *)0x20 < piVar9) {
                        piVar9 = (int32_t *)0x20;
                    }
                    if (*(uint64_t *)((int64_t)&iStackX_20 + iVar7 + -0x20) < uVar8) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a47c9;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
                        goto code_r0x0001801a47ce;
                    }
                    uVar10 = param_4 / (uint64_t)piVar9;
                    if (uVar10 < uVar8) {
                        uVar8 = param_4;
                        if (piVar9 != (int32_t *)0x0) {
                            iVar13 = *(int64_t *)((int64_t)&var_8h + iVar7);
                            piVar11 = (int32_t *)((int64_t)&iStackX_20 + iVar7 + -4);
                            uVar16 = uVar10 + 1;
                            piVar15 = piVar20;
                            piVar19 = piVar20;
                            if ((int32_t *)(param_4 % (uint64_t)piVar9) == (int32_t *)0x0) {
                                uVar16 = uVar10;
                            }
                            do {
                                *(uint64_t *)(piVar11 + 3) = uVar16;
                                iVar12 = (int64_t)piVar15 + iVar13 + uVar18;
                                *(char *)(piVar11 + -1) = cVar14;
                                piVar15 = (int32_t *)((int64_t)piVar15 + uVar16);
                                *(int64_t *)(piVar11 + 1) = iVar12;
                                piVar19 = (int32_t *)((int64_t)piVar19 + 1);
                                *piVar11 = iVar5;
                                piVar11 = piVar11 + 6;
                                uVar10 = uVar16 - 1;
                                if (piVar19 != (int32_t *)(param_4 % (uint64_t)piVar9)) {
                                    uVar10 = uVar16;
                                }
                                uVar16 = uVar10;
                            } while (piVar19 < piVar9);
                        }
                    } else {
                        if (piVar9 != (int32_t *)0x0) {
                            piVar11 = (int32_t *)((int64_t)&iStackX_20 + iVar7 + -4);
                            iVar13 = *(int64_t *)((int64_t)&var_8h + iVar7) + uVar18;
                            piVar15 = piVar9;
                            do {
                                *(int64_t *)(piVar11 + 1) = iVar13;
                                iVar13 = iVar13 + uVar8;
                                *(char *)(piVar11 + -1) = cVar14;
                                *piVar11 = iVar5;
                                *(uint64_t *)(piVar11 + 3) = uVar8;
                                piVar11 = piVar11 + 6;
                                piVar15 = (int32_t *)((int64_t)piVar15 + -1);
                            } while (piVar15 != (int32_t *)0x0);
                        }
                        uVar8 = (int64_t)piVar9 * uVar8;
                    }
                    *(uint64_t *)(piVar17 + 0x32e) = uVar8;
                    uVar2 = *(undefined8 *)(piVar17 + 800);
                    pcVar1 = *(code **)(*(int64_t *)(piVar17 + 0x31c) + 0x30);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a4697;
                    iVar6 = (*pcVar1)(uVar2, (int64_t)&iStackX_20 + iVar7 + -8);
                    if (iVar6 == 0) {
                        piVar17[0x1a] = 2;
                        goto code_r0x0001801a47b8;
                    }
                    piVar17[0x1a] = 1;
                    if (iVar6 == -3) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a4775;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a4785;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a479b;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                        *(uint64_t *)(piVar17 + 0x328) = uVar18;
                        goto code_r0x0001801a484a;
                    }
                    if (iVar6 == -2) {
                        uVar2 = *(undefined8 *)(piVar17 + 0x31e);
                        pcVar1 = *(code **)(*(int64_t *)(piVar17 + 0x31a) + 0x50);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a472c;
                        iVar5 = (*pcVar1)(uVar2);
                        if (iVar5 == -1) goto code_r0x0001801a47b8;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a473c;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a474c;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a475f;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar7));
                        *(uint64_t *)(piVar17 + 0x328) = uVar18;
                        goto code_r0x0001801a484a;
                    }
                    if (iVar6 == -1) {
                        *(uint64_t *)(piVar17 + 0x328) = uVar18;
                        goto code_r0x0001801a484a;
                    }
                    if ((iVar6 < -1) || (iVar6 < 1)) goto code_r0x0001801a47b8;
                    uVar8 = *(uint64_t *)(piVar17 + 0x32e);
                    if ((uVar8 == param_4) || ((cVar14 == '\x17' && ((*(uint8_t *)(piVar17 + 0x26c) & 1) != 0)))) break;
                    param_4 = param_4 - uVar8;
                    uVar18 = uVar18 + uVar8;
                }
                **(int64_t **)((int64_t)&var_10h + iVar7) = uVar8 + uVar18;
                *(undefined8 *)(piVar17 + 0x32e) = 0;
                goto code_r0x0001801a484a;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a47ea;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7)
                         );
code_r0x0001801a47ce:
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a47dd;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8));
        } else {
            if ((*(uint64_t *)(piVar17 + 0x32e) <= param_4) &&
               ((((*(uint8_t *)(piVar17 + 0x26c) & 2) != 0 || (*(int64_t *)(piVar17 + 0x332) == param_3)) &&
                (*(char *)(piVar17 + 0x330) == cVar14)))) {
                uVar2 = *(undefined8 *)(piVar17 + 800);
                pcVar1 = *(code **)(*(int64_t *)(piVar17 + 0x31c) + 0x38);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a445b;
                (*pcVar1)(uVar2);
                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar7) = 0x157;
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a4476;
                iVar5 = fcn.1801a32c0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&iStackX_20 + iVar7)
                                     );
                if (0 < iVar5) {
                    uVar18 = uVar18 + *(int64_t *)(piVar17 + 0x32e);
                    *(undefined8 *)(piVar17 + 0x32e) = 0;
                    goto code_r0x0001801a448c;
                }
code_r0x0001801a47b8:
                *(uint64_t *)(piVar17 + 0x328) = uVar18;
                goto code_r0x0001801a484a;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a47f6;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a480a;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8));
        }
    }
code_r0x0001801a483d:
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a4845;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar7));
code_r0x0001801a484a:
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801a485a;
    func_0x000180459870(*(uint64_t *)(&stack0x00000318 + iVar7) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801a4880
// Address: 0x1801a4880
// Size: 217 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_d08h because it doesn't fit into ProtoModel

undefined8 fcn.1801a4880(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a489a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *in_RDX;
    if (iVar2 == 0) {
        if ((in_R8 != 0) && (in_R8 != in_RDX[4])) goto code_r0x0001801a492b;
        iVar2 = in_RDX[3];
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a491c;
        func_0x000180224990(iVar2, 0x1804ad8a8, 0x241);
        in_RDX[3] = 0;
    } else {
        if (in_R8 == 0) {
            in_R8 = in_RDX[4];
        }
        uVar3 = *(undefined8 *)(in_RCX + 0xc78);
        pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a48cf;
        (*pcVar4)(uVar3, iVar2, in_R8);
        *(undefined4 *)((int64_t)&var_18h + iVar6) = 0x238;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a48eb;
        iVar5 = fcn.1801a32c0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_50h + iVar6));
        if (iVar5 < 1) {
            return 0;
        }
        if (in_R8 != in_RDX[4]) goto code_r0x0001801a492b;
    }
    *(int64_t *)(in_RCX + 0xd08) = *(int64_t *)(in_RCX + 0xd08) + 1;
code_r0x0001801a492b:
    piVar1 = in_RDX + 4;
    *piVar1 = *piVar1 - in_R8;
    if (*piVar1 == 0) {
        in_RDX[5] = 0;
    } else {
        in_RDX[5] = in_RDX[5] + in_R8;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a4960
// Address: 0x1801a4960
// Size: 2255 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h

void fcn.1801a4960(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
                  int64_t arg_b8h)
{
    char cVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined8 uVar4;
    code **ppcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    uint16_t uVar9;
    undefined2 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    uint64_t uVar16;
    int64_t in_RCX;
    uint64_t uVar17;
    int64_t iVar18;
    undefined4 in_EDX;
    code **ppcVar19;
    int64_t *piVar20;
    int32_t in_R8D;
    int32_t in_R9D;
    uint64_t uVar21;
    int64_t iVar22;
    int64_t *piVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_2e8h;
    int32_t var_2e0h;
    int32_t var_2dch;
    uint32_t var_2d8h;
    int32_t var_2d4h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    undefined4 auStack_268 [4];
    int64_t var_258h;
    undefined4 uStack_250;
    undefined4 uStack_24c;
    undefined4 auStack_248 [12];
    int64_t var_218h;
    undefined4 uStack_210;
    undefined4 uStack_20c;
    int64_t var_208h;
    undefined4 uStack_200;
    undefined4 uStack_1fc;
    int64_t var_1f8h;
    int64_t var_1f0h;
    undefined4 uStack_1e8;
    undefined4 uStack_1e4;
    int64_t var_1e0h;
    undefined4 uStack_1d8;
    undefined4 uStack_1d4;
    int64_t var_1d0h;
    int64_t var_1c8h;
    undefined4 uStack_1c0;
    undefined4 uStack_1bc;
    int64_t var_1b8h;
    undefined4 uStack_1b0;
    undefined4 uStack_1ac;
    int64_t var_1a8h;
    int64_t var_1a0h;
    undefined4 uStack_198;
    undefined4 uStack_194;
    int64_t var_190h;
    undefined4 uStack_188;
    undefined4 uStack_184;
    int64_t var_180h;
    int64_t var_178h;
    undefined4 uStack_170;
    undefined4 uStack_16c;
    int64_t var_168h;
    undefined4 uStack_160;
    undefined4 uStack_15c;
    int64_t var_158h;
    int64_t var_148h;
    undefined4 uStack_140;
    undefined4 uStack_13c;
    int64_t var_138h;
    undefined4 uStack_130;
    undefined4 uStack_12c;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_58h;
    undefined8 uStack_48;
    
    uStack_48 = 0x1801a497f;
    iVar12 = fcn.18045a350();
    iVar22 = arg_88h;
    iVar12 = -iVar12;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar12);
    piVar20 = &var_148h;
    var_278h = arg_28h;
    var_280h = arg_38h;
    var_288h = arg_48h;
    var_290h = arg_58h;
    var_298h = arg_68h;
    var_2a0h = arg_80h;
    var_2a8h = arg_90h;
    var_270h = *(int64_t *)(in_RCX + 8);
    var_2e8h._0_4_ = in_R9D;
    var_2d0h._0_4_ = in_EDX;
    var_2b8h = 0;
    var_2e8h._4_4_ = 0;
    var_2e0h = 0;
    if (in_R8D == 1) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4a20;
        var_2dch = func_0x0001801976c0();
    } else {
        var_2dch = 0x4000;
    }
    if (iVar22 == 0) {
        var_2c0h = 0;
    } else {
        var_2c0h = *(int64_t *)(iVar22 + 0x10);
    }
    ppcVar19 = *(code ***)(in_RCX + 0xc58);
    iVar22 = 0xc68;
    if (ppcVar19 == (code **)0x0) {
        if (in_R9D == 0) {
            ppcVar19 = (code **)0x1804b49f0;
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                ppcVar19 = (code **)0x1804b4610;
            }
        } else {
            iVar13 = 0xc68;
            if (in_R8D != 0) {
                iVar13 = 0xc70;
            }
            ppcVar19 = *(code ***)(iVar13 + in_RCX);
        }
    }
    iVar13 = 0x50;
    if (in_R8D != 0) {
        iVar13 = 0x58;
    }
    var_2b0h = *(int64_t *)(iVar13 + in_RCX);
    iVar13 = 0xc78;
    if (in_R8D != 0) {
        iVar13 = 0xc80;
    }
    var_2c8h = iVar13 + in_RCX;
    if (in_R8D != 0) {
        iVar22 = 0xc70;
    }
    piVar23 = (int64_t *)(iVar22 + in_RCX);
    if ((ppcVar19 == (code **)0x0) && (ppcVar19 = (code **)*piVar23, ppcVar19 == (code **)0x0)) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4ad3;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), *(int64_t *)(&stack0xffffffffffffffe8 + iVar12));
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4aeb;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), *(int64_t *)(&stack0xffffffffffffffe8 + iVar12), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar12), *(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                      *(int64_t *)((int64_t)&var_10h + iVar12));
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4afd;
        func_0x0001802296d0(0x14, 0xc0103, 0);
        goto code_r0x0001801a520c;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4b19;
    puVar14 = (undefined4 *)func_0x000180229cc0(auStack_268, 0x1804a9710, in_RCX + 0x9a8);
    var_218h._0_4_ = *puVar14;
    var_218h._4_4_ = puVar14[1];
    uStack_210 = puVar14[2];
    uStack_20c = puVar14[3];
    var_208h._0_4_ = puVar14[4];
    var_208h._4_4_ = puVar14[5];
    uStack_200 = puVar14[6];
    uStack_1fc = puVar14[7];
    var_1f8h = *(int64_t *)(puVar14 + 8);
    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4b49;
    puVar14 = (undefined4 *)func_0x000180229d80(auStack_268, 0x1804a95d0, in_RCX + 0x9b0);
    var_1f0h._0_4_ = *puVar14;
    var_1f0h._4_4_ = puVar14[1];
    uStack_1e8 = puVar14[2];
    uStack_1e4 = puVar14[3];
    var_1e0h._0_4_ = puVar14[4];
    var_1e0h._4_4_ = puVar14[5];
    uStack_1d8 = puVar14[6];
    uStack_1d4 = puVar14[7];
    var_1d0h = *(int64_t *)(puVar14 + 8);
    if (in_R8D == 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4b84;
        puVar14 = (undefined4 *)func_0x000180229cc0(auStack_268, 0x1804ad960, in_RCX + 0xc90);
        var_1c8h._0_4_ = *puVar14;
        var_1c8h._4_4_ = puVar14[1];
        uStack_1c0 = puVar14[2];
        uStack_1bc = puVar14[3];
        var_1b8h._0_4_ = puVar14[4];
        var_1b8h._4_4_ = puVar14[5];
        uStack_1b0 = puVar14[6];
        uStack_1ac = puVar14[7];
        var_1a8h = *(int64_t *)(puVar14 + 8);
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4bbd;
        puVar14 = (undefined4 *)func_0x000180229bc0(auStack_268, 0x1804a9518, in_RCX + 0xc98);
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4bd2;
        puVar14 = (undefined4 *)func_0x000180229cc0(auStack_268, 0x1804ad970, in_RCX + 0xcf0);
        var_1c8h._0_4_ = *puVar14;
        var_1c8h._4_4_ = puVar14[1];
        uStack_1c0 = puVar14[2];
        uStack_1bc = puVar14[3];
        var_1b8h._0_4_ = puVar14[4];
        var_1b8h._4_4_ = puVar14[5];
        uStack_1b0 = puVar14[6];
        uStack_1ac = puVar14[7];
        var_1a8h = *(int64_t *)(puVar14 + 8);
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4c0b;
        puVar14 = (undefined4 *)func_0x000180229cc0(auStack_268, 0x1804ad980, in_RCX + 0xcf8);
    }
    var_1a0h._0_4_ = *puVar14;
    var_1a0h._4_4_ = puVar14[1];
    uStack_198 = puVar14[2];
    uStack_194 = puVar14[3];
    var_190h._0_4_ = puVar14[4];
    var_190h._4_4_ = puVar14[5];
    uStack_188 = puVar14[6];
    uStack_184 = puVar14[7];
    var_180h = *(int64_t *)(puVar14 + 8);
    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4c36;
    puVar14 = (undefined4 *)func_0x000180229ba0(auStack_268);
    uVar2 = *(uint32_t *)(in_RCX + 0x570);
    var_178h._0_4_ = *puVar14;
    var_178h._4_4_ = puVar14[1];
    uStack_170 = puVar14[2];
    uStack_16c = puVar14[3];
    var_168h._0_4_ = puVar14[4];
    var_168h._4_4_ = puVar14[5];
    uStack_160 = puVar14[6];
    uStack_15c = puVar14[7];
    var_158h = *(int64_t *)(puVar14 + 8);
    if (in_R8D == 0) {
        var_2d8h = *(uint32_t *)(in_RCX + 0x160) >> 8;
        if ((uVar2 & 1) != 0) {
            var_2e8h._4_4_ = 1;
        }
        uVar2 = uVar2 & 4;
    } else {
        var_2d8h = *(uint32_t *)(in_RCX + 0x160) >> 10;
        if ((uVar2 & 2) != 0) {
            var_2e8h._4_4_ = 1;
        }
        uVar2 = uVar2 & 8;
    }
    var_2d8h = var_2d8h & 1;
    if (uVar2 != 0) {
        var_2e0h = 1;
    }
    if (var_2d8h != 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4cbc;
        puVar14 = (undefined4 *)func_0x000180229bc0(auStack_268, 0x1804ad990, &var_2d8h);
        piVar20 = &var_120h;
        var_148h._0_4_ = *puVar14;
        var_148h._4_4_ = puVar14[1];
        uStack_140 = puVar14[2];
        uStack_13c = puVar14[3];
        var_138h._0_4_ = puVar14[4];
        var_138h._4_4_ = puVar14[5];
        uStack_130 = puVar14[6];
        uStack_12c = puVar14[7];
        var_128h = *(int64_t *)(puVar14 + 8);
    }
    if (var_2e8h._4_4_ != 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4cff;
        puVar14 = (undefined4 *)func_0x000180229bc0(auStack_268, 0x1804ad998, (int64_t)&var_2e8h + 4);
        uVar6 = puVar14[1];
        uVar7 = puVar14[2];
        uVar8 = puVar14[3];
        *(undefined4 *)piVar20 = *puVar14;
        *(undefined4 *)((int64_t)piVar20 + 4) = uVar6;
        *(undefined4 *)(piVar20 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar20 + 0xc) = uVar8;
        uVar6 = puVar14[5];
        uVar7 = puVar14[6];
        uVar8 = puVar14[7];
        *(undefined4 *)(piVar20 + 2) = puVar14[4];
        *(undefined4 *)((int64_t)piVar20 + 0x14) = uVar6;
        *(undefined4 *)(piVar20 + 3) = uVar7;
        *(undefined4 *)((int64_t)piVar20 + 0x1c) = uVar8;
        piVar20[4] = *(int64_t *)(puVar14 + 8);
        piVar20 = piVar20 + 5;
    }
    if (var_2e0h != 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4d35;
        puVar14 = (undefined4 *)func_0x000180229bc0(auStack_268, 0x1804ad9a8, &var_2e0h);
        uVar6 = puVar14[1];
        uVar7 = puVar14[2];
        uVar8 = puVar14[3];
        *(undefined4 *)piVar20 = *puVar14;
        *(undefined4 *)((int64_t)piVar20 + 4) = uVar6;
        *(undefined4 *)(piVar20 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar20 + 0xc) = uVar8;
        uVar6 = puVar14[5];
        uVar7 = puVar14[6];
        uVar8 = puVar14[7];
        *(undefined4 *)(piVar20 + 2) = puVar14[4];
        *(undefined4 *)((int64_t)piVar20 + 0x14) = uVar6;
        *(undefined4 *)(piVar20 + 3) = uVar7;
        *(undefined4 *)((int64_t)piVar20 + 0x1c) = uVar8;
        piVar20[4] = *(int64_t *)(puVar14 + 8);
        piVar20 = piVar20 + 5;
    }
    if (((in_R8D == 0) && (*(int64_t *)(in_RCX + 0x8f8) != 0)) &&
       (cVar1 = *(char *)(*(int64_t *)(in_RCX + 0x8f8) + 0x350), (uint8_t)(cVar1 - 1U) < 4)) {
        var_2dch = 0x200 << (cVar1 - 1U & 0x1f);
    }
    if (var_2dch != 0x4000) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4d9c;
        puVar14 = (undefined4 *)func_0x000180229d80(auStack_268, 0x1804ad9b0, &var_2dch);
        uVar6 = puVar14[1];
        uVar7 = puVar14[2];
        uVar8 = puVar14[3];
        *(undefined4 *)piVar20 = *puVar14;
        *(undefined4 *)((int64_t)piVar20 + 4) = uVar6;
        *(undefined4 *)(piVar20 + 1) = uVar7;
        *(undefined4 *)((int64_t)piVar20 + 0xc) = uVar8;
        uVar6 = puVar14[5];
        uVar7 = puVar14[6];
        uVar8 = puVar14[7];
        *(undefined4 *)(piVar20 + 2) = puVar14[4];
        *(undefined4 *)((int64_t)piVar20 + 0x14) = uVar6;
        *(undefined4 *)(piVar20 + 3) = uVar7;
        *(undefined4 *)((int64_t)piVar20 + 0x1c) = uVar8;
        piVar20[4] = *(int64_t *)(puVar14 + 8);
        piVar20 = piVar20 + 5;
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        if ((in_R8D == 1) && (in_R9D == 1)) goto code_r0x0001801a4dd9;
    } else if ((in_R8D == 0) && (in_R9D - 1U < 2)) {
code_r0x0001801a4dd9:
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4de1;
        var_2d4h = fcn.1801a3200(in_RCX);
        if (var_2d4h != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4dfc;
            puVar14 = (undefined4 *)func_0x000180229d80(auStack_268, 0x1804ad9c0, &var_2d4h);
            uVar6 = puVar14[1];
            uVar7 = puVar14[2];
            uVar8 = puVar14[3];
            *(undefined4 *)piVar20 = *puVar14;
            *(undefined4 *)((int64_t)piVar20 + 4) = uVar6;
            *(undefined4 *)(piVar20 + 1) = uVar7;
            *(undefined4 *)((int64_t)piVar20 + 0xc) = uVar8;
            uVar6 = puVar14[5];
            uVar7 = puVar14[6];
            uVar8 = puVar14[7];
            *(undefined4 *)(piVar20 + 2) = puVar14[4];
            *(undefined4 *)((int64_t)piVar20 + 0x14) = uVar6;
            *(undefined4 *)(piVar20 + 3) = uVar7;
            *(undefined4 *)((int64_t)piVar20 + 0x1c) = uVar8;
            piVar20[4] = *(int64_t *)(puVar14 + 8);
            piVar20 = piVar20 + 5;
        }
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4e21;
    puVar14 = (undefined4 *)func_0x000180229ba0(auStack_268);
    uVar6 = puVar14[1];
    uVar7 = puVar14[2];
    uVar8 = puVar14[3];
    *(undefined4 *)piVar20 = *puVar14;
    *(undefined4 *)((int64_t)piVar20 + 4) = uVar6;
    *(undefined4 *)(piVar20 + 1) = uVar7;
    *(undefined4 *)((int64_t)piVar20 + 0xc) = uVar8;
    uVar6 = puVar14[5];
    uVar7 = puVar14[6];
    uVar8 = puVar14[7];
    *(undefined4 *)(piVar20 + 2) = puVar14[4];
    *(undefined4 *)((int64_t)piVar20 + 0x14) = uVar6;
    *(undefined4 *)(piVar20 + 3) = uVar7;
    *(undefined4 *)((int64_t)piVar20 + 0x1c) = uVar8;
    piVar20[4] = *(int64_t *)(puVar14 + 8);
    do {
        uVar21 = 0;
        uVar10 = 0;
        iVar22 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        if (in_R8D == 0) {
            uVar17 = *(uint64_t *)(in_RCX + 0xc88);
            uVar16 = 0;
            if (((*(uint8_t *)(iVar22 + 0x50) & 8) != 0) && (uVar16 = uVar21, (int32_t)var_2e8h != 0)) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4e7e;
                uVar9 = func_0x0001801c7570(in_RCX, 1);
                uVar16 = (uint64_t)uVar9;
            }
            uVar10 = (undefined2)uVar16;
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4e9e;
                uVar15 = func_0x0001802199b0();
            } else {
                *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4e97;
                uVar15 = func_0x000180253540();
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4ea6;
            uVar16 = func_0x00018021a7c0(uVar15);
            if (uVar16 != 0) {
                *(uint64_t *)(in_RCX + 0xc88) = uVar16;
                uVar21 = uVar17;
                goto code_r0x0001801a4ee6;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a50c9;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar12));
code_r0x0001801a50ce:
            *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a50e1;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar12), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar12), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar12), *(int64_t *)((int64_t)&var_10h + iVar12));
            goto code_r0x0001801a51fa;
        }
        uVar16 = uVar21;
        if (((*(uint8_t *)(iVar22 + 0x50) & 8) != 0) && (uVar10 = 0, (int32_t)var_2e8h != 0)) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a4ed7;
            uVar10 = func_0x0001801c7570(in_RCX, 2);
        }
code_r0x0001801a4ee6:
        iVar11 = (int32_t)var_2e8h;
        iVar22 = *(int64_t *)(in_RCX + 0x4f8);
        auStack_268[0] = 1;
        auStack_268[1] = 0;
        auStack_268[2] = 0x8019b800;
        auStack_268[3] = 1;
        if (iVar22 != 0) {
            var_258h._0_4_ = 2;
            var_258h._4_4_ = 0;
            uStack_250 = 0x801a2d80;
            uStack_24c = 1;
        }
        iVar13 = 0x20;
        if (iVar22 == 0) {
            iVar13 = 0x10;
        }
        uVar17 = (uint64_t)(iVar22 != 0);
        iVar18 = uVar17 + 2;
        iVar22 = *(int64_t *)(in_RCX + 0xce0);
        *(undefined4 *)((int64_t)auStack_268 + iVar13) = 3;
        *(undefined4 *)((int64_t)auStack_268 + iVar13 + 4) = 0;
        *(undefined4 *)((int64_t)auStack_268 + iVar13 + 8) = 0x801a2dd0;
        *(undefined4 *)((int64_t)auStack_268 + iVar13 + 0xc) = 1;
        iVar13 = iVar18;
        if (iVar22 != 0) {
            iVar13 = uVar17 + 3;
            auStack_268[iVar18 * 4] = 4;
            auStack_268[iVar18 * 4 + 1] = 0;
            auStack_268[iVar18 * 4 + 2] = 0x801a2df0;
            auStack_268[iVar18 * 4 + 3] = 1;
        }
        *(int64_t **)((int64_t)&arg_b8h + iVar12) = &var_2b8h;
        *(undefined8 *)((int64_t)&arg_b0h + iVar12) = *(undefined8 *)(in_RCX + 0xc60);
        *(int64_t *)((int64_t)&arg_a8h + iVar12) = in_RCX;
        *(undefined4 **)((int64_t)&arg_a0h + iVar12) = auStack_268;
        *(int64_t **)((int64_t)&arg_98h + iVar12) = &var_218h;
        *(int64_t **)((int64_t)&arg_90h + iVar12) = &var_148h;
        *(undefined8 *)((int64_t)&arg_88h + iVar12) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar12) = 0;
        *(uint64_t *)((int64_t)&arg_78h + iVar12) = uVar16;
        *(int64_t *)((int64_t)&arg_70h + iVar12) = var_2b0h;
        *(uint64_t *)((int64_t)&arg_68h + iVar12) = uVar21;
        *(int64_t *)((int64_t)&arg_60h + iVar12) = var_2a8h;
        *(int64_t *)((int64_t)&arg_58h + iVar12) = var_2c0h;
        *(int64_t *)((int64_t)&arg_50h + iVar12) = var_2a0h;
        *(undefined4 *)((int64_t)&arg_48h + iVar12) = (undefined4)arg_78h;
        *(int64_t *)((int64_t)&arg_40h + iVar12) = arg_70h;
        *(int64_t *)((int64_t)&arg_38h + iVar12) = var_298h;
        *(int64_t *)((int64_t)&arg_30h + iVar12) = arg_60h;
        *(int64_t *)((int64_t)&arg_28h + iVar12) = var_290h;
        *(int64_t *)((int64_t)&var_20h + iVar12) = arg_50h;
        *(int64_t *)((int64_t)&var_18h + iVar12) = var_288h;
        *(int64_t *)((int64_t)&var_10h + iVar12) = arg_40h;
        *(int64_t *)((int64_t)&var_8h + iVar12) = var_280h;
        *(int64_t *)(&stack0x00000000 + iVar12) = arg_30h;
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar12) = var_278h;
        auStack_268[iVar13 * 4] = 0;
        auStack_268[iVar13 * 4 + 1] = 0;
        auStack_268[iVar13 * 4 + 2] = 0;
        auStack_268[iVar13 * 4 + 3] = 0;
        pcVar3 = *ppcVar19;
        *(undefined2 *)(&stack0xfffffffffffffff0 + iVar12) = uVar10;
        uVar15 = *(undefined8 *)(var_270h + 0x460);
        uVar4 = *(undefined8 *)var_270h;
        *(int32_t *)(&stack0xffffffffffffffe8 + iVar12) = iVar11;
        *(int32_t *)(&stack0xffffffffffffffe0 + iVar12) = in_R8D;
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a5096;
        iVar11 = (*pcVar3)(uVar4, uVar15, (undefined4)var_2d0h);
        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a50a0;
        func_0x000180219f80(uVar21);
        if (iVar11 == -2) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a51dc;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar12));
            *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a51f4;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar12), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar12), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar12), *(int64_t *)((int64_t)&var_10h + iVar12));
            goto code_r0x0001801a51fa;
        }
        if (iVar11 != -1) {
            if (iVar11 != 1) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a511e;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), 
                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar12));
                goto code_r0x0001801a50ce;
            }
            if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) || (in_R8D == 0)) {
code_r0x0001801a5153:
                piVar20 = (int64_t *)var_2c8h;
                if (*piVar23 != 0) {
                    pcVar3 = *(code **)(*piVar23 + 8);
                    uVar15 = *(undefined8 *)var_2c8h;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a5169;
                    iVar11 = (*pcVar3)(uVar15);
                    if (iVar11 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a5172;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar12));
                        goto code_r0x0001801a50ce;
                    }
                }
            } else {
                uVar15 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
                *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a514e;
                iVar22 = func_0x00018001ed90(uVar15);
                piVar20 = (int64_t *)var_2c8h;
                if (iVar22 == 0) goto code_r0x0001801a5153;
            }
            *piVar20 = var_2b8h;
            *piVar23 = (int64_t)ppcVar19;
            iVar22 = *piVar20;
            if (((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) &&
               (pcVar3 = ppcVar19[0xe], pcVar3 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a51b5;
                (*pcVar3)(iVar22, 1);
            }
            if ((*(int64_t *)(in_RCX + 0x9e0) != 0) && (pcVar3 = ppcVar19[0xf], pcVar3 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a51d0;
                (*pcVar3)(iVar22);
            }
            goto code_r0x0001801a520c;
        }
        ppcVar5 = (code **)*piVar23;
    } while ((ppcVar5 != ppcVar19) && (ppcVar19 = ppcVar5, ppcVar5 != (code **)0x0));
    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a50f1;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), *(int64_t *)(&stack0xffffffffffffffe8 + iVar12));
    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a5109;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar12), *(int64_t *)(&stack0xffffffffffffffe8 + iVar12), 
                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar12), *(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                  *(int64_t *)((int64_t)&var_10h + iVar12));
code_r0x0001801a51fa:
    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a520a;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar12));
code_r0x0001801a520c:
    *(undefined8 *)((int64_t)&uStack_48 + iVar12) = 0x1801a521b;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar12));
    return;
}

// ============================================================
// Function: FUN_1801a5230
// Address: 0x1801a5230
// Size: 99 bytes
// ============================================================
undefined8 fcn.1801a5230(int64_t param_1)
{
    undefined4 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a523c;
    iVar4 = fcn.18045a350();
    if ((*(int64_t *)(param_1 + 0xc68) != 0) && (*(int64_t *)(param_1 + 0xc70) != 0)) {
        uVar1 = *(undefined4 *)(param_1 + 0x48);
        uVar2 = *(undefined8 *)(param_1 + 0xc78);
        pcVar3 = *(code **)(*(int64_t *)(param_1 + 0xc68) + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x1801a5268;
        (*pcVar3)(uVar2, uVar1);
        uVar1 = *(undefined4 *)(param_1 + 0x48);
        uVar2 = *(undefined8 *)(param_1 + 0xc80);
        pcVar3 = *(code **)(*(int64_t *)(param_1 + 0xc70) + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x1801a5280;
        (*pcVar3)(uVar2, uVar1);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a52a0
// Address: 0x1801a52a0
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801a52a0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a52b0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a52c6;
        uVar2 = fcn.18021b280(in_RDX);
        if ((int32_t)uVar2 == 0) {
            return uVar2;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a52de;
    fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(int64_t *)(in_RCX + 0x10) = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_1801a5300
// Address: 0x1801a5300
// Size: 64 bytes
// ============================================================
undefined8 fcn.1801a5300(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a530c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5320;
        fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5335;
        fcn.180224990(param_1, 0x1804ada98, 0xcd);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a5340
// Address: 0x1801a5340
// Size: 815 bytes
// ============================================================
undefined8
fcn.1801a5340(int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h,
             int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_130h,
             int64_t arg_138h, int64_t arg_140h, int64_t arg_148h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int32_t *piVar11;
    undefined8 unaff_RBP;
    undefined4 uVar12;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801a534d;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5367;
    piVar9 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_10h + iVar8));
    uVar12 = 0;
    if (piVar9 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5376;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a538e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                      *(int64_t *)(&stack0x00000040 + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a53a0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_58h + iVar8) = unaff_RDI;
    iVar2 = *(int64_t *)((int64_t)&arg_100h + iVar8);
    *(undefined8 *)((int64_t)&arg_60h + iVar8) = unaff_R14;
    iVar7 = *(int32_t *)((int64_t)&arg_78h + iVar8);
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_R15;
    ppiVar3 = *(int64_t ***)((int64_t)&arg_148h + iVar8);
    *piVar9 = *(int64_t *)((int64_t)&arg_140h + iVar8);
    *(int32_t *)(piVar9 + 1) = iVar7;
    if (iVar2 == 0) {
code_r0x0001801a543a:
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5443;
        fcn.180219f80(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        piVar11 = *(int32_t **)((int64_t)&arg_130h + iVar8);
        piVar9[0xb] = *(int64_t *)((int64_t)&arg_138h + iVar8);
        piVar9[2] = iVar2;
        *ppiVar3 = piVar9;
        if (piVar11 != (int32_t *)0x0) {
            iVar5 = *piVar11;
            while (iVar5 != 0) {
                if (iVar5 == 2) {
                    piVar9[10] = *(int64_t *)(piVar11 + 2);
                }
                piVar1 = piVar11 + 4;
                piVar11 = piVar11 + 4;
                iVar5 = *piVar1;
            }
        }
        if (iVar7 != 0) {
            iVar5 = *(int32_t *)((int64_t)&arg_70h + iVar8);
            if (*(int32_t *)(*piVar9 + 0x7c) == 0) {
                uVar10 = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a54c1;
                iVar6 = fcn.18020f2b0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar8), *(int64_t *)(&stack0x00000038 + iVar8), 
                                      *(int64_t *)(&stack0x00000040 + iVar8), *(int64_t *)(&stack0x00000048 + iVar8));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a54db;
                    iVar6 = fcn.18020f2b0(*(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8), 
                                          *(int64_t *)(&stack0x00000028 + iVar8), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                          *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8)
                                          , *(int64_t *)(&stack0x00000048 + iVar8));
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a54f5;
                        iVar6 = fcn.18020f2b0(*(int64_t *)((int64_t)&var_10h + iVar8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar8), 
                                              *(int64_t *)((int64_t)&var_20h + iVar8), 
                                              *(int64_t *)(&stack0x00000028 + iVar8), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                              *(int64_t *)(&stack0x00000038 + iVar8), 
                                              *(int64_t *)(&stack0x00000040 + iVar8), 
                                              *(int64_t *)(&stack0x00000048 + iVar8));
                        if (iVar6 == 0) {
                            *(undefined4 *)(piVar9 + 7) = 0x50;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5567;
                            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a557f;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8), 
                                          *(int64_t *)(&stack0x00000028 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8)
                                         );
                            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5591;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
                            *(uint32_t *)(*piVar9 + 0xa8) = *(uint32_t *)(*piVar9 + 0xa8) | 2;
                            goto code_r0x0001801a5626;
                        }
                        uVar12 = 3;
                    } else {
                        uVar12 = 2;
                    }
                } else {
                    uVar12 = 1;
                }
                uVar10 = *(undefined8 *)((int64_t)&arg_f0h + iVar8);
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a550e;
                iVar6 = fcn.180215670(uVar10);
                if (iVar6 == 0) {
                    *(undefined4 *)(piVar9 + 7) = 0x50;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5522;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a553a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                                  *(int64_t *)(&stack0x00000040 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a554c;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(uint32_t *)(*piVar9 + 0xa8) = *(uint32_t *)(*piVar9 + 0xa8) | 2;
                    goto code_r0x0001801a5626;
                }
            }
            pcVar4 = *(code **)(*piVar9 + 0x38);
            *(undefined8 *)((int64_t)&var_20h + iVar8) = *(undefined8 *)(*piVar9 + 0x40);
            *(undefined8 *)((int64_t)&var_18h + iVar8) = *(undefined8 *)((int64_t)&arg_90h + iVar8);
            *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_88h + iVar8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a55da;
            iVar7 = (*pcVar4)(iVar7, iVar5 != 0, uVar12, uVar10);
            if (iVar7 == 0) {
                *(undefined4 *)(piVar9 + 7) = 0x50;
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a55ea;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5602;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                              *(int64_t *)(&stack0x00000040 + iVar8));
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5614;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
                *(uint32_t *)(*piVar9 + 0xa8) = *(uint32_t *)(*piVar9 + 0xa8) | 2;
                *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5626;
                fcn.180215590(uVar10);
                goto code_r0x0001801a5626;
            }
        }
        uVar10 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a53f1;
        iVar5 = fcn.18021b280(iVar2);
        if (iVar5 != 0) goto code_r0x0001801a543a;
        *(undefined4 *)(piVar9 + 7) = 0x50;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5401;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5419;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                      *(int64_t *)(&stack0x00000040 + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a542b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar8));
        *(uint32_t *)(*piVar9 + 0xa8) = *(uint32_t *)(*piVar9 + 0xa8) | 2;
code_r0x0001801a5626:
        *ppiVar3 = (int64_t *)0x0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a5636;
        fcn.180219f80(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar8) = 0x1801a564b;
        fcn.180224990(piVar9, 0x1804ada98, 0xcd);
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_1801a5670
// Address: 0x1801a5670
// Size: 845 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable arg_32h
// WARNING: [rz-ghidra] Detected overlap for variable arg_33h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

void fcn.1801a5670(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined uVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    char cVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    uint64_t uVar13;
    int64_t in_R8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a5680;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    *(uint64_t *)((int64_t)&arg_38h + iVar12) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar12)
    ;
    if (in_R8 == 1) {
        iVar2 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5700;
        func_0x000180219ce0(iVar2, 0xf);
        pcVar3 = (code *)in_RCX[10];
        if (pcVar3 != (code *)0x0) {
            if (*(int32_t *)(in_RCX + 1) == 0) {
                cVar10 = *(char *)in_RDX;
            } else {
                cVar10 = '\x17';
            }
            *(char *)((int64_t)&arg_30h + iVar12) = cVar10;
            *(char *)((int64_t)&arg_30h + iVar12 + 1) = *(char *)((int64_t)in_RDX + 5);
            *(char *)((int64_t)&arg_30h + iVar12 + 2) = *(char *)(in_RDX + 1);
            *(char *)((int64_t)&arg_30h + iVar12 + 3) = *(char *)((int64_t)in_RDX + 0x11);
            *(char *)((int64_t)&arg_30h + iVar12 + 4) = *(char *)(in_RDX + 4);
            *(int64_t *)((int64_t)&var_20h + iVar12) = in_RCX[0xb];
            *(undefined8 *)((int64_t)&var_18h + iVar12) = 5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5768;
            (*pcVar3)(1, 0x304, 0x100, (int64_t)&arg_30h + iVar12);
            if (*(int32_t *)(in_RCX + 1) != 0) {
                pcVar3 = (code *)in_RCX[10];
                *(int64_t *)((int64_t)&var_20h + iVar12) = in_RCX[0xb];
                *(undefined8 *)((int64_t)&var_18h + iVar12) = 1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a579a;
                (*pcVar3)(1, 0x304, 0x101, in_RDX);
            }
        }
        if (*(char *)in_RDX == '\x15') {
            if (*(int64_t *)(in_RDX + 4) == 2) {
                pcVar3 = *(code **)(*in_RCX + 0x68);
                uVar6 = *(undefined8 *)(*in_RCX + 0x70);
                uVar1 = *(undefined *)(*(int64_t *)(in_RDX + 2) + 1);
                *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a596b;
                iVar11 = (*pcVar3)(uVar6, uVar1);
                if (iVar11 == 0) {
                    *(undefined4 *)(in_RCX + 7) = 0x50;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a597f;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5997;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar12), *(int64_t *)((int64_t)&arg_30h + iVar12), 
                                  *(int64_t *)(&stack0x00000048 + iVar12));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a59a9;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar12));
                    *(uint32_t *)(*in_RCX + 0xa8) = *(uint32_t *)(*in_RCX + 0xa8) | 2;
                }
            } else {
                *(undefined4 *)(in_RCX + 7) = 0x50;
                *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a591b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12));
                *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5933;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12), 
                              *(int64_t *)((int64_t)&arg_28h + iVar12), *(int64_t *)((int64_t)&arg_30h + iVar12), 
                              *(int64_t *)(&stack0x00000048 + iVar12));
                *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5945;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar12));
                *(uint32_t *)(*in_RCX + 0xa8) = *(uint32_t *)(*in_RCX + 0xa8) | 2;
            }
        } else if (*(char *)in_RDX == '\x16') {
            iVar2 = in_RCX[3];
            iVar4 = *(int64_t *)(in_RDX + 4);
            iVar5 = *(int64_t *)(in_RDX + 2);
            pcVar3 = *(code **)(*in_RCX + 8);
            uVar6 = *(undefined8 *)(*in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5816;
            iVar11 = (*pcVar3)(iVar2 + iVar5, iVar4 - iVar2, (int64_t)&arg_28h + iVar12, uVar6);
            if (iVar11 == 0) {
                *(undefined4 *)(in_RCX + 7) = 0x50;
                *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5826;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12));
                *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a583e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12), 
                              *(int64_t *)((int64_t)&arg_28h + iVar12), *(int64_t *)((int64_t)&arg_30h + iVar12), 
                              *(int64_t *)(&stack0x00000048 + iVar12));
                *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5850;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar12));
                *(uint32_t *)(*in_RCX + 0xa8) = *(uint32_t *)(*in_RCX + 0xa8) | 2;
            } else {
                uVar13 = in_RCX[3] + *(int64_t *)((int64_t)&arg_28h + iVar12);
                if (uVar13 == *(uint64_t *)(in_RDX + 4)) {
                    in_RCX[3] = 0;
                } else if (uVar13 < *(uint64_t *)(in_RDX + 4)) {
                    iVar2 = in_RCX[2];
                    in_RCX[3] = uVar13;
                    uVar7 = in_RDX[1];
                    uVar8 = in_RDX[2];
                    uVar9 = in_RDX[3];
                    *(undefined4 *)(in_RCX + 4) = *in_RDX;
                    *(undefined4 *)((int64_t)in_RCX + 0x24) = uVar7;
                    *(undefined4 *)(in_RCX + 5) = uVar8;
                    *(undefined4 *)((int64_t)in_RCX + 0x2c) = uVar9;
                    in_RCX[6] = *(int64_t *)(in_RDX + 4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a58df;
                    func_0x00018021b250(iVar2, 10);
                } else {
                    *(undefined4 *)(in_RCX + 7) = 0x50;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5881;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a5899;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar12), *(int64_t *)((int64_t)&arg_30h + iVar12), 
                                  *(int64_t *)(&stack0x00000048 + iVar12));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a58ab;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar12));
                    *(uint32_t *)(*in_RCX + 0xa8) = *(uint32_t *)(*in_RCX + 0xa8) | 2;
                }
            }
        } else {
            *(undefined4 *)(in_RCX + 7) = 0x50;
            *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a57b7;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12));
            *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a57cf;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12), 
                          *(int64_t *)((int64_t)&arg_28h + iVar12), *(int64_t *)((int64_t)&arg_30h + iVar12), 
                          *(int64_t *)(&stack0x00000048 + iVar12));
            *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a57e1;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar12));
            *(uint32_t *)(*in_RCX + 0xa8) = *(uint32_t *)(*in_RCX + 0xa8) | 2;
        }
    } else {
        if (in_RCX != (int64_t *)0x0) {
            *(undefined4 *)(in_RCX + 7) = 0x50;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a56af;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a56c7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12), 
                      *(int64_t *)((int64_t)&arg_28h + iVar12), *(int64_t *)((int64_t)&arg_30h + iVar12), 
                      *(int64_t *)(&stack0x00000048 + iVar12));
        *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a56d9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar12));
        if (in_RCX != (int64_t *)0x0) {
            *(uint32_t *)(*in_RCX + 0xa8) = *(uint32_t *)(*in_RCX + 0xa8) | 2;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar12) = 0x1801a58fd;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_38h + iVar12) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar12));
    return;
}

// ============================================================
// Function: FUN_1801a59c0
// Address: 0x1801a59c0
// Size: 32 bytes
// ============================================================
void fcn.1801a59c0(int64_t *param_1)
{
    undefined uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar15;
    undefined8 uStackX_18;
    undefined8 uStackX_20;
    
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    piVar13 = param_1 + 4;
    iVar15 = 1;
    *(undefined8 *)(&stack0x00000040 + iVar12) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar12) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar12) = 0x1801a5680;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(uint64_t *)(&stack0x00000060 + iVar11 + iVar12) =
         *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_20 + iVar11 + iVar12;
    if (iVar15 == 1) {
        iVar15 = param_1[2];
        *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5700;
        func_0x000180219ce0(iVar15, 0xf);
        pcVar2 = (code *)param_1[10];
        if (pcVar2 != (code *)0x0) {
            if (*(int32_t *)(param_1 + 1) == 0) {
                cVar9 = *(char *)piVar13;
            } else {
                cVar9 = '\x17';
            }
            (&stack0x00000058)[iVar11 + iVar12] = cVar9;
            (&stack0x00000059)[iVar11 + iVar12] = *(char *)((int64_t)piVar13 + 5);
            (&stack0x0000005a)[iVar11 + iVar12] = *(char *)((int64_t)piVar13 + 4);
            (&stack0x0000005b)[iVar11 + iVar12] = *(char *)((int64_t)piVar13 + 0x11);
            (&stack0x0000005c)[iVar11 + iVar12] = *(char *)(piVar13 + 2);
            *(int64_t *)(&stack0x00000048 + iVar11 + iVar12) = param_1[0xb];
            *(undefined8 *)(&stack0x00000040 + iVar11 + iVar12) = 5;
            *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5768;
            (*pcVar2)(1, 0x304, 0x100, &stack0x00000058 + iVar11 + iVar12);
            if (*(int32_t *)(param_1 + 1) != 0) {
                pcVar2 = (code *)param_1[10];
                *(int64_t *)(&stack0x00000048 + iVar11 + iVar12) = param_1[0xb];
                *(undefined8 *)(&stack0x00000040 + iVar11 + iVar12) = 1;
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a579a;
                (*pcVar2)(1, 0x304, 0x101, piVar13);
            }
        }
        if (*(char *)piVar13 == '\x15') {
            if (piVar13[2] == 2) {
                pcVar2 = *(code **)(*param_1 + 0x68);
                uVar5 = *(undefined8 *)(*param_1 + 0x70);
                uVar1 = *(undefined *)(piVar13[1] + 1);
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a596b;
                iVar10 = (*pcVar2)(uVar5, uVar1);
                if (iVar10 == 0) {
                    *(undefined4 *)(param_1 + 7) = 0x50;
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a597f;
                    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000048 + iVar11 + iVar12));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5997;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000048 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000050 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000058 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000070 + iVar11 + iVar12));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a59a9;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar11 + iVar12));
                    *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
                }
            } else {
                *(undefined4 *)(param_1 + 7) = 0x50;
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a591b;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000048 + iVar11 + iVar12));
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5933;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000048 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000050 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000058 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000070 + iVar11 + iVar12));
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5945;
                fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar11 + iVar12));
                *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
            }
        } else if (*(char *)piVar13 == '\x16') {
            iVar15 = param_1[3];
            iVar3 = piVar13[2];
            iVar4 = piVar13[1];
            pcVar2 = *(code **)(*param_1 + 8);
            uVar5 = *(undefined8 *)(*param_1 + 0x10);
            *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5816;
            iVar10 = (*pcVar2)(iVar15 + iVar4, iVar3 - iVar15, &stack0x00000050 + iVar11 + iVar12, uVar5);
            if (iVar10 == 0) {
                *(undefined4 *)(param_1 + 7) = 0x50;
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5826;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000048 + iVar11 + iVar12));
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a583e;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000048 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000050 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000058 + iVar11 + iVar12), 
                              *(int64_t *)(&stack0x00000070 + iVar11 + iVar12));
                *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5850;
                fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar11 + iVar12));
                *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
            } else {
                uVar14 = param_1[3] + *(int64_t *)(&stack0x00000050 + iVar11 + iVar12);
                if (uVar14 == piVar13[2]) {
                    param_1[3] = 0;
                } else if (uVar14 < (uint64_t)piVar13[2]) {
                    iVar15 = param_1[2];
                    param_1[3] = uVar14;
                    uVar6 = *(undefined4 *)((int64_t)piVar13 + 4);
                    uVar7 = *(undefined4 *)(piVar13 + 1);
                    uVar8 = *(undefined4 *)((int64_t)piVar13 + 0xc);
                    *(undefined4 *)(param_1 + 4) = *(undefined4 *)piVar13;
                    *(undefined4 *)((int64_t)param_1 + 0x24) = uVar6;
                    *(undefined4 *)(param_1 + 5) = uVar7;
                    *(undefined4 *)((int64_t)param_1 + 0x2c) = uVar8;
                    param_1[6] = piVar13[2];
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a58df;
                    func_0x00018021b250(iVar15, 10);
                } else {
                    *(undefined4 *)(param_1 + 7) = 0x50;
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5881;
                    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000048 + iVar11 + iVar12));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a5899;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000048 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000050 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000058 + iVar11 + iVar12), 
                                  *(int64_t *)(&stack0x00000070 + iVar11 + iVar12));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a58ab;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar11 + iVar12));
                    *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
                }
            }
        } else {
            *(undefined4 *)(param_1 + 7) = 0x50;
            *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a57b7;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                          *(int64_t *)(&stack0x00000048 + iVar11 + iVar12));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a57cf;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), 
                          *(int64_t *)(&stack0x00000048 + iVar11 + iVar12), 
                          *(int64_t *)(&stack0x00000050 + iVar11 + iVar12), 
                          *(int64_t *)(&stack0x00000058 + iVar11 + iVar12), 
                          *(int64_t *)(&stack0x00000070 + iVar11 + iVar12));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a57e1;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar11 + iVar12));
            *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
        }
    } else {
        if (param_1 != (int64_t *)0x0) {
            *(undefined4 *)(param_1 + 7) = 0x50;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a56af;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), *(int64_t *)(&stack0x00000048 + iVar11 + iVar12)
                     );
        *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a56c7;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar11 + iVar12), *(int64_t *)(&stack0x00000048 + iVar11 + iVar12)
                      , *(int64_t *)(&stack0x00000050 + iVar11 + iVar12), 
                      *(int64_t *)(&stack0x00000058 + iVar11 + iVar12), *(int64_t *)(&stack0x00000070 + iVar11 + iVar12)
                     );
        *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a56d9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar11 + iVar12));
        if (param_1 != (int64_t *)0x0) {
            *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
        }
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar11 + iVar12) = 0x1801a58fd;
    func_0x000180459870(*(uint64_t *)(&stack0x00000060 + iVar11 + iVar12) ^ (int64_t)&uStackX_20 + iVar11 + iVar12);
    return;
}

// ============================================================
// Function: FUN_1801a59e0
// Address: 0x1801a59e0
// Size: 393 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.1801a59e0(int64_t arg_70h, int64_t arg_78h)
{
    undefined8 uVar1;
    int64_t *piVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    int64_t **in_RDX;
    undefined4 *in_R8;
    undefined *in_R9;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x1801a59f3;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)aiStackX_10 + iVar8 + -8) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar8);
    uVar1 = *(undefined8 *)((int64_t)&arg_70h + iVar8);
    piVar2 = *(int64_t **)((int64_t)&arg_78h + iVar8);
    if ((in_RCX[8] == 0) && (in_RCX[9] == 0)) {
        iVar3 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5a3d;
        fcn.180219ce0(iVar3, 0xf);
        pcVar4 = *(code **)(*in_RCX + 0x18);
        uVar5 = *(undefined8 *)(*in_RCX + 0x20);
        *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5a50;
        iVar7 = (*pcVar4)(uVar1, piVar2, uVar5);
        if (iVar7 == 0) {
            *(undefined4 *)(in_RCX + 7) = 0x50;
            *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5a60;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0xfffffffffffffff8 + iVar8));
            *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5a78;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar8 + -0x10), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar8 + -8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar8 + 0x10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5a8a;
            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar8));
            *(uint32_t *)(*in_RCX + 0xa8) = *(uint32_t *)(*in_RCX + 0xa8) | 2;
        } else if (*piVar2 == 0) {
            iVar3 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5ac7;
            fcn.18021b250(iVar3, 9);
        } else {
            *in_RDX = in_RCX;
            *in_R8 = 0x304;
            *in_R9 = 0x16;
            iVar3 = *piVar2;
            pcVar4 = (code *)in_RCX[10];
            in_RCX[9] = iVar3;
            in_RCX[8] = iVar3;
            if (pcVar4 != (code *)0x0) {
                iVar7 = *(int32_t *)(in_RCX + 1);
                *(undefined2 *)((int64_t)aiStackX_10 + iVar8 + -0xf) = 0x303;
                *(char *)((int64_t)aiStackX_10 + iVar8 + -0x10) = (iVar7 != 0) + '\x16';
                *(undefined *)((int64_t)aiStackX_10 + iVar8 + -0xd) = *(undefined *)((int64_t)piVar2 + 1);
                *(undefined *)((int64_t)aiStackX_10 + iVar8 + -0xc) = *(undefined *)piVar2;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar8) = in_RCX[0xb];
                *(undefined8 *)((int64_t)&var_10h + iVar8) = 5;
                *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5b36;
                (*pcVar4)(0, 0x304, 0x100, (int64_t)aiStackX_10 + iVar8 + -0x10);
                pcVar4 = (code *)in_RCX[10];
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar8) = in_RCX[0xb];
                *(undefined8 *)((int64_t)&var_10h + iVar8) = 1;
                *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5b5f;
                (*pcVar4)(0, 0x304, 0x101, in_R9);
            }
        }
    }
    uVar6 = *(uint64_t *)((int64_t)aiStackX_10 + iVar8 + -8);
    *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801a5aa6;
    fcn.180459870(uVar6 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801a5b70
// Address: 0x1801a5b70
// Size: 199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801a5b70(int64_t arg_28h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    int64_t *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a5b80;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = in_RCX[8];
    if ((((uVar1 != 0) && (uVar2 = in_RCX[9], uVar2 <= uVar1)) && (in_RCX == in_RDX)) && (in_R8 <= uVar2)) {
        if (in_R8 == uVar2) {
            pcVar3 = *(code **)(*in_RCX + 0x28);
            uVar4 = *(undefined8 *)(*in_RCX + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a5bb4;
            iVar5 = (*pcVar3)(uVar1, uVar4);
            if (iVar5 == 0) {
                *(undefined4 *)(in_RCX + 7) = 0x50;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a5bc4;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                             );
                goto code_r0x0001801a5bf8;
            }
            in_RCX[8] = 0;
        }
        in_RCX[9] = in_RCX[9] - in_R8;
        return 1;
    }
    *(undefined4 *)(in_RCX + 7) = 0x50;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a5bf3;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
code_r0x0001801a5bf8:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a5c0b;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801a5c1d;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar6));
    *(uint32_t *)(*in_RCX + 0xa8) = *(uint32_t *)(*in_RCX + 0xa8) | 2;
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801a5c50
// Address: 0x1801a5c50
// Size: 119 bytes
// ============================================================
undefined8 fcn.1801a5c50(int64_t *param_1, int32_t param_2)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a5c5c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_2 != 0x304) {
        if (param_1 != (int64_t *)0x0) {
            *(undefined4 *)(param_1 + 7) = 0x50;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5c7b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5c93;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5ca5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        if (param_1 != (int64_t *)0x0) {
            *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
        }
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801a5d20
// Address: 0x1801a5d20
// Size: 100 bytes
// ============================================================
undefined8 fcn.1801a5d20(int64_t *param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a5d2c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 != (int64_t *)0x0) {
        *(undefined4 *)(param_1 + 7) = 0x50;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5d43;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5d5b;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5d6d;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    if (param_1 != (int64_t *)0x0) {
        *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a5d90
// Address: 0x1801a5d90
// Size: 100 bytes
// ============================================================
undefined8 fcn.1801a5d90(int64_t *param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a5d9c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 != (int64_t *)0x0) {
        *(undefined4 *)(param_1 + 7) = 0x50;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5db3;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5dcb;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5ddd;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    if (param_1 != (int64_t *)0x0) {
        *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a5e00
// Address: 0x1801a5e00
// Size: 100 bytes
// ============================================================
undefined8 fcn.1801a5e00(int64_t *param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a5e0c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 != (int64_t *)0x0) {
        *(undefined4 *)(param_1 + 7) = 0x50;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5e23;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5e3b;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a5e4d;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    if (param_1 != (int64_t *)0x0) {
        *(uint32_t *)(*param_1 + 0xa8) = *(uint32_t *)(*param_1 + 0xa8) | 2;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a5eb0
// Address: 0x1801a5eb0
// Size: 438 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801a5eb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t **in_RCX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a5ec0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar4 = *in_RCX;
    if (piVar4 != (int32_t *)0x0) {
        if (*piVar4 == 0) {
code_r0x0001801a5ef4:
            piVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5f0a;
            iVar2 = func_0x000180193380(piVar1, 0x7b, 0x304, 0);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5f17;
                uVar5 = func_0x0001802542e0();
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5f1f;
                iVar6 = func_0x00018021a7c0(uVar5);
                if (iVar6 != 0) {
                    piVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5f41;
                    func_0x000180194520(piVar1, iVar6, iVar6);
                    piVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5f4e;
                    func_0x000180193130(piVar1, 0x100000);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5f60;
                    func_0x0001801a32b0(piVar4, 0x1804ad9d0, in_RCX);
                    iVar6 = *(int64_t *)(piVar4 + 0x21e);
                    *(int32_t ***)((int64_t)&arg_40h + iVar3) = in_RCX;
                    iVar2 = *(int32_t *)(in_RCX + 0xf);
                    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0x1801a65b0;
                    *(int32_t ***)((int64_t)&arg_30h + iVar3) = in_RCX;
                    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1800086f0;
                    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1801a5e70;
                    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0x4a0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5fb9;
                    iVar2 = func_0x00018019b000(0, iVar6 + 0x80, iVar2 != 0, 0x39);
                    if (iVar2 == 0) {
                        return 0;
                    }
                    piVar4[0x58] = piVar4[0x58] | 0x2000;
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5f29;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                goto code_r0x0001801a5fe5;
            }
        } else if ((char)*piVar4 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5ee8;
            piVar4 = (int32_t *)func_0x0001801bda50(piVar4);
            if (piVar4 != (int32_t *)0x0) goto code_r0x0001801a5ef4;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5fe0;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x0001801a5fe5:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a5ff8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x1804adc38;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a6029;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    if (*(int32_t *)((int64_t)in_RCX + 0x7c) != 0) {
        piVar4 = in_RCX[0x12];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a603b;
        func_0x0001802547a0(piVar4);
        *(uint32_t *)(in_RCX + 0x15) = *(uint32_t *)(in_RCX + 0x15) | 2;
        in_RCX[0x13] = (int32_t *)0x1;
        in_RCX[0x14] = (int32_t *)0x1804adc38;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801a6059;
        func_0x0001802299d0();
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a6070
// Address: 0x1801a6070
// Size: 61 bytes
// ============================================================
void fcn.1801a6070(int64_t arg1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801a6080;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a6092;
        fcn.180220c50(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801a60a7;
        fcn.180224990(arg1, 0x1804ada98, 0x294);
    }
    return;
}

// ============================================================
// Function: FUN_1801a60f0
// Address: 0x1801a60f0
// Size: 53 bytes
// ============================================================
undefined8 fcn.1801a60f0(undefined8 *param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a60fa;
    iVar2 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x1801a6105;
    iVar2 = fcn.18019ce40(uVar1);
    if ((*(int32_t *)(iVar2 + 0x338) != -1) && (*(int32_t *)(iVar2 + 0x338) != 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801a6130
// Address: 0x1801a6130
// Size: 71 bytes
// ============================================================
bool fcn.1801a6130(int32_t **param_1)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801a613a;
    iVar1 = fcn.18045a350();
    piVar2 = *param_1;
    if (piVar2 != (int32_t *)0x0) {
        if (*piVar2 == 0) {
code_r0x0001801a615f:
            return piVar2[0xbe] == 0xd;
        }
        if ((char)*piVar2 < '\0') {
            *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x1801a6157;
            piVar2 = (int32_t *)func_0x0001801bda50(piVar2);
            if (piVar2 != (int32_t *)0x0) goto code_r0x0001801a615f;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801a6180
// Address: 0x1801a6180
// Size: 57 bytes
// ============================================================
undefined4 * fcn.1801a6180(int64_t arg_28h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 *in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a618c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((*(int64_t *)(in_RCX + 2) != 0) && (*(int64_t *)(in_RCX + 6) != 0)) && (*(int64_t *)(in_RCX + 10) != 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a61cf;
        puVar5 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (puVar5 == (undefined4 *)0x0) {
            return (undefined4 *)0x0;
        }
        if (in_RCX[0x1f] != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a61e2;
            iVar6 = fcn.1802542f0();
            *(int64_t *)(puVar5 + 0x24) = iVar6;
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a6203;
                fcn.180224990(puVar5, 0x1804ada98, 0x287);
                return (undefined4 *)0x0;
            }
        }
        uVar1 = in_RCX[1];
        uVar2 = in_RCX[2];
        uVar3 = in_RCX[3];
        *puVar5 = *in_RCX;
        puVar5[1] = uVar1;
        puVar5[2] = uVar2;
        puVar5[3] = uVar3;
        uVar1 = in_RCX[5];
        uVar2 = in_RCX[6];
        uVar3 = in_RCX[7];
        puVar5[4] = in_RCX[4];
        puVar5[5] = uVar1;
        puVar5[6] = uVar2;
        puVar5[7] = uVar3;
        uVar1 = in_RCX[9];
        uVar2 = in_RCX[10];
        uVar3 = in_RCX[0xb];
        puVar5[8] = in_RCX[8];
        puVar5[9] = uVar1;
        puVar5[10] = uVar2;
        puVar5[0xb] = uVar3;
        uVar1 = in_RCX[0xd];
        uVar2 = in_RCX[0xe];
        uVar3 = in_RCX[0xf];
        puVar5[0xc] = in_RCX[0xc];
        puVar5[0xd] = uVar1;
        puVar5[0xe] = uVar2;
        puVar5[0xf] = uVar3;
        uVar1 = in_RCX[0x11];
        uVar2 = in_RCX[0x12];
        uVar3 = in_RCX[0x13];
        puVar5[0x10] = in_RCX[0x10];
        puVar5[0x11] = uVar1;
        puVar5[0x12] = uVar2;
        puVar5[0x13] = uVar3;
        uVar1 = in_RCX[0x15];
        uVar2 = in_RCX[0x16];
        uVar3 = in_RCX[0x17];
        puVar5[0x14] = in_RCX[0x14];
        puVar5[0x15] = uVar1;
        puVar5[0x16] = uVar2;
        puVar5[0x17] = uVar3;
        uVar1 = in_RCX[0x19];
        uVar2 = in_RCX[0x1a];
        uVar3 = in_RCX[0x1b];
        puVar5[0x18] = in_RCX[0x18];
        puVar5[0x19] = uVar1;
        puVar5[0x1a] = uVar2;
        puVar5[0x1b] = uVar3;
        uVar1 = in_RCX[0x1d];
        uVar2 = in_RCX[0x1e];
        uVar3 = in_RCX[0x1f];
        puVar5[0x1c] = in_RCX[0x1c];
        puVar5[0x1d] = uVar1;
        puVar5[0x1e] = uVar2;
        puVar5[0x1f] = uVar3;
        return puVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a6261;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a6279;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a628b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_1801a61b9
// Address: 0x1801a61b9
// Size: 87 bytes
// ============================================================
undefined4 * fcn.1801a6180(int64_t arg_28h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 *in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801a618c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((*(int64_t *)(in_RCX + 2) != 0) && (*(int64_t *)(in_RCX + 6) != 0)) && (*(int64_t *)(in_RCX + 10) != 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a61cf;
        puVar5 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (puVar5 == (undefined4 *)0x0) {
            return (undefined4 *)0x0;
        }
        if (in_RCX[0x1f] != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a61e2;
            iVar6 = fcn.1802542f0();
            *(int64_t *)(puVar5 + 0x24) = iVar6;
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a6203;
                fcn.180224990(puVar5, 0x1804ada98, 0x287);
                return (undefined4 *)0x0;
            }
        }
        uVar1 = in_RCX[1];
        uVar2 = in_RCX[2];
        uVar3 = in_RCX[3];
        *puVar5 = *in_RCX;
        puVar5[1] = uVar1;
        puVar5[2] = uVar2;
        puVar5[3] = uVar3;
        uVar1 = in_RCX[5];
        uVar2 = in_RCX[6];
        uVar3 = in_RCX[7];
        puVar5[4] = in_RCX[4];
        puVar5[5] = uVar1;
        puVar5[6] = uVar2;
        puVar5[7] = uVar3;
        uVar1 = in_RCX[9];
        uVar2 = in_RCX[10];
        uVar3 = in_RCX[0xb];
        puVar5[8] = in_RCX[8];
        puVar5[9] = uVar1;
        puVar5[10] = uVar2;
        puVar5[0xb] = uVar3;
        uVar1 = in_RCX[0xd];
        uVar2 = in_RCX[0xe];
        uVar3 = in_RCX[0xf];
        puVar5[0xc] = in_RCX[0xc];
        puVar5[0xd] = uVar1;
        puVar5[0xe] = uVar2;
        puVar5[0xf] = uVar3;
        uVar1 = in_RCX[0x11];
        uVar2 = in_RCX[0x12];
        uVar3 = in_RCX[0x13];
        puVar5[0x10] = in_RCX[0x10];
        puVar5[0x11] = uVar1;
        puVar5[0x12] = uVar2;
        puVar5[0x13] = uVar3;
        uVar1 = in_RCX[0x15];
        uVar2 = in_RCX[0x16];
        uVar3 = in_RCX[0x17];
        puVar5[0x14] = in_RCX[0x14];
        puVar5[0x15] = uVar1;
        puVar5[0x16] = uVar2;
        puVar5[0x17] = uVar3;
        uVar1 = in_RCX[0x19];
        uVar2 = in_RCX[0x1a];
        uVar3 = in_RCX[0x1b];
        puVar5[0x18] = in_RCX[0x18];
        puVar5[0x19] = uVar1;
        puVar5[0x1a] = uVar2;
        puVar5[0x1b] = uVar3;
        uVar1 = in_RCX[0x1d];
        uVar2 = in_RCX[0x1e];
        uVar3 = in_RCX[0x1f];
        puVar5[0x1c] = in_RCX[0x1c];
        puVar5[0x1d] = uVar1;
        puVar5[0x1e] = uVar2;
        puVar5[0x1f] = uVar3;
        return puVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a6261;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a6279;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801a628b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
    return (undefined4 *)0x0;
}

