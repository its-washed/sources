// Chunk 56 - 50 functions

// ============================================================
// Function: FUN_1800b7682
// Address: 0x1800b7682
// Size: 33 bytes
// ============================================================
void fcn.1800b7682(int64_t arg_80h, int64_t arg_98h)
{
    int64_t unaff_RSI;
    undefined4 in_XMM0_Da;
    undefined4 in_XMM0_Db;
    undefined4 in_XMM0_Dc;
    undefined4 in_XMM0_Dd;
    
    *(undefined4 *)(unaff_RSI + 0x18) = in_XMM0_Da;
    *(undefined4 *)(unaff_RSI + 0x1c) = in_XMM0_Db;
    *(undefined4 *)(unaff_RSI + 0x20) = in_XMM0_Dc;
    *(undefined4 *)(unaff_RSI + 0x24) = in_XMM0_Dd;
    return;
}

// ============================================================
// Function: FUN_1800b76a3
// Address: 0x1800b76a3
// Size: 49 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_36h because it doesn't fit into ProtoModel

void fcn.1800b76a3(int64_t arg_80h, int64_t arg_90h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined uVar5;
    undefined4 *unaff_RSI;
    undefined8 unaff_R12;
    undefined4 *unaff_R14;
    undefined8 *unaff_R15;
    undefined4 in_XMM0_Da;
    undefined uStack0000000000000034;
    undefined2 uStack0000000000000036;
    
    _uStack0000000000000034 = 0;
    uVar5 = fcn.1800ad020(in_XMM0_Da, *unaff_R15);
    uVar1 = *unaff_R14;
    uVar2 = unaff_R14[1];
    uVar3 = unaff_R14[2];
    uVar4 = unaff_R14[3];
    *(undefined *)((int64_t)unaff_RSI + 5) = uVar5;
    *(undefined2 *)((int64_t)unaff_RSI + 6) = uStack0000000000000036;
    *unaff_RSI = 1;
    *(undefined *)(unaff_RSI + 1) = uStack0000000000000034;
    *(undefined8 *)(unaff_RSI + 2) = unaff_R12;
    *(undefined8 *)(unaff_RSI + 4) = unaff_R12;
    unaff_RSI[6] = uVar1;
    unaff_RSI[7] = uVar2;
    unaff_RSI[8] = uVar3;
    unaff_RSI[9] = uVar4;
    return;
}

// ============================================================
// Function: FUN_1800b76d4
// Address: 0x1800b76d4
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37h because it doesn't fit into ProtoModel

void fcn.1800b76d4(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3,
                  int64_t arg_28h, int64_t arg_88h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined uVar5;
    int32_t in_EAX;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *unaff_RSI;
    int64_t unaff_R12;
    undefined4 *unaff_R14;
    int64_t var_20h;
    undefined4 uStack0000000000000034;
    
    iVar7 = unaff_R12;
    if (in_EAX == *(int32_t *)0x180782738) {
        iVar7 = arg3;
    }
    if (iVar7 == 0) {
        iVar7 = unaff_R12;
        if (in_EAX == *(int32_t *)0x18078269c) {
            iVar7 = arg3;
        }
        if (iVar7 == 0) {
            iVar7 = unaff_R12;
            if (in_EAX == *(int32_t *)0x180782730) {
                iVar7 = arg3;
            }
            if (iVar7 == 0) {
                *unaff_RSI = unaff_R12;
                unaff_RSI[1] = unaff_R12;
                unaff_RSI[2] = unaff_R12;
                unaff_RSI[3] = unaff_R12;
                unaff_RSI[4] = unaff_R12;
            } else {
                func_0x0001800b7030(placeholder_0, *(undefined8 *)(iVar7 + 0x20));
                func_0x0001800b74a0();
            }
        } else {
            uStack0000000000000034 = 0;
            uVar5 = func_0x0001800b7030(placeholder_0, *(undefined8 *)(iVar7 + 0x20));
            iVar7 = *(int64_t *)(iVar7 + 0x28);
            iVar6 = func_0x000180498cd0(iVar7);
            uVar1 = *unaff_R14;
            uVar2 = unaff_R14[1];
            uVar3 = unaff_R14[2];
            uVar4 = unaff_R14[3];
            *(undefined2 *)((int64_t)unaff_RSI + 5) = uStack0000000000000034._1_2_;
            *(undefined *)((int64_t)unaff_RSI + 7) = uStack0000000000000034._3_1_;
            *(undefined4 *)unaff_RSI = 3;
            *(undefined *)((int64_t)unaff_RSI + 4) = uVar5;
            unaff_RSI[1] = iVar7;
            unaff_RSI[2] = iVar6;
            *(undefined4 *)(unaff_RSI + 3) = uVar1;
            *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar2;
            *(undefined4 *)(unaff_RSI + 4) = uVar3;
            *(undefined4 *)((int64_t)unaff_RSI + 0x24) = uVar4;
        }
    } else {
        iVar7 = *(int64_t *)(iVar7 + 0x20);
        iVar6 = func_0x000180498cd0(iVar7);
        uVar1 = *unaff_R14;
        uVar2 = unaff_R14[1];
        uVar3 = unaff_R14[2];
        uVar4 = unaff_R14[3];
        *unaff_RSI = 2;
        unaff_RSI[1] = iVar7;
        unaff_RSI[2] = iVar6;
        *(undefined4 *)(unaff_RSI + 3) = uVar1;
        *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar2;
        *(undefined4 *)(unaff_RSI + 4) = uVar3;
        *(undefined4 *)((int64_t)unaff_RSI + 0x24) = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_1800b7710
// Address: 0x1800b7710
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37h because it doesn't fit into ProtoModel

void fcn.1800b76d4(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3,
                  int64_t arg_28h, int64_t arg_88h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined uVar5;
    int32_t in_EAX;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *unaff_RSI;
    int64_t unaff_R12;
    undefined4 *unaff_R14;
    int64_t var_20h;
    undefined4 uStack0000000000000034;
    
    iVar7 = unaff_R12;
    if (in_EAX == *(int32_t *)0x180782738) {
        iVar7 = arg3;
    }
    if (iVar7 == 0) {
        iVar7 = unaff_R12;
        if (in_EAX == *(int32_t *)0x18078269c) {
            iVar7 = arg3;
        }
        if (iVar7 == 0) {
            iVar7 = unaff_R12;
            if (in_EAX == *(int32_t *)0x180782730) {
                iVar7 = arg3;
            }
            if (iVar7 == 0) {
                *unaff_RSI = unaff_R12;
                unaff_RSI[1] = unaff_R12;
                unaff_RSI[2] = unaff_R12;
                unaff_RSI[3] = unaff_R12;
                unaff_RSI[4] = unaff_R12;
            } else {
                func_0x0001800b7030(placeholder_0, *(undefined8 *)(iVar7 + 0x20));
                func_0x0001800b74a0();
            }
        } else {
            uStack0000000000000034 = 0;
            uVar5 = func_0x0001800b7030(placeholder_0, *(undefined8 *)(iVar7 + 0x20));
            iVar7 = *(int64_t *)(iVar7 + 0x28);
            iVar6 = func_0x000180498cd0(iVar7);
            uVar1 = *unaff_R14;
            uVar2 = unaff_R14[1];
            uVar3 = unaff_R14[2];
            uVar4 = unaff_R14[3];
            *(undefined2 *)((int64_t)unaff_RSI + 5) = uStack0000000000000034._1_2_;
            *(undefined *)((int64_t)unaff_RSI + 7) = uStack0000000000000034._3_1_;
            *(undefined4 *)unaff_RSI = 3;
            *(undefined *)((int64_t)unaff_RSI + 4) = uVar5;
            unaff_RSI[1] = iVar7;
            unaff_RSI[2] = iVar6;
            *(undefined4 *)(unaff_RSI + 3) = uVar1;
            *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar2;
            *(undefined4 *)(unaff_RSI + 4) = uVar3;
            *(undefined4 *)((int64_t)unaff_RSI + 0x24) = uVar4;
        }
    } else {
        iVar7 = *(int64_t *)(iVar7 + 0x20);
        iVar6 = func_0x000180498cd0(iVar7);
        uVar1 = *unaff_R14;
        uVar2 = unaff_R14[1];
        uVar3 = unaff_R14[2];
        uVar4 = unaff_R14[3];
        *unaff_RSI = 2;
        unaff_RSI[1] = iVar7;
        unaff_RSI[2] = iVar6;
        *(undefined4 *)(unaff_RSI + 3) = uVar1;
        *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar2;
        *(undefined4 *)(unaff_RSI + 4) = uVar3;
        *(undefined4 *)((int64_t)unaff_RSI + 0x24) = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_1800b7779
// Address: 0x1800b7779
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37h because it doesn't fit into ProtoModel

void fcn.1800b76d4(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3,
                  int64_t arg_28h, int64_t arg_88h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined uVar5;
    int32_t in_EAX;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *unaff_RSI;
    int64_t unaff_R12;
    undefined4 *unaff_R14;
    int64_t var_20h;
    undefined4 uStack0000000000000034;
    
    iVar7 = unaff_R12;
    if (in_EAX == *(int32_t *)0x180782738) {
        iVar7 = arg3;
    }
    if (iVar7 == 0) {
        iVar7 = unaff_R12;
        if (in_EAX == *(int32_t *)0x18078269c) {
            iVar7 = arg3;
        }
        if (iVar7 == 0) {
            iVar7 = unaff_R12;
            if (in_EAX == *(int32_t *)0x180782730) {
                iVar7 = arg3;
            }
            if (iVar7 == 0) {
                *unaff_RSI = unaff_R12;
                unaff_RSI[1] = unaff_R12;
                unaff_RSI[2] = unaff_R12;
                unaff_RSI[3] = unaff_R12;
                unaff_RSI[4] = unaff_R12;
            } else {
                func_0x0001800b7030(placeholder_0, *(undefined8 *)(iVar7 + 0x20));
                func_0x0001800b74a0();
            }
        } else {
            uStack0000000000000034 = 0;
            uVar5 = func_0x0001800b7030(placeholder_0, *(undefined8 *)(iVar7 + 0x20));
            iVar7 = *(int64_t *)(iVar7 + 0x28);
            iVar6 = func_0x000180498cd0(iVar7);
            uVar1 = *unaff_R14;
            uVar2 = unaff_R14[1];
            uVar3 = unaff_R14[2];
            uVar4 = unaff_R14[3];
            *(undefined2 *)((int64_t)unaff_RSI + 5) = uStack0000000000000034._1_2_;
            *(undefined *)((int64_t)unaff_RSI + 7) = uStack0000000000000034._3_1_;
            *(undefined4 *)unaff_RSI = 3;
            *(undefined *)((int64_t)unaff_RSI + 4) = uVar5;
            unaff_RSI[1] = iVar7;
            unaff_RSI[2] = iVar6;
            *(undefined4 *)(unaff_RSI + 3) = uVar1;
            *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar2;
            *(undefined4 *)(unaff_RSI + 4) = uVar3;
            *(undefined4 *)((int64_t)unaff_RSI + 0x24) = uVar4;
        }
    } else {
        iVar7 = *(int64_t *)(iVar7 + 0x20);
        iVar6 = func_0x000180498cd0(iVar7);
        uVar1 = *unaff_R14;
        uVar2 = unaff_R14[1];
        uVar3 = unaff_R14[2];
        uVar4 = unaff_R14[3];
        *unaff_RSI = 2;
        unaff_RSI[1] = iVar7;
        unaff_RSI[2] = iVar6;
        *(undefined4 *)(unaff_RSI + 3) = uVar1;
        *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar2;
        *(undefined4 *)(unaff_RSI + 4) = uVar3;
        *(undefined4 *)((int64_t)unaff_RSI + 0x24) = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_1800b77b4
// Address: 0x1800b77b4
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_35h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_37h because it doesn't fit into ProtoModel

void fcn.1800b76d4(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3,
                  int64_t arg_28h, int64_t arg_88h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined uVar5;
    int32_t in_EAX;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *unaff_RSI;
    int64_t unaff_R12;
    undefined4 *unaff_R14;
    int64_t var_20h;
    undefined4 uStack0000000000000034;
    
    iVar7 = unaff_R12;
    if (in_EAX == *(int32_t *)0x180782738) {
        iVar7 = arg3;
    }
    if (iVar7 == 0) {
        iVar7 = unaff_R12;
        if (in_EAX == *(int32_t *)0x18078269c) {
            iVar7 = arg3;
        }
        if (iVar7 == 0) {
            iVar7 = unaff_R12;
            if (in_EAX == *(int32_t *)0x180782730) {
                iVar7 = arg3;
            }
            if (iVar7 == 0) {
                *unaff_RSI = unaff_R12;
                unaff_RSI[1] = unaff_R12;
                unaff_RSI[2] = unaff_R12;
                unaff_RSI[3] = unaff_R12;
                unaff_RSI[4] = unaff_R12;
            } else {
                func_0x0001800b7030(placeholder_0, *(undefined8 *)(iVar7 + 0x20));
                func_0x0001800b74a0();
            }
        } else {
            uStack0000000000000034 = 0;
            uVar5 = func_0x0001800b7030(placeholder_0, *(undefined8 *)(iVar7 + 0x20));
            iVar7 = *(int64_t *)(iVar7 + 0x28);
            iVar6 = func_0x000180498cd0(iVar7);
            uVar1 = *unaff_R14;
            uVar2 = unaff_R14[1];
            uVar3 = unaff_R14[2];
            uVar4 = unaff_R14[3];
            *(undefined2 *)((int64_t)unaff_RSI + 5) = uStack0000000000000034._1_2_;
            *(undefined *)((int64_t)unaff_RSI + 7) = uStack0000000000000034._3_1_;
            *(undefined4 *)unaff_RSI = 3;
            *(undefined *)((int64_t)unaff_RSI + 4) = uVar5;
            unaff_RSI[1] = iVar7;
            unaff_RSI[2] = iVar6;
            *(undefined4 *)(unaff_RSI + 3) = uVar1;
            *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar2;
            *(undefined4 *)(unaff_RSI + 4) = uVar3;
            *(undefined4 *)((int64_t)unaff_RSI + 0x24) = uVar4;
        }
    } else {
        iVar7 = *(int64_t *)(iVar7 + 0x20);
        iVar6 = func_0x000180498cd0(iVar7);
        uVar1 = *unaff_R14;
        uVar2 = unaff_R14[1];
        uVar3 = unaff_R14[2];
        uVar4 = unaff_R14[3];
        *unaff_RSI = 2;
        unaff_RSI[1] = iVar7;
        unaff_RSI[2] = iVar6;
        *(undefined4 *)(unaff_RSI + 3) = uVar1;
        *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar2;
        *(undefined4 *)(unaff_RSI + 4) = uVar3;
        *(undefined4 *)((int64_t)unaff_RSI + 0x24) = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_1800b77e0
// Address: 0x1800b77e0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800b77e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(arg2 + 0x18) + 1;
    }
    if (5 < *(uint32_t *)arg2) {
        return;
    }
    uVar2 = (uint32_t)(uint8_t)placeholder_3;
    // switch table (6 cases) at 0x1800b7b64
    switch(*(uint32_t *)arg2) {
    case 0:
        uVar5 = *(undefined *)(arg2 + 4);
        if ((uint8_t)placeholder_3 != 0) {
            uVar5 = (undefined)placeholder_2;
            placeholder_2._0_1_ = *(undefined *)(arg2 + 4);
        }
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 6, (undefined)placeholder_2, uVar5, (int32_t)var_68h);
        break;
    case 1:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 9, (undefined)placeholder_2, *(undefined *)(arg2 + 5), 
                            (int32_t)var_68h);
        break;
    case 2:
        var_58h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_58h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        uVar4 = *(undefined8 *)arg1;
        var_50h = *(undefined8 *)(arg2 + 0x10);
        var_50h._0_4_ = func_0x0001800cf010(uVar4, &var_58h);
        var_58h._0_4_ = 5;
        stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
        var_38h._0_4_ = 5;
        _var_30h = ZEXT416((uint32_t)var_50h);
        iVar3 = func_0x0001800ced20(uVar4, &var_38h, &var_58h);
        if (iVar3 < 0) {
code_r0x0001800b7b50:
            func_0x0001800acea0(arg2 + 0x18, 0x18063f5a0);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar8 = *(uint64_t *)(arg2 + 0x10);
        uVar7 = uVar8;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
            uVar7 = (uint64_t)
                    ((uint32_t)uVar7 ^
                    (uint32_t)*(uint8_t *)(*(int64_t *)(arg2 + 8) + -1 + uVar8) + (uint32_t)uVar7 * 0x20 +
                    ((uint32_t)(uVar7 >> 2) & 0x3fffffff));
        }
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, (char)uVar7);
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 7, (undefined)placeholder_2, 0, (int32_t)var_68h);
        func_0x0001800cfe80(*(undefined8 *)arg1, iVar3);
        break;
    case 3:
        var_58h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_58h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        var_50h = *(int64_t *)(arg2 + 0x10);
        uVar4 = *(undefined8 *)arg1;
        var_30h._0_4_ = func_0x0001800cf010(uVar4, &var_58h);
        var_38h._0_4_ = 5;
        stack0xffffffffffffffd4 = SUB1612(ZEXT816(0), 4);
        var_58h._0_4_ = 5;
        _var_50h = ZEXT416((uint32_t)var_30h);
        iVar3 = func_0x0001800ced20(uVar4, &var_58h, &var_38h);
        if (iVar3 < 0) goto code_r0x0001800b7b50;
        uVar8 = *(uint64_t *)(arg2 + 0x10);
        uVar7 = uVar8;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
            uVar7 = (uint64_t)
                    ((uint32_t)uVar7 ^
                    (uint32_t)*(uint8_t *)(*(int64_t *)(arg2 + 8) + -1 + uVar8) + (uint32_t)uVar7 * 0x20 +
                    ((uint32_t)(uVar7 >> 2) & 0x3fffffff));
        }
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, (char)uVar7);
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0xf, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        func_0x0001800cfe80(*(undefined8 *)arg1, iVar3);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x18078269c) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        uVar5 = *(undefined *)(arg2 + 4);
        uVar9 = 4;
        uVar4 = *(undefined8 *)(iVar6 + 0x20);
        var_68h._0_4_ = 2;
        goto code_r0x0001800b7b21;
    case 4:
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, *(undefined *)(arg2 + 7));
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0x11, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x180782730) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        uVar5 = *(undefined *)(arg2 + 4);
        uVar9 = 4;
        uVar4 = *(undefined8 *)(iVar6 + 0x20);
        goto code_r0x0001800b7b19;
    case 5:
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, *(undefined *)(arg2 + 6));
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0xd, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x180782730) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        func_0x0001800bbfb0(arg1, *(undefined8 *)(iVar6 + 0x20), *(undefined *)(arg2 + 4), 4, 1);
        uVar5 = *(undefined *)(arg2 + 6);
        uVar9 = 2;
        uVar4 = *(undefined8 *)(iVar6 + 0x28);
code_r0x0001800b7b19:
        var_68h._0_4_ = 1;
code_r0x0001800b7b21:
        func_0x0001800bbfb0(arg1, uVar4, uVar5, uVar9, (int32_t)var_68h);
    }
    return;
}

// ============================================================
// Function: FUN_1800b7825
// Address: 0x1800b7825
// Size: 788 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800b77e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(arg2 + 0x18) + 1;
    }
    if (5 < *(uint32_t *)arg2) {
        return;
    }
    uVar2 = (uint32_t)(uint8_t)placeholder_3;
    // switch table (6 cases) at 0x1800b7b64
    switch(*(uint32_t *)arg2) {
    case 0:
        uVar5 = *(undefined *)(arg2 + 4);
        if ((uint8_t)placeholder_3 != 0) {
            uVar5 = (undefined)placeholder_2;
            placeholder_2._0_1_ = *(undefined *)(arg2 + 4);
        }
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 6, (undefined)placeholder_2, uVar5, (int32_t)var_68h);
        break;
    case 1:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 9, (undefined)placeholder_2, *(undefined *)(arg2 + 5), 
                            (int32_t)var_68h);
        break;
    case 2:
        var_58h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_58h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        uVar4 = *(undefined8 *)arg1;
        var_50h = *(undefined8 *)(arg2 + 0x10);
        var_50h._0_4_ = func_0x0001800cf010(uVar4, &var_58h);
        var_58h._0_4_ = 5;
        stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
        var_38h._0_4_ = 5;
        _var_30h = ZEXT416((uint32_t)var_50h);
        iVar3 = func_0x0001800ced20(uVar4, &var_38h, &var_58h);
        if (iVar3 < 0) {
code_r0x0001800b7b50:
            func_0x0001800acea0(arg2 + 0x18, 0x18063f5a0);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar8 = *(uint64_t *)(arg2 + 0x10);
        uVar7 = uVar8;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
            uVar7 = (uint64_t)
                    ((uint32_t)uVar7 ^
                    (uint32_t)*(uint8_t *)(*(int64_t *)(arg2 + 8) + -1 + uVar8) + (uint32_t)uVar7 * 0x20 +
                    ((uint32_t)(uVar7 >> 2) & 0x3fffffff));
        }
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, (char)uVar7);
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 7, (undefined)placeholder_2, 0, (int32_t)var_68h);
        func_0x0001800cfe80(*(undefined8 *)arg1, iVar3);
        break;
    case 3:
        var_58h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_58h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        var_50h = *(int64_t *)(arg2 + 0x10);
        uVar4 = *(undefined8 *)arg1;
        var_30h._0_4_ = func_0x0001800cf010(uVar4, &var_58h);
        var_38h._0_4_ = 5;
        stack0xffffffffffffffd4 = SUB1612(ZEXT816(0), 4);
        var_58h._0_4_ = 5;
        _var_50h = ZEXT416((uint32_t)var_30h);
        iVar3 = func_0x0001800ced20(uVar4, &var_58h, &var_38h);
        if (iVar3 < 0) goto code_r0x0001800b7b50;
        uVar8 = *(uint64_t *)(arg2 + 0x10);
        uVar7 = uVar8;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
            uVar7 = (uint64_t)
                    ((uint32_t)uVar7 ^
                    (uint32_t)*(uint8_t *)(*(int64_t *)(arg2 + 8) + -1 + uVar8) + (uint32_t)uVar7 * 0x20 +
                    ((uint32_t)(uVar7 >> 2) & 0x3fffffff));
        }
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, (char)uVar7);
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0xf, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        func_0x0001800cfe80(*(undefined8 *)arg1, iVar3);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x18078269c) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        uVar5 = *(undefined *)(arg2 + 4);
        uVar9 = 4;
        uVar4 = *(undefined8 *)(iVar6 + 0x20);
        var_68h._0_4_ = 2;
        goto code_r0x0001800b7b21;
    case 4:
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, *(undefined *)(arg2 + 7));
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0x11, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x180782730) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        uVar5 = *(undefined *)(arg2 + 4);
        uVar9 = 4;
        uVar4 = *(undefined8 *)(iVar6 + 0x20);
        goto code_r0x0001800b7b19;
    case 5:
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, *(undefined *)(arg2 + 6));
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0xd, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x180782730) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        func_0x0001800bbfb0(arg1, *(undefined8 *)(iVar6 + 0x20), *(undefined *)(arg2 + 4), 4, 1);
        uVar5 = *(undefined *)(arg2 + 6);
        uVar9 = 2;
        uVar4 = *(undefined8 *)(iVar6 + 0x28);
code_r0x0001800b7b19:
        var_68h._0_4_ = 1;
code_r0x0001800b7b21:
        func_0x0001800bbfb0(arg1, uVar4, uVar5, uVar9, (int32_t)var_68h);
    }
    return;
}

// ============================================================
// Function: FUN_1800b7b39
// Address: 0x1800b7b39
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800b77e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(arg2 + 0x18) + 1;
    }
    if (5 < *(uint32_t *)arg2) {
        return;
    }
    uVar2 = (uint32_t)(uint8_t)placeholder_3;
    // switch table (6 cases) at 0x1800b7b64
    switch(*(uint32_t *)arg2) {
    case 0:
        uVar5 = *(undefined *)(arg2 + 4);
        if ((uint8_t)placeholder_3 != 0) {
            uVar5 = (undefined)placeholder_2;
            placeholder_2._0_1_ = *(undefined *)(arg2 + 4);
        }
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 6, (undefined)placeholder_2, uVar5, (int32_t)var_68h);
        break;
    case 1:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 9, (undefined)placeholder_2, *(undefined *)(arg2 + 5), 
                            (int32_t)var_68h);
        break;
    case 2:
        var_58h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_58h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        uVar4 = *(undefined8 *)arg1;
        var_50h = *(undefined8 *)(arg2 + 0x10);
        var_50h._0_4_ = func_0x0001800cf010(uVar4, &var_58h);
        var_58h._0_4_ = 5;
        stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
        var_38h._0_4_ = 5;
        _var_30h = ZEXT416((uint32_t)var_50h);
        iVar3 = func_0x0001800ced20(uVar4, &var_38h, &var_58h);
        if (iVar3 < 0) {
code_r0x0001800b7b50:
            func_0x0001800acea0(arg2 + 0x18, 0x18063f5a0);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar8 = *(uint64_t *)(arg2 + 0x10);
        uVar7 = uVar8;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
            uVar7 = (uint64_t)
                    ((uint32_t)uVar7 ^
                    (uint32_t)*(uint8_t *)(*(int64_t *)(arg2 + 8) + -1 + uVar8) + (uint32_t)uVar7 * 0x20 +
                    ((uint32_t)(uVar7 >> 2) & 0x3fffffff));
        }
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, (char)uVar7);
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 7, (undefined)placeholder_2, 0, (int32_t)var_68h);
        func_0x0001800cfe80(*(undefined8 *)arg1, iVar3);
        break;
    case 3:
        var_58h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_58h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        var_50h = *(int64_t *)(arg2 + 0x10);
        uVar4 = *(undefined8 *)arg1;
        var_30h._0_4_ = func_0x0001800cf010(uVar4, &var_58h);
        var_38h._0_4_ = 5;
        stack0xffffffffffffffd4 = SUB1612(ZEXT816(0), 4);
        var_58h._0_4_ = 5;
        _var_50h = ZEXT416((uint32_t)var_30h);
        iVar3 = func_0x0001800ced20(uVar4, &var_58h, &var_38h);
        if (iVar3 < 0) goto code_r0x0001800b7b50;
        uVar8 = *(uint64_t *)(arg2 + 0x10);
        uVar7 = uVar8;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
            uVar7 = (uint64_t)
                    ((uint32_t)uVar7 ^
                    (uint32_t)*(uint8_t *)(*(int64_t *)(arg2 + 8) + -1 + uVar8) + (uint32_t)uVar7 * 0x20 +
                    ((uint32_t)(uVar7 >> 2) & 0x3fffffff));
        }
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, (char)uVar7);
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0xf, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        func_0x0001800cfe80(*(undefined8 *)arg1, iVar3);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x18078269c) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        uVar5 = *(undefined *)(arg2 + 4);
        uVar9 = 4;
        uVar4 = *(undefined8 *)(iVar6 + 0x20);
        var_68h._0_4_ = 2;
        goto code_r0x0001800b7b21;
    case 4:
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, *(undefined *)(arg2 + 7));
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0x11, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x180782730) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        uVar5 = *(undefined *)(arg2 + 4);
        uVar9 = 4;
        uVar4 = *(undefined8 *)(iVar6 + 0x20);
        goto code_r0x0001800b7b19;
    case 5:
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, *(undefined *)(arg2 + 6));
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0xd, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x180782730) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        func_0x0001800bbfb0(arg1, *(undefined8 *)(iVar6 + 0x20), *(undefined *)(arg2 + 4), 4, 1);
        uVar5 = *(undefined *)(arg2 + 6);
        uVar9 = 2;
        uVar4 = *(undefined8 *)(iVar6 + 0x28);
code_r0x0001800b7b19:
        var_68h._0_4_ = 1;
code_r0x0001800b7b21:
        func_0x0001800bbfb0(arg1, uVar4, uVar5, uVar9, (int32_t)var_68h);
    }
    return;
}

// ============================================================
// Function: FUN_1800b7b50
// Address: 0x1800b7b50
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1800b77e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(arg2 + 0x18) + 1;
    }
    if (5 < *(uint32_t *)arg2) {
        return;
    }
    uVar2 = (uint32_t)(uint8_t)placeholder_3;
    // switch table (6 cases) at 0x1800b7b64
    switch(*(uint32_t *)arg2) {
    case 0:
        uVar5 = *(undefined *)(arg2 + 4);
        if ((uint8_t)placeholder_3 != 0) {
            uVar5 = (undefined)placeholder_2;
            placeholder_2._0_1_ = *(undefined *)(arg2 + 4);
        }
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, 6, (undefined)placeholder_2, uVar5, (int32_t)var_68h);
        break;
    case 1:
        var_68h._0_4_ = (uint32_t)var_68h._1_3_ << 8;
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 9, (undefined)placeholder_2, *(undefined *)(arg2 + 5), 
                            (int32_t)var_68h);
        break;
    case 2:
        var_58h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_58h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        uVar4 = *(undefined8 *)arg1;
        var_50h = *(undefined8 *)(arg2 + 0x10);
        var_50h._0_4_ = func_0x0001800cf010(uVar4, &var_58h);
        var_58h._0_4_ = 5;
        stack0xffffffffffffffb4 = SUB1612(ZEXT816(0), 4);
        var_38h._0_4_ = 5;
        _var_30h = ZEXT416((uint32_t)var_50h);
        iVar3 = func_0x0001800ced20(uVar4, &var_38h, &var_58h);
        if (iVar3 < 0) {
code_r0x0001800b7b50:
            func_0x0001800acea0(arg2 + 0x18, 0x18063f5a0);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar8 = *(uint64_t *)(arg2 + 0x10);
        uVar7 = uVar8;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
            uVar7 = (uint64_t)
                    ((uint32_t)uVar7 ^
                    (uint32_t)*(uint8_t *)(*(int64_t *)(arg2 + 8) + -1 + uVar8) + (uint32_t)uVar7 * 0x20 +
                    ((uint32_t)(uVar7 >> 2) & 0x3fffffff));
        }
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, (char)uVar7);
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 7, (undefined)placeholder_2, 0, (int32_t)var_68h);
        func_0x0001800cfe80(*(undefined8 *)arg1, iVar3);
        break;
    case 3:
        var_58h._0_4_ = *(undefined4 *)(arg2 + 8);
        var_58h._4_4_ = *(undefined4 *)(arg2 + 0xc);
        var_50h = *(int64_t *)(arg2 + 0x10);
        uVar4 = *(undefined8 *)arg1;
        var_30h._0_4_ = func_0x0001800cf010(uVar4, &var_58h);
        var_38h._0_4_ = 5;
        stack0xffffffffffffffd4 = SUB1612(ZEXT816(0), 4);
        var_58h._0_4_ = 5;
        _var_50h = ZEXT416((uint32_t)var_30h);
        iVar3 = func_0x0001800ced20(uVar4, &var_58h, &var_38h);
        if (iVar3 < 0) goto code_r0x0001800b7b50;
        uVar8 = *(uint64_t *)(arg2 + 0x10);
        uVar7 = uVar8;
        for (; uVar8 != 0; uVar8 = uVar8 - 1) {
            uVar7 = (uint64_t)
                    ((uint32_t)uVar7 ^
                    (uint32_t)*(uint8_t *)(*(int64_t *)(arg2 + 8) + -1 + uVar8) + (uint32_t)uVar7 * 0x20 +
                    ((uint32_t)(uVar7 >> 2) & 0x3fffffff));
        }
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, (char)uVar7);
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0xf, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        func_0x0001800cfe80(*(undefined8 *)arg1, iVar3);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x18078269c) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        uVar5 = *(undefined *)(arg2 + 4);
        uVar9 = 4;
        uVar4 = *(undefined8 *)(iVar6 + 0x20);
        var_68h._0_4_ = 2;
        goto code_r0x0001800b7b21;
    case 4:
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, *(undefined *)(arg2 + 7));
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0x11, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x180782730) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        uVar5 = *(undefined *)(arg2 + 4);
        uVar9 = 4;
        uVar4 = *(undefined8 *)(iVar6 + 0x20);
        goto code_r0x0001800b7b19;
    case 5:
        var_68h._0_4_ = CONCAT31(var_68h._1_3_, *(undefined *)(arg2 + 6));
        func_0x0001800cfdd0(*(undefined8 *)arg1, uVar2 + 0xd, (undefined)placeholder_2, *(undefined *)(arg2 + 4), 
                            (int32_t)var_68h);
        if (arg_28h == 0) {
            return;
        }
        iVar6 = 0;
        if (*(int32_t *)(arg_28h + 8) == *(int32_t *)0x180782730) {
            iVar6 = arg_28h;
        }
        if (iVar6 == 0) {
            return;
        }
        func_0x0001800bbfb0(arg1, *(undefined8 *)(iVar6 + 0x20), *(undefined *)(arg2 + 4), 4, 1);
        uVar5 = *(undefined *)(arg2 + 6);
        uVar9 = 2;
        uVar4 = *(undefined8 *)(iVar6 + 0x28);
code_r0x0001800b7b19:
        var_68h._0_4_ = 1;
code_r0x0001800b7b21:
        func_0x0001800bbfb0(arg1, uVar4, uVar5, uVar9, (int32_t)var_68h);
    }
    return;
}

// ============================================================
// Function: FUN_1800b7be0
// Address: 0x1800b7be0
// Size: 147 bytes
// ============================================================
uint64_t fcn.1800b7be0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    uint8_t *puVar3;
    
    if (*(char *)0x180777f78 == '\0') {
        iVar1 = *(int32_t *)(arg2 + 8);
        iVar2 = 0;
        if (iVar1 == *(int32_t *)0x180782728) {
            iVar2 = arg2;
        }
        if (iVar2 != 0) goto code_r0x0001800b7c3a;
        iVar2 = 0;
        if (iVar1 == *(int32_t *)0x1807826c0) {
            iVar2 = arg2;
        }
        if (iVar2 == 0) {
            if (iVar1 == *(int32_t *)0x180782708) {
                iVar2 = arg2;
            }
            if (iVar2 == 0) {
                return 0xffffffff;
            }
        }
        iVar2 = func_0x0001800b7b80(iVar1, *(undefined8 *)(iVar2 + 0x20));
    } else {
        iVar2 = func_0x0001800beb60(arg2);
    }
    if (iVar2 == 0) {
        return 0xffffffff;
    }
code_r0x0001800b7c3a:
    iVar2 = func_0x0001800ac770(arg1 + 0x88, iVar2 + 0x20);
    puVar3 = (uint8_t *)(iVar2 + 8);
    if (iVar2 == 0) {
        puVar3 = (uint8_t *)0x0;
    }
    if ((puVar3 != (uint8_t *)0x0) && (puVar3[1] != 0)) {
        return (uint64_t)*puVar3;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800b7c80
// Address: 0x1800b7c80
// Size: 63 bytes
// ============================================================
undefined8 fcn.1800b7c80(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int32_t iVar2;
    uint64_t uVar3;
    
    iVar2 = fcn.1800acf70(*(undefined8 *)(arg1 + 8), *(undefined8 *)(arg2 + 0x20));
    if (-1 < iVar2) {
        uVar3 = 1LL << ((uint8_t)iVar2 & 0x3f);
        if ((*(uint64_t *)(arg1 + 0x30 + ((uint64_t)(int64_t)iVar2 >> 6) * 8) & uVar3) != 0) {
            puVar1 = (uint64_t *)(arg1 + 0x10 + ((uint64_t)(int64_t)iVar2 >> 6) * 8);
            *puVar1 = *puVar1 | uVar3;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800b7cc0
// Address: 0x1800b7cc0
// Size: 15732 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_248h
// WARNING: Variable defined which should be unmapped: var_240h
// WARNING: Variable defined which should be unmapped: var_238h
// WARNING: Variable defined which should be unmapped: var_230h
// WARNING: Variable defined which should be unmapped: var_228h
// WARNING: Variable defined which should be unmapped: var_220h
// WARNING: Variable defined which should be unmapped: var_218h
// WARNING: Variable defined which should be unmapped: var_208h
// WARNING: Variable defined which should be unmapped: var_200h
// WARNING: Variable defined which should be unmapped: var_1f8h
// WARNING: Variable defined which should be unmapped: var_1f0h
// WARNING: Variable defined which should be unmapped: var_14h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_21h

void fcn.1800b7cc0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t **placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  undefined8 placeholder_16, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
                  int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h,
                  undefined8 placeholder_26, int64_t arg_e0h, undefined8 placeholder_28, int64_t arg_f0h)
{
    double dVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    bool bVar9;
    char cVar10;
    uint8_t uVar11;
    undefined uVar12;
    uint8_t uVar13;
    undefined uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    undefined4 uVar18;
    int32_t iVar19;
    int32_t iVar20;
    uint64_t uVar21;
    undefined *puVar22;
    char *pcVar23;
    int32_t *piVar24;
    undefined4 *puVar25;
    uint64_t uVar26;
    int64_t *piVar27;
    int64_t iVar28;
    int64_t iVar29;
    uint32_t uVar30;
    uint64_t uVar31;
    int64_t **ppiVar32;
    uint64_t uVar33;
    uint64_t *puVar34;
    uint64_t *puVar35;
    uint64_t uVar36;
    int32_t iVar37;
    int64_t *piVar38;
    int64_t *piVar39;
    int64_t iVar40;
    int64_t *piVar41;
    undefined *puVar42;
    undefined *puVar43;
    int64_t iVar44;
    int64_t **ppiVar45;
    int64_t **ppiVar46;
    int64_t iVar47;
    int64_t iVar48;
    int32_t iVar49;
    int64_t *piVar50;
    int64_t *piVar51;
    int64_t **ppiVar52;
    int64_t *piVar53;
    int64_t iVar54;
    int64_t **ppiVar55;
    uint64_t *puVar56;
    int64_t *piVar57;
    undefined8 *puVar58;
    undefined8 uVar59;
    undefined8 extraout_XMM0_Qa;
    int64_t var_8h;
    int64_t var_14h;
    undefined8 uStackY_270;
    undefined auStackY_268 [8];
    undefined auStackY_260 [24];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t in_stack_fffffffffffffdf0;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    undefined8 in_stack_fffffffffffffe18;
    int64_t *piVar60;
    int64_t *piVar61;
    int64_t in_stack_fffffffffffffe20;
    int64_t in_stack_fffffffffffffe28;
    int64_t *piVar62;
    int64_t in_stack_fffffffffffffe30;
    int64_t in_stack_fffffffffffffe38;
    int64_t in_stack_fffffffffffffe40;
    uint64_t in_stack_fffffffffffffe48;
    int64_t in_stack_fffffffffffffe50;
    undefined in_stack_fffffffffffffe58 [16];
    double dVar66;
    undefined auVar63 [16];
    undefined auVar64 [16];
    undefined auVar65 [16];
    undefined8 in_stack_fffffffffffffe68;
    int64_t in_stack_fffffffffffffe70;
    undefined in_stack_fffffffffffffe78;
    unkbyte7 in_stack_fffffffffffffe79;
    undefined4 in_stack_fffffffffffffe80;
    undefined4 in_stack_fffffffffffffe84;
    undefined4 uVar67;
    int64_t **ppiStack_160;
    undefined8 uStack_158;
    int64_t *piStack_150;
    undefined8 uStack_148;
    undefined auStack_140 [16];
    undefined *puStack_130;
    uint64_t uStack_128;
    undefined auStack_120 [8];
    undefined8 uStack_118;
    int64_t iStack_110;
    undefined8 *puStack_108;
    undefined8 uStack_100;
    undefined auStack_f8 [8];
    int64_t iStack_f0;
    uint64_t uStack_e8;
    int64_t **ppiStack_d8;
    int64_t **ppiStack_d0;
    undefined8 uStack_c8;
    int64_t *piStack_c0;
    int64_t **ppiStack_b8;
    int64_t *piStack_b0;
    int64_t *piStack_a8;
    uint64_t uStack_a0;
    uint64_t auStack_98 [2];
    undefined auStack_88 [8];
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar22 = auStackY_268;
    puVar43 = auStackY_268;
    puVar42 = auStackY_268;
    var_78h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_268;
    uVar26 = 0;
    ppiVar32 = (int64_t **)(in_stack_fffffffffffffe48 & 0xffffffff00000000);
    if (0 < *(int32_t *)(arg1 + 0xc)) {
        *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)(arg2 + 0xc) + 1;
    }
    if (((0 < *(int32_t *)(arg1 + 0x14)) && (*(int32_t *)(arg2 + 8) != *(int32_t *)0x180782718)) &&
       (*(int32_t *)(arg2 + 8) != *(int32_t *)0x18078266c)) {
        iVar54 = *(int64_t *)arg1;
        in_stack_fffffffffffffe20 = CONCAT44((int32_t)((uint64_t)in_stack_fffffffffffffe20 >> 0x20), 0x45);
        func_0x0001800d31a0(iVar54 + 0x28, &stack0xfffffffffffffe20);
        func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
    }
    iVar19 = *(int32_t *)0x180782718;
    ppiVar46 = (int64_t **)0x0;
    iVar15 = *(int32_t *)(arg2 + 8);
    ppiVar45 = ppiVar46;
    if (iVar15 == *(int32_t *)0x180782718) {
        ppiVar45 = (int64_t **)arg2;
    }
    if (ppiVar45 != (int64_t **)0x0) {
        uVar18 = *(undefined4 *)(arg1 + 0x60c);
        iVar44 = CONCAT44((int32_t)((uint64_t)in_stack_fffffffffffffe30 >> 0x20), uVar18);
        iVar54 = *(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3;
        if (*(char *)0x180778520 != '\0') {
            *(int64_t *)(arg1 + 0x630) = *(int64_t *)(arg1 + 0x630) + 1;
        }
        iVar48 = arg1;
        if (ppiVar45[6] != (int64_t *)0x0) {
            do {
                iVar28 = ppiVar45[5][(int64_t)ppiVar46];
                fcn.1800b7cc0(arg1, iVar28, placeholder_2, placeholder_3, var_248h, var_240h, var_238h, var_230h, 
                              var_228h, var_220h, var_218h, in_stack_fffffffffffffdf0, arg1, var_200h, var_1f8h, 
                              var_1f0h, in_stack_fffffffffffffe18, in_stack_fffffffffffffe20, iVar48, iVar44, 
                              in_stack_fffffffffffffe38, in_stack_fffffffffffffe40, (int64_t)ppiVar32, 
                              in_stack_fffffffffffffe50, (int64_t)in_stack_fffffffffffffe58._0_8_, 
                              in_stack_fffffffffffffe58._8_8_, in_stack_fffffffffffffe68, in_stack_fffffffffffffe70, 
                              CONCAT71(in_stack_fffffffffffffe79, in_stack_fffffffffffffe78), 
                              CONCAT44(in_stack_fffffffffffffe84, in_stack_fffffffffffffe80));
                cVar10 = func_0x0001800acb30(arg1 + 0x100, iVar28);
                if (cVar10 != '\0') break;
                ppiVar46 = (int64_t **)((int64_t)ppiVar46 + 1);
            } while (ppiVar46 < ppiVar45[6]);
        }
        if (*(char *)0x180778520 != '\0') {
            *(int64_t *)(arg1 + 0x630) = *(int64_t *)(arg1 + 0x630) + -1;
        }
        func_0x0001800bbb60(arg1, iVar54);
        func_0x0001800bbc30(arg1, iVar54);
        *(undefined4 *)(arg1 + 0x60c) = uVar18;
        puVar42 = auStackY_268;
        goto code_r0x0001800bb7ba;
    }
    ppiVar45 = ppiVar46;
    if (iVar15 == *(int32_t *)0x180782724) {
        ppiVar45 = (int64_t **)arg2;
    }
    if (ppiVar45 != (int64_t **)0x0) {
        ppiVar55 = (int64_t **)ppiVar45[5];
        uVar26 = arg1 + 0x100;
        cVar10 = func_0x0001800aca90(uVar26, ppiVar55);
        if (cVar10 == '\0') {
            if (*(int32_t *)(ppiVar55 + 1) == *(int32_t *)0x180782668) {
                ppiVar46 = ppiVar55;
            }
            if (((ppiVar46 == (int64_t **)0x0) || (*(int32_t *)(ppiVar46 + 4) != 0xe)) ||
               (cVar10 = func_0x0001800aca90(uVar26, ppiVar46[6]), cVar10 == '\0')) {
                piVar60 = ppiVar45[7];
                if (piVar60 == (int64_t *)0x0) {
                    iVar15 = *(int32_t *)(ppiVar45[6] + 1);
                    piVar27 = (int64_t *)0x0;
                    if (iVar15 == iVar19) {
                        piVar27 = ppiVar45[6];
                    }
                    if (piVar27 != (int64_t *)0x0) {
                        if (piVar27[6] != 1) goto code_r0x0001800b7ef5;
                        iVar15 = *(int32_t *)(*(int64_t *)piVar27[5] + 8);
                    }
                    if ((iVar15 != *(int32_t *)0x180782700) ||
                       (cVar10 = func_0x0001800bbae0(arg1, *(undefined8 *)(*(int64_t *)(arg1 + 0x690) + -0x18)),
                       cVar10 != '\0')) goto code_r0x0001800b7ef5;
                    in_stack_fffffffffffffe58 = ZEXT816(0);
                    iVar54 = 0;
                    var_248h = CONCAT71(var_248h._1_7_, 1);
                    placeholder_3 = (int64_t **)&stack0xfffffffffffffe58;
                    func_0x0001800b3310(arg1, ppiVar55, 0);
                    arg2 = in_stack_fffffffffffffe58._8_8_;
                    ppiVar46 = in_stack_fffffffffffffe58._0_8_;
                    if (ppiVar46 != (int64_t **)arg2) {
                        do {
                            func_0x0001800bfe60(arg1 + 0x670, &stack0xfffffffffffffe28);
                            ppiVar46 = ppiVar46 + 1;
                        } while (ppiVar46 != (int64_t **)arg2);
                        ppiVar46 = in_stack_fffffffffffffe58._0_8_;
                    }
joined_r0x0001800b805b:
                    puVar42 = auStackY_268;
                    if (ppiVar46 == (int64_t **)0x0) goto code_r0x0001800bb7ba;
code_r0x0001800b8140:
                    uVar33 = (iVar54 - (int64_t)ppiVar46 >> 3) * 8;
                    ppiVar32 = ppiVar46;
                    if (0xfff < uVar33) {
                        ppiVar32 = (int64_t **)ppiVar46[-1];
                        arg1 = (int64_t)ppiVar46 + (-8 - (int64_t)ppiVar32);
                        if ((int64_t **)0x1f < (uint64_t)arg1) goto code_r0x0001800b847a;
                        uVar33 = uVar33 + 0x27;
                    }
code_r0x0001800b8177:
                    func_0x000180459c3c(ppiVar32, uVar33);
                    puVar42 = auStackY_268;
                    goto code_r0x0001800bb7ba;
                }
code_r0x0001800b7ef5:
                iVar54 = 0;
                if ((ppiVar45[6][6] == 1) &&
                   (iVar44 = *(int64_t *)ppiVar45[6][5], *(int32_t *)(iVar44 + 8) == *(int32_t *)0x180782750)) {
                    iVar54 = iVar44;
                }
                if ((piVar60 == (int64_t *)0x0) && (iVar54 != 0)) {
                    iVar44 = *(int64_t *)(arg1 + 0x690);
                    cVar10 = func_0x0001800bbae0(arg1, *(undefined8 *)(iVar44 + -0x10));
                    if (cVar10 == '\0') {
                        if (*(int64_t *)(iVar44 + -8) == 0) {
                            *(int64_t *)(iVar44 + -8) = iVar54;
                        }
                        in_stack_fffffffffffffe58 = ZEXT816(0);
                        iVar54 = 0;
                        var_248h = CONCAT71(var_248h._1_7_, 1);
                        placeholder_3 = (int64_t **)&stack0xfffffffffffffe58;
                        func_0x0001800b3310(arg1, ppiVar45[5], 0);
                        arg2 = in_stack_fffffffffffffe58._8_8_;
                        ppiVar46 = in_stack_fffffffffffffe58._0_8_;
                        if (ppiVar46 != (int64_t **)arg2) {
                            ppiVar45 = (int64_t **)(arg1 + 0x670);
                            do {
                                func_0x0001800bfe60(ppiVar45, &stack0xfffffffffffffe28);
                                ppiVar46 = ppiVar46 + 1;
                            } while (ppiVar46 != (int64_t **)arg2);
                            ppiVar46 = in_stack_fffffffffffffe58._0_8_;
                        }
                        goto joined_r0x0001800b805b;
                    }
                }
                uVar18 = 0;
                uVar67 = 0;
                var_248h = var_248h & 0xffffffffffffff00;
                placeholder_3 = (int64_t **)&stack0xfffffffffffffe80;
                uVar59 = 0;
                func_0x0001800b3310(arg1, ppiVar55);
                fcn.1800b7cc0(arg1, (int64_t)ppiVar45[6], uVar59, placeholder_3, var_248h, var_240h, var_238h, var_230h
                              , var_228h, var_220h, var_218h, in_stack_fffffffffffffdf0, arg1, var_200h, var_1f8h, 
                              var_1f0h, in_stack_fffffffffffffe18, in_stack_fffffffffffffe20, in_stack_fffffffffffffe28
                              , in_stack_fffffffffffffe30, in_stack_fffffffffffffe38, in_stack_fffffffffffffe40, 
                              (int64_t)ppiVar32, in_stack_fffffffffffffe50, (int64_t)in_stack_fffffffffffffe58._0_8_, 
                              in_stack_fffffffffffffe58._8_8_, in_stack_fffffffffffffe68, in_stack_fffffffffffffe70, 
                              CONCAT71(in_stack_fffffffffffffe79, in_stack_fffffffffffffe78), CONCAT44(uVar67, uVar18));
                piVar60 = ppiVar45[7];
                ppiVar55 = (int64_t **)0x0;
                ppiVar46 = (int64_t **)CONCAT44(uVar67, uVar18);
                if ((piVar60 == (int64_t *)0x0) || (-(int64_t)ppiVar46 >> 3 == 0)) {
                    arg2 = *(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2;
                    if (ppiVar46 != (int64_t **)0x0) {
                        do {
                            cVar10 = func_0x0001800cfeb0(*(undefined8 *)arg1, *ppiVar46, arg2);
                            if (cVar10 == '\0') goto code_r0x0001800bb7f9;
                            ppiVar46 = ppiVar46 + 1;
                        } while (ppiVar46 != (int64_t **)0x0);
                        goto code_r0x0001800b812f;
                    }
code_r0x0001800b8133:
                    puVar42 = auStackY_268;
                    if (ppiVar46 == (int64_t **)0x0) goto code_r0x0001800bb7ba;
                    iVar54 = 0;
                    goto code_r0x0001800b8140;
                }
                iVar54 = *(int64_t *)arg1;
                iVar44 = *(int64_t *)(iVar54 + 0x30);
                iVar48 = *(int64_t *)(iVar54 + 0x28);
                cVar10 = func_0x0001800acb30(uVar26, ppiVar45[6]);
                if (cVar10 != '\0') {
                    arg2 = iVar44 - iVar48 >> 2;
                    fcn.1800b7cc0(arg1, (int64_t)piVar60, uVar59, placeholder_3, var_248h, var_240h, var_238h, var_230h
                                  , var_228h, var_220h, var_218h, in_stack_fffffffffffffdf0, arg1, var_200h, var_1f8h, 
                                  var_1f0h, in_stack_fffffffffffffe18, in_stack_fffffffffffffe20, 
                                  in_stack_fffffffffffffe28, in_stack_fffffffffffffe30, in_stack_fffffffffffffe38, 
                                  in_stack_fffffffffffffe40, (int64_t)ppiVar32, in_stack_fffffffffffffe50, 
                                  (int64_t)in_stack_fffffffffffffe58._0_8_, in_stack_fffffffffffffe58._8_8_, 
                                  in_stack_fffffffffffffe68, in_stack_fffffffffffffe70, 
                                  CONCAT71(in_stack_fffffffffffffe79, in_stack_fffffffffffffe78), 
                                  CONCAT44(uVar67, uVar18));
                    ppiVar46 = (int64_t **)CONCAT44(uVar67, uVar18);
                    ppiVar55 = (int64_t **)0x0;
                    uVar26 = arg1;
                    if (ppiVar46 == (int64_t **)0x0) goto code_r0x0001800b8133;
                    do {
                        cVar10 = func_0x0001800cfeb0(*(undefined8 *)arg1, *ppiVar46, arg2);
                        puVar42 = auStackY_268;
                        if (cVar10 == '\0') goto code_r0x0001800bb7f9;
                        ppiVar46 = ppiVar46 + 1;
                    } while (ppiVar46 != (int64_t **)0x0);
code_r0x0001800b812f:
                    ppiVar46 = (int64_t **)CONCAT44(uVar67, uVar18);
                    goto code_r0x0001800b8133;
                }
                iVar28 = CONCAT44((int32_t)((uint64_t)in_stack_fffffffffffffe20 >> 0x20), 0x17);
                func_0x0001800d31a0(iVar54 + 0x28, &stack0xfffffffffffffe20);
                func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
                ppiVar55 = (int64_t **)
                           (*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
                fcn.1800b7cc0(arg1, (int64_t)ppiVar45[7], uVar59, placeholder_3, var_248h, var_240h, var_238h, var_230h
                              , var_228h, var_220h, var_218h, in_stack_fffffffffffffdf0, arg1, var_200h, var_1f8h, 
                              var_1f0h, in_stack_fffffffffffffe18, iVar28, in_stack_fffffffffffffe28, 
                              in_stack_fffffffffffffe30, in_stack_fffffffffffffe38, in_stack_fffffffffffffe40, 
                              (int64_t)ppiVar32, in_stack_fffffffffffffe50, (int64_t)in_stack_fffffffffffffe58._0_8_, 
                              in_stack_fffffffffffffe58._8_8_, in_stack_fffffffffffffe68, in_stack_fffffffffffffe70, 
                              CONCAT71(in_stack_fffffffffffffe79, in_stack_fffffffffffffe78), CONCAT44(uVar67, uVar18));
                iVar54 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
                iVar28 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
                uVar26 = 0;
                for (puVar58 = (undefined8 *)CONCAT44(uVar67, uVar18); puVar58 != (undefined8 *)0x0;
                    puVar58 = puVar58 + 1) {
                    cVar10 = func_0x0001800cfeb0(*(undefined8 *)arg1, *puVar58, ppiVar55);
                    puVar42 = auStackY_268;
                    if (cVar10 == '\0') goto code_r0x0001800bb7f9;
                }
                piVar60 = (int64_t *)(iVar54 - iVar28 >> 2);
                arg2 = iVar44 - iVar48 >> 2;
                cVar10 = func_0x0001800cfeb0(*(undefined8 *)arg1, arg2, piVar60);
                puVar42 = auStackY_268;
                if (cVar10 != '\0') goto code_r0x0001800b812f;
code_r0x0001800bb7f9:
                *(undefined8 *)(puVar42 + -8) = 0x1800bb809;
                func_0x0001800acea0((int64_t)ppiVar45 + 0xc, 0x18063f7f0);
code_r0x0001800bb80a:
                *(undefined8 *)(puVar42 + -8) = 0x1800bb813;
                func_0x00018002ee50(auStack_140 + 8);
                *(undefined8 *)(puVar42 + -8) = 0x1800bb81c;
                func_0x00018002ee50(&piStack_150);
code_r0x0001800bb81c:
                *(undefined8 *)(puVar42 + -8) = 0x1800bb82c;
                func_0x0001800acea0((int64_t)ppiVar55 + 0xc, 0x18063f5a0);
                puVar22 = puVar42;
code_r0x0001800bb82d:
                *(undefined8 *)(puVar22 + -8) = 0x1800bb83d;
                func_0x0001800acea0((int64_t)ppiVar45 + 0xc, 0x18063f7f0);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            func_0x0001800b70c0(arg1, ppiVar46[5]);
        }
        puVar42 = auStackY_268;
        if (ppiVar45[7] != (int64_t *)0x0) {
            fcn.1800b7cc0(arg1, (int64_t)ppiVar45[7], placeholder_2, placeholder_3, var_248h, var_240h, var_238h, 
                          var_230h, var_228h, var_220h, var_218h, in_stack_fffffffffffffdf0, arg1, var_200h, var_1f8h, 
                          var_1f0h, in_stack_fffffffffffffe18, in_stack_fffffffffffffe20, in_stack_fffffffffffffe28, 
                          in_stack_fffffffffffffe30, in_stack_fffffffffffffe38, in_stack_fffffffffffffe40, 
                          (int64_t)ppiVar32, in_stack_fffffffffffffe50, (int64_t)in_stack_fffffffffffffe58._0_8_, 
                          in_stack_fffffffffffffe58._8_8_, in_stack_fffffffffffffe68, in_stack_fffffffffffffe70, 
                          CONCAT71(in_stack_fffffffffffffe79, in_stack_fffffffffffffe78), 
                          CONCAT44(in_stack_fffffffffffffe84, in_stack_fffffffffffffe80));
            puVar42 = auStackY_268;
        }
        goto code_r0x0001800bb7ba;
    }
    ppiVar45 = ppiVar46;
    if (iVar15 == *(int32_t *)0x1807826fc) {
        ppiVar45 = (int64_t **)arg2;
    }
    puVar42 = auStackY_268;
    if (ppiVar45 != (int64_t **)0x0) {
        cVar10 = func_0x0001800aca90(arg1 + 0x100, ppiVar45[5]);
        puVar42 = auStackY_268;
        if (cVar10 != '\0') goto code_r0x0001800bb7ba;
        iVar54 = *(int64_t *)(arg1 + 0x678);
        iVar44 = *(int64_t *)(arg1 + 0x670);
        iVar40 = *(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3;
        iVar47 = 0;
        iVar29 = iVar40;
        func_0x0001800bfab0(arg1 + 0x688, &stack0xfffffffffffffe28);
        *(undefined *)(arg1 + 0x620) = 1;
        iVar48 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
        iVar28 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
        uVar18 = 0;
        uVar67 = 0;
        var_248h = var_248h & 0xffffffffffffff00;
        puVar42 = &stack0xfffffffffffffe80;
        uVar59 = 0;
        func_0x0001800b3310(arg1, ppiVar45[5]);
        fcn.1800b7cc0(arg1, (int64_t)ppiVar45[6], uVar59, (int64_t **)puVar42, var_248h, var_240h, var_238h, var_230h, 
                      var_228h, var_220h, var_218h, in_stack_fffffffffffffdf0, arg1, var_200h, var_1f8h, var_1f0h, 
                      iVar44, in_stack_fffffffffffffe20, iVar40, iVar29, iVar47, in_stack_fffffffffffffe40, 
                      (int64_t)ppiVar32, in_stack_fffffffffffffe50, (int64_t)in_stack_fffffffffffffe58._0_8_, 
                      in_stack_fffffffffffffe58._8_8_, in_stack_fffffffffffffe68, in_stack_fffffffffffffe70, 
                      CONCAT71(in_stack_fffffffffffffe79, in_stack_fffffffffffffe78), CONCAT44(uVar67, uVar18));
        iVar29 = *(int64_t *)arg1;
        piVar60 = (int64_t *)(*(int64_t *)(iVar29 + 0x30) - *(int64_t *)(iVar29 + 0x28) >> 2);
        if (0 < *(int32_t *)(arg1 + 0xc)) {
            *(int32_t *)(iVar29 + 0x270) = *(int32_t *)((int64_t)ppiVar45[5] + 0xc) + 1;
        }
        iVar29 = *(int64_t *)arg1;
        func_0x0001800d31a0(iVar29 + 0x28, &stack0xfffffffffffffe20);
        func_0x0001800d31a0(iVar29 + 0x40, iVar29 + 0x270);
        iVar29 = *(int64_t *)arg1;
        iVar40 = *(int64_t *)(iVar29 + 0x30);
        iVar47 = *(int64_t *)(iVar29 + 0x28);
        cVar10 = func_0x0001800cfeb0(iVar29, piVar60, iVar48 - iVar28 >> 2);
        if (cVar10 == '\0') goto code_r0x0001800bb82d;
        arg2 = iVar40 - iVar47 >> 2;
        ppiVar55 = (int64_t **)0x0;
        for (puVar58 = (undefined8 *)CONCAT44(uVar67, uVar18); puVar58 != (undefined8 *)0x0; puVar58 = puVar58 + 1) {
            ppiVar46 = (int64_t **)arg2;
            cVar10 = func_0x0001800cfeb0(*(undefined8 *)arg1, *puVar58);
            if (cVar10 == '\0') {
                func_0x0001800acea0((int64_t)ppiVar45 + 0xc, 0x18063f7f0);
                goto code_r0x0001800bb84f;
            }
        }
        uVar26 = iVar54 - iVar44 >> 4;
        placeholder_3 = (int64_t **)arg2;
        var_248h = (int64_t)piVar60;
        func_0x0001800bbdb0(arg1, ppiVar45, uVar26);
        func_0x0001800bfcc0(arg1 + 0x670, uVar26);
        *(int64_t *)(arg1 + 0x690) = *(int64_t *)(arg1 + 0x690) + -0x18;
        ppiVar32 = (int64_t **)CONCAT44(uVar67, uVar18);
        puVar42 = auStackY_268;
        if (ppiVar32 == (int64_t **)0x0) goto code_r0x0001800bb7ba;
        uVar33 = (-(int64_t)ppiVar32 >> 3) * 8;
        if (uVar33 < 0x1000) goto code_r0x0001800b8177;
        if ((uint64_t)((int64_t)ppiVar32 + (-8 - (int64_t)ppiVar32[-1])) < 0x20) {
            func_0x000180459c3c(ppiVar32[-1], uVar33 + 0x27);
            puVar42 = auStackY_268;
            goto code_r0x0001800bb7ba;
        }
code_r0x0001800b847a:
        pcVar3 = (code *)swi(0x29);
        iVar15 = (*pcVar3)(5);
        ppiVar46 = (int64_t **)arg1;
        puVar42 = auStackY_260;
        arg1 = (int64_t)piVar60;
    }
    ppiVar52 = ppiVar46;
    if (iVar15 == *(int32_t *)0x180782684) {
        ppiVar52 = (int64_t **)arg2;
    }
    if (ppiVar52 != (int64_t **)0x0) {
        in_stack_fffffffffffffe58._0_8_ = *(int64_t *)(arg1 + 0x678);
        iVar54 = *(int64_t *)(arg1 + 0x670);
        iVar44 = *(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3;
        *(undefined8 *)(puVar42 + -8) = 0x1800b84e8;
        ppiVar32 = ppiVar52;
        func_0x0001800bfab0((int64_t *)(arg1 + 0x688), &stack0xfffffffffffffe80);
        *(undefined *)(arg1 + 0x620) = 1;
        ppiVar45 = *(int64_t ***)(*(int64_t *)arg1 + 0x30);
        ppiStack_160 = ppiVar45;
        auStack_120 = (undefined  [8])*(undefined8 *)(*(int64_t *)arg1 + 0x28);
        ppiVar55 = (int64_t **)ppiVar52[6];
        ppiStack_d8 = ppiVar55;
        *(undefined4 *)(puVar42 + 0x70) = *(undefined4 *)(arg1 + 0x60c);
        bVar9 = false;
        piVar60 = (int64_t *)0x0;
        puVar43 = puVar42;
        if (ppiVar55[6] != (int64_t *)0x0) {
            do {
                iVar48 = ppiVar55[5][(int64_t)piVar60];
                *(undefined8 *)(puVar42 + -8) = 0x1800b8550;
                piVar27 = piVar60;
                fcn.1800b7cc0(arg1, iVar48, ppiVar45, placeholder_3, *(int64_t *)(puVar42 + 0x20), 
                              *(int64_t *)(puVar42 + 0x28), *(int64_t *)(puVar42 + 0x30), *(int64_t *)(puVar42 + 0x38), 
                              *(int64_t *)(puVar42 + 0x40), *(int64_t *)(puVar42 + 0x48), *(int64_t *)(puVar42 + 0x50), 
                              *(int64_t *)(puVar42 + 0x58), *(int64_t *)(puVar42 + 0x60), *(int64_t *)(puVar42 + 0x68), 
                              *(int64_t *)(puVar42 + 0x70), *(int64_t *)(puVar42 + 0x78), 
                              *(undefined8 *)(puVar42 + 0x80), *(int64_t *)(puVar42 + 0x88), 
                              *(int64_t *)(puVar42 + 0x90), *(int64_t *)(puVar42 + 0x98), *(int64_t *)(puVar42 + 0xa0), 
                              *(int64_t *)(puVar42 + 0xa8), *(int64_t *)(puVar42 + 0xb0), *(int64_t *)(puVar42 + 0xb8), 
                              *(int64_t *)(puVar42 + 0xc0), *(int64_t *)(puVar42 + 200), *(undefined8 *)(puVar42 + 0xd0)
                              , *(int64_t *)(puVar42 + 0xd8), *(undefined8 *)(puVar42 + 0xe0), 
                              *(int64_t *)(puVar42 + 0xe8));
                *(int64_t *)(*(int64_t *)(arg1 + 0x690) + -0x10) =
                     *(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3;
                if ((*(int64_t *)(*(int64_t *)(arg1 + 0x690) + -8) != 0) && (!bVar9)) {
                    ppiStack_d0 = (int64_t **)ppiVar52[5];
                    puStack_108 = *(undefined8 **)(*(int64_t *)(arg1 + 0x690) + -8);
                    uStack_c8 = 0x1806405b8;
                    ppiStack_b8 = (int64_t **)0x0;
                    piStack_b0 = (int64_t *)0x0;
                    piVar41 = (int64_t *)0x0;
                    piStack_a8 = (int64_t *)0x0;
                    uVar33 = 0;
                    uStack_a0 = 0;
                    uVar26 = 0;
                    auStack_98[0] = 0;
                    piVar38 = (int64_t *)((int64_t)piVar60 + 1);
                    piStack_c0 = (int64_t *)arg1;
                    if (piVar38 < ppiVar55[6]) {
                        do {
                            ppiVar52 = ppiVar32;
                            piVar60 = piVar27;
                            placeholder_3 = (int64_t **)ppiVar55[5];
                            piVar27 = placeholder_3[(int64_t)piVar38];
                            piVar50 = (int64_t *)0x0;
                            if (*(int32_t *)(piVar27 + 1) == *(int32_t *)0x1807826f8) {
                                piVar50 = piVar27;
                            }
                            if (piVar50 == (int64_t *)0x0) {
                                piVar50 = (int64_t *)0x0;
                                if (*(int32_t *)(piVar27 + 1) == *(int32_t *)0x1807826c4) {
                                    piVar50 = piVar27;
                                }
                                if (piVar50 != (int64_t *)0x0) {
                                    if ((uint64_t)((int64_t)piVar41 * 3) >> 2 <= uVar33) {
                                        if ((uVar33 != 0) && (uVar33 = piVar50[5], uVar33 != uVar26)) {
                                            placeholder_3 = (int64_t **)((int64_t)piVar41 + -1);
                                            uVar36 = (uVar33 >> 5 ^ uVar33) >> 4;
                                            ppiVar32 = (int64_t **)0x0;
                                            do {
                                                if (piStack_b0[uVar36 & (uint64_t)placeholder_3] == uVar33)
                                                goto code_r0x0001800b8990;
                                                if (piStack_b0[uVar36 & (uint64_t)placeholder_3] == uVar26) break;
                                                uVar36 = (uVar36 & (uint64_t)placeholder_3) + 1 + (int64_t)ppiVar32;
                                                ppiVar32 = (int64_t **)((int64_t)ppiVar32 + 1);
                                            } while (ppiVar32 <= placeholder_3);
                                        }
                                        *(undefined8 *)(puVar42 + -8) = 0x1800b88bf;
                                        func_0x0001800c1660(&uStack_158, auStack_98);
                                        piVar27 = piStack_b0;
                                        piVar41 = (int64_t *)0x0;
                                        if (piStack_a8 != (int64_t *)0x0) {
                                            do {
                                                uVar26 = piStack_b0[(int64_t)piVar41];
                                                if (uVar26 != auStack_98[0]) {
                                                    placeholder_3 = (int64_t **)((int64_t)piStack_150 + -1);
                                                    uVar33 = (uVar26 >> 5 ^ uVar26) >> 4;
                                                    ppiVar32 = (int64_t **)0x0;
                                                    do {
                                                        puVar35 = (uint64_t *)
                                                                  (uStack_158 + (uVar33 & (uint64_t)placeholder_3));
                                                        if (*puVar35 == auStack_140._0_8_) {
                                                            *puVar35 = uVar26;
                                                            uStack_148 = (int64_t **)((int64_t)uStack_148 + 1);
                                                            goto code_r0x0001800b893c;
                                                        }
                                                        if (*puVar35 == uVar26) goto code_r0x0001800b893c;
                                                        uVar33 = (uVar33 & (uint64_t)placeholder_3) + 1 +
                                                                 (int64_t)ppiVar32;
                                                        ppiVar32 = (int64_t **)((int64_t)ppiVar32 + 1);
                                                    } while (ppiVar32 <= placeholder_3);
                                                    puVar35 = (uint64_t *)0x0;
code_r0x0001800b893c:
                                                    *puVar35 = piStack_b0[(int64_t)piVar41];
                                                }
                                                piVar41 = (int64_t *)((int64_t)piVar41 + 1);
                                            } while (piVar41 < piStack_a8);
                                        }
                                        piStack_b0 = uStack_158;
                                        uStack_158 = piVar27;
                                        piStack_a8 = piStack_150;
                                        ppiVar55 = ppiStack_d8;
                                        if (piVar27 != (int64_t *)0x0) {
                                            *(undefined8 *)(puVar42 + -8) = 0x1800b8985;
                                            func_0x0001800f4640();
                                            ppiVar55 = ppiStack_d8;
                                        }
                                    }
code_r0x0001800b8990:
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b899f;
                                    func_0x0001800c15e0(&piStack_b0, piVar50 + 5);
                                    uVar26 = auStack_98[0];
                                    uVar33 = uStack_a0;
                                    piVar41 = piStack_a8;
                                }
                            } else {
                                puVar56 = (uint64_t *)piVar50[5];
                                puVar35 = puVar56 + piVar50[6];
                                for (; puVar56 != puVar35; puVar56 = puVar56 + 1) {
                                    uVar36 = *puVar56;
                                    if ((uint64_t)((int64_t)piVar41 * 3) >> 2 <= uVar33) {
                                        if ((uVar33 != 0) && (uVar36 != uVar26)) {
                                            uVar21 = (uVar36 >> 5 ^ uVar36) >> 4;
                                            uVar31 = 0;
                                            do {
                                                uVar21 = uVar21 & (int64_t)piVar41 - 1U;
                                                if (piStack_b0[uVar21] == uVar36) goto code_r0x0001800b87a1;
                                                if (piStack_b0[uVar21] == uVar26) break;
                                                uVar21 = uVar21 + 1 + uVar31;
                                                uVar31 = uVar31 + 1;
                                            } while (uVar31 <= (int64_t)piVar41 - 1U);
                                        }
                                        iVar48 = 0x10;
                                        if (piVar41 != (int64_t *)0x0) {
                                            iVar48 = (int64_t)piVar41 * 2;
                                        }
                                        *(undefined8 *)(puVar42 + -8) = 0x1800b86af;
                                        func_0x0001800c1660(&uStack_100, auStack_98, iVar48);
                                        piVar27 = piStack_b0;
                                        piVar50 = (int64_t *)0x0;
                                        piVar41 = (int64_t *)auStack_f8;
                                        if (piStack_a8 != (int64_t *)0x0) {
                                            do {
                                                uVar26 = piStack_b0[(int64_t)piVar50];
                                                if (uVar26 != auStack_98[0]) {
                                                    uVar33 = (uVar26 >> 5 ^ uVar26) >> 4;
                                                    uVar21 = 0;
                                                    do {
                                                        uVar33 = uVar33 & (int64_t)auStack_f8 - 1U;
                                                        puVar34 = (uint64_t *)(uStack_100 + uVar33);
                                                        if (*puVar34 == uStack_e8) {
                                                            *puVar34 = uVar26;
                                                            iStack_f0 = iStack_f0 + 1;
                                                            goto code_r0x0001800b873c;
                                                        }
                                                        if (*puVar34 == uVar26) goto code_r0x0001800b873c;
                                                        uVar33 = uVar33 + 1 + uVar21;
                                                        uVar21 = uVar21 + 1;
                                                    } while (uVar21 <= (int64_t)auStack_f8 - 1U);
                                                    puVar34 = (uint64_t *)0x0;
code_r0x0001800b873c:
                                                    *puVar34 = piStack_b0[(int64_t)piVar50];
                                                }
                                                piVar50 = (int64_t *)((int64_t)piVar50 + 1);
                                            } while (piVar50 < piStack_a8);
                                        }
                                        piStack_b0 = uStack_100;
                                        uStack_100 = piVar27;
                                        piStack_a8 = piVar41;
                                        uVar26 = auStack_98[0];
                                        uVar33 = uStack_a0;
                                        if (piVar27 != (int64_t *)0x0) {
                                            *(undefined8 *)(puVar42 + -8) = 0x1800b878c;
                                            func_0x0001800f4640();
                                            uVar26 = auStack_98[0];
                                            uVar33 = uStack_a0;
                                            piVar41 = piStack_a8;
                                        }
                                    }
code_r0x0001800b87a1:
                                    placeholder_3 = (int64_t **)((int64_t)piVar41 + -1);
                                    uVar21 = (uVar36 >> 5 ^ uVar36) >> 4;
                                    ppiVar32 = (int64_t **)0x0;
                                    do {
                                        uVar21 = uVar21 & (uint64_t)placeholder_3;
                                        if (piStack_b0[uVar21] == uVar26) {
                                            piStack_b0[uVar21] = uVar36;
                                            uVar33 = uStack_a0 + 1;
                                            uVar26 = auStack_98[0];
                                            piVar41 = piStack_a8;
                                            uStack_a0 = uVar33;
                                            break;
                                        }
                                        if (piStack_b0[uVar21] == uVar36) break;
                                        uVar21 = uVar21 + 1 + (int64_t)ppiVar32;
                                        ppiVar32 = (int64_t **)((int64_t)ppiVar32 + 1);
                                    } while (ppiVar32 <= placeholder_3);
                                    ppiVar55 = ppiStack_d8;
                                }
                            }
                            piVar38 = (int64_t *)((int64_t)piVar38 + 1);
                            piVar27 = piVar60;
                            ppiVar32 = ppiVar52;
                        } while (piVar38 < ppiVar55[6]);
                    }
                    arg2 = (int64_t)ppiStack_d0;
                    ppiVar45 = (int64_t **)0x10;
                    pcVar3 = (code *)**ppiStack_d0;
                    *(undefined8 *)(puVar42 + -8) = 0x1800b89e3;
                    (*pcVar3)(ppiStack_d0, &uStack_c8);
                    ppiVar46 = ppiStack_b8;
                    if (ppiStack_b8 != (int64_t **)0x0) goto code_r0x0001800bb84f;
                    ppiVar45 = ppiStack_b8;
                    if (piStack_b0 != (int64_t *)0x0) {
                        *(undefined8 *)(puVar42 + -8) = 0x1800b8a04;
                        func_0x0001800f4640();
                    }
                    bVar9 = true;
                    arg1 = *(int64_t *)(puVar42 + 0x60);
                    ppiVar46 = (int64_t **)(*(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3);
                }
                piVar60 = (int64_t *)((int64_t)piVar60 + 1);
            } while (piVar60 < ppiVar55[6]);
            if (bVar9) {
                if (0 < *(int32_t *)(arg1 + 0xc)) {
                    *(int32_t *)(*(int64_t *)arg1 + 0x270) =
                         *(int32_t *)(ppiVar55[5][(int64_t)ppiVar55[6] - 1] + 0x14) + 1;
                }
                *(undefined8 *)(puVar42 + -8) = 0x1800b8a67;
                func_0x0001800bbb60(arg1, ppiVar46);
                *(undefined8 *)(puVar42 + -8) = 0x1800b8a72;
                func_0x0001800bbc30(arg1, ppiVar46);
            }
        }
        iVar48 = *(int64_t *)arg1;
        uVar26 = *(uint64_t *)(iVar48 + 0x30);
        iVar28 = *(int64_t *)(iVar48 + 0x28);
        if (0 < *(int32_t *)(arg1 + 0xc)) {
            *(int32_t *)(iVar48 + 0x270) = *(int32_t *)((int64_t)ppiVar32[5] + 0xc) + 1;
        }
        piVar60 = ppiVar32[5];
        *(undefined8 *)(puVar42 + -8) = 0x1800b8ab1;
        cVar10 = func_0x0001800ac9f0((int64_t *)(arg1 + 0x100), piVar60);
        piVar27 = in_stack_fffffffffffffe58._0_8_;
        if (cVar10 == '\0') {
            ppiStack_160 = (int64_t **)((int64_t)ppiStack_160 - (int64_t)auStack_120 >> 2);
            _auStack_120 = ZEXT816(0);
            iStack_110 = 0;
            puVar42[0x20] = 1;
            placeholder_3 = (int64_t **)auStack_120;
            *(undefined8 *)(puVar42 + -8) = 0x1800b8b0c;
            func_0x0001800b3310(arg1, piVar60, 0);
            *(undefined8 *)(puVar42 + -8) = 0x1800b8b17;
            func_0x0001800bbb60(arg1, iVar44);
            iVar48 = *(int64_t *)arg1;
            iVar29 = *(int64_t *)(iVar48 + 0x30);
            iVar40 = *(int64_t *)(iVar48 + 0x28);
            *(undefined8 *)(puVar42 + -8) = 0x1800b8b3a;
            func_0x0001800d31a0((int64_t *)(iVar48 + 0x28), &stack0xfffffffffffffe20);
            *(undefined8 *)(puVar42 + -8) = 0x1800b8b4a;
            func_0x0001800d31a0(iVar48 + 0x40, iVar48 + 0x270);
            ppiVar55 = (int64_t **)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
            *(undefined8 *)(puVar42 + -8) = 0x1800b8b65;
            func_0x0001800bbb60(arg1, iVar44);
            iVar48 = *(int64_t *)arg1;
            ppiVar45 = *(int64_t ***)(iVar48 + 0x30);
            arg1 = *(int64_t *)(iVar48 + 0x28);
            *(undefined8 *)(puVar42 + -8) = 0x1800b8b7d;
            cVar10 = func_0x0001800cfeb0(iVar48, iVar29 - iVar40 >> 2, ppiStack_160);
            if (cVar10 == '\0') goto code_r0x0001800bb86e;
            arg2 = (int64_t)uStack_118;
            ppiVar46 = (int64_t **)auStack_120;
            if (auStack_120 != (undefined  [8])uStack_118) {
                do {
                    piVar60 = *ppiVar46;
                    uVar59 = **(undefined8 **)(puVar42 + 0x60);
                    *(undefined8 *)(puVar42 + -8) = 0x1800b8ba5;
                    cVar10 = func_0x0001800cfeb0(uVar59, piVar60, ppiVar55);
                    if (cVar10 == '\0') goto code_r0x0001800bb86e;
                    ppiVar46 = ppiVar46 + 1;
                } while (ppiVar46 != (int64_t **)arg2);
            }
            piVar27 = in_stack_fffffffffffffe58._0_8_;
            ppiVar45 = (int64_t **)((int64_t)ppiVar45 - arg1 >> 2);
            if (auStack_120 != (undefined  [8])0x0) {
                uVar33 = (iStack_110 - (int64_t)auStack_120 >> 3) * 8;
                ppiVar46 = (int64_t **)auStack_120;
                if (0xfff < uVar33) {
                    ppiVar46 = *(int64_t ***)((int64_t)auStack_120 + -8);
                    if (0x1f < (uint64_t)((int64_t)auStack_120 + (-8 - (int64_t)ppiVar46))) {
                        pcVar3 = (code *)swi(0x29);
                        iVar15 = (*pcVar3)(5);
                        puVar42 = puVar42 + 8;
                        goto code_r0x0001800b8c6e;
                    }
                    uVar33 = uVar33 + 0x27;
                }
                *(undefined8 *)(puVar42 + -8) = 0x1800b8c02;
                func_0x000180459c3c(ppiVar46, uVar33);
            }
            arg1 = *(int64_t *)(puVar42 + 0x60);
        } else {
            *(undefined8 *)(puVar42 + -8) = 0x1800b8ac0;
            func_0x0001800bbb60(arg1, iVar44);
            ppiVar45 = (int64_t **)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
        }
        iVar54 = (int64_t)piVar27 - iVar54 >> 4;
        *(undefined8 *)(puVar42 + -8) = 0x1800b8c1f;
        func_0x0001800bbc30(arg1, iVar44);
        *(int64_t *)(puVar42 + 0x20) = (int64_t)(uVar26 - iVar28) >> 2;
        *(undefined8 *)(puVar42 + -8) = 0x1800b8c3d;
        func_0x0001800bbdb0(arg1, ppiVar32, iVar54, ppiVar45);
        *(undefined8 *)(puVar42 + -8) = 0x1800b8c4d;
        func_0x0001800bfcc0((int64_t *)(arg1 + 0x670), iVar54);
        *(int64_t *)(arg1 + 0x690) = *(int64_t *)(arg1 + 0x690) + -0x18;
        *(undefined4 *)(arg1 + 0x60c) = *(undefined4 *)(puVar42 + 0x70);
        goto code_r0x0001800bb7ba;
    }
code_r0x0001800b8c6e:
    uVar59 = in_stack_fffffffffffffe58._8_8_;
    if (iVar15 == *(int32_t *)0x180782700) {
        uVar59 = *(undefined8 *)(*(int64_t *)(arg1 + 0x690) + -0x18);
        *(undefined8 *)(puVar42 + -8) = 0x1800b8c8a;
        func_0x0001800bbb60(arg1, uVar59);
        iVar54 = *(int64_t *)arg1;
        *(undefined4 *)(puVar42 + 0x70) = 0x17;
        *(undefined8 *)(puVar42 + -8) = 0x1800b8caf;
        func_0x0001800d31a0(iVar54 + 0x28, puVar42 + 0x70);
        *(undefined8 *)(puVar42 + -8) = 0x1800b8cbf;
        func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
    } else {
        ppiVar32 = (int64_t **)0x0;
        ppiVar46 = ppiVar32;
        if (iVar15 == *(int32_t *)0x180782750) {
            ppiVar46 = (int64_t **)arg2;
        }
        if (ppiVar46 == (int64_t **)0x0) {
            ppiVar55 = ppiVar32;
            if (iVar15 == *(int32_t *)0x1807826d0) {
                ppiVar55 = (int64_t **)arg2;
            }
            if (ppiVar55 == (int64_t **)0x0) {
                ppiVar46 = ppiVar32;
                if (iVar15 == *(int32_t *)0x180782698) {
                    ppiVar46 = (int64_t **)arg2;
                }
                if (ppiVar46 != (int64_t **)0x0) {
                    ppiVar46 = (int64_t **)ppiVar46[5];
                    if (*(int32_t *)(ppiVar46 + 1) == *(int32_t *)0x180782740) {
                        ppiVar32 = ppiVar46;
                    }
                    if (ppiVar32 == (int64_t **)0x0) {
                        *(undefined8 *)(puVar42 + -8) = 0x1800b9291;
                        func_0x0001800b70c0(arg1, ppiVar46);
                    } else {
                        puVar42[0x28] = 0;
                        puVar42[0x20] = 0;
                        uVar12 = *(undefined *)(arg1 + 0x60c);
                        *(undefined8 *)(puVar42 + -8) = 0x1800b9284;
                        func_0x0001800b0700(arg1, ppiVar32, uVar12, 0);
                    }
                    goto code_r0x0001800bb7ba;
                }
                ppiVar45 = ppiVar32;
                if (iVar15 == *(int32_t *)0x1807826f8) {
                    ppiVar45 = (int64_t **)arg2;
                }
                if (ppiVar45 != (int64_t **)0x0) {
                    if (*(char *)0x180778520 != '\0') {
                        piVar27 = ppiVar45[5];
                        piVar60 = piVar27 + (int64_t)ppiVar45[6];
                        for (; piVar27 != piVar60; piVar27 = piVar27 + 1) {
                            iVar54 = *piVar27;
                            *(undefined8 *)(puVar42 + -8) = 0x1800b92df;
                            func_0x0001800ad170(arg1, iVar54, (int64_t)ppiVar45 + 0xc);
                        }
                    }
                    if (0 < *(int32_t *)(arg1 + 8)) {
                        if ((*(int32_t *)(arg1 + 0xc) < 2) && (ppiVar45[8] <= ppiVar45[6])) {
                            puVar56 = (uint64_t *)ppiVar45[5];
                            puVar35 = puVar56 + (int64_t)ppiVar45[6];
                            for (; puVar56 != puVar35; puVar56 = puVar56 + 1) {
                                uVar26 = *puVar56;
                                if ((((*(char *)0x180778520 != '\0') && (*(char *)(uVar26 + 0x31) != '\0')) ||
                                    (*(int64_t *)(arg1 + 0xe8) == 0)) || (uVar26 == *(uint64_t *)(arg1 + 0xf0)))
                                goto code_r0x0001800b939a;
                                uVar33 = (uVar26 >> 5 ^ uVar26) >> 4;
                                ppiVar46 = ppiVar32;
                                while( true ) {
                                    uVar33 = uVar33 & (uint64_t)(int64_t **)(*(int64_t *)(arg1 + 0xe0) + -1);
                                    uVar36 = *(uint64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar33 * 0x18);
                                    if (uVar36 == uVar26) break;
                                    if (uVar36 == *(uint64_t *)(arg1 + 0xf0)) goto code_r0x0001800b939a;
                                    uVar33 = uVar33 + 1 + (int64_t)ppiVar46;
                                    ppiVar46 = (int64_t **)((int64_t)ppiVar46 + 1);
                                    if ((int64_t **)(*(int64_t *)(arg1 + 0xe0) + -1) < ppiVar46)
                                    goto code_r0x0001800b939a;
                                }
                                iVar54 = *(int64_t *)(arg1 + 0xd8) + 8 + uVar33 * 0x18;
                                if ((iVar54 == 0) || (*(char *)(iVar54 + 9) == '\0')) goto code_r0x0001800b939a;
                            }
                            goto code_r0x0001800bb7ba;
                        }
code_r0x0001800b939a:
                        if ((ppiVar45[6] == (int64_t *)0x1) && (ppiVar45[8] == (int64_t *)0x1)) {
                            *(undefined8 *)(puVar42 + -8) = 0x1800b93bc;
                            iVar54 = func_0x0001800b7b80();
                            if (iVar54 != 0) {
                                piVar60 = ppiVar45[5];
                                *(undefined8 *)(puVar42 + -8) = 0x1800b93df;
                                iVar44 = func_0x0001800ac770((int64_t *)(arg1 + 0xd8), piVar60);
                                ppiVar46 = (int64_t **)(iVar44 + 8);
                                if (iVar44 == 0) {
                                    ppiVar46 = ppiVar32;
                                }
                                *(undefined8 *)(puVar42 + -8) = 0x1800b93f9;
                                iVar44 = func_0x0001800ac770((int64_t *)(arg1 + 0xd8), (int64_t *)(iVar54 + 0x20));
                                ppiVar55 = (int64_t **)(iVar44 + 8);
                                if (iVar44 == 0) {
                                    ppiVar55 = ppiVar32;
                                }
                                arg1 = *(int64_t *)(puVar42 + 0x60);
                                *(undefined8 *)(puVar42 + -8) = 0x1800b9414;
                                iVar15 = fcn.1800b7be0(arg1, iVar54);
                                if ((((-1 < iVar15) &&
                                     ((ppiVar46 == (int64_t **)0x0 || (*(char *)(ppiVar46 + 1) == '\0')))) &&
                                    ((ppiVar55 == (int64_t **)0x0 || (*(char *)(ppiVar55 + 1) == '\0')))) &&
                                   ((iVar44 = *piVar60, *(char *)(iVar44 + 0x31) == '\0' &&
                                    (*(char *)(*(int64_t *)(iVar54 + 0x20) + 0x31) == '\0')))) {
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9452;
                                    func_0x0001800bba40(arg1, iVar44, iVar15, 0xffffffff);
                                    goto code_r0x0001800bb7ba;
                                }
                            }
                        }
                    }
                    uVar16 = *(uint32_t *)(arg1 + 0x60c);
                    uVar26 = (uint64_t)uVar16;
                    uVar30 = uVar16 + *(int32_t *)(ppiVar45 + 6);
                    if (uVar30 < 0x100) {
                        piVar60 = *(int64_t **)(puVar42 + 0x60);
                        *(uint32_t *)((int64_t)piVar60 + 0x60c) = uVar30;
                        uVar17 = *(uint32_t *)(piVar60 + 0xc2);
                        if (*(uint32_t *)(piVar60 + 0xc2) < uVar30) {
                            uVar17 = uVar30;
                        }
                        *(uint32_t *)(piVar60 + 0xc2) = uVar17;
                        iVar44 = *(int64_t *)(*piVar60 + 0x30) - *(int64_t *)(*piVar60 + 0x28) >> 2;
                        puVar42[0x20] = 1;
                        uVar12 = *(undefined *)(ppiVar45 + 6);
                        *(undefined8 *)(puVar42 + -8) = 0x1800b94f3;
                        iVar54 = iVar44;
                        func_0x0001800b72a0(piVar60, ppiVar45 + 7, uVar16 & 0xff, uVar12);
                        if (ppiVar45[6] != (int64_t *)0x0) {
                            piVar27 = *(int64_t **)(puVar42 + 0x60);
                            piVar60 = piVar27 + 0x11;
                            do {
                                piVar38 = (int64_t *)ppiVar45[5][(int64_t)ppiVar32];
                                if ((*(char *)0x180778520 == '\0') || (*(char *)((int64_t)piVar38 + 0x31) == '\0')) {
                                    if (199 < (uint64_t)(piVar27[0xc9] - piVar27[200] >> 3)) {
                                        iVar54 = *piVar38;
                                        *(undefined8 *)(puVar42 + -8) = 0x1800bb923;
                                        func_0x0001800acea0(piVar38 + 1, 0x18063fb70, iVar54, 200);
                                        goto code_r0x0001800bb924;
                                    }
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b97e8;
                                    func_0x0001800bf890(piVar27 + 200, &stack0xfffffffffffffe18);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b97f4;
                                    pcVar23 = (char *)func_0x0001800c0050(piVar60, &stack0xfffffffffffffe18);
                                    *pcVar23 = (char)uVar16 + (char)ppiVar32;
                                    pcVar23[1] = '\x01';
                                    piVar27 = *(int64_t **)(puVar42 + 0x60);
                                    iVar19 = (int32_t)(*(int64_t *)(*piVar27 + 0x30) - *(int64_t *)(*piVar27 + 0x28) >>
                                                      2);
                                    *(int32_t *)(pcVar23 + 4) = iVar19;
                                    iVar15 = (int32_t)iVar44;
                                    if ((int32_t)iVar44 == -1) {
                                        iVar15 = iVar19;
                                    }
                                    *(int32_t *)(pcVar23 + 8) = iVar15;
                                } else {
                                    piVar41 = piVar27 + 0xb8;
                                    piVar50 = piVar27;
                                    if ((piVar60[2] != 0) && (piVar41 != (int64_t *)piVar60[3])) {
                                        uVar33 = ((uint64_t)piVar41 >> 5 ^ (uint64_t)piVar41) >> 4;
                                        uVar36 = 0;
                                        do {
                                            uVar33 = uVar33 & piVar60[1] - 1U;
                                            piVar50 = *(int64_t **)(*piVar60 + uVar33 * 0x18);
                                            if (piVar50 == piVar41) {
                                                piVar50 = *(int64_t **)(puVar42 + 0x60);
                                                iVar44 = iVar54;
                                                goto code_r0x0001800b968b;
                                            }
                                            if (piVar50 == (int64_t *)piVar60[3]) break;
                                            uVar33 = uVar33 + 1 + uVar36;
                                            uVar36 = uVar36 + 1;
                                        } while (uVar36 <= piVar60[1] - 1U);
                                        piVar50 = *(int64_t **)(puVar42 + 0x60);
                                    }
                                    uVar30 = *(uint32_t *)((int64_t)piVar50 + 0x60c);
                                    uVar16 = uVar30 + 1;
                                    if (0xff < uVar16) {
                                        *(undefined8 *)(puVar42 + -8) = 0x1800bb909;
                                        func_0x0001800acea0((int64_t)ppiVar45 + 0xc, 0x18063fbc0, 1, 0xff);
                                        pcVar3 = (code *)swi(3);
                                        (*pcVar3)();
                                        return;
                                    }
                                    *(uint32_t *)((int64_t)piVar50 + 0x60c) = uVar16;
                                    uVar17 = *(uint32_t *)(piVar50 + 0xc2);
                                    if (*(uint32_t *)(piVar50 + 0xc2) < uVar16) {
                                        uVar17 = uVar16;
                                    }
                                    *(uint32_t *)(piVar50 + 0xc2) = uVar17;
                                    iVar44 = *piVar50;
                                    *(uint32_t *)(puVar42 + 0x70) = (uVar30 & 0xff) << 8 | 0x35;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b95ee;
                                    func_0x0001800d31a0(iVar44 + 0x28, puVar42 + 0x70);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b95fe;
                                    func_0x0001800d31a0(iVar44 + 0x40, iVar44 + 0x270);
                                    iVar44 = **(int64_t **)(puVar42 + 0x60);
                                    *(undefined4 *)(puVar42 + 0x70) = 0;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b961c;
                                    func_0x0001800d31a0(iVar44 + 0x28, puVar42 + 0x70);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b962c;
                                    func_0x0001800d31a0(iVar44 + 0x40, iVar44 + 0x270);
                                    piVar50 = *(int64_t **)(puVar42 + 0x60);
                                    if (199 < (uint64_t)(piVar50[0xc9] - piVar50[200] >> 3)) {
                                        iVar54 = *piVar41;
                                        *(undefined8 *)(puVar42 + -8) = 0x1800bb8ec;
                                        func_0x0001800acea0(piVar27 + 0xb9, 0x18063fb70, iVar54, 200);
                                        pcVar3 = (code *)swi(3);
                                        (*pcVar3)();
                                        return;
                                    }
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b965c;
                                    func_0x0001800bf890(piVar50 + 200, &stack0xfffffffffffffe18);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9668;
                                    puVar22 = (undefined *)func_0x0001800c0050(piVar60, &stack0xfffffffffffffe18);
                                    *puVar22 = (char)uVar30;
                                    puVar22[1] = 1;
                                    uVar18 = (undefined4)
                                             (*(int64_t *)(*piVar50 + 0x30) - *(int64_t *)(*piVar50 + 0x28) >> 2);
                                    *(undefined4 *)(puVar22 + 4) = uVar18;
                                    *(undefined4 *)(puVar22 + 8) = uVar18;
                                    iVar44 = iVar54;
code_r0x0001800b968b:
                                    iVar54 = *piVar50;
                                    iVar48 = *piVar38;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9699;
                                    func_0x000180498cd0(iVar48);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b96ad;
                                    uVar18 = func_0x0001800cf010(iVar54, &stack0xfffffffffffffe58);
                                    auStack_120._0_4_ = 5;
                                    uStack_118._0_4_ = uVar18;
                                    uStack_118._4_4_ = 0;
                                    iStack_110 = 0;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b96e3;
                                    iVar15 = func_0x0001800ced20(iVar54, auStack_120, &stack0xfffffffffffffe80);
                                    if (iVar15 < 0) {
                                        *(undefined8 *)(puVar42 + -8) = 0x1800bb8d2;
                                        func_0x0001800acea0(piVar38 + 1, 0x18063f5a0);
                                        pcVar3 = (code *)swi(3);
                                        (*pcVar3)();
                                        return;
                                    }
                                    piVar60 = *(int64_t **)(puVar42 + 0x60);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b96fe;
                                    uVar11 = func_0x0001800ad390(piVar60, ppiVar45);
                                    iVar54 = *piVar60;
                                    iVar48 = *piVar38;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9710;
                                    uVar33 = func_0x000180498cd0(iVar48);
                                    uVar36 = uVar33;
                                    for (; uVar16 = (uint32_t)uVar36, uVar33 != 0; uVar33 = uVar33 - 1) {
                                        uVar36 = (uint64_t)
                                                 (uVar16 ^ (uint32_t)*(uint8_t *)((uVar33 - 1) + iVar48) + uVar16 * 0x20
                                                           + ((uint32_t)(uVar36 >> 2) & 0x3fffffff));
                                    }
                                    *(uint32_t *)(puVar42 + 0x70) =
                                         (((uVar16 & 0xff) << 8 | (uint32_t)uVar11) << 8 |
                                         (uint32_t)(uint8_t)((char)ppiVar32 + (char)uVar26)) << 8 | 0x10;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b976c;
                                    func_0x0001800d31a0(iVar54 + 0x28, puVar42 + 0x70);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b977c;
                                    func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
                                    iVar54 = **(int64_t **)(puVar42 + 0x60);
                                    *(int32_t *)(puVar42 + 0x70) = iVar15;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9797;
                                    func_0x0001800d31a0(iVar54 + 0x28, puVar42 + 0x70);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b97a7;
                                    func_0x0001800d31a0(iVar54 + 0x40);
                                    piVar27 = *(int64_t **)(puVar42 + 0x60);
                                    piVar60 = piVar27 + 0x11;
                                    uVar16 = (uint32_t)uVar26;
                                    iVar54 = iVar44;
                                }
                                ppiVar32 = (int64_t **)((int64_t)ppiVar32 + 1);
                            } while (ppiVar32 < ppiVar45[6]);
                        }
                        goto code_r0x0001800bb7ba;
                    }
                    goto code_r0x0001800bb8ab;
                }
                ppiVar45 = ppiVar32;
                if (iVar15 == *(int32_t *)0x180782778) {
                    ppiVar45 = (int64_t **)arg2;
                }
                if (ppiVar45 == (int64_t **)0x0) {
                    ppiVar46 = ppiVar32;
                    if (iVar15 == *(int32_t *)0x180782780) {
                        ppiVar46 = (int64_t **)arg2;
                    }
                    if (ppiVar46 != (int64_t **)0x0) {
                        *(undefined4 *)(puVar42 + 0x70) = *(undefined4 *)(arg1 + 0x60c);
                        auStack_120 = (undefined  [8])(*(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3);
                        iVar54 = *(int64_t *)(arg1 + 0x678);
                        puStack_108 = *(undefined8 **)(arg1 + 0x670);
                        *(undefined8 *)(puVar42 + -8) = 0x1800ba19a;
                        func_0x0001800bfab0((int64_t *)(arg1 + 0x688), &stack0xfffffffffffffe28);
                        *(undefined *)(arg1 + 0x620) = 1;
                        *(undefined8 *)(puVar42 + -8) = 0x1800ba1b4;
                        uVar12 = func_0x0001800bbe60(arg1, ppiVar46, 3);
                        puVar42[0x78] = uVar12;
                        puVar42[0x20] = 1;
                        piVar60 = (int64_t *)CONCAT71((unkint7)((uint64_t)placeholder_3 >> 8), 3);
                        *(undefined8 *)(puVar42 + -8) = 0x1800ba1d5;
                        func_0x0001800b72a0(arg1, ppiVar46 + 7, uVar12);
                        uVar16 = *(uint32_t *)(ppiVar46 + 6);
                        if (*(uint32_t *)(ppiVar46 + 6) < 2) {
                            uVar16 = 2;
                        }
                        piVar27 = (int64_t *)(uint64_t)uVar16;
                        *(undefined8 *)(puVar42 + -8) = 0x1800ba1f0;
                        uVar12 = func_0x0001800bbe60(arg1);
                        puVar42[0x68] = uVar12;
                        iVar44 = *(int64_t *)(*(int64_t *)arg1 + 0x30);
                        iVar48 = *(int64_t *)(*(int64_t *)arg1 + 0x28);
                        if ((0 < *(int32_t *)(arg1 + 8)) && (ppiVar46[6] < (int64_t *)0x3)) {
                            if (ppiVar46[8] == (int64_t *)0x1) {
                                iVar15 = *(int32_t *)(*ppiVar46[7] + 8);
                                if (iVar15 == *(int32_t *)0x180782740) {
                                    piVar60 = (int64_t *)(arg1 + 0xd8);
                                    piVar27 = (int64_t *)(arg1 + 0xb0);
                                    iVar28 = 0;
                                    if (iVar15 == *(int32_t *)0x180782740) {
                                        iVar28 = *ppiVar46[7];
                                    }
                                    uVar2 = *(undefined8 *)(iVar28 + 0x20);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800ba26d;
                                    piVar38 = (int64_t *)func_0x0001800aa350(&stack0xfffffffffffffe28, uVar2);
                                    if ((*piVar38 == 0) && (iVar28 = piVar38[1], iVar28 != 0)) {
                                        piVar27 = (int64_t *)0x180625d3c;
                                        iVar29 = 0;
                                        do {
                                            iVar40 = iVar29 + 1;
                                            if (*(char *)(iVar28 + iVar29) != *(char *)(iVar29 + 0x180625d3c)) {
                                                piVar27 = (int64_t *)0x180625f3c;
                                                iVar29 = 0;
                                                goto code_r0x0001800ba2c0;
                                            }
                                            iVar29 = iVar40;
                                        } while (iVar40 != 7);
                                    }
                                }
                            } else if ((ppiVar46[8] == (int64_t *)0x2) &&
                                      ((*(char *)0x180777f98 == '\0' ||
                                       ((*(char *)(arg1 + 0x638) == '\0' && (*(char *)(arg1 + 0x639) == '\0')))))) {
                                piVar60 = (int64_t *)(arg1 + 0xd8);
                                piVar27 = (int64_t *)(arg1 + 0xb0);
                                iVar28 = *ppiVar46[7];
                                *(undefined8 *)(puVar42 + -8) = 0x1800ba32c;
                                piVar38 = (int64_t *)func_0x0001800aa350(&stack0xfffffffffffffe28, iVar28);
                                if ((*piVar38 == 0) && (piVar38[1] != 0)) {
                                    piVar27 = (int64_t *)0x180625f28;
                                    iVar28 = 0;
                                    do {
                                        iVar29 = iVar28 + 1;
                                        if (*(char *)(piVar38[1] + iVar28) != *(char *)(iVar28 + 0x180625f28)) break;
                                        iVar28 = iVar29;
                                    } while (iVar29 != 5);
                                }
                            }
                        }
                        goto code_r0x0001800ba379;
                    }
                    ppiVar46 = ppiVar32;
                    if (iVar15 == *(int32_t *)0x180782754) {
                        ppiVar46 = (int64_t **)arg2;
                    }
                    if (ppiVar46 != (int64_t **)0x0) {
                        uVar18 = *(undefined4 *)(arg1 + 0x60c);
                        *(undefined4 *)(puVar42 + 0x70) = uVar18;
                        piVar60 = ppiVar46[6];
                        if ((piVar60 == (int64_t *)0x1) && (ppiVar46[8] == (int64_t *)0x1)) {
                            iVar54 = *ppiVar46[5];
                            piVar60 = *(int64_t **)(puVar42 + 0x60);
                            *(undefined8 *)(puVar42 + -8) = 0x1800ba603;
                            func_0x0001800b7590(piVar60, &uStack_158, iVar54);
                            iVar54 = *ppiVar46[7];
                            if ((int32_t)uStack_158 == 0) {
                                *(undefined8 *)(puVar42 + -8) = 0x1800ba620;
                                func_0x0001800b4ce0(piVar60, iVar54, uStack_158._4_1_, 0);
                            } else {
                                *(undefined8 *)(puVar42 + -8) = 0x1800ba627;
                                uVar11 = func_0x0001800b7030(piVar60, iVar54);
                                if (0 < *(int32_t *)((int64_t)piVar60 + 0xc)) {
                                    *(int32_t *)(*piVar60 + 0x270) = *(int32_t *)(*ppiVar46[5] + 0xc) + 1;
                                }
                                *(int64_t *)(puVar42 + 0x20) = *ppiVar46[5];
                                *(undefined8 *)(puVar42 + -8) = 0x1800ba664;
                                fcn.1800b77e0((int64_t)piVar60, (int64_t)&uStack_158, (uint64_t)uVar11, 
                                              CONCAT71((unkint7)((uint64_t)placeholder_3 >> 8), 1), 
                                              *(int64_t *)(puVar42 + 0x20));
                            }
                            *(undefined4 *)((int64_t)piVar60 + 0x60c) = uVar18;
                            goto code_r0x0001800bb7ba;
                        }
                        ppiVar55 = (int64_t **)0x0;
                        if (piVar60 == (int64_t *)0x0) {
                            arg2 = 0;
                        } else {
                            ppiVar55 = (int64_t **)0x0;
                            if ((int64_t *)0x555555555555555 < piVar60) goto code_r0x0001800bb971;
                            *(undefined8 *)(puVar42 + -8) = 0x1800ba6a8;
                            arg2 = func_0x000180004de0((int64_t)piVar60 * 0x30);
                            ppiVar45 = (int64_t **)(arg2 + 0x18);
                            ppiVar55 = (int64_t **)arg2;
                            do {
                                *ppiVar55 = (int64_t *)0x0;
                                ppiVar55[3] = (int64_t *)0x0;
                                ppiVar55[4] = (int64_t *)0x0;
                                *(undefined4 *)((int64_t)ppiVar55 + 0x2a) = 0;
                                *(undefined2 *)((int64_t)ppiVar55 + 0x2e) = 0;
                                ppiVar55[1] = (int64_t *)0x0;
                                ppiVar55[2] = (int64_t *)0x0;
                                *ppiVar45 = (int64_t *)0x0;
                                ppiVar45[1] = (int64_t *)0x0;
                                *(undefined2 *)(ppiVar55 + 5) = 0xffff;
                                ppiVar55 = ppiVar55 + 6;
                                ppiVar45 = ppiVar45 + 6;
                                piVar60 = (int64_t *)((int64_t)piVar60 - 1);
                            } while (piVar60 != (int64_t *)0x0);
                        }
                        piVar60 = *(int64_t **)(puVar42 + 0x60);
                        ppiVar45 = ppiVar32;
                        if (ppiVar46[6] != (int64_t *)0x0) {
                            do {
                                iVar54 = ppiVar46[5][(int64_t)ppiVar45];
                                *(undefined8 *)(puVar42 + -8) = 0x1800ba744;
                                puVar25 = (undefined4 *)func_0x0001800b7590(piVar60, &uStack_158, iVar54);
                                uVar18 = puVar25[1];
                                uVar67 = puVar25[2];
                                uVar4 = puVar25[3];
                                uVar5 = puVar25[4];
                                uVar6 = puVar25[5];
                                uVar7 = puVar25[6];
                                uVar8 = puVar25[7];
                                piVar27 = *(int64_t **)(puVar25 + 8);
                                ppiVar52 = (int64_t **)(arg2 + (int64_t)ppiVar45 * 6 * 8);
                                *(undefined4 *)ppiVar52 = *puVar25;
                                *(undefined4 *)((int64_t)ppiVar52 + 4) = uVar18;
                                *(undefined4 *)(ppiVar52 + 1) = uVar67;
                                *(undefined4 *)((int64_t)ppiVar52 + 0xc) = uVar4;
                                ppiVar52 = (int64_t **)(arg2 + ((int64_t)ppiVar45 * 6 + 2) * 8);
                                *(undefined4 *)ppiVar52 = uVar5;
                                *(undefined4 *)((int64_t)ppiVar52 + 4) = uVar6;
                                *(undefined4 *)(ppiVar52 + 1) = uVar7;
                                *(undefined4 *)((int64_t)ppiVar52 + 0xc) = uVar8;
                                *(int64_t **)(arg2 + ((int64_t)ppiVar45 * 6 + 4) * 8) = piVar27;
                                ppiVar45 = (int64_t **)((int64_t)ppiVar45 + 1);
                            } while (ppiVar45 < ppiVar46[6]);
                        }
                        uStack_c8 = 0x180640198;
                        piStack_c0 = piVar60;
                        ppiStack_b8 = (int64_t **)0x0;
                        piStack_b0 = (int64_t *)0x0;
                        piStack_a8 = (int64_t *)0x0;
                        uStack_a0 = 0;
                        auStack_98[0] = 0;
                        auStack_98[1] = 0;
                        _auStack_88 = ZEXT816(0);
                        if (((int64_t)ppiVar55 - arg2 >> 4) * -0x5555555555555555 != 0) {
                            do {
                                if (*(int32_t *)(arg2 + (int64_t)ppiVar32 * 6 * 8) == 0) {
                                    if (ppiVar32 < ppiVar46[8]) {
                                        puVar58 = (undefined8 *)ppiVar46[7][(int64_t)ppiVar32];
                                        pcVar3 = *(code **)*puVar58;
                                        *(undefined8 *)(puVar42 + -8) = 0x1800ba7f8;
                                        (*pcVar3)(puVar58, &uStack_c8);
                                    }
                                    uVar11 = *(uint8_t *)(arg2 + (int64_t)ppiVar32 * 0x30 + 4);
                                    uVar13 = uVar11 >> 6;
                                    auStack_98[uVar13] = auStack_98[uVar13] | 1LL << (uVar11 & 0x3f);
                                }
                                ppiVar32 = (int64_t **)((int64_t)ppiVar32 + 1);
                            } while (ppiVar32 < (int64_t **)(((int64_t)ppiVar55 - arg2 >> 4) * -0x5555555555555555));
                            piVar60 = (int64_t *)0x0;
                            do {
                                if ((*(int32_t *)(arg2 + (int64_t)piVar60 * 6 * 8) != 0) && (piVar60 < ppiVar46[8])) {
                                    puVar58 = (undefined8 *)ppiVar46[7][(int64_t)piVar60];
                                    pcVar3 = *(code **)*puVar58;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800ba85a;
                                    (*pcVar3)(puVar58, &uStack_c8);
                                }
                                piVar60 = (int64_t *)((int64_t)piVar60 + 1);
                            } while (piVar60 < (int64_t *)(((int64_t)ppiVar55 - arg2 >> 4) * -0x5555555555555555));
                            piVar60 = *(int64_t **)(puVar42 + 0x60);
                        }
                        piVar27 = (int64_t *)(((int64_t)ppiVar55 - arg2 >> 4) * -0x5555555555555555);
                        ppiVar32 = (int64_t **)arg2;
                        if (piVar27 < ppiVar46[8]) {
                            do {
                                puVar58 = (undefined8 *)ppiVar46[7][(int64_t)piVar27];
                                pcVar3 = *(code **)*puVar58;
                                *(undefined8 *)(puVar42 + -8) = 0x1800ba8a4;
                                (*pcVar3)(puVar58, &uStack_c8);
                                piVar27 = (int64_t *)((int64_t)piVar27 + 1);
                            } while (piVar27 < ppiVar46[8]);
                        }
                        for (; ppiVar45 = (int64_t **)arg2, ppiVar32 != ppiVar55; ppiVar32 = ppiVar32 + 6) {
                            if ((*(int32_t *)ppiVar32 - 3U < 3) &&
                               (uVar26 = (uint64_t)((uint32_t)uVar26 | 1),
                               (auStack_98[*(uint8_t *)((int64_t)ppiVar32 + 4) >> 6] >>
                                (*(uint8_t *)((int64_t)ppiVar32 + 4) & 0x3f) & 1) != 0)) {
                                bVar9 = true;
                            } else {
                                bVar9 = false;
                            }
                            uVar16 = (uint32_t)uVar26 & 0xfffffffe;
                            if ((uVar26 & 1) == 0) {
                                uVar16 = (uint32_t)uVar26;
                            }
                            if (bVar9) {
                                uVar11 = *(uint8_t *)((int64_t)ppiVar32 + 4) >> 6;
                                (&ppiStack_b8)[uVar11] =
                                     (int64_t **)
                                     ((uint64_t)(&ppiStack_b8)[uVar11] |
                                     1LL << (*(uint8_t *)((int64_t)ppiVar32 + 4) & 0x3f));
                            }
                            if ((*(int32_t *)ppiVar32 == 5) &&
                               (uVar16 = uVar16 | 2,
                               (auStack_98[*(uint8_t *)((int64_t)ppiVar32 + 6) >> 6] >>
                                (*(uint8_t *)((int64_t)ppiVar32 + 6) & 0x3f) & 1) != 0)) {
                                bVar9 = true;
                            } else {
                                bVar9 = false;
                            }
                            uVar30 = uVar16 & 0xfffffffd;
                            if ((uVar16 & 2) == 0) {
                                uVar30 = uVar16;
                            }
                            uVar26 = (uint64_t)uVar30;
                            if (bVar9) {
                                uVar11 = *(uint8_t *)((int64_t)ppiVar32 + 6) >> 6;
                                (&ppiStack_b8)[uVar11] =
                                     (int64_t **)
                                     ((uint64_t)(&ppiStack_b8)[uVar11] |
                                     1LL << (*(uint8_t *)((int64_t)ppiVar32 + 6) & 0x3f));
                            }
                        }
                        for (; ppiVar45 != ppiVar55; ppiVar45 = ppiVar45 + 6) {
                            if ((*(int32_t *)ppiVar45 == 0) &&
                               (((uint64_t)(&ppiStack_b8)[*(uint8_t *)((int64_t)ppiVar45 + 4) >> 6] >>
                                 (*(uint8_t *)((int64_t)ppiVar45 + 4) & 0x3f) & 1) != 0)) {
                                bVar9 = true;
                            } else {
                                bVar9 = false;
                            }
                            if (bVar9) {
                                iVar15 = *(int32_t *)((int64_t)piVar60 + 0x60c);
                                uVar16 = iVar15 + 1;
                                if (0xff < uVar16) goto code_r0x0001800bb977;
                                *(uint32_t *)((int64_t)piVar60 + 0x60c) = uVar16;
                                uVar30 = *(uint32_t *)(piVar60 + 0xc2);
                                if (*(uint32_t *)(piVar60 + 0xc2) < uVar16) {
                                    uVar30 = uVar16;
                                }
                                *(uint32_t *)(piVar60 + 0xc2) = uVar30;
                                *(char *)(ppiVar45 + 5) = (char)iVar15;
                            }
                        }
                        piVar27 = (int64_t *)0x0;
                        piVar60 = ppiVar46[6];
                        if (piVar60 != (int64_t *)0x0) {
                            do {
                                piVar38 = ppiVar46[8];
                                if (piVar38 <= piVar27) break;
                                iVar54 = ppiVar46[7][(int64_t)piVar27];
                                if (((int64_t *)((int64_t)piVar27 + 1U) == piVar38) && (piVar38 < piVar60)) {
                                    iVar44 = *(int64_t *)(puVar42 + 0x60);
                                    iVar15 = *(int32_t *)(iVar44 + 0x60c);
                                    uVar16 = iVar15 + ((int32_t)piVar60 - (int32_t)piVar38) + 1;
                                    if (0xff < uVar16) goto code_r0x0001800bb994;
                                    *(uint32_t *)(iVar44 + 0x60c) = uVar16;
                                    uVar30 = *(uint32_t *)(iVar44 + 0x610);
                                    if (*(uint32_t *)(iVar44 + 0x610) < uVar16) {
                                        uVar30 = uVar16;
                                    }
                                    *(uint32_t *)(iVar44 + 0x610) = uVar30;
                                    ppiVar32 = (int64_t **)0x0;
                                    puVar42[0x20] = 1;
                                    cVar10 = (char)iVar15;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800baaae;
                                    func_0x0001800b7150(iVar44, iVar54, cVar10);
                                    if (piVar27 < ppiVar46[6]) {
                                        piVar60 = piVar27;
                                        do {
                                            *(char *)(arg2 + (int64_t)piVar60 * 0x30 + 0x29) =
                                                 (cVar10 - (char)piVar27) + (char)piVar60;
                                            piVar60 = (int64_t *)((int64_t)piVar60 + 1);
                                        } while (piVar60 < ppiVar46[6]);
                                    }
                                } else if (*(int32_t *)(arg2 + (int64_t)piVar27 * 6 * 8) == 0) {
                                    cVar10 = *(char *)(arg2 + ((int64_t)piVar27 * 6 + 5) * 8);
                                    if (cVar10 == -1) {
                                        cVar10 = *(char *)(arg2 + (int64_t)piVar27 * 0x30 + 4);
                                    }
                                    *(char *)(arg2 + (int64_t)piVar27 * 0x30 + 0x29) = cVar10;
                                    ppiVar32 = (int64_t **)0x0;
                                    iVar54 = ppiVar46[7][(int64_t)piVar27];
                                    *(undefined8 *)(puVar42 + -8) = 0x1800bab13;
                                    func_0x0001800b4ce0(*(undefined8 *)(puVar42 + 0x60), iVar54, cVar10, 0);
                                } else {
                                    *(undefined8 *)(puVar42 + -8) = 0x1800bab1f;
                                    iVar15 = fcn.1800b7be0(*(int64_t *)(puVar42 + 0x60), iVar54);
                                    uVar12 = (undefined)iVar15;
                                    if (iVar15 < 0) {
                                        *(undefined8 *)(puVar42 + -8) = 0x1800bab36;
                                        uVar12 = func_0x0001800bbe60(*(undefined8 *)(puVar42 + 0x60), iVar54, 1);
                                        ppiVar32 = (int64_t **)0x0;
                                        *(undefined8 *)(puVar42 + -8) = 0x1800bab4f;
                                        func_0x0001800b4ce0(*(undefined8 *)(puVar42 + 0x60), iVar54, uVar12, 1);
                                    }
                                    *(undefined *)(arg2 + (int64_t)piVar27 * 0x30 + 0x29) = uVar12;
                                }
                                piVar27 = (int64_t *)((int64_t)piVar27 + 1);
                                piVar60 = ppiVar46[6];
                            } while (piVar27 < piVar60);
                        }
                        if (piVar60 < ppiVar46[8]) {
                            puVar58 = *(undefined8 **)(puVar42 + 0x60);
                            do {
                                iVar54 = ppiVar46[7][(int64_t)piVar60];
                                iVar15 = *(int32_t *)(iVar54 + 8);
                                if ((((iVar15 != *(int32_t *)0x180782728) && (iVar15 != *(int32_t *)0x180782738)) &&
                                    (iVar15 != *(int32_t *)0x1807826b8)) && (iVar15 != *(int32_t *)0x1807826a0)) {
                                    *(undefined8 *)(puVar42 + -8) = 0x1800babaa;
                                    cVar10 = func_0x0001800b2930(puVar58, iVar54);
                                    if (cVar10 == '\0') {
                                        if (iVar15 != *(int32_t *)0x180782740) {
                                            uVar59 = *puVar58;
                                            *(undefined8 *)(puVar42 + -8) = 0x1800babc5;
                                            func_0x0001800d0a10(uVar59, 0x18063f9a8);
                                        }
                                        uVar18 = *(undefined4 *)((int64_t)puVar58 + 0x60c);
                                        *(undefined8 *)(puVar42 + -8) = 0x1800babdd;
                                        func_0x0001800b7030(puVar58, iVar54);
                                        *(undefined4 *)((int64_t)puVar58 + 0x60c) = uVar18;
                                    }
                                }
                                piVar60 = (int64_t *)((int64_t)piVar60 + 1);
                            } while (piVar60 < ppiVar46[8]);
                        }
                        piVar60 = (int64_t *)0x0;
                        if ((int64_t **)arg2 != ppiVar55) {
                            piVar27 = *(int64_t **)(puVar42 + 0x60);
                            ppiVar45 = (int64_t **)arg2;
                            do {
                                if (*(int32_t *)ppiVar45 != 0) {
                                    if (0 < *(int32_t *)((int64_t)piVar27 + 0xc)) {
                                        *(int32_t *)(*piVar27 + 0x270) = *(int32_t *)(ppiVar45 + 3) + 1;
                                    }
                                    ppiVar32 = (int64_t **)CONCAT71((unkint7)((uint64_t)ppiVar32 >> 8), 1);
                                    uVar11 = *(uint8_t *)((int64_t)ppiVar45 + 0x29);
                                    if (piVar60 < ppiVar46[6]) {
                                        *(int64_t *)(puVar42 + 0x20) = ppiVar46[5][(int64_t)piVar60];
                                    } else {
                                        *(undefined8 *)(puVar42 + 0x20) = 0;
                                    }
                                    *(undefined8 *)(puVar42 + -8) = 0x1800bac4f;
                                    fcn.1800b77e0((int64_t)piVar27, (int64_t)ppiVar45, (uint64_t)uVar11, ppiVar32, 
                                                  *(int64_t *)(puVar42 + 0x20));
                                }
                                piVar60 = (int64_t *)((int64_t)piVar60 + 1);
                                ppiVar45 = ppiVar45 + 6;
                            } while (ppiVar45 != ppiVar55);
                            for (; (int64_t **)arg2 != ppiVar55; arg2 = arg2 + 0x30) {
                                if ((*(int32_t *)arg2 == 0) && (*(char *)(arg2 + 0x29) != *(char *)(arg2 + 4))) {
                                    iVar54 = **(int64_t **)(puVar42 + 0x60);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800bac9a;
                                    func_0x0001800d31a0(iVar54 + 0x28, &stack0xfffffffffffffe48);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800bacaa;
                                    func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
                                }
                            }
                        }
                        *(undefined8 *)(puVar42 + -8) = 0x1800bacbc;
                        func_0x0001800c1750(&stack0xfffffffffffffe58);
                        *(undefined4 *)(*(int64_t *)(puVar42 + 0x60) + 0x60c) = *(undefined4 *)(puVar42 + 0x70);
                        goto code_r0x0001800bb7ba;
                    }
                    ppiVar46 = ppiVar32;
                    if (iVar15 == *(int32_t *)0x180782734) {
                        ppiVar46 = (int64_t **)arg2;
                    }
                    if (ppiVar46 != (int64_t **)0x0) {
                        uVar18 = *(undefined4 *)(arg1 + 0x60c);
                        piVar60 = ppiVar46[6];
                        puVar58 = *(undefined8 **)(puVar42 + 0x60);
                        *(undefined8 *)(puVar42 + -8) = 0x1800bad0c;
                        func_0x0001800b7590(puVar58, &uStack_100, piVar60);
                        iVar15 = (int32_t)uStack_100;
                        if ((int32_t)uStack_100 == 0) {
                            uVar11 = uStack_100._4_1_;
                        } else {
                            *(undefined8 *)(puVar42 + -8) = 0x1800bad2e;
                            uVar11 = func_0x0001800bbe60(puVar58, ppiVar46, 1);
                        }
    // switch table (8 cases) at 0x1800bb9dc
                        switch(*(undefined4 *)(ppiVar46 + 5)) {
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                            if (iVar15 != 0) {
                                *(int64_t **)(puVar42 + 0x20) = ppiVar46[6];
                                *(undefined8 *)(puVar42 + -8) = 0x1800bad72;
                                fcn.1800b77e0((int64_t)puVar58, (int64_t)&uStack_100, (uint64_t)uVar11, 0, 
                                              *(int64_t *)(puVar42 + 0x20));
                                iVar15 = (int32_t)uStack_100;
                            }
                            piVar60 = ppiVar46[7];
                            *(undefined8 *)(puVar42 + -8) = 0x1800bad81;
                            uVar16 = func_0x0001800b3050(puVar58, piVar60);
                            if (uVar16 < 0x100) {
    // switch table (7 cases) at 0x1800bb9fc
                                switch(*(undefined4 *)(ppiVar46 + 5)) {
                                case 0:
                                    uVar59 = 0x27;
                                    break;
                                case 1:
                                    uVar59 = 0x28;
                                    break;
                                case 2:
                                    uVar59 = 0x29;
                                    break;
                                case 3:
                                    uVar59 = 0x2a;
                                    break;
                                case 4:
                                    uVar59 = 0x52;
                                    break;
                                case 5:
                                    uVar59 = 0x2b;
                                    break;
                                case 6:
                                    uVar59 = 0x2c;
                                    break;
                                default:
                                    uVar59 = 0;
                                }
                                puVar42[0x20] = (char)uVar16;
                                placeholder_3 = (int64_t **)(uint64_t)uVar11;
                                uVar2 = *puVar58;
                                *(undefined8 *)(puVar42 + -8) = 0x1800bade4;
                                func_0x0001800cfdd0(uVar2, uVar59, uVar11, placeholder_3);
                            } else {
                                piVar60 = ppiVar46[7];
                                *(undefined8 *)(puVar42 + -8) = 0x1800badf5;
                                uVar12 = func_0x0001800b7030(puVar58, piVar60);
    // switch table (7 cases) at 0x1800bba18
                                switch(*(undefined4 *)(ppiVar46 + 5)) {
                                case 0:
                                    uVar59 = 0x21;
                                    break;
                                case 1:
                                    uVar59 = 0x22;
                                    break;
                                case 2:
                                    uVar59 = 0x23;
                                    break;
                                case 3:
                                    uVar59 = 0x24;
                                    break;
                                case 4:
                                    uVar59 = 0x51;
                                    break;
                                case 5:
                                    uVar59 = 0x25;
                                    break;
                                case 6:
                                    uVar59 = 0x26;
                                    break;
                                default:
                                    uVar59 = 0;
                                }
                                puVar42[0x20] = uVar12;
                                uVar2 = **(undefined8 **)(puVar42 + 0x60);
                                *(undefined8 *)(puVar42 + -8) = 0x1800bae5b;
                                func_0x0001800cfdd0(uVar2, uVar59, uVar11, uVar11);
                                if (iVar15 != 0) {
                                    *(undefined4 *)(puVar42 + 0x20) = 1;
                                    piVar60 = ppiVar46[6];
                                    *(undefined8 *)(puVar42 + -8) = 0x1800bae7e;
                                    func_0x0001800bbec0(*(undefined8 *)(puVar42 + 0x60), piVar60, uVar11, 2);
                                }
                                *(undefined4 *)(puVar42 + 0x20) = 1;
                                placeholder_3 = (int64_t **)0x0;
                                piVar60 = ppiVar46[7];
                                puVar58 = *(undefined8 **)(puVar42 + 0x60);
                                *(undefined8 *)(puVar42 + -8) = 0x1800bae9a;
                                func_0x0001800bbfb0(puVar58, piVar60, uVar12, 2);
                            }
                            break;
                        case 7:
                            *(undefined8 *)(puVar42 + -8) = 0x1800baec4;
                            func_0x0001800c08c0(&stack0xfffffffffffffe58, &stack0xfffffffffffffe28);
                            *(undefined8 *)(puVar42 + -8) = 0x1800baece;
                            func_0x0001800b3840(&stack0xfffffffffffffe58);
                            *(undefined8 *)(puVar42 + -8) = 0x1800baee8;
                            uVar13 = func_0x0001800bbe60(puVar58, ppiVar46, 
                                                         (int32_t)(in_stack_fffffffffffffe58._8_8_ -
                                                                   (int64_t)in_stack_fffffffffffffe58._0_8_ >> 3) + 1);
                            *(int64_t **)(puVar42 + 0x20) = ppiVar46[6];
                            puVar58 = *(undefined8 **)(puVar42 + 0x60);
                            *(undefined8 *)(puVar42 + -8) = 0x1800baf0d;
                            fcn.1800b77e0((int64_t)puVar58, (int64_t)&uStack_100, (uint64_t)uVar13, 0, 
                                          *(int64_t *)(puVar42 + 0x20));
                            uVar26 = 0;
                            iVar54 = in_stack_fffffffffffffe58._8_8_;
                            piVar60 = in_stack_fffffffffffffe58._0_8_;
                            if (iVar54 - (int64_t)piVar60 >> 3 != 0) {
                                do {
                                    iVar54 = piVar60[uVar26];
                                    *(undefined8 *)(puVar42 + -8) = 0x1800baf43;
                                    func_0x0001800b4ce0(puVar58, iVar54, uVar13 + 1 + (int32_t)uVar26, 1);
                                    uVar26 = uVar26 + 1;
                                    iVar54 = in_stack_fffffffffffffe58._8_8_;
                                    piVar60 = in_stack_fffffffffffffe58._0_8_;
                                } while (uVar26 < (uint64_t)(iVar54 - (int64_t)piVar60 >> 3));
                            }
                            puVar42[0x20] = (char)(iVar54 - (int64_t)piVar60 >> 3) + uVar13;
                            placeholder_3 = (int64_t **)(uint64_t)uVar13;
                            uVar59 = *puVar58;
                            *(undefined8 *)(puVar42 + -8) = 0x1800baf85;
                            func_0x0001800cfdd0(uVar59, 0x31, uVar11, placeholder_3);
                            *(undefined8 *)(puVar42 + -8) = 0x1800baf8f;
                            func_0x00018000ace0(&stack0xfffffffffffffe58);
                            iVar15 = (int32_t)uStack_100;
                        }
                        if (iVar15 != 0) {
                            *(int64_t **)(puVar42 + 0x20) = ppiVar46[6];
                            *(undefined8 *)(puVar42 + -8) = 0x1800bafb2;
                            fcn.1800b77e0((int64_t)puVar58, (int64_t)&uStack_100, (uint64_t)uVar11, 
                                          CONCAT71((unkint7)((uint64_t)placeholder_3 >> 8), 1), 
                                          *(int64_t *)(puVar42 + 0x20));
                        }
                        *(undefined4 *)((int64_t)puVar58 + 0x60c) = uVar18;
                        goto code_r0x0001800bb7ba;
                    }
                    ppiVar46 = ppiVar32;
                    if (iVar15 == *(int32_t *)0x180782690) {
                        ppiVar46 = (int64_t **)arg2;
                    }
                    if (ppiVar46 != (int64_t **)0x0) {
                        piVar60 = ppiVar46[5];
                        *(undefined8 *)(puVar42 + -8) = 0x1800bafe1;
                        uVar16 = fcn.1800b7be0(arg1, (int64_t)piVar60);
                        if ((int32_t)uVar16 < 0) {
                            uVar18 = *(undefined4 *)(arg1 + 0x60c);
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb01d;
                            uVar11 = func_0x0001800bbe60(arg1, ppiVar46, 1);
                            uVar59 = CONCAT71((unkint7)((uint64_t)placeholder_3 >> 8), 1);
                            piVar60 = ppiVar46[6];
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb033;
                            func_0x0001800b4ce0(arg1, piVar60, uVar11, uVar59);
                            piVar60 = ppiVar46[5];
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb043;
                            func_0x0001800b7590(arg1, &uStack_158, piVar60);
                            *(int64_t **)(puVar42 + 0x20) = ppiVar46[5];
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb05f;
                            fcn.1800b77e0(arg1, (int64_t)&uStack_158, (uint64_t)uVar11, 
                                          CONCAT71((unkint7)((uint64_t)uVar59 >> 8), 1), *(int64_t *)(puVar42 + 0x20));
                            *(undefined4 *)(arg1 + 0x60c) = uVar18;
                        } else {
                            piVar60 = ppiVar46[6];
                            *(undefined8 *)(puVar42 + -8) = 0x1800baff8;
                            func_0x0001800b4ce0(arg1, piVar60, uVar16 & 0xff, 0);
                        }
                        goto code_r0x0001800bb7ba;
                    }
                    ppiVar46 = ppiVar32;
                    if (iVar15 == *(int32_t *)0x1807826c4) {
                        ppiVar46 = (int64_t **)arg2;
                    }
                    if (ppiVar46 != (int64_t **)0x0) {
                        arg2 = (int64_t)(ppiVar46 + 5);
                        if ((*(char *)0x180778520 == '\0') ||
                           (piVar60 = *(int64_t **)arg2, *(char *)((int64_t)piVar60 + 0x31) == '\0')) {
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb1b3;
                            uVar12 = func_0x0001800bbe60(arg1, ppiVar46, 1);
                            piVar60 = *(int64_t **)arg2;
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb1cb;
                            func_0x0001800bba40(arg1, piVar60, uVar12, 0xffffffff);
                            if (*(char *)0x180778520 != '\0') {
                                piVar60 = *(int64_t **)arg2;
                                *(undefined8 *)(puVar42 + -8) = 0x1800bb1e3;
                                func_0x0001800ad170(arg1, piVar60, (int64_t)ppiVar46 + 0xc);
                            }
                            piVar60 = ppiVar46[6];
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb1f3;
                            func_0x0001800b2270(arg1, piVar60, uVar12);
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb203;
                            iVar54 = func_0x0001800c0050((int64_t *)(arg1 + 0x88), arg2);
                            *(int32_t *)(iVar54 + 4) =
                                 (int32_t)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28)
                                          >> 2);
                            goto code_r0x0001800bb7ba;
                        }
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb0ad;
                        func_0x0001800ad170(arg1, piVar60, (int64_t)ppiVar46 + 0xc);
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb0b8;
                        func_0x0001800ad1e0(arg1, ppiVar46);
                        uVar16 = *(uint32_t *)(arg1 + 0x60c);
                        ppiVar55 = (int64_t **)(uint64_t)uVar16;
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb0d9;
                        uVar12 = func_0x0001800bbe60(arg1, ppiVar46, 1);
                        piVar60 = ppiVar46[6];
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb0ed;
                        func_0x0001800b2270(arg1, piVar60, uVar12);
                        iVar54 = **(int64_t **)arg2;
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb0fb;
                        func_0x000180498cd0(iVar54);
                        arg1 = *(int64_t *)arg1;
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb110;
                        iVar15 = func_0x0001800cf790(arg1, &stack0xfffffffffffffe28);
                        if (-1 < iVar15) {
                            puVar58 = *(undefined8 **)(puVar42 + 0x60);
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb12b;
                            uVar14 = func_0x0001800ad390(puVar58, ppiVar46);
                            iVar54 = **(int64_t **)arg2;
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb13c;
                            uVar26 = func_0x000180498cd0(iVar54);
                            uVar33 = uVar26;
                            for (; uVar26 != 0; uVar26 = uVar26 - 1) {
                                uVar33 = (uint64_t)
                                         ((uint32_t)uVar33 ^
                                         (uint32_t)*(uint8_t *)(iVar54 + -1 + uVar26) + (uint32_t)uVar33 * 0x20 +
                                         ((uint32_t)(uVar33 >> 2) & 0x3fffffff));
                            }
                            puVar42[0x20] = (char)uVar33;
                            uVar59 = *puVar58;
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb189;
                            func_0x0001800cfdd0(uVar59, 0x10, uVar12, uVar14);
                            uVar59 = *puVar58;
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb195;
                            func_0x0001800cfe80(uVar59, iVar15);
                            *(uint32_t *)((int64_t)puVar58 + 0x60c) = uVar16;
                            goto code_r0x0001800bb7ba;
                        }
                        goto code_r0x0001800bb9ab;
                    }
                    if ((((iVar15 == *(int32_t *)0x18078266c) || (iVar15 == *(int32_t *)0x180782760)) ||
                        (*(char *)0x180778560 == '\0')) || (iVar15 != *(int32_t *)0x180782788))
                    goto code_r0x0001800bb7ba;
                    ppiVar55 = ppiVar32;
                    if (iVar15 == *(int32_t *)0x180782788) {
                        ppiVar55 = (int64_t **)arg2;
                    }
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb267;
                    uVar12 = func_0x0001800bbe60(arg1, ppiVar55, 1);
                    puVar42[0x68] = uVar12;
                    piVar60 = ppiVar55[5];
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb284;
                    func_0x0001800bba40(arg1, piVar60, uVar12, 0xffffffff);
                    if ((*(char *)0x180778520 != (char)uVar26) && (*(char *)(ppiVar55 + 8) != (char)uVar26)) {
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb2a6;
                        func_0x0001800ad1e0(arg1, ppiVar55);
                        puVar42[0x78] = puVar42[0x68];
                        ppiVar32 = (int64_t **)(arg1 + 0x6e8);
                        iVar54 = *(int64_t *)(arg1 + 0x6f0);
                        if ((uint64_t)(iVar54 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x6f8)) {
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb2d8;
                            iVar44 = func_0x0001800ac7f0(ppiVar32, ppiVar55 + 5);
                            if (iVar44 == 0) {
                                if (iVar54 == 0) {
                                    iVar54 = 0x10;
                                } else {
                                    iVar54 = iVar54 * 2;
                                }
                                *(undefined8 *)(puVar42 + -8) = 0x1800bb300;
                                func_0x0001800c12b0(&uStack_158, (int64_t *)(arg1 + 0x700), iVar54);
                                uVar26 = 0;
                                if (*(int64_t *)(arg1 + 0x6f0) != 0) {
                                    do {
                                        uVar33 = (*ppiVar32)[uVar26 * 2];
                                        if (uVar33 != *(uint64_t *)(arg1 + 0x700)) {
                                            uVar36 = (uVar33 >> 5 ^ uVar33) >> 4;
                                            uVar21 = 0;
                                            do {
                                                uVar36 = uVar36 & (int64_t)piStack_150 - 1U;
                                                puVar35 = (uint64_t *)(uStack_158 + uVar36 * 2);
                                                if (*puVar35 == auStack_140._0_8_) {
                                                    *puVar35 = uVar33;
                                                    goto code_r0x0001800bb380;
                                                }
                                                if (*puVar35 == uVar33) goto code_r0x0001800bb380;
                                                uVar36 = uVar36 + 1 + uVar21;
                                                uVar21 = uVar21 + 1;
                                            } while (uVar21 <= (int64_t)piStack_150 - 1U);
                                            puVar35 = (uint64_t *)0x0;
code_r0x0001800bb380:
                                            piVar60 = *ppiVar32;
                                            *puVar35 = piVar60[uVar26 * 2];
                                            *(undefined *)(puVar35 + 1) = *(undefined *)(piVar60 + uVar26 * 2 + 1);
                                        }
                                        uVar26 = uVar26 + 1;
                                    } while (uVar26 < *(uint64_t *)(arg1 + 0x6f0));
                                }
                                piVar60 = *ppiVar32;
                                *ppiVar32 = uStack_158;
                                *(int64_t **)(arg1 + 0x6f0) = piStack_150;
                                if (piVar60 != (int64_t *)0x0) {
                                    *(undefined8 *)(puVar42 + -8) = 0x1800bb3be;
                                    func_0x0001800f4640();
                                }
                                arg1 = *(int64_t *)(puVar42 + 0x60);
                            }
                        }
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb3ce;
                        iVar54 = func_0x0001800ac6e0(ppiVar32, ppiVar55 + 5);
                        *(undefined *)(iVar54 + 8) = puVar42[0x78];
                    }
                    *(undefined4 *)(puVar42 + 0x70) = *(undefined4 *)(arg1 + 0x60c);
                    iVar54 = *(int64_t *)arg1;
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb400;
                    func_0x0001800cfe30(iVar54, 0x42, puVar42[0x68], 0);
                    iVar54 = *(int64_t *)arg1;
                    piVar60 = *(int64_t **)(iVar54 + 0x30);
                    auVar65._8_8_ = uVar59;
                    auVar65._0_8_ = piVar60;
                    auStack_120 = (undefined  [8])*(undefined8 *)(iVar54 + 0x28);
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb427;
                    func_0x0001800d31a0((undefined8 *)(iVar54 + 0x28), &stack0xfffffffffffffe48);
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb437;
                    func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
                    piStack_c0 = (int64_t *)0x0;
                    ppiStack_b8 = (int64_t **)0x0;
                    piStack_b0 = (int64_t *)0x0;
                    piStack_a8 = (int64_t *)0x0;
                    uStack_a0 = 0;
                    auStack_98[0] = 0;
                    iVar54 = *ppiVar55[5];
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb464;
                    func_0x000180498cd0(iVar54);
                    iVar54 = *(int64_t *)arg1;
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb479;
                    iVar15 = func_0x0001800cf790(iVar54, &stack0xfffffffffffffe28);
                    uStack_c8 = CONCAT44(uStack_c8._4_4_, iVar15);
                    if (-1 < iVar15) {
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb495;
                        func_0x0001800bbe60(arg1, ppiVar55);
                        piVar39 = auVar65._0_8_;
                        piVar27 = ppiVar55[6];
                        piVar51 = piVar27 + (int64_t)ppiVar55[7] * 10;
                        piVar38 = piStack_c0;
                        ppiVar32 = ppiStack_b8;
                        piVar41 = piStack_b0;
                        piVar50 = piStack_a8;
                        uVar26 = uStack_a0;
                        uStack_128 = auStack_98[0];
                        for (; piVar27 != piVar51; piVar27 = piVar27 + 10) {
                            piStack_150 = &uStack_c8;
                            auStack_140._8_8_ = &uStack_c8;
                            auStack_140._0_8_ = &stack0xfffffffffffffe78;
                            puStack_130 = puVar42 + 0x68;
                            pcVar3 = *(code **)((int64_t)*(int32_t *)piVar27 * 8 + 0x180640188);
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb501;
                            uStack_158 = (int64_t *)arg1;
                            uStack_148 = (int64_t **)arg1;
                            piStack_c0 = piVar38;
                            ppiStack_b8 = ppiVar32;
                            piStack_b0 = piVar41;
                            piStack_a8 = piVar50;
                            uStack_a0 = uVar26;
                            auStack_98[0] = uStack_128;
                            (*pcVar3)(&uStack_158, piVar27 + 1);
                            piVar39 = auVar65._0_8_;
                            piVar38 = piStack_c0;
                            ppiVar32 = ppiStack_b8;
                            piVar41 = piStack_b0;
                            piVar50 = piStack_a8;
                            uVar26 = uStack_a0;
                            uStack_128 = auStack_98[0];
                        }
                        arg1 = *(int64_t *)arg1;
                        uVar33 = (uint64_t)uStack_158 >> 0x20;
                        uStack_158 = (int64_t *)CONCAT44((int32_t)uVar33, (undefined4)uStack_c8);
                        piStack_b0 = (int64_t *)0x0;
                        ppiStack_b8 = (int64_t **)0x0;
                        piStack_c0 = (int64_t *)0x0;
                        auStack_98[0] = 0;
                        uStack_a0 = 0;
                        piStack_a8 = (int64_t *)0x0;
                        auStack_140._8_8_ = piVar50;
                        auStack_140._0_8_ = piVar41;
                        puStack_108 = &uStack_158;
                        ppiVar45 = (int64_t **)
                                   ((*(int64_t *)(arg1 + 0x60) - *(int64_t *)(arg1 + 0x58) >> 3) * -0x5555555555555555);
                        uVar16 = (uint32_t)ppiVar45;
                        piStack_150 = piVar38;
                        uStack_148 = ppiVar32;
                        puStack_130 = (undefined *)uVar26;
                        if (0x7fffff < uVar16) goto code_r0x0001800bb80a;
                        uVar26 = (uint64_t)uStack_100 >> 0x20;
                        uStack_100 = (int64_t *)CONCAT44((int32_t)uVar26, 9);
                        iVar54 = *(int64_t *)(arg1 + 0xc0);
                        iVar44 = iVar54 - *(int64_t *)(arg1 + 0xb8) >> 3;
                        iVar48 = iVar44 * 0x6db6db6db6db6db7;
                        stack0xffffffffffffff0c = SUB1612(ZEXT816(0), 4);
                        auStack_f8._0_4_ = (int32_t)iVar48;
                        if (iVar54 == *(int64_t *)(arg1 + 200)) {
                            uVar26 = 0x492492492492492;
                            if (iVar48 == 0x492492492492492) goto code_r0x0001800bb9d4;
                            uVar33 = iVar48 + 1;
                            uVar36 = (*(int64_t *)(arg1 + 200) - *(int64_t *)(arg1 + 0xb8) >> 3) * 0x6db6db6db6db6db7;
                            uVar21 = 0x492492492492492 - (uVar36 >> 1);
                            if (uVar36 < uVar21 || uVar36 - uVar21 == 0) {
                                uVar36 = uVar36 + (uVar36 >> 1);
                                uVar26 = uVar33;
                                if (uVar33 <= uVar36) {
                                    uVar26 = uVar36;
                                }
                                if (0x492492492492492 < uVar26) {
                                    *(undefined8 *)(puVar42 + -8) = 0x1800bb7f8;
                                    func_0x000180004720();
                                    goto code_r0x0001800bb7f9;
                                }
                            }
                            iVar29 = uVar26 * 0x38;
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb66d;
                            piVar60 = piVar39;
                            iVar40 = func_0x000180004de0(iVar29);
                            iVar47 = iVar44 * 8 + iVar40;
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb683;
                            func_0x0001800d45d0(extraout_XMM0_Qa, iVar47, &uStack_158);
                            iVar48 = *(int64_t *)(arg1 + 0xc0);
                            iVar28 = *(int64_t *)(arg1 + 0xb8);
                            iVar44 = iVar40;
                            if (iVar54 != iVar48) {
                                *(undefined8 *)(puVar42 + -8) = 0x1800bb6a1;
                                func_0x0001800d4630(iVar28, iVar54, iVar40);
                                iVar44 = iVar47 + 0x38;
                                iVar48 = *(int64_t *)(arg1 + 0xc0);
                                iVar28 = iVar54;
                            }
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb6b4;
                            func_0x0001800d4630(iVar28, iVar48, iVar44);
                            iVar54 = *(int64_t *)(arg1 + 0xb8);
                            if (iVar54 != 0) {
                                uVar59 = *(undefined8 *)(arg1 + 0xc0);
                                *(undefined8 *)(puVar42 + -8) = 0x1800bb6cc;
                                uVar59 = func_0x0001800c1de0(iVar54, uVar59);
                                iVar54 = *(int64_t *)(arg1 + 0xb8);
                                iVar44 = *(int64_t *)(arg1 + 200);
                                *(undefined8 *)(puVar42 + -8) = 0x1800bb6f4;
                                func_0x0001800c2280(uVar59, iVar54, (iVar44 - iVar54 >> 3) * 0x6db6db6db6db6db7);
                            }
                            *(int64_t *)(arg1 + 0xb8) = iVar40;
                            *(uint64_t *)(arg1 + 0xc0) = uVar33 * 0x38 + iVar40;
                            *(int64_t *)(arg1 + 200) = iVar29 + iVar40;
                        } else {
                            *(undefined8 *)(puVar42 + -8) = 0x1800bb603;
                            func_0x0001800bc590(iVar54, &uStack_158);
                            *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 0x38;
                        }
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb728;
                        func_0x0001800d2f00(arg1 + 0x58, &uStack_100);
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb732;
                        func_0x00018002ee50(auStack_140 + 8);
                        *(undefined8 *)(puVar42 + -8) = 0x1800bb73b;
                        func_0x00018002ee50(&piStack_150);
                        if (-1 < (int32_t)uVar16) {
                            piVar27 = *(int64_t **)(puVar42 + 0x60);
                            iVar54 = *(int64_t *)(*piVar27 + 0x28);
                            *(uint32_t *)(iVar54 + ((int64_t)piVar60 - (int64_t)auStack_120 >> 2) * 4) = uVar16;
                            if (piStack_a8 != (int64_t *)0x0) {
                                *(undefined8 *)(puVar42 + -8) = 0x1800bb77a;
                                func_0x0001800c22c0(iVar54, piStack_a8, 
                                                    (int64_t)(auStack_98[0] - (int64_t)piStack_a8) >> 2);
                                piStack_a8 = (int64_t *)0x0;
                                uStack_a0 = 0;
                                auStack_98[0] = 0;
                            }
                            if (piStack_c0 != (int64_t *)0x0) {
                                *(undefined8 *)(puVar42 + -8) = 0x1800bb7af;
                                func_0x0001800c22c0();
                            }
                            *(undefined4 *)((int64_t)piVar27 + 0x60c) = *(undefined4 *)(puVar42 + 0x70);
                            goto code_r0x0001800bb7ba;
                        }
                        goto code_r0x0001800bb81c;
                    }
                    goto code_r0x0001800bb9bf;
                }
                uVar16 = *(uint32_t *)(arg1 + 0x60c);
                uVar26 = (uint64_t)uVar16;
                if (1 < *(int32_t *)(arg1 + 8)) {
                    piVar60 = ppiVar45[7];
                    *(undefined8 *)(puVar42 + -8) = 0x1800b987b;
                    cVar10 = func_0x0001800b2930(arg1, piVar60);
                    uVar16 = (uint32_t)uVar26;
                    if (cVar10 != '\0') {
                        piVar27 = ppiVar45[6];
                        *(undefined8 *)(puVar42 + -8) = 0x1800b9892;
                        cVar10 = func_0x0001800b2930(arg1, piVar27);
                        uVar16 = (uint32_t)uVar26;
                        if (cVar10 != '\0') {
                            piVar38 = ppiVar45[8];
                            if (piVar38 != (int64_t *)0x0) {
                                *(undefined8 *)(puVar42 + -8) = 0x1800b98ae;
                                cVar10 = func_0x0001800b2930(arg1, piVar38);
                                uVar16 = (uint32_t)uVar26;
                                if (cVar10 == '\0') goto code_r0x0001800b9e95;
                            }
                            *(undefined8 *)(puVar42 + -8) = 0x1800b98c9;
                            func_0x0001800b29d0(*(undefined8 *)(puVar42 + 0x60), &stack0xfffffffffffffe58, piVar27);
                            *(undefined8 *)(puVar42 + -8) = 0x1800b98da;
                            func_0x0001800b29d0(*(undefined8 *)(puVar42 + 0x60), &uStack_100, piVar60);
                            arg1 = *(int64_t *)(puVar42 + 0x60);
                            if (piVar38 == (int64_t *)0x0) {
                                piVar24 = (int32_t *)&stack0xfffffffffffffe28;
                                iVar15 = 3;
                            } else {
                                *(undefined8 *)(puVar42 + -8) = 0x1800b98f3;
                                piVar24 = (int32_t *)func_0x0001800b29d0(arg1, &stack0xfffffffffffffe28, piVar38);
                                iVar15 = *piVar24;
                            }
                            uVar16 = (uint32_t)uVar26;
                            if (((in_stack_fffffffffffffe58._0_4_ == 3) && ((int32_t)uStack_100 == 3)) && (iVar15 == 3))
                            {
                                dVar1 = *(double *)(piVar24 + 2);
                                *(undefined8 *)(puVar42 + -8) = 0x1800b9952;
                                dVar66 = in_stack_fffffffffffffe58._8_8_;
                                iVar19 = func_0x0001800c9560(3, SUB164(_auStack_f8, 0), dVar1);
                                iVar15 = *(int32_t *)0x180777f58;
                                uVar16 = (uint32_t)uVar26;
                                *(int32_t *)(puVar42 + 0x70) = iVar19;
                                if (iVar19 < 0) goto code_r0x0001800b9e85;
                                if (*(int32_t *)0x180777f58 < iVar19) {
                                    iVar54 = *(int64_t *)arg1;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9980;
                                    func_0x0001800d0a10(iVar54, 0x18063fc40, iVar19);
                                    goto code_r0x0001800b9e95;
                                }
                                *(undefined8 *)(puVar42 + -8) = 0x1800b9996;
                                iVar54 = func_0x0001800ac770((int64_t *)(arg1 + 0xd8), ppiVar45 + 5);
                                iVar37 = *(int32_t *)0x180777eb8;
                                uVar16 = (uint32_t)uVar26;
                                if (((iVar54 == 0) || (iVar54 == -8)) || (*(char *)(iVar54 + 0x10) == '\0')) {
                                    *(int64_t **)(puVar42 + 0x20) = (int64_t *)(arg1 + 0x100);
                                    piVar60 = ppiVar45[9];
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b99e5;
                                    uVar59 = func_0x0001800c92c0(piVar60, &stack0xfffffffffffffe28, 1, 
                                                                 (int64_t *)(arg1 + 0x1a0));
                                    uVar16 = (uint32_t)uVar26;
                                    uVar30 = (uint32_t)uVar59 & 0x7f;
                                    if (uVar30 == 0x7f) {
                                        iVar49 = 0x7f;
                                    } else {
                                        iVar49 = uVar30 - ((uint32_t)((uint64_t)uVar59 >> 8) & 0x7f);
                                    }
                                    iVar49 = iVar19 * iVar49;
                                    if ((iVar49 != 0) &&
                                       (iVar20 = (int32_t)((uVar30 + 1) * iVar19 * 100) / iVar49, iVar20 < iVar37)) {
                                        iVar37 = iVar20;
                                    }
                                    iVar54 = *(int64_t *)arg1;
                                    *(double *)(puVar42 + 0x20) = (double)iVar37 / 100.0;
                                    if (iVar49 <= (iVar37 * iVar15) / 100) {
                                        *(undefined8 *)(puVar42 + -8) = 0x1800b9a72;
                                        func_0x0001800d0a10(iVar54, 0x18063fab8);
                                        ppiStack_160 = (int64_t **)ppiVar45[5];
                                        piVar60 = *(int64_t **)(arg1 + 0x678);
                                        auVar63._8_8_ = dVar66;
                                        auVar63._0_8_ = piVar60;
                                        auStack_120 = (undefined  [8])
                                                      *(undefined8 *)(*(int64_t *)(puVar42 + 0x60) + 0x670);
                                        *(undefined8 *)(puVar42 + -8) = 0x1800b9aca;
                                        func_0x0001800bfab0(*(int64_t *)(puVar42 + 0x60) + 0x688, 
                                                            &stack0xfffffffffffffe28);
                                        piVar27 = *(int64_t **)(puVar42 + 0x60);
                                        if ((*(char *)0x180778018 != '\0') && (*(char *)0x180777ff8 != '\0')) {
                                            if (piVar27[0x57] != piVar27[0x58]) {
                                                piVar27[0x58] = piVar27[0x57];
                                            }
                                            if (piVar27[0x5a] != piVar27[0x5b]) {
                                                piVar27[0x5b] = piVar27[0x5a];
                                            }
                                        }
                                        iVar15 = 0;
                                        if (0 < iVar19) {
                                            piVar38 = piVar27 + 0x25;
                                            piVar39 = piVar27 + 0xc0;
                                            piVar60 = piVar27 + 10;
                                            piVar50 = piVar27 + 0xc1;
                                            piVar41 = piVar27 + 0xb7;
                                            piVar51 = piVar27 + 0xb7;
                                            do {
                                                *(undefined8 *)(puVar42 + -8) = 0x1800b9b4f;
                                                piVar62 = piVar51;
                                                puVar25 = (undefined4 *)func_0x0001800c05e0(piVar38, &ppiStack_160);
                                                *puVar25 = 3;
                                                *(undefined8 *)(puVar42 + -8) = 0x1800b9b74;
                                                iVar54 = func_0x0001800c05e0(piVar38, &ppiStack_160);
                                                *(double *)(iVar54 + 8) =
                                                     (double)iVar15 * dVar1 + in_stack_fffffffffffffe58._8_8_;
                                                if (*(char *)0x180778018 == '\0') {
                                                    iVar54 = *(int64_t *)(puVar42 + 0x60);
code_r0x0001800b9bf6:
                                                    iVar44 = 0;
                                                    iVar48 = 0;
                                                    piVar57 = (int64_t *)(iVar54 + 0x5b8);
                                                    piVar51 = (int64_t *)(iVar54 + 0x50);
                                                    piVar53 = (int64_t *)(iVar54 + 0x608);
                                                    piVar61 = (int64_t *)(iVar54 + 0x600);
                                                } else {
                                                    iVar54 = *(int64_t *)(puVar42 + 0x60);
                                                    if ((*(char *)0x180777ff8 == '\0') || (iVar15 != 0)) {
                                                        piVar60 = (int64_t *)(iVar54 + 0x50);
                                                        piVar50 = (int64_t *)(iVar54 + 0x608);
                                                        piVar39 = (int64_t *)(iVar54 + 0x600);
                                                        piVar41 = piVar51;
                                                        goto code_r0x0001800b9bf6;
                                                    }
                                                    piVar41 = (int64_t *)(iVar54 + 0x5b8);
                                                    piVar60 = (int64_t *)(iVar54 + 0x50);
                                                    piVar50 = (int64_t *)(iVar54 + 0x608);
                                                    piVar39 = (int64_t *)(iVar54 + 0x600);
                                                    iVar44 = iVar54 + 0x2b8;
                                                    iVar48 = iVar54 + 0x2d0;
                                                    piVar51 = piVar60;
                                                    piVar53 = piVar50;
                                                    piVar57 = piVar41;
                                                    piVar61 = piVar39;
                                                }
                                                *(int64_t *)(puVar42 + 0x50) = iVar48;
                                                *(int64_t *)(puVar42 + 0x48) = iVar44;
                                                *(int64_t *)(puVar42 + 0x40) = iVar54 + 0x150;
                                                *(int64_t *)(puVar42 + 0x38) = *piVar41;
                                                *(int64_t ***)(puVar42 + 0x30) = ppiVar45;
                                                *(int64_t *)(puVar42 + 0x28) = *piVar60;
                                                puVar42[0x20] = *(undefined *)piVar50;
                                                iVar44 = *piVar39;
                                                *(undefined8 *)(puVar42 + -8) = 0x1800b9c65;
                                                piVar27 = piVar38;
                                                func_0x0001800c7640(iVar54 + 0x100, iVar54 + 0xd8);
                                                uVar33 = *(int64_t *)(iVar54 + 0x678) -
                                                         *(int64_t *)(*(int64_t *)(puVar42 + 0x60) + 0x670) >> 4;
                                                piVar60 = ppiVar45[9];
                                                *(undefined8 *)(puVar42 + -8) = 0x1800b9c88;
                                                fcn.1800b7cc0(*(int64_t *)(puVar42 + 0x60), (int64_t)piVar60, piVar27, 
                                                              (int64_t **)iVar44, *(int64_t *)(puVar42 + 0x20), 
                                                              *(int64_t *)(puVar42 + 0x28), *(int64_t *)(puVar42 + 0x30)
                                                              , *(int64_t *)(puVar42 + 0x38), 
                                                              *(int64_t *)(puVar42 + 0x40), *(int64_t *)(puVar42 + 0x48)
                                                              , *(int64_t *)(puVar42 + 0x50), 
                                                              *(int64_t *)(puVar42 + 0x58), *(int64_t *)(puVar42 + 0x60)
                                                              , *(int64_t *)(puVar42 + 0x68), 
                                                              *(int64_t *)(puVar42 + 0x70), *(int64_t *)(puVar42 + 0x78)
                                                              , *(undefined8 *)(puVar42 + 0x80), 
                                                              *(int64_t *)(puVar42 + 0x88), *(int64_t *)(puVar42 + 0x90)
                                                              , *(int64_t *)(puVar42 + 0x98), 
                                                              *(int64_t *)(puVar42 + 0xa0), *(int64_t *)(puVar42 + 0xa8)
                                                              , *(int64_t *)(puVar42 + 0xb0), 
                                                              *(int64_t *)(puVar42 + 0xb8), *(int64_t *)(puVar42 + 0xc0)
                                                              , *(int64_t *)(puVar42 + 200), 
                                                              *(undefined8 *)(puVar42 + 0xd0), 
                                                              *(int64_t *)(puVar42 + 0xd8), 
                                                              *(undefined8 *)(puVar42 + 0xe0), 
                                                              *(int64_t *)(puVar42 + 0xe8));
                                                piVar27 = *(int64_t **)(puVar42 + 0x60);
                                                iVar54 = piVar27[0xce];
                                                piVar39 = piVar61;
                                                if (uVar33 < (uint64_t)(piVar27[0xcf] - iVar54 >> 4)) {
                                                    do {
                                                        if (*(int32_t *)(iVar54 + uVar33 * 0x10) == 1) {
                                                            uVar59 = *(undefined8 *)(iVar54 + 8 + uVar33 * 0x10);
                                                            iVar54 = *piVar27;
                                                            *(undefined8 *)(puVar42 + -8) = 0x1800b9cdc;
                                                            cVar10 = func_0x0001800cfeb0(iVar54, uVar59);
                                                            if (cVar10 == '\0') goto code_r0x0001800bb924;
                                                            piVar27 = *(int64_t **)(puVar42 + 0x60);
                                                        }
                                                        uVar33 = uVar33 + 1;
                                                        iVar54 = piVar27[0xce];
                                                    } while (uVar33 < (uint64_t)(piVar27[0xcf] - iVar54 >> 4));
                                                }
                                                iVar15 = iVar15 + 1;
                                                piVar60 = piVar51;
                                                piVar50 = piVar53;
                                                piVar41 = piVar57;
                                                piVar51 = piVar62;
                                            } while (iVar15 < *(int32_t *)(puVar42 + 0x70));
                                            piVar60 = auVar63._0_8_;
                                        }
                                        uVar18 = (undefined4)uVar26;
                                        uVar36 = (int64_t)piVar60 - (int64_t)auStack_120 >> 4;
                                        iVar54 = *(int64_t *)(*piVar27 + 0x30);
                                        iVar44 = *(int64_t *)(*piVar27 + 0x28);
                                        iVar48 = piVar27[0xce];
                                        uVar33 = uVar36;
                                        if (uVar36 < (uint64_t)(piVar27[0xcf] - iVar48 >> 4)) {
                                            do {
                                                if (*(int32_t *)(iVar48 + uVar33 * 0x10) == 0) {
                                                    uVar59 = *(undefined8 *)(iVar48 + 8 + uVar33 * 0x10);
                                                    iVar48 = *piVar27;
                                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9d7c;
                                                    cVar10 = func_0x0001800cfeb0(iVar48, uVar59, iVar54 - iVar44 >> 2);
                                                    if (cVar10 == '\0') goto code_r0x0001800bb924;
                                                    piVar27 = *(int64_t **)(puVar42 + 0x60);
                                                }
                                                uVar18 = (undefined4)uVar26;
                                                uVar33 = uVar33 + 1;
                                                iVar48 = piVar27[0xce];
                                            } while (uVar33 < (uint64_t)(piVar27[0xcf] - iVar48 >> 4));
                                        }
                                        *(undefined8 *)(puVar42 + -8) = 0x1800b9db5;
                                        func_0x0001800bfcc0(piVar27 + 0xce, uVar36);
                                        iVar54 = *(int64_t *)(puVar42 + 0x60);
                                        *(int64_t *)(iVar54 + 0x690) = *(int64_t *)(iVar54 + 0x690) + -0x18;
                                        *(undefined8 *)(puVar42 + -8) = 0x1800b9dd2;
                                        puVar25 = (undefined4 *)func_0x0001800c05e0(iVar54 + 0x128, &ppiStack_160);
                                        *puVar25 = 0;
                                        if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 == '\0')) {
                                            *(undefined8 *)(puVar42 + 0x50) = 0;
                                            *(undefined8 *)(puVar42 + 0x48) = 0;
                                            *(int64_t *)(puVar42 + 0x40) = iVar54 + 0x150;
                                            *(undefined8 *)(puVar42 + 0x38) = *(undefined8 *)(iVar54 + 0x5b8);
                                            *(int64_t ***)(puVar42 + 0x30) = ppiVar45;
                                            *(undefined8 *)(puVar42 + 0x28) = *(undefined8 *)(iVar54 + 0x50);
                                            puVar42[0x20] = *(undefined *)(iVar54 + 0x608);
                                            uVar59 = *(undefined8 *)(iVar54 + 0x600);
                                            *(undefined8 *)(puVar42 + -8) = 0x1800b9e76;
                                            func_0x0001800c7640(iVar54 + 0x100, iVar54 + 0xd8, iVar54 + 0x128, uVar59);
                                        } else {
                                            *(undefined8 *)(puVar42 + -8) = 0x1800b9dfd;
                                            func_0x0001800c75a0(iVar54 + 0x100, iVar54 + 0x2b8);
                                            *(undefined8 *)(puVar42 + -8) = 0x1800b9e10;
                                            func_0x0001800c75a0(iVar54 + 0x128, iVar54 + 0x2d0);
                                        }
                                        *(undefined4 *)(iVar54 + 0x60c) = uVar18;
                                        goto code_r0x0001800bb7ba;
                                    }
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9a61;
                                    func_0x0001800d0a10(iVar54, 0x18063fca0);
                                    goto code_r0x0001800b9e95;
                                }
                                uVar59 = 0x18063fc70;
                            } else {
code_r0x0001800b9e85:
                                uVar59 = 0x18063fc10;
                            }
                            iVar54 = *(int64_t *)arg1;
                            *(undefined8 *)(puVar42 + -8) = 0x1800b9e95;
                            func_0x0001800d0a10(iVar54, uVar59);
                        }
                    }
                }
code_r0x0001800b9e95:
                piVar60 = *(int64_t **)(puVar42 + 0x60);
                iVar48 = *(int64_t *)(arg1 + 0x648) - piVar60[200] >> 3;
                iVar54 = piVar60[0xcf];
                puStack_108 = (undefined8 *)piVar60[0xce];
                *(undefined8 *)(puVar42 + -8) = 0x1800b9edf;
                func_0x0001800bfab0(piVar60 + 0xd1, &stack0xfffffffffffffe28);
                *(undefined *)(piVar60 + 0xc4) = 1;
                *(undefined8 *)(puVar42 + -8) = 0x1800b9ef7;
                uVar11 = func_0x0001800bbe60(piVar60, ppiVar45, 3);
                puVar42[0x68] = uVar11 + 2;
                uVar26 = *(int64_t *)(*piVar60 + 0x30) - *(int64_t *)(*piVar60 + 0x28) >> 2;
                *(undefined8 *)(puVar42 + -8) = 0x1800b9f26;
                iVar44 = func_0x0001800ac770(piVar60 + 0x1b, ppiVar45 + 5);
                if (((iVar44 != 0) && (iVar44 != -8)) && (*(char *)(iVar44 + 0x10) != '\0')) {
                    *(undefined8 *)(puVar42 + -8) = 0x1800b9f45;
                    uVar12 = func_0x0001800bbe60(piVar60, ppiVar45, 1);
                    puVar42[0x68] = uVar12;
                }
                piVar27 = ppiVar45[6];
                *(undefined8 *)(puVar42 + -8) = 0x1800b9f5d;
                func_0x0001800b4ce0(piVar60, piVar27, uVar11 + 2, 1);
                piVar27 = ppiVar45[7];
                *(undefined8 *)(puVar42 + -8) = 0x1800b9f71;
                func_0x0001800b4ce0(piVar60, piVar27, uVar11, 1);
                if (ppiVar45[8] == (int64_t *)0x0) {
                    puVar42[0x20] = 0;
                    iVar44 = *piVar60;
                    *(undefined8 *)(puVar42 + -8) = 0x1800b9f9e;
                    func_0x0001800cfdd0(iVar44, 4, uVar11 + 1, 1);
                } else {
                    *(undefined8 *)(puVar42 + -8) = 0x1800b9f8a;
                    func_0x0001800b4ce0(piVar60);
                }
                iVar44 = *piVar60;
                piVar27 = (int64_t *)(*(int64_t *)(iVar44 + 0x30) - *(int64_t *)(iVar44 + 0x28) >> 2);
                *(uint32_t *)(puVar42 + 0x70) = (uint32_t)uVar11 << 8 | 0x38;
                *(undefined8 *)(puVar42 + -8) = 0x1800b9fce;
                func_0x0001800d31a0((int64_t *)(iVar44 + 0x28), puVar42 + 0x70);
                *(undefined8 *)(puVar42 + -8) = 0x1800b9fde;
                func_0x0001800d31a0(iVar44 + 0x40, iVar44 + 0x270);
                piVar60 = *(int64_t **)(puVar42 + 0x60);
                iVar44 = *piVar60;
                iVar28 = *(int64_t *)(iVar44 + 0x30);
                auStack_120 = (undefined  [8])*(undefined8 *)(iVar44 + 0x28);
                uVar13 = puVar42[0x68];
                if ((uint32_t)uVar13 != uVar11 + 2) {
                    puVar42[0x20] = 0;
                    *(undefined8 *)(puVar42 + -8) = 0x1800ba016;
                    func_0x0001800cfdd0(iVar44, 6, uVar13, uVar11 + 2);
                }
                uVar26 = uVar26 & 0xffffffff;
                uVar33 = (uint64_t)uVar13;
                piVar38 = ppiVar45[5];
                *(undefined8 *)(puVar42 + -8) = 0x1800ba02a;
                func_0x0001800bba40(piVar60, piVar38);
                piVar38 = ppiVar45[9];
                *(undefined8 *)(puVar42 + -8) = 0x1800ba036;
                fcn.1800b7cc0((int64_t)piVar60, (int64_t)piVar38, uVar33, (int64_t **)uVar26, 
                              *(int64_t *)(puVar42 + 0x20), *(int64_t *)(puVar42 + 0x28), *(int64_t *)(puVar42 + 0x30), 
                              *(int64_t *)(puVar42 + 0x38), *(int64_t *)(puVar42 + 0x40), *(int64_t *)(puVar42 + 0x48), 
                              *(int64_t *)(puVar42 + 0x50), *(int64_t *)(puVar42 + 0x58), *(int64_t *)(puVar42 + 0x60), 
                              *(int64_t *)(puVar42 + 0x68), *(int64_t *)(puVar42 + 0x70), *(int64_t *)(puVar42 + 0x78), 
                              *(undefined8 *)(puVar42 + 0x80), *(int64_t *)(puVar42 + 0x88), 
                              *(int64_t *)(puVar42 + 0x90), *(int64_t *)(puVar42 + 0x98), *(int64_t *)(puVar42 + 0xa0), 
                              *(int64_t *)(puVar42 + 0xa8), *(int64_t *)(puVar42 + 0xb0), *(int64_t *)(puVar42 + 0xb8), 
                              *(int64_t *)(puVar42 + 0xc0), *(int64_t *)(puVar42 + 200), *(undefined8 *)(puVar42 + 0xd0)
                              , *(int64_t *)(puVar42 + 0xd8), *(undefined8 *)(puVar42 + 0xe0), 
                              *(int64_t *)(puVar42 + 0xe8));
                *(undefined8 *)(puVar42 + -8) = 0x1800ba041;
                func_0x0001800bbb60(piVar60, iVar48);
                *(undefined8 *)(puVar42 + -8) = 0x1800ba04f;
                func_0x0001800bbc30(piVar60, iVar48);
                if (0 < *(int32_t *)((int64_t)piVar60 + 0xc)) {
                    *(int32_t *)(*piVar60 + 0x270) = *(int32_t *)((int64_t)ppiVar45 + 0xc) + 1;
                }
                iVar44 = *piVar60;
                iVar48 = *(int64_t *)(iVar44 + 0x30);
                iVar29 = *(int64_t *)(iVar44 + 0x28);
                *(undefined8 *)(puVar42 + -8) = 0x1800ba083;
                func_0x0001800d31a0((int64_t *)(iVar44 + 0x28), &stack0xfffffffffffffe48);
                *(undefined8 *)(puVar42 + -8) = 0x1800ba093;
                func_0x0001800d31a0(iVar44 + 0x40, iVar44 + 0x270);
                iVar44 = *piVar60;
                iVar40 = *(int64_t *)(iVar44 + 0x30) - *(int64_t *)(iVar44 + 0x28) >> 2;
                *(undefined8 *)(puVar42 + -8) = 0x1800ba0af;
                cVar10 = func_0x0001800cfeb0(iVar44, piVar27, iVar40);
                if (cVar10 == '\0') {
code_r0x0001800bb924:
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb934;
                    func_0x0001800acea0((int64_t)ppiVar45 + 0xc, 0x18063f7f0);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                iVar48 = iVar48 - iVar29 >> 2;
                piVar27 = (int64_t *)(iVar28 - (int64_t)auStack_120 >> 2);
                iVar44 = *piVar60;
                *(undefined8 *)(puVar42 + -8) = 0x1800ba0d5;
                cVar10 = func_0x0001800cfeb0(iVar44, iVar48);
                if (cVar10 == '\0') {
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb945;
                    func_0x0001800acea0((int64_t)ppiVar45 + 0xc, 0x18063f7f0);
code_r0x0001800bb946:
                    iVar54 = *piVar27;
                    *(undefined8 *)(puVar42 + -8) = 0x1800bb95f;
                    func_0x0001800acea0(piVar27 + 1, 0x18063fb70, iVar54, 200);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                iVar54 = iVar54 - (int64_t)puStack_108 >> 4;
                *(int64_t *)(puVar42 + 0x20) = iVar48;
                *(undefined8 *)(puVar42 + -8) = 0x1800ba0fb;
                func_0x0001800bbdb0(piVar60, ppiVar45, iVar54, iVar40);
                *(undefined8 *)(puVar42 + -8) = 0x1800ba10b;
                func_0x0001800bfcc0(piVar60 + 0xce, iVar54);
                piVar60[0xd2] = piVar60[0xd2] + -0x18;
                *(uint32_t *)((int64_t)piVar60 + 0x60c) = uVar16;
                goto code_r0x0001800bb7ba;
            }
            if ((1 < *(int32_t *)(arg1 + 8)) && (*(int64_t *)(arg1 + 0x6a0) != *(int64_t *)(arg1 + 0x6a8))) {
                if (0 < *(int32_t *)(arg1 + 0xc)) {
                    *(int32_t *)(*(int64_t *)arg1 + 0x270) = *(int32_t *)((int64_t)ppiVar55 + 0xc) + 1;
                }
                iVar54 = *(int64_t *)(arg1 + 0x6a8);
                uStack_158 = *(int64_t **)(iVar54 + -0x30);
                piStack_150 = *(int64_t **)(iVar54 + -0x28);
                uVar12 = *(undefined *)(undefined2 *)(iVar54 + -0x20);
                uVar14 = *(undefined *)(iVar54 + -0x1f);
                uStack_148 = (int64_t **)CONCAT62(uStack_148._2_6_, *(undefined2 *)(iVar54 + -0x20));
                auStack_140 = ZEXT816(0);
                puStack_130 = (undefined *)0x0;
                if (*(int64_t *)(iVar54 + -0x10) - *(int64_t *)(iVar54 + -0x18) >> 3 != 0) {
                    *(undefined8 *)(puVar42 + -8) = 0x1800b8dfc;
                    func_0x0001800c21e0(auStack_140);
                    ppiVar32 = (int64_t **)auStack_140._0_8_;
                    iVar44 = *(int64_t *)(iVar54 + -0x18);
                    iVar54 = *(int64_t *)(iVar54 + -0x10) - iVar44;
                    *(undefined8 *)(puVar42 + -8) = 0x1800b8e16;
                    func_0x000180498030(auStack_140._0_8_, iVar44, iVar54);
                    auStack_140._8_8_ = ppiVar32 + (iVar54 >> 3);
                    uVar12 = (undefined)uStack_148;
                    uVar14 = uStack_148._1_1_;
                }
                uVar26 = (uint64_t)puStack_130;
                piVar27 = piStack_150;
                puVar42[0x20] = 0;
                piVar60 = *(int64_t **)(puVar42 + 0x60);
                *(undefined8 *)(puVar42 + -8) = 0x1800b8e59;
                func_0x0001800b72a0(piVar60, ppiVar55 + 5, uVar12, uVar14);
                *(undefined8 *)(puVar42 + -8) = 0x1800b8e64;
                func_0x0001800bbb60(piVar60, piVar27);
                iVar54 = *piVar60;
                *(undefined4 *)(puVar42 + 0x70) = 0x17;
                *(undefined8 *)(puVar42 + -8) = 0x1800b8e8c;
                func_0x0001800d31a0(iVar54 + 0x28, puVar42 + 0x70);
                *(undefined8 *)(puVar42 + -8) = 0x1800b8e9c;
                func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
                iVar54 = piVar60[0xd5];
                *(undefined8 *)(puVar42 + -8) = 0x1800b8eb0;
                uVar59 = func_0x0001800bf890(iVar54 + -0x18, &stack0xfffffffffffffe28);
                if (ppiVar32 != (int64_t **)0x0) {
                    *(undefined8 *)(puVar42 + -8) = 0x1800b8ecc;
                    func_0x0001800c21a0(uVar59, ppiVar32, (int64_t)(uVar26 - (int64_t)ppiVar32) >> 3);
                }
                goto code_r0x0001800bb7ba;
            }
            piVar60 = ppiVar55[6];
            if ((int64_t *)0xfe < piVar60) goto code_r0x0001800bb883;
            iVar15 = *(int32_t *)(arg1 + 0x60c);
            if (piVar60 == (int64_t *)0x0) {
                uVar11 = 0;
code_r0x0001800b91e0:
                piVar60 = *(int64_t **)(puVar42 + 0x60);
                *(undefined8 *)(puVar42 + -8) = 0x1800b91ef;
                func_0x0001800bbb60(piVar60, 0);
                iVar54 = *piVar60;
code_r0x0001800b91f2:
                cVar10 = *(char *)(ppiVar55 + 6) + '\x01';
            } else {
                ppiVar45 = (int64_t **)((uint64_t)ppiVar45 & 0xffffffffffffff00);
                piVar27 = ppiVar55[5];
                iVar54 = *piVar27;
                *(undefined8 *)(puVar42 + -8) = 0x1800b8f13;
                uVar16 = fcn.1800b7be0(*(int64_t *)(puVar42 + 0x60), iVar54);
                cVar10 = *(char *)0x180777f78;
                uVar26 = (uint64_t)uVar16;
                uVar11 = (uint8_t)uVar16;
                if ((int32_t)uVar16 < 0) {
code_r0x0001800b8fde:
                    uVar16 = *(int32_t *)(ppiVar55 + 6) + iVar15;
                    if (0xff < uVar16) goto code_r0x0001800bb894;
                    piVar60 = *(int64_t **)(puVar42 + 0x60);
                    *(uint32_t *)((int64_t)piVar60 + 0x60c) = uVar16;
                    uVar30 = *(uint32_t *)(piVar60 + 0xc2);
                    if (*(uint32_t *)(piVar60 + 0xc2) < uVar16) {
                        uVar30 = uVar16;
                    }
                    *(uint32_t *)(piVar60 + 0xc2) = uVar30;
                    uVar11 = (uint8_t)iVar15;
                    uVar26 = (uint64_t)uVar11;
                    piVar38 = (int64_t *)0x0;
                    piVar27 = ppiVar55[6];
                    if (piVar27 != (int64_t *)0x0) {
                        do {
                            piVar41 = (int64_t *)((int64_t)piVar38 + 1);
                            uVar16 = iVar15 + (int32_t)piVar38;
                            if (piVar41 == piVar27) {
                                iVar54 = ppiVar55[5][(int64_t)piVar38];
                                iVar44 = 0;
                                if (*(int32_t *)(iVar54 + 8) == *(int32_t *)0x180782740) {
                                    iVar44 = iVar54;
                                }
                                if (iVar44 != 0) {
                                    if (1 < *(int32_t *)(piVar60 + 1)) {
                                        *(undefined8 *)(puVar42 + -8) = 0x1800b906f;
                                        cVar10 = func_0x0001800aeb90(piVar60, iVar54);
                                        if (cVar10 == '\0') {
                                            *(undefined8 *)(puVar42 + -8) = 0x1800b9087;
                                            func_0x0001800b4ce0(*(undefined8 *)(puVar42 + 0x60), iVar54, uVar16 & 0xff);
                                            ppiVar45 = (int64_t **)0x0;
                                            piVar60 = *(int64_t **)(puVar42 + 0x60);
                                            goto code_r0x0001800b91aa;
                                        }
                                        piVar60 = *(int64_t **)(puVar42 + 0x60);
                                    }
                                    uVar18 = *(undefined4 *)((int64_t)piVar60 + 0x60c);
                                    *(uint32_t *)((int64_t)piVar60 + 0x60c) = uVar16 & 0xff;
                                    puVar42[0x28] = 1;
                                    puVar42[0x20] = 1;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b90ce;
                                    func_0x0001800b0700(piVar60, iVar44, uVar16 & 0xff, 0);
                                    ppiVar45 = (int64_t **)0x1;
                                    goto code_r0x0001800b919e;
                                }
                                iVar44 = 0;
                                if (*(int32_t *)(iVar54 + 8) == *(int32_t *)0x1807826b8) {
                                    iVar44 = iVar54;
                                }
                                if (iVar44 == 0) {
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9165;
                                    func_0x0001800b4ce0(piVar60, iVar54, uVar16 & 0xff, 1);
                                    ppiVar45 = (int64_t **)0x0;
                                    piVar60 = *(int64_t **)(puVar42 + 0x60);
                                } else {
                                    uVar18 = *(undefined4 *)((int64_t)piVar60 + 0x60c);
                                    *(uint32_t *)((int64_t)piVar60 + 0x60c) = uVar16 & 0xff;
                                    if (0 < *(int32_t *)((int64_t)piVar60 + 0xc)) {
                                        *(int32_t *)(*piVar60 + 0x270) = *(int32_t *)(iVar44 + 0xc) + 1;
                                    }
                                    iVar54 = *piVar60;
                                    *(uint32_t *)(puVar42 + 0x70) = (uVar16 & 0xff) << 8 | 0x3f;
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9131;
                                    func_0x0001800d31a0(iVar54 + 0x28, puVar42 + 0x70);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b9141;
                                    func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
                                    piVar60 = *(int64_t **)(puVar42 + 0x60);
                                    *(undefined4 *)((int64_t)piVar60 + 0x60c) = uVar18;
                                    ppiVar45 = (int64_t **)0x1;
                                }
                            } else {
                                iVar54 = ppiVar55[5][(int64_t)piVar38];
                                uVar18 = *(undefined4 *)((int64_t)piVar60 + 0x60c);
                                uStack_118._0_4_ = uVar18;
                                auStack_120 = (undefined  [8])piVar60;
                                *(uint32_t *)((int64_t)piVar60 + 0x60c) = (uVar16 & 0xff) + 1;
                                *(undefined8 *)(puVar42 + -8) = 0x1800b919d;
                                func_0x0001800b4ce0(piVar60, iVar54, uVar16 & 0xff, 1);
code_r0x0001800b919e:
                                piVar60 = *(int64_t **)(puVar42 + 0x60);
                                *(undefined4 *)((int64_t)piVar60 + 0x60c) = uVar18;
                            }
code_r0x0001800b91aa:
                            uVar11 = (uint8_t)uVar26;
                            piVar27 = ppiVar55[6];
                            piVar38 = piVar41;
                        } while (piVar41 < piVar27);
                    }
                } else {
                    if ((int64_t *)0x1 < piVar60) {
                        piVar38 = (int64_t *)0x1;
                        do {
                            iVar54 = piVar27[(int64_t)piVar38];
                            if (cVar10 == '\0') {
                                iVar19 = *(int32_t *)(iVar54 + 8);
                                iVar44 = 0;
                                if (iVar19 == *(int32_t *)0x180782728) {
                                    iVar44 = iVar54;
                                }
                                if (iVar44 != 0) goto code_r0x0001800b8f8c;
                                iVar44 = 0;
                                if (iVar19 == *(int32_t *)0x1807826c0) {
                                    iVar44 = iVar54;
                                }
                                if (iVar44 != 0) {
code_r0x0001800b8f7e:
                                    uVar59 = *(undefined8 *)(iVar44 + 0x20);
                                    *(undefined8 *)(puVar42 + -8) = 0x1800b8f87;
                                    iVar44 = func_0x0001800b7b80(iVar54, uVar59);
                                    goto code_r0x0001800b8f87;
                                }
                                if (iVar19 == *(int32_t *)0x180782708) {
                                    iVar44 = iVar54;
                                }
                                if (iVar44 != 0) goto code_r0x0001800b8f7e;
code_r0x0001800b8fb7:
                                uVar16 = 0xffffffff;
                            } else {
                                *(undefined8 *)(puVar42 + -8) = 0x1800b8f44;
                                iVar44 = func_0x0001800beb60();
code_r0x0001800b8f87:
                                if (iVar44 == 0) goto code_r0x0001800b8fb7;
code_r0x0001800b8f8c:
                                *(undefined8 *)(puVar42 + -8) = 0x1800b8fa1;
                                iVar54 = func_0x0001800ac770(*(int64_t *)(puVar42 + 0x60) + 0x88, iVar44 + 0x20);
                                if (((iVar54 == 0) || ((uint8_t *)(iVar54 + 8) == (uint8_t *)0x0)) ||
                                   (*(char *)(iVar54 + 9) == '\0')) goto code_r0x0001800b8fb7;
                                uVar16 = (uint32_t)*(uint8_t *)(iVar54 + 8);
                            }
                            uVar11 = (uint8_t)uVar26;
                            if (uVar16 != ((uint32_t)uVar26 & 0xff) + (int32_t)piVar38) goto code_r0x0001800b8fde;
                            piVar38 = (int64_t *)((int64_t)piVar38 + 1);
                        } while (piVar38 < piVar60);
                        goto code_r0x0001800b91e0;
                    }
                    piVar60 = *(int64_t **)(puVar42 + 0x60);
                }
                *(undefined8 *)(puVar42 + -8) = 0x1800b91cb;
                func_0x0001800bbb60(piVar60, 0);
                piVar60 = *(int64_t **)(puVar42 + 0x60);
                iVar54 = *piVar60;
                if ((char)ppiVar45 == '\0') goto code_r0x0001800b91f2;
                cVar10 = '\0';
            }
            *(uint32_t *)(puVar42 + 0x70) = (uint32_t)CONCAT11(cVar10, uVar11) << 8 | 0x16;
            *(undefined8 *)(puVar42 + -8) = 0x1800b921d;
            func_0x0001800d31a0(iVar54 + 0x28, puVar42 + 0x70);
            *(undefined8 *)(puVar42 + -8) = 0x1800b922d;
            func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
            *(int32_t *)((int64_t)piVar60 + 0x60c) = iVar15;
            goto code_r0x0001800bb7ba;
        }
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x690) + -8) == 0) {
            *(int64_t ***)(*(int64_t *)(arg1 + 0x690) + -8) = ppiVar46;
        }
        uVar59 = *(undefined8 *)(*(int64_t *)(arg1 + 0x690) + -0x10);
        *(undefined8 *)(puVar42 + -8) = 0x1800b8d00;
        func_0x0001800bbb60(arg1, uVar59);
        iVar54 = *(int64_t *)arg1;
        *(undefined4 *)(puVar42 + 0x70) = 0x17;
        *(undefined8 *)(puVar42 + -8) = 0x1800b8d25;
        func_0x0001800d31a0(iVar54 + 0x28, puVar42 + 0x70);
        *(undefined8 *)(puVar42 + -8) = 0x1800b8d35;
        func_0x0001800d31a0(iVar54 + 0x40, iVar54 + 0x270);
    }
    *(undefined8 *)(puVar42 + -8) = 0x1800b8d54;
    func_0x0001800bfe60((int64_t *)(arg1 + 0x670), &stack0xfffffffffffffe28);
code_r0x0001800bb7ba:
    *(undefined8 *)(puVar42 + -8) = 0x1800bb7c9;
    func_0x000180459870(var_78h ^ (uint64_t)puVar42);
    return;
    while (iVar29 = iVar40, iVar40 != 6) {
code_r0x0001800ba2c0:
        iVar40 = iVar29 + 1;
        if (*(char *)(iVar28 + iVar29) != *(char *)(iVar29 + 0x180625f3c)) break;
    }
code_r0x0001800ba379:
    arg1 = *(int64_t *)arg1;
    iVar28 = *(int64_t *)(arg1 + 0x30);
    auVar64._8_8_ = uVar59;
    auVar64._0_8_ = *(undefined8 *)(arg1 + 0x28);
    *(undefined8 *)(puVar42 + -8) = 0x1800ba3a1;
    func_0x0001800d31a0((undefined8 *)(arg1 + 0x28), &stack0xfffffffffffffe48);
    *(undefined8 *)(puVar42 + -8) = 0x1800ba3b1;
    func_0x0001800d31a0(arg1 + 0x40, arg1 + 0x270);
    piVar50 = auVar64._0_8_;
    piVar38 = *(int64_t **)(puVar42 + 0x60);
    iVar29 = *(int64_t *)(*piVar38 + 0x30);
    iVar40 = *(int64_t *)(*piVar38 + 0x28);
    piVar41 = (int64_t *)0x0;
    if (ppiVar46[6] != (int64_t *)0x0) {
        do {
            piVar27 = (int64_t *)ppiVar46[5][(int64_t)piVar41];
            if (199 < (uint64_t)(piVar38[0xc9] - piVar38[200] >> 3)) goto code_r0x0001800bb946;
            *(undefined8 *)(puVar42 + -8) = 0x1800ba40b;
            func_0x0001800bf890(piVar38 + 200, &stack0xfffffffffffffe18);
            *(undefined8 *)(puVar42 + -8) = 0x1800ba420;
            pcVar23 = (char *)func_0x0001800c0050(*(int64_t *)(puVar42 + 0x60) + 0x88, &stack0xfffffffffffffe18);
            piVar50 = auVar64._0_8_;
            *pcVar23 = (char)piVar41 + puVar42[0x68];
            pcVar23[1] = '\x01';
            iVar19 = (int32_t)(*(int64_t *)(**(int64_t **)(puVar42 + 0x60) + 0x30) -
                               *(int64_t *)(**(int64_t **)(puVar42 + 0x60) + 0x28) >> 2);
            *(int32_t *)(pcVar23 + 4) = iVar19;
            iVar15 = (int32_t)(iVar44 - iVar48 >> 2);
            if (iVar15 == -1) {
                iVar15 = iVar19;
            }
            *(int32_t *)(pcVar23 + 8) = iVar15;
            piVar41 = (int64_t *)((int64_t)piVar41 + 1);
            piVar38 = *(int64_t **)(puVar42 + 0x60);
        } while (piVar41 < ppiVar46[6]);
    }
    piVar41 = ppiVar46[9];
    *(undefined8 *)(puVar42 + -8) = 0x1800ba47d;
    fcn.1800b7cc0((int64_t)piVar38, (int64_t)piVar41, piVar27, (int64_t **)piVar60, *(int64_t *)(puVar42 + 0x20), 
                  *(int64_t *)(puVar42 + 0x28), *(int64_t *)(puVar42 + 0x30), *(int64_t *)(puVar42 + 0x38), 
                  *(int64_t *)(puVar42 + 0x40), *(int64_t *)(puVar42 + 0x48), *(int64_t *)(puVar42 + 0x50), 
                  *(int64_t *)(puVar42 + 0x58), *(int64_t *)(puVar42 + 0x60), *(int64_t *)(puVar42 + 0x68), 
                  *(int64_t *)(puVar42 + 0x70), *(int64_t *)(puVar42 + 0x78), *(undefined8 *)(puVar42 + 0x80), 
                  *(int64_t *)(puVar42 + 0x88), *(int64_t *)(puVar42 + 0x90), *(int64_t *)(puVar42 + 0x98), 
                  *(int64_t *)(puVar42 + 0xa0), *(int64_t *)(puVar42 + 0xa8), *(int64_t *)(puVar42 + 0xb0), 
                  *(int64_t *)(puVar42 + 0xb8), *(int64_t *)(puVar42 + 0xc0), *(int64_t *)(puVar42 + 200), 
                  *(undefined8 *)(puVar42 + 0xd0), *(int64_t *)(puVar42 + 0xd8), *(undefined8 *)(puVar42 + 0xe0), 
                  *(int64_t *)(puVar42 + 0xe8));
    piVar60 = *(int64_t **)(puVar42 + 0x60);
    *(undefined8 *)(puVar42 + -8) = 0x1800ba48e;
    func_0x0001800bbb60(piVar60, auStack_120);
    *(undefined8 *)(puVar42 + -8) = 0x1800ba49a;
    func_0x0001800bbc30(piVar60, auStack_120);
    if (0 < *(int32_t *)((int64_t)piVar60 + 0xc)) {
        *(int32_t *)(*piVar60 + 0x270) = *(int32_t *)((int64_t)ppiVar46 + 0xc) + 1;
    }
    iVar44 = *piVar60;
    arg2 = *(int64_t *)(iVar44 + 0x30) - *(int64_t *)(iVar44 + 0x28) >> 2;
    *(undefined8 *)(puVar42 + -8) = 0x1800ba4d7;
    func_0x0001800d31a0((int64_t *)(iVar44 + 0x28), &stack0xfffffffffffffe48);
    *(undefined8 *)(puVar42 + -8) = 0x1800ba4e7;
    func_0x0001800d31a0(iVar44 + 0x40, iVar44 + 0x270);
    iVar44 = **(int64_t **)(puVar42 + 0x60);
    *(undefined8 *)(puVar42 + -8) = 0x1800ba510;
    func_0x0001800d31a0(iVar44 + 0x28, &stack0xfffffffffffffe48);
    *(undefined8 *)(puVar42 + -8) = 0x1800ba520;
    func_0x0001800d31a0(iVar44 + 0x40, iVar44 + 0x270);
    iVar44 = **(int64_t **)(puVar42 + 0x60);
    iVar48 = *(int64_t *)(iVar44 + 0x30);
    ppiVar55 = *(int64_t ***)(iVar44 + 0x28);
    *(undefined8 *)(puVar42 + -8) = 0x1800ba53b;
    cVar10 = func_0x0001800cfeb0(iVar44, iVar28 - (int64_t)piVar50 >> 2, arg2);
    if (cVar10 != '\0') {
        puVar58 = *(undefined8 **)(puVar42 + 0x60);
        uVar59 = *puVar58;
        *(undefined8 *)(puVar42 + -8) = 0x1800ba556;
        cVar10 = func_0x0001800cfeb0(uVar59, arg2, iVar29 - iVar40 >> 2);
        if (cVar10 != '\0') {
            iVar54 = iVar54 - (int64_t)puStack_108 >> 4;
            *(int64_t *)(puVar42 + 0x20) = arg2;
            *(undefined8 *)(puVar42 + -8) = 0x1800ba583;
            func_0x0001800bbdb0(puVar58, ppiVar46, iVar54, iVar48 - (int64_t)ppiVar55 >> 2);
            *(undefined8 *)(puVar42 + -8) = 0x1800ba592;
            func_0x0001800bfcc0(puVar58 + 0xce, iVar54);
            puVar58[0xd2] = puVar58[0xd2] + -0x18;
            *(undefined4 *)((int64_t)puVar58 + 0x60c) = *(undefined4 *)(puVar42 + 0x70);
            goto code_r0x0001800bb7ba;
        }
    }
    *(undefined8 *)(puVar42 + -8) = 0x1800bb970;
    func_0x0001800acea0((int64_t)ppiVar46 + 0xc, 0x18063f7f0);
code_r0x0001800bb971:
    *(undefined8 *)(puVar42 + -8) = 0x1800bb976;
    func_0x000180010010();
code_r0x0001800bb977:
    *(undefined8 *)(puVar42 + -8) = 0x1800bb993;
    func_0x0001800acea0((int64_t)ppiVar46 + 0xc, 0x18063fbc0, 1, 0xff);
code_r0x0001800bb994:
    *(undefined8 *)(puVar42 + -8) = 0x1800bb9aa;
    func_0x0001800acea0((int64_t)ppiVar46 + 0xc, 0x18063fbc0);
code_r0x0001800bb9ab:
    piVar60 = *(int64_t **)arg2;
    *(undefined8 *)(puVar42 + -8) = 0x1800bb9be;
    func_0x0001800acea0(piVar60 + 1, 0x18063f5a0);
code_r0x0001800bb9bf:
    piVar60 = ppiVar55[5];
    *(undefined8 *)(puVar42 + -8) = 0x1800bb9d3;
    func_0x0001800acea0(piVar60 + 1, 0x18063f5a0);
code_r0x0001800bb9d4:
    *(undefined8 *)(puVar42 + -8) = 0x1800bb9d9;
    func_0x000180010010();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
code_r0x0001800bb84f:
    iVar15 = *(int32_t *)((int64_t)puStack_108 + 0xc);
    piVar60 = *ppiVar46;
    *(undefined8 *)(puVar43 + -8) = 0x1800bb86d;
    func_0x0001800acea0(arg2 + 0xc, 0x18063fb00, piVar60, iVar15 + 1);
code_r0x0001800bb86e:
    *(undefined8 *)(puVar43 + -8) = 0x1800bb882;
    func_0x0001800acea0((int64_t)ppiVar32 + 0xc, 0x18063f7f0);
    puVar42 = puVar43;
code_r0x0001800bb883:
    *(undefined8 *)(puVar42 + -8) = 0x1800bb893;
    func_0x0001800acea0((int64_t)ppiVar55 + 0xc, 0x18063fa18);
code_r0x0001800bb894:
    *(undefined8 *)(puVar42 + -8) = 0x1800bb8aa;
    func_0x0001800acea0((int64_t)ppiVar55 + 0xc, 0x18063fbc0);
code_r0x0001800bb8ab:
    *(undefined8 *)(puVar42 + -8) = 0x1800bb8c1;
    func_0x0001800acea0((int64_t)ppiVar45 + 0xc, 0x18063fbc0);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800bba40
// Address: 0x1800bba40
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bba40(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    code *pcVar1;
    int32_t iVar2;
    undefined *puVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    var_10h = arg2;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3) < 200) {
        fcn.1800bf890((int64_t *)(arg1 + 0x640), &var_10h);
        puVar3 = (undefined *)fcn.1800c0050(arg1 + 0x88, &var_10h);
        *puVar3 = (undefined)placeholder_2;
        puVar3[1] = 1;
        iVar4 = (int32_t)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
        *(int32_t *)(puVar3 + 4) = iVar4;
        iVar2 = (int32_t)arg4;
        if ((int32_t)arg4 == -1) {
            iVar2 = iVar4;
        }
        *(int32_t *)(puVar3 + 8) = iVar2;
        return;
    }
    fcn.1800acea0(arg2 + 8, 0x18063fb70, *(undefined8 *)arg2, 200);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800bbae0
// Address: 0x1800bbae0
// Size: 114 bytes
// ============================================================
undefined fcn.1800bbae0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    char *pcVar3;
    uint64_t uVar4;
    
    iVar1 = *(int64_t *)(arg1 + 0x640);
    uVar4 = *(int64_t *)(arg1 + 0x648) - iVar1 >> 3;
    if ((uint64_t)arg2 < uVar4) {
        do {
            iVar2 = func_0x0001800ac770(arg1 + 0x88, iVar1 + arg2 * 8);
            pcVar3 = (char *)(iVar2 + 10);
            if (iVar2 == 0) {
                pcVar3 = (char *)0x2;
            }
            if (*pcVar3 != '\0') {
                return 1;
            }
            arg2 = arg2 + 1;
        } while ((uint64_t)arg2 < uVar4);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800bbb60
// Address: 0x1800bbb60
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bbb60(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t iVar1;
    bool bVar2;
    int64_t iVar3;
    uint8_t *puVar4;
    uint64_t uVar5;
    uint8_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x640);
    bVar2 = false;
    uVar5 = *(int64_t *)(arg1 + 0x648) - iVar1 >> 3;
    uVar6 = 0xff;
    if ((uint64_t)arg2 < uVar5) {
        do {
            iVar3 = func_0x0001800ac770(arg1 + 0x88, iVar1 + arg2 * 8);
            puVar4 = (uint8_t *)(iVar3 + 8);
            if (iVar3 == 0) {
                puVar4 = (uint8_t *)0x0;
            }
            if (puVar4[2] != 0) {
                bVar2 = true;
                if (*puVar4 < uVar6) {
                    uVar6 = *puVar4;
                }
            }
            arg2 = arg2 + 1;
        } while ((uint64_t)arg2 < uVar5);
        if (bVar2) {
            arg1 = *(int64_t *)arg1;
            var_8h._0_4_ = (uint32_t)uVar6 << 8 | 0xb;
            func_0x0001800d31a0(arg1 + 0x28, &var_8h);
            func_0x0001800d31a0(arg1 + 0x40, arg1 + 0x270);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800bbb9a
// Address: 0x1800bbb9a
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bbb60(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t iVar1;
    bool bVar2;
    int64_t iVar3;
    uint8_t *puVar4;
    uint64_t uVar5;
    uint8_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x640);
    bVar2 = false;
    uVar5 = *(int64_t *)(arg1 + 0x648) - iVar1 >> 3;
    uVar6 = 0xff;
    if ((uint64_t)arg2 < uVar5) {
        do {
            iVar3 = func_0x0001800ac770(arg1 + 0x88, iVar1 + arg2 * 8);
            puVar4 = (uint8_t *)(iVar3 + 8);
            if (iVar3 == 0) {
                puVar4 = (uint8_t *)0x0;
            }
            if (puVar4[2] != 0) {
                bVar2 = true;
                if (*puVar4 < uVar6) {
                    uVar6 = *puVar4;
                }
            }
            arg2 = arg2 + 1;
        } while ((uint64_t)arg2 < uVar5);
        if (bVar2) {
            arg1 = *(int64_t *)arg1;
            var_8h._0_4_ = (uint32_t)uVar6 << 8 | 0xb;
            func_0x0001800d31a0(arg1 + 0x28, &var_8h);
            func_0x0001800d31a0(arg1 + 0x40, arg1 + 0x270);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800bbbe7
// Address: 0x1800bbbe7
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bbb60(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t iVar1;
    bool bVar2;
    int64_t iVar3;
    uint8_t *puVar4;
    uint64_t uVar5;
    uint8_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x640);
    bVar2 = false;
    uVar5 = *(int64_t *)(arg1 + 0x648) - iVar1 >> 3;
    uVar6 = 0xff;
    if ((uint64_t)arg2 < uVar5) {
        do {
            iVar3 = func_0x0001800ac770(arg1 + 0x88, iVar1 + arg2 * 8);
            puVar4 = (uint8_t *)(iVar3 + 8);
            if (iVar3 == 0) {
                puVar4 = (uint8_t *)0x0;
            }
            if (puVar4[2] != 0) {
                bVar2 = true;
                if (*puVar4 < uVar6) {
                    uVar6 = *puVar4;
                }
            }
            arg2 = arg2 + 1;
        } while ((uint64_t)arg2 < uVar5);
        if (bVar2) {
            arg1 = *(int64_t *)arg1;
            var_8h._0_4_ = (uint32_t)uVar6 << 8 | 0xb;
            func_0x0001800d31a0(arg1 + 0x28, &var_8h);
            func_0x0001800d31a0(arg1 + 0x40, arg1 + 0x270);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800bbc30
// Address: 0x1800bbc30
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800bbc30(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined4 uVar12;
    undefined4 *puVar13;
    undefined *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar1 = (int64_t *)(arg1 + 0x640);
    iVar5 = *piVar1;
    uVar8 = arg2;
    if ((uint64_t)arg2 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - iVar5 >> 3)) {
        do {
            iVar5 = func_0x0001800ac770(arg1 + 0x88, iVar5 + uVar8 * 8);
            puVar14 = (undefined *)(iVar5 + 8);
            if (iVar5 == 0) {
                puVar14 = (undefined *)0x0;
            }
            puVar14[1] = 0;
            if (1 < *(int32_t *)(arg1 + 0xc)) {
                iVar5 = *(int64_t *)arg1;
                iVar2 = **(int64_t **)(*piVar1 + uVar8 * 8);
                var_30h = func_0x000180498cd0(iVar2);
                var_48h._0_4_ = (undefined4)(*(int64_t *)(iVar5 + 0x30) - *(int64_t *)(iVar5 + 0x28) >> 2);
                var_38h = iVar2;
                func_0x0001800d05e0(iVar5, &var_38h, *puVar14, *(undefined4 *)(puVar14 + 4));
            }
            if ((0 < *(int32_t *)(arg1 + 0x10)) && (*(uint64_t *)(arg1 + 0x618) <= uVar8)) {
                iVar5 = *(int64_t *)arg1;
                uVar12 = 0xf;
                iVar2 = *(int64_t *)(iVar5 + 0x30);
                iVar3 = *(int64_t *)(iVar5 + 0x28);
                iVar6 = func_0x0001800ac7f0(arg1 + 0x218);
                puVar13 = (undefined4 *)(iVar6 + 8);
                if (iVar6 == 0) {
                    puVar13 = (undefined4 *)0x0;
                }
                if (puVar13 != (undefined4 *)0x0) {
                    uVar12 = *puVar13;
                }
                var_48h._0_4_ = (undefined4)(iVar2 - iVar3 >> 2);
                func_0x0001800d00e0(iVar5, uVar12, *puVar14, *(undefined4 *)(puVar14 + 8));
            }
            iVar5 = *piVar1;
            uVar8 = uVar8 + 1;
        } while (uVar8 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - iVar5 >> 3));
    }
    piVar9 = &var_48h;
    piVar10 = &var_48h;
    iVar5 = *(int64_t *)(arg1 + 0x648);
    iVar2 = *piVar1;
    uVar8 = iVar5 - iVar2 >> 3;
    if ((uint64_t)arg2 < uVar8) {
        *(int64_t *)(arg1 + 0x648) = iVar2 + arg2 * 8;
        return;
    }
    if (uVar8 < (uint64_t)arg2) {
        uVar7 = *(int64_t *)(arg1 + 0x650) - iVar2 >> 3;
        if ((uint64_t)arg2 <= uVar7) {
            iVar2 = (arg2 - uVar8) * 8;
            func_0x0001804986e0(iVar5, 0, iVar2);
            *(int64_t *)(arg1 + 0x648) = iVar2 + iVar5;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar7 >> 1) < uVar7) ||
           ((uVar7 = uVar7 + (uVar7 >> 1), uVar11 = arg2, (uint64_t)arg2 <= uVar7 &&
            (uVar11 = uVar7, 0x1fffffffffffffff < uVar7)))) {
code_r0x0001800c0fb8:
            fcn.180004720();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar7 = uVar11 * 8;
        if (uVar7 == 0) {
            uVar7 = 0;
            piVar10 = &var_48h;
        } else if (uVar7 < 0x1000) {
            uVar7 = fcn.180459890();
        } else {
            if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c0fb8;
            iVar5 = fcn.180459890(uVar7 + 0x27);
            if (iVar5 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar5 = (*pcVar4)(5);
                piVar9 = &var_40h;
            }
            uVar7 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar7 - 8) = iVar5;
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f5c;
        func_0x0001804986e0(uVar7 + uVar8 * 8, 0, (arg2 - uVar8) * 8);
        iVar5 = *piVar1;
        iVar2 = *(int64_t *)(arg1 + 0x648);
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f6e;
        fcn.180498030(uVar7, iVar5, iVar2 - iVar5);
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f7f;
        func_0x0001800c2120(piVar1, uVar7, arg2, uVar11);
    }
    return;
}

// ============================================================
// Function: FUN_1800bbc65
// Address: 0x1800bbc65
// Size: 298 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800bbc30(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined4 uVar12;
    undefined4 *puVar13;
    undefined *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar1 = (int64_t *)(arg1 + 0x640);
    iVar5 = *piVar1;
    uVar8 = arg2;
    if ((uint64_t)arg2 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - iVar5 >> 3)) {
        do {
            iVar5 = func_0x0001800ac770(arg1 + 0x88, iVar5 + uVar8 * 8);
            puVar14 = (undefined *)(iVar5 + 8);
            if (iVar5 == 0) {
                puVar14 = (undefined *)0x0;
            }
            puVar14[1] = 0;
            if (1 < *(int32_t *)(arg1 + 0xc)) {
                iVar5 = *(int64_t *)arg1;
                iVar2 = **(int64_t **)(*piVar1 + uVar8 * 8);
                var_30h = func_0x000180498cd0(iVar2);
                var_48h._0_4_ = (undefined4)(*(int64_t *)(iVar5 + 0x30) - *(int64_t *)(iVar5 + 0x28) >> 2);
                var_38h = iVar2;
                func_0x0001800d05e0(iVar5, &var_38h, *puVar14, *(undefined4 *)(puVar14 + 4));
            }
            if ((0 < *(int32_t *)(arg1 + 0x10)) && (*(uint64_t *)(arg1 + 0x618) <= uVar8)) {
                iVar5 = *(int64_t *)arg1;
                uVar12 = 0xf;
                iVar2 = *(int64_t *)(iVar5 + 0x30);
                iVar3 = *(int64_t *)(iVar5 + 0x28);
                iVar6 = func_0x0001800ac7f0(arg1 + 0x218);
                puVar13 = (undefined4 *)(iVar6 + 8);
                if (iVar6 == 0) {
                    puVar13 = (undefined4 *)0x0;
                }
                if (puVar13 != (undefined4 *)0x0) {
                    uVar12 = *puVar13;
                }
                var_48h._0_4_ = (undefined4)(iVar2 - iVar3 >> 2);
                func_0x0001800d00e0(iVar5, uVar12, *puVar14, *(undefined4 *)(puVar14 + 8));
            }
            iVar5 = *piVar1;
            uVar8 = uVar8 + 1;
        } while (uVar8 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - iVar5 >> 3));
    }
    piVar9 = &var_48h;
    piVar10 = &var_48h;
    iVar5 = *(int64_t *)(arg1 + 0x648);
    iVar2 = *piVar1;
    uVar8 = iVar5 - iVar2 >> 3;
    if ((uint64_t)arg2 < uVar8) {
        *(int64_t *)(arg1 + 0x648) = iVar2 + arg2 * 8;
        return;
    }
    if (uVar8 < (uint64_t)arg2) {
        uVar7 = *(int64_t *)(arg1 + 0x650) - iVar2 >> 3;
        if ((uint64_t)arg2 <= uVar7) {
            iVar2 = (arg2 - uVar8) * 8;
            func_0x0001804986e0(iVar5, 0, iVar2);
            *(int64_t *)(arg1 + 0x648) = iVar2 + iVar5;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar7 >> 1) < uVar7) ||
           ((uVar7 = uVar7 + (uVar7 >> 1), uVar11 = arg2, (uint64_t)arg2 <= uVar7 &&
            (uVar11 = uVar7, 0x1fffffffffffffff < uVar7)))) {
code_r0x0001800c0fb8:
            fcn.180004720();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar7 = uVar11 * 8;
        if (uVar7 == 0) {
            uVar7 = 0;
            piVar10 = &var_48h;
        } else if (uVar7 < 0x1000) {
            uVar7 = fcn.180459890();
        } else {
            if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c0fb8;
            iVar5 = fcn.180459890(uVar7 + 0x27);
            if (iVar5 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar5 = (*pcVar4)(5);
                piVar9 = &var_40h;
            }
            uVar7 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar7 - 8) = iVar5;
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f5c;
        func_0x0001804986e0(uVar7 + uVar8 * 8, 0, (arg2 - uVar8) * 8);
        iVar5 = *piVar1;
        iVar2 = *(int64_t *)(arg1 + 0x648);
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f6e;
        fcn.180498030(uVar7, iVar5, iVar2 - iVar5);
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f7f;
        func_0x0001800c2120(piVar1, uVar7, arg2, uVar11);
    }
    return;
}

// ============================================================
// Function: FUN_1800bbd8f
// Address: 0x1800bbd8f
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800bbc30(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined4 uVar12;
    undefined4 *puVar13;
    undefined *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar1 = (int64_t *)(arg1 + 0x640);
    iVar5 = *piVar1;
    uVar8 = arg2;
    if ((uint64_t)arg2 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - iVar5 >> 3)) {
        do {
            iVar5 = func_0x0001800ac770(arg1 + 0x88, iVar5 + uVar8 * 8);
            puVar14 = (undefined *)(iVar5 + 8);
            if (iVar5 == 0) {
                puVar14 = (undefined *)0x0;
            }
            puVar14[1] = 0;
            if (1 < *(int32_t *)(arg1 + 0xc)) {
                iVar5 = *(int64_t *)arg1;
                iVar2 = **(int64_t **)(*piVar1 + uVar8 * 8);
                var_30h = func_0x000180498cd0(iVar2);
                var_48h._0_4_ = (undefined4)(*(int64_t *)(iVar5 + 0x30) - *(int64_t *)(iVar5 + 0x28) >> 2);
                var_38h = iVar2;
                func_0x0001800d05e0(iVar5, &var_38h, *puVar14, *(undefined4 *)(puVar14 + 4));
            }
            if ((0 < *(int32_t *)(arg1 + 0x10)) && (*(uint64_t *)(arg1 + 0x618) <= uVar8)) {
                iVar5 = *(int64_t *)arg1;
                uVar12 = 0xf;
                iVar2 = *(int64_t *)(iVar5 + 0x30);
                iVar3 = *(int64_t *)(iVar5 + 0x28);
                iVar6 = func_0x0001800ac7f0(arg1 + 0x218);
                puVar13 = (undefined4 *)(iVar6 + 8);
                if (iVar6 == 0) {
                    puVar13 = (undefined4 *)0x0;
                }
                if (puVar13 != (undefined4 *)0x0) {
                    uVar12 = *puVar13;
                }
                var_48h._0_4_ = (undefined4)(iVar2 - iVar3 >> 2);
                func_0x0001800d00e0(iVar5, uVar12, *puVar14, *(undefined4 *)(puVar14 + 8));
            }
            iVar5 = *piVar1;
            uVar8 = uVar8 + 1;
        } while (uVar8 < (uint64_t)(*(int64_t *)(arg1 + 0x648) - iVar5 >> 3));
    }
    piVar9 = &var_48h;
    piVar10 = &var_48h;
    iVar5 = *(int64_t *)(arg1 + 0x648);
    iVar2 = *piVar1;
    uVar8 = iVar5 - iVar2 >> 3;
    if ((uint64_t)arg2 < uVar8) {
        *(int64_t *)(arg1 + 0x648) = iVar2 + arg2 * 8;
        return;
    }
    if (uVar8 < (uint64_t)arg2) {
        uVar7 = *(int64_t *)(arg1 + 0x650) - iVar2 >> 3;
        if ((uint64_t)arg2 <= uVar7) {
            iVar2 = (arg2 - uVar8) * 8;
            func_0x0001804986e0(iVar5, 0, iVar2);
            *(int64_t *)(arg1 + 0x648) = iVar2 + iVar5;
            return;
        }
        if (0x1fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        if ((0x1fffffffffffffff - (uVar7 >> 1) < uVar7) ||
           ((uVar7 = uVar7 + (uVar7 >> 1), uVar11 = arg2, (uint64_t)arg2 <= uVar7 &&
            (uVar11 = uVar7, 0x1fffffffffffffff < uVar7)))) {
code_r0x0001800c0fb8:
            fcn.180004720();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar7 = uVar11 * 8;
        if (uVar7 == 0) {
            uVar7 = 0;
            piVar10 = &var_48h;
        } else if (uVar7 < 0x1000) {
            uVar7 = fcn.180459890();
        } else {
            if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c0fb8;
            iVar5 = fcn.180459890(uVar7 + 0x27);
            if (iVar5 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar5 = (*pcVar4)(5);
                piVar9 = &var_40h;
            }
            uVar7 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar7 - 8) = iVar5;
            piVar10 = piVar9;
        }
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f5c;
        func_0x0001804986e0(uVar7 + uVar8 * 8, 0, (arg2 - uVar8) * 8);
        iVar5 = *piVar1;
        iVar2 = *(int64_t *)(arg1 + 0x648);
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f6e;
        fcn.180498030(uVar7, iVar5, iVar2 - iVar5);
        *(undefined8 *)((int64_t)piVar10 + -8) = 0x1800c0f7f;
        func_0x0001800c2120(piVar1, uVar7, arg2, uVar11);
    }
    return;
}

// ============================================================
// Function: FUN_1800bbdb0
// Address: 0x1800bbdb0
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bbdb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    char cVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    iVar5 = *(int64_t *)(arg1 + 0x670);
    if ((uint64_t)arg3 < (uint64_t)(*(int64_t *)(arg1 + 0x678) - iVar5 >> 4)) {
        do {
            piVar4 = (int32_t *)(arg3 * 0x10 + iVar5);
            iVar1 = *piVar4;
            iVar5 = arg4;
            if (((iVar1 == 0) || (iVar5 = arg_28h, iVar1 == 1)) &&
               (cVar3 = func_0x0001800cfeb0(*(undefined8 *)arg1, *(undefined8 *)(piVar4 + 2), iVar5), cVar3 == '\0')) {
                fcn.1800acea0(arg2 + 0xc, 0x18063f7f0);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar5 = *(int64_t *)(arg1 + 0x670);
            arg3 = arg3 + 1;
        } while ((uint64_t)arg3 < (uint64_t)(*(int64_t *)(arg1 + 0x678) - iVar5 >> 4));
    }
    return;
}

// ============================================================
// Function: FUN_1800bbde0
// Address: 0x1800bbde0
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bbdb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    char cVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    iVar5 = *(int64_t *)(arg1 + 0x670);
    if ((uint64_t)arg3 < (uint64_t)(*(int64_t *)(arg1 + 0x678) - iVar5 >> 4)) {
        do {
            piVar4 = (int32_t *)(arg3 * 0x10 + iVar5);
            iVar1 = *piVar4;
            iVar5 = arg4;
            if (((iVar1 == 0) || (iVar5 = arg_28h, iVar1 == 1)) &&
               (cVar3 = func_0x0001800cfeb0(*(undefined8 *)arg1, *(undefined8 *)(piVar4 + 2), iVar5), cVar3 == '\0')) {
                fcn.1800acea0(arg2 + 0xc, 0x18063f7f0);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar5 = *(int64_t *)(arg1 + 0x670);
            arg3 = arg3 + 1;
        } while ((uint64_t)arg3 < (uint64_t)(*(int64_t *)(arg1 + 0x678) - iVar5 >> 4));
    }
    return;
}

// ============================================================
// Function: FUN_1800bbe3f
// Address: 0x1800bbe3f
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bbdb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    char cVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    iVar5 = *(int64_t *)(arg1 + 0x670);
    if ((uint64_t)arg3 < (uint64_t)(*(int64_t *)(arg1 + 0x678) - iVar5 >> 4)) {
        do {
            piVar4 = (int32_t *)(arg3 * 0x10 + iVar5);
            iVar1 = *piVar4;
            iVar5 = arg4;
            if (((iVar1 == 0) || (iVar5 = arg_28h, iVar1 == 1)) &&
               (cVar3 = func_0x0001800cfeb0(*(undefined8 *)arg1, *(undefined8 *)(piVar4 + 2), iVar5), cVar3 == '\0')) {
                fcn.1800acea0(arg2 + 0xc, 0x18063f7f0);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar5 = *(int64_t *)(arg1 + 0x670);
            arg3 = arg3 + 1;
        } while ((uint64_t)arg3 < (uint64_t)(*(int64_t *)(arg1 + 0x678) - iVar5 >> 4));
    }
    return;
}

// ============================================================
// Function: FUN_1800bbe49
// Address: 0x1800bbe49
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bbdb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    char cVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    iVar5 = *(int64_t *)(arg1 + 0x670);
    if ((uint64_t)arg3 < (uint64_t)(*(int64_t *)(arg1 + 0x678) - iVar5 >> 4)) {
        do {
            piVar4 = (int32_t *)(arg3 * 0x10 + iVar5);
            iVar1 = *piVar4;
            iVar5 = arg4;
            if (((iVar1 == 0) || (iVar5 = arg_28h, iVar1 == 1)) &&
               (cVar3 = func_0x0001800cfeb0(*(undefined8 *)arg1, *(undefined8 *)(piVar4 + 2), iVar5), cVar3 == '\0')) {
                fcn.1800acea0(arg2 + 0xc, 0x18063f7f0);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar5 = *(int64_t *)(arg1 + 0x670);
            arg3 = arg3 + 1;
        } while ((uint64_t)arg3 < (uint64_t)(*(int64_t *)(arg1 + 0x678) - iVar5 >> 4));
    }
    return;
}

// ============================================================
// Function: FUN_1800bbe60
// Address: 0x1800bbe60
// Size: 85 bytes
// ============================================================
uint64_t fcn.1800bbe60(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint32_t uVar4;
    undefined8 in_R8;
    uint32_t uVar5;
    
    uVar1 = *(uint32_t *)(arg1 + 0x60c);
    uVar5 = uVar1 + (int32_t)in_R8;
    if (uVar5 < 0x100) {
        *(uint32_t *)(arg1 + 0x60c) = uVar5;
        uVar4 = *(uint32_t *)(arg1 + 0x610);
        if (*(uint32_t *)(arg1 + 0x610) < uVar5) {
            uVar4 = uVar5;
        }
        *(uint32_t *)(arg1 + 0x610) = uVar4;
        return (uint64_t)uVar1 & 0xff;
    }
    fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, in_R8, 0xff);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800bbec0
// Address: 0x1800bbec0
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bbec0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(int64_t *)(arg1 + 0x250) != 0) && (arg2 != *(int64_t *)(arg1 + 600))) {
        uVar6 = *(int64_t *)(arg1 + 0x248) - 1;
        uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar4 = 0;
        do {
            uVar2 = uVar2 & uVar6;
            piVar5 = (int64_t *)(uVar2 * 0x10 + *(int64_t *)(arg1 + 0x240));
            if (*piVar5 == arg2) {
                piVar3 = piVar5 + 1;
                if (piVar5 == (int64_t *)0x0) {
                    piVar3 = (int64_t *)0x0;
                }
                if (piVar3 == (int64_t *)0x0) {
                    return;
                }
                if (*(int32_t *)piVar3 == (int32_t)arg4) {
                    return;
                }
                arg1 = *(int64_t *)arg1;
                iVar1 = (int32_t)(*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x28) >> 2);
                func_0x0001800d00e0(arg1, *(int32_t *)piVar3, arg3 & 0xff, iVar1 - (int32_t)arg_28h, iVar1);
                return;
            }
            if (*piVar5 == *(int64_t *)(arg1 + 600)) {
                return;
            }
            uVar2 = uVar2 + 1 + uVar4;
            uVar4 = uVar4 + 1;
        } while (uVar4 <= uVar6);
    }
    return;
}

// ============================================================
// Function: FUN_1800bbee9
// Address: 0x1800bbee9
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bbec0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(int64_t *)(arg1 + 0x250) != 0) && (arg2 != *(int64_t *)(arg1 + 600))) {
        uVar6 = *(int64_t *)(arg1 + 0x248) - 1;
        uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar4 = 0;
        do {
            uVar2 = uVar2 & uVar6;
            piVar5 = (int64_t *)(uVar2 * 0x10 + *(int64_t *)(arg1 + 0x240));
            if (*piVar5 == arg2) {
                piVar3 = piVar5 + 1;
                if (piVar5 == (int64_t *)0x0) {
                    piVar3 = (int64_t *)0x0;
                }
                if (piVar3 == (int64_t *)0x0) {
                    return;
                }
                if (*(int32_t *)piVar3 == (int32_t)arg4) {
                    return;
                }
                arg1 = *(int64_t *)arg1;
                iVar1 = (int32_t)(*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x28) >> 2);
                func_0x0001800d00e0(arg1, *(int32_t *)piVar3, arg3 & 0xff, iVar1 - (int32_t)arg_28h, iVar1);
                return;
            }
            if (*piVar5 == *(int64_t *)(arg1 + 600)) {
                return;
            }
            uVar2 = uVar2 + 1 + uVar4;
            uVar4 = uVar4 + 1;
        } while (uVar4 <= uVar6);
    }
    return;
}

// ============================================================
// Function: FUN_1800bbf9b
// Address: 0x1800bbf9b
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800bbec0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(int64_t *)(arg1 + 0x250) != 0) && (arg2 != *(int64_t *)(arg1 + 600))) {
        uVar6 = *(int64_t *)(arg1 + 0x248) - 1;
        uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar4 = 0;
        do {
            uVar2 = uVar2 & uVar6;
            piVar5 = (int64_t *)(uVar2 * 0x10 + *(int64_t *)(arg1 + 0x240));
            if (*piVar5 == arg2) {
                piVar3 = piVar5 + 1;
                if (piVar5 == (int64_t *)0x0) {
                    piVar3 = (int64_t *)0x0;
                }
                if (piVar3 == (int64_t *)0x0) {
                    return;
                }
                if (*(int32_t *)piVar3 == (int32_t)arg4) {
                    return;
                }
                arg1 = *(int64_t *)arg1;
                iVar1 = (int32_t)(*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x28) >> 2);
                func_0x0001800d00e0(arg1, *(int32_t *)piVar3, arg3 & 0xff, iVar1 - (int32_t)arg_28h, iVar1);
                return;
            }
            if (*piVar5 == *(int64_t *)(arg1 + 600)) {
                return;
            }
            uVar2 = uVar2 + 1 + uVar4;
            uVar4 = uVar4 + 1;
        } while (uVar4 <= uVar6);
    }
    return;
}

// ============================================================
// Function: FUN_1800bbfb0
// Address: 0x1800bbfb0
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800bbfb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(char *)0x180777f78 == '\0') {
        iVar1 = *(int32_t *)(arg2 + 8);
        iVar2 = 0;
        if (iVar1 == *(int32_t *)0x180782728) {
            iVar2 = arg2;
        }
        if (iVar2 != 0) {
            return;
        }
        iVar2 = 0;
        if (iVar1 == *(int32_t *)0x1807826c0) {
            iVar2 = arg2;
        }
        if (iVar2 == 0) {
            if (iVar1 == *(int32_t *)0x180782708) {
                iVar2 = arg2;
            }
            if (iVar2 == 0) goto code_r0x0001800bc020;
        }
        iVar2 = func_0x0001800b7b80(iVar1, *(undefined8 *)(iVar2 + 0x20));
    } else {
        iVar2 = func_0x0001800beb60(arg2);
    }
    if (iVar2 != 0) {
        return;
    }
code_r0x0001800bc020:
    fcn.1800bbec0(arg1, arg2, arg3 & 0xffffffff, arg4 & 0xffffffff, CONCAT44(var_18h._4_4_, (undefined4)arg_28h), 
                  unaff_RBX);
    return;
}

// ============================================================
// Function: FUN_1800bc0c0
// Address: 0x1800bc0c0
// Size: 485 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

uint64_t fcn.1800bc0c0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    int64_t **ppiVar3;
    code *pcVar4;
    uint8_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    int64_t *piVar9;
    undefined *puVar10;
    undefined *puVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    puVar10 = auStack_48;
    puVar11 = auStack_48;
    (**(code **)**(undefined8 **)(arg2 + 0x90))(*(undefined8 **)(arg2 + 0x90), arg1);
    piVar13 = *(int64_t **)(arg2 + 0x58);
    uVar6 = *(uint64_t *)(arg2 + 0x60);
    piVar9 = piVar13 + uVar6;
    if (piVar13 != piVar9) {
        uVar5 = *(uint8_t *)(arg1 + 0x10);
        do {
            iVar12 = *piVar13;
            piVar13 = piVar13 + 1;
            uVar5 = *(int64_t *)(iVar12 + 0x38) != 0 | uVar5;
            uVar6 = CONCAT71((unkint7)((uint64_t)iVar12 >> 8), uVar5);
            *(uint8_t *)(arg1 + 0x10) = uVar5;
        } while (piVar13 != piVar9);
    }
    ppiVar3 = *(int64_t ***)(arg1 + 8);
    piVar9 = ppiVar3[1];
    if (piVar9 != ppiVar3[2]) {
        *piVar9 = arg2;
        ppiVar3[1] = ppiVar3[1] + 1;
code_r0x0001800bc241:
        if (*(char *)(arg1 + 0x11) == '\0') {
            puVar8 = *(uint64_t **)(arg2 + 0x20);
            uVar6 = *(uint64_t *)(arg2 + 0x28);
            puVar2 = puVar8 + uVar6;
            for (; puVar8 != puVar2; puVar8 = puVar8 + 1) {
                uVar6 = *puVar8;
                if (*(int32_t *)(uVar6 + 0x20) == 1) {
                    *(undefined *)(arg1 + 0x11) = 1;
                    break;
                }
            }
        }
        return uVar6 & 0xffffffffffffff00;
    }
    iVar12 = (int64_t)piVar9 - (int64_t)*ppiVar3 >> 3;
    if (iVar12 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        uVar6 = (*pcVar4)();
        return uVar6;
    }
    uVar6 = (int64_t)ppiVar3[2] - (int64_t)*ppiVar3 >> 3;
    if (uVar6 <= 0x1fffffffffffffff - (uVar6 >> 1)) {
        uVar1 = iVar12 + 1;
        uVar6 = uVar6 + (uVar6 >> 1);
        uVar15 = uVar1;
        if (uVar1 <= uVar6) {
            uVar15 = uVar6;
        }
        if (uVar15 < 0x2000000000000000) {
            uVar6 = uVar15 * 8;
            if (uVar6 == 0) {
                uVar6 = 0;
                puVar11 = auStack_48;
            } else if (uVar6 < 0x1000) {
                uVar6 = fcn.180459890();
            } else {
                if (uVar6 + 0x27 <= uVar6) goto code_r0x0001800bc29f;
                iVar14 = fcn.180459890(uVar6 + 0x27);
                if (iVar14 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar14 = (*pcVar4)(5);
                    puVar10 = auStack_40;
                }
                uVar6 = iVar14 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar14;
                puVar11 = puVar10;
            }
            *(int64_t *)(uVar6 + iVar12 * 8) = arg2;
            piVar13 = *ppiVar3;
            if (piVar9 == ppiVar3[1]) {
                iVar14 = (int64_t)ppiVar3[1] - (int64_t)piVar13;
                uVar7 = uVar6;
                piVar9 = piVar13;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800bc219;
                fcn.180498030(uVar6, piVar13, (int64_t)piVar9 - (int64_t)piVar13);
                iVar14 = (int64_t)ppiVar3[1] - (int64_t)piVar9;
                uVar7 = uVar6 + (iVar12 + 1) * 8;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800bc230;
            fcn.180498030(uVar7, piVar9, iVar14);
            *(undefined8 *)(puVar11 + -8) = 0x1800bc241;
            uVar6 = func_0x0001800c2120(ppiVar3, uVar6, uVar1, uVar15);
            goto code_r0x0001800bc241;
        }
    }
code_r0x0001800bc29f:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    uVar6 = (*pcVar4)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800bc2b0
// Address: 0x1800bc2b0
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bc2b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    
    if (((*(int64_t *)(arg1 + 0x10) == 0) && (*(int64_t *)(arg1 + 0x28) != 0)) && (arg2 != *(int64_t *)(arg1 + 0x30))) {
        uVar4 = *(int64_t *)(arg1 + 0x20) - 1;
        uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar3 = 0;
        while( true ) {
            uVar2 = uVar2 & uVar4;
            iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + uVar2 * 8);
            if (iVar1 == arg2) break;
            if (iVar1 == *(int64_t *)(arg1 + 0x30)) {
                return;
            }
            uVar2 = uVar2 + 1 + uVar3;
            uVar3 = uVar3 + 1;
            if (uVar4 < uVar3) {
                return;
            }
        }
        *(int64_t *)(arg1 + 0x10) = arg2;
    }
    return;
}

// ============================================================
// Function: FUN_1800bc2e2
// Address: 0x1800bc2e2
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bc2b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    
    if (((*(int64_t *)(arg1 + 0x10) == 0) && (*(int64_t *)(arg1 + 0x28) != 0)) && (arg2 != *(int64_t *)(arg1 + 0x30))) {
        uVar4 = *(int64_t *)(arg1 + 0x20) - 1;
        uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar3 = 0;
        while( true ) {
            uVar2 = uVar2 & uVar4;
            iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + uVar2 * 8);
            if (iVar1 == arg2) break;
            if (iVar1 == *(int64_t *)(arg1 + 0x30)) {
                return;
            }
            uVar2 = uVar2 + 1 + uVar3;
            uVar3 = uVar3 + 1;
            if (uVar4 < uVar3) {
                return;
            }
        }
        *(int64_t *)(arg1 + 0x10) = arg2;
    }
    return;
}

// ============================================================
// Function: FUN_1800bc31b
// Address: 0x1800bc31b
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bc2b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    
    if (((*(int64_t *)(arg1 + 0x10) == 0) && (*(int64_t *)(arg1 + 0x28) != 0)) && (arg2 != *(int64_t *)(arg1 + 0x30))) {
        uVar4 = *(int64_t *)(arg1 + 0x20) - 1;
        uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar3 = 0;
        while( true ) {
            uVar2 = uVar2 & uVar4;
            iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + uVar2 * 8);
            if (iVar1 == arg2) break;
            if (iVar1 == *(int64_t *)(arg1 + 0x30)) {
                return;
            }
            uVar2 = uVar2 + 1 + uVar3;
            uVar3 = uVar3 + 1;
            if (uVar4 < uVar3) {
                return;
            }
        }
        *(int64_t *)(arg1 + 0x10) = arg2;
    }
    return;
}

// ============================================================
// Function: FUN_1800bc323
// Address: 0x1800bc323
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800bc2b0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    
    if (((*(int64_t *)(arg1 + 0x10) == 0) && (*(int64_t *)(arg1 + 0x28) != 0)) && (arg2 != *(int64_t *)(arg1 + 0x30))) {
        uVar4 = *(int64_t *)(arg1 + 0x20) - 1;
        uVar2 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar3 = 0;
        while( true ) {
            uVar2 = uVar2 & uVar4;
            iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + uVar2 * 8);
            if (iVar1 == arg2) break;
            if (iVar1 == *(int64_t *)(arg1 + 0x30)) {
                return;
            }
            uVar2 = uVar2 + 1 + uVar3;
            uVar3 = uVar3 + 1;
            if (uVar4 < uVar3) {
                return;
            }
        }
        *(int64_t *)(arg1 + 0x10) = arg2;
    }
    return;
}

// ============================================================
// Function: FUN_1800bc330
// Address: 0x1800bc330
// Size: 26 bytes
// ============================================================
undefined fcn.1800bc330(int64_t arg1, int64_t arg2)
{
    if (*(char *)(arg2 + 0x28) == '\0') {
        fcn.1800bc2b0(arg1, *(int64_t *)(arg2 + 0x20));
    }
    return 0;
}

// ============================================================
// Function: FUN_1800bc350
// Address: 0x1800bc350
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800bc350(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    uint64_t **ppuVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if ((*(int64_t *)(iVar1 + 0x70) != 0) && (arg2 != *(int64_t *)(iVar1 + 0x78))) {
        uVar8 = *(int64_t *)(iVar1 + 0x68) - 1;
        uVar5 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar6 = 0;
        do {
            uVar5 = uVar5 & uVar8;
            piVar7 = (int64_t *)(uVar5 * 0x38 + *(int64_t *)(iVar1 + 0x60));
            if (*piVar7 == arg2) goto code_r0x0001800bc3c8;
            if (*piVar7 == *(int64_t *)(iVar1 + 0x78)) break;
            uVar5 = uVar5 + 1 + uVar6;
            uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar8);
    }
    piVar7 = (int64_t *)0x0;
code_r0x0001800bc3c8:
    ppuVar4 = (uint64_t **)(piVar7 + 2);
    if (piVar7 == (int64_t *)0x0) {
        ppuVar4 = (uint64_t **)0x8;
    }
    puVar2 = ppuVar4[1];
    puVar9 = *ppuVar4;
    do {
        if (puVar9 == puVar2) {
            return (uint64_t)ppuVar4 & 0xffffffffffffff00;
        }
        uVar5 = *puVar9;
        ppuVar4 = (uint64_t **)(*(int64_t *)(arg2 + 0x98) + -1);
        if ((((*(uint64_t ***)(uVar5 + 0x20) == ppuVar4) && (*(int64_t *)(arg1 + 0x10) == 0)) &&
            (*(int64_t *)(arg1 + 0x28) != 0)) && (uVar5 != *(uint64_t *)(arg1 + 0x30))) {
            uVar8 = *(int64_t *)(arg1 + 0x20) - 1;
            ppuVar4 = (uint64_t **)((uVar5 >> 5 ^ uVar5) >> 4 & uVar8);
            uVar6 = 0;
            do {
                uVar3 = *(uint64_t *)(*(int64_t *)(arg1 + 0x18) + (int64_t)ppuVar4 * 8);
                if (uVar3 == uVar5) {
                    *(uint64_t *)(arg1 + 0x10) = uVar5;
                    break;
                }
                if (uVar3 == *(uint64_t *)(arg1 + 0x30)) break;
                iVar1 = uVar6 + 1;
                uVar6 = uVar6 + 1;
                ppuVar4 = (uint64_t **)((int64_t)ppuVar4 + iVar1 & uVar8);
            } while (uVar6 <= uVar8);
        }
        puVar9 = puVar9 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800bc3e8
// Address: 0x1800bc3e8
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800bc350(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    uint64_t **ppuVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if ((*(int64_t *)(iVar1 + 0x70) != 0) && (arg2 != *(int64_t *)(iVar1 + 0x78))) {
        uVar8 = *(int64_t *)(iVar1 + 0x68) - 1;
        uVar5 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar6 = 0;
        do {
            uVar5 = uVar5 & uVar8;
            piVar7 = (int64_t *)(uVar5 * 0x38 + *(int64_t *)(iVar1 + 0x60));
            if (*piVar7 == arg2) goto code_r0x0001800bc3c8;
            if (*piVar7 == *(int64_t *)(iVar1 + 0x78)) break;
            uVar5 = uVar5 + 1 + uVar6;
            uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar8);
    }
    piVar7 = (int64_t *)0x0;
code_r0x0001800bc3c8:
    ppuVar4 = (uint64_t **)(piVar7 + 2);
    if (piVar7 == (int64_t *)0x0) {
        ppuVar4 = (uint64_t **)0x8;
    }
    puVar2 = ppuVar4[1];
    puVar9 = *ppuVar4;
    do {
        if (puVar9 == puVar2) {
            return (uint64_t)ppuVar4 & 0xffffffffffffff00;
        }
        uVar5 = *puVar9;
        ppuVar4 = (uint64_t **)(*(int64_t *)(arg2 + 0x98) + -1);
        if ((((*(uint64_t ***)(uVar5 + 0x20) == ppuVar4) && (*(int64_t *)(arg1 + 0x10) == 0)) &&
            (*(int64_t *)(arg1 + 0x28) != 0)) && (uVar5 != *(uint64_t *)(arg1 + 0x30))) {
            uVar8 = *(int64_t *)(arg1 + 0x20) - 1;
            ppuVar4 = (uint64_t **)((uVar5 >> 5 ^ uVar5) >> 4 & uVar8);
            uVar6 = 0;
            do {
                uVar3 = *(uint64_t *)(*(int64_t *)(arg1 + 0x18) + (int64_t)ppuVar4 * 8);
                if (uVar3 == uVar5) {
                    *(uint64_t *)(arg1 + 0x10) = uVar5;
                    break;
                }
                if (uVar3 == *(uint64_t *)(arg1 + 0x30)) break;
                iVar1 = uVar6 + 1;
                uVar6 = uVar6 + 1;
                ppuVar4 = (uint64_t **)((int64_t)ppuVar4 + iVar1 & uVar8);
            } while (uVar6 <= uVar8);
        }
        puVar9 = puVar9 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800bc473
// Address: 0x1800bc473
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800bc350(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    uint64_t **ppuVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if ((*(int64_t *)(iVar1 + 0x70) != 0) && (arg2 != *(int64_t *)(iVar1 + 0x78))) {
        uVar8 = *(int64_t *)(iVar1 + 0x68) - 1;
        uVar5 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar6 = 0;
        do {
            uVar5 = uVar5 & uVar8;
            piVar7 = (int64_t *)(uVar5 * 0x38 + *(int64_t *)(iVar1 + 0x60));
            if (*piVar7 == arg2) goto code_r0x0001800bc3c8;
            if (*piVar7 == *(int64_t *)(iVar1 + 0x78)) break;
            uVar5 = uVar5 + 1 + uVar6;
            uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar8);
    }
    piVar7 = (int64_t *)0x0;
code_r0x0001800bc3c8:
    ppuVar4 = (uint64_t **)(piVar7 + 2);
    if (piVar7 == (int64_t *)0x0) {
        ppuVar4 = (uint64_t **)0x8;
    }
    puVar2 = ppuVar4[1];
    puVar9 = *ppuVar4;
    do {
        if (puVar9 == puVar2) {
            return (uint64_t)ppuVar4 & 0xffffffffffffff00;
        }
        uVar5 = *puVar9;
        ppuVar4 = (uint64_t **)(*(int64_t *)(arg2 + 0x98) + -1);
        if ((((*(uint64_t ***)(uVar5 + 0x20) == ppuVar4) && (*(int64_t *)(arg1 + 0x10) == 0)) &&
            (*(int64_t *)(arg1 + 0x28) != 0)) && (uVar5 != *(uint64_t *)(arg1 + 0x30))) {
            uVar8 = *(int64_t *)(arg1 + 0x20) - 1;
            ppuVar4 = (uint64_t **)((uVar5 >> 5 ^ uVar5) >> 4 & uVar8);
            uVar6 = 0;
            do {
                uVar3 = *(uint64_t *)(*(int64_t *)(arg1 + 0x18) + (int64_t)ppuVar4 * 8);
                if (uVar3 == uVar5) {
                    *(uint64_t *)(arg1 + 0x10) = uVar5;
                    break;
                }
                if (uVar3 == *(uint64_t *)(arg1 + 0x30)) break;
                iVar1 = uVar6 + 1;
                uVar6 = uVar6 + 1;
                ppuVar4 = (uint64_t **)((int64_t)ppuVar4 + iVar1 & uVar8);
            } while (uVar6 <= uVar8);
        }
        puVar9 = puVar9 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800bc490
// Address: 0x1800bc490
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined fcn.1800bc490(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    if (*(char *)(arg2 + 0x28) != '\0') {
        cVar1 = fcn.1800b2930(*(undefined8 *)(arg1 + 8));
        if (cVar1 != '\0') {
            fcn.1800bf890(arg1 + 0x10, arg2 + 0x20);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800bc4d0
// Address: 0x1800bc4d0
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined fcn.1800bc4d0(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    char cVar2;
    int64_t var_8h;
    
    uVar1 = *(uint8_t *)(arg1 + 0x10);
    if (*(int64_t *)(arg2 + 0x30) == 1) {
        cVar2 = fcn.1800aeb90(*(undefined8 *)(arg1 + 8), **(undefined8 **)(arg2 + 0x28));
        if (cVar2 == '\0') {
            *(uint8_t *)(arg1 + 0x10) = uVar1 & 1;
            return 0;
        }
    }
    *(undefined *)(arg1 + 0x10) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1800bc570
// Address: 0x1800bc570
// Size: 32 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800bc57d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800bc582)

void fcn.1800bc570(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t iStack_38;
    undefined8 uStack_30;
    
    uStack_30 = 0x1800bc582;
    puVar5 = auStack_58;
    uVar4 = *(uint64_t *)(arg1 + 0x20);
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x30) - uVar4) >> 2) * 4;
        iStack_38 = arg1;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_58;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_50;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18002eea5;
        fcn.180459c3c(uVar4, uVar3);
        *(uint64_t *)(arg1 + 0x20) = 0;
        *(undefined8 *)(arg1 + 0x28) = 0;
        *(undefined8 *)(arg1 + 0x30) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bc590
// Address: 0x1800bc590
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800bc590(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t var_8h;
    
    *(undefined4 *)arg1 = *(undefined4 *)arg2;
    uVar1 = *(undefined8 *)(arg2 + 8);
    uVar2 = *(undefined8 *)(arg2 + 0x18);
    uVar3 = *(undefined8 *)(arg2 + 0x10);
    *(undefined8 *)(arg2 + 0x18) = 0;
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    *(undefined8 *)(arg1 + 8) = uVar1;
    *(undefined8 *)(arg1 + 0x10) = uVar3;
    *(undefined8 *)(arg1 + 0x18) = uVar2;
    uVar1 = *(undefined8 *)(arg2 + 0x20);
    uVar2 = *(undefined8 *)(arg2 + 0x30);
    uVar3 = *(undefined8 *)(arg2 + 0x28);
    *(undefined8 *)(arg2 + 0x30) = 0;
    *(undefined8 *)(arg2 + 0x28) = 0;
    *(undefined8 *)(arg2 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x20) = uVar1;
    *(undefined8 *)(arg1 + 0x28) = uVar3;
    *(undefined8 *)(arg1 + 0x30) = uVar2;
    return arg1;
}

// ============================================================
// Function: FUN_1800bc600
// Address: 0x1800bc600
// Size: 40 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800bc60d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800bc612)

void fcn.1800bc600(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t iStack_38;
    undefined8 uStack_30;
    
    uStack_30 = 0x1800bc612;
    puVar5 = auStack_58;
    uVar4 = *(uint64_t *)(arg1 + 0x30);
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x40) - uVar4) >> 3) * 8;
        iStack_38 = arg1;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_58;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_50;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18000ad35;
        fcn.180459c3c(uVar4, uVar3);
        *(uint64_t *)(arg1 + 0x30) = 0;
        *(undefined8 *)(arg1 + 0x38) = 0;
        *(undefined8 *)(arg1 + 0x40) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800bc630
// Address: 0x1800bc630
// Size: 43 bytes
// ============================================================
int64_t fcn.1800bc630(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x50);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800bc660
// Address: 0x1800bc660
// Size: 49 bytes
// ============================================================
void fcn.1800bc660(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
    }
    *(undefined8 *)arg1 = 0x18063f2c0;
    return;
}

// ============================================================
// Function: FUN_1800bc6a0
// Address: 0x1800bc6a0
// Size: 34 bytes
// ============================================================
void fcn.1800bc6a0(int64_t arg1)
{
    fcn.18000ace0(arg1 + 0x10);
    *(undefined8 *)arg1 = 0x18063f2c0;
    return;
}

// ============================================================
// Function: FUN_1800bc6d0
// Address: 0x1800bc6d0
// Size: 43 bytes
// ============================================================
int64_t fcn.1800bc6d0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800bc700
// Address: 0x1800bc700
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800bc700(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
    }
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x40);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800bc760
// Address: 0x1800bc760
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800bc760(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.18000ace0(arg1 + 0x10);
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

