// Chunk 163 - 50 functions

// ============================================================
// Function: FUN_18021b380
// Address: 0x18021b380
// Size: 129 bytes
// ============================================================
uint64_t fcn.18021b380(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    uint64_t *in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021b398;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3b1;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3c9;
        func_0x0001802295a0(0x1804be610, 0x10b, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3db;
        func_0x0001802296d0(0x20, 0xc0102, 0);
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5d9;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5f1;
        func_0x0001802295a0(0x1804be610, 0x10f, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b603;
        func_0x0001802296d0(0x20, 0x79, 0);
        return 0xfffffffe;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R15;
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            pcVar5 = *(code **)(in_RCX + 0x18);
code_r0x00018021b423:
            *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
            *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b447;
            uVar2 = (*pcVar5)();
            goto code_r0x00018021b476;
        }
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 != (code *)0x0) goto code_r0x00018021b423;
        if (0x7fffffff < in_R8) {
            return 0xffffffff;
        }
        *(undefined4 *)((int64_t)&var_10h + iVar4) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b476;
        uVar2 = (*pcVar1)();
code_r0x00018021b476:
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b48b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4a3;
        func_0x0001802295a0(0x1804be610, 0x119, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4b5;
        func_0x0001802296d0(0x20, 0x78, 0);
        return 0xffffffff;
    }
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x20);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4e9;
    uVar6 = (*pcVar1)(in_RCX, in_RDX, in_R8, in_R9);
    iVar3 = (int32_t)uVar6;
    if (0 < iVar3) {
        *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + *in_R9;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021b58d;
        pcVar5 = *(code **)(in_RCX + 0x18);
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 == (code *)0x0) {
            if (in_R8 < 0x80000000) {
                if ((iVar3 < 1) || (uVar6 = *in_R9, uVar6 < 0x80000000)) {
                    *(int32_t *)((int64_t)&var_10h + iVar4) = (int32_t)uVar6;
                    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b57b;
                    uVar6 = (*pcVar1)(in_RCX, 0x82, in_RDX, in_R8 & 0xffffffff);
                    if ((int32_t)uVar6 < 1) {
                        return uVar6;
                    }
                    *in_R9 = (int64_t)(int32_t)uVar6;
                    uVar6 = 1;
                } else {
                    uVar6 = 0xffffffff;
                }
            } else {
                uVar6 = 0xffffffff;
            }
            goto code_r0x00018021b58d;
        }
    }
    *(uint64_t **)((int64_t)&var_20h + iVar4) = in_R9;
    *(int32_t *)((int64_t)&var_18h + iVar4) = iVar3;
    *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b53f;
    uVar6 = (*pcVar5)(in_RCX, 0x82, in_RDX, in_R8);
code_r0x00018021b58d:
    if ((0 < (int32_t)uVar6) && (in_R8 < *in_R9)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5a3;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5bb;
        func_0x0001802295a0(0x1804be610, 0x128, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5cd;
        func_0x0001802296d0(0x20, 0xc0103, 0);
        uVar6 = 0xffffffff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18021b401
// Address: 0x18021b401
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18021b380(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    uint64_t *in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021b398;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3b1;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3c9;
        func_0x0001802295a0(0x1804be610, 0x10b, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3db;
        func_0x0001802296d0(0x20, 0xc0102, 0);
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5d9;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5f1;
        func_0x0001802295a0(0x1804be610, 0x10f, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b603;
        func_0x0001802296d0(0x20, 0x79, 0);
        return 0xfffffffe;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R15;
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            pcVar5 = *(code **)(in_RCX + 0x18);
code_r0x00018021b423:
            *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
            *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b447;
            uVar2 = (*pcVar5)();
            goto code_r0x00018021b476;
        }
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 != (code *)0x0) goto code_r0x00018021b423;
        if (0x7fffffff < in_R8) {
            return 0xffffffff;
        }
        *(undefined4 *)((int64_t)&var_10h + iVar4) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b476;
        uVar2 = (*pcVar1)();
code_r0x00018021b476:
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b48b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4a3;
        func_0x0001802295a0(0x1804be610, 0x119, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4b5;
        func_0x0001802296d0(0x20, 0x78, 0);
        return 0xffffffff;
    }
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x20);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4e9;
    uVar6 = (*pcVar1)(in_RCX, in_RDX, in_R8, in_R9);
    iVar3 = (int32_t)uVar6;
    if (0 < iVar3) {
        *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + *in_R9;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021b58d;
        pcVar5 = *(code **)(in_RCX + 0x18);
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 == (code *)0x0) {
            if (in_R8 < 0x80000000) {
                if ((iVar3 < 1) || (uVar6 = *in_R9, uVar6 < 0x80000000)) {
                    *(int32_t *)((int64_t)&var_10h + iVar4) = (int32_t)uVar6;
                    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b57b;
                    uVar6 = (*pcVar1)(in_RCX, 0x82, in_RDX, in_R8 & 0xffffffff);
                    if ((int32_t)uVar6 < 1) {
                        return uVar6;
                    }
                    *in_R9 = (int64_t)(int32_t)uVar6;
                    uVar6 = 1;
                } else {
                    uVar6 = 0xffffffff;
                }
            } else {
                uVar6 = 0xffffffff;
            }
            goto code_r0x00018021b58d;
        }
    }
    *(uint64_t **)((int64_t)&var_20h + iVar4) = in_R9;
    *(int32_t *)((int64_t)&var_18h + iVar4) = iVar3;
    *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b53f;
    uVar6 = (*pcVar5)(in_RCX, 0x82, in_RDX, in_R8);
code_r0x00018021b58d:
    if ((0 < (int32_t)uVar6) && (in_R8 < *in_R9)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5a3;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5bb;
        func_0x0001802295a0(0x1804be610, 0x128, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5cd;
        func_0x0001802296d0(0x20, 0xc0103, 0);
        uVar6 = 0xffffffff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18021b4bf
// Address: 0x18021b4bf
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18021b380(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    uint64_t *in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021b398;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3b1;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3c9;
        func_0x0001802295a0(0x1804be610, 0x10b, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3db;
        func_0x0001802296d0(0x20, 0xc0102, 0);
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5d9;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5f1;
        func_0x0001802295a0(0x1804be610, 0x10f, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b603;
        func_0x0001802296d0(0x20, 0x79, 0);
        return 0xfffffffe;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R15;
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            pcVar5 = *(code **)(in_RCX + 0x18);
code_r0x00018021b423:
            *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
            *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b447;
            uVar2 = (*pcVar5)();
            goto code_r0x00018021b476;
        }
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 != (code *)0x0) goto code_r0x00018021b423;
        if (0x7fffffff < in_R8) {
            return 0xffffffff;
        }
        *(undefined4 *)((int64_t)&var_10h + iVar4) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b476;
        uVar2 = (*pcVar1)();
code_r0x00018021b476:
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b48b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4a3;
        func_0x0001802295a0(0x1804be610, 0x119, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4b5;
        func_0x0001802296d0(0x20, 0x78, 0);
        return 0xffffffff;
    }
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x20);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4e9;
    uVar6 = (*pcVar1)(in_RCX, in_RDX, in_R8, in_R9);
    iVar3 = (int32_t)uVar6;
    if (0 < iVar3) {
        *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + *in_R9;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021b58d;
        pcVar5 = *(code **)(in_RCX + 0x18);
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 == (code *)0x0) {
            if (in_R8 < 0x80000000) {
                if ((iVar3 < 1) || (uVar6 = *in_R9, uVar6 < 0x80000000)) {
                    *(int32_t *)((int64_t)&var_10h + iVar4) = (int32_t)uVar6;
                    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b57b;
                    uVar6 = (*pcVar1)(in_RCX, 0x82, in_RDX, in_R8 & 0xffffffff);
                    if ((int32_t)uVar6 < 1) {
                        return uVar6;
                    }
                    *in_R9 = (int64_t)(int32_t)uVar6;
                    uVar6 = 1;
                } else {
                    uVar6 = 0xffffffff;
                }
            } else {
                uVar6 = 0xffffffff;
            }
            goto code_r0x00018021b58d;
        }
    }
    *(uint64_t **)((int64_t)&var_20h + iVar4) = in_R9;
    *(int32_t *)((int64_t)&var_18h + iVar4) = iVar3;
    *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b53f;
    uVar6 = (*pcVar5)(in_RCX, 0x82, in_RDX, in_R8);
code_r0x00018021b58d:
    if ((0 < (int32_t)uVar6) && (in_R8 < *in_R9)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5a3;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5bb;
        func_0x0001802295a0(0x1804be610, 0x128, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5cd;
        func_0x0001802296d0(0x20, 0xc0103, 0);
        uVar6 = 0xffffffff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18021b4d2
// Address: 0x18021b4d2
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18021b380(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    uint64_t *in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021b398;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3b1;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3c9;
        func_0x0001802295a0(0x1804be610, 0x10b, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3db;
        func_0x0001802296d0(0x20, 0xc0102, 0);
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5d9;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5f1;
        func_0x0001802295a0(0x1804be610, 0x10f, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b603;
        func_0x0001802296d0(0x20, 0x79, 0);
        return 0xfffffffe;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R15;
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            pcVar5 = *(code **)(in_RCX + 0x18);
code_r0x00018021b423:
            *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
            *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b447;
            uVar2 = (*pcVar5)();
            goto code_r0x00018021b476;
        }
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 != (code *)0x0) goto code_r0x00018021b423;
        if (0x7fffffff < in_R8) {
            return 0xffffffff;
        }
        *(undefined4 *)((int64_t)&var_10h + iVar4) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b476;
        uVar2 = (*pcVar1)();
code_r0x00018021b476:
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b48b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4a3;
        func_0x0001802295a0(0x1804be610, 0x119, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4b5;
        func_0x0001802296d0(0x20, 0x78, 0);
        return 0xffffffff;
    }
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x20);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4e9;
    uVar6 = (*pcVar1)(in_RCX, in_RDX, in_R8, in_R9);
    iVar3 = (int32_t)uVar6;
    if (0 < iVar3) {
        *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + *in_R9;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021b58d;
        pcVar5 = *(code **)(in_RCX + 0x18);
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 == (code *)0x0) {
            if (in_R8 < 0x80000000) {
                if ((iVar3 < 1) || (uVar6 = *in_R9, uVar6 < 0x80000000)) {
                    *(int32_t *)((int64_t)&var_10h + iVar4) = (int32_t)uVar6;
                    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b57b;
                    uVar6 = (*pcVar1)(in_RCX, 0x82, in_RDX, in_R8 & 0xffffffff);
                    if ((int32_t)uVar6 < 1) {
                        return uVar6;
                    }
                    *in_R9 = (int64_t)(int32_t)uVar6;
                    uVar6 = 1;
                } else {
                    uVar6 = 0xffffffff;
                }
            } else {
                uVar6 = 0xffffffff;
            }
            goto code_r0x00018021b58d;
        }
    }
    *(uint64_t **)((int64_t)&var_20h + iVar4) = in_R9;
    *(int32_t *)((int64_t)&var_18h + iVar4) = iVar3;
    *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b53f;
    uVar6 = (*pcVar5)(in_RCX, 0x82, in_RDX, in_R8);
code_r0x00018021b58d:
    if ((0 < (int32_t)uVar6) && (in_R8 < *in_R9)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5a3;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5bb;
        func_0x0001802295a0(0x1804be610, 0x128, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5cd;
        func_0x0001802296d0(0x20, 0xc0103, 0);
        uVar6 = 0xffffffff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18021b5d4
// Address: 0x18021b5d4
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18021b380(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    uint64_t *in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021b398;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3b1;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3c9;
        func_0x0001802295a0(0x1804be610, 0x10b, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b3db;
        func_0x0001802296d0(0x20, 0xc0102, 0);
        return 0xffffffff;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5d9;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5f1;
        func_0x0001802295a0(0x1804be610, 0x10f, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b603;
        func_0x0001802296d0(0x20, 0x79, 0);
        return 0xfffffffe;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R15;
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            pcVar5 = *(code **)(in_RCX + 0x18);
code_r0x00018021b423:
            *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
            *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b447;
            uVar2 = (*pcVar5)();
            goto code_r0x00018021b476;
        }
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 != (code *)0x0) goto code_r0x00018021b423;
        if (0x7fffffff < in_R8) {
            return 0xffffffff;
        }
        *(undefined4 *)((int64_t)&var_10h + iVar4) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b476;
        uVar2 = (*pcVar1)();
code_r0x00018021b476:
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b48b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4a3;
        func_0x0001802295a0(0x1804be610, 0x119, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4b5;
        func_0x0001802296d0(0x20, 0x78, 0);
        return 0xffffffff;
    }
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x20);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b4e9;
    uVar6 = (*pcVar1)(in_RCX, in_RDX, in_R8, in_R9);
    iVar3 = (int32_t)uVar6;
    if (0 < iVar3) {
        *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + *in_R9;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021b58d;
        pcVar5 = *(code **)(in_RCX + 0x18);
    } else {
        pcVar5 = *(code **)(in_RCX + 0x18);
        if (pcVar5 == (code *)0x0) {
            if (in_R8 < 0x80000000) {
                if ((iVar3 < 1) || (uVar6 = *in_R9, uVar6 < 0x80000000)) {
                    *(int32_t *)((int64_t)&var_10h + iVar4) = (int32_t)uVar6;
                    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b57b;
                    uVar6 = (*pcVar1)(in_RCX, 0x82, in_RDX, in_R8 & 0xffffffff);
                    if ((int32_t)uVar6 < 1) {
                        return uVar6;
                    }
                    *in_R9 = (int64_t)(int32_t)uVar6;
                    uVar6 = 1;
                } else {
                    uVar6 = 0xffffffff;
                }
            } else {
                uVar6 = 0xffffffff;
            }
            goto code_r0x00018021b58d;
        }
    }
    *(uint64_t **)((int64_t)&var_20h + iVar4) = in_R9;
    *(int32_t *)((int64_t)&var_18h + iVar4) = iVar3;
    *(undefined4 *)((int64_t)&var_10h + iVar4) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b53f;
    uVar6 = (*pcVar5)(in_RCX, 0x82, in_RDX, in_R8);
code_r0x00018021b58d:
    if ((0 < (int32_t)uVar6) && (in_R8 < *in_R9)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5a3;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5bb;
        func_0x0001802295a0(0x1804be610, 0x128, 0x1804be638);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021b5cd;
        func_0x0001802296d0(0x20, 0xc0103, 0);
        uVar6 = 0xffffffff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18021b610
// Address: 0x18021b610
// Size: 540 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18021b610(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    uint64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021b628;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_R9 != (uint64_t *)0x0) {
        *in_R9 = 0;
    }
    if (in_RCX == 0) {
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) == 0) || (*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x10) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b7ea;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b802;
        func_0x0001802295a0(0x1804be610, 0x156, 0x1804be648);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b814;
        func_0x0001802296d0(0x20, 0x79, 0);
        return 0xfffffffe;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            pcVar4 = *(code **)(in_RCX + 0x18);
code_r0x00018021b683:
            *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar3) = 1;
            *(undefined4 *)((int64_t)&var_10h + iVar3) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b6a7;
            uVar5 = (*pcVar4)();
            goto code_r0x00018021b6cd;
        }
    } else {
        pcVar4 = *(code **)(in_RCX + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x00018021b683;
        if (0x7fffffff < in_R8) {
            return 0xffffffff;
        }
        *(undefined4 *)((int64_t)&var_10h + iVar3) = 1;
        *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b6cd;
        uVar5 = (*pcVar1)();
code_r0x00018021b6cd:
        if ((int32_t)uVar5 < 1) {
            return uVar5;
        }
    }
    if (*(int32_t *)(in_RCX + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b6e0;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b6f8;
        func_0x0001802295a0(0x1804be610, 0x160, 0x1804be648);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b70a;
        func_0x0001802296d0(0x20, 0x78, 0);
        return 0xffffffff;
    }
    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b72d;
    uVar6 = (*pcVar1)(in_RCX, in_RDX, in_R8, (int64_t)&arg_48h + iVar3);
    uVar5 = *(uint64_t *)((int64_t)&arg_48h + iVar3);
    iVar2 = (int32_t)uVar6;
    if (0 < iVar2) {
        *(int64_t *)(in_RCX + 0x68) = *(int64_t *)(in_RCX + 0x68) + uVar5;
    }
    pcVar1 = *(code **)(in_RCX + 0x10);
    if (pcVar1 == (code *)0x0) {
        if (*(int64_t *)(in_RCX + 0x18) == 0) goto code_r0x00018021b786;
        pcVar4 = *(code **)(in_RCX + 0x18);
code_r0x00018021b758:
        *(int64_t *)((int64_t)&var_20h + iVar3) = (int64_t)&arg_48h + iVar3;
        *(int32_t *)((int64_t)&var_18h + iVar3) = iVar2;
        *(undefined4 *)((int64_t)&var_10h + iVar3) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b781;
        uVar6 = (*pcVar4)(in_RCX, 0x83, in_RDX, in_R8);
    } else {
        pcVar4 = *(code **)(in_RCX + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x00018021b758;
        if (0x7fffffff < in_R8) {
            uVar6 = 0xffffffff;
            goto code_r0x00018021b786;
        }
        if (0 < iVar2) {
            if (0x7fffffff < uVar5) {
                uVar6 = 0xffffffff;
                goto code_r0x00018021b786;
            }
            uVar6 = uVar5 & 0xffffffff;
        }
        *(int32_t *)((int64_t)&var_10h + iVar3) = (int32_t)uVar6;
        *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021b7d7;
        uVar6 = (*pcVar1)(in_RCX, 0x83, in_RDX, in_R8 & 0xffffffff);
        if (0 < (int32_t)uVar6) {
            uVar5 = (uint64_t)(int32_t)uVar6;
            uVar6 = 1;
            goto code_r0x00018021b786;
        }
    }
    uVar5 = *(uint64_t *)((int64_t)&arg_48h + iVar3);
code_r0x00018021b786:
    if (in_R9 != (uint64_t *)0x0) {
        *in_R9 = uVar5;
        return uVar6;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18021b830
// Address: 0x18021b830
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021b830(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b840;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b864;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b875;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b88b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8a3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8b5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021b8e7. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8ef;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b907;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b919;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b93a;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b95b;
            uVar4 = fcn.18027f520(iVar2, 0, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b975;
        iVar2 = fcn.18021c7f0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b99b;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021b85a
// Address: 0x18021b85a
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021b830(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b840;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b864;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b875;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b88b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8a3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8b5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021b8e7. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8ef;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b907;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b919;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b93a;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b95b;
            uVar4 = fcn.18027f520(iVar2, 0, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b975;
        iVar2 = fcn.18021c7f0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b99b;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021b8ca
// Address: 0x18021b8ca
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021b830(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b840;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b864;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b875;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b88b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8a3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8b5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021b8e7. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8ef;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b907;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b919;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b93a;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b95b;
            uVar4 = fcn.18027f520(iVar2, 0, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b975;
        iVar2 = fcn.18021c7f0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b99b;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021b8ea
// Address: 0x18021b8ea
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021b830(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b840;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b864;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b875;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b88b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8a3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8b5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021b8e7. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8ef;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b907;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b919;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b93a;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b95b;
            uVar4 = fcn.18027f520(iVar2, 0, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b975;
        iVar2 = fcn.18021c7f0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b99b;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021b92e
// Address: 0x18021b92e
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021b830(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b840;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b864;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b875;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b88b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8a3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8b5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021b8e7. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8ef;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b907;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b919;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b93a;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b95b;
            uVar4 = fcn.18027f520(iVar2, 0, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b975;
        iVar2 = fcn.18021c7f0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b99b;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021b96b
// Address: 0x18021b96b
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021b830(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b840;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b864;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b875;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b88b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8a3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8b5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021b8e7. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8ef;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b907;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b919;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b93a;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b95b;
            uVar4 = fcn.18027f520(iVar2, 0, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b975;
        iVar2 = fcn.18021c7f0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b99b;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021b9ab
// Address: 0x18021b9ab
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021b830(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b840;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b864;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b875;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b88b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8a3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8b5;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021b8e7. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b8ef;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b907;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b919;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b93a;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b95b;
            uVar4 = fcn.18027f520(iVar2, 0, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b975;
        iVar2 = fcn.18021c7f0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021b99b;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021b9c0
// Address: 0x18021b9c0
// Size: 346 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18021b9c0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021b9e0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021b9f4;
    iVar3 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ba05;
        iVar4 = fcn.18028b4b0();
        if (iVar3 != iVar4) {
            if (0x7fffffff < in_R8) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ba1c;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ba34;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ba46;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0xffffffff;
            }
            pcVar1 = *(code **)(iVar3 + 8);
            if (pcVar1 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ba60;
                uVar5 = (*pcVar1)(in_RDX, in_R8 & 0xffffffff);
                return uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ba6a;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ba82;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ba94;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021baa8;
    iVar3 = fcn.180245b40(in_RCX, 5);
    if (iVar3 != 0) {
        iVar3 = *(int64_t *)(iVar3 + 0x18);
        if (iVar3 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar2) = in_R9D;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bac8;
            uVar5 = fcn.18027f520(iVar3, 0, in_RDX, in_R8);
            return uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bad5;
        iVar3 = fcn.18021c7f0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar2) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar2) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bafb;
            uVar5 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                                  *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar2), *(int64_t *)((int64_t)&arg_58h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
            return uVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021bb20
// Address: 0x18021bb20
// Size: 55 bytes
// ============================================================
int64_t fcn.18021bb20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h,
                     int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bb2c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021bb3c;
    puVar5 = (undefined8 *)fcn.180245b40();
    if (puVar5 == (undefined8 *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x18021c510;
    iVar6 = fcn.18045a350(in_RCX);
    iVar6 = -iVar6;
    iVar8 = 0;
    if (puVar5 == (undefined8 *)0x0) {
        return 0;
    }
    uVar1 = *puVar5;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c52c;
    iVar3 = fcn.180222850(uVar1);
    if (iVar3 == 0) {
        return 0;
    }
    uVar1 = *puVar5;
    iVar7 = puVar5[2];
    iVar2 = puVar5[1];
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c544;
    fcn.180222910(uVar1);
    if (iVar7 != 0) {
        return iVar7;
    }
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c55b;
        fcn.180229b10();
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c568;
        iVar7 = fcn.180245b40(in_RCX, 5);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c592;
            iVar7 = fcn.18028a770(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4));
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c5b0;
                iVar8 = fcn.18028a560(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4), 
                                      *(int64_t *)(&stack0x00000048 + iVar6 + iVar4), 
                                      *(int64_t *)(&stack0x00000078 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c5bb;
                fcn.18028a7c0(iVar7);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&arg_40h + iVar6 + iVar4) = 0;
                    *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4) = 0;
                    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c5ee;
                    iVar3 = fcn.18028a9e0(*(int64_t *)(&stack0x00000048 + iVar6 + iVar4), 
                                          *(int64_t *)(&stack0x00000050 + iVar6 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar6 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar4));
                    if (iVar3 != 0) goto code_r0x00018021c62f;
                }
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c601;
            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4));
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c616;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar6 + iVar4), *(int64_t *)(&stack0x00000050 + iVar6 + iVar4)
                          , *(int64_t *)((int64_t)&arg_68h + iVar6 + iVar4));
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c625;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c62d;
            fcn.18028a480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar6 + iVar4));
            iVar8 = 0;
        }
code_r0x00018021c62f:
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c637;
        fcn.1802299d0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4));
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c64e;
    iVar7 = fcn.18021c8d0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar4), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar6 + iVar4), *(int64_t *)(&stack0x00000088 + iVar6 + iVar4)
                          , *(int64_t *)(&stack0x000001d0 + iVar6 + iVar4), 
                          *(int64_t *)(&stack0x000001e0 + iVar6 + iVar4));
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c65e;
        iVar3 = fcn.18028a710(iVar7);
        if (iVar3 != 0) goto code_r0x00018021c6a0;
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c667;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4));
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c67f;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar6 + iVar4), *(int64_t *)(&stack0x00000050 + iVar6 + iVar4), 
                      *(int64_t *)((int64_t)&arg_68h + iVar6 + iVar4));
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c691;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar6 + iVar4));
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c699;
        fcn.18028a480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar6 + iVar4));
    }
    if (iVar8 == 0) {
        return 0;
    }
    iVar7 = 0;
code_r0x00018021c6a0:
    uVar1 = *puVar5;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c6a8;
    iVar3 = fcn.180222950(uVar1);
    if (iVar3 == 0) {
        return 0;
    }
    iVar2 = puVar5[2];
    if (iVar2 == 0) {
        if (iVar8 != 0) {
            puVar5[1] = iVar8;
        }
        uVar1 = *puVar5;
        puVar5[2] = iVar7;
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c6e7;
        fcn.180222910(uVar1);
        return iVar7;
    }
    uVar1 = *puVar5;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c6bd;
    fcn.180222910(uVar1);
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c6c5;
    fcn.18028a480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar6 + iVar4));
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18021c6cd;
    fcn.18028a480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar6 + iVar4));
    return iVar2;
}

// ============================================================
// Function: FUN_18021bb60
// Address: 0x18021bb60
// Size: 55 bytes
// ============================================================
int64_t fcn.18021bb60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bb6c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bb7c;
    iVar3 = fcn.180245b40();
    if (iVar3 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = 0x18021c72a;
    iVar3 = fcn.18045a350(in_RCX, iVar3);
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar2) = 0x18021c738;
    iVar4 = fcn.180245b10();
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar2) = 0x18021c751;
        iVar4 = fcn.18028a240(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2));
        if (iVar4 != 0) {
            return iVar4;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar2) = 0x18021c764;
        iVar4 = fcn.18021c4f0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar2));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar2) = 0x18021c779;
            iVar4 = fcn.18028a240(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2));
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar2) = 0x18021c78f;
                iVar1 = fcn.18028c680(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2), 
                                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2));
                if (iVar1 == 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar2) = 0x18021c7aa;
            iVar4 = fcn.18021c8d0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000060 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000070 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000080 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000088 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000001d0 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000001e0 + iVar3 + iVar2));
            *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar2) = 0x18021c7bd;
            iVar1 = fcn.18028a2c0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar2) = 0x18021c7c9;
                fcn.18028a480(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2));
                return 0;
            }
            return iVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021bba0
// Address: 0x18021bba0
// Size: 55 bytes
// ============================================================
int64_t fcn.18021bba0(undefined8 param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bbac;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bbbc;
    iVar3 = fcn.180245b40();
    if (iVar3 == 0) {
        return 0;
    }
    *(undefined8 *)(&stack0x00000028 + iVar2) = *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8);
    *(undefined8 *)(&stack0x00000030 + iVar2) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = 0x18021c80a;
    iVar4 = fcn.18045a350(param_1);
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x18021c818;
    iVar5 = fcn.180245b10();
    if ((iVar5 != 0) && (iVar3 != 0)) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x18021c83a;
        iVar3 = fcn.18028a240(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2));
        if (iVar3 != 0) {
            return iVar3;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x18021c84d;
        iVar3 = fcn.18021c4f0(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000040 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000080 + iVar4 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x18021c862;
            iVar3 = fcn.18028a240(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x18021c878;
                iVar1 = fcn.18028c680(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2), 
                                      *(int64_t *)(&stack0x00000040 + iVar4 + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar4 + iVar2));
                if (iVar1 == 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x18021c893;
            iVar3 = fcn.18021c8d0(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000060 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000070 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000080 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000088 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x000001d0 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x000001e0 + iVar4 + iVar2));
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x18021c8a6;
            iVar1 = fcn.18028a2c0(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000040 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar4 + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar2) = 0x18021c8b2;
                fcn.18028a480(*(int64_t *)(&stack0x00000038 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000040 + iVar4 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar2));
                return 0;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021bbe0
// Address: 0x18021bbe0
// Size: 134 bytes
// ============================================================
int64_t fcn.18021bbe0(int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bbec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc02;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e2c0;
    }
    if ((iVar2 == 0) || (*(int64_t *)0x18077e2a8 == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc2a;
    iVar2 = fcn.180222850();
    iVar4 = *(int64_t *)0x18077e2b0;
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc45;
    fcn.180222910(*(int64_t *)0x18077e2a8);
    if (iVar4 != 0) {
        return iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc56;
    iVar2 = fcn.180222950(*(int64_t *)0x18077e2a8);
    if (iVar2 == 0) {
        return 0;
    }
    iVar4 = *(int64_t *)0x18077e298;
    iVar5 = *(int64_t *)0x18077e2b0;
    if (*(int64_t *)0x18077e2b0 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc70;
        iVar4 = func_0x00018028cd20();
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc80;
            iVar5 = func_0x0001801e3990(iVar4);
            if (iVar5 != 0) goto code_r0x00018021bcb3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bca0;
        func_0x00018026aee0(iVar4);
        *(int64_t *)0x18077e2b0 = 0x1806a05b0;
        iVar4 = *(int64_t *)0x18077e298;
        iVar5 = *(int64_t *)0x18077e2b0;
    }
code_r0x00018021bcb3:
    *(int64_t *)0x18077e2b0 = iVar5;
    *(int64_t *)0x18077e298 = iVar4;
    iVar4 = *(int64_t *)0x18077e2b0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bcbf;
    fcn.180222910(*(int64_t *)0x18077e2a8);
    return iVar4;
}

// ============================================================
// Function: FUN_18021bc66
// Address: 0x18021bc66
// Size: 77 bytes
// ============================================================
int64_t fcn.18021bbe0(int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bbec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc02;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e2c0;
    }
    if ((iVar2 == 0) || (*(int64_t *)0x18077e2a8 == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc2a;
    iVar2 = fcn.180222850();
    iVar4 = *(int64_t *)0x18077e2b0;
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc45;
    fcn.180222910(*(int64_t *)0x18077e2a8);
    if (iVar4 != 0) {
        return iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc56;
    iVar2 = fcn.180222950(*(int64_t *)0x18077e2a8);
    if (iVar2 == 0) {
        return 0;
    }
    iVar4 = *(int64_t *)0x18077e298;
    iVar5 = *(int64_t *)0x18077e2b0;
    if (*(int64_t *)0x18077e2b0 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc70;
        iVar4 = func_0x00018028cd20();
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc80;
            iVar5 = func_0x0001801e3990(iVar4);
            if (iVar5 != 0) goto code_r0x00018021bcb3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bca0;
        func_0x00018026aee0(iVar4);
        *(int64_t *)0x18077e2b0 = 0x1806a05b0;
        iVar4 = *(int64_t *)0x18077e298;
        iVar5 = *(int64_t *)0x18077e2b0;
    }
code_r0x00018021bcb3:
    *(int64_t *)0x18077e2b0 = iVar5;
    *(int64_t *)0x18077e298 = iVar4;
    iVar4 = *(int64_t *)0x18077e2b0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bcbf;
    fcn.180222910(*(int64_t *)0x18077e2a8);
    return iVar4;
}

// ============================================================
// Function: FUN_18021bcb3
// Address: 0x18021bcb3
// Size: 29 bytes
// ============================================================
int64_t fcn.18021bbe0(int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bbec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc02;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e2c0;
    }
    if ((iVar2 == 0) || (*(int64_t *)0x18077e2a8 == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc2a;
    iVar2 = fcn.180222850();
    iVar4 = *(int64_t *)0x18077e2b0;
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc45;
    fcn.180222910(*(int64_t *)0x18077e2a8);
    if (iVar4 != 0) {
        return iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc56;
    iVar2 = fcn.180222950(*(int64_t *)0x18077e2a8);
    if (iVar2 == 0) {
        return 0;
    }
    iVar4 = *(int64_t *)0x18077e298;
    iVar5 = *(int64_t *)0x18077e2b0;
    if (*(int64_t *)0x18077e2b0 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc70;
        iVar4 = func_0x00018028cd20();
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bc80;
            iVar5 = func_0x0001801e3990(iVar4);
            if (iVar5 != 0) goto code_r0x00018021bcb3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bca0;
        func_0x00018026aee0(iVar4);
        *(int64_t *)0x18077e2b0 = 0x1806a05b0;
        iVar4 = *(int64_t *)0x18077e298;
        iVar5 = *(int64_t *)0x18077e2b0;
    }
code_r0x00018021bcb3:
    *(int64_t *)0x18077e2b0 = iVar5;
    *(int64_t *)0x18077e298 = iVar4;
    iVar4 = *(int64_t *)0x18077e2b0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021bcbf;
    fcn.180222910(*(int64_t *)0x18077e2a8);
    return iVar4;
}

// ============================================================
// Function: FUN_18021bcd0
// Address: 0x18021bcd0
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021bcd0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bce0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd04;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd15;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd2b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd43;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd55;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021bd87. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd8f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bda7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdb9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdda;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdfe;
            uVar4 = fcn.18027f520(iVar2, 1, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be18;
        iVar2 = fcn.18021c710(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be3e;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021bcfa
// Address: 0x18021bcfa
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021bcd0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bce0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd04;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd15;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd2b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd43;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd55;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021bd87. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd8f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bda7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdb9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdda;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdfe;
            uVar4 = fcn.18027f520(iVar2, 1, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be18;
        iVar2 = fcn.18021c710(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be3e;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021bd6a
// Address: 0x18021bd6a
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021bcd0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bce0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd04;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd15;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd2b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd43;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd55;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021bd87. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd8f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bda7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdb9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdda;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdfe;
            uVar4 = fcn.18027f520(iVar2, 1, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be18;
        iVar2 = fcn.18021c710(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be3e;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021bd8a
// Address: 0x18021bd8a
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021bcd0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bce0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd04;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd15;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd2b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd43;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd55;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021bd87. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd8f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bda7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdb9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdda;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdfe;
            uVar4 = fcn.18027f520(iVar2, 1, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be18;
        iVar2 = fcn.18021c710(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be3e;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021bdce
// Address: 0x18021bdce
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021bcd0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bce0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd04;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd15;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd2b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd43;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd55;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021bd87. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd8f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bda7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdb9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdda;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdfe;
            uVar4 = fcn.18027f520(iVar2, 1, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be18;
        iVar2 = fcn.18021c710(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be3e;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021be0e
// Address: 0x18021be0e
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021bcd0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bce0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd04;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd15;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd2b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd43;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd55;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021bd87. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd8f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bda7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdb9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdda;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdfe;
            uVar4 = fcn.18027f520(iVar2, 1, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be18;
        iVar2 = fcn.18021c710(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be3e;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021be4e
// Address: 0x18021be4e
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021bcd0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 in_RCX;
    uint32_t uVar5;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bce0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint32_t)in_RDX;
    if ((int32_t)uVar5 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd04;
    iVar2 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd15;
        iVar3 = fcn.18028b4b0();
        if (iVar2 != iVar3) {
            if (0x7fffffff < uVar5) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd2b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd43;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd55;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
                return 0xffffffff;
            }
            if (*(code **)(iVar2 + 8) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021bd87. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(iVar2 + 8))(in_RCX, in_RDX & 0xffffffff);
                return uVar4;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bd8f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bda7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdb9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdda;
    iVar2 = fcn.180245b40(0, 5);
    if (iVar2 != 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x18);
        if (iVar2 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021bdfe;
            uVar4 = fcn.18027f520(iVar2, 1, in_RCX, (int64_t)(int32_t)uVar5);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be18;
        iVar2 = fcn.18021c710(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021be3e;
            uVar4 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021be60
// Address: 0x18021be60
// Size: 349 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18021be60(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021be80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021be94;
    iVar3 = fcn.18021bbe0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bea5;
        iVar4 = fcn.18028b4b0();
        if (iVar3 != iVar4) {
            if (0x7fffffff < in_R8) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bebc;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bed4;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bee6;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0xffffffff;
            }
            pcVar1 = *(code **)(iVar3 + 8);
            if (pcVar1 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bf00;
                uVar5 = (*pcVar1)(in_RDX, in_R8 & 0xffffffff);
                return uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bf0a;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bf22;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bf34;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bf48;
    iVar3 = fcn.180245b40(in_RCX, 5);
    if (iVar3 != 0) {
        iVar3 = *(int64_t *)(iVar3 + 0x18);
        if (iVar3 != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar2) = in_R9D;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bf6b;
            uVar5 = fcn.18027f520(iVar3, 1, in_RDX, in_R8);
            return uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bf78;
        iVar3 = fcn.18021c710(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                              *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar2) = 0;
            *(undefined4 *)((int64_t)&var_18h + iVar2) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bf9e;
            uVar5 = fcn.18028a820(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                                  *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar2), *(int64_t *)((int64_t)&arg_58h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
            return uVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021bfc0
// Address: 0x18021bfc0
// Size: 129 bytes
// ============================================================
uint64_t fcn.18021bfc0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021bfcc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bfd4;
    iVar3 = fcn.18021bbe0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021bfe1;
        iVar4 = fcn.18028b4b0();
        if (iVar3 != iVar4) {
            if (*(code **)(iVar3 + 0x28) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021bff4. Too many branches
    // WARNING: Treating indirect jump as call
                uVar5 = (**(code **)(iVar3 + 0x28))();
                return uVar5;
            }
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c00d;
    iVar3 = fcn.180245b40(0, 5);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c01c;
        iVar3 = fcn.18021c4f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c029;
            iVar1 = fcn.18028a8d0(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                                  *(int64_t *)(&stack0x00000078 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2), 
                                  *(int64_t *)(&stack0x00000098 + iVar2), *(int64_t *)(&stack0x000000a0 + iVar2), 
                                  *(int64_t *)(&stack0x000000a8 + iVar2));
            return (uint64_t)(iVar1 == 1);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021c050
// Address: 0x18021c050
// Size: 145 bytes
// ============================================================
void fcn.18021c050(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021c05a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c062;
    *(int64_t *)0x18077e2a0 = fcn.180222800();
    if (*(int64_t *)0x18077e2a0 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c073;
        *(int64_t *)0x18077e2a8 = fcn.180222800();
        if (*(int64_t *)0x18077e2a8 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c084;
            iVar1 = fcn.1800066d0();
            if (iVar1 != 0) {
                *(undefined4 *)0x18077e2bc = 1;
                *(undefined4 *)0x18077e2c0 = 1;
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c0b0;
        fcn.1802227d0(*(int64_t *)0x18077e2a8);
        *(undefined8 *)0x18077e2a8 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c0c7;
        fcn.1802227d0(*(int64_t *)0x18077e2a0);
        *(int64_t *)0x18077e2a0 = 0;
    }
    *(undefined4 *)0x18077e2c0 = 0;
    return;
}

// ============================================================
// Function: FUN_18021c0f0
// Address: 0x18021c0f0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021c0f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c100;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c110;
    iVar4 = fcn.180245b40();
    if (iVar4 == 0) {
        return 0;
    }
    if ((*(int64_t *)(iVar4 + 0x20) != 0) && (*(int64_t *)(iVar4 + 0x18) == 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar1 = *(undefined8 *)(iVar4 + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c142;
        uVar5 = fcn.18025b180(in_RDX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c14d;
        iVar2 = fcn.180498f10(uVar1, uVar5);
        if (iVar2 == 0) {
            *(undefined8 *)(iVar4 + 0x18) = in_RDX;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18021c131
// Address: 0x18021c131
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021c0f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c100;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c110;
    iVar4 = fcn.180245b40();
    if (iVar4 == 0) {
        return 0;
    }
    if ((*(int64_t *)(iVar4 + 0x20) != 0) && (*(int64_t *)(iVar4 + 0x18) == 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar1 = *(undefined8 *)(iVar4 + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c142;
        uVar5 = fcn.18025b180(in_RDX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c14d;
        iVar2 = fcn.180498f10(uVar1, uVar5);
        if (iVar2 == 0) {
            *(undefined8 *)(iVar4 + 0x18) = in_RDX;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18021c156
// Address: 0x18021c156
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18021c0f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c100;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c110;
    iVar4 = fcn.180245b40();
    if (iVar4 == 0) {
        return 0;
    }
    if ((*(int64_t *)(iVar4 + 0x20) != 0) && (*(int64_t *)(iVar4 + 0x18) == 0)) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar1 = *(undefined8 *)(iVar4 + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c142;
        uVar5 = fcn.18025b180(in_RDX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021c14d;
        iVar2 = fcn.180498f10(uVar1, uVar5);
        if (iVar2 == 0) {
            *(undefined8 *)(iVar4 + 0x18) = in_RDX;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18021c170
// Address: 0x18021c170
// Size: 64 bytes
// ============================================================
undefined8 fcn.18021c170(undefined8 param_1, int64_t param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c17c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18021c18c;
    iVar1 = fcn.180245b40(param_1, 5);
    if (iVar1 == 0) {
        return 0;
    }
    if (*(int64_t *)(iVar1 + 0x18) == param_2) {
        *(undefined8 *)(iVar1 + 0x18) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18021c1b0
// Address: 0x18021c1b0
// Size: 125 bytes
// ============================================================
void fcn.18021c1b0(void)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021c1ba;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)0x18077e2bc != 0) {
        if ((*(int64_t *)0x18077e2b0 != 0) &&
           (pcVar1 = *(code **)(*(int64_t *)0x18077e2b0 + 0x10), pcVar1 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c1dd;
            (*pcVar1)();
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c1e6;
        fcn.18021ccc0(*(int64_t *)((int64_t)&iStackX_20 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c1eb;
        fcn.1800086f0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c1f7;
        fcn.1802227d0(*(undefined8 *)0x18077e2a0);
        *(undefined8 *)0x18077e2a0 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c20e;
        fcn.1802227d0(*(undefined8 *)0x18077e2a8);
        *(undefined8 *)0x18077e2a8 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021c21e;
        fcn.180245e40();
        *(int32_t *)0x18077e2bc = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18021c230
// Address: 0x18021c230
// Size: 233 bytes
// ============================================================
void fcn.18021c230(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021c244;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)arg1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c252;
        fcn.1802227d0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c25b;
        fcn.18028a480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c264;
        fcn.18028a480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2));
        uVar1 = *(undefined8 *)(arg1 + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c27a;
        fcn.180224990(uVar1, 0x1804be6e8, 0x22b);
        uVar1 = *(undefined8 *)(arg1 + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c290;
        fcn.180224990(uVar1, 0x1804be6e8, 0x22d);
        uVar1 = *(undefined8 *)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c2a6;
        fcn.180224990(uVar1, 0x1804be6e8, 0x22e);
        uVar1 = *(undefined8 *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c2bc;
        fcn.180224990(uVar1, 0x1804be6e8, 0x22f);
        uVar1 = *(undefined8 *)(arg1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c2d2;
        fcn.180224990(uVar1, 0x1804be6e8, 0x230);
        uVar1 = *(undefined8 *)(arg1 + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c2e8;
        fcn.180224990(uVar1, 0x1804be6e8, 0x231);
        uVar1 = *(undefined8 *)(arg1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c2fe;
        fcn.180224990(uVar1, 0x1804be6e8, 0x232);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c313;
        fcn.180224990(arg1, 0x1804be6e8, 0x234);
    }
    return;
}

// ============================================================
// Function: FUN_18021c320
// Address: 0x18021c320
// Size: 172 bytes
// ============================================================
int64_t * fcn.18021c320(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c32c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c346;
    piVar2 = (int64_t *)
             fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000040 + iVar1));
    if (piVar2 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c35a;
        fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c373;
        iVar3 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar1));
        piVar2[4] = iVar3;
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c381;
            iVar3 = fcn.180222800();
            *piVar2 = iVar3;
            if (iVar3 != 0) {
                return piVar2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c390;
            fcn.1802227d0(0);
        }
        iVar3 = piVar2[4];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c3a6;
        fcn.180224990(iVar3, 0x1804be6e8, 0x21a);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c3bb;
        fcn.180224990(piVar2, 0x1804be6e8, 0x21c);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18021c3d0
// Address: 0x18021c3d0
// Size: 48 bytes
// ============================================================
undefined8 fcn.18021c3d0(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c3dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c3e9;
    puVar5 = (undefined8 *)fcn.180245b40();
    if (puVar5 != (undefined8 *)0x0) {
        uVar1 = *puVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c3f9;
        iVar3 = fcn.180222850(uVar1);
        if (iVar3 != 0) {
            uVar1 = *puVar5;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            uVar2 = puVar5[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c40e;
            fcn.180222910(uVar1);
            return uVar2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021c400
// Address: 0x18021c400
// Size: 28 bytes
// ============================================================
undefined8 fcn.18021c3d0(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c3dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c3e9;
    puVar5 = (undefined8 *)fcn.180245b40();
    if (puVar5 != (undefined8 *)0x0) {
        uVar1 = *puVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c3f9;
        iVar3 = fcn.180222850(uVar1);
        if (iVar3 != 0) {
            uVar1 = *puVar5;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            uVar2 = puVar5[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c40e;
            fcn.180222910(uVar1);
            return uVar2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021c41c
// Address: 0x18021c41c
// Size: 8 bytes
// ============================================================
undefined8 fcn.18021c3d0(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c3dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c3e9;
    puVar5 = (undefined8 *)fcn.180245b40();
    if (puVar5 != (undefined8 *)0x0) {
        uVar1 = *puVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c3f9;
        iVar3 = fcn.180222850(uVar1);
        if (iVar3 != 0) {
            uVar1 = *puVar5;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            uVar2 = puVar5[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c40e;
            fcn.180222910(uVar1);
            return uVar2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021c430
// Address: 0x18021c430
// Size: 43 bytes
// ============================================================
bool fcn.18021c430(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x18024a43a;
    iVar2 = fcn.18045a350(0x180622400, 0x18021cd60, fcn.1800086f0);
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x18024a44d;
    iVar1 = fcn.18024ab80(*(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1)
                          , *(int64_t *)(&stack0x00000068 + iVar2 + iVar1));
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_18021c460
// Address: 0x18021c460
// Size: 36 bytes
// ============================================================
void fcn.18021c460(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c46c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c47c;
    iVar2 = fcn.180245b40();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c493;
        fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4a6;
        fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4ae;
        fcn.18028a480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4bb;
        fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4ce;
        fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4d6;
        fcn.18028a480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
    }
    return;
}

// ============================================================
// Function: FUN_18021c484
// Address: 0x18021c484
// Size: 87 bytes
// ============================================================
void fcn.18021c460(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c46c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c47c;
    iVar2 = fcn.180245b40();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c493;
        fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4a6;
        fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4ae;
        fcn.18028a480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4bb;
        fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4ce;
        fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4d6;
        fcn.18028a480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
    }
    return;
}

// ============================================================
// Function: FUN_18021c4db
// Address: 0x18021c4db
// Size: 6 bytes
// ============================================================
void fcn.18021c460(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c46c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c47c;
    iVar2 = fcn.180245b40();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c493;
        fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4a6;
        fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4ae;
        fcn.18028a480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4bb;
        fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4ce;
        fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021c4d6;
        fcn.18028a480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1));
    }
    return;
}

// ============================================================
// Function: FUN_18021c4f0
// Address: 0x18021c4f0
// Size: 537 bytes
// ============================================================
int64_t fcn.18021c4f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h,
                     int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c510;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    if (in_RDX == (undefined8 *)0x0) {
        return 0;
    }
    uVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c52c;
    iVar3 = fcn.180222850(uVar1);
    if (iVar3 == 0) {
        return 0;
    }
    uVar1 = *in_RDX;
    iVar5 = in_RDX[2];
    iVar2 = in_RDX[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c544;
    fcn.180222910(uVar1);
    if (iVar5 != 0) {
        return iVar5;
    }
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c55b;
        fcn.180229b10();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c568;
        iVar5 = fcn.180245b40(in_RCX, 5);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c592;
            iVar5 = fcn.18028a770(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4));
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c5b0;
                iVar6 = fcn.18028a560(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c5bb;
                fcn.18028a7c0(iVar5);
                if (iVar6 != 0) {
                    *(undefined8 *)(&stack0x00000020 + iVar4) = 0;
                    *(undefined8 *)(&stack0x00000018 + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c5ee;
                    iVar3 = fcn.18028a9e0(*(int64_t *)((int64_t)&arg_28h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)(&stack0x00000048 + iVar4), *(int64_t *)(&stack0x00000050 + iVar4)
                                         );
                    if (iVar3 != 0) goto code_r0x00018021c62f;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c601;
            fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c616;
            fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c625;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c62d;
            fcn.18028a480(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4));
            iVar6 = 0;
        }
code_r0x00018021c62f:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c637;
        fcn.1802299d0(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c64e;
    iVar5 = fcn.18021c8d0(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)((int64_t)&arg_60h + iVar4), 
                          *(int64_t *)((int64_t)&arg_68h + iVar4), *(int64_t *)(&stack0x000001b0 + iVar4), 
                          *(int64_t *)(&stack0x000001c0 + iVar4));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c65e;
        iVar3 = fcn.18028a710(iVar5);
        if (iVar3 != 0) goto code_r0x00018021c6a0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c667;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c67f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c691;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c699;
        fcn.18028a480(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
    }
    if (iVar6 == 0) {
        return 0;
    }
    iVar5 = 0;
code_r0x00018021c6a0:
    uVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c6a8;
    iVar3 = fcn.180222950(uVar1);
    if (iVar3 == 0) {
        return 0;
    }
    iVar2 = in_RDX[2];
    if (iVar2 == 0) {
        if (iVar6 != 0) {
            in_RDX[1] = iVar6;
        }
        uVar1 = *in_RDX;
        in_RDX[2] = iVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c6e7;
        fcn.180222910(uVar1);
        return iVar5;
    }
    uVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c6bd;
    fcn.180222910(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c6c5;
    fcn.18028a480(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021c6cd;
    fcn.18028a480(*(int64_t *)(&stack0x00000018 + iVar4), *(int64_t *)(&stack0x00000020 + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    return iVar2;
}

// ============================================================
// Function: FUN_18021c710
// Address: 0x18021c710
// Size: 215 bytes
// ============================================================
int64_t fcn.18021c710(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c72a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c738;
    iVar3 = fcn.180245b10();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c751;
        iVar3 = fcn.18028a240(*(int64_t *)(&stack0x00000018 + iVar2));
        if (iVar3 != 0) {
            return iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c764;
        iVar3 = fcn.18021c4f0(*(int64_t *)(&stack0x00000018 + iVar2), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2), 
                              *(int64_t *)((int64_t)&arg_58h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c779;
            iVar3 = fcn.18028a240(*(int64_t *)(&stack0x00000018 + iVar2));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c78f;
                iVar1 = fcn.18028c680(*(int64_t *)(&stack0x00000018 + iVar2), *(int64_t *)((int64_t)&iStackX_20 + iVar2)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar2));
                if (iVar1 == 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c7aa;
            iVar3 = fcn.18021c8d0(*(int64_t *)(&stack0x00000018 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x000001b0 + iVar2), 
                                  *(int64_t *)(&stack0x000001c0 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c7bd;
            iVar1 = fcn.18028a2c0(*(int64_t *)(&stack0x00000018 + iVar2), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c7c9;
                fcn.18028a480(*(int64_t *)(&stack0x00000018 + iVar2), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2));
                return 0;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021c7f0
// Address: 0x18021c7f0
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18021c7f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021c80a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c818;
    iVar3 = fcn.180245b10();
    if ((iVar3 != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c83a;
        iVar3 = fcn.18028a240(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8));
        if (iVar3 != 0) {
            return iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c84d;
        iVar3 = fcn.18021c4f0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                              *(int64_t *)(&stack0x00000060 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c862;
            iVar3 = fcn.18028a240(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c878;
                iVar1 = fcn.18028c680(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2));
                if (iVar1 == 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c893;
            iVar3 = fcn.18021c8d0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                  *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                                  *(int64_t *)(&stack0x000001b0 + iVar2), *(int64_t *)(&stack0x000001c0 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c8a6;
            iVar1 = fcn.18028a2c0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021c8b2;
                fcn.18028a480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2));
                return 0;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021c8d0
// Address: 0x18021c8d0
// Size: 178 bytes
// ============================================================
void fcn.18021c8d0(int64_t arg_28h, int64_t arg_50h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_1c0h
                  , int64_t arg_1d0h)
{
    undefined8 uVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined4 *puVar14;
    undefined4 in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18021c8df;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_1c0h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    *(undefined4 *)((int64_t)&var_18h + iVar7) = in_R8D;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c90e;
    iVar8 = fcn.180245b40(extraout_XMM0_Da, 5);
    *(undefined4 *)((int64_t)&var_10h + iVar7) = 1;
    piVar2 = &arg_50h;
    if (iVar8 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c941;
        iVar9 = fcn.18028a770(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c94e;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c966;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c978;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
        } else {
            *(undefined8 *)((int64_t)&arg_1d0h + iVar7) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c98f;
            uVar10 = func_0x00018001ed90(iVar9);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c997;
            iVar11 = func_0x000180192480(uVar10);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9a5;
            iVar12 = fcn.18028a560(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                   *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0x00000040 + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9b0;
            fcn.18028a7c0(iVar9);
            if (iVar12 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9ba;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9d2;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                              *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9e4;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9f3;
                uVar10 = func_0x00018028a6c0(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca05;
                iVar9 = func_0x00018022ae60(uVar10, 0x1804b4464);
                if (iVar9 != 0) {
                    iVar9 = 0x1804be768;
                    if (*(int64_t *)(iVar8 + 0x30) != 0) {
                        iVar9 = *(int64_t *)(iVar8 + 0x30);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca30;
                    puVar14 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804b4464, iVar9, 0);
                    piVar2 = &arg_78h;
                    uVar3 = puVar14[1];
                    uVar4 = puVar14[2];
                    uVar5 = puVar14[3];
                    *(undefined4 *)((int64_t)&arg_50h + iVar7) = *puVar14;
                    *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000058 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000005c + iVar7) = uVar5;
                    uVar3 = puVar14[5];
                    uVar4 = puVar14[6];
                    uVar5 = puVar14[7];
                    *(undefined4 *)((int64_t)&arg_60h + iVar7) = puVar14[4];
                    *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000068 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000006c + iVar7) = uVar5;
                    *(undefined8 *)((int64_t)&arg_70h + iVar7) = *(undefined8 *)(puVar14 + 8);
                }
                puVar14 = (undefined4 *)((int64_t)piVar2 + iVar7);
                if (*(int64_t *)(iVar8 + 0x38) != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca70;
                    iVar9 = func_0x00018022ae60(uVar10, 0x1804af254);
                    if (iVar9 != 0) {
                        uVar1 = *(undefined8 *)(iVar8 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca8d;
                        puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804af254, uVar1, 0);
                        uVar3 = puVar13[1];
                        uVar4 = puVar13[2];
                        uVar5 = puVar13[3];
                        *puVar14 = *puVar13;
                        puVar14[1] = uVar3;
                        puVar14[2] = uVar4;
                        puVar14[3] = uVar5;
                        uVar3 = puVar13[5];
                        uVar4 = puVar13[6];
                        uVar5 = puVar13[7];
                        puVar14[4] = puVar13[4];
                        puVar14[5] = uVar3;
                        puVar14[6] = uVar4;
                        puVar14[7] = uVar5;
                        *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                        puVar14 = puVar14 + 10;
                    }
                }
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cac5;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804be778, iVar11, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                iVar8 = *(int64_t *)(iVar8 + 0x40);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cafe;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804afa28, iVar8, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb29;
                iVar8 = func_0x00018022ae60(uVar10, 0x1804be788);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb49;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804be788, 0x1804af24c, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb74;
                iVar8 = func_0x00018022ae60(uVar10, 0x1804be790);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb8f;
                    puVar13 = (undefined4 *)
                              func_0x000180229bc0((int64_t)&arg_28h + iVar7, 0x1804be790, (int64_t)&var_10h + iVar7);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cbc1;
                puVar13 = (undefined4 *)
                          func_0x000180229d80((int64_t)&arg_28h + iVar7, 0x1804be7a8, (int64_t)&var_18h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                *puVar14 = *puVar13;
                puVar14[1] = uVar3;
                puVar14[2] = uVar4;
                puVar14[3] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[4] = puVar13[4];
                puVar14[5] = uVar3;
                puVar14[6] = uVar4;
                puVar14[7] = uVar5;
                *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cbef;
                puVar13 = (undefined4 *)
                          func_0x000180229d20((int64_t)&arg_28h + iVar7, 0x1804be7b8, (int64_t)&var_20h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                puVar14[10] = *puVar13;
                puVar14[0xb] = uVar3;
                puVar14[0xc] = uVar4;
                puVar14[0xd] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[0xe] = puVar13[4];
                puVar14[0xf] = uVar3;
                puVar14[0x10] = uVar4;
                puVar14[0x11] = uVar5;
                *(undefined8 *)(puVar14 + 0x12) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc12;
                puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                puVar14[0x14] = *puVar13;
                puVar14[0x15] = uVar3;
                puVar14[0x16] = uVar4;
                puVar14[0x17] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[0x18] = puVar13[4];
                puVar14[0x19] = uVar3;
                puVar14[0x1a] = uVar4;
                puVar14[0x1b] = uVar5;
                uVar10 = *(undefined8 *)(puVar13 + 8);
                *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_50h + iVar7;
                *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                *(undefined8 *)(puVar14 + 0x1c) = uVar10;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc4e;
                iVar6 = fcn.18028a9e0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc57;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc6f;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                  *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                  *(int64_t *)(&stack0x00000030 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc81;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc89;
                    fcn.18028a480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cca8;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_1c0h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18021c982
// Address: 0x18021c982
// Size: 790 bytes
// ============================================================
void fcn.18021c8d0(int64_t arg_28h, int64_t arg_50h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_1c0h
                  , int64_t arg_1d0h)
{
    undefined8 uVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined4 *puVar14;
    undefined4 in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18021c8df;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_1c0h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    *(undefined4 *)((int64_t)&var_18h + iVar7) = in_R8D;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c90e;
    iVar8 = fcn.180245b40(extraout_XMM0_Da, 5);
    *(undefined4 *)((int64_t)&var_10h + iVar7) = 1;
    piVar2 = &arg_50h;
    if (iVar8 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c941;
        iVar9 = fcn.18028a770(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c94e;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c966;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c978;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
        } else {
            *(undefined8 *)((int64_t)&arg_1d0h + iVar7) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c98f;
            uVar10 = func_0x00018001ed90(iVar9);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c997;
            iVar11 = func_0x000180192480(uVar10);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9a5;
            iVar12 = fcn.18028a560(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                   *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0x00000040 + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9b0;
            fcn.18028a7c0(iVar9);
            if (iVar12 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9ba;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9d2;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                              *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9e4;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9f3;
                uVar10 = func_0x00018028a6c0(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca05;
                iVar9 = func_0x00018022ae60(uVar10, 0x1804b4464);
                if (iVar9 != 0) {
                    iVar9 = 0x1804be768;
                    if (*(int64_t *)(iVar8 + 0x30) != 0) {
                        iVar9 = *(int64_t *)(iVar8 + 0x30);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca30;
                    puVar14 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804b4464, iVar9, 0);
                    piVar2 = &arg_78h;
                    uVar3 = puVar14[1];
                    uVar4 = puVar14[2];
                    uVar5 = puVar14[3];
                    *(undefined4 *)((int64_t)&arg_50h + iVar7) = *puVar14;
                    *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000058 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000005c + iVar7) = uVar5;
                    uVar3 = puVar14[5];
                    uVar4 = puVar14[6];
                    uVar5 = puVar14[7];
                    *(undefined4 *)((int64_t)&arg_60h + iVar7) = puVar14[4];
                    *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000068 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000006c + iVar7) = uVar5;
                    *(undefined8 *)((int64_t)&arg_70h + iVar7) = *(undefined8 *)(puVar14 + 8);
                }
                puVar14 = (undefined4 *)((int64_t)piVar2 + iVar7);
                if (*(int64_t *)(iVar8 + 0x38) != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca70;
                    iVar9 = func_0x00018022ae60(uVar10, 0x1804af254);
                    if (iVar9 != 0) {
                        uVar1 = *(undefined8 *)(iVar8 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca8d;
                        puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804af254, uVar1, 0);
                        uVar3 = puVar13[1];
                        uVar4 = puVar13[2];
                        uVar5 = puVar13[3];
                        *puVar14 = *puVar13;
                        puVar14[1] = uVar3;
                        puVar14[2] = uVar4;
                        puVar14[3] = uVar5;
                        uVar3 = puVar13[5];
                        uVar4 = puVar13[6];
                        uVar5 = puVar13[7];
                        puVar14[4] = puVar13[4];
                        puVar14[5] = uVar3;
                        puVar14[6] = uVar4;
                        puVar14[7] = uVar5;
                        *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                        puVar14 = puVar14 + 10;
                    }
                }
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cac5;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804be778, iVar11, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                iVar8 = *(int64_t *)(iVar8 + 0x40);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cafe;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804afa28, iVar8, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb29;
                iVar8 = func_0x00018022ae60(uVar10, 0x1804be788);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb49;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804be788, 0x1804af24c, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb74;
                iVar8 = func_0x00018022ae60(uVar10, 0x1804be790);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb8f;
                    puVar13 = (undefined4 *)
                              func_0x000180229bc0((int64_t)&arg_28h + iVar7, 0x1804be790, (int64_t)&var_10h + iVar7);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cbc1;
                puVar13 = (undefined4 *)
                          func_0x000180229d80((int64_t)&arg_28h + iVar7, 0x1804be7a8, (int64_t)&var_18h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                *puVar14 = *puVar13;
                puVar14[1] = uVar3;
                puVar14[2] = uVar4;
                puVar14[3] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[4] = puVar13[4];
                puVar14[5] = uVar3;
                puVar14[6] = uVar4;
                puVar14[7] = uVar5;
                *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cbef;
                puVar13 = (undefined4 *)
                          func_0x000180229d20((int64_t)&arg_28h + iVar7, 0x1804be7b8, (int64_t)&var_20h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                puVar14[10] = *puVar13;
                puVar14[0xb] = uVar3;
                puVar14[0xc] = uVar4;
                puVar14[0xd] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[0xe] = puVar13[4];
                puVar14[0xf] = uVar3;
                puVar14[0x10] = uVar4;
                puVar14[0x11] = uVar5;
                *(undefined8 *)(puVar14 + 0x12) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc12;
                puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                puVar14[0x14] = *puVar13;
                puVar14[0x15] = uVar3;
                puVar14[0x16] = uVar4;
                puVar14[0x17] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[0x18] = puVar13[4];
                puVar14[0x19] = uVar3;
                puVar14[0x1a] = uVar4;
                puVar14[0x1b] = uVar5;
                uVar10 = *(undefined8 *)(puVar13 + 8);
                *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_50h + iVar7;
                *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                *(undefined8 *)(puVar14 + 0x1c) = uVar10;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc4e;
                iVar6 = fcn.18028a9e0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc57;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc6f;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                  *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                  *(int64_t *)(&stack0x00000030 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc81;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc89;
                    fcn.18028a480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cca8;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_1c0h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18021cc98
// Address: 0x18021cc98
// Size: 28 bytes
// ============================================================
void fcn.18021c8d0(int64_t arg_28h, int64_t arg_50h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_1c0h
                  , int64_t arg_1d0h)
{
    undefined8 uVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    undefined4 *puVar14;
    undefined4 in_R8D;
    undefined8 in_R9;
    undefined8 unaff_R14;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18021c8df;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_1c0h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    *(undefined4 *)((int64_t)&var_18h + iVar7) = in_R8D;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c90e;
    iVar8 = fcn.180245b40(extraout_XMM0_Da, 5);
    *(undefined4 *)((int64_t)&var_10h + iVar7) = 1;
    piVar2 = &arg_50h;
    if (iVar8 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c941;
        iVar9 = fcn.18028a770(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c94e;
            fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c966;
            fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c978;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
        } else {
            *(undefined8 *)((int64_t)&arg_1d0h + iVar7) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c98f;
            uVar10 = func_0x00018001ed90(iVar9);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c997;
            iVar11 = func_0x000180192480(uVar10);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9a5;
            iVar12 = fcn.18028a560(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                   *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)(&stack0x00000040 + iVar7));
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9b0;
            fcn.18028a7c0(iVar9);
            if (iVar12 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9ba;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9d2;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                              *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9e4;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021c9f3;
                uVar10 = func_0x00018028a6c0(iVar12);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca05;
                iVar9 = func_0x00018022ae60(uVar10, 0x1804b4464);
                if (iVar9 != 0) {
                    iVar9 = 0x1804be768;
                    if (*(int64_t *)(iVar8 + 0x30) != 0) {
                        iVar9 = *(int64_t *)(iVar8 + 0x30);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca30;
                    puVar14 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804b4464, iVar9, 0);
                    piVar2 = &arg_78h;
                    uVar3 = puVar14[1];
                    uVar4 = puVar14[2];
                    uVar5 = puVar14[3];
                    *(undefined4 *)((int64_t)&arg_50h + iVar7) = *puVar14;
                    *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000058 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000005c + iVar7) = uVar5;
                    uVar3 = puVar14[5];
                    uVar4 = puVar14[6];
                    uVar5 = puVar14[7];
                    *(undefined4 *)((int64_t)&arg_60h + iVar7) = puVar14[4];
                    *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000068 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000006c + iVar7) = uVar5;
                    *(undefined8 *)((int64_t)&arg_70h + iVar7) = *(undefined8 *)(puVar14 + 8);
                }
                puVar14 = (undefined4 *)((int64_t)piVar2 + iVar7);
                if (*(int64_t *)(iVar8 + 0x38) != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca70;
                    iVar9 = func_0x00018022ae60(uVar10, 0x1804af254);
                    if (iVar9 != 0) {
                        uVar1 = *(undefined8 *)(iVar8 + 0x38);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021ca8d;
                        puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804af254, uVar1, 0);
                        uVar3 = puVar13[1];
                        uVar4 = puVar13[2];
                        uVar5 = puVar13[3];
                        *puVar14 = *puVar13;
                        puVar14[1] = uVar3;
                        puVar14[2] = uVar4;
                        puVar14[3] = uVar5;
                        uVar3 = puVar13[5];
                        uVar4 = puVar13[6];
                        uVar5 = puVar13[7];
                        puVar14[4] = puVar13[4];
                        puVar14[5] = uVar3;
                        puVar14[6] = uVar4;
                        puVar14[7] = uVar5;
                        *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                        puVar14 = puVar14 + 10;
                    }
                }
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cac5;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804be778, iVar11, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                iVar8 = *(int64_t *)(iVar8 + 0x40);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cafe;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804afa28, iVar8, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb29;
                iVar8 = func_0x00018022ae60(uVar10, 0x1804be788);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb49;
                    puVar13 = (undefined4 *)func_0x000180229e30((int64_t)&arg_28h + iVar7, 0x1804be788, 0x1804af24c, 0);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb74;
                iVar8 = func_0x00018022ae60(uVar10, 0x1804be790);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cb8f;
                    puVar13 = (undefined4 *)
                              func_0x000180229bc0((int64_t)&arg_28h + iVar7, 0x1804be790, (int64_t)&var_10h + iVar7);
                    uVar3 = puVar13[1];
                    uVar4 = puVar13[2];
                    uVar5 = puVar13[3];
                    *puVar14 = *puVar13;
                    puVar14[1] = uVar3;
                    puVar14[2] = uVar4;
                    puVar14[3] = uVar5;
                    uVar3 = puVar13[5];
                    uVar4 = puVar13[6];
                    uVar5 = puVar13[7];
                    puVar14[4] = puVar13[4];
                    puVar14[5] = uVar3;
                    puVar14[6] = uVar4;
                    puVar14[7] = uVar5;
                    *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                    puVar14 = puVar14 + 10;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cbc1;
                puVar13 = (undefined4 *)
                          func_0x000180229d80((int64_t)&arg_28h + iVar7, 0x1804be7a8, (int64_t)&var_18h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                *puVar14 = *puVar13;
                puVar14[1] = uVar3;
                puVar14[2] = uVar4;
                puVar14[3] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[4] = puVar13[4];
                puVar14[5] = uVar3;
                puVar14[6] = uVar4;
                puVar14[7] = uVar5;
                *(undefined8 *)(puVar14 + 8) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cbef;
                puVar13 = (undefined4 *)
                          func_0x000180229d20((int64_t)&arg_28h + iVar7, 0x1804be7b8, (int64_t)&var_20h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                puVar14[10] = *puVar13;
                puVar14[0xb] = uVar3;
                puVar14[0xc] = uVar4;
                puVar14[0xd] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[0xe] = puVar13[4];
                puVar14[0xf] = uVar3;
                puVar14[0x10] = uVar4;
                puVar14[0x11] = uVar5;
                *(undefined8 *)(puVar14 + 0x12) = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc12;
                puVar13 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_28h + iVar7);
                uVar3 = puVar13[1];
                uVar4 = puVar13[2];
                uVar5 = puVar13[3];
                puVar14[0x14] = *puVar13;
                puVar14[0x15] = uVar3;
                puVar14[0x16] = uVar4;
                puVar14[0x17] = uVar5;
                uVar3 = puVar13[5];
                uVar4 = puVar13[6];
                uVar5 = puVar13[7];
                puVar14[0x18] = puVar13[4];
                puVar14[0x19] = uVar3;
                puVar14[0x1a] = uVar4;
                puVar14[0x1b] = uVar5;
                uVar10 = *(undefined8 *)(puVar13 + 8);
                *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_50h + iVar7;
                *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                *(undefined8 *)(puVar14 + 0x1c) = uVar10;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc4e;
                iVar6 = fcn.18028a9e0(*(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc57;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc6f;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                  *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                  *(int64_t *)(&stack0x00000030 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc81;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cc89;
                    fcn.18028a480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021cca8;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_1c0h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
    return;
}

