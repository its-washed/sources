// Chunk 137 - 50 functions

// ============================================================
// Function: FUN_1801d7cea
// Address: 0x1801d7cea
// Size: 587 bytes
// ============================================================
void fcn.1801d7cea(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    undefined8 in_RDX;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t iVar9;
    int64_t unaff_RBP;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t unaff_R12;
    int64_t unaff_R13;
    uint64_t unaff_R14;
    undefined8 *puVar13;
    int64_t var_20h;
    int64_t var_70h;
    
    func_0x0001804986e0(unaff_RBP + 0x6d0, in_RDX, 0x948);
    if (arg_48h + unaff_R13 != 0) {
        iVar9 = unaff_RBP + -0x70;
        piVar11 = (int64_t *)(unaff_RBP + 0x6d8);
        do {
            if (unaff_R12 < (uint64_t)arg_48h) {
                piVar10 = &arg_78h;
            } else {
                piVar10 = (int64_t *)(arg_68h + (unaff_R12 - arg_48h) * 0x18);
            }
            pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x60);
            arg_60h = unaff_R14;
            if (pcVar2 == (code *)0x0) {
                uVar6 = *(uint8_t *)piVar10;
            } else {
                uVar6 = (*pcVar2)();
            }
            *(uint32_t *)((int64_t)piVar11 + -4) = (uint32_t)uVar6;
            *(undefined4 *)(piVar11 + -1) = *(undefined4 *)((int64_t)piVar10 + 4);
            iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x68))();
            if (iVar7 == 0) goto code_r0x0001801d7f2d;
            iVar3 = *(int64_t *)(unaff_RBX + 0x1040);
            piVar11[3] = arg_60h;
            iVar4 = piVar10[2];
            *piVar11 = iVar4;
            iVar5 = piVar10[1];
            piVar11[4] = iVar5;
            if (iVar3 != 0) {
                var_20h = CONCAT44((int32_t)((uint64_t)&arg_60h >> 0x20), (int32_t)iVar4);
                iVar7 = func_0x0001802477c0(iVar3, arg_60h, (int32_t)iVar4 + 0x400, iVar5, var_20h);
                if (-1 < iVar7) {
                    piVar11[4] = piVar11[3];
                    *piVar11 = (int64_t)iVar7;
                    iVar7 = func_0x000180243f60(iVar9, (int64_t)iVar7, 0);
                    if (iVar7 != 0) goto code_r0x0001801d7e41;
                }
                func_0x000180229480();
                func_0x0001802295a0(0x1804b46d8, 0x723, 0x1804b4940);
                goto code_r0x0001801d7f1a;
            }
            if (arg_60h != 0) {
                iVar7 = func_0x0001802445f0(iVar9, iVar5, iVar4, iVar5, &arg_60h);
                if (iVar7 == 0) {
                    func_0x000180229480();
                    uVar8 = 0x728;
                    goto code_r0x0001801d7f08;
                }
                piVar11[4] = piVar11[3];
            }
code_r0x0001801d7e41:
            pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x70);
            if (((pcVar2 != (code *)0x0) && (iVar7 = (*pcVar2)(), iVar7 == 0)) ||
               (iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x78))(), iVar7 == 0))
            goto code_r0x0001801d7f2d;
            unaff_R12 = unaff_R12 + 1;
            iVar9 = iVar9 + 0x38;
            piVar11 = piVar11 + 9;
        } while (unaff_R12 < (uint64_t)(arg_48h + unaff_R13));
    }
    if ((arg_48h == 0) || (iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 8))(), 0 < iVar7)) {
        iVar9 = arg_70h;
        iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 8))();
        if (0 < iVar7) {
            if (iVar9 + arg_48h != 0) {
                iVar9 = unaff_RBP + 0x6d0;
                puVar13 = (undefined8 *)(unaff_RBX + 0x80);
                uVar12 = unaff_R14;
                do {
                    iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x80))();
                    if (iVar7 == 0) break;
                    puVar1 = (undefined8 *)(iVar9 + 8);
                    uVar12 = uVar12 + 1;
                    iVar9 = iVar9 + 0x48;
                    *puVar13 = *puVar1;
                    puVar13 = puVar13 + 6;
                } while (uVar12 < (uint64_t)(arg_70h + arg_48h));
            }
            goto code_r0x0001801d7f2d;
        }
        if (*(int32_t *)(unaff_RBX + 0x1008) != -1) goto code_r0x0001801d7f2d;
        func_0x000180229480();
        uVar8 = 0x746;
    } else {
        if (*(int32_t *)(unaff_RBX + 0x1008) != -1) goto code_r0x0001801d7f2d;
        func_0x000180229480();
        uVar8 = 0x73e;
    }
code_r0x0001801d7f08:
    func_0x0001802295a0(0x1804b46d8, uVar8, 0x1804b4940);
code_r0x0001801d7f1a:
    func_0x0001801d5640();
code_r0x0001801d7f2d:
    if (unaff_R14 < (uint64_t)arg_58h) {
        iVar9 = unaff_RBP + -0x70;
        do {
            func_0x000180243fb0(iVar9);
            unaff_R14 = unaff_R14 + 1;
            iVar9 = iVar9 + 0x38;
        } while (unaff_R14 < (uint64_t)arg_58h);
    }
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x1020) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1801d7f35
// Address: 0x1801d7f35
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_60h
// WARNING: [rz-ghidra] Removing arg arg_1130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d8h because it doesn't fit into ProtoModel

void fcn.1801d7cea(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    undefined8 in_RDX;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t iVar9;
    int64_t unaff_RBP;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t unaff_R12;
    int64_t unaff_R13;
    uint64_t unaff_R14;
    undefined8 *puVar13;
    int64_t var_20h;
    int64_t var_70h;
    
    func_0x0001804986e0(unaff_RBP + 0x6d0, in_RDX, 0x948);
    if (arg_48h + unaff_R13 != 0) {
        iVar9 = unaff_RBP + -0x70;
        piVar11 = (int64_t *)(unaff_RBP + 0x6d8);
        do {
            if (unaff_R12 < (uint64_t)arg_48h) {
                piVar10 = &arg_78h;
            } else {
                piVar10 = (int64_t *)(arg_68h + (unaff_R12 - arg_48h) * 0x18);
            }
            pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x60);
            arg_60h = unaff_R14;
            if (pcVar2 == (code *)0x0) {
                uVar6 = *(uint8_t *)piVar10;
            } else {
                uVar6 = (*pcVar2)();
            }
            *(uint32_t *)((int64_t)piVar11 + -4) = (uint32_t)uVar6;
            *(undefined4 *)(piVar11 + -1) = *(undefined4 *)((int64_t)piVar10 + 4);
            iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x68))();
            if (iVar7 == 0) goto code_r0x0001801d7f2d;
            iVar3 = *(int64_t *)(unaff_RBX + 0x1040);
            piVar11[3] = arg_60h;
            iVar4 = piVar10[2];
            *piVar11 = iVar4;
            iVar5 = piVar10[1];
            piVar11[4] = iVar5;
            if (iVar3 != 0) {
                var_20h = CONCAT44((int32_t)((uint64_t)&arg_60h >> 0x20), (int32_t)iVar4);
                iVar7 = func_0x0001802477c0(iVar3, arg_60h, (int32_t)iVar4 + 0x400, iVar5, var_20h);
                if (-1 < iVar7) {
                    piVar11[4] = piVar11[3];
                    *piVar11 = (int64_t)iVar7;
                    iVar7 = func_0x000180243f60(iVar9, (int64_t)iVar7, 0);
                    if (iVar7 != 0) goto code_r0x0001801d7e41;
                }
                func_0x000180229480();
                func_0x0001802295a0(0x1804b46d8, 0x723, 0x1804b4940);
                goto code_r0x0001801d7f1a;
            }
            if (arg_60h != 0) {
                iVar7 = func_0x0001802445f0(iVar9, iVar5, iVar4, iVar5, &arg_60h);
                if (iVar7 == 0) {
                    func_0x000180229480();
                    uVar8 = 0x728;
                    goto code_r0x0001801d7f08;
                }
                piVar11[4] = piVar11[3];
            }
code_r0x0001801d7e41:
            pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x70);
            if (((pcVar2 != (code *)0x0) && (iVar7 = (*pcVar2)(), iVar7 == 0)) ||
               (iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x78))(), iVar7 == 0))
            goto code_r0x0001801d7f2d;
            unaff_R12 = unaff_R12 + 1;
            iVar9 = iVar9 + 0x38;
            piVar11 = piVar11 + 9;
        } while (unaff_R12 < (uint64_t)(arg_48h + unaff_R13));
    }
    if ((arg_48h == 0) || (iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 8))(), 0 < iVar7)) {
        iVar9 = arg_70h;
        iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 8))();
        if (0 < iVar7) {
            if (iVar9 + arg_48h != 0) {
                iVar9 = unaff_RBP + 0x6d0;
                puVar13 = (undefined8 *)(unaff_RBX + 0x80);
                uVar12 = unaff_R14;
                do {
                    iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x80))();
                    if (iVar7 == 0) break;
                    puVar1 = (undefined8 *)(iVar9 + 8);
                    uVar12 = uVar12 + 1;
                    iVar9 = iVar9 + 0x48;
                    *puVar13 = *puVar1;
                    puVar13 = puVar13 + 6;
                } while (uVar12 < (uint64_t)(arg_70h + arg_48h));
            }
            goto code_r0x0001801d7f2d;
        }
        if (*(int32_t *)(unaff_RBX + 0x1008) != -1) goto code_r0x0001801d7f2d;
        func_0x000180229480();
        uVar8 = 0x746;
    } else {
        if (*(int32_t *)(unaff_RBX + 0x1008) != -1) goto code_r0x0001801d7f2d;
        func_0x000180229480();
        uVar8 = 0x73e;
    }
code_r0x0001801d7f08:
    func_0x0001802295a0(0x1804b46d8, uVar8, 0x1804b4940);
code_r0x0001801d7f1a:
    func_0x0001801d5640();
code_r0x0001801d7f2d:
    if (unaff_R14 < (uint64_t)arg_58h) {
        iVar9 = unaff_RBP + -0x70;
        do {
            func_0x000180243fb0(iVar9);
            unaff_R14 = unaff_R14 + 1;
            iVar9 = iVar9 + 0x38;
        } while (unaff_R14 < (uint64_t)arg_58h);
    }
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x1020) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1801d7f54
// Address: 0x1801d7f54
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_60h
// WARNING: [rz-ghidra] Removing arg arg_1130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d8h because it doesn't fit into ProtoModel

void fcn.1801d7cea(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    undefined8 in_RDX;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t iVar9;
    int64_t unaff_RBP;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t unaff_R12;
    int64_t unaff_R13;
    uint64_t unaff_R14;
    undefined8 *puVar13;
    int64_t var_20h;
    int64_t var_70h;
    
    func_0x0001804986e0(unaff_RBP + 0x6d0, in_RDX, 0x948);
    if (arg_48h + unaff_R13 != 0) {
        iVar9 = unaff_RBP + -0x70;
        piVar11 = (int64_t *)(unaff_RBP + 0x6d8);
        do {
            if (unaff_R12 < (uint64_t)arg_48h) {
                piVar10 = &arg_78h;
            } else {
                piVar10 = (int64_t *)(arg_68h + (unaff_R12 - arg_48h) * 0x18);
            }
            pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x60);
            arg_60h = unaff_R14;
            if (pcVar2 == (code *)0x0) {
                uVar6 = *(uint8_t *)piVar10;
            } else {
                uVar6 = (*pcVar2)();
            }
            *(uint32_t *)((int64_t)piVar11 + -4) = (uint32_t)uVar6;
            *(undefined4 *)(piVar11 + -1) = *(undefined4 *)((int64_t)piVar10 + 4);
            iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x68))();
            if (iVar7 == 0) goto code_r0x0001801d7f2d;
            iVar3 = *(int64_t *)(unaff_RBX + 0x1040);
            piVar11[3] = arg_60h;
            iVar4 = piVar10[2];
            *piVar11 = iVar4;
            iVar5 = piVar10[1];
            piVar11[4] = iVar5;
            if (iVar3 != 0) {
                var_20h = CONCAT44((int32_t)((uint64_t)&arg_60h >> 0x20), (int32_t)iVar4);
                iVar7 = func_0x0001802477c0(iVar3, arg_60h, (int32_t)iVar4 + 0x400, iVar5, var_20h);
                if (-1 < iVar7) {
                    piVar11[4] = piVar11[3];
                    *piVar11 = (int64_t)iVar7;
                    iVar7 = func_0x000180243f60(iVar9, (int64_t)iVar7, 0);
                    if (iVar7 != 0) goto code_r0x0001801d7e41;
                }
                func_0x000180229480();
                func_0x0001802295a0(0x1804b46d8, 0x723, 0x1804b4940);
                goto code_r0x0001801d7f1a;
            }
            if (arg_60h != 0) {
                iVar7 = func_0x0001802445f0(iVar9, iVar5, iVar4, iVar5, &arg_60h);
                if (iVar7 == 0) {
                    func_0x000180229480();
                    uVar8 = 0x728;
                    goto code_r0x0001801d7f08;
                }
                piVar11[4] = piVar11[3];
            }
code_r0x0001801d7e41:
            pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x70);
            if (((pcVar2 != (code *)0x0) && (iVar7 = (*pcVar2)(), iVar7 == 0)) ||
               (iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x78))(), iVar7 == 0))
            goto code_r0x0001801d7f2d;
            unaff_R12 = unaff_R12 + 1;
            iVar9 = iVar9 + 0x38;
            piVar11 = piVar11 + 9;
        } while (unaff_R12 < (uint64_t)(arg_48h + unaff_R13));
    }
    if ((arg_48h == 0) || (iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 8))(), 0 < iVar7)) {
        iVar9 = arg_70h;
        iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 8))();
        if (0 < iVar7) {
            if (iVar9 + arg_48h != 0) {
                iVar9 = unaff_RBP + 0x6d0;
                puVar13 = (undefined8 *)(unaff_RBX + 0x80);
                uVar12 = unaff_R14;
                do {
                    iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x80))();
                    if (iVar7 == 0) break;
                    puVar1 = (undefined8 *)(iVar9 + 8);
                    uVar12 = uVar12 + 1;
                    iVar9 = iVar9 + 0x48;
                    *puVar13 = *puVar1;
                    puVar13 = puVar13 + 6;
                } while (uVar12 < (uint64_t)(arg_70h + arg_48h));
            }
            goto code_r0x0001801d7f2d;
        }
        if (*(int32_t *)(unaff_RBX + 0x1008) != -1) goto code_r0x0001801d7f2d;
        func_0x000180229480();
        uVar8 = 0x746;
    } else {
        if (*(int32_t *)(unaff_RBX + 0x1008) != -1) goto code_r0x0001801d7f2d;
        func_0x000180229480();
        uVar8 = 0x73e;
    }
code_r0x0001801d7f08:
    func_0x0001802295a0(0x1804b46d8, uVar8, 0x1804b4940);
code_r0x0001801d7f1a:
    func_0x0001801d5640();
code_r0x0001801d7f2d:
    if (unaff_R14 < (uint64_t)arg_58h) {
        iVar9 = unaff_RBP + -0x70;
        do {
            func_0x000180243fb0(iVar9);
            unaff_R14 = unaff_R14 + 1;
            iVar9 = iVar9 + 0x38;
        } while (unaff_R14 < (uint64_t)arg_58h);
    }
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x1020) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1801d7f8e
// Address: 0x1801d7f8e
// Size: 286 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_60h
// WARNING: [rz-ghidra] Removing arg arg_1130h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1138h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1140h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1188h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1020h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6d8h because it doesn't fit into ProtoModel

void fcn.1801d7cea(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    undefined8 in_RDX;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t iVar9;
    int64_t unaff_RBP;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t unaff_R12;
    int64_t unaff_R13;
    uint64_t unaff_R14;
    undefined8 *puVar13;
    int64_t var_20h;
    int64_t var_70h;
    
    func_0x0001804986e0(unaff_RBP + 0x6d0, in_RDX, 0x948);
    if (arg_48h + unaff_R13 != 0) {
        iVar9 = unaff_RBP + -0x70;
        piVar11 = (int64_t *)(unaff_RBP + 0x6d8);
        do {
            if (unaff_R12 < (uint64_t)arg_48h) {
                piVar10 = &arg_78h;
            } else {
                piVar10 = (int64_t *)(arg_68h + (unaff_R12 - arg_48h) * 0x18);
            }
            pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x60);
            arg_60h = unaff_R14;
            if (pcVar2 == (code *)0x0) {
                uVar6 = *(uint8_t *)piVar10;
            } else {
                uVar6 = (*pcVar2)();
            }
            *(uint32_t *)((int64_t)piVar11 + -4) = (uint32_t)uVar6;
            *(undefined4 *)(piVar11 + -1) = *(undefined4 *)((int64_t)piVar10 + 4);
            iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x68))();
            if (iVar7 == 0) goto code_r0x0001801d7f2d;
            iVar3 = *(int64_t *)(unaff_RBX + 0x1040);
            piVar11[3] = arg_60h;
            iVar4 = piVar10[2];
            *piVar11 = iVar4;
            iVar5 = piVar10[1];
            piVar11[4] = iVar5;
            if (iVar3 != 0) {
                var_20h = CONCAT44((int32_t)((uint64_t)&arg_60h >> 0x20), (int32_t)iVar4);
                iVar7 = func_0x0001802477c0(iVar3, arg_60h, (int32_t)iVar4 + 0x400, iVar5, var_20h);
                if (-1 < iVar7) {
                    piVar11[4] = piVar11[3];
                    *piVar11 = (int64_t)iVar7;
                    iVar7 = func_0x000180243f60(iVar9, (int64_t)iVar7, 0);
                    if (iVar7 != 0) goto code_r0x0001801d7e41;
                }
                func_0x000180229480();
                func_0x0001802295a0(0x1804b46d8, 0x723, 0x1804b4940);
                goto code_r0x0001801d7f1a;
            }
            if (arg_60h != 0) {
                iVar7 = func_0x0001802445f0(iVar9, iVar5, iVar4, iVar5, &arg_60h);
                if (iVar7 == 0) {
                    func_0x000180229480();
                    uVar8 = 0x728;
                    goto code_r0x0001801d7f08;
                }
                piVar11[4] = piVar11[3];
            }
code_r0x0001801d7e41:
            pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x70);
            if (((pcVar2 != (code *)0x0) && (iVar7 = (*pcVar2)(), iVar7 == 0)) ||
               (iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x78))(), iVar7 == 0))
            goto code_r0x0001801d7f2d;
            unaff_R12 = unaff_R12 + 1;
            iVar9 = iVar9 + 0x38;
            piVar11 = piVar11 + 9;
        } while (unaff_R12 < (uint64_t)(arg_48h + unaff_R13));
    }
    if ((arg_48h == 0) || (iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 8))(), 0 < iVar7)) {
        iVar9 = arg_70h;
        iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 8))();
        if (0 < iVar7) {
            if (iVar9 + arg_48h != 0) {
                iVar9 = unaff_RBP + 0x6d0;
                puVar13 = (undefined8 *)(unaff_RBX + 0x80);
                uVar12 = unaff_R14;
                do {
                    iVar7 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1148) + 0x80))();
                    if (iVar7 == 0) break;
                    puVar1 = (undefined8 *)(iVar9 + 8);
                    uVar12 = uVar12 + 1;
                    iVar9 = iVar9 + 0x48;
                    *puVar13 = *puVar1;
                    puVar13 = puVar13 + 6;
                } while (uVar12 < (uint64_t)(arg_70h + arg_48h));
            }
            goto code_r0x0001801d7f2d;
        }
        if (*(int32_t *)(unaff_RBX + 0x1008) != -1) goto code_r0x0001801d7f2d;
        func_0x000180229480();
        uVar8 = 0x746;
    } else {
        if (*(int32_t *)(unaff_RBX + 0x1008) != -1) goto code_r0x0001801d7f2d;
        func_0x000180229480();
        uVar8 = 0x73e;
    }
code_r0x0001801d7f08:
    func_0x0001802295a0(0x1804b46d8, uVar8, 0x1804b4940);
code_r0x0001801d7f1a:
    func_0x0001801d5640();
code_r0x0001801d7f2d:
    if (unaff_R14 < (uint64_t)arg_58h) {
        iVar9 = unaff_RBP + -0x70;
        do {
            func_0x000180243fb0(iVar9);
            unaff_R14 = unaff_R14 + 1;
            iVar9 = iVar9 + 0x38;
        } while (unaff_R14 < (uint64_t)arg_58h);
    }
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x1020) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1801d80c0
// Address: 0x1801d80c0
// Size: 27 bytes
// ============================================================
undefined8 fcn.1801d80c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d80cc;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x6c0);
    uVar7 = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    if (iVar11 != 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x6b8);
        iVar2 = *(int64_t *)(in_RCX + 0x6a0);
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8109;
        uVar7 = func_0x00018021b300(uVar3, iVar1 + iVar2, iVar11, (int64_t)&arg_38h + iVar10);
        *(undefined8 *)(in_RCX + 0x6c0) = 0;
    }
    iVar11 = *(int64_t *)(in_RCX + 0x10e0);
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = unaff_RBX;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar10) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8135;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            puVar4 = *(undefined8 **)(iVar11 + 8);
            uVar3 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = puVar4[1];
            uVar6 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8159;
            uVar8 = func_0x00018021b300(uVar3, uVar6, uVar5, (int64_t)&arg_38h + iVar10);
            uVar3 = puVar4[2];
            uVar7 = uVar7 & uVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8171;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x262);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8187;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x263);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d818f;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d819b;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81af;
        func_0x0001801a66d0(uVar3);
    }
    if (*(int64_t *)(in_RCX + 0x10e8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ca;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(iVar11 + 8) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ec;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26c);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8202;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26d);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d820a;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8216;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d822a;
        func_0x0001801a66d0(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8232;
    iVar9 = func_0x0001801d49b0(in_RCX);
    if ((iVar9 != 0) && (uVar7 != 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d80db
// Address: 0x1801d80db
// Size: 8 bytes
// ============================================================
undefined8 fcn.1801d80c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d80cc;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x6c0);
    uVar7 = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    if (iVar11 != 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x6b8);
        iVar2 = *(int64_t *)(in_RCX + 0x6a0);
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8109;
        uVar7 = func_0x00018021b300(uVar3, iVar1 + iVar2, iVar11, (int64_t)&arg_38h + iVar10);
        *(undefined8 *)(in_RCX + 0x6c0) = 0;
    }
    iVar11 = *(int64_t *)(in_RCX + 0x10e0);
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = unaff_RBX;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar10) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8135;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            puVar4 = *(undefined8 **)(iVar11 + 8);
            uVar3 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = puVar4[1];
            uVar6 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8159;
            uVar8 = func_0x00018021b300(uVar3, uVar6, uVar5, (int64_t)&arg_38h + iVar10);
            uVar3 = puVar4[2];
            uVar7 = uVar7 & uVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8171;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x262);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8187;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x263);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d818f;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d819b;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81af;
        func_0x0001801a66d0(uVar3);
    }
    if (*(int64_t *)(in_RCX + 0x10e8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ca;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(iVar11 + 8) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ec;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26c);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8202;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26d);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d820a;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8216;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d822a;
        func_0x0001801a66d0(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8232;
    iVar9 = func_0x0001801d49b0(in_RCX);
    if ((iVar9 != 0) && (uVar7 != 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d80e3
// Address: 0x1801d80e3
// Size: 72 bytes
// ============================================================
undefined8 fcn.1801d80c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d80cc;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x6c0);
    uVar7 = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    if (iVar11 != 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x6b8);
        iVar2 = *(int64_t *)(in_RCX + 0x6a0);
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8109;
        uVar7 = func_0x00018021b300(uVar3, iVar1 + iVar2, iVar11, (int64_t)&arg_38h + iVar10);
        *(undefined8 *)(in_RCX + 0x6c0) = 0;
    }
    iVar11 = *(int64_t *)(in_RCX + 0x10e0);
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = unaff_RBX;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar10) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8135;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            puVar4 = *(undefined8 **)(iVar11 + 8);
            uVar3 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = puVar4[1];
            uVar6 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8159;
            uVar8 = func_0x00018021b300(uVar3, uVar6, uVar5, (int64_t)&arg_38h + iVar10);
            uVar3 = puVar4[2];
            uVar7 = uVar7 & uVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8171;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x262);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8187;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x263);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d818f;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d819b;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81af;
        func_0x0001801a66d0(uVar3);
    }
    if (*(int64_t *)(in_RCX + 0x10e8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ca;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(iVar11 + 8) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ec;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26c);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8202;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26d);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d820a;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8216;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d822a;
        func_0x0001801a66d0(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8232;
    iVar9 = func_0x0001801d49b0(in_RCX);
    if ((iVar9 != 0) && (uVar7 != 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d812b
// Address: 0x1801d812b
// Size: 137 bytes
// ============================================================
undefined8 fcn.1801d80c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d80cc;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x6c0);
    uVar7 = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    if (iVar11 != 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x6b8);
        iVar2 = *(int64_t *)(in_RCX + 0x6a0);
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8109;
        uVar7 = func_0x00018021b300(uVar3, iVar1 + iVar2, iVar11, (int64_t)&arg_38h + iVar10);
        *(undefined8 *)(in_RCX + 0x6c0) = 0;
    }
    iVar11 = *(int64_t *)(in_RCX + 0x10e0);
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = unaff_RBX;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar10) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8135;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            puVar4 = *(undefined8 **)(iVar11 + 8);
            uVar3 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = puVar4[1];
            uVar6 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8159;
            uVar8 = func_0x00018021b300(uVar3, uVar6, uVar5, (int64_t)&arg_38h + iVar10);
            uVar3 = puVar4[2];
            uVar7 = uVar7 & uVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8171;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x262);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8187;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x263);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d818f;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d819b;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81af;
        func_0x0001801a66d0(uVar3);
    }
    if (*(int64_t *)(in_RCX + 0x10e8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ca;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(iVar11 + 8) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ec;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26c);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8202;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26d);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d820a;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8216;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d822a;
        func_0x0001801a66d0(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8232;
    iVar9 = func_0x0001801d49b0(in_RCX);
    if ((iVar9 != 0) && (uVar7 != 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d81b4
// Address: 0x1801d81b4
// Size: 17 bytes
// ============================================================
undefined8 fcn.1801d80c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d80cc;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x6c0);
    uVar7 = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    if (iVar11 != 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x6b8);
        iVar2 = *(int64_t *)(in_RCX + 0x6a0);
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8109;
        uVar7 = func_0x00018021b300(uVar3, iVar1 + iVar2, iVar11, (int64_t)&arg_38h + iVar10);
        *(undefined8 *)(in_RCX + 0x6c0) = 0;
    }
    iVar11 = *(int64_t *)(in_RCX + 0x10e0);
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = unaff_RBX;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar10) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8135;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            puVar4 = *(undefined8 **)(iVar11 + 8);
            uVar3 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = puVar4[1];
            uVar6 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8159;
            uVar8 = func_0x00018021b300(uVar3, uVar6, uVar5, (int64_t)&arg_38h + iVar10);
            uVar3 = puVar4[2];
            uVar7 = uVar7 & uVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8171;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x262);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8187;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x263);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d818f;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d819b;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81af;
        func_0x0001801a66d0(uVar3);
    }
    if (*(int64_t *)(in_RCX + 0x10e8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ca;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(iVar11 + 8) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ec;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26c);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8202;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26d);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d820a;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8216;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d822a;
        func_0x0001801a66d0(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8232;
    iVar9 = func_0x0001801d49b0(in_RCX);
    if ((iVar9 != 0) && (uVar7 != 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d81c5
// Address: 0x1801d81c5
// Size: 123 bytes
// ============================================================
undefined8 fcn.1801d80c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d80cc;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x6c0);
    uVar7 = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    if (iVar11 != 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x6b8);
        iVar2 = *(int64_t *)(in_RCX + 0x6a0);
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8109;
        uVar7 = func_0x00018021b300(uVar3, iVar1 + iVar2, iVar11, (int64_t)&arg_38h + iVar10);
        *(undefined8 *)(in_RCX + 0x6c0) = 0;
    }
    iVar11 = *(int64_t *)(in_RCX + 0x10e0);
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = unaff_RBX;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar10) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8135;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            puVar4 = *(undefined8 **)(iVar11 + 8);
            uVar3 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = puVar4[1];
            uVar6 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8159;
            uVar8 = func_0x00018021b300(uVar3, uVar6, uVar5, (int64_t)&arg_38h + iVar10);
            uVar3 = puVar4[2];
            uVar7 = uVar7 & uVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8171;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x262);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8187;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x263);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d818f;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d819b;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81af;
        func_0x0001801a66d0(uVar3);
    }
    if (*(int64_t *)(in_RCX + 0x10e8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ca;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(iVar11 + 8) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ec;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26c);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8202;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26d);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d820a;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8216;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d822a;
        func_0x0001801a66d0(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8232;
    iVar9 = func_0x0001801d49b0(in_RCX);
    if ((iVar9 != 0) && (uVar7 != 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d8240
// Address: 0x1801d8240
// Size: 23 bytes
// ============================================================
undefined8 fcn.1801d80c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d80cc;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x6c0);
    uVar7 = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    if (iVar11 != 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x6b8);
        iVar2 = *(int64_t *)(in_RCX + 0x6a0);
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8109;
        uVar7 = func_0x00018021b300(uVar3, iVar1 + iVar2, iVar11, (int64_t)&arg_38h + iVar10);
        *(undefined8 *)(in_RCX + 0x6c0) = 0;
    }
    iVar11 = *(int64_t *)(in_RCX + 0x10e0);
    *(undefined8 *)((int64_t)&arg_40h + iVar10) = unaff_RBX;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar10) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8135;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            puVar4 = *(undefined8 **)(iVar11 + 8);
            uVar3 = *(undefined8 *)(in_RCX + 0x48);
            uVar5 = puVar4[1];
            uVar6 = *puVar4;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8159;
            uVar8 = func_0x00018021b300(uVar3, uVar6, uVar5, (int64_t)&arg_38h + iVar10);
            uVar3 = puVar4[2];
            uVar7 = uVar7 & uVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8171;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x262);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8187;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x263);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d818f;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d819b;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81af;
        func_0x0001801a66d0(uVar3);
    }
    if (*(int64_t *)(in_RCX + 0x10e8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ca;
        iVar11 = func_0x0001801a6800();
        while (iVar11 != 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(iVar11 + 8) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d81ec;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26c);
            uVar3 = *(undefined8 *)(iVar11 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8202;
            func_0x000180224990(uVar3, 0x1804b4ad0, 0x26d);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d820a;
            func_0x0001801a65e0(iVar11);
            uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8216;
            iVar11 = func_0x0001801a6800(uVar3);
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x10e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d822a;
        func_0x0001801a66d0(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d8232;
    iVar9 = func_0x0001801d49b0(in_RCX);
    if ((iVar9 != 0) && (uVar7 != 0)) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d8260
// Address: 0x1801d8260
// Size: 235 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint64_t fcn.1801d8260(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_98h,
                      int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_e0h, int64_t arg_e8h,
                      int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                      int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_148h, int64_t arg_150h, int64_t arg_168h, int64_t arg_170h, int64_t arg_178h,
                      int64_t arg_180h, int64_t arg_190h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    code *pcVar11;
    uint32_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801d827d;
    iVar13 = func_0x00018045a350();
    iVar13 = -iVar13;
    piVar3 = *(int64_t **)((int64_t)&arg_190h + iVar13);
    uVar4 = *(undefined8 *)((int64_t)&arg_130h + iVar13);
    uVar5 = *(undefined8 *)((int64_t)&arg_128h + iVar13);
    uVar6 = *(undefined8 *)((int64_t)&arg_118h + iVar13);
    uVar7 = *(undefined8 *)((int64_t)&arg_110h + iVar13);
    uVar2 = *(undefined4 *)((int64_t)&arg_c0h + iVar13);
    *(int64_t **)((int64_t)&arg_60h + iVar13) = piVar3;
    *(undefined8 *)((int64_t)&arg_58h + iVar13) = *(undefined8 *)((int64_t)&arg_180h + iVar13);
    *(undefined8 *)((int64_t)&arg_50h + iVar13) = *(undefined8 *)((int64_t)&arg_178h + iVar13);
    *(undefined8 *)((int64_t)&arg_48h + iVar13) = *(undefined8 *)((int64_t)&arg_170h + iVar13);
    *(undefined8 *)((int64_t)&arg_40h + iVar13) = *(undefined8 *)((int64_t)&arg_168h + iVar13);
    *(undefined8 *)((int64_t)&arg_38h + iVar13) = *(undefined8 *)((int64_t)&arg_150h + iVar13);
    *(undefined8 *)((int64_t)&arg_30h + iVar13) = *(undefined8 *)((int64_t)&arg_148h + iVar13);
    *(undefined8 *)((int64_t)&arg_28h + iVar13) = *(undefined8 *)((int64_t)&arg_140h + iVar13);
    *(undefined8 *)((int64_t)&var_20h + iVar13) = uVar4;
    *(undefined8 *)((int64_t)&var_18h + iVar13) = uVar5;
    *(undefined8 *)((int64_t)&var_10h + iVar13) = uVar6;
    *(undefined8 *)((int64_t)&var_8h + iVar13) = uVar7;
    *(undefined4 *)(&stack0x00000000 + iVar13) = uVar2;
    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar13) = *(undefined4 *)((int64_t)&arg_b8h + iVar13);
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d8342;
    uVar14 = func_0x0001801d6f60();
    if ((int32_t)uVar14 != 1) {
        return uVar14;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar13) = unaff_RBX;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d835b;
    uVar15 = func_0x0001801a67b0();
    *(undefined8 *)(iVar8 + 0x10e0) = uVar15;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d836a;
    uVar15 = func_0x0001801a67b0();
    *(undefined8 *)(iVar8 + 0x10e8) = uVar15;
    iVar8 = *piVar3;
    if ((*(int64_t *)(iVar8 + 0x10e0) == 0) || (*(int64_t *)(iVar8 + 0x10e8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84b8;
        fcn.1801d80c0(*(int64_t *)((int64_t)&var_8h + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                      *(int64_t *)((int64_t)&var_18h + iVar13));
        *piVar3 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84c4;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84dc;
        func_0x0001802295a0(0x1804b4ad0, 0x296, 0x1804b4b10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84ee;
        func_0x0001802296d0(0x14, 0x80014, 0);
        return 0xfffffffe;
    }
    uVar1 = *(undefined2 *)((int64_t)&arg_c8h + iVar13);
    *(undefined4 *)(iVar8 + 0x10) = 1;
    *(undefined2 *)(*piVar3 + 0x30) = uVar1;
    *(undefined4 *)(*piVar3 + 0x1110) = 1;
    if (((in_R8D == 0x100) || (in_R8D == 0xfefd)) || (in_R8D == 0xfeff)) {
        uVar15 = 0x1804b8300;
    } else {
        if (in_R8D != 0x1ffff) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83d5;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83ed;
            func_0x0001802295a0(0x1804b4ad0, 0x2a9, 0x1804b4b10);
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83ff;
            func_0x0001802296d0(0x14, 0xc0103, 0);
            uVar14 = 0xfffffffe;
            goto code_r0x0001801d84a0;
        }
        uVar15 = 0x1804b85e0;
    }
    iVar8 = *piVar3;
    uVar9 = *(undefined8 *)((int64_t)&arg_e8h + iVar13);
    uVar10 = *(undefined8 *)((int64_t)&arg_e0h + iVar13);
    *(undefined8 *)((int64_t)&arg_38h + iVar13) = uVar4;
    *(undefined8 *)(iVar8 + 0x1148) = uVar15;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&arg_30h + iVar13) = uVar5;
    pcVar11 = **(code ***)(iVar8 + 0x1148);
    *(undefined4 *)((int64_t)&arg_28h + iVar13) = *(undefined4 *)((int64_t)&arg_120h + iVar13);
    *(undefined8 *)((int64_t)&var_20h + iVar13) = uVar6;
    *(undefined8 *)((int64_t)&var_18h + iVar13) = uVar7;
    *(undefined8 *)((int64_t)&var_10h + iVar13) = *(undefined8 *)((int64_t)&arg_108h + iVar13);
    *(undefined8 *)((int64_t)&var_8h + iVar13) = *(undefined8 *)((int64_t)&arg_100h + iVar13);
    *(undefined8 *)(&stack0x00000000 + iVar13) = *(undefined8 *)((int64_t)&arg_f8h + iVar13);
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar13) = *(undefined8 *)((int64_t)&arg_f0h + iVar13);
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d8499;
    uVar12 = (*pcVar11)(iVar8, uVar2, uVar10, uVar9);
    uVar14 = (uint64_t)uVar12;
    if (uVar12 == 1) {
        return uVar14;
    }
code_r0x0001801d84a0:
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84a8;
    fcn.1801d80c0(*(int64_t *)((int64_t)&var_8h + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                  *(int64_t *)((int64_t)&var_18h + iVar13));
    *piVar3 = 0;
    return uVar14;
}

// ============================================================
// Function: FUN_1801d834b
// Address: 0x1801d834b
// Size: 432 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint64_t fcn.1801d8260(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_98h,
                      int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_e0h, int64_t arg_e8h,
                      int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                      int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_148h, int64_t arg_150h, int64_t arg_168h, int64_t arg_170h, int64_t arg_178h,
                      int64_t arg_180h, int64_t arg_190h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    code *pcVar11;
    uint32_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801d827d;
    iVar13 = func_0x00018045a350();
    iVar13 = -iVar13;
    piVar3 = *(int64_t **)((int64_t)&arg_190h + iVar13);
    uVar4 = *(undefined8 *)((int64_t)&arg_130h + iVar13);
    uVar5 = *(undefined8 *)((int64_t)&arg_128h + iVar13);
    uVar6 = *(undefined8 *)((int64_t)&arg_118h + iVar13);
    uVar7 = *(undefined8 *)((int64_t)&arg_110h + iVar13);
    uVar2 = *(undefined4 *)((int64_t)&arg_c0h + iVar13);
    *(int64_t **)((int64_t)&arg_60h + iVar13) = piVar3;
    *(undefined8 *)((int64_t)&arg_58h + iVar13) = *(undefined8 *)((int64_t)&arg_180h + iVar13);
    *(undefined8 *)((int64_t)&arg_50h + iVar13) = *(undefined8 *)((int64_t)&arg_178h + iVar13);
    *(undefined8 *)((int64_t)&arg_48h + iVar13) = *(undefined8 *)((int64_t)&arg_170h + iVar13);
    *(undefined8 *)((int64_t)&arg_40h + iVar13) = *(undefined8 *)((int64_t)&arg_168h + iVar13);
    *(undefined8 *)((int64_t)&arg_38h + iVar13) = *(undefined8 *)((int64_t)&arg_150h + iVar13);
    *(undefined8 *)((int64_t)&arg_30h + iVar13) = *(undefined8 *)((int64_t)&arg_148h + iVar13);
    *(undefined8 *)((int64_t)&arg_28h + iVar13) = *(undefined8 *)((int64_t)&arg_140h + iVar13);
    *(undefined8 *)((int64_t)&var_20h + iVar13) = uVar4;
    *(undefined8 *)((int64_t)&var_18h + iVar13) = uVar5;
    *(undefined8 *)((int64_t)&var_10h + iVar13) = uVar6;
    *(undefined8 *)((int64_t)&var_8h + iVar13) = uVar7;
    *(undefined4 *)(&stack0x00000000 + iVar13) = uVar2;
    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar13) = *(undefined4 *)((int64_t)&arg_b8h + iVar13);
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d8342;
    uVar14 = func_0x0001801d6f60();
    if ((int32_t)uVar14 != 1) {
        return uVar14;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar13) = unaff_RBX;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d835b;
    uVar15 = func_0x0001801a67b0();
    *(undefined8 *)(iVar8 + 0x10e0) = uVar15;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d836a;
    uVar15 = func_0x0001801a67b0();
    *(undefined8 *)(iVar8 + 0x10e8) = uVar15;
    iVar8 = *piVar3;
    if ((*(int64_t *)(iVar8 + 0x10e0) == 0) || (*(int64_t *)(iVar8 + 0x10e8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84b8;
        fcn.1801d80c0(*(int64_t *)((int64_t)&var_8h + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                      *(int64_t *)((int64_t)&var_18h + iVar13));
        *piVar3 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84c4;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84dc;
        func_0x0001802295a0(0x1804b4ad0, 0x296, 0x1804b4b10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84ee;
        func_0x0001802296d0(0x14, 0x80014, 0);
        return 0xfffffffe;
    }
    uVar1 = *(undefined2 *)((int64_t)&arg_c8h + iVar13);
    *(undefined4 *)(iVar8 + 0x10) = 1;
    *(undefined2 *)(*piVar3 + 0x30) = uVar1;
    *(undefined4 *)(*piVar3 + 0x1110) = 1;
    if (((in_R8D == 0x100) || (in_R8D == 0xfefd)) || (in_R8D == 0xfeff)) {
        uVar15 = 0x1804b8300;
    } else {
        if (in_R8D != 0x1ffff) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83d5;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83ed;
            func_0x0001802295a0(0x1804b4ad0, 0x2a9, 0x1804b4b10);
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83ff;
            func_0x0001802296d0(0x14, 0xc0103, 0);
            uVar14 = 0xfffffffe;
            goto code_r0x0001801d84a0;
        }
        uVar15 = 0x1804b85e0;
    }
    iVar8 = *piVar3;
    uVar9 = *(undefined8 *)((int64_t)&arg_e8h + iVar13);
    uVar10 = *(undefined8 *)((int64_t)&arg_e0h + iVar13);
    *(undefined8 *)((int64_t)&arg_38h + iVar13) = uVar4;
    *(undefined8 *)(iVar8 + 0x1148) = uVar15;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&arg_30h + iVar13) = uVar5;
    pcVar11 = **(code ***)(iVar8 + 0x1148);
    *(undefined4 *)((int64_t)&arg_28h + iVar13) = *(undefined4 *)((int64_t)&arg_120h + iVar13);
    *(undefined8 *)((int64_t)&var_20h + iVar13) = uVar6;
    *(undefined8 *)((int64_t)&var_18h + iVar13) = uVar7;
    *(undefined8 *)((int64_t)&var_10h + iVar13) = *(undefined8 *)((int64_t)&arg_108h + iVar13);
    *(undefined8 *)((int64_t)&var_8h + iVar13) = *(undefined8 *)((int64_t)&arg_100h + iVar13);
    *(undefined8 *)(&stack0x00000000 + iVar13) = *(undefined8 *)((int64_t)&arg_f8h + iVar13);
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar13) = *(undefined8 *)((int64_t)&arg_f0h + iVar13);
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d8499;
    uVar12 = (*pcVar11)(iVar8, uVar2, uVar10, uVar9);
    uVar14 = (uint64_t)uVar12;
    if (uVar12 == 1) {
        return uVar14;
    }
code_r0x0001801d84a0:
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84a8;
    fcn.1801d80c0(*(int64_t *)((int64_t)&var_8h + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                  *(int64_t *)((int64_t)&var_18h + iVar13));
    *piVar3 = 0;
    return uVar14;
}

// ============================================================
// Function: FUN_1801d84fb
// Address: 0x1801d84fb
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint64_t fcn.1801d8260(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_98h,
                      int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_e0h, int64_t arg_e8h,
                      int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                      int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_148h, int64_t arg_150h, int64_t arg_168h, int64_t arg_170h, int64_t arg_178h,
                      int64_t arg_180h, int64_t arg_190h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    code *pcVar11;
    uint32_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801d827d;
    iVar13 = func_0x00018045a350();
    iVar13 = -iVar13;
    piVar3 = *(int64_t **)((int64_t)&arg_190h + iVar13);
    uVar4 = *(undefined8 *)((int64_t)&arg_130h + iVar13);
    uVar5 = *(undefined8 *)((int64_t)&arg_128h + iVar13);
    uVar6 = *(undefined8 *)((int64_t)&arg_118h + iVar13);
    uVar7 = *(undefined8 *)((int64_t)&arg_110h + iVar13);
    uVar2 = *(undefined4 *)((int64_t)&arg_c0h + iVar13);
    *(int64_t **)((int64_t)&arg_60h + iVar13) = piVar3;
    *(undefined8 *)((int64_t)&arg_58h + iVar13) = *(undefined8 *)((int64_t)&arg_180h + iVar13);
    *(undefined8 *)((int64_t)&arg_50h + iVar13) = *(undefined8 *)((int64_t)&arg_178h + iVar13);
    *(undefined8 *)((int64_t)&arg_48h + iVar13) = *(undefined8 *)((int64_t)&arg_170h + iVar13);
    *(undefined8 *)((int64_t)&arg_40h + iVar13) = *(undefined8 *)((int64_t)&arg_168h + iVar13);
    *(undefined8 *)((int64_t)&arg_38h + iVar13) = *(undefined8 *)((int64_t)&arg_150h + iVar13);
    *(undefined8 *)((int64_t)&arg_30h + iVar13) = *(undefined8 *)((int64_t)&arg_148h + iVar13);
    *(undefined8 *)((int64_t)&arg_28h + iVar13) = *(undefined8 *)((int64_t)&arg_140h + iVar13);
    *(undefined8 *)((int64_t)&var_20h + iVar13) = uVar4;
    *(undefined8 *)((int64_t)&var_18h + iVar13) = uVar5;
    *(undefined8 *)((int64_t)&var_10h + iVar13) = uVar6;
    *(undefined8 *)((int64_t)&var_8h + iVar13) = uVar7;
    *(undefined4 *)(&stack0x00000000 + iVar13) = uVar2;
    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar13) = *(undefined4 *)((int64_t)&arg_b8h + iVar13);
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d8342;
    uVar14 = func_0x0001801d6f60();
    if ((int32_t)uVar14 != 1) {
        return uVar14;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar13) = unaff_RBX;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d835b;
    uVar15 = func_0x0001801a67b0();
    *(undefined8 *)(iVar8 + 0x10e0) = uVar15;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d836a;
    uVar15 = func_0x0001801a67b0();
    *(undefined8 *)(iVar8 + 0x10e8) = uVar15;
    iVar8 = *piVar3;
    if ((*(int64_t *)(iVar8 + 0x10e0) == 0) || (*(int64_t *)(iVar8 + 0x10e8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84b8;
        fcn.1801d80c0(*(int64_t *)((int64_t)&var_8h + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                      *(int64_t *)((int64_t)&var_18h + iVar13));
        *piVar3 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84c4;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84dc;
        func_0x0001802295a0(0x1804b4ad0, 0x296, 0x1804b4b10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84ee;
        func_0x0001802296d0(0x14, 0x80014, 0);
        return 0xfffffffe;
    }
    uVar1 = *(undefined2 *)((int64_t)&arg_c8h + iVar13);
    *(undefined4 *)(iVar8 + 0x10) = 1;
    *(undefined2 *)(*piVar3 + 0x30) = uVar1;
    *(undefined4 *)(*piVar3 + 0x1110) = 1;
    if (((in_R8D == 0x100) || (in_R8D == 0xfefd)) || (in_R8D == 0xfeff)) {
        uVar15 = 0x1804b8300;
    } else {
        if (in_R8D != 0x1ffff) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83d5;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83ed;
            func_0x0001802295a0(0x1804b4ad0, 0x2a9, 0x1804b4b10);
            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d83ff;
            func_0x0001802296d0(0x14, 0xc0103, 0);
            uVar14 = 0xfffffffe;
            goto code_r0x0001801d84a0;
        }
        uVar15 = 0x1804b85e0;
    }
    iVar8 = *piVar3;
    uVar9 = *(undefined8 *)((int64_t)&arg_e8h + iVar13);
    uVar10 = *(undefined8 *)((int64_t)&arg_e0h + iVar13);
    *(undefined8 *)((int64_t)&arg_38h + iVar13) = uVar4;
    *(undefined8 *)(iVar8 + 0x1148) = uVar15;
    iVar8 = *piVar3;
    *(undefined8 *)((int64_t)&arg_30h + iVar13) = uVar5;
    pcVar11 = **(code ***)(iVar8 + 0x1148);
    *(undefined4 *)((int64_t)&arg_28h + iVar13) = *(undefined4 *)((int64_t)&arg_120h + iVar13);
    *(undefined8 *)((int64_t)&var_20h + iVar13) = uVar6;
    *(undefined8 *)((int64_t)&var_18h + iVar13) = uVar7;
    *(undefined8 *)((int64_t)&var_10h + iVar13) = *(undefined8 *)((int64_t)&arg_108h + iVar13);
    *(undefined8 *)((int64_t)&var_8h + iVar13) = *(undefined8 *)((int64_t)&arg_100h + iVar13);
    *(undefined8 *)(&stack0x00000000 + iVar13) = *(undefined8 *)((int64_t)&arg_f8h + iVar13);
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar13) = *(undefined8 *)((int64_t)&arg_f0h + iVar13);
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d8499;
    uVar12 = (*pcVar11)(iVar8, uVar2, uVar10, uVar9);
    uVar14 = (uint64_t)uVar12;
    if (uVar12 == 1) {
        return uVar14;
    }
code_r0x0001801d84a0:
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d84a8;
    fcn.1801d80c0(*(int64_t *)((int64_t)&var_8h + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                  *(int64_t *)((int64_t)&var_18h + iVar13));
    *piVar3 = 0;
    return uVar14;
}

// ============================================================
// Function: FUN_1801d8520
// Address: 0x1801d8520
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801d8520(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t iVar4;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d8530;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = 0;
    if (*(int64_t *)(in_RCX + 0x1020) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d8549;
        uVar3 = fcn.18020e940();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d8551;
        iVar1 = fcn.18020efb0(uVar3);
        if (iVar1 == 2) {
            uVar3 = *(undefined8 *)(in_RCX + 0x1020);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d8562;
            iVar1 = fcn.18020e950(uVar3);
            iVar4 = (int64_t)iVar1;
        }
    }
    return *(int64_t *)(in_RCX + 0x10d8) + 0xd + *(int64_t *)(in_RCX + 0x1030) + iVar4;
}

// ============================================================
// Function: FUN_1801d8590
// Address: 0x1801d8590
// Size: 1677 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801d8590(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined (*pauVar1) [16];
    undefined (*pauVar2) [16];
    uint8_t uVar3;
    code *pcVar4;
    uint8_t *puVar5;
    int64_t *piVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    bool bVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 uVar14;
    uint64_t uVar15;
    undefined8 *puVar16;
    int64_t iVar17;
    int64_t in_RCX;
    uint64_t *puVar18;
    uint32_t uVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d85b2;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    pauVar1 = (undefined (*) [16])(in_RCX + 0x6a0);
    pauVar2 = (undefined (*) [16])(in_RCX + 0x6d0);
    *(undefined8 *)(in_RCX + 0xfd0) = 0;
    *(undefined8 *)(in_RCX + 0xfd8) = 0;
    *(undefined8 *)(in_RCX + 0xfe0) = 0;
    if (*(int64_t *)*pauVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d85e9;
        iVar11 = func_0x0001801d78b0();
        if (iVar11 == 0) {
            return 0xfffffffe;
        }
    }
code_r0x0001801d8600:
    do {
        puVar18 = (uint64_t *)(in_RCX + 0xff8);
        uVar14 = *(undefined8 *)(in_RCX + 0x10e8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d860c;
        iVar13 = func_0x0001801a6800(uVar14);
        if (iVar13 != 0) {
            piVar6 = *(int64_t **)(iVar13 + 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8b4d;
            func_0x0001801d57e0(pauVar1);
            *(int64_t *)(in_RCX + 0xff0) = *piVar6;
            *puVar18 = piVar6[1];
            uVar7 = *(undefined4 *)((int64_t)piVar6 + 0x14);
            uVar8 = *(undefined4 *)(piVar6 + 3);
            uVar9 = *(undefined4 *)((int64_t)piVar6 + 0x1c);
            *(undefined4 *)(in_RCX + 0x6a0) = *(undefined4 *)(piVar6 + 2);
            *(undefined4 *)(in_RCX + 0x6a4) = uVar7;
            *(undefined4 *)(in_RCX + 0x6a8) = uVar8;
            *(undefined4 *)(in_RCX + 0x6ac) = uVar9;
            uVar7 = *(undefined4 *)((int64_t)piVar6 + 0x24);
            uVar8 = *(undefined4 *)(piVar6 + 5);
            uVar9 = *(undefined4 *)((int64_t)piVar6 + 0x2c);
            *(undefined4 *)(in_RCX + 0x6b0) = *(undefined4 *)(piVar6 + 4);
            *(undefined4 *)(in_RCX + 0x6b4) = uVar7;
            *(undefined4 *)(in_RCX + 0x6b8) = uVar8;
            *(undefined4 *)(in_RCX + 0x6bc) = uVar9;
            uVar7 = *(undefined4 *)((int64_t)piVar6 + 0x34);
            uVar8 = *(undefined4 *)(piVar6 + 7);
            uVar9 = *(undefined4 *)((int64_t)piVar6 + 0x3c);
            *(undefined4 *)(in_RCX + 0x6c0) = *(undefined4 *)(piVar6 + 6);
            *(undefined4 *)(in_RCX + 0x6c4) = uVar7;
            *(undefined4 *)(in_RCX + 0x6c8) = uVar8;
            *(undefined4 *)(in_RCX + 0x6cc) = uVar9;
            uVar7 = *(undefined4 *)((int64_t)piVar6 + 0x44);
            uVar8 = *(undefined4 *)(piVar6 + 9);
            uVar9 = *(undefined4 *)((int64_t)piVar6 + 0x4c);
            *(undefined4 *)(in_RCX + 0x6d0) = *(undefined4 *)(piVar6 + 8);
            *(undefined4 *)(in_RCX + 0x6d4) = uVar7;
            *(undefined4 *)(in_RCX + 0x6d8) = uVar8;
            *(undefined4 *)(in_RCX + 0x6dc) = uVar9;
            uVar7 = *(undefined4 *)((int64_t)piVar6 + 0x54);
            uVar8 = *(undefined4 *)(piVar6 + 0xb);
            uVar9 = *(undefined4 *)((int64_t)piVar6 + 0x5c);
            *(undefined4 *)(in_RCX + 0x6e0) = *(undefined4 *)(piVar6 + 10);
            *(undefined4 *)(in_RCX + 0x6e4) = uVar7;
            *(undefined4 *)(in_RCX + 0x6e8) = uVar8;
            *(undefined4 *)(in_RCX + 0x6ec) = uVar9;
            uVar7 = *(undefined4 *)((int64_t)piVar6 + 100);
            uVar8 = *(undefined4 *)(piVar6 + 0xd);
            uVar9 = *(undefined4 *)((int64_t)piVar6 + 0x6c);
            *(undefined4 *)(in_RCX + 0x6f0) = *(undefined4 *)(piVar6 + 0xc);
            *(undefined4 *)(in_RCX + 0x6f4) = uVar7;
            *(undefined4 *)(in_RCX + 0x6f8) = uVar8;
            *(undefined4 *)(in_RCX + 0x6fc) = uVar9;
            uVar7 = *(undefined4 *)((int64_t)piVar6 + 0x74);
            uVar8 = *(undefined4 *)(piVar6 + 0xf);
            uVar9 = *(undefined4 *)((int64_t)piVar6 + 0x7c);
            *(undefined4 *)(in_RCX + 0x700) = *(undefined4 *)(piVar6 + 0xe);
            *(undefined4 *)(in_RCX + 0x704) = uVar7;
            *(undefined4 *)(in_RCX + 0x708) = uVar8;
            *(undefined4 *)(in_RCX + 0x70c) = uVar9;
            *(int64_t *)(in_RCX + 0x710) = piVar6[0x10];
            iVar17 = *piVar6;
            *(undefined4 *)(in_RCX + 0x1002) = *(undefined4 *)(iVar17 + 5);
            *(undefined2 *)(in_RCX + 0x1006) = *(undefined2 *)(iVar17 + 9);
            uVar14 = *(undefined8 *)(iVar13 + 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8be8;
            func_0x000180224990(uVar14, 0x1804b4ad0, 0x167);
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8bf0;
            func_0x0001801a65e0(iVar13);
code_r0x0001801d8bf0:
            *(undefined8 *)(in_RCX + 0xfd0) = 1;
            return 1;
        }
        if ((*(int32_t *)(in_RCX + 0xfe8) == 0xf1) && (0xc < *puVar18)) {
code_r0x0001801d87a5:
            uVar15 = *(uint64_t *)(in_RCX + 0x6d8);
            if (*(int64_t *)(in_RCX + 0xff8) - 0xdU < uVar15) {
                pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x20);
                *(int64_t *)(&stack0x00000000 + iVar12) = (int64_t)&arg_38h + iVar12;
                *(undefined4 *)(&stack0xfffffffffffffff8 + iVar12) = 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d87e7;
                iVar11 = (*pcVar4)(in_RCX, uVar15, uVar15);
                if ((iVar11 < 1) || (*(uint64_t *)((int64_t)&arg_38h + iVar12) != uVar15)) {
                    if (*(int32_t *)(in_RCX + 0x1008) != -1) {
                        return 0xfffffffe;
                    }
                    *(undefined8 *)(in_RCX + 0x6d8) = 0;
                    *(int64_t *)(in_RCX + 0xff8) = 0;
                    goto code_r0x0001801d8600;
                }
            }
            bVar10 = false;
            *(undefined4 *)(in_RCX + 0xfe8) = 0xf0;
            if (*(uint16_t *)(in_RCX + 0x708) == *(uint16_t *)(in_RCX + 0x30)) {
                iVar13 = 0x10f0;
code_r0x0001801d8857:
                puVar16 = (undefined8 *)(in_RCX + 0xff8);
                puVar18 = (uint64_t *)(in_RCX + iVar13);
                if (puVar18 != (uint64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8874;
                    iVar11 = func_0x0001801d9200(in_RCX + 0x1000, puVar18 + 1);
                    if ((iVar11 < 1) &&
                       ((0x3f < (uint32_t)-iVar11 || ((*puVar18 >> ((uint64_t)(uint32_t)-iVar11 & 0x3f) & 1) != 0)))) {
                        *(undefined8 *)(in_RCX + 0x6d8) = 0;
                        *puVar16 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d88ba;
                        func_0x0001801d5820(pauVar2, in_RCX + 0x1000);
                        if (*(int64_t *)(in_RCX + 0x6d8) != 0) {
                            if (bVar10) {
                                if (*(int32_t *)(in_RCX + 0x1110) != 0) {
                                    uVar14 = *(undefined8 *)(in_RCX + 0x10e0);
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d88f0;
                                    uVar15 = func_0x0001801a6810(uVar14);
                                    if (uVar15 < 100) {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8911;
                                        puVar16 = (undefined8 *)func_0x0001802248d0(0x88, 0x1804b4ad0, 0x123);
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8920;
                                        iVar13 = func_0x0001801a6610(in_RCX + 0x70a, puVar16);
                                        if ((puVar16 == (undefined8 *)0x0) || (iVar13 == 0)) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8afc;
                                            func_0x000180224990(puVar16, 0x1804b4ad0, 0x126);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8b04;
                                            func_0x0001801a65e0(iVar13);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8b09;
                                            func_0x000180229480();
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8b21;
                                            func_0x0001802295a0(0x1804b4ad0, 0x128, 0x1804b4af0);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8b37;
                                            func_0x0001801d5640(in_RCX, 0x50, 0xc0103, 0);
                                            return 0xfffffffe;
                                        }
                                        *puVar16 = *(undefined8 *)(in_RCX + 0xff0);
                                        puVar16[1] = *(undefined8 *)(in_RCX + 0xff8);
                                        uVar7 = *(undefined4 *)(in_RCX + 0x6a4);
                                        uVar8 = *(undefined4 *)(in_RCX + 0x6a8);
                                        uVar9 = *(undefined4 *)(in_RCX + 0x6ac);
                                        *(undefined4 *)(puVar16 + 2) = *(undefined4 *)*pauVar1;
                                        *(undefined4 *)((int64_t)puVar16 + 0x14) = uVar7;
                                        *(undefined4 *)(puVar16 + 3) = uVar8;
                                        *(undefined4 *)((int64_t)puVar16 + 0x1c) = uVar9;
                                        uVar7 = *(undefined4 *)(in_RCX + 0x6b4);
                                        uVar8 = *(undefined4 *)(in_RCX + 0x6b8);
                                        uVar9 = *(undefined4 *)(in_RCX + 0x6bc);
                                        *(undefined4 *)(puVar16 + 4) = *(undefined4 *)(in_RCX + 0x6b0);
                                        *(undefined4 *)((int64_t)puVar16 + 0x24) = uVar7;
                                        *(undefined4 *)(puVar16 + 5) = uVar8;
                                        *(undefined4 *)((int64_t)puVar16 + 0x2c) = uVar9;
                                        uVar7 = *(undefined4 *)(in_RCX + 0x6c4);
                                        uVar8 = *(undefined4 *)(in_RCX + 0x6c8);
                                        uVar9 = *(undefined4 *)(in_RCX + 0x6cc);
                                        *(undefined4 *)(puVar16 + 6) = *(undefined4 *)(in_RCX + 0x6c0);
                                        *(undefined4 *)((int64_t)puVar16 + 0x34) = uVar7;
                                        *(undefined4 *)(puVar16 + 7) = uVar8;
                                        *(undefined4 *)((int64_t)puVar16 + 0x3c) = uVar9;
                                        uVar7 = *(undefined4 *)(in_RCX + 0x6d4);
                                        uVar8 = *(undefined4 *)(in_RCX + 0x6d8);
                                        uVar9 = *(undefined4 *)(in_RCX + 0x6dc);
                                        *(undefined4 *)(puVar16 + 8) = *(undefined4 *)*pauVar2;
                                        *(undefined4 *)((int64_t)puVar16 + 0x44) = uVar7;
                                        *(undefined4 *)(puVar16 + 9) = uVar8;
                                        *(undefined4 *)((int64_t)puVar16 + 0x4c) = uVar9;
                                        uVar7 = *(undefined4 *)(in_RCX + 0x6e4);
                                        uVar8 = *(undefined4 *)(in_RCX + 0x6e8);
                                        uVar9 = *(undefined4 *)(in_RCX + 0x6ec);
                                        *(undefined4 *)(puVar16 + 10) = *(undefined4 *)(in_RCX + 0x6e0);
                                        *(undefined4 *)((int64_t)puVar16 + 0x54) = uVar7;
                                        *(undefined4 *)(puVar16 + 0xb) = uVar8;
                                        *(undefined4 *)((int64_t)puVar16 + 0x5c) = uVar9;
                                        uVar7 = *(undefined4 *)(in_RCX + 0x6f4);
                                        uVar8 = *(undefined4 *)(in_RCX + 0x6f8);
                                        uVar9 = *(undefined4 *)(in_RCX + 0x6fc);
                                        *(undefined4 *)(puVar16 + 0xc) = *(undefined4 *)(in_RCX + 0x6f0);
                                        *(undefined4 *)((int64_t)puVar16 + 100) = uVar7;
                                        *(undefined4 *)(puVar16 + 0xd) = uVar8;
                                        *(undefined4 *)((int64_t)puVar16 + 0x6c) = uVar9;
                                        uVar7 = *(undefined4 *)(in_RCX + 0x704);
                                        uVar8 = *(undefined4 *)(in_RCX + 0x708);
                                        uVar9 = *(undefined4 *)(in_RCX + 0x70c);
                                        *(undefined4 *)(puVar16 + 0xe) = *(undefined4 *)(in_RCX + 0x700);
                                        *(undefined4 *)((int64_t)puVar16 + 0x74) = uVar7;
                                        *(undefined4 *)(puVar16 + 0xf) = uVar8;
                                        *(undefined4 *)((int64_t)puVar16 + 0x7c) = uVar9;
                                        puVar16[0x10] = *(undefined8 *)(in_RCX + 0x710);
                                        *(undefined8 **)(iVar13 + 8) = puVar16;
                                        *(undefined8 *)(in_RCX + 0xff0) = 0;
                                        *(undefined8 *)(in_RCX + 0xff8) = 0;
                                        *pauVar1 = ZEXT816(0);
                                        *(undefined (*) [16])(in_RCX + 0x6b0) = ZEXT816(0);
                                        *(undefined (*) [16])(in_RCX + 0x6c0) = ZEXT816(0);
                                        *pauVar2 = ZEXT816(0);
                                        *(undefined (*) [16])(in_RCX + 0x6e0) = ZEXT816(0);
                                        *(undefined (*) [16])(in_RCX + 0x6f0) = ZEXT816(0);
                                        *(undefined (*) [16])(in_RCX + 0x700) = ZEXT816(0);
                                        *(undefined8 *)(in_RCX + 0x710) = 0;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d89dd;
                                        iVar11 = func_0x0001801d78b0(in_RCX);
                                        if (iVar11 == 0) {
                                            uVar14 = puVar16[2];
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8ac0;
                                            func_0x000180224990(uVar14, 0x1804b4ad0, 0x13a);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8ad5;
                                            func_0x000180224990(puVar16, 0x1804b4ad0, 0x13b);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8add;
                                            func_0x0001801a65e0(iVar13);
                                            return 0xfffffffe;
                                        }
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d89f0;
                                        iVar17 = func_0x0001801a6700(uVar14, iVar13);
                                        if (iVar17 == 0) {
                                            uVar14 = puVar16[2];
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8a0b;
                                            func_0x000180224990(uVar14, 0x1804b4ad0, 0x142);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8a20;
                                            func_0x000180224990(puVar16, 0x1804b4ad0, 0x143);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8a28;
                                            func_0x0001801a65e0(iVar13);
                                        }
                                    }
                                }
                                *(undefined8 *)(in_RCX + 0x6d8) = 0;
                                *(undefined8 *)(in_RCX + 0xff8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8a46;
                                iVar11 = func_0x0001801d8db0(in_RCX, puVar18);
                                if (iVar11 == 0) {
                                    if (*(int32_t *)(in_RCX + 0x1008) != -1) {
                                        return 0xfffffffe;
                                    }
                                    *(undefined8 *)(in_RCX + 0x6d8) = 0;
                                    *(undefined8 *)(in_RCX + 0xff8) = 0;
                                } else {
                                    pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x38);
                                    if (pcVar4 != (code *)0x0) {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8a80;
                                        iVar11 = (*pcVar4)(in_RCX, pauVar2);
                                        if (iVar11 == 0) {
                                            return 0xfffffffe;
                                        }
                                    }
                                    if (*(int64_t *)(in_RCX + 0x6d8) != 0) goto code_r0x0001801d8bf0;
                                    *(undefined8 *)(in_RCX + 0xff8) = 0;
                                }
                            }
                        }
                    }
                    goto code_r0x0001801d8600;
                }
            } else if ((uint32_t)*(uint16_t *)(in_RCX + 0x708) == *(uint16_t *)(in_RCX + 0x30) + 1) {
                bVar10 = true;
                iVar13 = 0x1100;
                goto code_r0x0001801d8857;
            }
            *(undefined8 *)(in_RCX + 0x6d8) = 0;
            *(undefined8 *)(in_RCX + 0xff8) = 0;
            goto code_r0x0001801d8600;
        }
        uVar14 = *(undefined8 *)(in_RCX + 0x6b0);
        pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x20);
        *(int64_t *)(&stack0x00000000 + iVar12) = (int64_t)&arg_38h + iVar12;
        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar12) = 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8660;
        uVar14 = (*pcVar4)(in_RCX, 0xd, uVar14, 0);
        if ((int32_t)uVar14 < 1) {
            return uVar14;
        }
        if (*puVar18 == 0xd) {
            puVar5 = *(uint8_t **)(in_RCX + 0xff0);
            *(undefined4 *)(in_RCX + 0xfe8) = 0xf1;
            *(uint32_t *)(in_RCX + 0x6d4) = (uint32_t)*puVar5;
            uVar3 = puVar5[1];
            uVar19 = (uint32_t)CONCAT11(uVar3, puVar5[2]);
            *(uint32_t *)*pauVar2 = uVar19;
            *(uint16_t *)(in_RCX + 0x708) = CONCAT11(puVar5[3], puVar5[4]);
            *(undefined4 *)(in_RCX + 0x1002) = *(undefined4 *)(puVar5 + 5);
            *(undefined2 *)(in_RCX + 0x1006) = *(undefined2 *)(puVar5 + 9);
            *(uint64_t *)(in_RCX + 0x6d8) = (uint64_t)CONCAT11(puVar5[0xb], puVar5[0xc]);
            pcVar4 = *(code **)(in_RCX + 0x1128);
            if (pcVar4 != (code *)0x0) {
                *(undefined8 *)(&stack0x00000000 + iVar12) = *(undefined8 *)(in_RCX + 0x1118);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar12) = 0xd;
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801d8713;
                (*pcVar4)(0, uVar19, 0x100);
            }
            if (((*(int32_t *)(in_RCX + 0x10d4) == 0) && (*(int32_t *)(in_RCX + 0x6d4) != 0x15)) &&
               (*(int32_t *)*pauVar2 != *(int32_t *)(in_RCX + 0x14))) {
                *(undefined8 *)(in_RCX + 0x6d8) = 0;
                *(undefined8 *)(in_RCX + 0xff8) = 0;
            } else {
                if (*(int32_t *)(in_RCX + 0x14) == 0x1ffff) {
                    uVar19 = 0xfe;
                } else {
                    uVar19 = *(int32_t *)(in_RCX + 0x14) >> 8;
                }
                if (uVar3 == uVar19) {
                    if (*(uint64_t *)(in_RCX + 0x6d8) < 0x4541) {
                        if (*(uint64_t *)(in_RCX + 0x6d8) <= (uint64_t)(*(int32_t *)(in_RCX + 0x104c) + 0x140))
                        goto code_r0x0001801d87a5;
                        *(undefined8 *)(in_RCX + 0x6d8) = 0;
                        *(undefined8 *)(in_RCX + 0xff8) = 0;
                    } else {
                        *(undefined8 *)(in_RCX + 0x6d8) = 0;
                        *(undefined8 *)(in_RCX + 0xff8) = 0;
                    }
                } else {
                    *(undefined8 *)(in_RCX + 0x6d8) = 0;
                    *(undefined8 *)(in_RCX + 0xff8) = 0;
                }
            }
        } else {
            *puVar18 = 0;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801d8c20
// Address: 0x1801d8c20
// Size: 56 bytes
// ============================================================
undefined8 fcn.1801d8c20(int64_t arg_58h)
{
    int64_t iVar1;
    char *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int32_t iVar5;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d8c2c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + -8) = *(undefined8 *)((int64_t)&arg_58h + iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d8c41;
    uVar4 = fcn.1801d7360(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
    if ((int32_t)uVar4 == 0) {
        return uVar4;
    }
    *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)(&stack0x00000028 + iVar3);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1801d480c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    pcVar2 = (char *)(in_RCX + 0x1007);
    iVar5 = 8;
    do {
        *pcVar2 = *pcVar2 + '\x01';
        if (*pcVar2 != '\0') break;
        pcVar2 = pcVar2 + -1;
        iVar5 = iVar5 + -1;
    } while (0 < (int64_t)(pcVar2 + (-0xfff - in_RCX)));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x1801d484e;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar1 + iVar3), *(int64_t *)(&stack0x00000050 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x1801d4866;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar1 + iVar3), *(int64_t *)(&stack0x00000050 + iVar1 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar1 + iVar3), *(int64_t *)(&stack0x00000060 + iVar1 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar3) = 0x1801d487c;
        fcn.1801d5640(*(int64_t *)(&stack0x00000070 + iVar1 + iVar3));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d8c60
// Address: 0x1801d8c60
// Size: 327 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801d8c60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined2 uVar1;
    undefined4 uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar7;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d8c80;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar3 = *(undefined8 **)((int64_t)&arg_48h + iVar6);
    *puVar3 = 0;
    iVar7 = *(int64_t *)(in_R8 + 0x10) + 0x400;
    if (*(int64_t *)(in_RCX + 0x1040) == 0) {
        iVar7 = *(int64_t *)(in_R8 + 0x10);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8cc1;
    iVar5 = func_0x0001802446f0(in_RDX, in_R9 & 0xff, 1);
    if (iVar5 != 0) {
        uVar2 = *(undefined4 *)(in_R8 + 4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8cda;
        iVar5 = func_0x0001802446f0(in_RDX, uVar2, 2);
        if (iVar5 != 0) {
            uVar1 = *(undefined2 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8cf0;
            iVar5 = func_0x0001802446f0(in_RDX, uVar1, 2);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8d09;
                iVar5 = func_0x0001802445f0(in_RDX, in_RCX + 0x1002, 6);
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8d1a;
                    iVar5 = func_0x000180244a90(in_RDX, 2);
                    if (iVar5 != 0) {
                        iVar4 = *(int64_t *)(in_RCX + 0x1030);
                        if (iVar4 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8d35;
                            iVar5 = func_0x000180243f60(in_RDX, iVar4, 0);
                            if (iVar5 == 0) goto code_r0x0001801d8d57;
                        }
                        if (iVar7 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8d4c;
                            iVar5 = func_0x000180244860(in_RDX, iVar7, puVar3);
                            if (iVar5 == 0) goto code_r0x0001801d8d57;
                        }
                        return 1;
                    }
                }
            }
        }
    }
code_r0x0001801d8d57:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8d5c;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8d74;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                  *(int64_t *)((int64_t)&arg_48h + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d8d8a;
    fcn.1801d5640(*(int64_t *)((int64_t)&arg_40h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801d8db0
// Address: 0x1801d8db0
// Size: 260 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4400h because it doesn't fit into ProtoModel

void fcn.1801d8db0(int64_t arg_58h, int64_t arg_a8h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    uint64_t *in_RDX;
    uint64_t *puVar11;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d8dc1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_58h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8);
    iVar1 = in_RCX + 0x6d0;
    iVar9 = *(int64_t *)(in_RCX + 0xff0) + 0xd;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    uVar10 = *(uint64_t *)(in_RCX + 0x6d8);
    *(undefined4 *)((int64_t)&var_10h + iVar8) = 0;
    *(int64_t *)(in_RCX + 0x6f8) = iVar9;
    if (0x4540 < uVar10) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e11;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                     );
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e29;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                      , *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e3f;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        goto code_r0x0001801d91dd;
    }
    *(int64_t *)(in_RCX + 0x6f0) = iVar9;
    *(uint64_t *)(in_RCX + 0x6e0) = uVar10;
    uVar10 = 0;
    if (*(int64_t *)(in_RCX + 0x1038) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e5f;
        iVar9 = fcn.18020e940();
        uVar10 = 0;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e6c;
            iVar5 = func_0x00018020f800(iVar9);
            uVar10 = (uint64_t)iVar5;
            if (0x3f < iVar5 - 1U) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e7c;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e94;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8)
                              , *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8eaa;
                fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
                goto code_r0x0001801d91dd;
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar8) = unaff_R15;
    if ((*(int32_t *)(in_RCX + 0x10b0) != 0) && (*(int64_t *)(in_RCX + 0x1038) != 0)) {
        if (*(uint64_t *)(in_RCX + 0x6e0) < uVar10) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ee0;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ef8;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f0e;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
            goto code_r0x0001801d91dd;
        }
        *(int64_t *)(in_RCX + 0x6d8) = *(int64_t *)(in_RCX + 0x6d8) - uVar10;
        iVar9 = *(int64_t *)(in_RCX + 0x6d8);
        iVar2 = *(int64_t *)(in_RCX + 0x6f0);
        pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f3d;
        iVar5 = (*pcVar3)(in_RCX, iVar1, (int64_t)&iStackX_20 + iVar8 + -8, 0);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f51;
            iVar5 = func_0x0001802262e0((int64_t)&iStackX_20 + iVar8 + -8, iVar9 + iVar2, uVar10);
            uVar10 = 0;
            if (iVar5 == 0) goto code_r0x0001801d8f58;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fb7;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                     );
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fcf;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                      , *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fe5;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        goto code_r0x0001801d91dd;
    }
code_r0x0001801d8f58:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f5d;
    func_0x000180229b10();
    iVar9 = *(int64_t *)(in_RCX + 0x1148);
    *(uint64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20) = uVar10;
    pcVar3 = *(code **)(iVar9 + 8);
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar8) = (int64_t)&var_8h + iVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f89;
    iVar5 = (*pcVar3)(in_RCX, iVar1, 1, 0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f95;
        func_0x0001802299d0();
        if (*(int32_t *)(in_RCX + 0x1008) == -1) {
            *(undefined8 *)(in_RCX + 0x6d8) = 0;
            *(undefined8 *)(in_RCX + 0xff8) = 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ff1;
        func_0x000180229900();
        if ((*(int32_t *)(in_RCX + 0x10b0) == 0) && (*(int64_t *)(in_RCX + 0x1020) != 0)) {
            uVar4 = *(undefined8 *)(in_RCX + 0x1038);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d900e;
            iVar9 = fcn.18020e940(uVar4);
            if (iVar9 != 0) {
                pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d902f;
                iVar6 = (*pcVar3)(in_RCX, iVar1, (int64_t)&iStackX_20 + iVar8 + -8, 0);
                if ((iVar6 == 0) || (*(int64_t *)((int64_t)&var_8h + iVar8) == 0)) {
code_r0x0001801d904e:
                    iVar5 = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d904a;
                    iVar6 = func_0x0001802262e0((int64_t)&iStackX_20 + iVar8 + -8, 
                                                *(int64_t *)((int64_t)&var_8h + iVar8), uVar10);
                    if (iVar6 != 0) goto code_r0x0001801d904e;
                }
                if ((uVar10 + 0x4400 < *(uint64_t *)(in_RCX + 0x6d8)) || (iVar5 == 0)) {
                    *(undefined8 *)(in_RCX + 0x6d8) = 0;
                    *(undefined8 *)(in_RCX + 0xff8) = 0;
                    goto code_r0x0001801d91b5;
                }
            }
        }
        if (*(int64_t *)(in_RCX + 0x1040) == 0) {
code_r0x0001801d9109:
            if ((uint64_t)*(uint32_t *)(in_RCX + 0x104c) < *(uint64_t *)(in_RCX + 0x6d8)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d911a;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9132;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8)
                              , *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9148;
                fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
            } else {
                *(undefined8 *)(in_RCX + 0x6e8) = 0;
                puVar11 = in_RDX + 1;
                *(undefined8 *)(in_RCX + 0xff8) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9165;
                uVar7 = func_0x0001801d9200(in_RCX + 0x1000);
                if ((int32_t)uVar7 < 1) {
                    if (-uVar7 < 0x40) {
                        *in_RDX = *in_RDX | 1LL << ((uint64_t)-uVar7 & 0x3f);
                    }
                } else if (uVar7 < 0x40) {
                    *in_RDX = *in_RDX << ((uint8_t)uVar7 & 0x3f) | 1;
                    *puVar11 = *(uint64_t *)(in_RCX + 0x1000);
                } else {
                    *in_RDX = 1;
                    *puVar11 = *(uint64_t *)(in_RCX + 0x1000);
                }
            }
        } else if (*(uint64_t *)(in_RCX + 0x6d8) < 0x4401) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90cd;
            iVar5 = func_0x0001801d5fc0(in_RCX, iVar1);
            if (iVar5 != 0) goto code_r0x0001801d9109;
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90d6;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90ee;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9104;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d908f;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90a7;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90bd;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        }
    }
code_r0x0001801d91b5:
    if (*(int32_t *)((int64_t)&var_10h + iVar8) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d91d3;
        func_0x000180224990(*(undefined8 *)((int64_t)&var_8h + iVar8), 0x1804b4ad0, 0x115);
    }
code_r0x0001801d91dd:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d91ed;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801d8eb4
// Address: 0x1801d8eb4
// Size: 809 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4400h because it doesn't fit into ProtoModel

void fcn.1801d8db0(int64_t arg_58h, int64_t arg_a8h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    uint64_t *in_RDX;
    uint64_t *puVar11;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d8dc1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_58h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8);
    iVar1 = in_RCX + 0x6d0;
    iVar9 = *(int64_t *)(in_RCX + 0xff0) + 0xd;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    uVar10 = *(uint64_t *)(in_RCX + 0x6d8);
    *(undefined4 *)((int64_t)&var_10h + iVar8) = 0;
    *(int64_t *)(in_RCX + 0x6f8) = iVar9;
    if (0x4540 < uVar10) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e11;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                     );
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e29;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                      , *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e3f;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        goto code_r0x0001801d91dd;
    }
    *(int64_t *)(in_RCX + 0x6f0) = iVar9;
    *(uint64_t *)(in_RCX + 0x6e0) = uVar10;
    uVar10 = 0;
    if (*(int64_t *)(in_RCX + 0x1038) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e5f;
        iVar9 = fcn.18020e940();
        uVar10 = 0;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e6c;
            iVar5 = func_0x00018020f800(iVar9);
            uVar10 = (uint64_t)iVar5;
            if (0x3f < iVar5 - 1U) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e7c;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e94;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8)
                              , *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8eaa;
                fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
                goto code_r0x0001801d91dd;
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar8) = unaff_R15;
    if ((*(int32_t *)(in_RCX + 0x10b0) != 0) && (*(int64_t *)(in_RCX + 0x1038) != 0)) {
        if (*(uint64_t *)(in_RCX + 0x6e0) < uVar10) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ee0;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ef8;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f0e;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
            goto code_r0x0001801d91dd;
        }
        *(int64_t *)(in_RCX + 0x6d8) = *(int64_t *)(in_RCX + 0x6d8) - uVar10;
        iVar9 = *(int64_t *)(in_RCX + 0x6d8);
        iVar2 = *(int64_t *)(in_RCX + 0x6f0);
        pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f3d;
        iVar5 = (*pcVar3)(in_RCX, iVar1, (int64_t)&iStackX_20 + iVar8 + -8, 0);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f51;
            iVar5 = func_0x0001802262e0((int64_t)&iStackX_20 + iVar8 + -8, iVar9 + iVar2, uVar10);
            uVar10 = 0;
            if (iVar5 == 0) goto code_r0x0001801d8f58;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fb7;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                     );
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fcf;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                      , *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fe5;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        goto code_r0x0001801d91dd;
    }
code_r0x0001801d8f58:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f5d;
    func_0x000180229b10();
    iVar9 = *(int64_t *)(in_RCX + 0x1148);
    *(uint64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20) = uVar10;
    pcVar3 = *(code **)(iVar9 + 8);
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar8) = (int64_t)&var_8h + iVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f89;
    iVar5 = (*pcVar3)(in_RCX, iVar1, 1, 0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f95;
        func_0x0001802299d0();
        if (*(int32_t *)(in_RCX + 0x1008) == -1) {
            *(undefined8 *)(in_RCX + 0x6d8) = 0;
            *(undefined8 *)(in_RCX + 0xff8) = 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ff1;
        func_0x000180229900();
        if ((*(int32_t *)(in_RCX + 0x10b0) == 0) && (*(int64_t *)(in_RCX + 0x1020) != 0)) {
            uVar4 = *(undefined8 *)(in_RCX + 0x1038);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d900e;
            iVar9 = fcn.18020e940(uVar4);
            if (iVar9 != 0) {
                pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d902f;
                iVar6 = (*pcVar3)(in_RCX, iVar1, (int64_t)&iStackX_20 + iVar8 + -8, 0);
                if ((iVar6 == 0) || (*(int64_t *)((int64_t)&var_8h + iVar8) == 0)) {
code_r0x0001801d904e:
                    iVar5 = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d904a;
                    iVar6 = func_0x0001802262e0((int64_t)&iStackX_20 + iVar8 + -8, 
                                                *(int64_t *)((int64_t)&var_8h + iVar8), uVar10);
                    if (iVar6 != 0) goto code_r0x0001801d904e;
                }
                if ((uVar10 + 0x4400 < *(uint64_t *)(in_RCX + 0x6d8)) || (iVar5 == 0)) {
                    *(undefined8 *)(in_RCX + 0x6d8) = 0;
                    *(undefined8 *)(in_RCX + 0xff8) = 0;
                    goto code_r0x0001801d91b5;
                }
            }
        }
        if (*(int64_t *)(in_RCX + 0x1040) == 0) {
code_r0x0001801d9109:
            if ((uint64_t)*(uint32_t *)(in_RCX + 0x104c) < *(uint64_t *)(in_RCX + 0x6d8)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d911a;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9132;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8)
                              , *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9148;
                fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
            } else {
                *(undefined8 *)(in_RCX + 0x6e8) = 0;
                puVar11 = in_RDX + 1;
                *(undefined8 *)(in_RCX + 0xff8) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9165;
                uVar7 = func_0x0001801d9200(in_RCX + 0x1000);
                if ((int32_t)uVar7 < 1) {
                    if (-uVar7 < 0x40) {
                        *in_RDX = *in_RDX | 1LL << ((uint64_t)-uVar7 & 0x3f);
                    }
                } else if (uVar7 < 0x40) {
                    *in_RDX = *in_RDX << ((uint8_t)uVar7 & 0x3f) | 1;
                    *puVar11 = *(uint64_t *)(in_RCX + 0x1000);
                } else {
                    *in_RDX = 1;
                    *puVar11 = *(uint64_t *)(in_RCX + 0x1000);
                }
            }
        } else if (*(uint64_t *)(in_RCX + 0x6d8) < 0x4401) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90cd;
            iVar5 = func_0x0001801d5fc0(in_RCX, iVar1);
            if (iVar5 != 0) goto code_r0x0001801d9109;
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90d6;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90ee;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9104;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d908f;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90a7;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90bd;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        }
    }
code_r0x0001801d91b5:
    if (*(int32_t *)((int64_t)&var_10h + iVar8) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d91d3;
        func_0x000180224990(*(undefined8 *)((int64_t)&var_8h + iVar8), 0x1804b4ad0, 0x115);
    }
code_r0x0001801d91dd:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d91ed;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801d91dd
// Address: 0x1801d91dd
// Size: 30 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_4400h because it doesn't fit into ProtoModel

void fcn.1801d8db0(int64_t arg_58h, int64_t arg_a8h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    uint64_t *in_RDX;
    uint64_t *puVar11;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d8dc1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_58h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8);
    iVar1 = in_RCX + 0x6d0;
    iVar9 = *(int64_t *)(in_RCX + 0xff0) + 0xd;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = 0;
    uVar10 = *(uint64_t *)(in_RCX + 0x6d8);
    *(undefined4 *)((int64_t)&var_10h + iVar8) = 0;
    *(int64_t *)(in_RCX + 0x6f8) = iVar9;
    if (0x4540 < uVar10) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e11;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                     );
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e29;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                      , *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e3f;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        goto code_r0x0001801d91dd;
    }
    *(int64_t *)(in_RCX + 0x6f0) = iVar9;
    *(uint64_t *)(in_RCX + 0x6e0) = uVar10;
    uVar10 = 0;
    if (*(int64_t *)(in_RCX + 0x1038) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e5f;
        iVar9 = fcn.18020e940();
        uVar10 = 0;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e6c;
            iVar5 = func_0x00018020f800(iVar9);
            uVar10 = (uint64_t)iVar5;
            if (0x3f < iVar5 - 1U) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e7c;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8e94;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8)
                              , *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8eaa;
                fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
                goto code_r0x0001801d91dd;
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_a8h + iVar8) = unaff_R15;
    if ((*(int32_t *)(in_RCX + 0x10b0) != 0) && (*(int64_t *)(in_RCX + 0x1038) != 0)) {
        if (*(uint64_t *)(in_RCX + 0x6e0) < uVar10) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ee0;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ef8;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f0e;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
            goto code_r0x0001801d91dd;
        }
        *(int64_t *)(in_RCX + 0x6d8) = *(int64_t *)(in_RCX + 0x6d8) - uVar10;
        iVar9 = *(int64_t *)(in_RCX + 0x6d8);
        iVar2 = *(int64_t *)(in_RCX + 0x6f0);
        pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f3d;
        iVar5 = (*pcVar3)(in_RCX, iVar1, (int64_t)&iStackX_20 + iVar8 + -8, 0);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f51;
            iVar5 = func_0x0001802262e0((int64_t)&iStackX_20 + iVar8 + -8, iVar9 + iVar2, uVar10);
            uVar10 = 0;
            if (iVar5 == 0) goto code_r0x0001801d8f58;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fb7;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                     );
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fcf;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20)
                      , *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8fe5;
        fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        goto code_r0x0001801d91dd;
    }
code_r0x0001801d8f58:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f5d;
    func_0x000180229b10();
    iVar9 = *(int64_t *)(in_RCX + 0x1148);
    *(uint64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20) = uVar10;
    pcVar3 = *(code **)(iVar9 + 8);
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar8) = (int64_t)&var_8h + iVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f89;
    iVar5 = (*pcVar3)(in_RCX, iVar1, 1, 0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8f95;
        func_0x0001802299d0();
        if (*(int32_t *)(in_RCX + 0x1008) == -1) {
            *(undefined8 *)(in_RCX + 0x6d8) = 0;
            *(undefined8 *)(in_RCX + 0xff8) = 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d8ff1;
        func_0x000180229900();
        if ((*(int32_t *)(in_RCX + 0x10b0) == 0) && (*(int64_t *)(in_RCX + 0x1020) != 0)) {
            uVar4 = *(undefined8 *)(in_RCX + 0x1038);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d900e;
            iVar9 = fcn.18020e940(uVar4);
            if (iVar9 != 0) {
                pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d902f;
                iVar6 = (*pcVar3)(in_RCX, iVar1, (int64_t)&iStackX_20 + iVar8 + -8, 0);
                if ((iVar6 == 0) || (*(int64_t *)((int64_t)&var_8h + iVar8) == 0)) {
code_r0x0001801d904e:
                    iVar5 = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d904a;
                    iVar6 = func_0x0001802262e0((int64_t)&iStackX_20 + iVar8 + -8, 
                                                *(int64_t *)((int64_t)&var_8h + iVar8), uVar10);
                    if (iVar6 != 0) goto code_r0x0001801d904e;
                }
                if ((uVar10 + 0x4400 < *(uint64_t *)(in_RCX + 0x6d8)) || (iVar5 == 0)) {
                    *(undefined8 *)(in_RCX + 0x6d8) = 0;
                    *(undefined8 *)(in_RCX + 0xff8) = 0;
                    goto code_r0x0001801d91b5;
                }
            }
        }
        if (*(int64_t *)(in_RCX + 0x1040) == 0) {
code_r0x0001801d9109:
            if ((uint64_t)*(uint32_t *)(in_RCX + 0x104c) < *(uint64_t *)(in_RCX + 0x6d8)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d911a;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9132;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8)
                              , *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9148;
                fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
            } else {
                *(undefined8 *)(in_RCX + 0x6e8) = 0;
                puVar11 = in_RDX + 1;
                *(undefined8 *)(in_RCX + 0xff8) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9165;
                uVar7 = func_0x0001801d9200(in_RCX + 0x1000);
                if ((int32_t)uVar7 < 1) {
                    if (-uVar7 < 0x40) {
                        *in_RDX = *in_RDX | 1LL << ((uint64_t)-uVar7 & 0x3f);
                    }
                } else if (uVar7 < 0x40) {
                    *in_RDX = *in_RDX << ((uint8_t)uVar7 & 0x3f) | 1;
                    *puVar11 = *(uint64_t *)(in_RCX + 0x1000);
                } else {
                    *in_RDX = 1;
                    *puVar11 = *(uint64_t *)(in_RCX + 0x1000);
                }
            }
        } else if (*(uint64_t *)(in_RCX + 0x6d8) < 0x4401) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90cd;
            iVar5 = func_0x0001801d5fc0(in_RCX, iVar1);
            if (iVar5 != 0) goto code_r0x0001801d9109;
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90d6;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90ee;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d9104;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d908f;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90a7;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar8 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d90bd;
            fcn.1801d5640(*(int64_t *)((int64_t)&iStackX_20 + iVar8));
        }
    }
code_r0x0001801d91b5:
    if (*(int32_t *)((int64_t)&var_10h + iVar8) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d91d3;
        func_0x000180224990(*(undefined8 *)((int64_t)&var_8h + iVar8), 0x1804b4ad0, 0x115);
    }
code_r0x0001801d91dd:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801d91ed;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801d92f0
// Address: 0x1801d92f0
// Size: 309 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801d92f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_1c0h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_198h;
    undefined4 uStack_190;
    undefined4 uStack_18c;
    int64_t var_188h;
    undefined4 uStack_180;
    undefined4 uStack_17c;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    int64_t var_160h;
    undefined4 uStack_158;
    undefined4 uStack_154;
    int64_t var_150h;
    int64_t var_148h;
    undefined4 uStack_140;
    undefined4 uStack_13c;
    undefined4 uStack_138;
    undefined4 uStack_134;
    undefined4 uStack_130;
    undefined4 uStack_12c;
    int64_t var_128h;
    int64_t var_120h;
    undefined4 uStack_118;
    undefined4 uStack_114;
    int64_t var_110h;
    undefined4 uStack_108;
    undefined4 uStack_104;
    int64_t var_100h;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    int64_t var_d0h;
    undefined4 uStack_c8;
    undefined4 uStack_c4;
    int64_t var_c0h;
    undefined4 uStack_b8;
    undefined4 uStack_b4;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_88h;
    int64_t var_80h;
    undefined4 uStack_78;
    undefined4 uStack_74;
    int64_t var_70h;
    undefined4 uStack_68;
    undefined4 uStack_64;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801d930e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4);
    *(int64_t *)((int64_t)&var_8h + iVar4) = arg_28h;
    *(int64_t *)((int64_t)&iStackX_8 + iVar4) = arg_30h;
    *(int64_t *)(&stack0x00000000 + iVar4) = arg_38h;
    *(int64_t *)((int64_t)&var_18h + iVar4) = arg_40h;
    *(int64_t *)((int64_t)&var_10h + iVar4) = arg_48h;
    *(int64_t *)((int64_t)&arg_28h + iVar4) = arg_50h;
    *(int64_t *)((int64_t)&var_20h + iVar4) = arg_58h;
    *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = arg_60h;
    *(int64_t *)(&stack0xffffffffffffffe8 + iVar4) = arg_68h;
    *(int64_t *)((int64_t)&arg_30h + iVar4) = arg_70h;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93ab;
    iVar5 = func_0x0001801a0900();
    iVar7 = 0;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93ba;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
        if ((int32_t)arg_80h == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9401;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9413;
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93da;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93f0;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        }
    } else {
        puVar1 = *(undefined8 **)(in_RCX + 8);
        *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RSI;
        uVar8 = puVar1[0x8c];
        uVar2 = *puVar1;
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d943c;
        iVar6 = func_0x00018025f200(uVar2, 0x1804b4b68, uVar8);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9450;
            iVar7 = func_0x00018025f910(iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d945b;
            func_0x00018025f250(iVar6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d946c;
                uVar8 = func_0x00018020f750(iVar5);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9483;
                puVar9 = (undefined4 *)func_0x000180229e30((int64_t)&arg_38h + iVar4, 0x1804af254, uVar8, 0);
                var_198h._0_4_ = *puVar9;
                var_198h._4_4_ = puVar9[1];
                uStack_190 = puVar9[2];
                uStack_18c = puVar9[3];
                var_188h._0_4_ = puVar9[4];
                var_188h._4_4_ = puVar9[5];
                uStack_180 = puVar9[6];
                uStack_17c = puVar9[7];
                var_178h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d94b7;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b74, 
                                             *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4), 
                                             *(undefined8 *)(&stack0xffffffffffffffe8 + iVar4));
                var_170h._0_4_ = *puVar9;
                var_170h._4_4_ = puVar9[1];
                uStack_168 = puVar9[2];
                uStack_164 = puVar9[3];
                var_160h._0_4_ = puVar9[4];
                var_160h._4_4_ = puVar9[5];
                uStack_158 = puVar9[6];
                uStack_154 = puVar9[7];
                var_150h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d94e7;
                puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, in_RDX, in_R8);
                var_148h._0_4_ = *puVar9;
                var_148h._4_4_ = puVar9[1];
                uStack_140 = puVar9[2];
                uStack_13c = puVar9[3];
                uStack_138 = puVar9[4];
                uStack_134 = puVar9[5];
                uStack_130 = puVar9[6];
                uStack_12c = puVar9[7];
                var_128h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9519;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, in_R9, 
                                             *(undefined8 *)((int64_t)&var_8h + iVar4));
                var_120h._0_4_ = *puVar9;
                var_120h._4_4_ = puVar9[1];
                uStack_118 = puVar9[2];
                uStack_114 = puVar9[3];
                var_110h._0_4_ = puVar9[4];
                var_110h._4_4_ = puVar9[5];
                uStack_108 = puVar9[6];
                uStack_104 = puVar9[7];
                var_100h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d954d;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&iStackX_8 + iVar4), 
                                             *(undefined8 *)(&stack0x00000000 + iVar4));
                var_f8h._0_4_ = *puVar9;
                var_f8h._4_4_ = puVar9[1];
                uStack_f0 = puVar9[2];
                uStack_ec = puVar9[3];
                var_e8h._0_4_ = puVar9[4];
                var_e8h._4_4_ = puVar9[5];
                uStack_e0 = puVar9[6];
                uStack_dc = puVar9[7];
                var_d8h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9581;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&var_18h + iVar4), 
                                             *(undefined8 *)((int64_t)&var_10h + iVar4));
                var_d0h._0_4_ = *puVar9;
                var_d0h._4_4_ = puVar9[1];
                uStack_c8 = puVar9[2];
                uStack_c4 = puVar9[3];
                var_c0h._0_4_ = puVar9[4];
                var_c0h._4_4_ = puVar9[5];
                uStack_b8 = puVar9[6];
                uStack_b4 = puVar9[7];
                var_b0h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d95b8;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&arg_28h + iVar4), 
                                             *(undefined8 *)((int64_t)&var_20h + iVar4));
                var_a8h._0_4_ = *puVar9;
                var_a8h._4_4_ = puVar9[1];
                uStack_a0 = puVar9[2];
                uStack_9c = puVar9[3];
                var_98h._0_4_ = puVar9[4];
                var_98h._4_4_ = puVar9[5];
                uStack_90 = puVar9[6];
                uStack_8c = puVar9[7];
                var_88h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d95e4;
                puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_38h + iVar4);
                var_80h._0_4_ = *puVar9;
                var_80h._4_4_ = puVar9[1];
                uStack_78 = puVar9[2];
                uStack_74 = puVar9[3];
                var_70h._0_4_ = puVar9[4];
                var_70h._4_4_ = puVar9[5];
                uStack_68 = puVar9[6];
                uStack_64 = puVar9[7];
                var_60h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d961e;
                iVar3 = func_0x00018025fa30(iVar7, *(undefined8 *)((int64_t)&arg_30h + iVar4), arg_78h, &var_198h);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d962a;
                    func_0x00018025f7a0(iVar7);
                    goto code_r0x0001801d969d;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9636;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
        if ((int32_t)arg_80h == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9679;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d968b;
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9657;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d966d;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9693;
        func_0x00018025f7a0(iVar7);
    }
code_r0x0001801d969d:
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d96ac;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801d9425
// Address: 0x1801d9425
// Size: 632 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801d92f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_1c0h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_198h;
    undefined4 uStack_190;
    undefined4 uStack_18c;
    int64_t var_188h;
    undefined4 uStack_180;
    undefined4 uStack_17c;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    int64_t var_160h;
    undefined4 uStack_158;
    undefined4 uStack_154;
    int64_t var_150h;
    int64_t var_148h;
    undefined4 uStack_140;
    undefined4 uStack_13c;
    undefined4 uStack_138;
    undefined4 uStack_134;
    undefined4 uStack_130;
    undefined4 uStack_12c;
    int64_t var_128h;
    int64_t var_120h;
    undefined4 uStack_118;
    undefined4 uStack_114;
    int64_t var_110h;
    undefined4 uStack_108;
    undefined4 uStack_104;
    int64_t var_100h;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    int64_t var_d0h;
    undefined4 uStack_c8;
    undefined4 uStack_c4;
    int64_t var_c0h;
    undefined4 uStack_b8;
    undefined4 uStack_b4;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_88h;
    int64_t var_80h;
    undefined4 uStack_78;
    undefined4 uStack_74;
    int64_t var_70h;
    undefined4 uStack_68;
    undefined4 uStack_64;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801d930e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4);
    *(int64_t *)((int64_t)&var_8h + iVar4) = arg_28h;
    *(int64_t *)((int64_t)&iStackX_8 + iVar4) = arg_30h;
    *(int64_t *)(&stack0x00000000 + iVar4) = arg_38h;
    *(int64_t *)((int64_t)&var_18h + iVar4) = arg_40h;
    *(int64_t *)((int64_t)&var_10h + iVar4) = arg_48h;
    *(int64_t *)((int64_t)&arg_28h + iVar4) = arg_50h;
    *(int64_t *)((int64_t)&var_20h + iVar4) = arg_58h;
    *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = arg_60h;
    *(int64_t *)(&stack0xffffffffffffffe8 + iVar4) = arg_68h;
    *(int64_t *)((int64_t)&arg_30h + iVar4) = arg_70h;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93ab;
    iVar5 = func_0x0001801a0900();
    iVar7 = 0;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93ba;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
        if ((int32_t)arg_80h == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9401;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9413;
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93da;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93f0;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        }
    } else {
        puVar1 = *(undefined8 **)(in_RCX + 8);
        *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RSI;
        uVar8 = puVar1[0x8c];
        uVar2 = *puVar1;
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d943c;
        iVar6 = func_0x00018025f200(uVar2, 0x1804b4b68, uVar8);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9450;
            iVar7 = func_0x00018025f910(iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d945b;
            func_0x00018025f250(iVar6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d946c;
                uVar8 = func_0x00018020f750(iVar5);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9483;
                puVar9 = (undefined4 *)func_0x000180229e30((int64_t)&arg_38h + iVar4, 0x1804af254, uVar8, 0);
                var_198h._0_4_ = *puVar9;
                var_198h._4_4_ = puVar9[1];
                uStack_190 = puVar9[2];
                uStack_18c = puVar9[3];
                var_188h._0_4_ = puVar9[4];
                var_188h._4_4_ = puVar9[5];
                uStack_180 = puVar9[6];
                uStack_17c = puVar9[7];
                var_178h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d94b7;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b74, 
                                             *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4), 
                                             *(undefined8 *)(&stack0xffffffffffffffe8 + iVar4));
                var_170h._0_4_ = *puVar9;
                var_170h._4_4_ = puVar9[1];
                uStack_168 = puVar9[2];
                uStack_164 = puVar9[3];
                var_160h._0_4_ = puVar9[4];
                var_160h._4_4_ = puVar9[5];
                uStack_158 = puVar9[6];
                uStack_154 = puVar9[7];
                var_150h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d94e7;
                puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, in_RDX, in_R8);
                var_148h._0_4_ = *puVar9;
                var_148h._4_4_ = puVar9[1];
                uStack_140 = puVar9[2];
                uStack_13c = puVar9[3];
                uStack_138 = puVar9[4];
                uStack_134 = puVar9[5];
                uStack_130 = puVar9[6];
                uStack_12c = puVar9[7];
                var_128h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9519;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, in_R9, 
                                             *(undefined8 *)((int64_t)&var_8h + iVar4));
                var_120h._0_4_ = *puVar9;
                var_120h._4_4_ = puVar9[1];
                uStack_118 = puVar9[2];
                uStack_114 = puVar9[3];
                var_110h._0_4_ = puVar9[4];
                var_110h._4_4_ = puVar9[5];
                uStack_108 = puVar9[6];
                uStack_104 = puVar9[7];
                var_100h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d954d;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&iStackX_8 + iVar4), 
                                             *(undefined8 *)(&stack0x00000000 + iVar4));
                var_f8h._0_4_ = *puVar9;
                var_f8h._4_4_ = puVar9[1];
                uStack_f0 = puVar9[2];
                uStack_ec = puVar9[3];
                var_e8h._0_4_ = puVar9[4];
                var_e8h._4_4_ = puVar9[5];
                uStack_e0 = puVar9[6];
                uStack_dc = puVar9[7];
                var_d8h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9581;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&var_18h + iVar4), 
                                             *(undefined8 *)((int64_t)&var_10h + iVar4));
                var_d0h._0_4_ = *puVar9;
                var_d0h._4_4_ = puVar9[1];
                uStack_c8 = puVar9[2];
                uStack_c4 = puVar9[3];
                var_c0h._0_4_ = puVar9[4];
                var_c0h._4_4_ = puVar9[5];
                uStack_b8 = puVar9[6];
                uStack_b4 = puVar9[7];
                var_b0h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d95b8;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&arg_28h + iVar4), 
                                             *(undefined8 *)((int64_t)&var_20h + iVar4));
                var_a8h._0_4_ = *puVar9;
                var_a8h._4_4_ = puVar9[1];
                uStack_a0 = puVar9[2];
                uStack_9c = puVar9[3];
                var_98h._0_4_ = puVar9[4];
                var_98h._4_4_ = puVar9[5];
                uStack_90 = puVar9[6];
                uStack_8c = puVar9[7];
                var_88h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d95e4;
                puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_38h + iVar4);
                var_80h._0_4_ = *puVar9;
                var_80h._4_4_ = puVar9[1];
                uStack_78 = puVar9[2];
                uStack_74 = puVar9[3];
                var_70h._0_4_ = puVar9[4];
                var_70h._4_4_ = puVar9[5];
                uStack_68 = puVar9[6];
                uStack_64 = puVar9[7];
                var_60h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d961e;
                iVar3 = func_0x00018025fa30(iVar7, *(undefined8 *)((int64_t)&arg_30h + iVar4), arg_78h, &var_198h);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d962a;
                    func_0x00018025f7a0(iVar7);
                    goto code_r0x0001801d969d;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9636;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
        if ((int32_t)arg_80h == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9679;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d968b;
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9657;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d966d;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9693;
        func_0x00018025f7a0(iVar7);
    }
code_r0x0001801d969d:
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d96ac;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801d969d
// Address: 0x1801d969d
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801d92f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_1c0h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_198h;
    undefined4 uStack_190;
    undefined4 uStack_18c;
    int64_t var_188h;
    undefined4 uStack_180;
    undefined4 uStack_17c;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    int64_t var_160h;
    undefined4 uStack_158;
    undefined4 uStack_154;
    int64_t var_150h;
    int64_t var_148h;
    undefined4 uStack_140;
    undefined4 uStack_13c;
    undefined4 uStack_138;
    undefined4 uStack_134;
    undefined4 uStack_130;
    undefined4 uStack_12c;
    int64_t var_128h;
    int64_t var_120h;
    undefined4 uStack_118;
    undefined4 uStack_114;
    int64_t var_110h;
    undefined4 uStack_108;
    undefined4 uStack_104;
    int64_t var_100h;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    int64_t var_d0h;
    undefined4 uStack_c8;
    undefined4 uStack_c4;
    int64_t var_c0h;
    undefined4 uStack_b8;
    undefined4 uStack_b4;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_88h;
    int64_t var_80h;
    undefined4 uStack_78;
    undefined4 uStack_74;
    int64_t var_70h;
    undefined4 uStack_68;
    undefined4 uStack_64;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x1801d930e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4);
    *(int64_t *)((int64_t)&var_8h + iVar4) = arg_28h;
    *(int64_t *)((int64_t)&iStackX_8 + iVar4) = arg_30h;
    *(int64_t *)(&stack0x00000000 + iVar4) = arg_38h;
    *(int64_t *)((int64_t)&var_18h + iVar4) = arg_40h;
    *(int64_t *)((int64_t)&var_10h + iVar4) = arg_48h;
    *(int64_t *)((int64_t)&arg_28h + iVar4) = arg_50h;
    *(int64_t *)((int64_t)&var_20h + iVar4) = arg_58h;
    *(int64_t *)(&stack0xfffffffffffffff0 + iVar4) = arg_60h;
    *(int64_t *)(&stack0xffffffffffffffe8 + iVar4) = arg_68h;
    *(int64_t *)((int64_t)&arg_30h + iVar4) = arg_70h;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93ab;
    iVar5 = func_0x0001801a0900();
    iVar7 = 0;
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93ba;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
        if ((int32_t)arg_80h == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9401;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9413;
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93da;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d93f0;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        }
    } else {
        puVar1 = *(undefined8 **)(in_RCX + 8);
        *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RSI;
        uVar8 = puVar1[0x8c];
        uVar2 = *puVar1;
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d943c;
        iVar6 = func_0x00018025f200(uVar2, 0x1804b4b68, uVar8);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9450;
            iVar7 = func_0x00018025f910(iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d945b;
            func_0x00018025f250(iVar6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d946c;
                uVar8 = func_0x00018020f750(iVar5);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9483;
                puVar9 = (undefined4 *)func_0x000180229e30((int64_t)&arg_38h + iVar4, 0x1804af254, uVar8, 0);
                var_198h._0_4_ = *puVar9;
                var_198h._4_4_ = puVar9[1];
                uStack_190 = puVar9[2];
                uStack_18c = puVar9[3];
                var_188h._0_4_ = puVar9[4];
                var_188h._4_4_ = puVar9[5];
                uStack_180 = puVar9[6];
                uStack_17c = puVar9[7];
                var_178h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d94b7;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b74, 
                                             *(undefined8 *)(&stack0xfffffffffffffff0 + iVar4), 
                                             *(undefined8 *)(&stack0xffffffffffffffe8 + iVar4));
                var_170h._0_4_ = *puVar9;
                var_170h._4_4_ = puVar9[1];
                uStack_168 = puVar9[2];
                uStack_164 = puVar9[3];
                var_160h._0_4_ = puVar9[4];
                var_160h._4_4_ = puVar9[5];
                uStack_158 = puVar9[6];
                uStack_154 = puVar9[7];
                var_150h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d94e7;
                puVar9 = (undefined4 *)func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, in_RDX, in_R8);
                var_148h._0_4_ = *puVar9;
                var_148h._4_4_ = puVar9[1];
                uStack_140 = puVar9[2];
                uStack_13c = puVar9[3];
                uStack_138 = puVar9[4];
                uStack_134 = puVar9[5];
                uStack_130 = puVar9[6];
                uStack_12c = puVar9[7];
                var_128h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9519;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, in_R9, 
                                             *(undefined8 *)((int64_t)&var_8h + iVar4));
                var_120h._0_4_ = *puVar9;
                var_120h._4_4_ = puVar9[1];
                uStack_118 = puVar9[2];
                uStack_114 = puVar9[3];
                var_110h._0_4_ = puVar9[4];
                var_110h._4_4_ = puVar9[5];
                uStack_108 = puVar9[6];
                uStack_104 = puVar9[7];
                var_100h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d954d;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&iStackX_8 + iVar4), 
                                             *(undefined8 *)(&stack0x00000000 + iVar4));
                var_f8h._0_4_ = *puVar9;
                var_f8h._4_4_ = puVar9[1];
                uStack_f0 = puVar9[2];
                uStack_ec = puVar9[3];
                var_e8h._0_4_ = puVar9[4];
                var_e8h._4_4_ = puVar9[5];
                uStack_e0 = puVar9[6];
                uStack_dc = puVar9[7];
                var_d8h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9581;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&var_18h + iVar4), 
                                             *(undefined8 *)((int64_t)&var_10h + iVar4));
                var_d0h._0_4_ = *puVar9;
                var_d0h._4_4_ = puVar9[1];
                uStack_c8 = puVar9[2];
                uStack_c4 = puVar9[3];
                var_c0h._0_4_ = puVar9[4];
                var_c0h._4_4_ = puVar9[5];
                uStack_b8 = puVar9[6];
                uStack_b4 = puVar9[7];
                var_b0h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d95b8;
                puVar9 = (undefined4 *)
                         func_0x000180229c70((int64_t)&arg_38h + iVar4, 0x1804b4b7c, 
                                             *(undefined8 *)((int64_t)&arg_28h + iVar4), 
                                             *(undefined8 *)((int64_t)&var_20h + iVar4));
                var_a8h._0_4_ = *puVar9;
                var_a8h._4_4_ = puVar9[1];
                uStack_a0 = puVar9[2];
                uStack_9c = puVar9[3];
                var_98h._0_4_ = puVar9[4];
                var_98h._4_4_ = puVar9[5];
                uStack_90 = puVar9[6];
                uStack_8c = puVar9[7];
                var_88h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d95e4;
                puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_38h + iVar4);
                var_80h._0_4_ = *puVar9;
                var_80h._4_4_ = puVar9[1];
                uStack_78 = puVar9[2];
                uStack_74 = puVar9[3];
                var_70h._0_4_ = puVar9[4];
                var_70h._4_4_ = puVar9[5];
                uStack_68 = puVar9[6];
                uStack_64 = puVar9[7];
                var_60h = *(int64_t *)(puVar9 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d961e;
                iVar3 = func_0x00018025fa30(iVar7, *(undefined8 *)((int64_t)&arg_30h + iVar4), arg_78h, &var_198h);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d962a;
                    func_0x00018025f7a0(iVar7);
                    goto code_r0x0001801d969d;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9636;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
        if ((int32_t)arg_80h == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9679;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d968b;
            func_0x0001802296d0(0x14, 0xc0103, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9657;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4)
                          , *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d966d;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d9693;
        func_0x00018025f7a0(iVar7);
    }
code_r0x0001801d969d:
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801d96ac;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801d98b0
// Address: 0x1801d98b0
// Size: 811 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801d98b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_b8h, int64_t arg_c0h,
                  int64_t arg_c8h, int64_t arg_d0h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t iVar8;
    uint32_t uVar9;
    uint64_t in_RDX;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801d98ca;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar2 = *(undefined8 *)(in_RCX + 0x370);
    iVar3 = *(int64_t *)(in_RCX + 0x368);
    iVar4 = *(int64_t *)(in_RCX + 0x388);
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = *(undefined8 *)(in_RCX + 0x378);
    *(undefined4 *)((int64_t)&arg_c8h + iVar7) = *(undefined4 *)(in_RCX + 0x380);
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = *(undefined8 *)(in_RCX + 0x390);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d991b;
    iVar5 = func_0x00018020efa0(uVar2);
    iVar12 = (int64_t)iVar5;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d9926;
    iVar5 = fcn.18020efb0(uVar2);
    if (iVar5 == 6) {
code_r0x0001801d994c:
        iVar5 = 4;
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d9933;
        iVar5 = fcn.18020efb0(uVar2);
        if (iVar5 == 7) goto code_r0x0001801d994c;
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d9940;
        iVar5 = func_0x00018020ef90(uVar2);
        if (iVar5 < 0) goto code_r0x0001801d99bd;
    }
    iVar13 = (int64_t)iVar5;
    if (((int32_t)in_RDX == 0x12) || ((int32_t)in_RDX == 0x21)) {
        iVar8 = iVar4 * 2;
        *(int64_t *)((int64_t)&arg_d0h + iVar7) = iVar3;
        iVar10 = iVar8 + iVar12 * 2;
        uVar11 = iVar10 + iVar13 * 2;
    } else {
        iVar8 = iVar4 * 2 + iVar12;
        *(int64_t *)((int64_t)&arg_d0h + iVar7) = iVar4 + iVar3;
        iVar10 = iVar8 + iVar13 + iVar12;
        uVar11 = iVar10 + iVar13;
    }
    *(int64_t *)((int64_t)&arg_68h + iVar7) = iVar10 + iVar3;
    *(int64_t *)((int64_t)&arg_70h + iVar7) = iVar8 + iVar3;
    if (*(uint64_t *)(in_RCX + 0x360) < uVar11) {
code_r0x0001801d99bd:
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d99dc;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d99ea;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d99fa;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d9a09;
    iVar5 = fcn.18020efb0(uVar2);
    if (iVar5 != 6) {
        if (iVar5 == 7) {
            uVar9 = 8;
            if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x24) & 0x30000) == 0) {
                uVar9 = 0x10;
            }
            uVar11 = (uint64_t)uVar9;
            goto code_r0x0001801d9a53;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d9a22;
        iVar5 = func_0x00018020f2b0(uVar2, 0x1804adae8);
        if (iVar5 == 0) {
            uVar11 = *(uint64_t *)(in_RCX + 0x388);
            goto code_r0x0001801d9a53;
        }
    }
    uVar11 = 0x10;
code_r0x0001801d9a53:
    uVar9 = *(uint32_t *)(in_RCX + 0x160);
    iVar5 = *(int32_t *)(in_RCX + 0xb14);
    iVar3 = *(int64_t *)(in_RCX + 0x300);
    if ((in_RDX & 1) == 0) {
        *(undefined4 *)((int64_t)&arg_b8h + iVar7) = 1;
        uVar6 = uVar9 | 0x400;
        if (iVar5 == 0) {
            uVar6 = uVar9 & 0xfffffbff;
        }
        *(uint32_t *)(in_RCX + 0x160) = uVar6;
        uVar9 = *(uint32_t *)(in_RCX + 0x570) | 2;
        if ((*(uint32_t *)(iVar3 + 0x40) & 0x10000) == 0) {
            uVar9 = *(uint32_t *)(in_RCX + 0x570) & 0xfffffffd;
        }
        *(uint32_t *)(in_RCX + 0x570) = uVar9;
        uVar6 = uVar9 & 0xfffffff7;
        uVar9 = uVar9 | 8;
    } else {
        *(undefined4 *)((int64_t)&arg_b8h + iVar7) = 0;
        uVar6 = uVar9 | 0x100;
        if (iVar5 == 0) {
            uVar6 = uVar9 & 0xfffffeff;
        }
        *(uint32_t *)(in_RCX + 0x160) = uVar6;
        uVar9 = *(uint32_t *)(in_RCX + 0x570) | 1;
        if ((*(uint32_t *)(iVar3 + 0x40) & 0x10000) == 0) {
            uVar9 = *(uint32_t *)(in_RCX + 0x570) & 0xfffffffe;
        }
        *(uint32_t *)(in_RCX + 0x570) = uVar9;
        uVar6 = uVar9 & 0xfffffffb;
        uVar9 = uVar9 | 4;
    }
    if ((*(uint32_t *)(iVar3 + 0x40) & 0x20000) == 0) {
        uVar9 = uVar6;
    }
    *(uint32_t *)(in_RCX + 0x570) = uVar9;
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d9b25;
        func_0x0001801c7590(in_RCX, in_RDX & 0xffffffff);
    }
    uVar1 = *(undefined4 *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = *(undefined8 *)((int64_t)&arg_58h + iVar7);
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = *(undefined8 *)((int64_t)&arg_60h + iVar7);
    *(undefined4 *)((int64_t)&arg_38h + iVar7) = *(undefined4 *)((int64_t)&arg_c8h + iVar7);
    *(uint64_t *)((int64_t)&arg_30h + iVar7) = uVar11;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = uVar2;
    *(int64_t *)((int64_t)&var_20h + iVar7) = iVar4;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = *(undefined8 *)((int64_t)&arg_d0h + iVar7);
    *(int64_t *)((int64_t)&var_10h + iVar7) = iVar13;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = *(undefined8 *)((int64_t)&arg_68h + iVar7);
    *(int64_t *)(&stack0x00000000 + iVar7) = iVar12;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = *(undefined8 *)((int64_t)&arg_70h + iVar7);
    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar7) = 0;
    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801d9bb8;
    iVar5 = func_0x0001801a4960(in_RCX, uVar1, *(undefined4 *)((int64_t)&arg_b8h + iVar7), 3);
    return iVar5 != 0;
}

// ============================================================
// Function: FUN_1801d9be0
// Address: 0x1801d9be0
// Size: 705 bytes
// ============================================================
undefined4
fcn.1801d9be0(int64_t placeholder_0, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h,
             int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h)
{
    undefined4 *puVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    undefined4 uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801d9bfa;
    var_10h = arg2;
    var_18h = arg3;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    uVar2 = *(uint64_t *)((int64_t)&arg_c0h + iVar11);
    uVar10 = 0;
    if (0xffff < uVar2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9c1b;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11));
        *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9c33;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11), 
                      *(int64_t *)((int64_t)&var_10h + iVar11), *(int64_t *)((int64_t)&var_18h + iVar11), 
                      *(int64_t *)((int64_t)&arg_30h + iVar11));
        *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9c45;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar11));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar11) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_a8h + iVar11) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_60h + iVar11) = unaff_R14;
    iVar3 = *(int64_t *)((int64_t)&arg_b0h + iVar11);
    *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9c9e;
    piVar12 = (int64_t *)fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11))
    ;
    if (piVar12 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9cb8;
        fcn.180498030(piVar12, placeholder_3, iVar3);
        uVar6 = *(undefined4 *)(placeholder_0 + 0x188);
        uVar7 = *(undefined4 *)(placeholder_0 + 0x18c);
        uVar8 = *(undefined4 *)(placeholder_0 + 400);
        puVar1 = (undefined4 *)((int64_t)piVar12 + iVar3);
        *puVar1 = *(undefined4 *)(placeholder_0 + 0x184);
        puVar1[1] = uVar6;
        puVar1[2] = uVar7;
        puVar1[3] = uVar8;
        uVar6 = *(undefined4 *)(placeholder_0 + 0x198);
        uVar7 = *(undefined4 *)(placeholder_0 + 0x19c);
        uVar8 = *(undefined4 *)(placeholder_0 + 0x1a0);
        puVar1 = (undefined4 *)((int64_t)piVar12 + iVar3 + 0x10);
        *puVar1 = *(undefined4 *)(placeholder_0 + 0x194);
        puVar1[1] = uVar6;
        puVar1[2] = uVar7;
        puVar1[3] = uVar8;
        uVar6 = *(undefined4 *)(placeholder_0 + 0x168);
        uVar7 = *(undefined4 *)(placeholder_0 + 0x16c);
        uVar8 = *(undefined4 *)(placeholder_0 + 0x170);
        puVar1 = (undefined4 *)(iVar3 + 0x20 + (int64_t)piVar12);
        *puVar1 = *(undefined4 *)(placeholder_0 + 0x164);
        puVar1[1] = uVar6;
        puVar1[2] = uVar7;
        puVar1[3] = uVar8;
        uVar6 = *(undefined4 *)(placeholder_0 + 0x178);
        uVar7 = *(undefined4 *)(placeholder_0 + 0x17c);
        uVar8 = *(undefined4 *)(placeholder_0 + 0x180);
        puVar1 = (undefined4 *)(iVar3 + 0x30 + (int64_t)piVar12);
        *puVar1 = *(undefined4 *)(placeholder_0 + 0x174);
        puVar1[1] = uVar6;
        puVar1[2] = uVar7;
        puVar1[3] = uVar8;
        if (*(int32_t *)((int64_t)&arg_c8h + iVar11) != 0) {
            iVar4 = *(int64_t *)((int64_t)&arg_b8h + iVar11);
            *(char *)((int64_t)piVar12 + iVar3 + 0x40) = (char)(uVar2 >> 8);
            *(char *)(iVar3 + 0x41 + (int64_t)piVar12) = (char)uVar2;
            if ((uVar2 != 0) || (iVar4 != 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9d2c;
                fcn.180498030(iVar3 + 0x42 + (int64_t)piVar12, iVar4, uVar2);
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9d41;
        iVar9 = fcn.180497f30(piVar12, 0x1804aea00, 0xf);
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9d5e;
            iVar9 = fcn.180497f30(piVar12, 0x1804aea10, 0xf);
            if ((iVar9 != 0) &&
               (((*piVar12 != 0x732072657473616d || (*(int32_t *)(piVar12 + 1) != 0x65726365)) ||
                (*(char *)((int64_t)piVar12 + 0xc) != 't')))) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9d9d;
                iVar9 = fcn.180497f30(piVar12, 0x1804b4bd0, 0x16);
                if ((iVar9 != 0) &&
                   (((*piVar12 != 0x617078652079656b || (*(int32_t *)(piVar12 + 1) != 0x6f69736e)) ||
                    (*(char *)((int64_t)piVar12 + 0xc) != 'n')))) {
                    iVar3 = *(int64_t *)(placeholder_0 + 0x8f8);
                    *(undefined4 *)((int64_t)&arg_58h + iVar11) = 0;
                    *(undefined8 *)((int64_t)&arg_50h + iVar11) = *(undefined8 *)((int64_t)&arg_a0h + iVar11);
                    uVar5 = *(undefined8 *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&arg_48h + iVar11) = *(undefined8 *)((int64_t)&arg_98h + iVar11);
                    *(undefined8 *)((int64_t)&arg_40h + iVar11) = uVar5;
                    *(int64_t *)((int64_t)&arg_38h + iVar11) = iVar3 + 0x50;
                    *(undefined8 *)((int64_t)&arg_30h + iVar11) = 0;
                    *(undefined8 *)((int64_t)&arg_28h + iVar11) = 0;
                    *(undefined8 *)((int64_t)&var_20h + iVar11) = 0;
                    *(undefined8 *)((int64_t)&var_18h + iVar11) = 0;
                    *(undefined8 *)((int64_t)&var_10h + iVar11) = 0;
                    *(undefined8 *)((int64_t)&var_8h + iVar11) = 0;
                    *(undefined8 *)(&stack0x00000000 + iVar11) = 0;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9e2e;
                    uVar10 = fcn.1801d92f0(*(int64_t *)(&stack0x00000000 + iVar11), 
                                           *(int64_t *)((int64_t)&var_8h + iVar11), 
                                           *(int64_t *)((int64_t)&var_10h + iVar11), 
                                           *(int64_t *)((int64_t)&var_18h + iVar11), 
                                           *(int64_t *)((int64_t)&var_20h + iVar11), 
                                           *(int64_t *)((int64_t)&arg_28h + iVar11), 
                                           *(int64_t *)((int64_t)&arg_30h + iVar11), 
                                           *(int64_t *)((int64_t)&arg_38h + iVar11), 
                                           *(int64_t *)((int64_t)&arg_40h + iVar11), 
                                           *(int64_t *)((int64_t)&arg_48h + iVar11), 
                                           *(int64_t *)((int64_t)&arg_50h + iVar11), 
                                           *(int64_t *)((int64_t)&arg_58h + iVar11), 
                                           *(int64_t *)(&stack0x00000198 + iVar11));
                    goto code_r0x0001801d9e61;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9e37;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11));
        *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9e4f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11), 
                      *(int64_t *)((int64_t)&var_10h + iVar11), *(int64_t *)((int64_t)&var_18h + iVar11), 
                      *(int64_t *)((int64_t)&arg_30h + iVar11));
        *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9e61;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar11));
    }
code_r0x0001801d9e61:
    *(undefined8 *)((int64_t)&uStack_28 + iVar11) = 0x1801d9e79;
    fcn.180224b90(*(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11));
    return uVar10;
}

// ============================================================
// Function: FUN_1801d9eb0
// Address: 0x1801d9eb0
// Size: 301 bytes
// ============================================================
void fcn.1801d9eb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_68h, int64_t arg_a8h, int64_t arg_168h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 uVar4;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d9ec1;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_a8h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3);
    uVar4 = 0x20;
    if ((*(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c) & 0x200) == 0) {
        uVar4 = 0xc;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801d9f04;
    iVar2 = func_0x0001801da790();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801d9f2a;
        iVar2 = func_0x000180197770(in_RCX, (int64_t)&arg_68h + iVar3, 0x40, (int64_t)&arg_58h + iVar3);
        if (iVar2 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 0x8f8);
            *(undefined4 *)((int64_t)&arg_50h + iVar3) = 1;
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = uVar4;
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = in_R9;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = *(undefined8 *)(iVar1 + 8);
            *(int64_t *)((int64_t)&arg_30h + iVar3) = iVar1 + 0x50;
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
            *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = *(undefined8 *)((int64_t)&arg_58h + iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801d9fa0;
            iVar2 = fcn.1801d92f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3)
                                  , *(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3), 
                                  *(int64_t *)(&stack0x00000190 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801d9fb9;
                func_0x000180244fc0((int64_t)&arg_68h + iVar3, *(undefined8 *)((int64_t)&arg_58h + iVar3));
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801d9fcf;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_a8h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801d9fe0
// Address: 0x1801d9fe0
// Size: 435 bytes
// ============================================================
void fcn.1801d9fe0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_68h, int64_t arg_e8h, int64_t arg_148h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d9ff1;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_e8h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3);
    puVar1 = *(undefined8 **)((int64_t)&arg_148h + iVar3);
    if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x370) & 1) == 0) {
        *(undefined4 *)((int64_t)&arg_50h + iVar3) = 1;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x30;
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = in_RDX;
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = 0x20;
        *(int64_t *)((int64_t)&var_10h + iVar3) = in_RCX + 0x164;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0x20;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801da184;
        iVar2 = fcn.1801d92f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                              *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3), 
                              *(int64_t *)(&stack0x00000190 + iVar3));
        if (iVar2 == 0) goto code_r0x0001801da0f9;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801da038;
        iVar2 = fcn.1801da790(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        if (iVar2 == 0) goto code_r0x0001801da0f9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801da05e;
        iVar2 = fcn.180197770(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)&var_8h + iVar3));
        if (iVar2 == 0) goto code_r0x0001801da0f9;
        *(undefined4 *)((int64_t)&arg_50h + iVar3) = 1;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x30;
        *(undefined8 *)((int64_t)&arg_40h + iVar3) = in_RDX;
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = in_R9;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = in_R8;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = *(undefined8 *)((int64_t)&arg_58h + iVar3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801da0d0;
        iVar2 = fcn.1801d92f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                              *(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3), 
                              *(int64_t *)(&stack0x00000190 + iVar3));
        if (iVar2 == 0) goto code_r0x0001801da0f9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801da0ed;
        fcn.180244fc0((int64_t)&arg_68h + iVar3, *(undefined8 *)((int64_t)&arg_58h + iVar3));
    }
    *puVar1 = 0x30;
code_r0x0001801da0f9:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801da109;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801da1a0
// Address: 0x1801da1a0
// Size: 380 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8
fcn.1801da1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h,
             int64_t arg_b8h, int64_t arg_c0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801da1ae;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    *(undefined4 *)((int64_t)&arg_a8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_b8h + iVar6) = 0;
    if (*(int64_t *)(in_RCX + 0x360) != 0) {
        return 1;
    }
    *(undefined4 *)((int64_t)&var_20h + iVar6) = *(undefined4 *)(in_RCX + 0xb14);
    *(int64_t *)((int64_t)&var_18h + iVar6) = (int64_t)&arg_68h + iVar6;
    *(int64_t *)((int64_t)&var_10h + iVar6) = (int64_t)&arg_b8h + iVar6;
    *(int64_t *)((int64_t)&var_8h + iVar6) = (int64_t)&arg_a8h + iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da22f;
    iVar4 = fcn.18019eb60(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6), *(int64_t *)((int64_t)&arg_60h + iVar6), 
                          *(int64_t *)(&stack0x000000c8 + iVar6));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da240;
        fcn.18019b6a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x370);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da259;
    fcn.1801974e0(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x378);
    *(undefined8 *)(in_RCX + 0x370) = *(undefined8 *)((int64_t)&arg_b0h + iVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da274;
    fcn.1801975c0(uVar1);
    uVar1 = *(undefined8 *)((int64_t)&arg_b0h + iVar6);
    *(undefined8 *)(in_RCX + 0x378) = *(undefined8 *)((int64_t)&arg_c0h + iVar6);
    *(undefined4 *)(in_RCX + 0x380) = *(undefined4 *)((int64_t)&arg_a8h + iVar6);
    *(undefined8 *)(in_RCX + 0x388) = *(undefined8 *)((int64_t)&arg_b8h + iVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2af;
    iVar4 = fcn.18020efb0(uVar1);
    if (iVar4 != 6) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2bc;
        iVar4 = fcn.18020efb0(uVar1);
        if (iVar4 != 7) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2c9;
            iVar4 = fcn.18020ef90(uVar1);
            if (iVar4 < 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2d4;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2ec;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da302;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
            goto code_r0x0001801da314;
        }
    }
    iVar4 = 4;
code_r0x0001801da314:
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da329;
    iVar5 = fcn.18020efa0(*(undefined8 *)((int64_t)&arg_b0h + iVar6));
    iVar3 = ((int64_t)iVar4 + (int64_t)iVar5 + *(int64_t *)((int64_t)&arg_b8h + iVar6)) * 2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da345;
    fcn.1801da740(in_RCX);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da35a;
    iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da367;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da37f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da395;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        *(int64_t *)(in_RCX + 0x368) = iVar7;
        *(int64_t *)(in_RCX + 0x360) = iVar3;
        *(undefined4 *)((int64_t)&arg_60h + iVar6) = 1;
        *(int64_t *)((int64_t)&arg_58h + iVar6) = iVar3;
        uVar1 = *(undefined8 *)(iVar2 + 8);
        *(int64_t *)((int64_t)&arg_50h + iVar6) = iVar7;
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = uVar1;
        *(int64_t *)((int64_t)&arg_40h + iVar6) = iVar2 + 0x50;
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = 0x20;
        *(int64_t *)((int64_t)&var_10h + iVar6) = in_RCX + 0x184;
        *(undefined8 *)((int64_t)&var_8h + iVar6) = 0x20;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da422;
        iVar4 = fcn.1801d92f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)((int64_t)&arg_50h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6), *(int64_t *)((int64_t)&arg_60h + iVar6), 
                              *(int64_t *)(&stack0x000001a0 + iVar6));
        if (iVar4 != 0) {
            uVar8 = 1;
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801da31c
// Address: 0x1801da31c
// Size: 288 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8
fcn.1801da1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h,
             int64_t arg_b8h, int64_t arg_c0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801da1ae;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar8 = 0;
    *(undefined4 *)((int64_t)&arg_a8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_b8h + iVar6) = 0;
    if (*(int64_t *)(in_RCX + 0x360) != 0) {
        return 1;
    }
    *(undefined4 *)((int64_t)&var_20h + iVar6) = *(undefined4 *)(in_RCX + 0xb14);
    *(int64_t *)((int64_t)&var_18h + iVar6) = (int64_t)&arg_68h + iVar6;
    *(int64_t *)((int64_t)&var_10h + iVar6) = (int64_t)&arg_b8h + iVar6;
    *(int64_t *)((int64_t)&var_8h + iVar6) = (int64_t)&arg_a8h + iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da22f;
    iVar4 = fcn.18019eb60(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6), *(int64_t *)((int64_t)&arg_60h + iVar6), 
                          *(int64_t *)(&stack0x000000c8 + iVar6));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da240;
        fcn.18019b6a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x370);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da259;
    fcn.1801974e0(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x378);
    *(undefined8 *)(in_RCX + 0x370) = *(undefined8 *)((int64_t)&arg_b0h + iVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da274;
    fcn.1801975c0(uVar1);
    uVar1 = *(undefined8 *)((int64_t)&arg_b0h + iVar6);
    *(undefined8 *)(in_RCX + 0x378) = *(undefined8 *)((int64_t)&arg_c0h + iVar6);
    *(undefined4 *)(in_RCX + 0x380) = *(undefined4 *)((int64_t)&arg_a8h + iVar6);
    *(undefined8 *)(in_RCX + 0x388) = *(undefined8 *)((int64_t)&arg_b8h + iVar6);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2af;
    iVar4 = fcn.18020efb0(uVar1);
    if (iVar4 != 6) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2bc;
        iVar4 = fcn.18020efb0(uVar1);
        if (iVar4 != 7) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2c9;
            iVar4 = fcn.18020ef90(uVar1);
            if (iVar4 < 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2d4;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da2ec;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da302;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                return 0;
            }
            goto code_r0x0001801da314;
        }
    }
    iVar4 = 4;
code_r0x0001801da314:
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da329;
    iVar5 = fcn.18020efa0(*(undefined8 *)((int64_t)&arg_b0h + iVar6));
    iVar3 = ((int64_t)iVar4 + (int64_t)iVar5 + *(int64_t *)((int64_t)&arg_b8h + iVar6)) * 2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da345;
    fcn.1801da740(in_RCX);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da35a;
    iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da367;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da37f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da395;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        *(int64_t *)(in_RCX + 0x368) = iVar7;
        *(int64_t *)(in_RCX + 0x360) = iVar3;
        *(undefined4 *)((int64_t)&arg_60h + iVar6) = 1;
        *(int64_t *)((int64_t)&arg_58h + iVar6) = iVar3;
        uVar1 = *(undefined8 *)(iVar2 + 8);
        *(int64_t *)((int64_t)&arg_50h + iVar6) = iVar7;
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = uVar1;
        *(int64_t *)((int64_t)&arg_40h + iVar6) = iVar2 + 0x50;
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar6) = 0;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = 0x20;
        *(int64_t *)((int64_t)&var_10h + iVar6) = in_RCX + 0x184;
        *(undefined8 *)((int64_t)&var_8h + iVar6) = 0x20;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801da422;
        iVar4 = fcn.1801d92f0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)((int64_t)&arg_50h + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6), *(int64_t *)((int64_t)&arg_60h + iVar6), 
                              *(int64_t *)(&stack0x000001a0 + iVar6));
        if (iVar4 != 0) {
            uVar8 = 1;
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801da580
// Address: 0x1801da580
// Size: 434 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1801da580(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_98h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint32_t in_EDX;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801da5a2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *(int64_t *)(in_RCX + 0x378);
    uVar2 = *(undefined8 *)(in_RCX + 0x370);
    if (iVar1 != 0) {
        iVar3 = *(int64_t *)(in_RCX + 0x368);
        *(undefined8 *)((int64_t)&arg_98h + iVar5) = *(undefined8 *)(in_RCX + 0x390);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801da5ed;
        iVar4 = func_0x00018020f800(iVar1);
        iVar8 = (int64_t)iVar4;
        if (0 < iVar4) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801da604;
            iVar4 = fcn.18020efa0(uVar2);
            iVar12 = (int64_t)iVar4;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801da60f;
            iVar4 = fcn.18020ef90(uVar2);
            iVar10 = (int64_t)iVar4;
            if ((in_EDX == 0x12) || (in_EDX == 0x21)) {
                iVar7 = iVar8 * 2;
                iVar9 = iVar7 + iVar12 * 2;
                uVar6 = iVar9 + iVar10 * 2;
                iVar11 = iVar3;
            } else {
                iVar7 = iVar12 + iVar8 * 2;
                iVar9 = iVar7 + iVar10 + iVar12;
                uVar6 = iVar9 + iVar10;
                iVar11 = iVar3 + iVar8;
            }
            if (uVar6 <= *(uint64_t *)(in_RCX + 0x360)) {
                *(undefined8 *)((int64_t)&arg_60h + iVar5) = 0;
                *(undefined8 *)((int64_t)&arg_58h + iVar5) = *(undefined8 *)((int64_t)&arg_98h + iVar5);
                *(int64_t *)((int64_t)&arg_50h + iVar5) = iVar1;
                *(undefined4 *)((int64_t)&arg_48h + iVar5) = 0;
                *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                *(undefined8 *)((int64_t)&arg_38h + iVar5) = uVar2;
                *(int64_t *)((int64_t)&arg_30h + iVar5) = iVar8;
                *(int64_t *)((int64_t)&arg_28h + iVar5) = iVar11;
                *(int64_t *)((int64_t)&var_20h + iVar5) = iVar10;
                *(int64_t *)((int64_t)&var_18h + iVar5) = iVar9 + iVar3;
                *(int64_t *)((int64_t)&var_10h + iVar5) = iVar12;
                *(int64_t *)((int64_t)&var_8h + iVar5) = iVar7 + iVar3;
                *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801da709;
                iVar4 = func_0x0001801a4960(in_RCX, 0x300, ~in_EDX & 1, 3);
                return iVar4 != 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801da675;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801da683;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                  *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801da693;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar5));
    return false;
}

// ============================================================
// Function: FUN_1801da740
// Address: 0x1801da740
// Size: 72 bytes
// ============================================================
void fcn.1801da740(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801da74c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801da772;
    fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)(param_1 + 0x368) = 0;
    *(undefined8 *)(param_1 + 0x360) = 0;
    return;
}

// ============================================================
// Function: FUN_1801da790
// Address: 0x1801da790
// Size: 438 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801da790(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801da7aa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 0x1b0) == 0) {
        uVar5 = *(undefined8 *)(in_RCX + 0x1a8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da7d9;
        iVar1 = func_0x000180219d10(uVar5, 3, 0, (int64_t)&arg_28h + iVar3);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da7e5;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da7fd;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da813;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da81f;
        iVar4 = func_0x000180215470();
        *(int64_t *)(in_RCX + 0x1b0) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da830;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da848;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da85e;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da86d;
        iVar4 = func_0x0001801a0380(in_RCX);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da877;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da88f;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da8a5;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        uVar5 = *(undefined8 *)(in_RCX + 0x1b0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da8be;
        iVar2 = func_0x000180214880(uVar5, iVar4, 0);
        if (iVar2 != 0) {
            uVar5 = *(undefined8 *)(in_RCX + 0x1b0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da8d6;
            iVar1 = func_0x0001802149b0(uVar5, *(undefined8 *)((int64_t)&arg_28h + iVar3), (int64_t)iVar1);
            if (iVar1 != 0) goto code_r0x0001801da911;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da8df;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da8f7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da90d;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar5 = 0;
    } else {
code_r0x0001801da911:
        if (in_EDX == 0) {
            uVar5 = *(undefined8 *)(in_RCX + 0x1a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801da921;
            func_0x000180219f80(uVar5);
            *(undefined8 *)(in_RCX + 0x1a8) = 0;
        }
        uVar5 = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1801da950
// Address: 0x1801da950
// Size: 799 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801da950(int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_58h, int64_t arg_90h, int64_t arg_140h
                  )
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    undefined8 uStack_48;
    int64_t var_18h;
    
    uStack_48 = 0x1801da967;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_90h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar7);
    if (*(int64_t *)(in_RCX + 0x1b0) == 0) {
        uVar9 = *(undefined8 *)(in_RCX + 0x1a8);
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801da9af;
        iVar5 = func_0x000180219d10(uVar9, 3, 0, &stack0xffffffffffffffe0 + iVar7);
        if (0 < iVar5) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801da9c9;
            iVar8 = func_0x000180215470();
            *(int64_t *)(in_RCX + 0x1b0) = iVar8;
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801da9eb;
                iVar8 = func_0x0001801a0380(in_RCX);
                if (iVar8 != 0) {
                    uVar9 = *(undefined8 *)(in_RCX + 0x1b0);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daa10;
                    iVar6 = func_0x000180214880(uVar9, iVar8, 0);
                    if (iVar6 != 0) {
                        uVar9 = *(undefined8 *)(in_RCX + 0x1b0);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daa28;
                        iVar5 = func_0x0001802149b0(uVar9, *(undefined8 *)(&stack0xffffffffffffffe0 + iVar7), 
                                                    (int64_t)iVar5);
                        if (iVar5 != 0) goto code_r0x0001801daa77;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daa52;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daa60;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)auStackX_18 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daa70;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar7));
        goto code_r0x0001801dac4b;
    }
code_r0x0001801daa77:
    uVar9 = *(undefined8 *)(in_RCX + 0x1a8);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daa83;
    func_0x000180219f80(uVar9);
    uVar9 = *(undefined8 *)(in_RCX + 0x1b0);
    *(undefined8 *)(in_RCX + 0x1a8) = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daa98;
    uVar9 = fcn.18020e940(uVar9);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daaa0;
    iVar5 = func_0x000180203a00(uVar9);
    if (iVar5 != 0x72) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daaaa;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daac2;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)auStackX_18 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daad8;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar7));
        goto code_r0x0001801dac4b;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daae4;
    iVar8 = func_0x000180215470();
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801daaf1;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dab09;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)auStackX_18 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dab1f;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar7));
        goto code_r0x0001801dac4b;
    }
    uVar9 = *(undefined8 *)(in_RCX + 0x1b0);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dab35;
    iVar5 = func_0x000180214b00(iVar8, uVar9);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dab3e;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
code_r0x0001801dac15:
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dac28;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                      *(int64_t *)((int64_t)auStackX_18 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dac3e;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dab50;
        iVar5 = func_0x00018020f590(iVar8);
        if (iVar5 < 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dab5b;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
            goto code_r0x0001801dac15;
        }
        if (in_RDX != 0) {
            iVar1 = *(int64_t *)(in_RCX + 0x8f8);
            uVar9 = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dab8e;
            puVar10 = (undefined4 *)func_0x000180229c70((int64_t)&var_18h + iVar7, 0x1804b4ce0, iVar1 + 0x50, uVar9);
            uVar2 = puVar10[1];
            uVar3 = puVar10[2];
            uVar4 = puVar10[3];
            *(undefined4 *)((int64_t)auStackX_18 + iVar7 + -8) = *puVar10;
            *(undefined4 *)((int64_t)auStackX_18 + iVar7 + -4) = uVar2;
            *(undefined4 *)((int64_t)auStackX_18 + iVar7) = uVar3;
            *(undefined4 *)((int64_t)auStackX_18 + iVar7 + 4) = uVar4;
            uVar2 = puVar10[5];
            uVar3 = puVar10[6];
            uVar4 = puVar10[7];
            *(undefined4 *)((int64_t)&var_20h + iVar7) = puVar10[4];
            *(undefined4 *)((int64_t)&var_20h + iVar7 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000028 + iVar7) = uVar3;
            *(undefined4 *)(&stack0x0000002c + iVar7) = uVar4;
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = *(undefined8 *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dabb4;
            puVar10 = (undefined4 *)func_0x000180229ba0((int64_t)&var_18h + iVar7);
            uVar2 = puVar10[1];
            uVar3 = puVar10[2];
            uVar4 = puVar10[3];
            *(undefined4 *)((int64_t)&arg_38h + iVar7) = *puVar10;
            *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000040 + iVar7) = uVar3;
            *(undefined4 *)(&stack0x00000044 + iVar7) = uVar4;
            uVar2 = puVar10[5];
            uVar3 = puVar10[6];
            uVar4 = puVar10[7];
            *(undefined4 *)((int64_t)&arg_48h + iVar7) = puVar10[4];
            *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000050 + iVar7) = uVar3;
            *(undefined4 *)(&stack0x00000054 + iVar7) = uVar4;
            *(undefined8 *)((int64_t)&arg_58h + iVar7) = *(undefined8 *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dabe4;
            iVar5 = func_0x0001802149b0(iVar8, in_RDX, in_R8);
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dabf5;
                iVar5 = func_0x0001802154c0(iVar8, (int64_t)auStackX_18 + iVar7 + -8);
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dac07;
                    iVar5 = func_0x0001802146d0(iVar8, in_R9, 0);
                    if (0 < iVar5) goto code_r0x0001801dac40;
                }
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dac10;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
            goto code_r0x0001801dac15;
        }
    }
code_r0x0001801dac40:
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dac48;
    func_0x000180215310(iVar8);
code_r0x0001801dac4b:
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801dac5b;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_90h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801dac70
// Address: 0x1801dac70
// Size: 291 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801dac70(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dac80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0x1b0) == 0) {
        if (0x7fffffff < in_R8) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801daca7;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dacbf;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dacd5;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dacee;
        iVar1 = fcn.18021b2c0(*(int64_t *)(&stack0x00000038 + iVar2));
        if ((iVar1 < 1) || (iVar1 != (int32_t)in_R8)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dacff;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dad17;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dad2d;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dad3f;
        iVar1 = fcn.1802149b0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dad48;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dad60;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dad76;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801dada0
// Address: 0x1801dada0
// Size: 70 bytes
// ============================================================
void fcn.1801dada0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dadac;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dadbe;
    fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    uVar1 = *(undefined8 *)(param_1 + 0x1b0);
    *(undefined8 *)(param_1 + 0x1a8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dadd5;
    fcn.180215310(uVar1);
    *(undefined8 *)(param_1 + 0x1b0) = 0;
    return;
}

// ============================================================
// Function: FUN_1801dadf0
// Address: 0x1801dadf0
// Size: 780 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1801dadf0(int64_t arg_28h, int64_t arg_90h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t in_R8D;
    uint32_t uVar11;
    int64_t aiStackX_8 [2];
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_40 = 0x1801dae0a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_28h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6);
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined *)((int64_t)&var_18h + iVar6) = 0x41;
    *(undefined4 *)((int64_t)&var_18h + iVar6 + 4) = 0;
    uVar2 = puVar1[0x8c];
    uVar11 = 0;
    uVar3 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801dae4b;
    uVar7 = func_0x000180197550(uVar3, 4, uVar2);
    uVar2 = puVar1[0x8c];
    uVar3 = *puVar1;
    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6) = uVar7;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801dae64;
    iVar8 = func_0x000180197550(uVar3, 0x40, uVar2);
    *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801dae71;
    iVar9 = func_0x000180215470();
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801dae79;
    iVar10 = func_0x000180215470();
    if ((((*(int64_t *)(&stack0xfffffffffffffff0 + iVar6) == 0) || (iVar8 == 0)) || (iVar9 == 0)) || (iVar10 == 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db081;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db099;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                      *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_18 + iVar6));
code_r0x0001801db09f:
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db0af;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar6));
    } else {
        iVar5 = 0;
        if (0 < in_R8D) {
            do {
                uVar11 = uVar11 + 1;
                if (0x10 < uVar11) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db075;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    goto code_r0x0001801db01a;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801daed2;
                fcn.1804986e0((int64_t)&iStackX_18 + iVar6, *(undefined *)((int64_t)&var_18h + iVar6), uVar11);
                *(char *)((int64_t)&var_18h + iVar6) = *(char *)((int64_t)&var_18h + iVar6) + '\x01';
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801daee6;
                iVar4 = func_0x000180214880(iVar10, *(undefined8 *)((int64_t)&var_8h + iVar6), 0);
                if (iVar4 == 0) {
code_r0x0001801db064:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db069;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
code_r0x0001801db01a:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db02d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6)
                                  , *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&iStackX_18 + iVar6));
                    goto code_r0x0001801db09f;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801daefe;
                iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                      , *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar4 == 0) goto code_r0x0001801db064;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801daf1d;
                iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                      , *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar4 == 0) goto code_r0x0001801db064;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801daf3a;
                iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                      , *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar4 == 0) goto code_r0x0001801db064;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801daf57;
                iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                      , *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar4 == 0) goto code_r0x0001801db064;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801daf6f;
                iVar4 = func_0x0001802146d0(iVar10, (int64_t)&stack0x00000000 + iVar6, 0);
                if (iVar4 == 0) goto code_r0x0001801db064;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801daf87;
                iVar4 = func_0x000180214880(iVar9, *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6), 0);
                if (iVar4 == 0) goto code_r0x0001801db064;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801dafa6;
                iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                      , *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar4 == 0) goto code_r0x0001801db064;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801dafc1;
                iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                      , *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar4 == 0) goto code_r0x0001801db064;
                iVar4 = iVar5 + 0x10;
                if (in_R8D < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db03f;
                    iVar4 = func_0x0001802146d0(iVar9, (int64_t)&stack0x00000000 + iVar6, 0);
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db05d;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                        goto code_r0x0001801db01a;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db056;
                    fcn.180498030(in_RDX, (int64_t)&stack0x00000000 + iVar6, in_R8D - iVar5);
                    break;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801dafe0;
                iVar5 = func_0x0001802146d0(iVar9, in_RDX, 0);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db015;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    goto code_r0x0001801db01a;
                }
                in_RDX = in_RDX + 0x10;
                iVar5 = iVar4;
            } while (iVar4 < in_R8D);
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db003;
        fcn.180244fc0((int64_t)&stack0x00000000 + iVar6, 0x14);
        *(undefined4 *)((int64_t)&var_18h + iVar6 + 4) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db0b7;
    fcn.180215310(iVar9);
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db0bf;
    fcn.180215310(iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db0c9;
    fcn.1801975c0(*(undefined8 *)(&stack0xfffffffffffffff0 + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db0d3;
    fcn.1801975c0(*(undefined8 *)((int64_t)&var_8h + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801db0e4;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801db100
// Address: 0x1801db100
// Size: 149 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801db100(int64_t arg_58h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_d8h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar5;
    undefined8 unaff_RBP;
    undefined8 in_R9;
    int64_t iVar6;
    undefined8 unaff_R15;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801db113;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_58h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3);
    *(undefined8 *)((int64_t)&iStackX_10 + iVar3 + -8) = *(undefined8 *)((int64_t)&arg_d8h + iVar3);
    *(undefined8 *)(&stack0x00000000 + iVar3) = in_R9;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db148;
    iVar4 = func_0x000180215470();
    iVar6 = 0;
    *(undefined4 *)(&stack0xfffffffffffffffc + iVar3) = 1;
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db160;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db178;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db18e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar3));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_RBP;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_R15;
        puVar7 = (undefined8 *)0x1804b4c18;
        *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RBX;
        do {
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x108);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1cc;
            iVar2 = func_0x000180214880(iVar4, uVar1, 0);
            if (iVar2 < 1) {
code_r0x0001801db2f1:
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2f6;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db30e;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db324;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar3));
                *(undefined4 *)(&stack0xfffffffffffffffc + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db334;
                fcn.180215310(iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db343;
                fcn.180244fc0((int64_t)&var_18h + iVar3, 0x40);
                goto code_r0x0001801db35f;
            }
            uVar1 = *puVar7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1dc;
            func_0x000180498cd0(uVar1);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1ea;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db205;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db222;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db23f;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db259;
            iVar2 = func_0x0001802146d0(iVar4, (int64_t)&var_18h + iVar3, &stack0xfffffffffffffff8 + iVar3);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x100);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db277;
            iVar2 = func_0x000180214880(iVar4, uVar1, 0);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db289;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db29f;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2b3;
            iVar2 = func_0x0001802146d0(iVar4, in_RDX);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            iVar5 = iVar5 + 1;
            in_RDX = in_RDX + (uint64_t)*(uint32_t *)(&stack0xfffffffffffffff8 + iVar3);
            iVar6 = iVar6 + (uint64_t)*(uint32_t *)(&stack0xfffffffffffffff8 + iVar3);
            puVar7 = puVar7 + 1;
        } while (iVar5 < 3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2d8;
        fcn.180215310(iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2e7;
        fcn.180244fc0((int64_t)&var_18h + iVar3, 0x40);
        **(int64_t **)((int64_t)&iStackX_10 + iVar3 + -8) = iVar6;
    }
code_r0x0001801db35f:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db36f;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801db195
// Address: 0x1801db195
// Size: 458 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801db100(int64_t arg_58h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_d8h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar5;
    undefined8 unaff_RBP;
    undefined8 in_R9;
    int64_t iVar6;
    undefined8 unaff_R15;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801db113;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_58h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3);
    *(undefined8 *)((int64_t)&iStackX_10 + iVar3 + -8) = *(undefined8 *)((int64_t)&arg_d8h + iVar3);
    *(undefined8 *)(&stack0x00000000 + iVar3) = in_R9;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db148;
    iVar4 = func_0x000180215470();
    iVar6 = 0;
    *(undefined4 *)(&stack0xfffffffffffffffc + iVar3) = 1;
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db160;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db178;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db18e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar3));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_RBP;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_R15;
        puVar7 = (undefined8 *)0x1804b4c18;
        *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RBX;
        do {
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x108);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1cc;
            iVar2 = func_0x000180214880(iVar4, uVar1, 0);
            if (iVar2 < 1) {
code_r0x0001801db2f1:
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2f6;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db30e;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db324;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar3));
                *(undefined4 *)(&stack0xfffffffffffffffc + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db334;
                fcn.180215310(iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db343;
                fcn.180244fc0((int64_t)&var_18h + iVar3, 0x40);
                goto code_r0x0001801db35f;
            }
            uVar1 = *puVar7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1dc;
            func_0x000180498cd0(uVar1);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1ea;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db205;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db222;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db23f;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db259;
            iVar2 = func_0x0001802146d0(iVar4, (int64_t)&var_18h + iVar3, &stack0xfffffffffffffff8 + iVar3);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x100);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db277;
            iVar2 = func_0x000180214880(iVar4, uVar1, 0);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db289;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db29f;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2b3;
            iVar2 = func_0x0001802146d0(iVar4, in_RDX);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            iVar5 = iVar5 + 1;
            in_RDX = in_RDX + (uint64_t)*(uint32_t *)(&stack0xfffffffffffffff8 + iVar3);
            iVar6 = iVar6 + (uint64_t)*(uint32_t *)(&stack0xfffffffffffffff8 + iVar3);
            puVar7 = puVar7 + 1;
        } while (iVar5 < 3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2d8;
        fcn.180215310(iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2e7;
        fcn.180244fc0((int64_t)&var_18h + iVar3, 0x40);
        **(int64_t **)((int64_t)&iStackX_10 + iVar3 + -8) = iVar6;
    }
code_r0x0001801db35f:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db36f;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801db35f
// Address: 0x1801db35f
// Size: 32 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801db100(int64_t arg_58h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_d8h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar5;
    undefined8 unaff_RBP;
    undefined8 in_R9;
    int64_t iVar6;
    undefined8 unaff_R15;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801db113;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_58h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3);
    *(undefined8 *)((int64_t)&iStackX_10 + iVar3 + -8) = *(undefined8 *)((int64_t)&arg_d8h + iVar3);
    *(undefined8 *)(&stack0x00000000 + iVar3) = in_R9;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db148;
    iVar4 = func_0x000180215470();
    iVar6 = 0;
    *(undefined4 *)(&stack0xfffffffffffffffc + iVar3) = 1;
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db160;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db178;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db18e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar3));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar3) = unaff_RBP;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_R15;
        puVar7 = (undefined8 *)0x1804b4c18;
        *(undefined8 *)((int64_t)&arg_80h + iVar3) = unaff_RBX;
        do {
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x108);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1cc;
            iVar2 = func_0x000180214880(iVar4, uVar1, 0);
            if (iVar2 < 1) {
code_r0x0001801db2f1:
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2f6;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db30e;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db324;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar3));
                *(undefined4 *)(&stack0xfffffffffffffffc + iVar3) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db334;
                fcn.180215310(iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db343;
                fcn.180244fc0((int64_t)&var_18h + iVar3, 0x40);
                goto code_r0x0001801db35f;
            }
            uVar1 = *puVar7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1dc;
            func_0x000180498cd0(uVar1);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db1ea;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db205;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db222;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db23f;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db259;
            iVar2 = func_0x0001802146d0(iVar4, (int64_t)&var_18h + iVar3, &stack0xfffffffffffffff8 + iVar3);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x100);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db277;
            iVar2 = func_0x000180214880(iVar4, uVar1, 0);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db289;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db29f;
            iVar2 = fcn.1802149b0(*(int64_t *)((int64_t)&iStackX_10 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2b3;
            iVar2 = func_0x0001802146d0(iVar4, in_RDX);
            if (iVar2 < 1) goto code_r0x0001801db2f1;
            iVar5 = iVar5 + 1;
            in_RDX = in_RDX + (uint64_t)*(uint32_t *)(&stack0xfffffffffffffff8 + iVar3);
            iVar6 = iVar6 + (uint64_t)*(uint32_t *)(&stack0xfffffffffffffff8 + iVar3);
            puVar7 = puVar7 + 1;
        } while (iVar5 < 3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2d8;
        fcn.180215310(iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db2e7;
        fcn.180244fc0((int64_t)&var_18h + iVar3, 0x40);
        **(int64_t **)((int64_t)&iStackX_10 + iVar3 + -8) = iVar6;
    }
code_r0x0001801db35f:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801db36f;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801db380
// Address: 0x1801db380
// Size: 198 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801db380(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801db390;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801db39b;
    fcn.1802199b0();
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801db3a3;
    iVar3 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801db3b0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801db3c8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801db3de;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801db3f7;
    fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    uVar1 = *(undefined8 *)(in_RCX + 0x1b0);
    *(undefined8 *)(in_RCX + 0x1a8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801db40e;
    fcn.180215310(uVar1);
    *(undefined8 *)(in_RCX + 0x1b0) = 0;
    *(int64_t *)(in_RCX + 0x1a8) = iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801db436;
    fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    return 1;
}

// ============================================================
// Function: FUN_1801db450
// Address: 0x1801db450
// Size: 63 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

undefined8
fcn.1801db450(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801db45c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x360) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
    *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
    *(int64_t *)((int64_t)&arg_28h + iVar4) = (int64_t)&arg_78h + iVar4;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4b3;
    iVar1 = fcn.18019eb60(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                          *(int64_t *)(&stack0x00000060 + iVar4), *(int64_t *)((int64_t)&arg_70h + iVar4), 
                          *(int64_t *)(&stack0x000000d8 + iVar4));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4c4;
        fcn.18019b6a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        return 0;
    }
    uVar6 = *(undefined8 *)(in_RCX + 0x370);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4e2;
    fcn.1801974e0(uVar6);
    uVar6 = *(undefined8 *)(in_RCX + 0x378);
    *(undefined8 *)(in_RCX + 0x370) = *(undefined8 *)((int64_t)&arg_68h + iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4fa;
    fcn.1801975c0(uVar6);
    uVar6 = *(undefined8 *)((int64_t)&arg_78h + iVar4);
    *(undefined8 *)(in_RCX + 0x378) = *(undefined8 *)((int64_t)&arg_70h + iVar4);
    *(undefined8 *)(in_RCX + 0x390) = uVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db51a;
    iVar1 = fcn.18020f800();
    if (iVar1 < 1) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db547;
    iVar2 = fcn.18020ef90(*(undefined8 *)((int64_t)&arg_68h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db553;
    iVar3 = fcn.18020efa0(*(undefined8 *)((int64_t)&arg_68h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db57d;
    fcn.180224b90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)(in_RCX + 0x368) = 0;
    *(undefined8 *)(in_RCX + 0x360) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5a3;
    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5c5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5db;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar6 = 0;
    } else {
        *(int64_t *)(in_RCX + 0x360) = (int64_t)((iVar3 + iVar1 + iVar2) * 2);
        *(int64_t *)(in_RCX + 0x368) = iVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5fb;
        uVar6 = fcn.1801dadf0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000080 + iVar4));
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801db48f
// Address: 0x1801db48f
// Size: 66 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

undefined8
fcn.1801db450(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801db45c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x360) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
    *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
    *(int64_t *)((int64_t)&arg_28h + iVar4) = (int64_t)&arg_78h + iVar4;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4b3;
    iVar1 = fcn.18019eb60(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                          *(int64_t *)(&stack0x00000060 + iVar4), *(int64_t *)((int64_t)&arg_70h + iVar4), 
                          *(int64_t *)(&stack0x000000d8 + iVar4));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4c4;
        fcn.18019b6a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        return 0;
    }
    uVar6 = *(undefined8 *)(in_RCX + 0x370);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4e2;
    fcn.1801974e0(uVar6);
    uVar6 = *(undefined8 *)(in_RCX + 0x378);
    *(undefined8 *)(in_RCX + 0x370) = *(undefined8 *)((int64_t)&arg_68h + iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4fa;
    fcn.1801975c0(uVar6);
    uVar6 = *(undefined8 *)((int64_t)&arg_78h + iVar4);
    *(undefined8 *)(in_RCX + 0x378) = *(undefined8 *)((int64_t)&arg_70h + iVar4);
    *(undefined8 *)(in_RCX + 0x390) = uVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db51a;
    iVar1 = fcn.18020f800();
    if (iVar1 < 1) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db547;
    iVar2 = fcn.18020ef90(*(undefined8 *)((int64_t)&arg_68h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db553;
    iVar3 = fcn.18020efa0(*(undefined8 *)((int64_t)&arg_68h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db57d;
    fcn.180224b90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)(in_RCX + 0x368) = 0;
    *(undefined8 *)(in_RCX + 0x360) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5a3;
    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5c5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5db;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar6 = 0;
    } else {
        *(int64_t *)(in_RCX + 0x360) = (int64_t)((iVar3 + iVar1 + iVar2) * 2);
        *(int64_t *)(in_RCX + 0x368) = iVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5fb;
        uVar6 = fcn.1801dadf0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000080 + iVar4));
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801db4d1
// Address: 0x1801db4d1
// Size: 98 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

undefined8
fcn.1801db450(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801db45c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x360) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
    *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
    *(int64_t *)((int64_t)&arg_28h + iVar4) = (int64_t)&arg_78h + iVar4;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4b3;
    iVar1 = fcn.18019eb60(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                          *(int64_t *)(&stack0x00000060 + iVar4), *(int64_t *)((int64_t)&arg_70h + iVar4), 
                          *(int64_t *)(&stack0x000000d8 + iVar4));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4c4;
        fcn.18019b6a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        return 0;
    }
    uVar6 = *(undefined8 *)(in_RCX + 0x370);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4e2;
    fcn.1801974e0(uVar6);
    uVar6 = *(undefined8 *)(in_RCX + 0x378);
    *(undefined8 *)(in_RCX + 0x370) = *(undefined8 *)((int64_t)&arg_68h + iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4fa;
    fcn.1801975c0(uVar6);
    uVar6 = *(undefined8 *)((int64_t)&arg_78h + iVar4);
    *(undefined8 *)(in_RCX + 0x378) = *(undefined8 *)((int64_t)&arg_70h + iVar4);
    *(undefined8 *)(in_RCX + 0x390) = uVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db51a;
    iVar1 = fcn.18020f800();
    if (iVar1 < 1) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db547;
    iVar2 = fcn.18020ef90(*(undefined8 *)((int64_t)&arg_68h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db553;
    iVar3 = fcn.18020efa0(*(undefined8 *)((int64_t)&arg_68h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db57d;
    fcn.180224b90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)(in_RCX + 0x368) = 0;
    *(undefined8 *)(in_RCX + 0x360) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5a3;
    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5c5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5db;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar6 = 0;
    } else {
        *(int64_t *)(in_RCX + 0x360) = (int64_t)((iVar3 + iVar1 + iVar2) * 2);
        *(int64_t *)(in_RCX + 0x368) = iVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5fb;
        uVar6 = fcn.1801dadf0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000080 + iVar4));
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801db533
// Address: 0x1801db533
// Size: 226 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

undefined8
fcn.1801db450(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801db45c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x360) != 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RBP;
    *(undefined4 *)((int64_t)&arg_30h + iVar4) = 0;
    *(int64_t *)((int64_t)&arg_28h + iVar4) = (int64_t)&arg_78h + iVar4;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4b3;
    iVar1 = fcn.18019eb60(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                          *(int64_t *)(&stack0x00000060 + iVar4), *(int64_t *)((int64_t)&arg_70h + iVar4), 
                          *(int64_t *)(&stack0x000000d8 + iVar4));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4c4;
        fcn.18019b6a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        return 0;
    }
    uVar6 = *(undefined8 *)(in_RCX + 0x370);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4e2;
    fcn.1801974e0(uVar6);
    uVar6 = *(undefined8 *)(in_RCX + 0x378);
    *(undefined8 *)(in_RCX + 0x370) = *(undefined8 *)((int64_t)&arg_68h + iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db4fa;
    fcn.1801975c0(uVar6);
    uVar6 = *(undefined8 *)((int64_t)&arg_78h + iVar4);
    *(undefined8 *)(in_RCX + 0x378) = *(undefined8 *)((int64_t)&arg_70h + iVar4);
    *(undefined8 *)(in_RCX + 0x390) = uVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db51a;
    iVar1 = fcn.18020f800();
    if (iVar1 < 1) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db547;
    iVar2 = fcn.18020ef90(*(undefined8 *)((int64_t)&arg_68h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db553;
    iVar3 = fcn.18020efa0(*(undefined8 *)((int64_t)&arg_68h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db57d;
    fcn.180224b90(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)(in_RCX + 0x368) = 0;
    *(undefined8 *)(in_RCX + 0x360) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5a3;
    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5c5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5db;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar6 = 0;
    } else {
        *(int64_t *)(in_RCX + 0x360) = (int64_t)((iVar3 + iVar1 + iVar2) * 2);
        *(int64_t *)(in_RCX + 0x368) = iVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801db5fb;
        uVar6 = fcn.1801dadf0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000080 + iVar4));
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801db620
// Address: 0x1801db620
// Size: 78 bytes
// ============================================================
bool fcn.1801db620(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801db62a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(param_1 + 0x20);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801db649;
        iVar2 = fcn.180193380(iVar1, 0x62, 0, param_2);
        return 0 < iVar2;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801db660;
    iVar2 = fcn.180191a20(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)(&stack0x000000d0 + iVar3), *(int64_t *)(&stack0x000000d8 + iVar3), 
                          *(int64_t *)(&stack0x000000e8 + iVar3), *(int64_t *)(&stack0x000001e8 + iVar3));
    return 0 < iVar2;
}

// ============================================================
// Function: FUN_1801db670
// Address: 0x1801db670
// Size: 78 bytes
// ============================================================
bool fcn.1801db670(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801db67a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(param_1 + 0x20);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801db699;
        iVar2 = fcn.180193380(iVar1, 0x66, 0, param_2);
        return 0 < iVar2;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801db6b0;
    iVar2 = fcn.180191a20(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)(&stack0x000000d0 + iVar3), *(int64_t *)(&stack0x000000d8 + iVar3), 
                          *(int64_t *)(&stack0x000000e8 + iVar3), *(int64_t *)(&stack0x000001e8 + iVar3));
    return 0 < iVar2;
}

// ============================================================
// Function: FUN_1801db6c0
// Address: 0x1801db6c0
// Size: 78 bytes
// ============================================================
bool fcn.1801db6c0(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801db6ca;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(param_1 + 0x20);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801db6e9;
        iVar2 = fcn.180193380(iVar1, 0x5c, 0, param_2);
        return 0 < iVar2;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1801db700;
    iVar2 = fcn.180191a20(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)(&stack0x000000d0 + iVar3), *(int64_t *)(&stack0x000000d8 + iVar3), 
                          *(int64_t *)(&stack0x000000e8 + iVar3), *(int64_t *)(&stack0x000001e8 + iVar3));
    return 0 < iVar2;
}

// ============================================================
// Function: FUN_1801db710
// Address: 0x1801db710
// Size: 233 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801db710(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint8_t *in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801db725;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = 1;
    if ((*in_RCX & 2) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801db747;
        iVar1 = func_0x000180223670(in_RDX, 0x1804b62a0);
        if (iVar1 == 0) {
            return true;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801db75a;
        iVar1 = func_0x000180223670(in_RDX, 0x1804b62b0);
        if (iVar1 == 0) {
            return true;
        }
    }
    if ((*in_RCX & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801db772;
        iVar1 = func_0x000180498f10(in_RDX, 0x1804b62bc);
        if (iVar1 == 0) {
            return true;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801db795;
    iVar4 = fcn.18045b928(in_RDX, 0x3a);
    if (iVar4 != 0) {
        return false;
    }
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801db7e0;
            iVar2 = fcn.180193380(iVar4, 0x5c, 0, in_RDX);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801db7c5;
        iVar2 = fcn.180191a20(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x000000c8 + iVar3), *(int64_t *)(&stack0x000000d0 + iVar3), 
                              *(int64_t *)(&stack0x000000e0 + iVar3), *(int64_t *)(&stack0x000001e0 + iVar3));
    }
    return 0 < iVar2;
}

// ============================================================
// Function: FUN_1801db800
// Address: 0x1801db800
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801db800(int64_t arg_28h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801db810;
    iVar3 = fcn.18045a350();
    iVar2 = 1;
    if (*(int64_t *)(in_RCX + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801db82d;
        iVar2 = func_0x000180192e20();
    }
    iVar1 = *(int64_t *)(in_RCX + 0x20);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801db841;
        iVar2 = func_0x000180194830(iVar1, in_RDX);
    }
    return 0 < iVar2;
}

