// Chunk 173 - 50 functions

// ============================================================
// Function: FUN_18022c729
// Address: 0x18022c729
// Size: 117 bytes
// ============================================================
uint64_t fcn.18022c729(int64_t arg_30h, int64_t arg_60h, int64_t arg_70h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint64_t unaff_RSI;
    uint64_t unaff_RDI;
    int64_t unaff_R14;
    int64_t var_20h;
    
    uVar3 = unaff_RDI;
    if (unaff_RSI != 0) {
        do {
            iVar1 = *(int64_t *)(unaff_R14 + uVar3 * 8);
            if (*(int32_t *)(iVar1 + 8) != 5) goto code_r0x00018022c78d;
            if ((*(int64_t *)(iVar1 + 0x10) != 0) && (*(int64_t *)(iVar1 + 0x18) != 0)) {
                iVar2 = func_0x0001802445f0(&var_20h);
                if (iVar2 == 0) goto code_r0x00018022c78d;
            }
            uVar3 = uVar3 + 1;
        } while (uVar3 < unaff_RSI);
    }
    iVar2 = func_0x0001802442e0(&var_20h);
    if (iVar2 != 0) {
        iVar2 = func_0x000180244200(&var_20h);
        unaff_RDI = unaff_RDI & 0xffffffff;
        if (iVar2 != 0) {
            unaff_RDI = 1;
        }
    }
code_r0x00018022c78d:
    func_0x000180243fb0(&var_20h);
    return unaff_RDI & 0xffffffff;
}

// ============================================================
// Function: FUN_18022c79e
// Address: 0x18022c79e
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_70h

uint64_t fcn.18022c729(int64_t arg_30h, int64_t arg_60h, int64_t arg_70h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint64_t unaff_RSI;
    uint64_t unaff_RDI;
    int64_t unaff_R14;
    int64_t var_20h;
    
    uVar3 = unaff_RDI;
    if (unaff_RSI != 0) {
        do {
            iVar1 = *(int64_t *)(unaff_R14 + uVar3 * 8);
            if (*(int32_t *)(iVar1 + 8) != 5) goto code_r0x00018022c78d;
            if ((*(int64_t *)(iVar1 + 0x10) != 0) && (*(int64_t *)(iVar1 + 0x18) != 0)) {
                iVar2 = func_0x0001802445f0(&var_20h);
                if (iVar2 == 0) goto code_r0x00018022c78d;
            }
            uVar3 = uVar3 + 1;
        } while (uVar3 < unaff_RSI);
    }
    iVar2 = func_0x0001802442e0(&var_20h);
    if (iVar2 != 0) {
        iVar2 = func_0x000180244200(&var_20h);
        unaff_RDI = unaff_RDI & 0xffffffff;
        if (iVar2 != 0) {
            unaff_RDI = 1;
        }
    }
code_r0x00018022c78d:
    func_0x000180243fb0(&var_20h);
    return unaff_RDI & 0xffffffff;
}

// ============================================================
// Function: FUN_18022c7d0
// Address: 0x18022c7d0
// Size: 98 bytes
// ============================================================
undefined8 fcn.18022c7d0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022c7da;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(char *)(in_R8 + -1 + in_R9) < '\0') {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022c7ea;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022c802;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022c814;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022c82d;
    uVar2 = fcn.18022bd50(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                          *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_18022c840
// Address: 0x18022c840
// Size: 41 bytes
// ============================================================
void fcn.18022c840(int64_t arg_28h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022c84a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_60h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022c864;
    fcn.1802963b0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18022c870
// Address: 0x18022c870
// Size: 419 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.18022c870(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022c88a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar2 = 0;
    if (in_RCX == 0) {
        if (in_RDX != 0) {
code_r0x00018022c8e2:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c8ea;
            iVar1 = func_0x00018022d080(in_RDX);
            if (iVar1 != 0) goto code_r0x00018022c8ff;
            goto code_r0x00018022c8ee;
        }
        if (in_R8 != 0) goto code_r0x00018022c8f3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c8ac;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c8c4;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c8d6;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
code_r0x00018022c8d6:
        uVar2 = 0;
    } else {
        if (in_RDX != 0) goto code_r0x00018022c8e2;
code_r0x00018022c8ee:
        if (in_R8 != 0) {
code_r0x00018022c8f3:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c8fb;
            iVar1 = func_0x00018022ca40(in_R8);
            if (iVar1 != 0) {
code_r0x00018022c8ff:
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c904;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c91c;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c92e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                return 0;
            }
        }
        if (in_RCX == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c991;
            piVar4 = (int64_t *)func_0x00018027c1b0();
            if (piVar4 == (int64_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c99e;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c9b6;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c9c8;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                return 0;
            }
code_r0x00018022c9cc:
            *(undefined4 *)(piVar4 + 2) = 0;
            *piVar4 = in_RDX;
            piVar4[1] = in_R8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c9e3;
            uVar2 = func_0x00018022d360(piVar4, 1);
            *piVar4 = 0;
            piVar4[1] = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c947;
            piVar4 = (int64_t *)func_0x00018022d200(in_RCX, 1);
            if (piVar4 == (int64_t *)0x0) goto code_r0x00018022c8d6;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c957;
            iVar1 = func_0x00018022dde0(piVar4);
            if (iVar1 == 0) goto code_r0x00018022c9cc;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c960;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c978;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c98a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022c9fc;
        func_0x00018027c100(piVar4);
    }
    return uVar2;
}

// ============================================================
// Function: FUN_18022ca40
// Address: 0x18022ca40
// Size: 294 bytes
// ============================================================
undefined4 fcn.18022ca40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint32_t *puVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    undefined4 uVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ca4c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = in_RCX;
    *(int64_t *)((int64_t)&arg_78h + iVar3) = (int64_t)&arg_38h + iVar3;
    uVar6 = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0x18022dc20;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022ca93;
    puVar4 = (uint32_t *)
             fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                           *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                           *(int64_t *)((int64_t)&arg_40h + iVar3));
    if (puVar4 != (uint32_t *)0x0) {
        return *(undefined4 *)((uint64_t)*puVar4 * 0x28 + 0x1804c3050);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022caba;
    fcn.180243560(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022cacd;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_18h + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e4b4;
    }
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022cae8;
        iVar2 = fcn.180222850(*(undefined8 *)0x18077e4a8);
        if (iVar2 != 0) {
            *(int64_t *)((int64_t)&arg_30h + iVar3) = (int64_t)&arg_38h + iVar3;
            *(undefined4 *)((int64_t)&arg_28h + iVar3) = 2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022cb0f;
            iVar5 = fcn.180229240(*(int64_t *)((int64_t)&var_20h + iVar3));
            if (iVar5 != 0) {
                uVar6 = *(undefined4 *)(*(int64_t *)(iVar5 + 8) + 0x10);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022cb27;
            fcn.180222910(*(undefined8 *)0x18077e4a8);
            return uVar6;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022cb34;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022cb4c;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022cb5e;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18022cb70
// Address: 0x18022cb70
// Size: 37 bytes
// ============================================================
undefined8 fcn.18022cb70(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022cb7a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022cb82;
    iVar1 = fcn.18022cba0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
    if (iVar1 == 0) {
        return 0;
    }
    return *(undefined8 *)(iVar1 + 8);
}

// ============================================================
// Function: FUN_18022cba0
// Address: 0x18022cba0
// Size: 157 bytes
// ============================================================
int64_t fcn.18022cba0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t in_ECX;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022cbaa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_ECX != 0) && ((0x5db < in_ECX - 1U || (*(int32_t *)((int64_t)in_ECX * 0x28 + 0x1804c3050) == 0)))) {
        *(int32_t *)((int64_t)&arg_40h + iVar3) = in_ECX;
        *(int64_t *)((int64_t)&arg_28h + iVar3) = (int64_t)&arg_30h + iVar3;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 3;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cbfb;
        fcn.180243560(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc0e;
        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_20h + iVar3));
        iVar2 = 0;
        if (iVar1 != 0) {
            iVar2 = *(int32_t *)0x18077e4b4;
        }
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc2d;
            iVar2 = fcn.180222850(*(undefined8 *)0x18077e4a8);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc47;
                iVar4 = fcn.180229240(*(int64_t *)((int64_t)&arg_28h + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc56;
                fcn.180222910(*(undefined8 *)0x18077e4a8);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc6e;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc86;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc98;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
                    return 0;
                }
                return *(int64_t *)(iVar4 + 8);
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cca9;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022ccc1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022ccd3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
        return 0;
    }
    return (int64_t)in_ECX * 0x28 + 0x1804c3040;
}

// ============================================================
// Function: FUN_18022cc3d
// Address: 0x18022cc3d
// Size: 44 bytes
// ============================================================
int64_t fcn.18022cba0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t in_ECX;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022cbaa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_ECX != 0) && ((0x5db < in_ECX - 1U || (*(int32_t *)((int64_t)in_ECX * 0x28 + 0x1804c3050) == 0)))) {
        *(int32_t *)((int64_t)&arg_40h + iVar3) = in_ECX;
        *(int64_t *)((int64_t)&arg_28h + iVar3) = (int64_t)&arg_30h + iVar3;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 3;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cbfb;
        fcn.180243560(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc0e;
        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_20h + iVar3));
        iVar2 = 0;
        if (iVar1 != 0) {
            iVar2 = *(int32_t *)0x18077e4b4;
        }
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc2d;
            iVar2 = fcn.180222850(*(undefined8 *)0x18077e4a8);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc47;
                iVar4 = fcn.180229240(*(int64_t *)((int64_t)&arg_28h + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc56;
                fcn.180222910(*(undefined8 *)0x18077e4a8);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc6e;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc86;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc98;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
                    return 0;
                }
                return *(int64_t *)(iVar4 + 8);
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cca9;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022ccc1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022ccd3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
        return 0;
    }
    return (int64_t)in_ECX * 0x28 + 0x1804c3040;
}

// ============================================================
// Function: FUN_18022cc69
// Address: 0x18022cc69
// Size: 59 bytes
// ============================================================
int64_t fcn.18022cba0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t in_ECX;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022cbaa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_ECX != 0) && ((0x5db < in_ECX - 1U || (*(int32_t *)((int64_t)in_ECX * 0x28 + 0x1804c3050) == 0)))) {
        *(int32_t *)((int64_t)&arg_40h + iVar3) = in_ECX;
        *(int64_t *)((int64_t)&arg_28h + iVar3) = (int64_t)&arg_30h + iVar3;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 3;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cbfb;
        fcn.180243560(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc0e;
        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_20h + iVar3));
        iVar2 = 0;
        if (iVar1 != 0) {
            iVar2 = *(int32_t *)0x18077e4b4;
        }
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc2d;
            iVar2 = fcn.180222850(*(undefined8 *)0x18077e4a8);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc47;
                iVar4 = fcn.180229240(*(int64_t *)((int64_t)&arg_28h + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc56;
                fcn.180222910(*(undefined8 *)0x18077e4a8);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc6e;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc86;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc98;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
                    return 0;
                }
                return *(int64_t *)(iVar4 + 8);
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cca9;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022ccc1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022ccd3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
        return 0;
    }
    return (int64_t)in_ECX * 0x28 + 0x1804c3040;
}

// ============================================================
// Function: FUN_18022cca4
// Address: 0x18022cca4
// Size: 70 bytes
// ============================================================
int64_t fcn.18022cba0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t in_ECX;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022cbaa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_ECX != 0) && ((0x5db < in_ECX - 1U || (*(int32_t *)((int64_t)in_ECX * 0x28 + 0x1804c3050) == 0)))) {
        *(int32_t *)((int64_t)&arg_40h + iVar3) = in_ECX;
        *(int64_t *)((int64_t)&arg_28h + iVar3) = (int64_t)&arg_30h + iVar3;
        *(undefined4 *)((int64_t)&var_20h + iVar3) = 3;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cbfb;
        fcn.180243560(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc0e;
        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_20h + iVar3));
        iVar2 = 0;
        if (iVar1 != 0) {
            iVar2 = *(int32_t *)0x18077e4b4;
        }
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc2d;
            iVar2 = fcn.180222850(*(undefined8 *)0x18077e4a8);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc47;
                iVar4 = fcn.180229240(*(int64_t *)((int64_t)&arg_28h + iVar3));
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc56;
                fcn.180222910(*(undefined8 *)0x18077e4a8);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc6e;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc86;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cc98;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
                    return 0;
                }
                return *(int64_t *)(iVar4 + 8);
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022cca9;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022ccc1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                      *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022ccd3;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar3));
        return 0;
    }
    return (int64_t)in_ECX * 0x28 + 0x1804c3040;
}

// ============================================================
// Function: FUN_18022ccf0
// Address: 0x18022ccf0
// Size: 36 bytes
// ============================================================
undefined8 fcn.18022ccf0(void)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022ccfa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022cd02;
    puVar2 = (undefined8 *)
             fcn.18022cba0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                           *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
    if (puVar2 == (undefined8 *)0x0) {
        return 0;
    }
    return *puVar2;
}

// ============================================================
// Function: FUN_18022cd20
// Address: 0x18022cd20
// Size: 22 bytes
// ============================================================
int32_t fcn.18022cd20(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(int64_t *)((int64_t)&arg_30h + iVar2) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x18022ddf0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = 0;
    if (in_RCX != 0) {
        if (*(int32_t *)(in_RCX + 0x10) != 0) {
            return *(int32_t *)(in_RCX + 0x10);
        }
        if (*(int32_t *)(in_RCX + 0x14) != 0) {
            *(undefined4 *)((int64_t)&arg_48h + iVar3 + iVar2) = 0;
            *(undefined8 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0x18022dcf0;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18022de3f;
            puVar4 = (uint32_t *)
                     fcn.1802963b0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                   *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                                   *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                                   *(int64_t *)(&stack0x00000060 + iVar3 + iVar2), 
                                   *(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
            if (puVar4 != (uint32_t *)0x0) {
                return *(int32_t *)((uint64_t)*puVar4 * 0x28 + 0x1804c3050);
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18022de5f;
            iVar1 = fcn.18022dee0();
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar2) = *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2);
                *(undefined4 *)((int64_t)&arg_50h + iVar3 + iVar2) = 0;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18022deb9;
                iVar5 = fcn.180229240(*(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2));
                if (iVar5 != 0) {
                    iVar6 = *(int32_t *)(*(int64_t *)(iVar5 + 8) + 0x10);
                }
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18022ded1;
                fcn.180222910(*(undefined8 *)0x18077e4a8);
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18022de68;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2));
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18022de80;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2));
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18022de92;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022cd40
// Address: 0x18022cd40
// Size: 81 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.18022cd40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    uint8_t uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar10;
    uint64_t uVar11;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint8_t *puVar12;
    undefined8 unaff_R13;
    uint64_t uVar13;
    int64_t var_4h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18022cd51;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_28h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6);
    uVar13 = (uint64_t)in_EDX;
    *(undefined4 *)(&stack0x00000018 + iVar6 + -0x18) = 0;
    if ((in_RCX != (char *)0x0) && (0 < in_EDX)) {
        *in_RCX = '\0';
    }
    if ((in_R8 == 0) || (*(int64_t *)(in_R8 + 0x18) == 0)) goto code_r0x00018022ce8c;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdab;
        iVar3 = func_0x00018022dde0(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdb8;
            iVar7 = fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                  *(int64_t *)((int64_t)&var_4h + iVar6 + 4), *(int64_t *)(&stack0x00000018 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
            if ((iVar7 == 0) || (iVar7 = *(int64_t *)(iVar7 + 8), iVar7 == 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdcd;
                piVar8 = (int64_t *)
                         fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                       *(int64_t *)((int64_t)&var_4h + iVar6 + 4), 
                                       *(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                if ((piVar8 == (int64_t *)0x0) || (iVar7 = *piVar8, iVar7 == 0)) goto code_r0x00018022cdfa;
            }
            if (in_RCX != (char *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cded;
                func_0x000180223790(in_RCX, iVar7, uVar13);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdf5;
            func_0x000180498cd0(iVar7);
            goto code_r0x00018022ce8c;
        }
    }
code_r0x00018022cdfa:
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R12;
    iVar7 = 0;
    puVar12 = *(uint8_t **)(in_R8 + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_R13;
    iVar3 = *(int32_t *)(in_R8 + 0x14);
    *(undefined4 *)((int64_t)&var_4h + iVar6) = 1;
    if (iVar3 < 0x24b) {
        if (0 < iVar3) {
code_r0x00018022ce30:
            uVar11 = 0;
            bVar2 = false;
code_r0x00018022ce40:
            do {
                uVar1 = *puVar12;
                puVar12 = puVar12 + 1;
                iVar3 = iVar3 + -1;
                if ((iVar3 == 0) && ((char)uVar1 < '\0')) goto code_r0x00018022ce68;
                if (bVar2) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce64;
                    iVar4 = func_0x000180296ea0(iVar7, uVar1 & 0x7f);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                } else {
                    uVar11 = (uint64_t)((uint32_t)uVar11 | uVar1 & 0x7f);
                }
                uVar10 = (uint32_t)uVar11;
                if (-1 < (char)uVar1) goto code_r0x00018022cf06;
                if (!bVar2) {
                    if (uVar10 < 0x2000000) {
                        uVar11 = (uint64_t)(uVar10 << 7);
                        goto code_r0x00018022ce40;
                    }
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cec5;
                        iVar7 = func_0x0001802554c0();
                        if (iVar7 == 0) goto code_r0x00018022ce68;
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ced7;
                    iVar4 = func_0x000180255860(iVar7, uVar11);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                    bVar2 = true;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cef1;
                iVar4 = func_0x0001802974c0(iVar7, iVar7, 7);
                if (iVar4 == 0) goto code_r0x00018022ce68;
            } while( true );
        }
code_r0x00018022d063:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d06b;
        func_0x000180255290(iVar7);
    } else {
code_r0x00018022ce68:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce70;
        func_0x000180255290(iVar7);
    }
code_r0x00018022ce8c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce99;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6));
    return;
code_r0x00018022cf06:
    if (*(int32_t *)((int64_t)&var_4h + iVar6) != 0) {
        *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
        if (uVar10 < 0x50) {
            iVar4 = (int32_t)(uVar11 / 0x28);
            uVar11 = (uint64_t)(uVar10 + iVar4 * -0x28);
        } else {
            iVar4 = 2;
            if (bVar2) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf2e;
                iVar5 = func_0x0001802973b0(iVar7, 0x50);
                if (iVar5 == 0) goto code_r0x00018022ce68;
            } else {
                uVar11 = (uint64_t)(uVar10 - 0x50);
            }
        }
        if ((in_RCX != (char *)0x0) && (1 < (int32_t)uVar13)) {
            *in_RCX = (char)iVar4 + '0';
            in_RCX = in_RCX + 1;
            uVar13 = (uint64_t)((int32_t)uVar13 - 1);
            *in_RCX = '\0';
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1;
    }
    iVar4 = (int32_t)uVar13;
    if (bVar2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf7d;
        iVar9 = func_0x000180297c80(iVar7);
        if (iVar9 == 0) goto code_r0x00018022ce68;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf91;
        iVar5 = func_0x000180498cd0(iVar9);
        if (in_RCX != (char *)0x0) {
            if (1 < iVar4) {
                *in_RCX = '.';
                in_RCX = in_RCX + 1;
                iVar4 = iVar4 + -1;
                *in_RCX = '\0';
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cfbe;
            func_0x000180223790(in_RCX, iVar9, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1 + iVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cff5;
        func_0x000180224990(iVar9, 0x1804e1b50, 0x20a);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d010;
        func_0x000180245f70((int64_t)&var_4h + iVar6 + 4, 0x1a, 0x1804e1ba4, uVar11);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d01a;
        iVar5 = func_0x000180498cd0((int64_t)&var_4h + iVar6 + 4);
        if ((in_RCX != (char *)0x0) && (0 < iVar4)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d03a;
            func_0x000180223790(in_RCX, (int64_t)&var_4h + iVar6 + 4, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + iVar5;
    }
    if (iVar3 < 1) goto code_r0x00018022d063;
    goto code_r0x00018022ce30;
}

// ============================================================
// Function: FUN_18022cd91
// Address: 0x18022cd91
// Size: 105 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.18022cd40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    uint8_t uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar10;
    uint64_t uVar11;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint8_t *puVar12;
    undefined8 unaff_R13;
    uint64_t uVar13;
    int64_t var_4h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18022cd51;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_28h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6);
    uVar13 = (uint64_t)in_EDX;
    *(undefined4 *)(&stack0x00000018 + iVar6 + -0x18) = 0;
    if ((in_RCX != (char *)0x0) && (0 < in_EDX)) {
        *in_RCX = '\0';
    }
    if ((in_R8 == 0) || (*(int64_t *)(in_R8 + 0x18) == 0)) goto code_r0x00018022ce8c;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdab;
        iVar3 = func_0x00018022dde0(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdb8;
            iVar7 = fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                  *(int64_t *)((int64_t)&var_4h + iVar6 + 4), *(int64_t *)(&stack0x00000018 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
            if ((iVar7 == 0) || (iVar7 = *(int64_t *)(iVar7 + 8), iVar7 == 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdcd;
                piVar8 = (int64_t *)
                         fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                       *(int64_t *)((int64_t)&var_4h + iVar6 + 4), 
                                       *(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                if ((piVar8 == (int64_t *)0x0) || (iVar7 = *piVar8, iVar7 == 0)) goto code_r0x00018022cdfa;
            }
            if (in_RCX != (char *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cded;
                func_0x000180223790(in_RCX, iVar7, uVar13);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdf5;
            func_0x000180498cd0(iVar7);
            goto code_r0x00018022ce8c;
        }
    }
code_r0x00018022cdfa:
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R12;
    iVar7 = 0;
    puVar12 = *(uint8_t **)(in_R8 + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_R13;
    iVar3 = *(int32_t *)(in_R8 + 0x14);
    *(undefined4 *)((int64_t)&var_4h + iVar6) = 1;
    if (iVar3 < 0x24b) {
        if (0 < iVar3) {
code_r0x00018022ce30:
            uVar11 = 0;
            bVar2 = false;
code_r0x00018022ce40:
            do {
                uVar1 = *puVar12;
                puVar12 = puVar12 + 1;
                iVar3 = iVar3 + -1;
                if ((iVar3 == 0) && ((char)uVar1 < '\0')) goto code_r0x00018022ce68;
                if (bVar2) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce64;
                    iVar4 = func_0x000180296ea0(iVar7, uVar1 & 0x7f);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                } else {
                    uVar11 = (uint64_t)((uint32_t)uVar11 | uVar1 & 0x7f);
                }
                uVar10 = (uint32_t)uVar11;
                if (-1 < (char)uVar1) goto code_r0x00018022cf06;
                if (!bVar2) {
                    if (uVar10 < 0x2000000) {
                        uVar11 = (uint64_t)(uVar10 << 7);
                        goto code_r0x00018022ce40;
                    }
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cec5;
                        iVar7 = func_0x0001802554c0();
                        if (iVar7 == 0) goto code_r0x00018022ce68;
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ced7;
                    iVar4 = func_0x000180255860(iVar7, uVar11);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                    bVar2 = true;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cef1;
                iVar4 = func_0x0001802974c0(iVar7, iVar7, 7);
                if (iVar4 == 0) goto code_r0x00018022ce68;
            } while( true );
        }
code_r0x00018022d063:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d06b;
        func_0x000180255290(iVar7);
    } else {
code_r0x00018022ce68:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce70;
        func_0x000180255290(iVar7);
    }
code_r0x00018022ce8c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce99;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6));
    return;
code_r0x00018022cf06:
    if (*(int32_t *)((int64_t)&var_4h + iVar6) != 0) {
        *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
        if (uVar10 < 0x50) {
            iVar4 = (int32_t)(uVar11 / 0x28);
            uVar11 = (uint64_t)(uVar10 + iVar4 * -0x28);
        } else {
            iVar4 = 2;
            if (bVar2) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf2e;
                iVar5 = func_0x0001802973b0(iVar7, 0x50);
                if (iVar5 == 0) goto code_r0x00018022ce68;
            } else {
                uVar11 = (uint64_t)(uVar10 - 0x50);
            }
        }
        if ((in_RCX != (char *)0x0) && (1 < (int32_t)uVar13)) {
            *in_RCX = (char)iVar4 + '0';
            in_RCX = in_RCX + 1;
            uVar13 = (uint64_t)((int32_t)uVar13 - 1);
            *in_RCX = '\0';
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1;
    }
    iVar4 = (int32_t)uVar13;
    if (bVar2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf7d;
        iVar9 = func_0x000180297c80(iVar7);
        if (iVar9 == 0) goto code_r0x00018022ce68;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf91;
        iVar5 = func_0x000180498cd0(iVar9);
        if (in_RCX != (char *)0x0) {
            if (1 < iVar4) {
                *in_RCX = '.';
                in_RCX = in_RCX + 1;
                iVar4 = iVar4 + -1;
                *in_RCX = '\0';
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cfbe;
            func_0x000180223790(in_RCX, iVar9, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1 + iVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cff5;
        func_0x000180224990(iVar9, 0x1804e1b50, 0x20a);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d010;
        func_0x000180245f70((int64_t)&var_4h + iVar6 + 4, 0x1a, 0x1804e1ba4, uVar11);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d01a;
        iVar5 = func_0x000180498cd0((int64_t)&var_4h + iVar6 + 4);
        if ((in_RCX != (char *)0x0) && (0 < iVar4)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d03a;
            func_0x000180223790(in_RCX, (int64_t)&var_4h + iVar6 + 4, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + iVar5;
    }
    if (iVar3 < 1) goto code_r0x00018022d063;
    goto code_r0x00018022ce30;
}

// ============================================================
// Function: FUN_18022cdfa
// Address: 0x18022cdfa
// Size: 133 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.18022cd40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    uint8_t uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar10;
    uint64_t uVar11;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint8_t *puVar12;
    undefined8 unaff_R13;
    uint64_t uVar13;
    int64_t var_4h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18022cd51;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_28h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6);
    uVar13 = (uint64_t)in_EDX;
    *(undefined4 *)(&stack0x00000018 + iVar6 + -0x18) = 0;
    if ((in_RCX != (char *)0x0) && (0 < in_EDX)) {
        *in_RCX = '\0';
    }
    if ((in_R8 == 0) || (*(int64_t *)(in_R8 + 0x18) == 0)) goto code_r0x00018022ce8c;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdab;
        iVar3 = func_0x00018022dde0(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdb8;
            iVar7 = fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                  *(int64_t *)((int64_t)&var_4h + iVar6 + 4), *(int64_t *)(&stack0x00000018 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
            if ((iVar7 == 0) || (iVar7 = *(int64_t *)(iVar7 + 8), iVar7 == 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdcd;
                piVar8 = (int64_t *)
                         fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                       *(int64_t *)((int64_t)&var_4h + iVar6 + 4), 
                                       *(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                if ((piVar8 == (int64_t *)0x0) || (iVar7 = *piVar8, iVar7 == 0)) goto code_r0x00018022cdfa;
            }
            if (in_RCX != (char *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cded;
                func_0x000180223790(in_RCX, iVar7, uVar13);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdf5;
            func_0x000180498cd0(iVar7);
            goto code_r0x00018022ce8c;
        }
    }
code_r0x00018022cdfa:
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R12;
    iVar7 = 0;
    puVar12 = *(uint8_t **)(in_R8 + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_R13;
    iVar3 = *(int32_t *)(in_R8 + 0x14);
    *(undefined4 *)((int64_t)&var_4h + iVar6) = 1;
    if (iVar3 < 0x24b) {
        if (0 < iVar3) {
code_r0x00018022ce30:
            uVar11 = 0;
            bVar2 = false;
code_r0x00018022ce40:
            do {
                uVar1 = *puVar12;
                puVar12 = puVar12 + 1;
                iVar3 = iVar3 + -1;
                if ((iVar3 == 0) && ((char)uVar1 < '\0')) goto code_r0x00018022ce68;
                if (bVar2) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce64;
                    iVar4 = func_0x000180296ea0(iVar7, uVar1 & 0x7f);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                } else {
                    uVar11 = (uint64_t)((uint32_t)uVar11 | uVar1 & 0x7f);
                }
                uVar10 = (uint32_t)uVar11;
                if (-1 < (char)uVar1) goto code_r0x00018022cf06;
                if (!bVar2) {
                    if (uVar10 < 0x2000000) {
                        uVar11 = (uint64_t)(uVar10 << 7);
                        goto code_r0x00018022ce40;
                    }
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cec5;
                        iVar7 = func_0x0001802554c0();
                        if (iVar7 == 0) goto code_r0x00018022ce68;
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ced7;
                    iVar4 = func_0x000180255860(iVar7, uVar11);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                    bVar2 = true;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cef1;
                iVar4 = func_0x0001802974c0(iVar7, iVar7, 7);
                if (iVar4 == 0) goto code_r0x00018022ce68;
            } while( true );
        }
code_r0x00018022d063:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d06b;
        func_0x000180255290(iVar7);
    } else {
code_r0x00018022ce68:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce70;
        func_0x000180255290(iVar7);
    }
code_r0x00018022ce8c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce99;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6));
    return;
code_r0x00018022cf06:
    if (*(int32_t *)((int64_t)&var_4h + iVar6) != 0) {
        *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
        if (uVar10 < 0x50) {
            iVar4 = (int32_t)(uVar11 / 0x28);
            uVar11 = (uint64_t)(uVar10 + iVar4 * -0x28);
        } else {
            iVar4 = 2;
            if (bVar2) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf2e;
                iVar5 = func_0x0001802973b0(iVar7, 0x50);
                if (iVar5 == 0) goto code_r0x00018022ce68;
            } else {
                uVar11 = (uint64_t)(uVar10 - 0x50);
            }
        }
        if ((in_RCX != (char *)0x0) && (1 < (int32_t)uVar13)) {
            *in_RCX = (char)iVar4 + '0';
            in_RCX = in_RCX + 1;
            uVar13 = (uint64_t)((int32_t)uVar13 - 1);
            *in_RCX = '\0';
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1;
    }
    iVar4 = (int32_t)uVar13;
    if (bVar2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf7d;
        iVar9 = func_0x000180297c80(iVar7);
        if (iVar9 == 0) goto code_r0x00018022ce68;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf91;
        iVar5 = func_0x000180498cd0(iVar9);
        if (in_RCX != (char *)0x0) {
            if (1 < iVar4) {
                *in_RCX = '.';
                in_RCX = in_RCX + 1;
                iVar4 = iVar4 + -1;
                *in_RCX = '\0';
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cfbe;
            func_0x000180223790(in_RCX, iVar9, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1 + iVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cff5;
        func_0x000180224990(iVar9, 0x1804e1b50, 0x20a);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d010;
        func_0x000180245f70((int64_t)&var_4h + iVar6 + 4, 0x1a, 0x1804e1ba4, uVar11);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d01a;
        iVar5 = func_0x000180498cd0((int64_t)&var_4h + iVar6 + 4);
        if ((in_RCX != (char *)0x0) && (0 < iVar4)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d03a;
            func_0x000180223790(in_RCX, (int64_t)&var_4h + iVar6 + 4, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + iVar5;
    }
    if (iVar3 < 1) goto code_r0x00018022d063;
    goto code_r0x00018022ce30;
}

// ============================================================
// Function: FUN_18022ce7f
// Address: 0x18022ce7f
// Size: 13 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.18022cd40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    uint8_t uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar10;
    uint64_t uVar11;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint8_t *puVar12;
    undefined8 unaff_R13;
    uint64_t uVar13;
    int64_t var_4h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18022cd51;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_28h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6);
    uVar13 = (uint64_t)in_EDX;
    *(undefined4 *)(&stack0x00000018 + iVar6 + -0x18) = 0;
    if ((in_RCX != (char *)0x0) && (0 < in_EDX)) {
        *in_RCX = '\0';
    }
    if ((in_R8 == 0) || (*(int64_t *)(in_R8 + 0x18) == 0)) goto code_r0x00018022ce8c;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdab;
        iVar3 = func_0x00018022dde0(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdb8;
            iVar7 = fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                  *(int64_t *)((int64_t)&var_4h + iVar6 + 4), *(int64_t *)(&stack0x00000018 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
            if ((iVar7 == 0) || (iVar7 = *(int64_t *)(iVar7 + 8), iVar7 == 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdcd;
                piVar8 = (int64_t *)
                         fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                       *(int64_t *)((int64_t)&var_4h + iVar6 + 4), 
                                       *(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                if ((piVar8 == (int64_t *)0x0) || (iVar7 = *piVar8, iVar7 == 0)) goto code_r0x00018022cdfa;
            }
            if (in_RCX != (char *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cded;
                func_0x000180223790(in_RCX, iVar7, uVar13);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdf5;
            func_0x000180498cd0(iVar7);
            goto code_r0x00018022ce8c;
        }
    }
code_r0x00018022cdfa:
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R12;
    iVar7 = 0;
    puVar12 = *(uint8_t **)(in_R8 + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_R13;
    iVar3 = *(int32_t *)(in_R8 + 0x14);
    *(undefined4 *)((int64_t)&var_4h + iVar6) = 1;
    if (iVar3 < 0x24b) {
        if (0 < iVar3) {
code_r0x00018022ce30:
            uVar11 = 0;
            bVar2 = false;
code_r0x00018022ce40:
            do {
                uVar1 = *puVar12;
                puVar12 = puVar12 + 1;
                iVar3 = iVar3 + -1;
                if ((iVar3 == 0) && ((char)uVar1 < '\0')) goto code_r0x00018022ce68;
                if (bVar2) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce64;
                    iVar4 = func_0x000180296ea0(iVar7, uVar1 & 0x7f);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                } else {
                    uVar11 = (uint64_t)((uint32_t)uVar11 | uVar1 & 0x7f);
                }
                uVar10 = (uint32_t)uVar11;
                if (-1 < (char)uVar1) goto code_r0x00018022cf06;
                if (!bVar2) {
                    if (uVar10 < 0x2000000) {
                        uVar11 = (uint64_t)(uVar10 << 7);
                        goto code_r0x00018022ce40;
                    }
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cec5;
                        iVar7 = func_0x0001802554c0();
                        if (iVar7 == 0) goto code_r0x00018022ce68;
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ced7;
                    iVar4 = func_0x000180255860(iVar7, uVar11);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                    bVar2 = true;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cef1;
                iVar4 = func_0x0001802974c0(iVar7, iVar7, 7);
                if (iVar4 == 0) goto code_r0x00018022ce68;
            } while( true );
        }
code_r0x00018022d063:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d06b;
        func_0x000180255290(iVar7);
    } else {
code_r0x00018022ce68:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce70;
        func_0x000180255290(iVar7);
    }
code_r0x00018022ce8c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce99;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6));
    return;
code_r0x00018022cf06:
    if (*(int32_t *)((int64_t)&var_4h + iVar6) != 0) {
        *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
        if (uVar10 < 0x50) {
            iVar4 = (int32_t)(uVar11 / 0x28);
            uVar11 = (uint64_t)(uVar10 + iVar4 * -0x28);
        } else {
            iVar4 = 2;
            if (bVar2) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf2e;
                iVar5 = func_0x0001802973b0(iVar7, 0x50);
                if (iVar5 == 0) goto code_r0x00018022ce68;
            } else {
                uVar11 = (uint64_t)(uVar10 - 0x50);
            }
        }
        if ((in_RCX != (char *)0x0) && (1 < (int32_t)uVar13)) {
            *in_RCX = (char)iVar4 + '0';
            in_RCX = in_RCX + 1;
            uVar13 = (uint64_t)((int32_t)uVar13 - 1);
            *in_RCX = '\0';
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1;
    }
    iVar4 = (int32_t)uVar13;
    if (bVar2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf7d;
        iVar9 = func_0x000180297c80(iVar7);
        if (iVar9 == 0) goto code_r0x00018022ce68;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf91;
        iVar5 = func_0x000180498cd0(iVar9);
        if (in_RCX != (char *)0x0) {
            if (1 < iVar4) {
                *in_RCX = '.';
                in_RCX = in_RCX + 1;
                iVar4 = iVar4 + -1;
                *in_RCX = '\0';
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cfbe;
            func_0x000180223790(in_RCX, iVar9, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1 + iVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cff5;
        func_0x000180224990(iVar9, 0x1804e1b50, 0x20a);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d010;
        func_0x000180245f70((int64_t)&var_4h + iVar6 + 4, 0x1a, 0x1804e1ba4, uVar11);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d01a;
        iVar5 = func_0x000180498cd0((int64_t)&var_4h + iVar6 + 4);
        if ((in_RCX != (char *)0x0) && (0 < iVar4)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d03a;
            func_0x000180223790(in_RCX, (int64_t)&var_4h + iVar6 + 4, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + iVar5;
    }
    if (iVar3 < 1) goto code_r0x00018022d063;
    goto code_r0x00018022ce30;
}

// ============================================================
// Function: FUN_18022ce8c
// Address: 0x18022ce8c
// Size: 24 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.18022cd40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    uint8_t uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar10;
    uint64_t uVar11;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint8_t *puVar12;
    undefined8 unaff_R13;
    uint64_t uVar13;
    int64_t var_4h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18022cd51;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_28h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6);
    uVar13 = (uint64_t)in_EDX;
    *(undefined4 *)(&stack0x00000018 + iVar6 + -0x18) = 0;
    if ((in_RCX != (char *)0x0) && (0 < in_EDX)) {
        *in_RCX = '\0';
    }
    if ((in_R8 == 0) || (*(int64_t *)(in_R8 + 0x18) == 0)) goto code_r0x00018022ce8c;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdab;
        iVar3 = func_0x00018022dde0(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdb8;
            iVar7 = fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                  *(int64_t *)((int64_t)&var_4h + iVar6 + 4), *(int64_t *)(&stack0x00000018 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
            if ((iVar7 == 0) || (iVar7 = *(int64_t *)(iVar7 + 8), iVar7 == 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdcd;
                piVar8 = (int64_t *)
                         fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                       *(int64_t *)((int64_t)&var_4h + iVar6 + 4), 
                                       *(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                if ((piVar8 == (int64_t *)0x0) || (iVar7 = *piVar8, iVar7 == 0)) goto code_r0x00018022cdfa;
            }
            if (in_RCX != (char *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cded;
                func_0x000180223790(in_RCX, iVar7, uVar13);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdf5;
            func_0x000180498cd0(iVar7);
            goto code_r0x00018022ce8c;
        }
    }
code_r0x00018022cdfa:
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R12;
    iVar7 = 0;
    puVar12 = *(uint8_t **)(in_R8 + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_R13;
    iVar3 = *(int32_t *)(in_R8 + 0x14);
    *(undefined4 *)((int64_t)&var_4h + iVar6) = 1;
    if (iVar3 < 0x24b) {
        if (0 < iVar3) {
code_r0x00018022ce30:
            uVar11 = 0;
            bVar2 = false;
code_r0x00018022ce40:
            do {
                uVar1 = *puVar12;
                puVar12 = puVar12 + 1;
                iVar3 = iVar3 + -1;
                if ((iVar3 == 0) && ((char)uVar1 < '\0')) goto code_r0x00018022ce68;
                if (bVar2) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce64;
                    iVar4 = func_0x000180296ea0(iVar7, uVar1 & 0x7f);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                } else {
                    uVar11 = (uint64_t)((uint32_t)uVar11 | uVar1 & 0x7f);
                }
                uVar10 = (uint32_t)uVar11;
                if (-1 < (char)uVar1) goto code_r0x00018022cf06;
                if (!bVar2) {
                    if (uVar10 < 0x2000000) {
                        uVar11 = (uint64_t)(uVar10 << 7);
                        goto code_r0x00018022ce40;
                    }
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cec5;
                        iVar7 = func_0x0001802554c0();
                        if (iVar7 == 0) goto code_r0x00018022ce68;
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ced7;
                    iVar4 = func_0x000180255860(iVar7, uVar11);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                    bVar2 = true;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cef1;
                iVar4 = func_0x0001802974c0(iVar7, iVar7, 7);
                if (iVar4 == 0) goto code_r0x00018022ce68;
            } while( true );
        }
code_r0x00018022d063:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d06b;
        func_0x000180255290(iVar7);
    } else {
code_r0x00018022ce68:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce70;
        func_0x000180255290(iVar7);
    }
code_r0x00018022ce8c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce99;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6));
    return;
code_r0x00018022cf06:
    if (*(int32_t *)((int64_t)&var_4h + iVar6) != 0) {
        *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
        if (uVar10 < 0x50) {
            iVar4 = (int32_t)(uVar11 / 0x28);
            uVar11 = (uint64_t)(uVar10 + iVar4 * -0x28);
        } else {
            iVar4 = 2;
            if (bVar2) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf2e;
                iVar5 = func_0x0001802973b0(iVar7, 0x50);
                if (iVar5 == 0) goto code_r0x00018022ce68;
            } else {
                uVar11 = (uint64_t)(uVar10 - 0x50);
            }
        }
        if ((in_RCX != (char *)0x0) && (1 < (int32_t)uVar13)) {
            *in_RCX = (char)iVar4 + '0';
            in_RCX = in_RCX + 1;
            uVar13 = (uint64_t)((int32_t)uVar13 - 1);
            *in_RCX = '\0';
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1;
    }
    iVar4 = (int32_t)uVar13;
    if (bVar2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf7d;
        iVar9 = func_0x000180297c80(iVar7);
        if (iVar9 == 0) goto code_r0x00018022ce68;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf91;
        iVar5 = func_0x000180498cd0(iVar9);
        if (in_RCX != (char *)0x0) {
            if (1 < iVar4) {
                *in_RCX = '.';
                in_RCX = in_RCX + 1;
                iVar4 = iVar4 + -1;
                *in_RCX = '\0';
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cfbe;
            func_0x000180223790(in_RCX, iVar9, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1 + iVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cff5;
        func_0x000180224990(iVar9, 0x1804e1b50, 0x20a);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d010;
        func_0x000180245f70((int64_t)&var_4h + iVar6 + 4, 0x1a, 0x1804e1ba4, uVar11);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d01a;
        iVar5 = func_0x000180498cd0((int64_t)&var_4h + iVar6 + 4);
        if ((in_RCX != (char *)0x0) && (0 < iVar4)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d03a;
            func_0x000180223790(in_RCX, (int64_t)&var_4h + iVar6 + 4, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + iVar5;
    }
    if (iVar3 < 1) goto code_r0x00018022d063;
    goto code_r0x00018022ce30;
}

// ============================================================
// Function: FUN_18022cea4
// Address: 0x18022cea4
// Size: 462 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.18022cd40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    uint8_t uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar10;
    uint64_t uVar11;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint8_t *puVar12;
    undefined8 unaff_R13;
    uint64_t uVar13;
    int64_t var_4h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18022cd51;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_28h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6);
    uVar13 = (uint64_t)in_EDX;
    *(undefined4 *)(&stack0x00000018 + iVar6 + -0x18) = 0;
    if ((in_RCX != (char *)0x0) && (0 < in_EDX)) {
        *in_RCX = '\0';
    }
    if ((in_R8 == 0) || (*(int64_t *)(in_R8 + 0x18) == 0)) goto code_r0x00018022ce8c;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdab;
        iVar3 = func_0x00018022dde0(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdb8;
            iVar7 = fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                  *(int64_t *)((int64_t)&var_4h + iVar6 + 4), *(int64_t *)(&stack0x00000018 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
            if ((iVar7 == 0) || (iVar7 = *(int64_t *)(iVar7 + 8), iVar7 == 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdcd;
                piVar8 = (int64_t *)
                         fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                       *(int64_t *)((int64_t)&var_4h + iVar6 + 4), 
                                       *(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                if ((piVar8 == (int64_t *)0x0) || (iVar7 = *piVar8, iVar7 == 0)) goto code_r0x00018022cdfa;
            }
            if (in_RCX != (char *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cded;
                func_0x000180223790(in_RCX, iVar7, uVar13);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdf5;
            func_0x000180498cd0(iVar7);
            goto code_r0x00018022ce8c;
        }
    }
code_r0x00018022cdfa:
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R12;
    iVar7 = 0;
    puVar12 = *(uint8_t **)(in_R8 + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_R13;
    iVar3 = *(int32_t *)(in_R8 + 0x14);
    *(undefined4 *)((int64_t)&var_4h + iVar6) = 1;
    if (iVar3 < 0x24b) {
        if (0 < iVar3) {
code_r0x00018022ce30:
            uVar11 = 0;
            bVar2 = false;
code_r0x00018022ce40:
            do {
                uVar1 = *puVar12;
                puVar12 = puVar12 + 1;
                iVar3 = iVar3 + -1;
                if ((iVar3 == 0) && ((char)uVar1 < '\0')) goto code_r0x00018022ce68;
                if (bVar2) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce64;
                    iVar4 = func_0x000180296ea0(iVar7, uVar1 & 0x7f);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                } else {
                    uVar11 = (uint64_t)((uint32_t)uVar11 | uVar1 & 0x7f);
                }
                uVar10 = (uint32_t)uVar11;
                if (-1 < (char)uVar1) goto code_r0x00018022cf06;
                if (!bVar2) {
                    if (uVar10 < 0x2000000) {
                        uVar11 = (uint64_t)(uVar10 << 7);
                        goto code_r0x00018022ce40;
                    }
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cec5;
                        iVar7 = func_0x0001802554c0();
                        if (iVar7 == 0) goto code_r0x00018022ce68;
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ced7;
                    iVar4 = func_0x000180255860(iVar7, uVar11);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                    bVar2 = true;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cef1;
                iVar4 = func_0x0001802974c0(iVar7, iVar7, 7);
                if (iVar4 == 0) goto code_r0x00018022ce68;
            } while( true );
        }
code_r0x00018022d063:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d06b;
        func_0x000180255290(iVar7);
    } else {
code_r0x00018022ce68:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce70;
        func_0x000180255290(iVar7);
    }
code_r0x00018022ce8c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce99;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6));
    return;
code_r0x00018022cf06:
    if (*(int32_t *)((int64_t)&var_4h + iVar6) != 0) {
        *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
        if (uVar10 < 0x50) {
            iVar4 = (int32_t)(uVar11 / 0x28);
            uVar11 = (uint64_t)(uVar10 + iVar4 * -0x28);
        } else {
            iVar4 = 2;
            if (bVar2) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf2e;
                iVar5 = func_0x0001802973b0(iVar7, 0x50);
                if (iVar5 == 0) goto code_r0x00018022ce68;
            } else {
                uVar11 = (uint64_t)(uVar10 - 0x50);
            }
        }
        if ((in_RCX != (char *)0x0) && (1 < (int32_t)uVar13)) {
            *in_RCX = (char)iVar4 + '0';
            in_RCX = in_RCX + 1;
            uVar13 = (uint64_t)((int32_t)uVar13 - 1);
            *in_RCX = '\0';
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1;
    }
    iVar4 = (int32_t)uVar13;
    if (bVar2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf7d;
        iVar9 = func_0x000180297c80(iVar7);
        if (iVar9 == 0) goto code_r0x00018022ce68;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf91;
        iVar5 = func_0x000180498cd0(iVar9);
        if (in_RCX != (char *)0x0) {
            if (1 < iVar4) {
                *in_RCX = '.';
                in_RCX = in_RCX + 1;
                iVar4 = iVar4 + -1;
                *in_RCX = '\0';
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cfbe;
            func_0x000180223790(in_RCX, iVar9, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1 + iVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cff5;
        func_0x000180224990(iVar9, 0x1804e1b50, 0x20a);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d010;
        func_0x000180245f70((int64_t)&var_4h + iVar6 + 4, 0x1a, 0x1804e1ba4, uVar11);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d01a;
        iVar5 = func_0x000180498cd0((int64_t)&var_4h + iVar6 + 4);
        if ((in_RCX != (char *)0x0) && (0 < iVar4)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d03a;
            func_0x000180223790(in_RCX, (int64_t)&var_4h + iVar6 + 4, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + iVar5;
    }
    if (iVar3 < 1) goto code_r0x00018022d063;
    goto code_r0x00018022ce30;
}

// ============================================================
// Function: FUN_18022d072
// Address: 0x18022d072
// Size: 7 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.18022cd40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    uint8_t uVar1;
    bool bVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint32_t uVar10;
    uint64_t uVar11;
    int64_t in_R8;
    int32_t in_R9D;
    undefined8 unaff_R12;
    uint8_t *puVar12;
    undefined8 unaff_R13;
    uint64_t uVar13;
    int64_t var_4h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18022cd51;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_28h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6);
    uVar13 = (uint64_t)in_EDX;
    *(undefined4 *)(&stack0x00000018 + iVar6 + -0x18) = 0;
    if ((in_RCX != (char *)0x0) && (0 < in_EDX)) {
        *in_RCX = '\0';
    }
    if ((in_R8 == 0) || (*(int64_t *)(in_R8 + 0x18) == 0)) goto code_r0x00018022ce8c;
    *(undefined8 *)((int64_t)&arg_88h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    if (in_R9D == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdab;
        iVar3 = func_0x00018022dde0(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdb8;
            iVar7 = fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                  *(int64_t *)((int64_t)&var_4h + iVar6 + 4), *(int64_t *)(&stack0x00000018 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
            if ((iVar7 == 0) || (iVar7 = *(int64_t *)(iVar7 + 8), iVar7 == 0)) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdcd;
                piVar8 = (int64_t *)
                         fcn.18022cba0(*(int64_t *)(&stack0x00000018 + iVar6 + -0x18), 
                                       *(int64_t *)((int64_t)&var_4h + iVar6 + 4), 
                                       *(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                if ((piVar8 == (int64_t *)0x0) || (iVar7 = *piVar8, iVar7 == 0)) goto code_r0x00018022cdfa;
            }
            if (in_RCX != (char *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cded;
                func_0x000180223790(in_RCX, iVar7, uVar13);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cdf5;
            func_0x000180498cd0(iVar7);
            goto code_r0x00018022ce8c;
        }
    }
code_r0x00018022cdfa:
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R12;
    iVar7 = 0;
    puVar12 = *(uint8_t **)(in_R8 + 0x18);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_R13;
    iVar3 = *(int32_t *)(in_R8 + 0x14);
    *(undefined4 *)((int64_t)&var_4h + iVar6) = 1;
    if (iVar3 < 0x24b) {
        if (0 < iVar3) {
code_r0x00018022ce30:
            uVar11 = 0;
            bVar2 = false;
code_r0x00018022ce40:
            do {
                uVar1 = *puVar12;
                puVar12 = puVar12 + 1;
                iVar3 = iVar3 + -1;
                if ((iVar3 == 0) && ((char)uVar1 < '\0')) goto code_r0x00018022ce68;
                if (bVar2) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce64;
                    iVar4 = func_0x000180296ea0(iVar7, uVar1 & 0x7f);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                } else {
                    uVar11 = (uint64_t)((uint32_t)uVar11 | uVar1 & 0x7f);
                }
                uVar10 = (uint32_t)uVar11;
                if (-1 < (char)uVar1) goto code_r0x00018022cf06;
                if (!bVar2) {
                    if (uVar10 < 0x2000000) {
                        uVar11 = (uint64_t)(uVar10 << 7);
                        goto code_r0x00018022ce40;
                    }
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cec5;
                        iVar7 = func_0x0001802554c0();
                        if (iVar7 == 0) goto code_r0x00018022ce68;
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ced7;
                    iVar4 = func_0x000180255860(iVar7, uVar11);
                    if (iVar4 == 0) goto code_r0x00018022ce68;
                    bVar2 = true;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cef1;
                iVar4 = func_0x0001802974c0(iVar7, iVar7, 7);
                if (iVar4 == 0) goto code_r0x00018022ce68;
            } while( true );
        }
code_r0x00018022d063:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d06b;
        func_0x000180255290(iVar7);
    } else {
code_r0x00018022ce68:
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce70;
        func_0x000180255290(iVar7);
    }
code_r0x00018022ce8c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022ce99;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar6));
    return;
code_r0x00018022cf06:
    if (*(int32_t *)((int64_t)&var_4h + iVar6) != 0) {
        *(undefined4 *)((int64_t)&var_4h + iVar6) = 0;
        if (uVar10 < 0x50) {
            iVar4 = (int32_t)(uVar11 / 0x28);
            uVar11 = (uint64_t)(uVar10 + iVar4 * -0x28);
        } else {
            iVar4 = 2;
            if (bVar2) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf2e;
                iVar5 = func_0x0001802973b0(iVar7, 0x50);
                if (iVar5 == 0) goto code_r0x00018022ce68;
            } else {
                uVar11 = (uint64_t)(uVar10 - 0x50);
            }
        }
        if ((in_RCX != (char *)0x0) && (1 < (int32_t)uVar13)) {
            *in_RCX = (char)iVar4 + '0';
            in_RCX = in_RCX + 1;
            uVar13 = (uint64_t)((int32_t)uVar13 - 1);
            *in_RCX = '\0';
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1;
    }
    iVar4 = (int32_t)uVar13;
    if (bVar2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf7d;
        iVar9 = func_0x000180297c80(iVar7);
        if (iVar9 == 0) goto code_r0x00018022ce68;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cf91;
        iVar5 = func_0x000180498cd0(iVar9);
        if (in_RCX != (char *)0x0) {
            if (1 < iVar4) {
                *in_RCX = '.';
                in_RCX = in_RCX + 1;
                iVar4 = iVar4 + -1;
                *in_RCX = '\0';
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cfbe;
            func_0x000180223790(in_RCX, iVar9, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + 1 + iVar5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022cff5;
        func_0x000180224990(iVar9, 0x1804e1b50, 0x20a);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d010;
        func_0x000180245f70((int64_t)&var_4h + iVar6 + 4, 0x1a, 0x1804e1ba4, uVar11);
        *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d01a;
        iVar5 = func_0x000180498cd0((int64_t)&var_4h + iVar6 + 4);
        if ((in_RCX != (char *)0x0) && (0 < iVar4)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar6) = 0x18022d03a;
            func_0x000180223790(in_RCX, (int64_t)&var_4h + iVar6 + 4, (int64_t)iVar4);
            if (iVar4 < iVar5) {
                in_RCX = in_RCX + iVar4;
                uVar13 = 0;
            } else {
                in_RCX = in_RCX + iVar5;
                uVar13 = (uint64_t)(uint32_t)(iVar4 - iVar5);
            }
        }
        *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) = *(int32_t *)(&stack0x00000018 + iVar6 + -0x18) + iVar5;
    }
    if (iVar3 < 1) goto code_r0x00018022d063;
    goto code_r0x00018022ce30;
}

// ============================================================
// Function: FUN_18022d080
// Address: 0x18022d080
// Size: 294 bytes
// ============================================================
undefined4 fcn.18022d080(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint32_t *puVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    undefined4 uVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022d08c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = in_RCX;
    *(int64_t *)((int64_t)&arg_78h + iVar3) = (int64_t)&arg_38h + iVar3;
    uVar6 = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0x18022df40;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d0d3;
    puVar4 = (uint32_t *)
             fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                           *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                           *(int64_t *)(&stack0x00000040 + iVar3));
    if (puVar4 != (uint32_t *)0x0) {
        return *(undefined4 *)((uint64_t)*puVar4 * 0x28 + 0x1804c3050);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d0fa;
    fcn.180243560(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d10d;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_18h + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e4b4;
    }
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d128;
        iVar2 = fcn.180222850(*(undefined8 *)0x18077e4a8);
        if (iVar2 != 0) {
            *(int64_t *)((int64_t)&arg_30h + iVar3) = (int64_t)&arg_38h + iVar3;
            *(undefined4 *)((int64_t)&arg_28h + iVar3) = 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d14f;
            iVar5 = fcn.180229240(*(int64_t *)((int64_t)&var_20h + iVar3));
            if (iVar5 != 0) {
                uVar6 = *(undefined4 *)(*(int64_t *)(iVar5 + 8) + 0x10);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d167;
            fcn.180222910(*(undefined8 *)0x18077e4a8);
            return uVar6;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d174;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d18c;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d19e;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18022d1b0
// Address: 0x18022d1b0
// Size: 33 bytes
// ============================================================
undefined4 fcn.18022d1b0(int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022d1bc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1c6;
    iVar3 = fcn.18022d200(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1db;
        uVar1 = fcn.18022dde0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1e5;
        fcn.18027c100(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        return uVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18022d1d1
// Address: 0x18022d1d1
// Size: 33 bytes
// ============================================================
undefined4 fcn.18022d1b0(int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022d1bc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1c6;
    iVar3 = fcn.18022d200(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1db;
        uVar1 = fcn.18022dde0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1e5;
        fcn.18027c100(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        return uVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18022d1f2
// Address: 0x18022d1f2
// Size: 6 bytes
// ============================================================
undefined4 fcn.18022d1b0(int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022d1bc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1c6;
    iVar3 = fcn.18022d200(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1db;
        uVar1 = fcn.18022dde0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022d1e5;
        fcn.18027c100(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        return uVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18022d200
// Address: 0x18022d200
// Size: 348 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.18022d200(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18022d20c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_EDX != 0) {
code_r0x00018022d27b:
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d29c;
        iVar2 = fcn.18027c1f0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3));
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d2b5;
            iVar2 = fcn.180296c90(0, iVar2, 6);
            if (-1 < iVar2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d2d5;
                iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                if (iVar4 != 0) {
                    *(int64_t *)((int64_t)&arg_58h + iVar3) = iVar4;
                    *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d2ff;
                    fcn.180296d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d314;
                    fcn.18027c1f0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3));
                    *(int64_t *)((int64_t)&arg_60h + iVar3) = iVar4;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d328;
                    uVar5 = fcn.18027c6d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3)
                                          , *(int64_t *)(&stack0x00000050 + iVar3), 
                                          *(int64_t *)(&stack0x00000070 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d340;
                    fcn.180224990(iVar4, 0x1804e1b50, 0x185);
                    return uVar5;
                }
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d21b;
    iVar2 = fcn.18022d080(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d227;
        iVar2 = fcn.18022ca40(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            cVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d233;
            iVar2 = fcn.180275480((int32_t)cVar1);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d23c;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d254;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d266;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                return 0;
            }
            goto code_r0x00018022d27b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022d275;
    uVar5 = fcn.18022cba0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3));
    return uVar5;
}

// ============================================================
// Function: FUN_18022d360
// Address: 0x18022d360
// Size: 343 bytes
// ============================================================
int64_t * fcn.18022d360(int64_t arg_28h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t iVar11;
    int32_t in_EDX;
    int64_t iVar12;
    uint32_t uVar13;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined8 unaff_R12;
    int64_t *piVar17;
    int64_t *piVar18;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18022d372;
    iVar4 = fcn.18045a350();
    iVar2 = *(int32_t *)0x1806a0038;
    iVar4 = -iVar4;
    piVar14 = (int64_t *)0x0;
    piVar15 = (int64_t *)0x0;
    *(int64_t **)((int64_t)&var_8h + iVar4) = in_RCX;
    iVar3 = *(int32_t *)(in_RCX + 2);
    piVar17 = (int64_t *)0x0;
    *(undefined (*) [16])((int64_t)&var_10h + iVar4) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_20h + iVar4) = ZEXT816(0);
    if (in_EDX == 0) {
        if (iVar3 < 0x5dd) {
            return (int64_t *)0x0;
        }
        if (in_RCX[3] != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022dcf0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d417;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
            in_RCX = *(int64_t **)((int64_t)&var_8h + iVar4);
        }
        if (*in_RCX != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022df40;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d457;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
            in_RCX = *(int64_t **)((int64_t)&var_8h + iVar4);
        }
        if (in_RCX[1] != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022dc20;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d498;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d4ab;
        piVar5 = (int64_t *)func_0x0001802983b0();
        if (piVar5 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
    } else {
        if (iVar3 != 0) {
            return (int64_t *)0x0;
        }
        LOCK();
        UNLOCK();
        if (*(int32_t *)0x1806a0038 < 0x5dd) {
            *(int32_t *)0x1806a0038 = *(int32_t *)0x1806a0038 + 1;
            return (int64_t *)0x0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d3c5;
        *(int32_t *)0x1806a0038 = *(int32_t *)0x1806a0038 + 1;
        piVar5 = (int64_t *)func_0x0001802983b0(*(undefined8 *)((int64_t)&var_8h + iVar4));
        if (piVar5 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
        *(int32_t *)(piVar5 + 2) = iVar2;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d4e6;
    puVar6 = (undefined4 *)
             fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined4 **)((int64_t)&arg_28h + iVar4) = puVar6;
    piVar16 = piVar14;
    piVar18 = piVar14;
    if (puVar6 == (undefined4 *)0x0) goto code_r0x00018022d880;
    piVar18 = piVar17;
    if ((*(int32_t *)((int64_t)piVar5 + 0x14) == 0) ||
       (*(int64_t *)(*(int64_t *)((int64_t)&var_8h + iVar4) + 0x18) == 0)) {
        puVar7 = *(undefined4 **)((int64_t)&var_10h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d51f;
        puVar7 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_10h + iVar4) = puVar7;
        if (puVar7 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    if (*piVar5 == 0) {
        puVar8 = *(undefined4 **)((int64_t)&var_18h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d553;
        puVar8 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_18h + iVar4) = puVar8;
        if (puVar8 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    piVar16 = piVar15;
    if (piVar5[1] == 0) {
        puVar9 = *(undefined4 **)((int64_t)&var_20h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d588;
        puVar9 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_20h + iVar4) = puVar9;
        if (puVar9 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5ac;
    fcn.180243560(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5bf;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e4b4;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5de;
        iVar3 = fcn.180222950(*(undefined8 *)0x18077e4a8);
        if (iVar3 != 0) {
            piVar15 = piVar14;
            if (puVar7 != (undefined4 *)0x0) {
                *puVar7 = 0;
                *(int64_t **)(puVar7 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d601;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                piVar15 = (int64_t *)0x0;
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar8 != (undefined4 *)0x0) {
                *puVar8 = 1;
                *(int64_t **)(puVar8 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d629;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar9 != (undefined4 *)0x0) {
                *puVar9 = 2;
                *(int64_t **)(puVar9 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d650;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar6 != (undefined4 *)0x0) {
                *puVar6 = 3;
                *(int64_t **)(puVar6 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d67a;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            piVar17 = piVar14;
            if (piVar15 == (int64_t *)0x0) {
                do {
                    iVar10 = (int64_t)&var_10h + (int64_t)piVar17 * 8 + iVar4;
                    uVar13 = (uint32_t)piVar14;
                    if (*(int64_t *)((int64_t)&var_10h + (int64_t)piVar17 * 8 + iVar4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d78e;
                        func_0x000180228fb0(*(undefined8 *)0x18077e4a0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d79a;
                        iVar3 = func_0x000180228e00(*(undefined8 *)0x18077e4a0);
                        if (iVar3 != 0) goto joined_r0x00018022d7e3;
                    }
                    piVar14 = (int64_t *)(uint64_t)(uVar13 + 1);
                    piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                    if (3 < (int32_t)(uVar13 + 1)) {
                        *(uint32_t *)(piVar5 + 4) = *(uint32_t *)(piVar5 + 4) & 0xfffffff2;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d7b9;
                        fcn.180222910(*(undefined8 *)0x18077e4a8);
                        return (int64_t *)(uint64_t)*(uint32_t *)(piVar5 + 2);
                    }
                } while( true );
            }
            piVar14 = *(int64_t **)((int64_t)&var_8h + iVar4);
            uVar13 = *(uint32_t *)(piVar15 + 2);
            if ((*(uint32_t *)(piVar14 + 2) == uVar13) &&
               (iVar3 = *(int32_t *)((int64_t)piVar14 + 0x14), iVar3 == *(int32_t *)((int64_t)piVar15 + 0x14))) {
                iVar10 = piVar15[3];
                iVar11 = piVar14[3];
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d6ba;
                iVar3 = func_0x000180497f30(iVar11, iVar10, (int64_t)iVar3);
                if (iVar3 == 0) {
                    iVar10 = *piVar14;
                    iVar11 = *piVar15;
                    if ((iVar10 == 0) == (iVar11 == 0)) {
                        iVar12 = 0x1805aadb1;
                        if (iVar11 != 0) {
                            iVar12 = iVar11;
                        }
                        iVar11 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            iVar11 = iVar10;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d700;
                        iVar3 = func_0x000180498f10(iVar11, iVar12);
                        if (iVar3 == 0) {
                            iVar10 = piVar14[1];
                            iVar11 = piVar15[1];
                            if ((iVar10 == 0) == (iVar11 == 0)) {
                                iVar12 = 0x1805aadb1;
                                if (iVar11 != 0) {
                                    iVar12 = iVar11;
                                }
                                iVar11 = 0x1805aadb1;
                                if (iVar10 != 0) {
                                    iVar11 = iVar10;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d741;
                                iVar3 = func_0x000180498f10(iVar11, iVar12);
                                if (iVar3 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d758;
                                    fcn.180222910(*(undefined8 *)0x18077e4a8);
                                    piVar18 = (int64_t *)(uint64_t)uVar13;
                                    goto code_r0x00018022d880;
                                }
                            }
                        }
                    }
                }
            }
            goto code_r0x00018022d83e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d851;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d869;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d87b;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x00018022d880:
    do {
        uVar1 = *(undefined8 *)((int64_t)&var_10h + (int64_t)piVar16 * 8 + iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d897;
        fcn.180224990(uVar1, 0x1804e1b50, 0x35c);
        piVar16 = (int64_t *)((int64_t)piVar16 + 1);
    } while ((int64_t)piVar16 < 4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d8a8;
    fcn.18027c100(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    return piVar18;
joined_r0x00018022d7e3:
    while (0 < (int32_t)uVar13) {
        piVar15 = (int64_t *)(iVar10 + -8);
        iVar10 = iVar10 + -8;
        uVar13 = (int32_t)piVar14 - 1;
        piVar14 = (int64_t *)(uint64_t)uVar13;
        if (*piVar15 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d80b;
            func_0x000180228b10(*(undefined8 *)0x18077e4a0);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d814;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d82c;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d83e;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x00018022d83e:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d84a;
    fcn.180222910(*(undefined8 *)0x18077e4a8);
    goto code_r0x00018022d880;
}

// ============================================================
// Function: FUN_18022d4b7
// Address: 0x18022d4b7
// Size: 810 bytes
// ============================================================
int64_t * fcn.18022d360(int64_t arg_28h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t iVar11;
    int32_t in_EDX;
    int64_t iVar12;
    uint32_t uVar13;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined8 unaff_R12;
    int64_t *piVar17;
    int64_t *piVar18;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18022d372;
    iVar4 = fcn.18045a350();
    iVar2 = *(int32_t *)0x1806a0038;
    iVar4 = -iVar4;
    piVar14 = (int64_t *)0x0;
    piVar15 = (int64_t *)0x0;
    *(int64_t **)((int64_t)&var_8h + iVar4) = in_RCX;
    iVar3 = *(int32_t *)(in_RCX + 2);
    piVar17 = (int64_t *)0x0;
    *(undefined (*) [16])((int64_t)&var_10h + iVar4) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_20h + iVar4) = ZEXT816(0);
    if (in_EDX == 0) {
        if (iVar3 < 0x5dd) {
            return (int64_t *)0x0;
        }
        if (in_RCX[3] != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022dcf0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d417;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
            in_RCX = *(int64_t **)((int64_t)&var_8h + iVar4);
        }
        if (*in_RCX != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022df40;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d457;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
            in_RCX = *(int64_t **)((int64_t)&var_8h + iVar4);
        }
        if (in_RCX[1] != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022dc20;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d498;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d4ab;
        piVar5 = (int64_t *)func_0x0001802983b0();
        if (piVar5 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
    } else {
        if (iVar3 != 0) {
            return (int64_t *)0x0;
        }
        LOCK();
        UNLOCK();
        if (*(int32_t *)0x1806a0038 < 0x5dd) {
            *(int32_t *)0x1806a0038 = *(int32_t *)0x1806a0038 + 1;
            return (int64_t *)0x0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d3c5;
        *(int32_t *)0x1806a0038 = *(int32_t *)0x1806a0038 + 1;
        piVar5 = (int64_t *)func_0x0001802983b0(*(undefined8 *)((int64_t)&var_8h + iVar4));
        if (piVar5 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
        *(int32_t *)(piVar5 + 2) = iVar2;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d4e6;
    puVar6 = (undefined4 *)
             fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined4 **)((int64_t)&arg_28h + iVar4) = puVar6;
    piVar16 = piVar14;
    piVar18 = piVar14;
    if (puVar6 == (undefined4 *)0x0) goto code_r0x00018022d880;
    piVar18 = piVar17;
    if ((*(int32_t *)((int64_t)piVar5 + 0x14) == 0) ||
       (*(int64_t *)(*(int64_t *)((int64_t)&var_8h + iVar4) + 0x18) == 0)) {
        puVar7 = *(undefined4 **)((int64_t)&var_10h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d51f;
        puVar7 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_10h + iVar4) = puVar7;
        if (puVar7 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    if (*piVar5 == 0) {
        puVar8 = *(undefined4 **)((int64_t)&var_18h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d553;
        puVar8 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_18h + iVar4) = puVar8;
        if (puVar8 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    piVar16 = piVar15;
    if (piVar5[1] == 0) {
        puVar9 = *(undefined4 **)((int64_t)&var_20h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d588;
        puVar9 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_20h + iVar4) = puVar9;
        if (puVar9 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5ac;
    fcn.180243560(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5bf;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e4b4;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5de;
        iVar3 = fcn.180222950(*(undefined8 *)0x18077e4a8);
        if (iVar3 != 0) {
            piVar15 = piVar14;
            if (puVar7 != (undefined4 *)0x0) {
                *puVar7 = 0;
                *(int64_t **)(puVar7 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d601;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                piVar15 = (int64_t *)0x0;
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar8 != (undefined4 *)0x0) {
                *puVar8 = 1;
                *(int64_t **)(puVar8 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d629;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar9 != (undefined4 *)0x0) {
                *puVar9 = 2;
                *(int64_t **)(puVar9 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d650;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar6 != (undefined4 *)0x0) {
                *puVar6 = 3;
                *(int64_t **)(puVar6 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d67a;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            piVar17 = piVar14;
            if (piVar15 == (int64_t *)0x0) {
                do {
                    iVar10 = (int64_t)&var_10h + (int64_t)piVar17 * 8 + iVar4;
                    uVar13 = (uint32_t)piVar14;
                    if (*(int64_t *)((int64_t)&var_10h + (int64_t)piVar17 * 8 + iVar4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d78e;
                        func_0x000180228fb0(*(undefined8 *)0x18077e4a0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d79a;
                        iVar3 = func_0x000180228e00(*(undefined8 *)0x18077e4a0);
                        if (iVar3 != 0) goto joined_r0x00018022d7e3;
                    }
                    piVar14 = (int64_t *)(uint64_t)(uVar13 + 1);
                    piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                    if (3 < (int32_t)(uVar13 + 1)) {
                        *(uint32_t *)(piVar5 + 4) = *(uint32_t *)(piVar5 + 4) & 0xfffffff2;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d7b9;
                        fcn.180222910(*(undefined8 *)0x18077e4a8);
                        return (int64_t *)(uint64_t)*(uint32_t *)(piVar5 + 2);
                    }
                } while( true );
            }
            piVar14 = *(int64_t **)((int64_t)&var_8h + iVar4);
            uVar13 = *(uint32_t *)(piVar15 + 2);
            if ((*(uint32_t *)(piVar14 + 2) == uVar13) &&
               (iVar3 = *(int32_t *)((int64_t)piVar14 + 0x14), iVar3 == *(int32_t *)((int64_t)piVar15 + 0x14))) {
                iVar10 = piVar15[3];
                iVar11 = piVar14[3];
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d6ba;
                iVar3 = func_0x000180497f30(iVar11, iVar10, (int64_t)iVar3);
                if (iVar3 == 0) {
                    iVar10 = *piVar14;
                    iVar11 = *piVar15;
                    if ((iVar10 == 0) == (iVar11 == 0)) {
                        iVar12 = 0x1805aadb1;
                        if (iVar11 != 0) {
                            iVar12 = iVar11;
                        }
                        iVar11 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            iVar11 = iVar10;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d700;
                        iVar3 = func_0x000180498f10(iVar11, iVar12);
                        if (iVar3 == 0) {
                            iVar10 = piVar14[1];
                            iVar11 = piVar15[1];
                            if ((iVar10 == 0) == (iVar11 == 0)) {
                                iVar12 = 0x1805aadb1;
                                if (iVar11 != 0) {
                                    iVar12 = iVar11;
                                }
                                iVar11 = 0x1805aadb1;
                                if (iVar10 != 0) {
                                    iVar11 = iVar10;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d741;
                                iVar3 = func_0x000180498f10(iVar11, iVar12);
                                if (iVar3 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d758;
                                    fcn.180222910(*(undefined8 *)0x18077e4a8);
                                    piVar18 = (int64_t *)(uint64_t)uVar13;
                                    goto code_r0x00018022d880;
                                }
                            }
                        }
                    }
                }
            }
            goto code_r0x00018022d83e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d851;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d869;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d87b;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x00018022d880:
    do {
        uVar1 = *(undefined8 *)((int64_t)&var_10h + (int64_t)piVar16 * 8 + iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d897;
        fcn.180224990(uVar1, 0x1804e1b50, 0x35c);
        piVar16 = (int64_t *)((int64_t)piVar16 + 1);
    } while ((int64_t)piVar16 < 4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d8a8;
    fcn.18027c100(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    return piVar18;
joined_r0x00018022d7e3:
    while (0 < (int32_t)uVar13) {
        piVar15 = (int64_t *)(iVar10 + -8);
        iVar10 = iVar10 + -8;
        uVar13 = (int32_t)piVar14 - 1;
        piVar14 = (int64_t *)(uint64_t)uVar13;
        if (*piVar15 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d80b;
            func_0x000180228b10(*(undefined8 *)0x18077e4a0);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d814;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d82c;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d83e;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x00018022d83e:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d84a;
    fcn.180222910(*(undefined8 *)0x18077e4a8);
    goto code_r0x00018022d880;
}

// ============================================================
// Function: FUN_18022d7e1
// Address: 0x18022d7e1
// Size: 207 bytes
// ============================================================
int64_t * fcn.18022d360(int64_t arg_28h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t iVar11;
    int32_t in_EDX;
    int64_t iVar12;
    uint32_t uVar13;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined8 unaff_R12;
    int64_t *piVar17;
    int64_t *piVar18;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18022d372;
    iVar4 = fcn.18045a350();
    iVar2 = *(int32_t *)0x1806a0038;
    iVar4 = -iVar4;
    piVar14 = (int64_t *)0x0;
    piVar15 = (int64_t *)0x0;
    *(int64_t **)((int64_t)&var_8h + iVar4) = in_RCX;
    iVar3 = *(int32_t *)(in_RCX + 2);
    piVar17 = (int64_t *)0x0;
    *(undefined (*) [16])((int64_t)&var_10h + iVar4) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_20h + iVar4) = ZEXT816(0);
    if (in_EDX == 0) {
        if (iVar3 < 0x5dd) {
            return (int64_t *)0x0;
        }
        if (in_RCX[3] != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022dcf0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d417;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
            in_RCX = *(int64_t **)((int64_t)&var_8h + iVar4);
        }
        if (*in_RCX != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022df40;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d457;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
            in_RCX = *(int64_t **)((int64_t)&var_8h + iVar4);
        }
        if (in_RCX[1] != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022dc20;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d498;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d4ab;
        piVar5 = (int64_t *)func_0x0001802983b0();
        if (piVar5 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
    } else {
        if (iVar3 != 0) {
            return (int64_t *)0x0;
        }
        LOCK();
        UNLOCK();
        if (*(int32_t *)0x1806a0038 < 0x5dd) {
            *(int32_t *)0x1806a0038 = *(int32_t *)0x1806a0038 + 1;
            return (int64_t *)0x0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d3c5;
        *(int32_t *)0x1806a0038 = *(int32_t *)0x1806a0038 + 1;
        piVar5 = (int64_t *)func_0x0001802983b0(*(undefined8 *)((int64_t)&var_8h + iVar4));
        if (piVar5 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
        *(int32_t *)(piVar5 + 2) = iVar2;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d4e6;
    puVar6 = (undefined4 *)
             fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined4 **)((int64_t)&arg_28h + iVar4) = puVar6;
    piVar16 = piVar14;
    piVar18 = piVar14;
    if (puVar6 == (undefined4 *)0x0) goto code_r0x00018022d880;
    piVar18 = piVar17;
    if ((*(int32_t *)((int64_t)piVar5 + 0x14) == 0) ||
       (*(int64_t *)(*(int64_t *)((int64_t)&var_8h + iVar4) + 0x18) == 0)) {
        puVar7 = *(undefined4 **)((int64_t)&var_10h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d51f;
        puVar7 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_10h + iVar4) = puVar7;
        if (puVar7 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    if (*piVar5 == 0) {
        puVar8 = *(undefined4 **)((int64_t)&var_18h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d553;
        puVar8 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_18h + iVar4) = puVar8;
        if (puVar8 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    piVar16 = piVar15;
    if (piVar5[1] == 0) {
        puVar9 = *(undefined4 **)((int64_t)&var_20h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d588;
        puVar9 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_20h + iVar4) = puVar9;
        if (puVar9 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5ac;
    fcn.180243560(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5bf;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e4b4;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5de;
        iVar3 = fcn.180222950(*(undefined8 *)0x18077e4a8);
        if (iVar3 != 0) {
            piVar15 = piVar14;
            if (puVar7 != (undefined4 *)0x0) {
                *puVar7 = 0;
                *(int64_t **)(puVar7 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d601;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                piVar15 = (int64_t *)0x0;
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar8 != (undefined4 *)0x0) {
                *puVar8 = 1;
                *(int64_t **)(puVar8 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d629;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar9 != (undefined4 *)0x0) {
                *puVar9 = 2;
                *(int64_t **)(puVar9 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d650;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar6 != (undefined4 *)0x0) {
                *puVar6 = 3;
                *(int64_t **)(puVar6 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d67a;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            piVar17 = piVar14;
            if (piVar15 == (int64_t *)0x0) {
                do {
                    iVar10 = (int64_t)&var_10h + (int64_t)piVar17 * 8 + iVar4;
                    uVar13 = (uint32_t)piVar14;
                    if (*(int64_t *)((int64_t)&var_10h + (int64_t)piVar17 * 8 + iVar4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d78e;
                        func_0x000180228fb0(*(undefined8 *)0x18077e4a0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d79a;
                        iVar3 = func_0x000180228e00(*(undefined8 *)0x18077e4a0);
                        if (iVar3 != 0) goto joined_r0x00018022d7e3;
                    }
                    piVar14 = (int64_t *)(uint64_t)(uVar13 + 1);
                    piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                    if (3 < (int32_t)(uVar13 + 1)) {
                        *(uint32_t *)(piVar5 + 4) = *(uint32_t *)(piVar5 + 4) & 0xfffffff2;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d7b9;
                        fcn.180222910(*(undefined8 *)0x18077e4a8);
                        return (int64_t *)(uint64_t)*(uint32_t *)(piVar5 + 2);
                    }
                } while( true );
            }
            piVar14 = *(int64_t **)((int64_t)&var_8h + iVar4);
            uVar13 = *(uint32_t *)(piVar15 + 2);
            if ((*(uint32_t *)(piVar14 + 2) == uVar13) &&
               (iVar3 = *(int32_t *)((int64_t)piVar14 + 0x14), iVar3 == *(int32_t *)((int64_t)piVar15 + 0x14))) {
                iVar10 = piVar15[3];
                iVar11 = piVar14[3];
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d6ba;
                iVar3 = func_0x000180497f30(iVar11, iVar10, (int64_t)iVar3);
                if (iVar3 == 0) {
                    iVar10 = *piVar14;
                    iVar11 = *piVar15;
                    if ((iVar10 == 0) == (iVar11 == 0)) {
                        iVar12 = 0x1805aadb1;
                        if (iVar11 != 0) {
                            iVar12 = iVar11;
                        }
                        iVar11 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            iVar11 = iVar10;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d700;
                        iVar3 = func_0x000180498f10(iVar11, iVar12);
                        if (iVar3 == 0) {
                            iVar10 = piVar14[1];
                            iVar11 = piVar15[1];
                            if ((iVar10 == 0) == (iVar11 == 0)) {
                                iVar12 = 0x1805aadb1;
                                if (iVar11 != 0) {
                                    iVar12 = iVar11;
                                }
                                iVar11 = 0x1805aadb1;
                                if (iVar10 != 0) {
                                    iVar11 = iVar10;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d741;
                                iVar3 = func_0x000180498f10(iVar11, iVar12);
                                if (iVar3 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d758;
                                    fcn.180222910(*(undefined8 *)0x18077e4a8);
                                    piVar18 = (int64_t *)(uint64_t)uVar13;
                                    goto code_r0x00018022d880;
                                }
                            }
                        }
                    }
                }
            }
            goto code_r0x00018022d83e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d851;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d869;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d87b;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x00018022d880:
    do {
        uVar1 = *(undefined8 *)((int64_t)&var_10h + (int64_t)piVar16 * 8 + iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d897;
        fcn.180224990(uVar1, 0x1804e1b50, 0x35c);
        piVar16 = (int64_t *)((int64_t)piVar16 + 1);
    } while ((int64_t)piVar16 < 4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d8a8;
    fcn.18027c100(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    return piVar18;
joined_r0x00018022d7e3:
    while (0 < (int32_t)uVar13) {
        piVar15 = (int64_t *)(iVar10 + -8);
        iVar10 = iVar10 + -8;
        uVar13 = (int32_t)piVar14 - 1;
        piVar14 = (int64_t *)(uint64_t)uVar13;
        if (*piVar15 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d80b;
            func_0x000180228b10(*(undefined8 *)0x18077e4a0);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d814;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d82c;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d83e;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x00018022d83e:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d84a;
    fcn.180222910(*(undefined8 *)0x18077e4a8);
    goto code_r0x00018022d880;
}

// ============================================================
// Function: FUN_18022d8b0
// Address: 0x18022d8b0
// Size: 14 bytes
// ============================================================
int64_t * fcn.18022d360(int64_t arg_28h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined4 *puVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t iVar11;
    int32_t in_EDX;
    int64_t iVar12;
    uint32_t uVar13;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined8 unaff_R12;
    int64_t *piVar17;
    int64_t *piVar18;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18022d372;
    iVar4 = fcn.18045a350();
    iVar2 = *(int32_t *)0x1806a0038;
    iVar4 = -iVar4;
    piVar14 = (int64_t *)0x0;
    piVar15 = (int64_t *)0x0;
    *(int64_t **)((int64_t)&var_8h + iVar4) = in_RCX;
    iVar3 = *(int32_t *)(in_RCX + 2);
    piVar17 = (int64_t *)0x0;
    *(undefined (*) [16])((int64_t)&var_10h + iVar4) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_20h + iVar4) = ZEXT816(0);
    if (in_EDX == 0) {
        if (iVar3 < 0x5dd) {
            return (int64_t *)0x0;
        }
        if (in_RCX[3] != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022dcf0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d417;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
            in_RCX = *(int64_t **)((int64_t)&var_8h + iVar4);
        }
        if (*in_RCX != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022df40;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d457;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
            in_RCX = *(int64_t **)((int64_t)&var_8h + iVar4);
        }
        if (in_RCX[1] != 0) {
            *(undefined4 *)(&stack0x00000000 + iVar4) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x18022dc20;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d498;
            iVar10 = fcn.1802963b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                   *(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                                   *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            if (iVar10 != 0) {
                return (int64_t *)0x0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d4ab;
        piVar5 = (int64_t *)func_0x0001802983b0();
        if (piVar5 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
    } else {
        if (iVar3 != 0) {
            return (int64_t *)0x0;
        }
        LOCK();
        UNLOCK();
        if (*(int32_t *)0x1806a0038 < 0x5dd) {
            *(int32_t *)0x1806a0038 = *(int32_t *)0x1806a0038 + 1;
            return (int64_t *)0x0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d3c5;
        *(int32_t *)0x1806a0038 = *(int32_t *)0x1806a0038 + 1;
        piVar5 = (int64_t *)func_0x0001802983b0(*(undefined8 *)((int64_t)&var_8h + iVar4));
        if (piVar5 == (int64_t *)0x0) {
            return (int64_t *)0x0;
        }
        *(int32_t *)(piVar5 + 2) = iVar2;
    }
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d4e6;
    puVar6 = (undefined4 *)
             fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined4 **)((int64_t)&arg_28h + iVar4) = puVar6;
    piVar16 = piVar14;
    piVar18 = piVar14;
    if (puVar6 == (undefined4 *)0x0) goto code_r0x00018022d880;
    piVar18 = piVar17;
    if ((*(int32_t *)((int64_t)piVar5 + 0x14) == 0) ||
       (*(int64_t *)(*(int64_t *)((int64_t)&var_8h + iVar4) + 0x18) == 0)) {
        puVar7 = *(undefined4 **)((int64_t)&var_10h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d51f;
        puVar7 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_10h + iVar4) = puVar7;
        if (puVar7 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    if (*piVar5 == 0) {
        puVar8 = *(undefined4 **)((int64_t)&var_18h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d553;
        puVar8 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_18h + iVar4) = puVar8;
        if (puVar8 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    piVar16 = piVar15;
    if (piVar5[1] == 0) {
        puVar9 = *(undefined4 **)((int64_t)&var_20h + iVar4);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d588;
        puVar9 = (undefined4 *)
                 fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined4 **)((int64_t)&var_20h + iVar4) = puVar9;
        if (puVar9 == (undefined4 *)0x0) goto code_r0x00018022d880;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5ac;
    fcn.180243560(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5bf;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e4b4;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d5de;
        iVar3 = fcn.180222950(*(undefined8 *)0x18077e4a8);
        if (iVar3 != 0) {
            piVar15 = piVar14;
            if (puVar7 != (undefined4 *)0x0) {
                *puVar7 = 0;
                *(int64_t **)(puVar7 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d601;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                piVar15 = (int64_t *)0x0;
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar8 != (undefined4 *)0x0) {
                *puVar8 = 1;
                *(int64_t **)(puVar8 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d629;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar9 != (undefined4 *)0x0) {
                *puVar9 = 2;
                *(int64_t **)(puVar9 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d650;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            if (puVar6 != (undefined4 *)0x0) {
                *puVar6 = 3;
                *(int64_t **)(puVar6 + 2) = piVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d67a;
                iVar10 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar4));
                if (iVar10 != 0) {
                    piVar15 = *(int64_t **)(iVar10 + 8);
                }
            }
            piVar17 = piVar14;
            if (piVar15 == (int64_t *)0x0) {
                do {
                    iVar10 = (int64_t)&var_10h + (int64_t)piVar17 * 8 + iVar4;
                    uVar13 = (uint32_t)piVar14;
                    if (*(int64_t *)((int64_t)&var_10h + (int64_t)piVar17 * 8 + iVar4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d78e;
                        func_0x000180228fb0(*(undefined8 *)0x18077e4a0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d79a;
                        iVar3 = func_0x000180228e00(*(undefined8 *)0x18077e4a0);
                        if (iVar3 != 0) goto joined_r0x00018022d7e3;
                    }
                    piVar14 = (int64_t *)(uint64_t)(uVar13 + 1);
                    piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                    if (3 < (int32_t)(uVar13 + 1)) {
                        *(uint32_t *)(piVar5 + 4) = *(uint32_t *)(piVar5 + 4) & 0xfffffff2;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d7b9;
                        fcn.180222910(*(undefined8 *)0x18077e4a8);
                        return (int64_t *)(uint64_t)*(uint32_t *)(piVar5 + 2);
                    }
                } while( true );
            }
            piVar14 = *(int64_t **)((int64_t)&var_8h + iVar4);
            uVar13 = *(uint32_t *)(piVar15 + 2);
            if ((*(uint32_t *)(piVar14 + 2) == uVar13) &&
               (iVar3 = *(int32_t *)((int64_t)piVar14 + 0x14), iVar3 == *(int32_t *)((int64_t)piVar15 + 0x14))) {
                iVar10 = piVar15[3];
                iVar11 = piVar14[3];
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d6ba;
                iVar3 = func_0x000180497f30(iVar11, iVar10, (int64_t)iVar3);
                if (iVar3 == 0) {
                    iVar10 = *piVar14;
                    iVar11 = *piVar15;
                    if ((iVar10 == 0) == (iVar11 == 0)) {
                        iVar12 = 0x1805aadb1;
                        if (iVar11 != 0) {
                            iVar12 = iVar11;
                        }
                        iVar11 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            iVar11 = iVar10;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d700;
                        iVar3 = func_0x000180498f10(iVar11, iVar12);
                        if (iVar3 == 0) {
                            iVar10 = piVar14[1];
                            iVar11 = piVar15[1];
                            if ((iVar10 == 0) == (iVar11 == 0)) {
                                iVar12 = 0x1805aadb1;
                                if (iVar11 != 0) {
                                    iVar12 = iVar11;
                                }
                                iVar11 = 0x1805aadb1;
                                if (iVar10 != 0) {
                                    iVar11 = iVar10;
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d741;
                                iVar3 = func_0x000180498f10(iVar11, iVar12);
                                if (iVar3 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d758;
                                    fcn.180222910(*(undefined8 *)0x18077e4a8);
                                    piVar18 = (int64_t *)(uint64_t)uVar13;
                                    goto code_r0x00018022d880;
                                }
                            }
                        }
                    }
                }
            }
            goto code_r0x00018022d83e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d851;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d869;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d87b;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x00018022d880:
    do {
        uVar1 = *(undefined8 *)((int64_t)&var_10h + (int64_t)piVar16 * 8 + iVar4);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d897;
        fcn.180224990(uVar1, 0x1804e1b50, 0x35c);
        piVar16 = (int64_t *)((int64_t)piVar16 + 1);
    } while ((int64_t)piVar16 < 4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d8a8;
    fcn.18027c100(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    return piVar18;
joined_r0x00018022d7e3:
    while (0 < (int32_t)uVar13) {
        piVar15 = (int64_t *)(iVar10 + -8);
        iVar10 = iVar10 + -8;
        uVar13 = (int32_t)piVar14 - 1;
        piVar14 = (int64_t *)(uint64_t)uVar13;
        if (*piVar15 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d80b;
            func_0x000180228b10(*(undefined8 *)0x18077e4a0);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d814;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d82c;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d83e;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
code_r0x00018022d83e:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18022d84a;
    fcn.180222910(*(undefined8 *)0x18077e4a8);
    goto code_r0x00018022d880;
}

// ============================================================
// Function: FUN_18022d8c0
// Address: 0x18022d8c0
// Size: 171 bytes
// ============================================================
uint64_t fcn.18022d8c0(int32_t *param_1, int32_t *param_2)
{
    uint8_t uVar1;
    int32_t iVar2;
    uint64_t **ppuVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    bool bVar11;
    
    fcn.18045a350();
    iVar2 = *param_1;
    uVar10 = (uint64_t)(uint32_t)(iVar2 - *param_2);
    if (iVar2 - *param_2 == 0) {
        ppuVar3 = *(uint64_t ***)(param_1 + 2);
        piVar4 = *(int64_t **)(param_2 + 2);
        if (iVar2 != 0) {
            if (iVar2 == 1) {
                puVar7 = *ppuVar3;
                if (puVar7 == (uint64_t *)0x0) {
                    return 0xffffffff;
                }
                iVar8 = *piVar4;
            } else {
                if (iVar2 != 2) {
                    if (iVar2 == 3) {
                        return (uint64_t)(uint32_t)(*(int32_t *)(ppuVar3 + 2) - *(int32_t *)(piVar4 + 2));
                    }
                    return uVar10;
                }
                puVar7 = ppuVar3[1];
                if (puVar7 == (uint64_t *)0x0) {
                    return 0xffffffff;
                }
                iVar8 = piVar4[1];
            }
            if (iVar8 == 0) {
                return 1;
            }
            iVar8 = iVar8 - (int64_t)puVar7;
            while( true ) {
                if (((uint64_t)puVar7 & 7) == 0) {
                    while ((((int32_t)iVar8 + (int32_t)puVar7 & 0xfffU) < 0xff9 &&
                           (uVar10 = *puVar7, uVar10 == *(uint64_t *)(iVar8 + (int64_t)puVar7)))) {
                        puVar7 = puVar7 + 1;
                        if ((~uVar10 & uVar10 + 0xfefefefefefefeff & 0x8080808080808080) != 0) {
                            return 0;
                        }
                    }
                }
                uVar1 = *(uint8_t *)puVar7;
                if (uVar1 != *(uint8_t *)(iVar8 + (int64_t)puVar7)) break;
                puVar7 = (uint64_t *)((int64_t)puVar7 + 1);
                if (uVar1 == 0) {
                    return 0;
                }
            }
            return -(uint64_t)(uVar1 < *(uint8_t *)(iVar8 + (int64_t)puVar7)) | 1;
        }
        uVar9 = (uint64_t)*(int32_t *)((int64_t)ppuVar3 + 0x14);
        uVar5 = *(int32_t *)((int64_t)ppuVar3 + 0x14) - *(int32_t *)((int64_t)piVar4 + 0x14);
        uVar10 = (uint64_t)uVar5;
        if (uVar5 == 0) {
            puVar7 = ppuVar3[3];
            iVar8 = piVar4[3] - (int64_t)puVar7;
            if (7 < uVar9) {
                for (; ((uint64_t)puVar7 & 7) != 0; puVar7 = (uint64_t *)((int64_t)puVar7 + 1)) {
                    bVar11 = *(uint8_t *)puVar7 < *(uint8_t *)((int64_t)puVar7 + iVar8);
                    if (*(uint8_t *)puVar7 != *(uint8_t *)((int64_t)puVar7 + iVar8)) goto code_r0x000180497f73;
                    uVar9 = uVar9 - 1;
                }
                if (uVar9 >> 3 != 0) {
                    uVar10 = uVar9 >> 5;
                    if (uVar10 != 0) {
                        do {
                            uVar6 = *puVar7;
                            if (uVar6 != *(uint64_t *)((int64_t)puVar7 + iVar8)) goto code_r0x000180497fe4;
                            uVar6 = puVar7[1];
                            if (uVar6 != *(uint64_t *)((int64_t)puVar7 + iVar8 + 8)) {
code_r0x000180497fe0:
                                puVar7 = puVar7 + 1;
                                goto code_r0x000180497fe4;
                            }
                            uVar6 = puVar7[2];
                            if (uVar6 != *(uint64_t *)((int64_t)puVar7 + iVar8 + 0x10)) {
code_r0x000180497fdc:
                                puVar7 = puVar7 + 1;
                                goto code_r0x000180497fe0;
                            }
                            uVar6 = puVar7[3];
                            if (uVar6 != *(uint64_t *)((int64_t)puVar7 + iVar8 + 0x18)) {
                                puVar7 = puVar7 + 1;
                                goto code_r0x000180497fdc;
                            }
                            puVar7 = puVar7 + 4;
                            uVar10 = uVar10 - 1;
                        } while (uVar10 != 0);
                        uVar9 = uVar9 & 0x1f;
                    }
                    uVar10 = uVar9 >> 3;
                    if (uVar10 != 0) {
                        do {
                            uVar6 = *puVar7;
                            if (uVar6 != *(uint64_t *)((int64_t)puVar7 + iVar8)) {
code_r0x000180497fe4:
                                uVar10 = *(uint64_t *)(iVar8 + (int64_t)puVar7);
                                uVar5 = (uint32_t)
                                        ((uVar6 >> 0x38 | (uVar6 & 0xff000000000000) >> 0x28 |
                                          (uVar6 & 0xff0000000000) >> 0x18 | (uVar6 & 0xff00000000) >> 8 |
                                          (uVar6 & 0xff000000) << 8 | (uVar6 & 0xff0000) << 0x18 |
                                          (uVar6 & 0xff00) << 0x28 | uVar6 << 0x38) <
                                        (uVar10 >> 0x38 | (uVar10 & 0xff000000000000) >> 0x28 |
                                         (uVar10 & 0xff0000000000) >> 0x18 | (uVar10 & 0xff00000000) >> 8 |
                                         (uVar10 & 0xff000000) << 8 | (uVar10 & 0xff0000) << 0x18 |
                                         (uVar10 & 0xff00) << 0x28 | uVar10 << 0x38));
                                return (uint64_t)((1 - uVar5) - (uint32_t)(uVar5 != 0));
                            }
                            puVar7 = puVar7 + 1;
                            uVar10 = uVar10 - 1;
                        } while (uVar10 != 0);
                        uVar9 = uVar9 & 7;
                    }
                }
            }
            while( true ) {
                if (uVar9 == 0) {
                    return 0;
                }
                bVar11 = *(uint8_t *)puVar7 < *(uint8_t *)((int64_t)puVar7 + iVar8);
                if (*(uint8_t *)puVar7 != *(uint8_t *)((int64_t)puVar7 + iVar8)) break;
                puVar7 = (uint64_t *)((int64_t)puVar7 + 1);
                uVar9 = uVar9 - 1;
            }
code_r0x000180497f73:
            return (uint64_t)((1 - (uint32_t)bVar11) - (uint32_t)(bVar11 != 0));
        }
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18022d970
// Address: 0x18022d970
// Size: 140 bytes
// ============================================================
uint32_t fcn.18022d970(int64_t arg_28h, int64_t arg_38h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int32_t iVar8;
    uint8_t *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    int32_t iVar12;
    int32_t iVar13;
    undefined auVar14 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar20 [16];
    undefined auVar21 [16];
    int32_t iVar28;
    undefined auVar22 [16];
    undefined auVar23 [16];
    undefined auVar24 [16];
    undefined auVar25 [16];
    undefined auVar26 [16];
    undefined auVar27 [16];
    uint32_t uVar29;
    uint32_t uVar30;
    uint32_t uVar31;
    uint32_t uVar32;
    uint32_t uVar33;
    uint32_t uVar34;
    uint32_t uVar35;
    uint32_t uVar36;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    int64_t var_18h;
    undefined4 auStackX_20 [2];
    undefined8 uStack_10;
    undefined auVar15 [16];
    undefined auVar19 [16];
    
    uStack_10 = 0x18022d97c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar8 = *in_RCX;
    puVar2 = *(undefined8 **)(in_RCX + 2);
    if (iVar8 == 0) {
        uVar1 = *(uint32_t *)((int64_t)puVar2 + 0x14);
        iVar8 = 0;
        puVar4 = (undefined4 *)puVar2[3];
        uVar5 = uVar1 << 0x14;
        if (0 < (int32_t)uVar1) {
            if ((7 < uVar1) && (4 < *(int32_t *)0x1806a3990)) {
                *(undefined4 *)((int64_t)&arg_38h + iVar7) = unaff_XMM6_Da;
                *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = unaff_XMM6_Db;
                *(undefined4 *)(&stack0x00000040 + iVar7) = unaff_XMM6_Dc;
                *(undefined4 *)(&stack0x00000044 + iVar7) = unaff_XMM6_Dd;
                *(undefined4 *)((int64_t)&arg_28h + iVar7) = unaff_XMM7_Da;
                *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = unaff_XMM7_Db;
                *(undefined4 *)(&stack0x00000030 + iVar7) = unaff_XMM7_Dc;
                *(undefined4 *)(&stack0x00000034 + iVar7) = unaff_XMM7_Dd;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + -8) = unaff_XMM8_Da;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + -4) = unaff_XMM8_Db;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7) = unaff_XMM8_Dc;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + 4) = unaff_XMM8_Dd;
                uVar6 = uVar1 & 0x80000007;
                if ((int32_t)uVar6 < 0) {
                    uVar6 = (uVar6 - 1 | 0xfffffff8) + 1;
                }
                uVar33 = 0;
                uVar34 = 0;
                uVar35 = 0;
                uVar36 = 0;
                uVar29 = 0;
                uVar30 = 0;
                uVar31 = 0;
                uVar32 = 0;
                puVar10 = puVar4;
                iVar13 = iVar8;
                do {
                    auVar22._4_4_ = iVar13 + 1;
                    auVar22._0_4_ = iVar13;
                    auVar22._8_4_ = iVar13 + 2;
                    auVar22._12_4_ = iVar13 + 3;
                    iVar8 = iVar13 + 8;
                    auVar23 = pmulld(auVar22, *(undefined (*) [16])0x180646a10);
                    iVar12 = auVar23._8_4_;
                    auVar26._4_4_ = iVar12;
                    auVar26._0_4_ = iVar12;
                    auVar26._12_4_ = auVar23._12_4_;
                    auVar26._8_4_ = auVar26._12_4_;
                    iVar28 = auVar23._4_4_;
                    auVar15._0_8_ = auVar23._0_8_;
                    auVar15._8_4_ = iVar28;
                    auVar15._12_4_ = iVar28;
                    auVar14._8_8_ = auVar15._8_8_;
                    auVar14._0_4_ = auVar23._0_4_;
                    auVar14._4_4_ = auVar14._0_4_;
                    auVar23 = pmuldq(auVar26, *(undefined (*) [16])0x1804e1c00);
                    auVar16 = pmuldq(auVar14, *(undefined (*) [16])0x1804e1c00);
                    auVar17._0_4_ = auVar16._4_4_ >> 2;
                    auVar17._4_4_ = auVar16._12_4_ >> 2;
                    auVar17._8_4_ = auVar23._4_4_ >> 2;
                    auVar17._12_4_ = auVar23._12_4_ >> 2;
                    auVar20._0_4_ = auVar17._0_4_ - (auVar16._4_4_ >> 0x1f);
                    auVar20._4_4_ = auVar17._4_4_ - (auVar16._12_4_ >> 0x1f);
                    auVar20._8_4_ = auVar17._8_4_ - (auVar23._4_4_ >> 0x1f);
                    auVar20._12_4_ = auVar17._12_4_ - (auVar23._12_4_ >> 0x1f);
                    auVar16 = pmovzxbd(auVar17, *puVar10);
                    auVar23 = pmulld(auVar20, *(undefined (*) [16])0x1804e1bf0);
                    auVar24._0_4_ = auVar14._0_4_ - auVar23._0_4_;
                    auVar24._4_4_ = iVar28 - auVar23._4_4_;
                    auVar24._8_4_ = iVar12 - auVar23._8_4_;
                    auVar24._12_4_ = auVar26._12_4_ - auVar23._12_4_;
                    auVar26 = vpsllvd_avx2(auVar16, auVar24);
                    uVar33 = uVar33 ^ auVar26._0_4_;
                    uVar34 = uVar34 ^ auVar26._4_4_;
                    uVar35 = uVar35 ^ auVar26._8_4_;
                    uVar36 = uVar36 ^ auVar26._12_4_;
                    auVar25._4_4_ = iVar13 + 5;
                    auVar25._0_4_ = iVar13 + 4;
                    auVar25._8_4_ = iVar13 + 6;
                    auVar25._12_4_ = iVar13 + 7;
                    auVar26 = pmulld(auVar25, *(undefined (*) [16])0x180646a10);
                    iVar13 = auVar26._8_4_;
                    auVar23._4_4_ = iVar13;
                    auVar23._0_4_ = iVar13;
                    auVar23._12_4_ = auVar26._12_4_;
                    auVar23._8_4_ = auVar23._12_4_;
                    iVar12 = auVar26._4_4_;
                    auVar19._0_8_ = auVar26._0_8_;
                    auVar19._8_4_ = iVar12;
                    auVar19._12_4_ = iVar12;
                    auVar18._8_8_ = auVar19._8_8_;
                    auVar18._0_4_ = auVar26._0_4_;
                    auVar18._4_4_ = auVar18._0_4_;
                    auVar26 = pmuldq(auVar23, *(undefined (*) [16])0x1804e1c00);
                    auVar20 = pmuldq(auVar18, *(undefined (*) [16])0x1804e1c00);
                    auVar21._0_4_ = auVar20._4_4_ >> 2;
                    auVar21._4_4_ = auVar20._12_4_ >> 2;
                    auVar21._8_4_ = auVar26._4_4_ >> 2;
                    auVar21._12_4_ = auVar26._12_4_ >> 2;
                    auVar16._0_4_ = auVar21._0_4_ - (auVar20._4_4_ >> 0x1f);
                    auVar16._4_4_ = auVar21._4_4_ - (auVar20._12_4_ >> 0x1f);
                    auVar16._8_4_ = auVar21._8_4_ - (auVar26._4_4_ >> 0x1f);
                    auVar16._12_4_ = auVar21._12_4_ - (auVar26._12_4_ >> 0x1f);
                    auVar20 = pmovzxbd(auVar21, puVar10[1]);
                    auVar26 = pmulld(auVar16, *(undefined (*) [16])0x1804e1bf0);
                    auVar27._0_4_ = auVar18._0_4_ - auVar26._0_4_;
                    auVar27._4_4_ = iVar12 - auVar26._4_4_;
                    auVar27._8_4_ = iVar13 - auVar26._8_4_;
                    auVar27._12_4_ = auVar23._12_4_ - auVar26._12_4_;
                    auVar26 = vpsllvd_avx2(auVar20, auVar27);
                    uVar29 = uVar29 ^ auVar26._0_4_;
                    uVar30 = uVar30 ^ auVar26._4_4_;
                    uVar31 = uVar31 ^ auVar26._8_4_;
                    uVar32 = uVar32 ^ auVar26._12_4_;
                    puVar10 = puVar10 + 2;
                    iVar13 = iVar8;
                } while (iVar8 < (int32_t)(uVar1 - uVar6));
                uVar5 = uVar5 ^ uVar29 ^ uVar33 ^ uVar31 ^ uVar35 ^ uVar30 ^ uVar34 ^ uVar32 ^ uVar36;
                if ((int32_t)uVar1 <= iVar8) goto code_r0x00018022db95;
            }
            uVar11 = (uint64_t)(uVar1 - iVar8);
            puVar9 = (uint8_t *)((int64_t)puVar4 + (int64_t)iVar8);
            iVar8 = iVar8 * 3;
            do {
                uVar5 = uVar5 ^ (uint32_t)*puVar9 << ((char)iVar8 + (char)(iVar8 / 0x18) * -0x18 & 0x1fU);
                uVar11 = uVar11 - 1;
                puVar9 = puVar9 + 1;
                iVar8 = iVar8 + 3;
            } while (uVar11 != 0);
        }
    } else if (iVar8 == 1) {
        uVar3 = *puVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022d9c5;
        uVar5 = fcn.1802292c0(uVar3);
    } else if (iVar8 == 2) {
        uVar3 = puVar2[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022d9b5;
        uVar5 = fcn.1802292c0(uVar3);
    } else {
        if (iVar8 != 3) {
            return 0;
        }
        uVar5 = *(uint32_t *)(puVar2 + 2);
    }
code_r0x00018022db95:
    return *in_RCX << 0x1e | uVar5 & 0x3fffffff;
}

// ============================================================
// Function: FUN_18022d9fc
// Address: 0x18022d9fc
// Size: 339 bytes
// ============================================================
uint32_t fcn.18022d970(int64_t arg_28h, int64_t arg_38h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int32_t iVar8;
    uint8_t *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    int32_t iVar12;
    int32_t iVar13;
    undefined auVar14 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar20 [16];
    undefined auVar21 [16];
    int32_t iVar28;
    undefined auVar22 [16];
    undefined auVar23 [16];
    undefined auVar24 [16];
    undefined auVar25 [16];
    undefined auVar26 [16];
    undefined auVar27 [16];
    uint32_t uVar29;
    uint32_t uVar30;
    uint32_t uVar31;
    uint32_t uVar32;
    uint32_t uVar33;
    uint32_t uVar34;
    uint32_t uVar35;
    uint32_t uVar36;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    int64_t var_18h;
    undefined4 auStackX_20 [2];
    undefined8 uStack_10;
    undefined auVar15 [16];
    undefined auVar19 [16];
    
    uStack_10 = 0x18022d97c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar8 = *in_RCX;
    puVar2 = *(undefined8 **)(in_RCX + 2);
    if (iVar8 == 0) {
        uVar1 = *(uint32_t *)((int64_t)puVar2 + 0x14);
        iVar8 = 0;
        puVar4 = (undefined4 *)puVar2[3];
        uVar5 = uVar1 << 0x14;
        if (0 < (int32_t)uVar1) {
            if ((7 < uVar1) && (4 < *(int32_t *)0x1806a3990)) {
                *(undefined4 *)((int64_t)&arg_38h + iVar7) = unaff_XMM6_Da;
                *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = unaff_XMM6_Db;
                *(undefined4 *)(&stack0x00000040 + iVar7) = unaff_XMM6_Dc;
                *(undefined4 *)(&stack0x00000044 + iVar7) = unaff_XMM6_Dd;
                *(undefined4 *)((int64_t)&arg_28h + iVar7) = unaff_XMM7_Da;
                *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = unaff_XMM7_Db;
                *(undefined4 *)(&stack0x00000030 + iVar7) = unaff_XMM7_Dc;
                *(undefined4 *)(&stack0x00000034 + iVar7) = unaff_XMM7_Dd;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + -8) = unaff_XMM8_Da;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + -4) = unaff_XMM8_Db;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7) = unaff_XMM8_Dc;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + 4) = unaff_XMM8_Dd;
                uVar6 = uVar1 & 0x80000007;
                if ((int32_t)uVar6 < 0) {
                    uVar6 = (uVar6 - 1 | 0xfffffff8) + 1;
                }
                uVar33 = 0;
                uVar34 = 0;
                uVar35 = 0;
                uVar36 = 0;
                uVar29 = 0;
                uVar30 = 0;
                uVar31 = 0;
                uVar32 = 0;
                puVar10 = puVar4;
                iVar13 = iVar8;
                do {
                    auVar22._4_4_ = iVar13 + 1;
                    auVar22._0_4_ = iVar13;
                    auVar22._8_4_ = iVar13 + 2;
                    auVar22._12_4_ = iVar13 + 3;
                    iVar8 = iVar13 + 8;
                    auVar23 = pmulld(auVar22, *(undefined (*) [16])0x180646a10);
                    iVar12 = auVar23._8_4_;
                    auVar26._4_4_ = iVar12;
                    auVar26._0_4_ = iVar12;
                    auVar26._12_4_ = auVar23._12_4_;
                    auVar26._8_4_ = auVar26._12_4_;
                    iVar28 = auVar23._4_4_;
                    auVar15._0_8_ = auVar23._0_8_;
                    auVar15._8_4_ = iVar28;
                    auVar15._12_4_ = iVar28;
                    auVar14._8_8_ = auVar15._8_8_;
                    auVar14._0_4_ = auVar23._0_4_;
                    auVar14._4_4_ = auVar14._0_4_;
                    auVar23 = pmuldq(auVar26, *(undefined (*) [16])0x1804e1c00);
                    auVar16 = pmuldq(auVar14, *(undefined (*) [16])0x1804e1c00);
                    auVar17._0_4_ = auVar16._4_4_ >> 2;
                    auVar17._4_4_ = auVar16._12_4_ >> 2;
                    auVar17._8_4_ = auVar23._4_4_ >> 2;
                    auVar17._12_4_ = auVar23._12_4_ >> 2;
                    auVar20._0_4_ = auVar17._0_4_ - (auVar16._4_4_ >> 0x1f);
                    auVar20._4_4_ = auVar17._4_4_ - (auVar16._12_4_ >> 0x1f);
                    auVar20._8_4_ = auVar17._8_4_ - (auVar23._4_4_ >> 0x1f);
                    auVar20._12_4_ = auVar17._12_4_ - (auVar23._12_4_ >> 0x1f);
                    auVar16 = pmovzxbd(auVar17, *puVar10);
                    auVar23 = pmulld(auVar20, *(undefined (*) [16])0x1804e1bf0);
                    auVar24._0_4_ = auVar14._0_4_ - auVar23._0_4_;
                    auVar24._4_4_ = iVar28 - auVar23._4_4_;
                    auVar24._8_4_ = iVar12 - auVar23._8_4_;
                    auVar24._12_4_ = auVar26._12_4_ - auVar23._12_4_;
                    auVar26 = vpsllvd_avx2(auVar16, auVar24);
                    uVar33 = uVar33 ^ auVar26._0_4_;
                    uVar34 = uVar34 ^ auVar26._4_4_;
                    uVar35 = uVar35 ^ auVar26._8_4_;
                    uVar36 = uVar36 ^ auVar26._12_4_;
                    auVar25._4_4_ = iVar13 + 5;
                    auVar25._0_4_ = iVar13 + 4;
                    auVar25._8_4_ = iVar13 + 6;
                    auVar25._12_4_ = iVar13 + 7;
                    auVar26 = pmulld(auVar25, *(undefined (*) [16])0x180646a10);
                    iVar13 = auVar26._8_4_;
                    auVar23._4_4_ = iVar13;
                    auVar23._0_4_ = iVar13;
                    auVar23._12_4_ = auVar26._12_4_;
                    auVar23._8_4_ = auVar23._12_4_;
                    iVar12 = auVar26._4_4_;
                    auVar19._0_8_ = auVar26._0_8_;
                    auVar19._8_4_ = iVar12;
                    auVar19._12_4_ = iVar12;
                    auVar18._8_8_ = auVar19._8_8_;
                    auVar18._0_4_ = auVar26._0_4_;
                    auVar18._4_4_ = auVar18._0_4_;
                    auVar26 = pmuldq(auVar23, *(undefined (*) [16])0x1804e1c00);
                    auVar20 = pmuldq(auVar18, *(undefined (*) [16])0x1804e1c00);
                    auVar21._0_4_ = auVar20._4_4_ >> 2;
                    auVar21._4_4_ = auVar20._12_4_ >> 2;
                    auVar21._8_4_ = auVar26._4_4_ >> 2;
                    auVar21._12_4_ = auVar26._12_4_ >> 2;
                    auVar16._0_4_ = auVar21._0_4_ - (auVar20._4_4_ >> 0x1f);
                    auVar16._4_4_ = auVar21._4_4_ - (auVar20._12_4_ >> 0x1f);
                    auVar16._8_4_ = auVar21._8_4_ - (auVar26._4_4_ >> 0x1f);
                    auVar16._12_4_ = auVar21._12_4_ - (auVar26._12_4_ >> 0x1f);
                    auVar20 = pmovzxbd(auVar21, puVar10[1]);
                    auVar26 = pmulld(auVar16, *(undefined (*) [16])0x1804e1bf0);
                    auVar27._0_4_ = auVar18._0_4_ - auVar26._0_4_;
                    auVar27._4_4_ = iVar12 - auVar26._4_4_;
                    auVar27._8_4_ = iVar13 - auVar26._8_4_;
                    auVar27._12_4_ = auVar23._12_4_ - auVar26._12_4_;
                    auVar26 = vpsllvd_avx2(auVar20, auVar27);
                    uVar29 = uVar29 ^ auVar26._0_4_;
                    uVar30 = uVar30 ^ auVar26._4_4_;
                    uVar31 = uVar31 ^ auVar26._8_4_;
                    uVar32 = uVar32 ^ auVar26._12_4_;
                    puVar10 = puVar10 + 2;
                    iVar13 = iVar8;
                } while (iVar8 < (int32_t)(uVar1 - uVar6));
                uVar5 = uVar5 ^ uVar29 ^ uVar33 ^ uVar31 ^ uVar35 ^ uVar30 ^ uVar34 ^ uVar32 ^ uVar36;
                if ((int32_t)uVar1 <= iVar8) goto code_r0x00018022db95;
            }
            uVar11 = (uint64_t)(uVar1 - iVar8);
            puVar9 = (uint8_t *)((int64_t)puVar4 + (int64_t)iVar8);
            iVar8 = iVar8 * 3;
            do {
                uVar5 = uVar5 ^ (uint32_t)*puVar9 << ((char)iVar8 + (char)(iVar8 / 0x18) * -0x18 & 0x1fU);
                uVar11 = uVar11 - 1;
                puVar9 = puVar9 + 1;
                iVar8 = iVar8 + 3;
            } while (uVar11 != 0);
        }
    } else if (iVar8 == 1) {
        uVar3 = *puVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022d9c5;
        uVar5 = fcn.1802292c0(uVar3);
    } else if (iVar8 == 2) {
        uVar3 = puVar2[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022d9b5;
        uVar5 = fcn.1802292c0(uVar3);
    } else {
        if (iVar8 != 3) {
            return 0;
        }
        uVar5 = *(uint32_t *)(puVar2 + 2);
    }
code_r0x00018022db95:
    return *in_RCX << 0x1e | uVar5 & 0x3fffffff;
}

// ============================================================
// Function: FUN_18022db4f
// Address: 0x18022db4f
// Size: 91 bytes
// ============================================================
uint32_t fcn.18022d970(int64_t arg_28h, int64_t arg_38h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int32_t iVar8;
    uint8_t *puVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    int32_t iVar12;
    int32_t iVar13;
    undefined auVar14 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar20 [16];
    undefined auVar21 [16];
    int32_t iVar28;
    undefined auVar22 [16];
    undefined auVar23 [16];
    undefined auVar24 [16];
    undefined auVar25 [16];
    undefined auVar26 [16];
    undefined auVar27 [16];
    uint32_t uVar29;
    uint32_t uVar30;
    uint32_t uVar31;
    uint32_t uVar32;
    uint32_t uVar33;
    uint32_t uVar34;
    uint32_t uVar35;
    uint32_t uVar36;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    int64_t var_18h;
    undefined4 auStackX_20 [2];
    undefined8 uStack_10;
    undefined auVar15 [16];
    undefined auVar19 [16];
    
    uStack_10 = 0x18022d97c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar8 = *in_RCX;
    puVar2 = *(undefined8 **)(in_RCX + 2);
    if (iVar8 == 0) {
        uVar1 = *(uint32_t *)((int64_t)puVar2 + 0x14);
        iVar8 = 0;
        puVar4 = (undefined4 *)puVar2[3];
        uVar5 = uVar1 << 0x14;
        if (0 < (int32_t)uVar1) {
            if ((7 < uVar1) && (4 < *(int32_t *)0x1806a3990)) {
                *(undefined4 *)((int64_t)&arg_38h + iVar7) = unaff_XMM6_Da;
                *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = unaff_XMM6_Db;
                *(undefined4 *)(&stack0x00000040 + iVar7) = unaff_XMM6_Dc;
                *(undefined4 *)(&stack0x00000044 + iVar7) = unaff_XMM6_Dd;
                *(undefined4 *)((int64_t)&arg_28h + iVar7) = unaff_XMM7_Da;
                *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = unaff_XMM7_Db;
                *(undefined4 *)(&stack0x00000030 + iVar7) = unaff_XMM7_Dc;
                *(undefined4 *)(&stack0x00000034 + iVar7) = unaff_XMM7_Dd;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + -8) = unaff_XMM8_Da;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + -4) = unaff_XMM8_Db;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7) = unaff_XMM8_Dc;
                *(undefined4 *)((int64_t)auStackX_20 + iVar7 + 4) = unaff_XMM8_Dd;
                uVar6 = uVar1 & 0x80000007;
                if ((int32_t)uVar6 < 0) {
                    uVar6 = (uVar6 - 1 | 0xfffffff8) + 1;
                }
                uVar33 = 0;
                uVar34 = 0;
                uVar35 = 0;
                uVar36 = 0;
                uVar29 = 0;
                uVar30 = 0;
                uVar31 = 0;
                uVar32 = 0;
                puVar10 = puVar4;
                iVar13 = iVar8;
                do {
                    auVar22._4_4_ = iVar13 + 1;
                    auVar22._0_4_ = iVar13;
                    auVar22._8_4_ = iVar13 + 2;
                    auVar22._12_4_ = iVar13 + 3;
                    iVar8 = iVar13 + 8;
                    auVar23 = pmulld(auVar22, *(undefined (*) [16])0x180646a10);
                    iVar12 = auVar23._8_4_;
                    auVar26._4_4_ = iVar12;
                    auVar26._0_4_ = iVar12;
                    auVar26._12_4_ = auVar23._12_4_;
                    auVar26._8_4_ = auVar26._12_4_;
                    iVar28 = auVar23._4_4_;
                    auVar15._0_8_ = auVar23._0_8_;
                    auVar15._8_4_ = iVar28;
                    auVar15._12_4_ = iVar28;
                    auVar14._8_8_ = auVar15._8_8_;
                    auVar14._0_4_ = auVar23._0_4_;
                    auVar14._4_4_ = auVar14._0_4_;
                    auVar23 = pmuldq(auVar26, *(undefined (*) [16])0x1804e1c00);
                    auVar16 = pmuldq(auVar14, *(undefined (*) [16])0x1804e1c00);
                    auVar17._0_4_ = auVar16._4_4_ >> 2;
                    auVar17._4_4_ = auVar16._12_4_ >> 2;
                    auVar17._8_4_ = auVar23._4_4_ >> 2;
                    auVar17._12_4_ = auVar23._12_4_ >> 2;
                    auVar20._0_4_ = auVar17._0_4_ - (auVar16._4_4_ >> 0x1f);
                    auVar20._4_4_ = auVar17._4_4_ - (auVar16._12_4_ >> 0x1f);
                    auVar20._8_4_ = auVar17._8_4_ - (auVar23._4_4_ >> 0x1f);
                    auVar20._12_4_ = auVar17._12_4_ - (auVar23._12_4_ >> 0x1f);
                    auVar16 = pmovzxbd(auVar17, *puVar10);
                    auVar23 = pmulld(auVar20, *(undefined (*) [16])0x1804e1bf0);
                    auVar24._0_4_ = auVar14._0_4_ - auVar23._0_4_;
                    auVar24._4_4_ = iVar28 - auVar23._4_4_;
                    auVar24._8_4_ = iVar12 - auVar23._8_4_;
                    auVar24._12_4_ = auVar26._12_4_ - auVar23._12_4_;
                    auVar26 = vpsllvd_avx2(auVar16, auVar24);
                    uVar33 = uVar33 ^ auVar26._0_4_;
                    uVar34 = uVar34 ^ auVar26._4_4_;
                    uVar35 = uVar35 ^ auVar26._8_4_;
                    uVar36 = uVar36 ^ auVar26._12_4_;
                    auVar25._4_4_ = iVar13 + 5;
                    auVar25._0_4_ = iVar13 + 4;
                    auVar25._8_4_ = iVar13 + 6;
                    auVar25._12_4_ = iVar13 + 7;
                    auVar26 = pmulld(auVar25, *(undefined (*) [16])0x180646a10);
                    iVar13 = auVar26._8_4_;
                    auVar23._4_4_ = iVar13;
                    auVar23._0_4_ = iVar13;
                    auVar23._12_4_ = auVar26._12_4_;
                    auVar23._8_4_ = auVar23._12_4_;
                    iVar12 = auVar26._4_4_;
                    auVar19._0_8_ = auVar26._0_8_;
                    auVar19._8_4_ = iVar12;
                    auVar19._12_4_ = iVar12;
                    auVar18._8_8_ = auVar19._8_8_;
                    auVar18._0_4_ = auVar26._0_4_;
                    auVar18._4_4_ = auVar18._0_4_;
                    auVar26 = pmuldq(auVar23, *(undefined (*) [16])0x1804e1c00);
                    auVar20 = pmuldq(auVar18, *(undefined (*) [16])0x1804e1c00);
                    auVar21._0_4_ = auVar20._4_4_ >> 2;
                    auVar21._4_4_ = auVar20._12_4_ >> 2;
                    auVar21._8_4_ = auVar26._4_4_ >> 2;
                    auVar21._12_4_ = auVar26._12_4_ >> 2;
                    auVar16._0_4_ = auVar21._0_4_ - (auVar20._4_4_ >> 0x1f);
                    auVar16._4_4_ = auVar21._4_4_ - (auVar20._12_4_ >> 0x1f);
                    auVar16._8_4_ = auVar21._8_4_ - (auVar26._4_4_ >> 0x1f);
                    auVar16._12_4_ = auVar21._12_4_ - (auVar26._12_4_ >> 0x1f);
                    auVar20 = pmovzxbd(auVar21, puVar10[1]);
                    auVar26 = pmulld(auVar16, *(undefined (*) [16])0x1804e1bf0);
                    auVar27._0_4_ = auVar18._0_4_ - auVar26._0_4_;
                    auVar27._4_4_ = iVar12 - auVar26._4_4_;
                    auVar27._8_4_ = iVar13 - auVar26._8_4_;
                    auVar27._12_4_ = auVar23._12_4_ - auVar26._12_4_;
                    auVar26 = vpsllvd_avx2(auVar20, auVar27);
                    uVar29 = uVar29 ^ auVar26._0_4_;
                    uVar30 = uVar30 ^ auVar26._4_4_;
                    uVar31 = uVar31 ^ auVar26._8_4_;
                    uVar32 = uVar32 ^ auVar26._12_4_;
                    puVar10 = puVar10 + 2;
                    iVar13 = iVar8;
                } while (iVar8 < (int32_t)(uVar1 - uVar6));
                uVar5 = uVar5 ^ uVar29 ^ uVar33 ^ uVar31 ^ uVar35 ^ uVar30 ^ uVar34 ^ uVar32 ^ uVar36;
                if ((int32_t)uVar1 <= iVar8) goto code_r0x00018022db95;
            }
            uVar11 = (uint64_t)(uVar1 - iVar8);
            puVar9 = (uint8_t *)((int64_t)puVar4 + (int64_t)iVar8);
            iVar8 = iVar8 * 3;
            do {
                uVar5 = uVar5 ^ (uint32_t)*puVar9 << ((char)iVar8 + (char)(iVar8 / 0x18) * -0x18 & 0x1fU);
                uVar11 = uVar11 - 1;
                puVar9 = puVar9 + 1;
                iVar8 = iVar8 + 3;
            } while (uVar11 != 0);
        }
    } else if (iVar8 == 1) {
        uVar3 = *puVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022d9c5;
        uVar5 = fcn.1802292c0(uVar3);
    } else if (iVar8 == 2) {
        uVar3 = puVar2[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18022d9b5;
        uVar5 = fcn.1802292c0(uVar3);
    } else {
        if (iVar8 != 3) {
            return 0;
        }
        uVar5 = *(uint32_t *)(puVar2 + 2);
    }
code_r0x00018022db95:
    return *in_RCX << 0x1e | uVar5 & 0x3fffffff;
}

// ============================================================
// Function: FUN_18022dbe0
// Address: 0x18022dbe0
// Size: 63 bytes
// ============================================================
void fcn.18022dbe0(int64_t param_1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022dbec;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar1 = (int32_t *)(*(int64_t *)(param_1 + 8) + 0x10);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022dc05;
        fcn.18027c100(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    }
    uVar7 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = 0x18022499a;
    iVar4 = fcn.18045a350(param_1, 0x1804e1b50, 0xe2);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar4 + iVar5) = uVar7;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar5) = 0x18047ca3c;
            iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar5) = 0x18047ca46;
                uVar3 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar5) = 0x18047ca4d;
                uVar3 = fcn.18046b63c(uVar3);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar5) = 0x18047ca54;
                puVar6 = (undefined4 *)fcn.18046b77c();
                *puVar6 = uVar3;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_18022dc20
// Address: 0x18022dc20
// Size: 46 bytes
// ============================================================
uint64_t fcn.18022dc20(int64_t *param_1, uint32_t *param_2)
{
    uint8_t uVar1;
    uint64_t uVar2;
    uint64_t *puVar3;
    int64_t iVar4;
    
    fcn.18045a350();
    puVar3 = *(uint64_t **)(*param_1 + 8);
    iVar4 = *(int64_t *)((uint64_t)*param_2 * 0x28 + 0x1804c3048) - (int64_t)puVar3;
    while( true ) {
        if (((uint64_t)puVar3 & 7) == 0) {
            while ((((int32_t)iVar4 + (int32_t)puVar3 & 0xfffU) < 0xff9 &&
                   (uVar2 = *puVar3, uVar2 == *(uint64_t *)(iVar4 + (int64_t)puVar3)))) {
                puVar3 = puVar3 + 1;
                if ((~uVar2 & uVar2 + 0xfefefefefefefeff & 0x8080808080808080) != 0) {
                    return 0;
                }
            }
        }
        uVar1 = *(uint8_t *)puVar3;
        if (uVar1 != *(uint8_t *)(iVar4 + (int64_t)puVar3)) break;
        puVar3 = (uint64_t *)((int64_t)puVar3 + 1);
        if (uVar1 == 0) {
            return 0;
        }
    }
    return -(uint64_t)(uVar1 < *(uint8_t *)(iVar4 + (int64_t)puVar3)) | 1;
}

// ============================================================
// Function: FUN_18022dc50
// Address: 0x18022dc50
// Size: 160 bytes
// ============================================================
void fcn.18022dc50(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022dc5a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022dc62;
    *(int64_t *)0x18077e4a8 = fcn.180222800();
    if (*(int64_t *)0x18077e4a8 == 0) {
        *(undefined4 *)0x18077e4b4 = 0;
        return;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022dc8c;
    fcn.180229130(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022dcb5;
    *(int64_t *)0x18077e4a0 = fcn.180229290(*(int64_t *)((int64_t)&var_20h + iVar1));
    if (*(int64_t *)0x18077e4a0 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022dccd;
        fcn.1802227d0(*(int64_t *)0x18077e4a8);
        *(undefined8 *)0x18077e4a8 = 0;
        *(undefined4 *)0x18077e4b4 = 0;
        return;
    }
    *(undefined4 *)0x18077e4b4 = 1;
    return;
}

// ============================================================
// Function: FUN_18022dcf0
// Address: 0x18022dcf0
// Size: 85 bytes
// ============================================================
int32_t fcn.18022dcf0(int64_t *param_1, uint32_t *param_2)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    bool bVar9;
    
    fcn.18045a350();
    iVar1 = *(int32_t *)(*param_1 + 0x14);
    uVar5 = (uint64_t)iVar1;
    iVar3 = iVar1 - *(int32_t *)((uint64_t)*param_2 * 0x28 + 0x1804c3054);
    if (iVar3 != 0) {
        return iVar3;
    }
    if (iVar1 == 0) {
        return iVar3;
    }
    puVar6 = *(uint64_t **)(*param_1 + 0x18);
    iVar7 = *(int64_t *)((uint64_t)*param_2 * 0x28 + 0x1804c3058) - (int64_t)puVar6;
    if (7 < uVar5) {
        for (; ((uint64_t)puVar6 & 7) != 0; puVar6 = (uint64_t *)((int64_t)puVar6 + 1)) {
            bVar9 = *(uint8_t *)puVar6 < *(uint8_t *)((int64_t)puVar6 + iVar7);
            if (*(uint8_t *)puVar6 != *(uint8_t *)((int64_t)puVar6 + iVar7)) goto code_r0x000180497f73;
            uVar5 = uVar5 - 1;
        }
        if (uVar5 >> 3 != 0) {
            uVar8 = uVar5 >> 5;
            if (uVar8 != 0) {
                do {
                    uVar4 = *puVar6;
                    if (uVar4 != *(uint64_t *)((int64_t)puVar6 + iVar7)) goto code_r0x000180497fe4;
                    uVar4 = puVar6[1];
                    if (uVar4 != *(uint64_t *)((int64_t)puVar6 + iVar7 + 8)) {
code_r0x000180497fe0:
                        puVar6 = puVar6 + 1;
                        goto code_r0x000180497fe4;
                    }
                    uVar4 = puVar6[2];
                    if (uVar4 != *(uint64_t *)((int64_t)puVar6 + iVar7 + 0x10)) {
code_r0x000180497fdc:
                        puVar6 = puVar6 + 1;
                        goto code_r0x000180497fe0;
                    }
                    uVar4 = puVar6[3];
                    if (uVar4 != *(uint64_t *)((int64_t)puVar6 + iVar7 + 0x18)) {
                        puVar6 = puVar6 + 1;
                        goto code_r0x000180497fdc;
                    }
                    puVar6 = puVar6 + 4;
                    uVar8 = uVar8 - 1;
                } while (uVar8 != 0);
                uVar5 = uVar5 & 0x1f;
            }
            uVar8 = uVar5 >> 3;
            if (uVar8 != 0) {
                do {
                    uVar4 = *puVar6;
                    if (uVar4 != *(uint64_t *)((int64_t)puVar6 + iVar7)) {
code_r0x000180497fe4:
                        uVar5 = *(uint64_t *)(iVar7 + (int64_t)puVar6);
                        uVar2 = (uint32_t)
                                ((uVar4 >> 0x38 | (uVar4 & 0xff000000000000) >> 0x28 | (uVar4 & 0xff0000000000) >> 0x18
                                  | (uVar4 & 0xff00000000) >> 8 | (uVar4 & 0xff000000) << 8 | (uVar4 & 0xff0000) << 0x18
                                  | (uVar4 & 0xff00) << 0x28 | uVar4 << 0x38) <
                                (uVar5 >> 0x38 | (uVar5 & 0xff000000000000) >> 0x28 | (uVar5 & 0xff0000000000) >> 0x18 |
                                 (uVar5 & 0xff00000000) >> 8 | (uVar5 & 0xff000000) << 8 | (uVar5 & 0xff0000) << 0x18 |
                                 (uVar5 & 0xff00) << 0x28 | uVar5 << 0x38));
                        return (1 - uVar2) - (uint32_t)(uVar2 != 0);
                    }
                    puVar6 = puVar6 + 1;
                    uVar8 = uVar8 - 1;
                } while (uVar8 != 0);
                uVar5 = uVar5 & 7;
            }
        }
    }
    while( true ) {
        if (uVar5 == 0) {
            return 0;
        }
        bVar9 = *(uint8_t *)puVar6 < *(uint8_t *)((int64_t)puVar6 + iVar7);
        if (*(uint8_t *)puVar6 != *(uint8_t *)((int64_t)puVar6 + iVar7)) break;
        puVar6 = (uint64_t *)((int64_t)puVar6 + 1);
        uVar5 = uVar5 - 1;
    }
code_r0x000180497f73:
    return (1 - (uint32_t)bVar9) - (uint32_t)(bVar9 != 0);
}

// ============================================================
// Function: FUN_18022dd50
// Address: 0x18022dd50
// Size: 140 bytes
// ============================================================
void fcn.18022dd50(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022dd5a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)0x18077e4a0 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022dd70;
        fcn.180229280(*(int64_t *)0x18077e4a0, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022dd83;
        fcn.180228c50(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022dd96;
        fcn.180228c50(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022dda9;
        fcn.180228c50(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ddb5;
        fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(int64_t *)0x18077e4a0 = 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022ddcc;
    fcn.1802227d0(*(undefined8 *)0x18077e4a8);
    *(undefined8 *)0x18077e4a8 = 0;
    return;
}

// ============================================================
// Function: FUN_18022dde0
// Address: 0x18022dde0
// Size: 249 bytes
// ============================================================
int32_t fcn.18022dde0(int64_t arg1, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint32_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    code *pcStackX_18;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022ddf0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0;
    if (arg1 != 0) {
        if (*(int32_t *)(arg1 + 0x10) != 0) {
            return *(int32_t *)(arg1 + 0x10);
        }
        if (*(int32_t *)(arg1 + 0x14) != 0) {
            *(undefined4 *)((int64_t)&iStackX_20 + iVar2) = 0;
            *(code **)((int64_t)&pcStackX_18 + iVar2) = fcn.18022dcf0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022de3f;
            puVar3 = (uint32_t *)
                     fcn.1802963b0(*(int64_t *)((int64_t)&pcStackX_18 + iVar2), 
                                   *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                                   *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2));
            if (puVar3 != (uint32_t *)0x0) {
                return *(int32_t *)((uint64_t)*puVar3 * 0x28 + 0x1804c3050);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022de5f;
            iVar1 = fcn.18022dee0();
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)((int64_t)&arg_48h + iVar2);
                *(undefined4 *)(&stack0x00000028 + iVar2) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022deb9;
                iVar4 = fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar2));
                if (iVar4 != 0) {
                    iVar5 = *(int32_t *)(*(int64_t *)(iVar4 + 8) + 0x10);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022ded1;
                fcn.180222910(*(undefined8 *)0x18077e4a8);
                return iVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022de68;
            fcn.180229480(*(int64_t *)((int64_t)&pcStackX_18 + iVar2), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022de80;
            fcn.1802295a0(*(int64_t *)((int64_t)&pcStackX_18 + iVar2), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022de92;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022dee0
// Address: 0x18022dee0
// Size: 82 bytes
// ============================================================
undefined8 fcn.18022dee0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022deea;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022def9;
    fcn.180243560(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022df0c;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
    iVar4 = 0;
    if (iVar1 != 0) {
        iVar4 = *(int32_t *)0x18077e4b4;
    }
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&iStackX_20 + iVar3) = 0x18022285a;
    iVar2 = fcn.18045a350(*(undefined8 *)0x18077e4a8);
    *(undefined8 *)((int64_t)&iStackX_20 + (iVar3 - iVar2)) = 0x180222863;
    (*(code *)0x69a0ae)();
    return 1;
}

// ============================================================
// Function: FUN_18022df40
// Address: 0x18022df40
// Size: 45 bytes
// ============================================================
uint64_t fcn.18022df40(undefined8 *param_1, uint32_t *param_2)
{
    uint8_t uVar1;
    uint64_t uVar2;
    uint64_t *puVar3;
    int64_t iVar4;
    
    fcn.18045a350();
    puVar3 = *(uint64_t **)*param_1;
    iVar4 = *(int64_t *)((uint64_t)*param_2 * 0x28 + 0x1804c3040) - (int64_t)puVar3;
    while( true ) {
        if (((uint64_t)puVar3 & 7) == 0) {
            while ((((int32_t)iVar4 + (int32_t)puVar3 & 0xfffU) < 0xff9 &&
                   (uVar2 = *puVar3, uVar2 == *(uint64_t *)(iVar4 + (int64_t)puVar3)))) {
                puVar3 = puVar3 + 1;
                if ((~uVar2 & uVar2 + 0xfefefefefefefeff & 0x8080808080808080) != 0) {
                    return 0;
                }
            }
        }
        uVar1 = *(uint8_t *)puVar3;
        if (uVar1 != *(uint8_t *)(iVar4 + (int64_t)puVar3)) break;
        puVar3 = (uint64_t *)((int64_t)puVar3 + 1);
        if (uVar1 == 0) {
            return 0;
        }
    }
    return -(uint64_t)(uVar1 < *(uint8_t *)(iVar4 + (int64_t)puVar3)) | 1;
}

// ============================================================
// Function: FUN_18022df70
// Address: 0x18022df70
// Size: 86 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018022df99: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018022df9e)
// WARNING: Removing unreachable block (ram,0x00018022dfa2)

undefined8
fcn.18022df70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint32_t *puVar9;
    int32_t *piVar10;
    int64_t iVar11;
    undefined4 *in_RCX;
    uint32_t uVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t aiStack_20 [3];
    
    aiStack_20[2] = 0x18022df7c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == (undefined4 *)0x0) {
        return 0;
    }
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)aiStack_20 + iVar6 + 0x10) = 0x18022df8e;
    uVar7 = fcn.18022ccf0(uVar1);
    uVar12 = 2;
    *(undefined8 *)((int64_t)aiStack_20 + iVar6 + 0x10) = 0x18022df9e;
    *(undefined4 **)(&stack0xfffffffffffffff8 + iVar6) = in_RCX;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = unaff_RBP;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStack_20 + iVar6 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStack_20 + iVar6) = 0x180281910;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281930;
    iVar4 = fcn.180222870(*(int64_t *)(&stack0x00000008 + iVar8 + iVar6));
    iVar5 = 0;
    if (iVar4 != 0) {
        iVar5 = *(int32_t *)0x18077e96c;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281959;
        puVar9 = (uint32_t *)
                 fcn.1802248d0(*(int64_t *)(&stack0x00000008 + iVar8 + iVar6), 
                               *(int64_t *)(&stack0x00000010 + iVar8 + iVar6));
        uVar2 = *(undefined8 *)0x18077e958;
        if (puVar9 != (uint32_t *)0x0) {
            *(undefined8 *)(puVar9 + 2) = uVar7;
            *(undefined4 **)(puVar9 + 4) = in_RCX;
            puVar9[1] = uVar12 & 0x8000;
            *puVar9 = uVar12 & 0xffff7fff;
            *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281985;
            iVar5 = fcn.180222950(uVar2);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x1802819ca;
                piVar10 = (int32_t *)
                          fcn.180228fb0(*(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar6 + -8), 
                                        *(int64_t *)((int64_t)&iStackX_20 + iVar8 + iVar6), 
                                        *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar6));
                if (piVar10 == (int32_t *)0x0) {
                    *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281a3f;
                    iVar5 = fcn.180228e00(*(undefined8 *)0x18077e950);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281a58;
                        fcn.180224990(puVar9, 0x1804e9240, 0xe6);
                        *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281a64;
                        fcn.180222910(*(undefined8 *)0x18077e958);
                        return 0;
                    }
                } else {
                    if (*(int64_t *)0x18077e960 != 0) {
                        *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x1802819e3;
                        iVar5 = fcn.180222010();
                        if (*piVar10 < iVar5) {
                            *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x1802819f5;
                            iVar11 = fcn.180222340(*(int64_t *)0x18077e960);
                            uVar7 = *(undefined8 *)(piVar10 + 4);
                            iVar5 = *piVar10;
                            uVar2 = *(undefined8 *)(piVar10 + 2);
                            pcVar3 = *(code **)(iVar11 + 0x10);
                            *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281a06;
                            (*pcVar3)(uVar2, iVar5, uVar7);
                        }
                    }
                    *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281a1b;
                    fcn.180224990(piVar10, 0x1804e9240, 0xe2);
                }
                *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x180281a2c;
                fcn.180222910(*(undefined8 *)0x18077e958);
                return 1;
            }
            *(undefined8 *)((int64_t)aiStack_20 + iVar8 + iVar6) = 0x18028199e;
            fcn.180224990(puVar9, 0x1804e9240, 0xd1);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022dfd0
// Address: 0x18022dfd0
// Size: 162 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018022dffb: Changing call to branch
// WARNING: Possible PIC construction at 0x00018022e016: Changing call to branch
// WARNING: Possible PIC construction at 0x00018022e03a: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018022e01b)
// WARNING: Removing unreachable block (ram,0x00018022e01f)
// WARNING: Removing unreachable block (ram,0x00018022e026)
// WARNING: Removing unreachable block (ram,0x00018022e02a)
// WARNING: Removing unreachable block (ram,0x00018022e000)
// WARNING: Removing unreachable block (ram,0x00018022e004)
// WARNING: Removing unreachable block (ram,0x00018022e03f)
// WARNING: Removing unreachable block (ram,0x00018022e065)
// WARNING: Removing unreachable block (ram,0x00018022e067)
// WARNING: Removing unreachable block (ram,0x00018022e043)
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18022dfd0(int64_t arg_28h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint32_t *puVar9;
    int32_t *piVar10;
    int64_t iVar11;
    undefined4 *in_RCX;
    uint32_t uVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 auStack_20 [3];
    
    auStack_20[2] = 0x18022dfe0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)auStack_20 + iVar6 + 0x10) = 0x18022dfed;
    uVar7 = fcn.18022ccf0(uVar1);
    uVar12 = 1;
    *(undefined8 *)((int64_t)auStack_20 + iVar6 + 0x10) = 0x18022e000;
    *(undefined4 **)(&stack0xfffffffffffffff8 + iVar6) = in_RCX;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + -0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + -8) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar6) = uVar7;
    *(undefined8 *)((int64_t)auStack_20 + iVar6 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_20 + iVar6) = 0x180281910;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281930;
    iVar4 = fcn.180222870(*(int64_t *)((int64_t)aiStackX_10 + iVar8 + iVar6 + -8));
    iVar5 = 0;
    if (iVar4 != 0) {
        iVar5 = *(int32_t *)0x18077e96c;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281959;
        puVar9 = (uint32_t *)
                 fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_10 + iVar8 + iVar6 + -8), 
                               *(int64_t *)((int64_t)aiStackX_10 + iVar8 + iVar6));
        uVar2 = *(undefined8 *)0x18077e958;
        if (puVar9 != (uint32_t *)0x0) {
            *(undefined8 *)(puVar9 + 2) = uVar7;
            *(undefined4 **)(puVar9 + 4) = in_RCX;
            puVar9[1] = uVar12 & 0x8000;
            *puVar9 = uVar12 & 0xffff7fff;
            *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281985;
            iVar5 = fcn.180222950(uVar2);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x1802819ca;
                piVar10 = (int32_t *)
                          fcn.180228fb0(*(int64_t *)((int64_t)aiStackX_10 + iVar8 + iVar6 + 8), 
                                        *(int64_t *)((int64_t)aiStackX_10 + iVar8 + iVar6 + 0x10), 
                                        *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar6));
                if (piVar10 == (int32_t *)0x0) {
                    *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281a3f;
                    iVar5 = fcn.180228e00(*(undefined8 *)0x18077e950);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281a58;
                        fcn.180224990(puVar9, 0x1804e9240, 0xe6);
                        *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281a64;
                        fcn.180222910(*(undefined8 *)0x18077e958);
                        return 0;
                    }
                } else {
                    if (*(int64_t *)0x18077e960 != 0) {
                        *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x1802819e3;
                        iVar5 = fcn.180222010();
                        if (*piVar10 < iVar5) {
                            *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x1802819f5;
                            iVar11 = fcn.180222340(*(int64_t *)0x18077e960);
                            uVar7 = *(undefined8 *)(piVar10 + 4);
                            iVar5 = *piVar10;
                            uVar2 = *(undefined8 *)(piVar10 + 2);
                            pcVar3 = *(code **)(iVar11 + 0x10);
                            *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281a06;
                            (*pcVar3)(uVar2, iVar5, uVar7);
                        }
                    }
                    *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281a1b;
                    fcn.180224990(piVar10, 0x1804e9240, 0xe2);
                }
                *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x180281a2c;
                fcn.180222910(*(undefined8 *)0x18077e958);
                return 1;
            }
            *(undefined8 *)((int64_t)auStack_20 + iVar8 + iVar6) = 0x18028199e;
            fcn.180224990(puVar9, 0x1804e9240, 0xd1);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022e080
// Address: 0x18022e080
// Size: 73 bytes
// ============================================================
int64_t fcn.18022e080(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e08c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e09e;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0b9;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0d3;
        fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x000000a8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0e1;
        iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0ea;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0f7;
            uVar4 = fcn.1802119f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0ff;
            fcn.180211a40(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e104;
            fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e10f;
            iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e138;
        iVar1 = fcn.180299310(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        iVar3 = *(int64_t *)((int64_t)&arg_30h + iVar2);
        if (iVar1 == 0) {
            iVar3 = 0;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022e0c9
// Address: 0x18022e0c9
// Size: 89 bytes
// ============================================================
int64_t fcn.18022e080(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e08c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e09e;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0b9;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0d3;
        fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x000000a8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0e1;
        iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0ea;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0f7;
            uVar4 = fcn.1802119f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0ff;
            fcn.180211a40(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e104;
            fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e10f;
            iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e138;
        iVar1 = fcn.180299310(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        iVar3 = *(int64_t *)((int64_t)&arg_30h + iVar2);
        if (iVar1 == 0) {
            iVar3 = 0;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022e122
// Address: 0x18022e122
// Size: 43 bytes
// ============================================================
int64_t fcn.18022e080(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e08c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e09e;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0b9;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0d3;
        fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x000000a8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0e1;
        iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0ea;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0f7;
            uVar4 = fcn.1802119f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0ff;
            fcn.180211a40(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e104;
            fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e10f;
            iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e138;
        iVar1 = fcn.180299310(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        iVar3 = *(int64_t *)((int64_t)&arg_30h + iVar2);
        if (iVar1 == 0) {
            iVar3 = 0;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022e14d
// Address: 0x18022e14d
// Size: 6 bytes
// ============================================================
int64_t fcn.18022e080(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e08c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e09e;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0b9;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0d3;
        fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x000000a8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0e1;
        iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0ea;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0f7;
            uVar4 = fcn.1802119f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e0ff;
            fcn.180211a40(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e104;
            fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e10f;
            iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e138;
        iVar1 = fcn.180299310(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        iVar3 = *(int64_t *)((int64_t)&arg_30h + iVar2);
        if (iVar1 == 0) {
            iVar3 = 0;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022e160
// Address: 0x18022e160
// Size: 73 bytes
// ============================================================
int64_t fcn.18022e160(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e16c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e17e;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e199;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1b3;
        fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x000000a8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1c1;
        iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1ca;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1d7;
            uVar4 = fcn.180215540(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1df;
            fcn.180215590(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1e4;
            fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1ef;
            iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e218;
        iVar1 = fcn.180299310(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        iVar3 = *(int64_t *)((int64_t)&arg_30h + iVar2);
        if (iVar1 == 0) {
            iVar3 = 0;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022e1a9
// Address: 0x18022e1a9
// Size: 89 bytes
// ============================================================
int64_t fcn.18022e160(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e16c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e17e;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e199;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1b3;
        fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x000000a8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1c1;
        iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1ca;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1d7;
            uVar4 = fcn.180215540(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1df;
            fcn.180215590(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1e4;
            fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1ef;
            iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e218;
        iVar1 = fcn.180299310(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        iVar3 = *(int64_t *)((int64_t)&arg_30h + iVar2);
        if (iVar1 == 0) {
            iVar3 = 0;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18022e202
// Address: 0x18022e202
// Size: 43 bytes
// ============================================================
int64_t fcn.18022e160(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022e16c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e17e;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e199;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1b3;
        fcn.180299670(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x000000a8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1c1;
        iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1ca;
            fcn.180229b10();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1d7;
            uVar4 = fcn.180215540(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1df;
            fcn.180215590(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1e4;
            fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e1ef;
            iVar1 = fcn.1802993f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022e218;
        iVar1 = fcn.180299310(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
        iVar3 = *(int64_t *)((int64_t)&arg_30h + iVar2);
        if (iVar1 == 0) {
            iVar3 = 0;
        }
    }
    return iVar3;
}

