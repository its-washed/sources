// Chunk 171 - 50 functions

// ============================================================
// Function: FUN_180228ce0
// Address: 0x180228ce0
// Size: 33 bytes
// ============================================================
void fcn.180228ce0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 in_R8;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228cf8;
        iVar6 = func_0x00018045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
        pcVar2 = *(code **)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180228d3f;
                    (*pcVar2)(uVar4, in_R8, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228d01
// Address: 0x180228d01
// Size: 28 bytes
// ============================================================
void fcn.180228ce0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 in_R8;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228cf8;
        iVar6 = func_0x00018045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
        pcVar2 = *(code **)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180228d3f;
                    (*pcVar2)(uVar4, in_R8, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228d1d
// Address: 0x180228d1d
// Size: 53 bytes
// ============================================================
void fcn.180228ce0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 in_R8;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228cf8;
        iVar6 = func_0x00018045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
        pcVar2 = *(code **)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180228d3f;
                    (*pcVar2)(uVar4, in_R8, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228d52
// Address: 0x180228d52
// Size: 19 bytes
// ============================================================
void fcn.180228ce0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 in_R8;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228cf8;
        iVar6 = func_0x00018045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
        pcVar2 = *(code **)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180228d3f;
                    (*pcVar2)(uVar4, in_R8, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228d65
// Address: 0x180228d65
// Size: 1 bytes
// ============================================================
void fcn.180228ce0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 in_R8;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228cf8;
        iVar6 = func_0x00018045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
        pcVar2 = *(code **)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        iVar7 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*(int64_t *)arg1 + iVar7 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180228d3f;
                    (*pcVar2)(uVar4, in_R8, in_RDX);
                    puVar5 = puVar3;
                }
                iVar7 = iVar7 + -1;
            } while (-1 < iVar7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228d70
// Address: 0x180228d70
// Size: 41 bytes
// ============================================================
void fcn.180228d70(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    code *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228d8d;
        iVar5 = func_0x00018045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        iVar6 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            do {
                puVar4 = *(undefined8 **)(*(int64_t *)arg1 + iVar6 * 8);
                while (puVar4 != (undefined8 *)0x0) {
                    puVar2 = (undefined8 *)puVar4[1];
                    uVar3 = *puVar4;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180228dd0;
                    (*in_RDX)(uVar3, in_R9, in_R8);
                    puVar4 = puVar2;
                }
                iVar6 = iVar6 + -1;
            } while (-1 < iVar6);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228d99
// Address: 0x180228d99
// Size: 19 bytes
// ============================================================
void fcn.180228d70(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    code *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228d8d;
        iVar5 = func_0x00018045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        iVar6 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            do {
                puVar4 = *(undefined8 **)(*(int64_t *)arg1 + iVar6 * 8);
                while (puVar4 != (undefined8 *)0x0) {
                    puVar2 = (undefined8 *)puVar4[1];
                    uVar3 = *puVar4;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180228dd0;
                    (*in_RDX)(uVar3, in_R9, in_R8);
                    puVar4 = puVar2;
                }
                iVar6 = iVar6 + -1;
            } while (-1 < iVar6);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228dac
// Address: 0x180228dac
// Size: 55 bytes
// ============================================================
void fcn.180228d70(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    code *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228d8d;
        iVar5 = func_0x00018045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        iVar6 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            do {
                puVar4 = *(undefined8 **)(*(int64_t *)arg1 + iVar6 * 8);
                while (puVar4 != (undefined8 *)0x0) {
                    puVar2 = (undefined8 *)puVar4[1];
                    uVar3 = *puVar4;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180228dd0;
                    (*in_RDX)(uVar3, in_R9, in_R8);
                    puVar4 = puVar2;
                }
                iVar6 = iVar6 + -1;
            } while (-1 < iVar6);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228de3
// Address: 0x180228de3
// Size: 19 bytes
// ============================================================
void fcn.180228d70(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    code *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228d8d;
        iVar5 = func_0x00018045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        iVar6 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            do {
                puVar4 = *(undefined8 **)(*(int64_t *)arg1 + iVar6 * 8);
                while (puVar4 != (undefined8 *)0x0) {
                    puVar2 = (undefined8 *)puVar4[1];
                    uVar3 = *puVar4;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180228dd0;
                    (*in_RDX)(uVar3, in_R9, in_R8);
                    puVar4 = puVar2;
                }
                iVar6 = iVar6 + -1;
            } while (-1 < iVar6);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228df6
// Address: 0x180228df6
// Size: 1 bytes
// ============================================================
void fcn.180228d70(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    code *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_20;
    
    if (arg1 != 0) {
        uStack_20 = 0x180228d8d;
        iVar5 = func_0x00018045a350();
        iVar5 = -iVar5;
        iVar1 = *(int32_t *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        iVar6 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            do {
                puVar4 = *(undefined8 **)(*(int64_t *)arg1 + iVar6 * 8);
                while (puVar4 != (undefined8 *)0x0) {
                    puVar2 = (undefined8 *)puVar4[1];
                    uVar3 = *puVar4;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180228dd0;
                    (*in_RDX)(uVar3, in_R9, in_R8);
                    puVar4 = puVar2;
                }
                iVar6 = iVar6 + -1;
            } while (-1 < iVar6);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180228e10
// Address: 0x180228e10
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228e10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228e24;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228e86;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180228e27
// Address: 0x180228e27
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228e10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228e24;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228e86;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180228e3d
// Address: 0x180228e3d
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228e10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228e24;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228e86;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180228ea6
// Address: 0x180228ea6
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228e10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228e24;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228e86;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180228eb8
// Address: 0x180228eb8
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228e10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228e24;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228e86;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180228ec0
// Address: 0x180228ec0
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228ec0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228ed4;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f36;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        iVar1 = *(int64_t *)arg1;
        *(undefined4 *)(arg1 + 0x50) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f6e;
        func_0x000180224990(iVar1, 0x1804c07c8, 0x5c);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f83;
        func_0x000180224990(arg1, 0x1804c07c8, 0x5d);
    }
    return;
}

// ============================================================
// Function: FUN_180228ed7
// Address: 0x180228ed7
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228ec0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228ed4;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f36;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        iVar1 = *(int64_t *)arg1;
        *(undefined4 *)(arg1 + 0x50) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f6e;
        func_0x000180224990(iVar1, 0x1804c07c8, 0x5c);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f83;
        func_0x000180224990(arg1, 0x1804c07c8, 0x5d);
    }
    return;
}

// ============================================================
// Function: FUN_180228eed
// Address: 0x180228eed
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228ec0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228ed4;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f36;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        iVar1 = *(int64_t *)arg1;
        *(undefined4 *)(arg1 + 0x50) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f6e;
        func_0x000180224990(iVar1, 0x1804c07c8, 0x5c);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f83;
        func_0x000180224990(arg1, 0x1804c07c8, 0x5d);
    }
    return;
}

// ============================================================
// Function: FUN_180228f56
// Address: 0x180228f56
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228ec0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228ed4;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f36;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        iVar1 = *(int64_t *)arg1;
        *(undefined4 *)(arg1 + 0x50) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f6e;
        func_0x000180224990(iVar1, 0x1804c07c8, 0x5c);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f83;
        func_0x000180224990(arg1, 0x1804c07c8, 0x5d);
    }
    return;
}

// ============================================================
// Function: FUN_180228f92
// Address: 0x180228f92
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180228ec0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar5;
    uint32_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180228ed4;
        iVar4 = func_0x00018045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        uVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        if (*(int32_t *)(arg1 + 0x38) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R14;
            do {
                iVar1 = uVar5 * 8;
                iVar3 = *(int64_t *)(iVar1 + *(int64_t *)arg1);
                while (iVar3 != 0) {
                    iVar2 = *(int64_t *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f36;
                    func_0x000180224990(iVar3, 0x1804c07c8, 0x6c);
                    iVar3 = iVar2;
                }
                uVar6 = (int32_t)uVar5 + 1;
                uVar5 = (uint64_t)uVar6;
                *(undefined8 *)(iVar1 + *(int64_t *)arg1) = 0;
            } while (uVar6 < *(uint32_t *)(arg1 + 0x38));
        }
        iVar1 = *(int64_t *)arg1;
        *(undefined4 *)(arg1 + 0x50) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f6e;
        func_0x000180224990(iVar1, 0x1804c07c8, 0x5c);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180228f83;
        func_0x000180224990(arg1, 0x1804c07c8, 0x5d);
    }
    return;
}

// ============================================================
// Function: FUN_180228fb0
// Address: 0x180228fb0
// Size: 370 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180228fb0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t *piVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    uStack_30 = 0x180228fcc;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(undefined4 *)((int64_t)in_RCX + 0x54) = 0;
    if (*(uint32_t *)(in_RCX + 9) <= (uint32_t)(*(int32_t *)(in_RCX + 10) << 8) / *(uint32_t *)(in_RCX + 7)) {
        uVar2 = *(uint32_t *)(in_RCX + 8);
        uVar3 = *(uint32_t *)((int64_t)in_RCX + 0x44);
        uVar4 = *(uint32_t *)((int64_t)in_RCX + 0x3c);
        uVar6 = uVar2 + 1;
        if (uVar3 <= uVar2 + 1) {
            iVar8 = *in_RCX;
            *(undefined4 *)((int64_t)&var_8h + iVar7) = 0xfe;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180229025;
            iVar8 = func_0x000180224f60(iVar8, uVar4 * 2, 8, 0x1804c07c8);
            if (iVar8 == 0) goto code_r0x00018022902d;
            *in_RCX = iVar8;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18022904c;
            func_0x0001804986e0(iVar8 + (uint64_t)uVar4 * 8, 0);
            *(uint32_t *)((int64_t)in_RCX + 0x44) = uVar4;
            *(uint32_t *)((int64_t)in_RCX + 0x3c) = uVar4 * 2;
            uVar6 = 0;
        }
        *(uint32_t *)(in_RCX + 8) = uVar6;
        uVar9 = (uint64_t)(uVar3 + uVar2);
        iVar8 = *in_RCX;
        *(int32_t *)(in_RCX + 7) = *(int32_t *)(in_RCX + 7) + 1;
        piVar10 = (int64_t *)(iVar8 + (uint64_t)uVar2 * 8);
        *(undefined8 *)(iVar8 + uVar9 * 8) = 0;
        piVar1 = (int64_t *)(iVar8 + uVar9 * 8);
        iVar8 = *piVar10;
        while (iVar8 != 0) {
            if (*(uint32_t *)(iVar8 + 0x10) % uVar4 == uVar2) {
                piVar10 = (int64_t *)(iVar8 + 8);
            } else {
                *piVar10 = *(int64_t *)(iVar8 + 8);
                *(int64_t *)(iVar8 + 8) = *piVar1;
                *piVar1 = iVar8;
            }
            iVar8 = *piVar10;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802290be;
    piVar10 = (int64_t *)func_0x000180229330(in_RCX, in_RDX, (int64_t)&arg_38h + iVar7);
    puVar11 = (undefined8 *)*piVar10;
    if (puVar11 != (undefined8 *)0x0) {
        uVar5 = *puVar11;
        *puVar11 = in_RDX;
        return uVar5;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802290e0;
    puVar11 = (undefined8 *)func_0x0001802248d0(0x18, 0x1804c07c8, 0x82);
    if (puVar11 != (undefined8 *)0x0) {
        *puVar11 = in_RDX;
        puVar11[1] = 0;
        *(undefined4 *)(puVar11 + 2) = *(undefined4 *)((int64_t)&arg_38h + iVar7);
        *piVar10 = (int64_t)puVar11;
        *(int32_t *)(in_RCX + 10) = *(int32_t *)(in_RCX + 10) + 1;
        return 0;
    }
code_r0x00018022902d:
    *(int32_t *)((int64_t)in_RCX + 0x54) = *(int32_t *)((int64_t)in_RCX + 0x54) + 1;
    return 0;
}

// ============================================================
// Function: FUN_180229130
// Address: 0x180229130
// Size: 246 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t * fcn.180229130(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180229145;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180229165;
    piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (piVar2 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180229189;
        iVar3 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *piVar2 = iVar3;
        if (iVar3 != 0) {
            *(undefined4 *)(piVar2 + 7) = 8;
            *(undefined4 *)((int64_t)piVar2 + 0x3c) = 0x10;
            if (in_RDX == 0) {
                in_RDX = 0x180498f10;
            }
            *(undefined4 *)((int64_t)piVar2 + 0x44) = 8;
            piVar2[1] = in_RDX;
            *(undefined4 *)(piVar2 + 9) = 0x200;
            if (in_RCX == 0) {
                in_RCX = 0x1802292c0;
            }
            *(undefined4 *)((int64_t)piVar2 + 0x4c) = 0x100;
            piVar2[2] = in_RCX;
            return piVar2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802291a5;
        fcn.180224990(0, 0x1804c07c8, 0x51);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802291ba;
        fcn.180224990(piVar2, 0x1804c07c8, 0x52);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180229240
// Address: 0x180229240
// Size: 57 bytes
// ============================================================
undefined8 * fcn.180229240(int64_t arg_30h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t in_RCX;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022924a;
    iVar2 = fcn.18045a350();
    if (*(int32_t *)(in_RCX + 0x54) != 0) {
        *(undefined4 *)(in_RCX + 0x54) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x180229264;
    piVar3 = (int64_t *)func_0x000180229330();
    puVar1 = (undefined8 *)*piVar3;
    if (puVar1 == (undefined8 *)0x0) {
        return puVar1;
    }
    return (undefined8 *)*puVar1;
}

// ============================================================
// Function: FUN_180229330
// Address: 0x180229330
// Size: 193 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 * fcn.180229330(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 *puVar1;
    code *pcVar2;
    code *pcVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    uint32_t uVar10;
    undefined8 in_RDX;
    uint32_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180229350;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    pcVar2 = (code *)in_RCX[3];
    pcVar3 = (code *)in_RCX[2];
    if (pcVar2 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180229376;
        uVar7 = (*pcVar3)(in_RDX);
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180229372;
        uVar7 = (*pcVar2)();
    }
    *in_R8 = uVar7;
    uVar10 = uVar7 % *(uint32_t *)((int64_t)in_RCX + 0x44);
    if (uVar10 < *(uint32_t *)(in_RCX + 8)) {
        uVar10 = uVar7 % *(uint32_t *)((int64_t)in_RCX + 0x3c);
    }
    puVar4 = *(undefined8 **)(*in_RCX + (int64_t)(int32_t)uVar10 * 8);
    puVar1 = (undefined8 *)(*in_RCX + (int64_t)(int32_t)uVar10 * 8);
    do {
        if (puVar4 == (undefined8 *)0x0) {
            return puVar1;
        }
        if (*(uint32_t *)(puVar4 + 2) == uVar7) {
            pcVar2 = (code *)in_RCX[4];
            uVar5 = *puVar4;
            if (pcVar2 == (code *)0x0) {
                pcVar2 = (code *)in_RCX[1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802293c2;
                iVar8 = (*pcVar2)(uVar5, in_RDX);
            } else {
                iVar6 = in_RCX[1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1802293ba;
                iVar8 = (*pcVar2)(uVar5, in_RDX, iVar6);
            }
            if (iVar8 == 0) {
                return puVar1;
            }
        }
        puVar1 = puVar4 + 1;
        puVar4 = (undefined8 *)puVar4[1];
    } while( true );
}

// ============================================================
// Function: FUN_180229480
// Address: 0x180229480
// Size: 40 bytes
// ============================================================
void fcn.180229480(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    undefined *puVar2;
    undefined8 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint32_t uVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar8;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022948c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229494;
    iVar6 = func_0x000180221280();
    if (iVar6 != 0) {
        iVar1 = *(int32_t *)(iVar6 + 0x340);
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        uVar7 = iVar1 + 1U & 0x8000000f;
        if ((int32_t)uVar7 < 0) {
            uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
        }
        *(uint32_t *)(iVar6 + 0x340) = uVar7;
        if (uVar7 == *(uint32_t *)(iVar6 + 0x344)) {
            uVar4 = *(uint32_t *)(iVar6 + 0x344) + 1 & 0x8000000f;
            if ((int32_t)uVar4 < 0) {
                uVar4 = (uVar4 - 1 | 0xfffffff0) + 1;
            }
            *(uint32_t *)(iVar6 + 0x344) = uVar4;
        }
        iVar8 = (int64_t)(int32_t)uVar7;
        if ((*(uint8_t *)(iVar6 + 0x1c0 + iVar8 * 4) & 1) == 0) {
            *(undefined8 *)(iVar6 + 0xc0 + iVar8 * 8) = 0;
            *(undefined8 *)(iVar6 + 0x140 + iVar8 * 8) = 0;
            *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 0;
        } else {
            puVar2 = *(undefined **)(iVar6 + 0xc0 + iVar8 * 8);
            if (puVar2 != (undefined *)0x0) {
                *puVar2 = 0;
                *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 1;
            }
        }
        *(undefined4 *)(iVar6 + 0x40 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + 0x80 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + 0x280 + iVar8 * 4) = 0xffffffff;
        uVar3 = *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022955d;
        fcn.180224990(uVar3, 0x1804bf6a0, 0x5b);
        uVar3 = *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8);
        *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022957f;
        fcn.180224990(uVar3, 0x1804bf6a0, 0x5d);
        *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1802294a8
// Address: 0x1802294a8
// Size: 233 bytes
// ============================================================
void fcn.180229480(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    undefined *puVar2;
    undefined8 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint32_t uVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar8;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022948c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229494;
    iVar6 = func_0x000180221280();
    if (iVar6 != 0) {
        iVar1 = *(int32_t *)(iVar6 + 0x340);
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        uVar7 = iVar1 + 1U & 0x8000000f;
        if ((int32_t)uVar7 < 0) {
            uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
        }
        *(uint32_t *)(iVar6 + 0x340) = uVar7;
        if (uVar7 == *(uint32_t *)(iVar6 + 0x344)) {
            uVar4 = *(uint32_t *)(iVar6 + 0x344) + 1 & 0x8000000f;
            if ((int32_t)uVar4 < 0) {
                uVar4 = (uVar4 - 1 | 0xfffffff0) + 1;
            }
            *(uint32_t *)(iVar6 + 0x344) = uVar4;
        }
        iVar8 = (int64_t)(int32_t)uVar7;
        if ((*(uint8_t *)(iVar6 + 0x1c0 + iVar8 * 4) & 1) == 0) {
            *(undefined8 *)(iVar6 + 0xc0 + iVar8 * 8) = 0;
            *(undefined8 *)(iVar6 + 0x140 + iVar8 * 8) = 0;
            *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 0;
        } else {
            puVar2 = *(undefined **)(iVar6 + 0xc0 + iVar8 * 8);
            if (puVar2 != (undefined *)0x0) {
                *puVar2 = 0;
                *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 1;
            }
        }
        *(undefined4 *)(iVar6 + 0x40 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + 0x80 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + 0x280 + iVar8 * 4) = 0xffffffff;
        uVar3 = *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022955d;
        fcn.180224990(uVar3, 0x1804bf6a0, 0x5b);
        uVar3 = *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8);
        *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022957f;
        fcn.180224990(uVar3, 0x1804bf6a0, 0x5d);
        *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180229591
// Address: 0x180229591
// Size: 6 bytes
// ============================================================
void fcn.180229480(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    undefined *puVar2;
    undefined8 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint32_t uVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar8;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022948c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229494;
    iVar6 = func_0x000180221280();
    if (iVar6 != 0) {
        iVar1 = *(int32_t *)(iVar6 + 0x340);
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        uVar7 = iVar1 + 1U & 0x8000000f;
        if ((int32_t)uVar7 < 0) {
            uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
        }
        *(uint32_t *)(iVar6 + 0x340) = uVar7;
        if (uVar7 == *(uint32_t *)(iVar6 + 0x344)) {
            uVar4 = *(uint32_t *)(iVar6 + 0x344) + 1 & 0x8000000f;
            if ((int32_t)uVar4 < 0) {
                uVar4 = (uVar4 - 1 | 0xfffffff0) + 1;
            }
            *(uint32_t *)(iVar6 + 0x344) = uVar4;
        }
        iVar8 = (int64_t)(int32_t)uVar7;
        if ((*(uint8_t *)(iVar6 + 0x1c0 + iVar8 * 4) & 1) == 0) {
            *(undefined8 *)(iVar6 + 0xc0 + iVar8 * 8) = 0;
            *(undefined8 *)(iVar6 + 0x140 + iVar8 * 8) = 0;
            *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 0;
        } else {
            puVar2 = *(undefined **)(iVar6 + 0xc0 + iVar8 * 8);
            if (puVar2 != (undefined *)0x0) {
                *puVar2 = 0;
                *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 1;
            }
        }
        *(undefined4 *)(iVar6 + 0x40 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + 0x80 + iVar8 * 4) = 0;
        *(undefined4 *)(iVar6 + 0x280 + iVar8 * 4) = 0xffffffff;
        uVar3 = *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022955d;
        fcn.180224990(uVar3, 0x1804bf6a0, 0x5b);
        uVar3 = *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8);
        *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022957f;
        fcn.180224990(uVar3, 0x1804bf6a0, 0x5d);
        *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1802295a0
// Address: 0x1802295a0
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1802295a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    undefined4 in_EDX;
    undefined8 unaff_RBP;
    int64_t iVar5;
    char *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802295bb;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802295cc;
    iVar3 = func_0x000180221280();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
        iVar5 = (int64_t)*(int32_t *)(iVar3 + 0x340);
        uVar1 = *(undefined8 *)(iVar3 + 0x200 + iVar5 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802295fe;
        fcn.180224990(uVar1, 0x1804bf6a0, 0x39);
        if ((in_RCX == (char *)0x0) || (*in_RCX == '\0')) {
            *(undefined8 *)(iVar3 + 0x200 + iVar5 * 8) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229610;
            func_0x000180498cd0(in_RCX);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022961e;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(int64_t *)(iVar3 + 0x200 + iVar5 * 8) = iVar4;
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229636;
                func_0x0001804990c0(iVar4, in_RCX);
            }
        }
        *(undefined4 *)(iVar3 + 0x280 + iVar5 * 4) = in_EDX;
        uVar1 = *(undefined8 *)(iVar3 + 0x2c0 + iVar5 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229666;
        fcn.180224990(uVar1, 0x1804bf6a0, 0x42);
        if ((in_R8 == (char *)0x0) || (*in_R8 == '\0')) {
            *(undefined8 *)(iVar3 + 0x2c0 + iVar5 * 8) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229678;
            func_0x000180498cd0(in_R8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229686;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(int64_t *)(iVar3 + 0x2c0 + iVar5 * 8) = iVar4;
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022969e;
                func_0x0001804990c0(iVar4, in_R8);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802295d8
// Address: 0x1802295d8
// Size: 217 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1802295a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    undefined4 in_EDX;
    undefined8 unaff_RBP;
    int64_t iVar5;
    char *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802295bb;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802295cc;
    iVar3 = func_0x000180221280();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
        iVar5 = (int64_t)*(int32_t *)(iVar3 + 0x340);
        uVar1 = *(undefined8 *)(iVar3 + 0x200 + iVar5 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802295fe;
        fcn.180224990(uVar1, 0x1804bf6a0, 0x39);
        if ((in_RCX == (char *)0x0) || (*in_RCX == '\0')) {
            *(undefined8 *)(iVar3 + 0x200 + iVar5 * 8) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229610;
            func_0x000180498cd0(in_RCX);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022961e;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(int64_t *)(iVar3 + 0x200 + iVar5 * 8) = iVar4;
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229636;
                func_0x0001804990c0(iVar4, in_RCX);
            }
        }
        *(undefined4 *)(iVar3 + 0x280 + iVar5 * 4) = in_EDX;
        uVar1 = *(undefined8 *)(iVar3 + 0x2c0 + iVar5 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229666;
        fcn.180224990(uVar1, 0x1804bf6a0, 0x42);
        if ((in_R8 == (char *)0x0) || (*in_R8 == '\0')) {
            *(undefined8 *)(iVar3 + 0x2c0 + iVar5 * 8) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229678;
            func_0x000180498cd0(in_R8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229686;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(int64_t *)(iVar3 + 0x2c0 + iVar5 * 8) = iVar4;
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022969e;
                func_0x0001804990c0(iVar4, in_R8);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802296b1
// Address: 0x1802296b1
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1802295a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    undefined4 in_EDX;
    undefined8 unaff_RBP;
    int64_t iVar5;
    char *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802295bb;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802295cc;
    iVar3 = func_0x000180221280();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
        iVar5 = (int64_t)*(int32_t *)(iVar3 + 0x340);
        uVar1 = *(undefined8 *)(iVar3 + 0x200 + iVar5 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802295fe;
        fcn.180224990(uVar1, 0x1804bf6a0, 0x39);
        if ((in_RCX == (char *)0x0) || (*in_RCX == '\0')) {
            *(undefined8 *)(iVar3 + 0x200 + iVar5 * 8) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229610;
            func_0x000180498cd0(in_RCX);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022961e;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(int64_t *)(iVar3 + 0x200 + iVar5 * 8) = iVar4;
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229636;
                func_0x0001804990c0(iVar4, in_RCX);
            }
        }
        *(undefined4 *)(iVar3 + 0x280 + iVar5 * 4) = in_EDX;
        uVar1 = *(undefined8 *)(iVar3 + 0x2c0 + iVar5 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229666;
        fcn.180224990(uVar1, 0x1804bf6a0, 0x42);
        if ((in_R8 == (char *)0x0) || (*in_R8 == '\0')) {
            *(undefined8 *)(iVar3 + 0x2c0 + iVar5 * 8) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229678;
            func_0x000180498cd0(in_R8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229686;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(int64_t *)(iVar3 + 0x2c0 + iVar5 * 8) = iVar4;
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022969e;
                func_0x0001804990c0(iVar4, in_R8);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802296d0
// Address: 0x1802296d0
// Size: 38 bytes
// ============================================================
void fcn.1802296d0(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802296e4;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802296f1;
    fcn.180229700(*(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1));
    return;
}

// ============================================================
// Function: FUN_180229700
// Address: 0x180229700
// Size: 505 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180229700(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    uint32_t in_EDX;
    undefined4 uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    int64_t in_R8;
    undefined8 in_R9;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uVar10 = (uint32_t)arg1;
    uStack_30 = 0x180229726;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
    iVar12 = 0;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180229744;
    iVar5 = func_0x000180221280();
    if (iVar5 == 0) {
        return;
    }
    iVar11 = iVar12;
    if (in_R8 == 0) goto code_r0x000180229826;
    iVar6 = (int64_t)*(int32_t *)(iVar5 + 0x340);
    uVar9 = *(uint64_t *)(iVar5 + 0x140 + iVar6 * 8);
    iVar11 = *(int64_t *)(iVar5 + 0xc0 + iVar6 * 8);
    *(undefined8 *)(iVar5 + 0xc0 + iVar6 * 8) = 0;
    *(undefined4 *)(iVar5 + 0x1c0 + iVar6 * 4) = 0;
    if (uVar9 < 0x400) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802297a3;
        iVar6 = func_0x0001802249c0(iVar11, 0x400, 0x1804c07e0, 0x54);
        if (iVar6 == 0) goto code_r0x0001802297b2;
        uVar9 = 0x400;
        iVar11 = iVar6;
code_r0x0001802297b7:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802297c8;
        iVar3 = func_0x0001802460e0(iVar11, uVar9, in_R8, in_R9);
        iVar7 = 0;
        if (-1 < iVar3) {
            iVar7 = iVar3;
        }
        iVar12 = (int64_t)iVar7;
        *(undefined *)(iVar11 + iVar12) = 0;
    } else {
code_r0x0001802297b2:
        if (iVar11 != 0) goto code_r0x0001802297b7;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802297f8;
    iVar6 = func_0x0001802249c0(iVar11, iVar12 + 1U, 0x1804c07e0, 0x67);
    if (iVar6 == 0) {
        if (iVar11 == 0) {
            uVar8 = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar4);
        } else {
            uVar8 = 3;
        }
    } else {
        *(undefined *)(iVar12 + iVar6) = 0;
        uVar8 = 3;
        uVar9 = iVar12 + 1U;
        iVar11 = iVar6;
    }
    uVar10 = *(uint32_t *)((int64_t)&arg_38h + iVar4);
code_r0x000180229826:
    iVar12 = (int64_t)*(int32_t *)(iVar5 + 0x340);
    if ((*(uint8_t *)(iVar5 + 0x1c0 + iVar12 * 4) & 1) == 0) {
        *(undefined8 *)(iVar5 + 0xc0 + iVar12 * 8) = 0;
        *(undefined8 *)(iVar5 + 0x140 + iVar12 * 8) = 0;
        *(undefined4 *)(iVar5 + 0x1c0 + iVar12 * 4) = 0;
    } else {
        puVar1 = *(undefined **)(iVar5 + 0xc0 + iVar12 * 8);
        if (puVar1 != (undefined *)0x0) {
            *puVar1 = 0;
            *(undefined4 *)(iVar5 + 0x1c0 + iVar12 * 4) = 1;
        }
    }
    if (uVar10 == 2) {
        in_EDX = in_EDX | 0x80000000;
    } else {
        in_EDX = in_EDX & 0x7fffff | (uVar10 & 0xff) << 0x17;
    }
    *(uint32_t *)(iVar5 + 0x80 + (int64_t)*(int32_t *)(iVar5 + 0x340) * 4) = in_EDX;
    if (in_R8 != 0) {
        iVar12 = (int64_t)*(int32_t *)(iVar5 + 0x340);
        if ((*(uint8_t *)(iVar5 + 0x1c0 + iVar12 * 4) & 1) != 0) {
            uVar2 = *(undefined8 *)(iVar5 + 0xc0 + iVar12 * 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802298c5;
            fcn.180224990(uVar2, 0x1804bf6a0, 0x4e);
        }
        *(int64_t *)(iVar5 + 0xc0 + iVar12 * 8) = iVar11;
        *(uint64_t *)(iVar5 + 0x140 + iVar12 * 8) = uVar9;
        *(undefined4 *)(iVar5 + 0x1c0 + iVar12 * 4) = uVar8;
    }
    return;
}

// ============================================================
// Function: FUN_180229900
// Address: 0x180229900
// Size: 109 bytes
// ============================================================
undefined8 fcn.180229900(void)
{
    int32_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022990a;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x180229912;
    iVar2 = func_0x000180221280();
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)(iVar2 + 0x340);
        uVar4 = (uint64_t)iVar3;
        uVar5 = uVar4;
        while (((int64_t)*(int32_t *)(iVar2 + 0x344) != uVar4 &&
               (iVar3 = (int32_t)uVar5, *(int32_t *)(iVar2 + 0x40 + uVar4 * 4) == 0))) {
            if ((int64_t)uVar4 < 1) {
                uVar5 = 0xf;
                uVar4 = 0xf;
            } else {
                uVar5 = (uint64_t)(iVar3 - 1);
                uVar4 = uVar4 - 1;
            }
            iVar3 = (int32_t)uVar5;
        }
        if (*(int32_t *)(iVar2 + 0x344) != iVar3) {
            piVar1 = (int32_t *)(iVar2 + 0x40 + (int64_t)iVar3 * 4);
            *piVar1 = *piVar1 + -1;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180229970
// Address: 0x180229970
// Size: 92 bytes
// ============================================================
int32_t fcn.180229970(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022997c;
    iVar1 = fcn.18045a350();
    iVar3 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180229986;
    iVar1 = fcn.180221280(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
    if (iVar1 == 0) {
        return 0;
    }
    iVar2 = (int64_t)*(int32_t *)(iVar1 + 0x340);
    while ((*(int32_t *)(iVar1 + 0x344) != iVar2 && (*(int32_t *)(iVar1 + 0x40 + iVar2 * 4) == 0))) {
        iVar3 = iVar3 + 1;
        if (iVar2 < 1) {
            iVar2 = 0xf;
        } else {
            iVar2 = iVar2 + -1;
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1802299d0
// Address: 0x1802299d0
// Size: 52 bytes
// ============================================================
undefined8 fcn.1802299d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802299dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802299e4;
    iVar6 = fcn.180221280(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    if (iVar6 != 0) {
        iVar7 = *(int32_t *)(iVar6 + 0x344);
        iVar4 = *(int32_t *)(iVar6 + 0x340);
        if (iVar7 != iVar4) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            do {
                iVar8 = (int64_t)iVar4;
                if (*(int32_t *)(iVar6 + 0x40 + iVar8 * 4) != 0) break;
                if ((*(uint8_t *)(iVar6 + 0x1c0 + iVar8 * 4) & 1) == 0) {
                    *(undefined8 *)(iVar6 + 0xc0 + iVar8 * 8) = 0;
                    *(undefined8 *)(iVar6 + 0x140 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 0;
                } else {
                    puVar2 = *(undefined **)(iVar6 + 0xc0 + iVar8 * 8);
                    if (puVar2 != (undefined *)0x0) {
                        *puVar2 = 0;
                        *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 1;
                    }
                }
                *(undefined4 *)(iVar6 + 0x40 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + 0x80 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + 0x280 + iVar8 * 4) = 0xffffffff;
                uVar3 = *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229a8e;
                fcn.180224990(uVar3, 0x1804bf6a0, 0x5b);
                uVar3 = *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8);
                *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229ab0;
                fcn.180224990(uVar3, 0x1804bf6a0, 0x5d);
                *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8) = 0;
                if (*(int32_t *)(iVar6 + 0x340) < 1) {
                    iVar4 = 0xf;
                } else {
                    iVar4 = *(int32_t *)(iVar6 + 0x340) + -1;
                }
                *(int32_t *)(iVar6 + 0x340) = iVar4;
                iVar7 = *(int32_t *)(iVar6 + 0x344);
            } while (iVar7 != iVar4);
            if (iVar7 != iVar4) {
                piVar1 = (int32_t *)(iVar6 + 0x40 + (int64_t)iVar4 * 4);
                *piVar1 = *piVar1 + -1;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180229a04
// Address: 0x180229a04
// Size: 233 bytes
// ============================================================
undefined8 fcn.1802299d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802299dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802299e4;
    iVar6 = fcn.180221280(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    if (iVar6 != 0) {
        iVar7 = *(int32_t *)(iVar6 + 0x344);
        iVar4 = *(int32_t *)(iVar6 + 0x340);
        if (iVar7 != iVar4) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            do {
                iVar8 = (int64_t)iVar4;
                if (*(int32_t *)(iVar6 + 0x40 + iVar8 * 4) != 0) break;
                if ((*(uint8_t *)(iVar6 + 0x1c0 + iVar8 * 4) & 1) == 0) {
                    *(undefined8 *)(iVar6 + 0xc0 + iVar8 * 8) = 0;
                    *(undefined8 *)(iVar6 + 0x140 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 0;
                } else {
                    puVar2 = *(undefined **)(iVar6 + 0xc0 + iVar8 * 8);
                    if (puVar2 != (undefined *)0x0) {
                        *puVar2 = 0;
                        *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 1;
                    }
                }
                *(undefined4 *)(iVar6 + 0x40 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + 0x80 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + 0x280 + iVar8 * 4) = 0xffffffff;
                uVar3 = *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229a8e;
                fcn.180224990(uVar3, 0x1804bf6a0, 0x5b);
                uVar3 = *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8);
                *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229ab0;
                fcn.180224990(uVar3, 0x1804bf6a0, 0x5d);
                *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8) = 0;
                if (*(int32_t *)(iVar6 + 0x340) < 1) {
                    iVar4 = 0xf;
                } else {
                    iVar4 = *(int32_t *)(iVar6 + 0x340) + -1;
                }
                *(int32_t *)(iVar6 + 0x340) = iVar4;
                iVar7 = *(int32_t *)(iVar6 + 0x344);
            } while (iVar7 != iVar4);
            if (iVar7 != iVar4) {
                piVar1 = (int32_t *)(iVar6 + 0x40 + (int64_t)iVar4 * 4);
                *piVar1 = *piVar1 + -1;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180229aed
// Address: 0x180229aed
// Size: 26 bytes
// ============================================================
undefined8 fcn.1802299d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar8;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802299dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802299e4;
    iVar6 = fcn.180221280(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    if (iVar6 != 0) {
        iVar7 = *(int32_t *)(iVar6 + 0x344);
        iVar4 = *(int32_t *)(iVar6 + 0x340);
        if (iVar7 != iVar4) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
            do {
                iVar8 = (int64_t)iVar4;
                if (*(int32_t *)(iVar6 + 0x40 + iVar8 * 4) != 0) break;
                if ((*(uint8_t *)(iVar6 + 0x1c0 + iVar8 * 4) & 1) == 0) {
                    *(undefined8 *)(iVar6 + 0xc0 + iVar8 * 8) = 0;
                    *(undefined8 *)(iVar6 + 0x140 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 0;
                } else {
                    puVar2 = *(undefined **)(iVar6 + 0xc0 + iVar8 * 8);
                    if (puVar2 != (undefined *)0x0) {
                        *puVar2 = 0;
                        *(undefined4 *)(iVar6 + 0x1c0 + iVar8 * 4) = 1;
                    }
                }
                *(undefined4 *)(iVar6 + 0x40 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + 0x80 + iVar8 * 4) = 0;
                *(undefined4 *)(iVar6 + 0x280 + iVar8 * 4) = 0xffffffff;
                uVar3 = *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229a8e;
                fcn.180224990(uVar3, 0x1804bf6a0, 0x5b);
                uVar3 = *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8);
                *(undefined8 *)(iVar6 + 0x200 + iVar8 * 8) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180229ab0;
                fcn.180224990(uVar3, 0x1804bf6a0, 0x5d);
                *(undefined8 *)(iVar6 + 0x2c0 + iVar8 * 8) = 0;
                if (*(int32_t *)(iVar6 + 0x340) < 1) {
                    iVar4 = 0xf;
                } else {
                    iVar4 = *(int32_t *)(iVar6 + 0x340) + -1;
                }
                *(int32_t *)(iVar6 + 0x340) = iVar4;
                iVar7 = *(int32_t *)(iVar6 + 0x344);
            } while (iVar7 != iVar4);
            if (iVar7 != iVar4) {
                piVar1 = (int32_t *)(iVar6 + 0x40 + (int64_t)iVar4 * 4);
                *piVar1 = *piVar1 + -1;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180229b10
// Address: 0x180229b10
// Size: 59 bytes
// ============================================================
undefined8 fcn.180229b10(void)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180229b1a;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x180229b22;
    iVar2 = fcn.180221280(*(int64_t *)((int64_t)&iStackX_20 + -iVar2));
    if ((iVar2 != 0) && (*(int32_t *)(iVar2 + 0x344) != *(int32_t *)(iVar2 + 0x340))) {
        piVar1 = (int32_t *)(iVar2 + 0x40 + (int64_t)*(int32_t *)(iVar2 + 0x340) * 4);
        *piVar1 = *piVar1 + 1;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180229b50
// Address: 0x180229b50
// Size: 79 bytes
// ============================================================
undefined4 * fcn.180229b50(undefined4 *param_1, undefined8 param_2, undefined8 param_3, undefined8 param_4)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00000000 + iVar9) = param_2;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 2;
    uVar2 = *(undefined4 *)(&stack0x00000004 + iVar9);
    uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_8h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = param_3;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = param_4;
    uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&var_18h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0xffffffffffffffff;
    *param_1 = *(undefined4 *)(&stack0x00000000 + iVar9);
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&var_20h + iVar9);
    param_1[4] = uVar5;
    param_1[5] = uVar6;
    param_1[6] = uVar7;
    param_1[7] = uVar8;
    *(undefined8 *)(param_1 + 8) = uVar1;
    return param_1;
}

// ============================================================
// Function: FUN_180229bc0
// Address: 0x180229bc0
// Size: 83 bytes
// ============================================================
undefined4 * fcn.180229bc0(undefined4 *param_1, undefined8 param_2, undefined8 param_3)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00000000 + iVar9) = param_2;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 1;
    uVar2 = *(undefined4 *)(&stack0x00000004 + iVar9);
    uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_8h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = param_3;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = 4;
    uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&var_18h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0xffffffffffffffff;
    *param_1 = *(undefined4 *)(&stack0x00000000 + iVar9);
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&var_20h + iVar9);
    param_1[4] = uVar5;
    param_1[5] = uVar6;
    param_1[6] = uVar7;
    param_1[7] = uVar8;
    *(undefined8 *)(param_1 + 8) = uVar1;
    return param_1;
}

// ============================================================
// Function: FUN_180229c20
// Address: 0x180229c20
// Size: 79 bytes
// ============================================================
undefined4 * fcn.180229c20(undefined4 *param_1, undefined8 param_2, undefined8 param_3, undefined8 param_4)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00000000 + iVar9) = param_2;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 7;
    uVar2 = *(undefined4 *)(&stack0x00000004 + iVar9);
    uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_8h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = param_3;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = param_4;
    uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&var_18h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0xffffffffffffffff;
    *param_1 = *(undefined4 *)(&stack0x00000000 + iVar9);
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&var_20h + iVar9);
    param_1[4] = uVar5;
    param_1[5] = uVar6;
    param_1[6] = uVar7;
    param_1[7] = uVar8;
    *(undefined8 *)(param_1 + 8) = uVar1;
    return param_1;
}

// ============================================================
// Function: FUN_180229c70
// Address: 0x180229c70
// Size: 79 bytes
// ============================================================
undefined4 * fcn.180229c70(undefined4 *param_1, undefined8 param_2, undefined8 param_3, undefined8 param_4)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00000000 + iVar9) = param_2;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 5;
    uVar2 = *(undefined4 *)(&stack0x00000004 + iVar9);
    uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_8h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = param_3;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = param_4;
    uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&var_18h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0xffffffffffffffff;
    *param_1 = *(undefined4 *)(&stack0x00000000 + iVar9);
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&var_20h + iVar9);
    param_1[4] = uVar5;
    param_1[5] = uVar6;
    param_1[6] = uVar7;
    param_1[7] = uVar8;
    *(undefined8 *)(param_1 + 8) = uVar1;
    return param_1;
}

// ============================================================
// Function: FUN_180229cc0
// Address: 0x180229cc0
// Size: 83 bytes
// ============================================================
undefined4 * fcn.180229cc0(undefined4 *param_1, undefined8 param_2, undefined8 param_3)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00000000 + iVar9) = param_2;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 2;
    uVar2 = *(undefined4 *)(&stack0x00000004 + iVar9);
    uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_8h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = param_3;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = 8;
    uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&var_18h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0xffffffffffffffff;
    *param_1 = *(undefined4 *)(&stack0x00000000 + iVar9);
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&var_20h + iVar9);
    param_1[4] = uVar5;
    param_1[5] = uVar6;
    param_1[6] = uVar7;
    param_1[7] = uVar8;
    *(undefined8 *)(param_1 + 8) = uVar1;
    return param_1;
}

// ============================================================
// Function: FUN_180229d20
// Address: 0x180229d20
// Size: 83 bytes
// ============================================================
undefined4 * fcn.180229d20(undefined4 *param_1, undefined8 param_2, undefined8 param_3)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00000000 + iVar9) = param_2;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 1;
    uVar2 = *(undefined4 *)(&stack0x00000004 + iVar9);
    uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_8h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = param_3;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = 8;
    uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&var_18h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0xffffffffffffffff;
    *param_1 = *(undefined4 *)(&stack0x00000000 + iVar9);
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&var_20h + iVar9);
    param_1[4] = uVar5;
    param_1[5] = uVar6;
    param_1[6] = uVar7;
    param_1[7] = uVar8;
    *(undefined8 *)(param_1 + 8) = uVar1;
    return param_1;
}

// ============================================================
// Function: FUN_180229d80
// Address: 0x180229d80
// Size: 83 bytes
// ============================================================
undefined4 * fcn.180229d80(undefined4 *param_1, undefined8 param_2, undefined8 param_3)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00000000 + iVar9) = param_2;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 2;
    uVar2 = *(undefined4 *)(&stack0x00000004 + iVar9);
    uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_8h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = param_3;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = 4;
    uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&var_18h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0xffffffffffffffff;
    *param_1 = *(undefined4 *)(&stack0x00000000 + iVar9);
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&var_20h + iVar9);
    param_1[4] = uVar5;
    param_1[5] = uVar6;
    param_1[6] = uVar7;
    param_1[7] = uVar8;
    *(undefined8 *)(param_1 + 8) = uVar1;
    return param_1;
}

// ============================================================
// Function: FUN_180229de0
// Address: 0x180229de0
// Size: 79 bytes
// ============================================================
undefined4 * fcn.180229de0(undefined4 *param_1, undefined8 param_2, undefined8 param_3, undefined8 param_4)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(&stack0x00000000 + iVar9) = param_2;
    *(undefined4 *)((int64_t)&var_8h + iVar9) = 6;
    uVar2 = *(undefined4 *)(&stack0x00000004 + iVar9);
    uVar3 = *(undefined4 *)((int64_t)&var_8h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_8h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_10h + iVar9) = param_3;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = param_4;
    uVar5 = *(undefined4 *)((int64_t)&var_10h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&var_10h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&var_18h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = 0xffffffffffffffff;
    *param_1 = *(undefined4 *)(&stack0x00000000 + iVar9);
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&var_20h + iVar9);
    param_1[4] = uVar5;
    param_1[5] = uVar6;
    param_1[6] = uVar7;
    param_1[7] = uVar8;
    *(undefined8 *)(param_1 + 8) = uVar1;
    return param_1;
}

// ============================================================
// Function: FUN_180229e30
// Address: 0x180229e30
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.180229e30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180229e45;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if ((in_R8 != 0) && (in_R9 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x180229e66;
        in_R9 = fcn.180498cd0(in_R8);
    }
    *(undefined8 *)((int64_t)&var_18h + iVar9) = in_RDX;
    *(int64_t *)((int64_t)&arg_30h + iVar9) = in_R9;
    *(undefined4 *)((int64_t)&var_20h + iVar9) = 4;
    uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
    uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar9);
    uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
    *(int64_t *)((int64_t)&arg_28h + iVar9) = in_R8;
    uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar9);
    uVar6 = *(undefined4 *)((int64_t)&arg_28h + iVar9 + 4);
    uVar7 = *(undefined4 *)((int64_t)&arg_30h + iVar9);
    uVar8 = *(undefined4 *)((int64_t)&arg_30h + iVar9 + 4);
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = 0xffffffffffffffff;
    *in_RCX = *(undefined4 *)((int64_t)&var_18h + iVar9);
    in_RCX[1] = uVar2;
    in_RCX[2] = uVar3;
    in_RCX[3] = uVar4;
    uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar9);
    in_RCX[4] = uVar5;
    in_RCX[5] = uVar6;
    in_RCX[6] = uVar7;
    in_RCX[7] = uVar8;
    *(undefined8 *)(in_RCX + 8) = uVar1;
    return in_RCX;
}

// ============================================================
// Function: FUN_180229ec0
// Address: 0x180229ec0
// Size: 251 bytes
// ============================================================
undefined8 fcn.180229ec0(int64_t param_1, int64_t *param_2, undefined8 param_3, int64_t param_4)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 placeholder_1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180229ecc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((param_2 == (int64_t *)0x0) || (param_1 == 0)) || (param_4 = *(int64_t *)(param_1 + 0x10), param_4 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229f89;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229fa1;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        placeholder_1 = 0xc0102;
        goto code_r0x000180229fa6;
    }
    if (*(int32_t *)(param_1 + 8) == 1) {
        uVar1 = *(undefined4 *)(param_1 + 0x18);
        iVar3 = *param_2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229f4d;
        iVar3 = func_0x000180255910(param_4, uVar1, iVar3);
code_r0x000180229f4d:
        if (iVar3 != 0) {
            *param_2 = iVar3;
            return 1;
        }
    } else {
        if (*(int32_t *)(param_1 + 8) == 2) {
            uVar1 = *(undefined4 *)(param_1 + 0x18);
            iVar3 = *param_2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229f3d;
            iVar3 = func_0x000180255400(param_4, uVar1, iVar3);
            goto code_r0x000180229f4d;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229f03;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229f1b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229f2d;
        fcn.1802296d0(0xf, 0x81, 0, param_4, *(int64_t *)(&stack0x00000038 + iVar2));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229f57;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229f6f;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    placeholder_1 = 0x80003;
code_r0x000180229fa6:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180229fb3;
    fcn.1802296d0(0xf, placeholder_1, 0, param_4, *(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180229fc0
// Address: 0x180229fc0
// Size: 22 bytes
// ============================================================
undefined8 fcn.180229fc0(int64_t arg_70h, int64_t arg_78h)
{
    double *pdVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    double dVar9;
    int32_t *in_RDX;
    undefined8 uVar10;
    int64_t in_R9;
    undefined8 uStackX_20;
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar6) = 0x180229fea;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if ((in_RDX == (int32_t *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1be;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
    } else {
        pdVar1 = *(double **)(in_RCX + 0x10);
        if (pdVar1 != (double *)0x0) {
            iVar5 = *(int32_t *)(in_RCX + 8);
            if (iVar5 == 1) {
                if (*(int64_t *)(in_RCX + 0x18) == 4) {
                    iVar5 = *(int32_t *)pdVar1;
code_r0x00018022a09e:
                    *in_RDX = iVar5;
                    return 1;
                }
                if (*(int64_t *)(in_RCX + 0x18) != 8) {
code_r0x00018022a035:
                    uVar10 = 4;
                    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar6) = 0x18022be2a;
                    iVar8 = fcn.18045a350();
                    iVar8 = -iVar8;
                    iVar2 = *(int64_t *)(in_RCX + 0x10);
                    if (iVar2 == 0) {
                        *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022be41;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6));
                        *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022be59;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000080 + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000088 + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x000000a0 + iVar8 + iVar7 + iVar6));
                        *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022be6b;
                        fcn.1802296d0(0xf, 0xc0102, 0, in_R9, *(int64_t *)(&stack0x00000090 + iVar8 + iVar7 + iVar6));
                        return 0;
                    }
                    if (*(int32_t *)(in_RCX + 8) != 1) {
                        if (*(int32_t *)(in_RCX + 8) != 2) {
                            *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022bece;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022bee6;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000080 + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000088 + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x000000a0 + iVar8 + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022bef8;
                            fcn.1802296d0(0xf, 0x7c, 0, in_R9, *(int64_t *)(&stack0x00000090 + iVar8 + iVar7 + iVar6));
                            return 0;
                        }
                        uVar4 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6) = 1;
                        *(undefined *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6) = 0;
                        *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022bec4;
                        uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar2, uVar4);
                        return uVar10;
                    }
                    iVar3 = *(int64_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6) = 1;
                    *(char *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6) = *(char *)(iVar3 + -1 + iVar2) >> 7;
                    *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022be9e;
                    uVar10 = func_0x00018022bd50(in_RDX, uVar10);
                    return uVar10;
                }
                dVar9 = *pdVar1;
                if ((int64_t)dVar9 + 0x80000000U < 0x100000000) goto code_r0x00018022a05a;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a06b;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
            } else {
                if (iVar5 == 2) {
                    if (*(int64_t *)(in_RCX + 0x18) == 4) {
                        dVar9 = (double)(uint64_t)*(uint32_t *)pdVar1;
                        if (0x7fffffff < *(uint32_t *)pdVar1) {
                            *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a0ef;
                            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                            goto code_r0x00018022a070;
                        }
                    } else {
                        if (*(int64_t *)(in_RCX + 0x18) != 8) goto code_r0x00018022a035;
                        dVar9 = *pdVar1;
                        if (0x7fffffff < (uint64_t)dVar9) {
                            *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a0d5;
                            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                            goto code_r0x00018022a070;
                        }
                    }
code_r0x00018022a05a:
                    *in_RDX = SUB84(dVar9, 0);
                    return 1;
                }
                if (iVar5 != 3) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a188;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1a0;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1b2;
                    fcn.1802296d0(0xf, 0x81, 0, in_R9, *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
                    return 0;
                }
                if (*(int64_t *)(in_RCX + 0x18) != 8) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a10f;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a127;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a139;
                    fcn.1802296d0(0xf, 0x82, 0, in_R9, *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
                    return 0;
                }
                dVar9 = *pdVar1;
                if (((-2147483648.0 <= dVar9) && (dVar9 <= 2147483647.0)) &&
                   (iVar5 = (int32_t)dVar9, dVar9 == (double)iVar5)) goto code_r0x00018022a09e;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a179;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
            }
code_r0x00018022a070:
            *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a083;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), *(int64_t *)(&stack0x00000050 + iVar7 + iVar6)
                          , *(int64_t *)(&stack0x00000058 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a095;
            fcn.1802296d0(0xf, 0x7e, 0, in_R9, *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a00d;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1d6;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), *(int64_t *)(&stack0x00000050 + iVar7 + iVar6), 
                  *(int64_t *)(&stack0x00000058 + iVar7 + iVar6), *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1e8;
    fcn.1802296d0(0xf, 0xc0102, 0, in_R9, *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_180229fe0
// Address: 0x180229fe0
// Size: 527 bytes
// ============================================================
undefined8 fcn.180229fc0(int64_t arg_70h, int64_t arg_78h)
{
    double *pdVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    double dVar9;
    int32_t *in_RDX;
    undefined8 uVar10;
    int64_t in_R9;
    undefined8 uStackX_20;
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar6) = 0x180229fea;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if ((in_RDX == (int32_t *)0x0) || (in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1be;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
    } else {
        pdVar1 = *(double **)(in_RCX + 0x10);
        if (pdVar1 != (double *)0x0) {
            iVar5 = *(int32_t *)(in_RCX + 8);
            if (iVar5 == 1) {
                if (*(int64_t *)(in_RCX + 0x18) == 4) {
                    iVar5 = *(int32_t *)pdVar1;
code_r0x00018022a09e:
                    *in_RDX = iVar5;
                    return 1;
                }
                if (*(int64_t *)(in_RCX + 0x18) != 8) {
code_r0x00018022a035:
                    uVar10 = 4;
                    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar6) = 0x18022be2a;
                    iVar8 = fcn.18045a350();
                    iVar8 = -iVar8;
                    iVar2 = *(int64_t *)(in_RCX + 0x10);
                    if (iVar2 == 0) {
                        *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022be41;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6));
                        *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022be59;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000080 + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000088 + iVar8 + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x000000a0 + iVar8 + iVar7 + iVar6));
                        *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022be6b;
                        fcn.1802296d0(0xf, 0xc0102, 0, in_R9, *(int64_t *)(&stack0x00000090 + iVar8 + iVar7 + iVar6));
                        return 0;
                    }
                    if (*(int32_t *)(in_RCX + 8) != 1) {
                        if (*(int32_t *)(in_RCX + 8) != 2) {
                            *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022bece;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022bee6;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000080 + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000088 + iVar8 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x000000a0 + iVar8 + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022bef8;
                            fcn.1802296d0(0xf, 0x7c, 0, in_R9, *(int64_t *)(&stack0x00000090 + iVar8 + iVar7 + iVar6));
                            return 0;
                        }
                        uVar4 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6) = 1;
                        *(undefined *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6) = 0;
                        *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022bec4;
                        uVar10 = func_0x00018022bd50(in_RDX, uVar10, iVar2, uVar4);
                        return uVar10;
                    }
                    iVar3 = *(int64_t *)(in_RCX + 0x18);
                    *(undefined4 *)((int64_t)&arg_78h + iVar8 + iVar7 + iVar6) = 1;
                    *(char *)((int64_t)&arg_70h + iVar8 + iVar7 + iVar6) = *(char *)(iVar3 + -1 + iVar2) >> 7;
                    *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + iVar6) = 0x18022be9e;
                    uVar10 = func_0x00018022bd50(in_RDX, uVar10);
                    return uVar10;
                }
                dVar9 = *pdVar1;
                if ((int64_t)dVar9 + 0x80000000U < 0x100000000) goto code_r0x00018022a05a;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a06b;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
            } else {
                if (iVar5 == 2) {
                    if (*(int64_t *)(in_RCX + 0x18) == 4) {
                        dVar9 = (double)(uint64_t)*(uint32_t *)pdVar1;
                        if (0x7fffffff < *(uint32_t *)pdVar1) {
                            *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a0ef;
                            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                            goto code_r0x00018022a070;
                        }
                    } else {
                        if (*(int64_t *)(in_RCX + 0x18) != 8) goto code_r0x00018022a035;
                        dVar9 = *pdVar1;
                        if (0x7fffffff < (uint64_t)dVar9) {
                            *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a0d5;
                            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                            goto code_r0x00018022a070;
                        }
                    }
code_r0x00018022a05a:
                    *in_RDX = SUB84(dVar9, 0);
                    return 1;
                }
                if (iVar5 != 3) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a188;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1a0;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1b2;
                    fcn.1802296d0(0xf, 0x81, 0, in_R9, *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
                    return 0;
                }
                if (*(int64_t *)(in_RCX + 0x18) != 8) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a10f;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a127;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000050 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a139;
                    fcn.1802296d0(0xf, 0x82, 0, in_R9, *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
                    return 0;
                }
                dVar9 = *pdVar1;
                if (((-2147483648.0 <= dVar9) && (dVar9 <= 2147483647.0)) &&
                   (iVar5 = (int32_t)dVar9, dVar9 == (double)iVar5)) goto code_r0x00018022a09e;
                *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a179;
                fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                              *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
            }
code_r0x00018022a070:
            *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a083;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), *(int64_t *)(&stack0x00000050 + iVar7 + iVar6)
                          , *(int64_t *)(&stack0x00000058 + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a095;
            fcn.1802296d0(0xf, 0x7e, 0, in_R9, *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a00d;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), *(int64_t *)(&stack0x00000050 + iVar7 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1d6;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6), *(int64_t *)(&stack0x00000050 + iVar7 + iVar6), 
                  *(int64_t *)(&stack0x00000058 + iVar7 + iVar6), *(int64_t *)(&stack0x00000060 + iVar7 + iVar6), 
                  *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar6));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + iVar6) = 0x18022a1e8;
    fcn.1802296d0(0xf, 0xc0102, 0, in_R9, *(int64_t *)(&stack0x00000068 + iVar7 + iVar6));
    return 0;
}

