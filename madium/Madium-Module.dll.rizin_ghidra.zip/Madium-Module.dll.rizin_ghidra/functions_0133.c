// Chunk 133 - 50 functions

// ============================================================
// Function: FUN_1801c6a40
// Address: 0x1801c6a40
// Size: 107 bytes
// ============================================================
void fcn.1801c6a40(int64_t arg_60h)
{
    undefined uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined8 unaff_RBX;
    uint64_t uVar5;
    undefined *puVar6;
    undefined8 unaff_RBP;
    undefined *puVar7;
    undefined8 unaff_RSI;
    undefined *puVar8;
    undefined8 unaff_RDI;
    int64_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined *puVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined *puVar11;
    undefined8 uStack_478;
    undefined auStack_470 [32];
    int64_t aiStack_450 [2];
    int64_t var_440h;
    int64_t var_420h;
    int64_t var_410h;
    undefined8 auStack_250 [6];
    int64_t var_220h;
    uint64_t auStack_60 [6];
    int64_t var_30h;
    undefined8 auStack_28 [2];
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    var_8h = 0x1801c6a4a;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = 0x1801c6a6b;
    *(undefined8 *)((int64_t)&var_10h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_28 + iVar3 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_28 + iVar3) = unaff_R15;
    *(uint64_t *)((int64_t)auStack_60 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(auStack_470 + iVar3);
    *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f12e;
    func_0x000180483e04(0x1801c31d0);
    *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f140;
    func_0x0001804986e0((int64_t)&var_440h + iVar3, 0, 0x1f0);
    *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f155;
    func_0x0001804986e0((int64_t)auStack_250 + iVar3, 0, 0x1f0);
    *(undefined8 *)((int64_t)auStack_28 + iVar3 + -8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStack_60 + iVar3 + 0x28) = unaff_RBP;
    *(undefined8 *)((int64_t)auStack_60 + iVar3 + 0x20) = unaff_RSI;
    iVar9 = 0;
    *(undefined8 *)((int64_t)auStack_60 + iVar3 + 0x18) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStack_450 + iVar3) = 0;
    puVar10 = (undefined *)0x18069c690;
    puVar11 = (undefined *)0x18069c870;
code_r0x00018046f190:
    while (uVar5 = (uint64_t)((int64_t)puVar11 - (int64_t)puVar10) / 0x50 + 1, 8 < uVar5) {
        uVar5 = uVar5 >> 1;
        puVar7 = puVar10 + uVar5 * 0x50;
        *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f248;
        iVar2 = (*(code *)0x1801c31d0)(puVar10, puVar7);
        if ((0 < iVar2) && (iVar9 = 0x50, puVar6 = puVar7, puVar10 != puVar7)) {
            do {
                uVar1 = puVar6[uVar5 * -0x50];
                puVar6[uVar5 * -0x50] = *puVar6;
                *puVar6 = uVar1;
                iVar9 = iVar9 + -1;
                puVar6 = puVar6 + 1;
            } while (iVar9 != 0);
        }
        *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f284;
        iVar2 = (*(code *)0x1801c31d0)(puVar10, puVar11);
        if ((0 < iVar2) && (iVar9 = 0x50, puVar10 != puVar11)) {
            puVar6 = puVar11;
            do {
                uVar1 = puVar6[(int64_t)puVar10 - (int64_t)puVar11];
                puVar6[(int64_t)puVar10 - (int64_t)puVar11] = *puVar6;
                *puVar6 = uVar1;
                puVar6 = puVar6 + 1;
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
        }
        *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f2c1;
        iVar2 = (*(code *)0x1801c31d0)(puVar7);
        puVar6 = puVar10;
        puVar8 = puVar11;
        if ((0 < iVar2) && (iVar9 = 0x50, puVar7 != puVar11)) {
            puVar4 = puVar11;
            do {
                uVar1 = puVar4[(int64_t)puVar7 - (int64_t)puVar11];
                puVar4[(int64_t)puVar7 - (int64_t)puVar11] = *puVar4;
                *puVar4 = uVar1;
                puVar4 = puVar4 + 1;
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
        }
code_r0x00018046f300:
        puVar4 = puVar7;
        if (puVar6 < puVar4) {
            do {
                puVar6 = puVar6 + 0x50;
                if (puVar4 <= puVar6) goto code_r0x00018046f320;
                *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f316;
                iVar2 = (*(code *)0x1801c31d0)(puVar6);
            } while (iVar2 < 1);
        } else {
code_r0x00018046f320:
            do {
                puVar6 = puVar6 + 0x50;
                if (puVar11 < puVar6) break;
                *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f331;
                iVar2 = (*(code *)0x1801c31d0)(puVar6);
            } while (iVar2 < 1);
        }
        do {
            puVar7 = puVar8;
            puVar8 = puVar7 + -0x50;
            if (puVar8 <= puVar4) break;
            *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f349;
            iVar2 = (*(code *)0x1801c31d0)(puVar8);
        } while (0 < iVar2);
        if (puVar6 <= puVar8) {
            iVar9 = 0x50;
            if (puVar8 != puVar6) {
                puVar7 = puVar8;
                do {
                    uVar1 = puVar7[(int64_t)puVar6 - (int64_t)puVar8];
                    puVar7[(int64_t)puVar6 - (int64_t)puVar8] = *puVar7;
                    *puVar7 = uVar1;
                    puVar7 = puVar7 + 1;
                    iVar9 = iVar9 + -1;
                } while (iVar9 != 0);
            }
            puVar7 = puVar6;
            if (puVar4 != puVar8) {
                puVar7 = puVar4;
            }
            goto code_r0x00018046f300;
        }
        if (puVar4 < puVar7) {
            do {
                puVar7 = puVar7 + -0x50;
                if (puVar7 <= puVar4) goto code_r0x00018046f3a7;
                *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f3a1;
                iVar2 = (*(code *)0x1801c31d0)(puVar7);
            } while (iVar2 == 0);
        } else {
code_r0x00018046f3a7:
            do {
                puVar7 = puVar7 + -0x50;
                if (puVar7 <= puVar10) break;
                *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f3b8;
                iVar2 = (*(code *)0x1801c31d0)(puVar7);
            } while (iVar2 == 0);
        }
        iVar9 = *(int64_t *)((int64_t)aiStack_450 + iVar3);
        if ((int64_t)puVar7 - (int64_t)puVar10 < (int64_t)puVar11 - (int64_t)puVar6) goto code_r0x00018046f3fd;
        if (puVar10 < puVar7) {
            *(undefined **)((int64_t)&var_440h + iVar9 * 8 + iVar3) = puVar10;
            *(undefined **)((int64_t)auStack_250 + iVar9 * 8 + iVar3) = puVar7;
            iVar9 = iVar9 + 1;
            *(int64_t *)((int64_t)aiStack_450 + iVar3) = iVar9;
        }
        puVar10 = puVar6;
        if (puVar11 <= puVar6) goto code_r0x00018046f213;
    }
    puVar6 = puVar10;
    puVar7 = puVar10;
    if (puVar10 < puVar11) {
        do {
            while (puVar8 = puVar6, puVar7 = puVar7 + 0x50, puVar7 <= puVar11) {
                *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f1c9;
                iVar2 = (*(code *)0x1801c31d0)(puVar7, puVar8);
                puVar6 = puVar7;
                if (iVar2 < 1) {
                    puVar6 = puVar8;
                }
            }
            iVar9 = 0x50;
            if (puVar8 != puVar11) {
                puVar7 = puVar11;
                do {
                    uVar1 = puVar7[(int64_t)puVar8 - (int64_t)puVar11];
                    puVar7[(int64_t)puVar8 - (int64_t)puVar11] = *puVar7;
                    *puVar7 = uVar1;
                    puVar7 = puVar7 + 1;
                    iVar9 = iVar9 + -1;
                } while (iVar9 != 0);
            }
            puVar11 = puVar11 + -0x50;
            puVar6 = puVar10;
            puVar7 = puVar10;
        } while (puVar10 < puVar11);
        iVar9 = *(int64_t *)((int64_t)aiStack_450 + iVar3);
    }
    goto code_r0x00018046f213;
code_r0x00018046f3fd:
    if (puVar6 < puVar11) {
        *(undefined **)((int64_t)&var_440h + iVar9 * 8 + iVar3) = puVar6;
        *(undefined **)((int64_t)auStack_250 + iVar9 * 8 + iVar3) = puVar11;
        iVar9 = iVar9 + 1;
        *(int64_t *)((int64_t)aiStack_450 + iVar3) = iVar9;
    }
    puVar11 = puVar7;
    if (puVar7 <= puVar10) {
code_r0x00018046f213:
        iVar9 = iVar9 + -1;
        *(int64_t *)((int64_t)aiStack_450 + iVar3) = iVar9;
        if (iVar9 < 0) {
            *(undefined8 *)((int64_t)&uStack_478 + iVar3) = 0x18046f458;
            func_0x000180459870(*(uint64_t *)((int64_t)auStack_60 + iVar3) ^ (uint64_t)(auStack_470 + iVar3));
            return;
        }
        puVar10 = *(undefined **)((int64_t)&var_440h + iVar9 * 8 + iVar3);
        puVar11 = *(undefined **)((int64_t)auStack_250 + iVar9 * 8 + iVar3);
    }
    goto code_r0x00018046f190;
}

// ============================================================
// Function: FUN_1801c6ab0
// Address: 0x1801c6ab0
// Size: 417 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch

uint64_t fcn.1801c6ab0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h)
{
    int32_t *piVar1;
    undefined uVar2;
    undefined uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int32_t *piVar10;
    uint64_t uVar11;
    int32_t *in_RCX;
    undefined8 unaff_RBP;
    code *pcVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c6ac5;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    piVar10 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6aec;
        piVar10 = (int32_t *)func_0x0001801bda50();
        if (piVar10 == (int32_t *)0x0) {
            return 0xffffffff;
        }
    }
    if (*(int64_t *)(piVar10 + 0x31c) == 0) {
        piVar10[0x71] = 0;
        return 1;
    }
    *(undefined *)((int64_t)&arg_38h + iVar9) = 0x15;
    iVar6 = piVar10[0x12];
    if (iVar6 == 0x304) {
        iVar6 = 0x303;
    }
    *(int32_t *)((int64_t)&arg_38h + iVar9 + 4) = iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b43;
    iVar6 = func_0x00018019b210(in_RCX);
    if ((iVar6 == 0xd) && (piVar10[0x2e8] == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b59;
        uVar7 = func_0x000180194ed0(in_RCX);
        if ((uVar7 & 0xffffff00) == 0x300) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b6d;
            iVar6 = func_0x000180194ed0(in_RCX);
            if (0x301 < iVar6) {
                uVar8 = *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4);
                if (piVar10[0x232] == 0) {
                    uVar8 = 0x301;
                }
                *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4) = uVar8;
            }
        }
    }
    piVar1 = piVar10 + 0x72;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = 2;
    *(int32_t **)((int64_t)&arg_40h + iVar9) = piVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6ba9;
    iVar6 = func_0x0001801a31f0(piVar10 + 0x314);
    if (iVar6 != 0) {
        if (piVar10[0x71] == 2) {
            uVar4 = *(undefined8 *)(piVar10 + 800);
            pcVar12 = *(code **)(*(int64_t *)(piVar10 + 0x31c) + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6bee;
            uVar8 = (*pcVar12)(uVar4);
            *(undefined4 *)((int64_t)&var_18h + iVar9) = 0x77;
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c0d;
            iVar6 = func_0x0001801a32c0(piVar10, 1, uVar8, 0x1804b3148);
            if (0 < iVar6) {
                *(undefined8 *)(piVar10 + 0x32e) = 0;
                piVar10[0x71] = 0;
                return 1;
            }
        } else {
            piVar10[0x71] = 0;
        }
        return 0xffffffff;
    }
    iVar5 = *(int64_t *)(piVar10 + 0x31c);
    uVar4 = *(undefined8 *)(piVar10 + 800);
    *(undefined8 *)((int64_t)&arg_68h + iVar9) = unaff_RBP;
    pcVar12 = *(code **)(iVar5 + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c5d;
    uVar8 = (*pcVar12)(uVar4, (int64_t)&arg_38h + iVar9, 1);
    *(undefined4 *)((int64_t)&var_18h + iVar9) = 0x82;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c7c;
    uVar11 = func_0x0001801a32c0(piVar10, 1, uVar8, 0x1804b3148);
    if ((int32_t)uVar11 < 1) {
        piVar10[0x71] = 2;
        *(undefined8 *)(piVar10 + 0x32e) = *(undefined8 *)((int64_t)&arg_48h + iVar9);
        *(undefined *)(piVar10 + 0x330) = *(undefined *)((int64_t)&arg_38h + iVar9);
        *(undefined8 *)(piVar10 + 0x332) = *(undefined8 *)((int64_t)&arg_40h + iVar9);
        return uVar11;
    }
    uVar4 = *(undefined8 *)(piVar10 + 0x16);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6cdb;
    func_0x000180219d10(uVar4, 0xb, 0, 0);
    pcVar12 = *(code **)(piVar10 + 0x13e);
    piVar10[0x71] = 0;
    if (pcVar12 != (code *)0x0) {
        iVar6 = piVar10[0x12];
        *(undefined8 *)((int64_t)&arg_28h + iVar9) = *(undefined8 *)(piVar10 + 0x140);
        *(int32_t **)((int64_t)&var_20h + iVar9) = in_RCX;
        *(undefined8 *)((int64_t)&var_18h + iVar9) = 2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6d1d;
        (*pcVar12)(1, iVar6, 0x15, piVar1);
    }
    pcVar12 = *(code **)(piVar10 + 0x256);
    if ((pcVar12 != (code *)0x0) || (pcVar12 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120), pcVar12 != (code *)0x0)) {
        uVar2 = *(undefined *)piVar1;
        uVar3 = *(undefined *)((int64_t)piVar10 + 0x1c9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6d56;
        (*pcVar12)(in_RCX, 0x4008, CONCAT11(uVar2, uVar3));
    }
    return uVar11 & 0xffffffff;
}

// ============================================================
// Function: FUN_1801c6c51
// Address: 0x1801c6c51
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch

uint64_t fcn.1801c6ab0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h)
{
    int32_t *piVar1;
    undefined uVar2;
    undefined uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int32_t *piVar10;
    uint64_t uVar11;
    int32_t *in_RCX;
    undefined8 unaff_RBP;
    code *pcVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c6ac5;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    piVar10 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6aec;
        piVar10 = (int32_t *)func_0x0001801bda50();
        if (piVar10 == (int32_t *)0x0) {
            return 0xffffffff;
        }
    }
    if (*(int64_t *)(piVar10 + 0x31c) == 0) {
        piVar10[0x71] = 0;
        return 1;
    }
    *(undefined *)((int64_t)&arg_38h + iVar9) = 0x15;
    iVar6 = piVar10[0x12];
    if (iVar6 == 0x304) {
        iVar6 = 0x303;
    }
    *(int32_t *)((int64_t)&arg_38h + iVar9 + 4) = iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b43;
    iVar6 = func_0x00018019b210(in_RCX);
    if ((iVar6 == 0xd) && (piVar10[0x2e8] == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b59;
        uVar7 = func_0x000180194ed0(in_RCX);
        if ((uVar7 & 0xffffff00) == 0x300) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b6d;
            iVar6 = func_0x000180194ed0(in_RCX);
            if (0x301 < iVar6) {
                uVar8 = *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4);
                if (piVar10[0x232] == 0) {
                    uVar8 = 0x301;
                }
                *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4) = uVar8;
            }
        }
    }
    piVar1 = piVar10 + 0x72;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = 2;
    *(int32_t **)((int64_t)&arg_40h + iVar9) = piVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6ba9;
    iVar6 = func_0x0001801a31f0(piVar10 + 0x314);
    if (iVar6 != 0) {
        if (piVar10[0x71] == 2) {
            uVar4 = *(undefined8 *)(piVar10 + 800);
            pcVar12 = *(code **)(*(int64_t *)(piVar10 + 0x31c) + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6bee;
            uVar8 = (*pcVar12)(uVar4);
            *(undefined4 *)((int64_t)&var_18h + iVar9) = 0x77;
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c0d;
            iVar6 = func_0x0001801a32c0(piVar10, 1, uVar8, 0x1804b3148);
            if (0 < iVar6) {
                *(undefined8 *)(piVar10 + 0x32e) = 0;
                piVar10[0x71] = 0;
                return 1;
            }
        } else {
            piVar10[0x71] = 0;
        }
        return 0xffffffff;
    }
    iVar5 = *(int64_t *)(piVar10 + 0x31c);
    uVar4 = *(undefined8 *)(piVar10 + 800);
    *(undefined8 *)((int64_t)&arg_68h + iVar9) = unaff_RBP;
    pcVar12 = *(code **)(iVar5 + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c5d;
    uVar8 = (*pcVar12)(uVar4, (int64_t)&arg_38h + iVar9, 1);
    *(undefined4 *)((int64_t)&var_18h + iVar9) = 0x82;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c7c;
    uVar11 = func_0x0001801a32c0(piVar10, 1, uVar8, 0x1804b3148);
    if ((int32_t)uVar11 < 1) {
        piVar10[0x71] = 2;
        *(undefined8 *)(piVar10 + 0x32e) = *(undefined8 *)((int64_t)&arg_48h + iVar9);
        *(undefined *)(piVar10 + 0x330) = *(undefined *)((int64_t)&arg_38h + iVar9);
        *(undefined8 *)(piVar10 + 0x332) = *(undefined8 *)((int64_t)&arg_40h + iVar9);
        return uVar11;
    }
    uVar4 = *(undefined8 *)(piVar10 + 0x16);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6cdb;
    func_0x000180219d10(uVar4, 0xb, 0, 0);
    pcVar12 = *(code **)(piVar10 + 0x13e);
    piVar10[0x71] = 0;
    if (pcVar12 != (code *)0x0) {
        iVar6 = piVar10[0x12];
        *(undefined8 *)((int64_t)&arg_28h + iVar9) = *(undefined8 *)(piVar10 + 0x140);
        *(int32_t **)((int64_t)&var_20h + iVar9) = in_RCX;
        *(undefined8 *)((int64_t)&var_18h + iVar9) = 2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6d1d;
        (*pcVar12)(1, iVar6, 0x15, piVar1);
    }
    pcVar12 = *(code **)(piVar10 + 0x256);
    if ((pcVar12 != (code *)0x0) || (pcVar12 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120), pcVar12 != (code *)0x0)) {
        uVar2 = *(undefined *)piVar1;
        uVar3 = *(undefined *)((int64_t)piVar10 + 0x1c9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6d56;
        (*pcVar12)(in_RCX, 0x4008, CONCAT11(uVar2, uVar3));
    }
    return uVar11 & 0xffffffff;
}

// ============================================================
// Function: FUN_1801c6cc7
// Address: 0x1801c6cc7
// Size: 169 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch

uint64_t fcn.1801c6ab0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h)
{
    int32_t *piVar1;
    undefined uVar2;
    undefined uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int32_t *piVar10;
    uint64_t uVar11;
    int32_t *in_RCX;
    undefined8 unaff_RBP;
    code *pcVar12;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c6ac5;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    piVar10 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6aec;
        piVar10 = (int32_t *)func_0x0001801bda50();
        if (piVar10 == (int32_t *)0x0) {
            return 0xffffffff;
        }
    }
    if (*(int64_t *)(piVar10 + 0x31c) == 0) {
        piVar10[0x71] = 0;
        return 1;
    }
    *(undefined *)((int64_t)&arg_38h + iVar9) = 0x15;
    iVar6 = piVar10[0x12];
    if (iVar6 == 0x304) {
        iVar6 = 0x303;
    }
    *(int32_t *)((int64_t)&arg_38h + iVar9 + 4) = iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b43;
    iVar6 = func_0x00018019b210(in_RCX);
    if ((iVar6 == 0xd) && (piVar10[0x2e8] == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b59;
        uVar7 = func_0x000180194ed0(in_RCX);
        if ((uVar7 & 0xffffff00) == 0x300) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6b6d;
            iVar6 = func_0x000180194ed0(in_RCX);
            if (0x301 < iVar6) {
                uVar8 = *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4);
                if (piVar10[0x232] == 0) {
                    uVar8 = 0x301;
                }
                *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4) = uVar8;
            }
        }
    }
    piVar1 = piVar10 + 0x72;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = 2;
    *(int32_t **)((int64_t)&arg_40h + iVar9) = piVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6ba9;
    iVar6 = func_0x0001801a31f0(piVar10 + 0x314);
    if (iVar6 != 0) {
        if (piVar10[0x71] == 2) {
            uVar4 = *(undefined8 *)(piVar10 + 800);
            pcVar12 = *(code **)(*(int64_t *)(piVar10 + 0x31c) + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6bee;
            uVar8 = (*pcVar12)(uVar4);
            *(undefined4 *)((int64_t)&var_18h + iVar9) = 0x77;
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c0d;
            iVar6 = func_0x0001801a32c0(piVar10, 1, uVar8, 0x1804b3148);
            if (0 < iVar6) {
                *(undefined8 *)(piVar10 + 0x32e) = 0;
                piVar10[0x71] = 0;
                return 1;
            }
        } else {
            piVar10[0x71] = 0;
        }
        return 0xffffffff;
    }
    iVar5 = *(int64_t *)(piVar10 + 0x31c);
    uVar4 = *(undefined8 *)(piVar10 + 800);
    *(undefined8 *)((int64_t)&arg_68h + iVar9) = unaff_RBP;
    pcVar12 = *(code **)(iVar5 + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c5d;
    uVar8 = (*pcVar12)(uVar4, (int64_t)&arg_38h + iVar9, 1);
    *(undefined4 *)((int64_t)&var_18h + iVar9) = 0x82;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6c7c;
    uVar11 = func_0x0001801a32c0(piVar10, 1, uVar8, 0x1804b3148);
    if ((int32_t)uVar11 < 1) {
        piVar10[0x71] = 2;
        *(undefined8 *)(piVar10 + 0x32e) = *(undefined8 *)((int64_t)&arg_48h + iVar9);
        *(undefined *)(piVar10 + 0x330) = *(undefined *)((int64_t)&arg_38h + iVar9);
        *(undefined8 *)(piVar10 + 0x332) = *(undefined8 *)((int64_t)&arg_40h + iVar9);
        return uVar11;
    }
    uVar4 = *(undefined8 *)(piVar10 + 0x16);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6cdb;
    func_0x000180219d10(uVar4, 0xb, 0, 0);
    pcVar12 = *(code **)(piVar10 + 0x13e);
    piVar10[0x71] = 0;
    if (pcVar12 != (code *)0x0) {
        iVar6 = piVar10[0x12];
        *(undefined8 *)((int64_t)&arg_28h + iVar9) = *(undefined8 *)(piVar10 + 0x140);
        *(int32_t **)((int64_t)&var_20h + iVar9) = in_RCX;
        *(undefined8 *)((int64_t)&var_18h + iVar9) = 2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6d1d;
        (*pcVar12)(1, iVar6, 0x15, piVar1);
    }
    pcVar12 = *(code **)(piVar10 + 0x256);
    if ((pcVar12 != (code *)0x0) || (pcVar12 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120), pcVar12 != (code *)0x0)) {
        uVar2 = *(undefined *)piVar1;
        uVar3 = *(undefined *)((int64_t)piVar10 + 0x1c9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801c6d56;
        (*pcVar12)(in_RCX, 0x4008, CONCAT11(uVar2, uVar3));
    }
    return uVar11 & 0xffffffff;
}

// ============================================================
// Function: FUN_1801c6d70
// Address: 0x1801c6d70
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801c6d70(int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c6d80;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar3 = 0x21;
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        uVar3 = 0x11;
    }
    if (*(int64_t *)(in_RCX + 0x368) == 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x8f8);
        if ((iVar1 == 0) || (*(int64_t *)(iVar1 + 8) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c6de9;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c6e01;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c6e13;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
            return 0;
        }
        *(undefined8 *)(iVar1 + 0x2f8) = *(undefined8 *)(in_RCX + 0x300);
        pcVar2 = **(code ***)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c6dd5;
        uVar6 = (*pcVar2)(in_RCX);
        if ((int32_t)uVar6 == 0) {
            return uVar6;
        }
    }
    pcVar2 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c6e36;
    iVar4 = (*pcVar2)(in_RCX, uVar3);
    return (uint64_t)(iVar4 != 0);
}

// ============================================================
// Function: FUN_1801c6e50
// Address: 0x1801c6e50
// Size: 278 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801c6e50(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    code *UNRECOVERED_JUMPTABLE;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c6e65;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36);
    if ((((((*(uint8_t *)(iVar1 + 0x50) & 8) == 0) && (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) &&
         (iVar2 != 0x10000)) || (iVar2 = *(int32_t *)(in_RCX + 0xf0), iVar2 == 2)) ||
       ((((iVar2 - 1U & 0xfffffffc) == 0 && (iVar2 != 2)) || (*(int32_t *)(in_RCX + 0x8c8) == 1)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c6ec4;
        iVar2 = func_0x0001801b2cc0(in_R8D);
    } else {
        UNRECOVERED_JUMPTABLE = *(code **)(iVar1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c6eba;
        iVar2 = (*UNRECOVERED_JUMPTABLE)(in_R8D);
    }
    if ((*(int32_t *)(in_RCX + 0x48) == 0x300) && (iVar2 == 0x46)) {
        iVar2 = 0x28;
    } else if (iVar2 < 0) {
        return 0xffffffff;
    }
    if (((*(uint8_t *)(in_RCX + 0x84) & 1) == 0) || (iVar2 == 0)) {
        if ((in_EDX == 2) && (*(int64_t *)(in_RCX + 0x8f8) != 0)) {
            uVar4 = *(undefined8 *)(in_RCX + 0xb88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c6f09;
            func_0x00018019c8a0(uVar4);
        }
        *(undefined4 *)(in_RCX + 0x1c4) = 1;
        *(char *)(in_RCX + 0x1c8) = (char)in_EDX;
        *(char *)(in_RCX + 0x1c9) = (char)iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c6f2d;
        iVar2 = func_0x0001801a31f0(in_RCX + 0xc50);
        if (iVar2 == 0) {
            UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x90);
    // WARNING: Could not recover jumptable at 0x0001801c6f4e. Too many branches
    // WARNING: Treating indirect jump as call
            uVar4 = (*UNRECOVERED_JUMPTABLE)(in_RCX, UNRECOVERED_JUMPTABLE);
            return uVar4;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801c6f70
// Address: 0x1801c6f70
// Size: 98 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

uint64_t fcn.1801c6f70(int64_t arg_30h, int64_t arg_50h, int64_t arg_60h)
{
    undefined uVar1;
    undefined uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    int32_t *piVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801c6f7d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if (piVar6 != (int32_t *)0x0) {
            piVar6[0x71] = 0;
            *(undefined *)((int64_t)&arg_50h + iVar4) = *(undefined *)(piVar6 + 0x72);
            *(undefined *)((int64_t)&arg_50h + iVar4 + 1) = *(undefined *)((int64_t)piVar6 + 0x1c9);
            *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_RBP;
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&arg_58h + iVar4;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c6fe6;
            uVar5 = fcn.1801c7430(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar4));
            if ((int32_t)uVar5 < 1) {
                piVar6[0x71] = 1;
                return uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c701b;
            fcn.180219d10(*(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
            pcVar7 = *(code **)(piVar6 + 0x13e);
            if (pcVar7 != (code *)0x0) {
                iVar3 = piVar6[0x12];
                *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)(piVar6 + 0x140);
                *(int32_t **)((int64_t)&var_18h + iVar4) = in_RCX;
                *(undefined8 *)((int64_t)&var_10h + iVar4) = 2;
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c7059;
                (*pcVar7)(1, iVar3, 0x15, piVar6 + 0x72);
            }
            pcVar7 = *(code **)(piVar6 + 0x256);
            if ((pcVar7 != (code *)0x0) ||
               (pcVar7 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120), pcVar7 != (code *)0x0)) {
                uVar1 = *(undefined *)(piVar6 + 0x72);
                uVar2 = *(undefined *)((int64_t)piVar6 + 0x1c9);
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c7096;
                (*pcVar7)(in_RCX, 0x4008, CONCAT11(uVar1, uVar2));
            }
            return uVar5 & 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c6fd2
// Address: 0x1801c6fd2
// Size: 53 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

uint64_t fcn.1801c6f70(int64_t arg_30h, int64_t arg_50h, int64_t arg_60h)
{
    undefined uVar1;
    undefined uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    int32_t *piVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801c6f7d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if (piVar6 != (int32_t *)0x0) {
            piVar6[0x71] = 0;
            *(undefined *)((int64_t)&arg_50h + iVar4) = *(undefined *)(piVar6 + 0x72);
            *(undefined *)((int64_t)&arg_50h + iVar4 + 1) = *(undefined *)((int64_t)piVar6 + 0x1c9);
            *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_RBP;
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&arg_58h + iVar4;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c6fe6;
            uVar5 = fcn.1801c7430(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar4));
            if ((int32_t)uVar5 < 1) {
                piVar6[0x71] = 1;
                return uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c701b;
            fcn.180219d10(*(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
            pcVar7 = *(code **)(piVar6 + 0x13e);
            if (pcVar7 != (code *)0x0) {
                iVar3 = piVar6[0x12];
                *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)(piVar6 + 0x140);
                *(int32_t **)((int64_t)&var_18h + iVar4) = in_RCX;
                *(undefined8 *)((int64_t)&var_10h + iVar4) = 2;
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c7059;
                (*pcVar7)(1, iVar3, 0x15, piVar6 + 0x72);
            }
            pcVar7 = *(code **)(piVar6 + 0x256);
            if ((pcVar7 != (code *)0x0) ||
               (pcVar7 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120), pcVar7 != (code *)0x0)) {
                uVar1 = *(undefined *)(piVar6 + 0x72);
                uVar2 = *(undefined *)((int64_t)piVar6 + 0x1c9);
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c7096;
                (*pcVar7)(in_RCX, 0x4008, CONCAT11(uVar1, uVar2));
            }
            return uVar5 & 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c7007
// Address: 0x1801c7007
// Size: 162 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

uint64_t fcn.1801c6f70(int64_t arg_30h, int64_t arg_50h, int64_t arg_60h)
{
    undefined uVar1;
    undefined uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    int32_t *piVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801c6f7d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if (piVar6 != (int32_t *)0x0) {
            piVar6[0x71] = 0;
            *(undefined *)((int64_t)&arg_50h + iVar4) = *(undefined *)(piVar6 + 0x72);
            *(undefined *)((int64_t)&arg_50h + iVar4 + 1) = *(undefined *)((int64_t)piVar6 + 0x1c9);
            *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_RBP;
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&arg_58h + iVar4;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c6fe6;
            uVar5 = fcn.1801c7430(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar4));
            if ((int32_t)uVar5 < 1) {
                piVar6[0x71] = 1;
                return uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c701b;
            fcn.180219d10(*(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
            pcVar7 = *(code **)(piVar6 + 0x13e);
            if (pcVar7 != (code *)0x0) {
                iVar3 = piVar6[0x12];
                *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)(piVar6 + 0x140);
                *(int32_t **)((int64_t)&var_18h + iVar4) = in_RCX;
                *(undefined8 *)((int64_t)&var_10h + iVar4) = 2;
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c7059;
                (*pcVar7)(1, iVar3, 0x15, piVar6 + 0x72);
            }
            pcVar7 = *(code **)(piVar6 + 0x256);
            if ((pcVar7 != (code *)0x0) ||
               (pcVar7 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120), pcVar7 != (code *)0x0)) {
                uVar1 = *(undefined *)(piVar6 + 0x72);
                uVar2 = *(undefined *)((int64_t)piVar6 + 0x1c9);
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c7096;
                (*pcVar7)(in_RCX, 0x4008, CONCAT11(uVar1, uVar2));
            }
            return uVar5 & 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c70a9
// Address: 0x1801c70a9
// Size: 9 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

uint64_t fcn.1801c6f70(int64_t arg_30h, int64_t arg_50h, int64_t arg_60h)
{
    undefined uVar1;
    undefined uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    int32_t *piVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801c6f7d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if (piVar6 != (int32_t *)0x0) {
            piVar6[0x71] = 0;
            *(undefined *)((int64_t)&arg_50h + iVar4) = *(undefined *)(piVar6 + 0x72);
            *(undefined *)((int64_t)&arg_50h + iVar4 + 1) = *(undefined *)((int64_t)piVar6 + 0x1c9);
            *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_RBP;
            *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&arg_58h + iVar4;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c6fe6;
            uVar5 = fcn.1801c7430(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar4));
            if ((int32_t)uVar5 < 1) {
                piVar6[0x71] = 1;
                return uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c701b;
            fcn.180219d10(*(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
            pcVar7 = *(code **)(piVar6 + 0x13e);
            if (pcVar7 != (code *)0x0) {
                iVar3 = piVar6[0x12];
                *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)(piVar6 + 0x140);
                *(int32_t **)((int64_t)&var_18h + iVar4) = in_RCX;
                *(undefined8 *)((int64_t)&var_10h + iVar4) = 2;
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c7059;
                (*pcVar7)(1, iVar3, 0x15, piVar6 + 0x72);
            }
            pcVar7 = *(code **)(piVar6 + 0x256);
            if ((pcVar7 != (code *)0x0) ||
               (pcVar7 = *(code **)(*(int64_t *)(in_RCX + 2) + 0x120), pcVar7 != (code *)0x0)) {
                uVar1 = *(undefined *)(piVar6 + 0x72);
                uVar2 = *(undefined *)((int64_t)piVar6 + 0x1c9);
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801c7096;
                (*pcVar7)(in_RCX, 0x4008, CONCAT11(uVar1, uVar2));
            }
            return uVar5 & 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c70c0
// Address: 0x1801c70c0
// Size: 259 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

undefined8 fcn.1801c70c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t *in_RCX;
    int32_t *piVar5;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c70e0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    piVar5 = (int32_t *)0x0;
    if (*in_RCX == 0) {
        piVar5 = in_RCX;
    }
    if (piVar5 == (int32_t *)0x0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c7107;
    iVar2 = fcn.18019b2a0();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c7113;
        iVar2 = fcn.18019b680(piVar5);
        if (iVar2 == 0) {
            pcVar1 = *(code **)(piVar5 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c7120;
            uVar4 = (*pcVar1)(in_RCX);
            if ((int32_t)uVar4 < 0) {
                return uVar4;
            }
            if ((int32_t)uVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c712b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c7143;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3));
                goto code_r0x0001801c714b;
            }
        }
    }
    if (in_R9 < 0x4001) {
        *(undefined8 *)((int64_t)&var_18h + iVar3) = *(undefined8 *)((int64_t)&arg_58h + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c71c1;
        uVar4 = fcn.1801c8060(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3), 
                              *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3));
        return uVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c7183;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c719b;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
code_r0x0001801c714b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c7155;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801c71d0
// Address: 0x1801c71d0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801c71d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c71e6;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (undefined8 *)in_RCX[0x11];
    uVar3 = puVar2[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c71fc;
    iVar6 = func_0x0001801a6800(uVar3);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        do {
            puVar1 = (undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x18);
            if ((*(uint8_t *)(*in_RCX + 0x9a8) & 2) != 0) {
                uVar3 = *(undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x20);
                uVar4 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7230;
                func_0x000180244fc0(uVar4, uVar3);
            }
            uVar3 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7245;
            func_0x000180224990(uVar3, 0x1804b3188, 0x41);
            uVar3 = *(undefined8 *)(iVar6 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c725b;
            func_0x000180224990(uVar3, 0x1804b3188, 0x42);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7263;
            func_0x0001801a65e0(iVar6);
            uVar3 = puVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c726c;
            iVar6 = func_0x0001801a6800(uVar3);
        } while (iVar6 != 0);
    }
    *puVar2 = 0;
    puVar2[1] = puVar2[1];
    return;
}

// ============================================================
// Function: FUN_1801c7204
// Address: 0x1801c7204
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801c71d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c71e6;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (undefined8 *)in_RCX[0x11];
    uVar3 = puVar2[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c71fc;
    iVar6 = func_0x0001801a6800(uVar3);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        do {
            puVar1 = (undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x18);
            if ((*(uint8_t *)(*in_RCX + 0x9a8) & 2) != 0) {
                uVar3 = *(undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x20);
                uVar4 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7230;
                func_0x000180244fc0(uVar4, uVar3);
            }
            uVar3 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7245;
            func_0x000180224990(uVar3, 0x1804b3188, 0x41);
            uVar3 = *(undefined8 *)(iVar6 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c725b;
            func_0x000180224990(uVar3, 0x1804b3188, 0x42);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7263;
            func_0x0001801a65e0(iVar6);
            uVar3 = puVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c726c;
            iVar6 = func_0x0001801a6800(uVar3);
        } while (iVar6 != 0);
    }
    *puVar2 = 0;
    puVar2[1] = puVar2[1];
    return;
}

// ============================================================
// Function: FUN_1801c7279
// Address: 0x1801c7279
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801c71d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c71e6;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (undefined8 *)in_RCX[0x11];
    uVar3 = puVar2[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c71fc;
    iVar6 = func_0x0001801a6800(uVar3);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        do {
            puVar1 = (undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x18);
            if ((*(uint8_t *)(*in_RCX + 0x9a8) & 2) != 0) {
                uVar3 = *(undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x20);
                uVar4 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7230;
                func_0x000180244fc0(uVar4, uVar3);
            }
            uVar3 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7245;
            func_0x000180224990(uVar3, 0x1804b3188, 0x41);
            uVar3 = *(undefined8 *)(iVar6 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c725b;
            func_0x000180224990(uVar3, 0x1804b3188, 0x42);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7263;
            func_0x0001801a65e0(iVar6);
            uVar3 = puVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c726c;
            iVar6 = func_0x0001801a6800(uVar3);
        } while (iVar6 != 0);
    }
    *puVar2 = 0;
    puVar2[1] = puVar2[1];
    return;
}

// ============================================================
// Function: FUN_1801c72a0
// Address: 0x1801c72a0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801c72a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c72b1;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (undefined8 *)in_RCX[0x11];
    if (puVar2 != (undefined8 *)0x0) {
        uVar3 = puVar2[1];
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c72da;
        iVar6 = func_0x0001801a6800(uVar3);
        while (iVar6 != 0) {
            puVar1 = (undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x18);
            if ((*(uint8_t *)(*in_RCX + 0x9a8) & 2) != 0) {
                uVar3 = *(undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x20);
                uVar4 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7302;
                func_0x000180244fc0(uVar4, uVar3);
            }
            uVar3 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7317;
            func_0x000180224990(uVar3, 0x1804b3188, 0x41);
            uVar3 = *(undefined8 *)(iVar6 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c732d;
            func_0x000180224990(uVar3, 0x1804b3188, 0x42);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7335;
            func_0x0001801a65e0(iVar6);
            uVar3 = puVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c733e;
            iVar6 = func_0x0001801a6800(uVar3);
        }
        *puVar2 = 0;
        puVar2[1] = puVar2[1];
        uVar3 = *(undefined8 *)(in_RCX[0x11] + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7363;
        func_0x0001801a66d0(uVar3);
        iVar6 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c737c;
        func_0x000180224990(iVar6, 0x1804b3188, 0x2f);
        in_RCX[0x11] = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801c72cb
// Address: 0x1801c72cb
// Size: 194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801c72a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c72b1;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (undefined8 *)in_RCX[0x11];
    if (puVar2 != (undefined8 *)0x0) {
        uVar3 = puVar2[1];
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c72da;
        iVar6 = func_0x0001801a6800(uVar3);
        while (iVar6 != 0) {
            puVar1 = (undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x18);
            if ((*(uint8_t *)(*in_RCX + 0x9a8) & 2) != 0) {
                uVar3 = *(undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x20);
                uVar4 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7302;
                func_0x000180244fc0(uVar4, uVar3);
            }
            uVar3 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7317;
            func_0x000180224990(uVar3, 0x1804b3188, 0x41);
            uVar3 = *(undefined8 *)(iVar6 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c732d;
            func_0x000180224990(uVar3, 0x1804b3188, 0x42);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7335;
            func_0x0001801a65e0(iVar6);
            uVar3 = puVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c733e;
            iVar6 = func_0x0001801a6800(uVar3);
        }
        *puVar2 = 0;
        puVar2[1] = puVar2[1];
        uVar3 = *(undefined8 *)(in_RCX[0x11] + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7363;
        func_0x0001801a66d0(uVar3);
        iVar6 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c737c;
        func_0x000180224990(iVar6, 0x1804b3188, 0x2f);
        in_RCX[0x11] = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801c738d
// Address: 0x1801c738d
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801c72a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c72b1;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (undefined8 *)in_RCX[0x11];
    if (puVar2 != (undefined8 *)0x0) {
        uVar3 = puVar2[1];
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c72da;
        iVar6 = func_0x0001801a6800(uVar3);
        while (iVar6 != 0) {
            puVar1 = (undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x18);
            if ((*(uint8_t *)(*in_RCX + 0x9a8) & 2) != 0) {
                uVar3 = *(undefined8 *)(*(int64_t *)(iVar6 + 8) + 0x20);
                uVar4 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7302;
                func_0x000180244fc0(uVar4, uVar3);
            }
            uVar3 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7317;
            func_0x000180224990(uVar3, 0x1804b3188, 0x41);
            uVar3 = *(undefined8 *)(iVar6 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c732d;
            func_0x000180224990(uVar3, 0x1804b3188, 0x42);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7335;
            func_0x0001801a65e0(iVar6);
            uVar3 = puVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c733e;
            iVar6 = func_0x0001801a6800(uVar3);
        }
        *puVar2 = 0;
        puVar2[1] = puVar2[1];
        uVar3 = *(undefined8 *)(in_RCX[0x11] + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c7363;
        func_0x0001801a66d0(uVar3);
        iVar6 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c737c;
        func_0x000180224990(iVar6, 0x1804b3188, 0x2f);
        in_RCX[0x11] = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801c73a0
// Address: 0x1801c73a0
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801c73a0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c73b0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c73cd;
    iVar2 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (iVar2 != 0) {
        *(int64_t *)(in_RCX + 0x88) = iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c73e1;
        iVar3 = fcn.1801a67b0(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000040 + iVar1));
        *(int64_t *)(iVar2 + 8) = iVar3;
        if (iVar3 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c73ff;
        fcn.180224990(iVar2, 0x1804b3188, 0x20);
        *(undefined8 *)(in_RCX + 0x88) = 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c7430
// Address: 0x1801c7430
// Size: 320 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

undefined8
fcn.1801c7430(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    code *pcVar1;
    int32_t *piVar2;
    int64_t iVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined in_DL;
    undefined8 in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c7450;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (0 < *(int32_t *)(in_RCX + 0x1c4)) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x90);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c7476;
        uVar7 = (*pcVar1)();
        if ((int32_t)uVar7 < 1) {
            return uVar7;
        }
    }
    if (in_R9 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c748b;
        uVar4 = func_0x0001801976c0(in_RCX);
        if (in_R9 <= uVar4) {
            piVar2 = *(int32_t **)(in_RCX + 0x18);
            *(undefined *)((int64_t)&arg_28h + iVar6) = in_DL;
            if ((*piVar2 == 0x1ffff) && (*(int32_t *)(in_RCX + 0x9b8) != 0x100)) {
                *(undefined4 *)((int64_t)&arg_28h + iVar6 + 4) = 0xfeff;
            } else {
                *(undefined4 *)((int64_t)&arg_28h + iVar6 + 4) = *(undefined4 *)(in_RCX + 0x48);
            }
            iVar3 = *(int64_t *)(in_RCX + 0xc70);
            uVar7 = *(undefined8 *)(in_RCX + 0xc80);
            *(undefined8 *)((int64_t)&arg_30h + iVar6) = in_R8;
            *(uint64_t *)((int64_t)&arg_38h + iVar6) = in_R9;
            pcVar1 = *(code **)(iVar3 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c7524;
            uVar5 = (*pcVar1)(uVar7, (int64_t)&arg_28h + iVar6, 1);
            *(undefined4 *)((int64_t)&var_18h + iVar6) = 0x2a0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c7543;
            uVar7 = func_0x0001801a32c0(in_RCX, 1, uVar5, 0x1804b3188);
            if ((int32_t)uVar7 < 1) {
                return uVar7;
            }
            **(int64_t **)((int64_t)&arg_78h + iVar6) = (int64_t)(int32_t)in_R9;
            return uVar7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c7497;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c74af;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c74c5;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc2, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c7590
// Address: 0x1801c7590
// Size: 46 bytes
// ============================================================
void fcn.1801c7590(int64_t arg_30h, int64_t arg_50h)
{
    undefined8 uVar1;
    int16_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t in_DL;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar2 = *(int16_t **)(in_RCX + 0xcd8);
    if ((in_DL & 1) == 0) {
        piVar2[1] = piVar2[1] + 1;
        return;
    }
    *piVar2 = *piVar2 + 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x1801c2620;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1801c2639;
    iVar4 = func_0x0001801a6800(uVar1);
    while (iVar4 != 0) {
        uVar1 = *(undefined8 *)(iVar4 + 8);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1801c264a;
        func_0x0001801cae70(uVar1);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1801c2652;
        func_0x0001801a65e0(iVar4);
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1801c2665;
        iVar4 = func_0x0001801a6800(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1801c75c0
// Address: 0x1801c75c0
// Size: 2714 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801c75c0(int32_t *placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h)
{
    char cVar1;
    uint8_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int32_t *piVar9;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    int64_t iVar13;
    undefined8 uVar14;
    uint32_t uVar15;
    int32_t *piVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    code *pcVar19;
    code *pcVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801c75e4;
    var_18h = arg3;
    var_20h = arg4;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    pcVar19 = (code *)0x0;
    if (placeholder_0 == (int32_t *)0x0) {
        return 0xffffffff;
    }
    piVar9 = placeholder_0;
    if (*placeholder_0 != 0) {
        if (-1 < (char)*placeholder_0) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c760f;
        piVar9 = (int32_t *)func_0x0001801bda50();
        if (piVar9 == (int32_t *)0x0) {
            return 0xffffffff;
        }
    }
    if ((((char)placeholder_1 != '\0') && (1 < (uint8_t)((char)placeholder_1 - 0x16U))) ||
       ((*(int32_t *)((int64_t)&arg_b0h + iVar8) != 0 && ((char)placeholder_1 != '\x17')))) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7638;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
code_r0x0001801c7644:
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7650;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8));
        uVar17 = 0xc0103;
code_r0x0001801c7656:
        uVar14 = 0x50;
code_r0x0001801c765b:
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7666;
        func_0x00018019b5e0(piVar9, uVar14, uVar17, 0);
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c768e;
    iVar6 = fcn.18019b680(piVar9);
    pcVar20 = (code *)0x0;
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c769a;
        iVar6 = fcn.18019b2a0(placeholder_0);
        pcVar20 = pcVar19;
        if (iVar6 != 0) {
            pcVar20 = *(code **)(piVar9 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c76a7;
            uVar14 = (*pcVar20)(placeholder_0);
            iVar6 = (int32_t)uVar14;
            if (-1 < iVar6) goto joined_r0x0001801c76ab;
            return uVar14;
        }
    }
code_r0x0001801c76b0:
    while( true ) {
        do {
            piVar9[0x1a] = 1;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c76c2;
            iVar6 = func_0x00018019b2e0(placeholder_0);
            if ((iVar6 != 0) && (*(uint64_t *)(piVar9 + 0x340) <= *(uint64_t *)(piVar9 + 0x342))) {
                uVar14 = *(undefined8 *)(*(int64_t *)(piVar9 + 0x336) + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c76ea;
                iVar10 = func_0x0001801a6800(uVar14);
                if (iVar10 != 0) {
                    piVar16 = *(int32_t **)(iVar10 + 8);
                    iVar6 = piVar16[1];
                    iVar4 = piVar16[2];
                    iVar5 = piVar16[3];
                    piVar9[0x344] = *piVar16;
                    piVar9[0x345] = iVar6;
                    piVar9[0x346] = iVar4;
                    piVar9[0x347] = iVar5;
                    iVar6 = piVar16[5];
                    iVar4 = piVar16[6];
                    iVar5 = piVar16[7];
                    piVar9[0x348] = piVar16[4];
                    piVar9[0x349] = iVar6;
                    piVar9[0x34a] = iVar4;
                    piVar9[0x34b] = iVar5;
                    iVar6 = piVar16[9];
                    iVar4 = piVar16[10];
                    iVar5 = piVar16[0xb];
                    piVar9[0x34c] = piVar16[8];
                    piVar9[0x34d] = iVar6;
                    piVar9[0x34e] = iVar4;
                    piVar9[0x34f] = iVar5;
                    iVar6 = piVar16[0xd];
                    iVar4 = piVar16[0xe];
                    iVar5 = piVar16[0xf];
                    piVar9[0x350] = piVar16[0xc];
                    piVar9[0x351] = iVar6;
                    piVar9[0x352] = iVar4;
                    piVar9[0x353] = iVar5;
                    *(undefined8 *)(piVar9 + 0x340) = 1;
                    *(undefined8 *)(piVar9 + 0x342) = 0;
                    uVar14 = *(undefined8 *)(iVar10 + 8);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7749;
                    fcn.180224990(uVar14, 0x1804b3188, 0xa5);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7751;
                    func_0x0001801a65e0(iVar10);
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7759;
            iVar6 = func_0x0001801c2960(piVar9);
        } while (0 < iVar6);
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7769;
        iVar6 = func_0x00018019b690(piVar9);
        if (iVar6 != 0) {
            return 0xffffffff;
        }
        if (*(uint64_t *)(piVar9 + 0x342) < *(uint64_t *)(piVar9 + 0x340)) break;
        iVar10 = *(int64_t *)(piVar9 + 0x31a);
        piVar16 = piVar9 + 0x344;
        *(undefined8 *)(piVar9 + 0x340) = 0;
        *(int64_t *)(&stack0x00000000 + iVar8) = (int64_t)piVar9 + 0xd42;
        uVar14 = *(undefined8 *)(piVar9 + 0x31e);
        *(int32_t **)(&stack0xfffffffffffffff8 + iVar8) = piVar9 + 0x350;
        *(undefined8 *)(piVar9 + 0x342) = 0;
        pcVar19 = *(code **)(iVar10 + 0x40);
        *(int32_t **)(&stack0xfffffffffffffff0 + iVar8) = piVar9 + 0x34c;
        *(int32_t **)(&stack0xffffffffffffffe8 + iVar8) = piVar9 + 0x348;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c77de;
        uVar7 = (*pcVar19)(uVar14, piVar16, piVar9 + 0x346, piVar9 + 0x347);
        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar8) = 0x102;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c77fa;
        iVar6 = func_0x0001801a32c0(piVar9, 0, uVar7, 0x1804b3188);
        while (0 < iVar6) {
            *(undefined8 *)(piVar16 + 10) = 0;
            *(int64_t *)(piVar9 + 0x340) = *(int64_t *)(piVar9 + 0x340) + 1;
            uVar14 = *(undefined8 *)(piVar9 + 0x31e);
            pcVar19 = *(code **)(*(int64_t *)(piVar9 + 0x31a) + 0x18);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7821;
            iVar6 = (*pcVar19)(uVar14);
            if ((iVar6 == 0) || (0x1f < *(uint64_t *)(piVar9 + 0x340))) {
                arg3 = *(undefined8 *)((int64_t)&arg_98h + iVar8);
                goto code_r0x0001801c78d7;
            }
            piVar16 = piVar9 + *(uint64_t *)(piVar9 + 0x340) * 0x10 + 0x344;
            pcVar19 = *(code **)(*(int64_t *)(piVar9 + 0x31a) + 0x40);
            *(int64_t *)(&stack0x00000000 + iVar8) = (int64_t)piVar16 + 0x32;
            uVar14 = *(undefined8 *)(piVar9 + 0x31e);
            *(int32_t **)(&stack0xfffffffffffffff8 + iVar8) = piVar16 + 0xc;
            *(int32_t **)(&stack0xfffffffffffffff0 + iVar8) = piVar16 + 8;
            *(int32_t **)(&stack0xffffffffffffffe8 + iVar8) = piVar16 + 4;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c788c;
            uVar7 = (*pcVar19)(uVar14, piVar16, piVar16 + 2, piVar16 + 3);
            *(undefined4 *)(&stack0xffffffffffffffe8 + iVar8) = 0x102;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c78a8;
            iVar6 = func_0x0001801a32c0(piVar9, 0, uVar7, 0x1804b3188);
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c78ba;
        uVar14 = func_0x0001801cb3a0(piVar9, iVar6);
        if ((int32_t)uVar14 < 1) {
            return uVar14;
        }
        arg3 = *(undefined8 *)((int64_t)&arg_98h + iVar8);
    }
code_r0x0001801c78d7:
    piVar16 = piVar9 + *(int64_t *)(piVar9 + 0x342) * 0x10 + 0x344;
    if ((*(char *)(piVar16 + 3) != '\x15') && (*(int64_t *)(piVar16 + 8) != 0)) {
        piVar9[0x334] = 0;
    }
    if ((piVar9[0x6e] != 0) && (*(char *)(piVar16 + 3) != '\x16')) {
        uVar14 = *(undefined8 *)(*(int64_t *)(piVar9 + 0x336) + 8);
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7929;
        uVar11 = func_0x0001801a6810(uVar14);
        if (uVar11 < 100) {
            if (*(int64_t *)(piVar16 + 10) != 0) {
                return 0xffffffff;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7955;
            puVar12 = (undefined8 *)
                      fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                    *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7964;
            iVar10 = func_0x0001801a6610((int64_t)piVar16 + 0x32, puVar12);
            if ((puVar12 == (undefined8 *)0x0) || (iVar10 == 0)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7d17;
                fcn.180224990(puVar12, 0x1804b3188, 0x5c);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7d1f;
                func_0x0001801a65e0(iVar10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7d24;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                goto code_r0x0001801c7644;
            }
            iVar6 = piVar16[1];
            iVar4 = piVar16[2];
            iVar5 = piVar16[3];
            *(int32_t *)puVar12 = *piVar16;
            *(int32_t *)((int64_t)puVar12 + 4) = iVar6;
            *(int32_t *)(puVar12 + 1) = iVar4;
            *(int32_t *)((int64_t)puVar12 + 0xc) = iVar5;
            iVar6 = piVar16[5];
            iVar4 = piVar16[6];
            iVar5 = piVar16[7];
            *(int32_t *)(puVar12 + 2) = piVar16[4];
            *(int32_t *)((int64_t)puVar12 + 0x14) = iVar6;
            *(int32_t *)(puVar12 + 3) = iVar4;
            *(int32_t *)((int64_t)puVar12 + 0x1c) = iVar5;
            iVar6 = piVar16[9];
            iVar4 = piVar16[10];
            iVar5 = piVar16[0xb];
            *(int32_t *)(puVar12 + 4) = piVar16[8];
            *(int32_t *)((int64_t)puVar12 + 0x24) = iVar6;
            *(int32_t *)(puVar12 + 5) = iVar4;
            *(int32_t *)((int64_t)puVar12 + 0x2c) = iVar5;
            iVar6 = piVar16[0xd];
            iVar4 = piVar16[0xe];
            iVar5 = piVar16[0xf];
            *(int32_t *)(puVar12 + 6) = piVar16[0xc];
            *(int32_t *)((int64_t)puVar12 + 0x34) = iVar6;
            *(int32_t *)(puVar12 + 7) = iVar4;
            *(int32_t *)((int64_t)puVar12 + 0x3c) = iVar5;
            uVar17 = *(undefined8 *)(piVar16 + 8);
            uVar3 = *(undefined8 *)(piVar16 + 4);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c79b1;
            iVar13 = func_0x000180223170(uVar3, uVar17, 0x1804b3188, 0x68);
            puVar12[3] = iVar13;
            puVar12[2] = iVar13;
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7cd2;
                fcn.180224990(puVar12, 0x1804b3188, 0x6a);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7cda;
                func_0x0001801a65e0(iVar10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7cdf;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7cf7;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
                uVar17 = 0x8000f;
                goto code_r0x0001801c7656;
            }
            *puVar12 = 0;
            *(undefined8 **)(iVar10 + 8) = puVar12;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c79d8;
            iVar13 = func_0x0001801a6700(uVar14, iVar10);
            if (iVar13 == 0) {
                uVar14 = puVar12[3];
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c79f3;
                fcn.180224990(uVar14, 0x1804b3188, 0x83);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7a08;
                fcn.180224990(puVar12, 0x1804b3188);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7a10;
                func_0x0001801a65e0(iVar10);
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7a20;
        iVar6 = func_0x0001801a4880(piVar9, piVar16, 0);
        if (iVar6 == 0) {
            return 0xffffffff;
        }
        arg3 = *(undefined8 *)((int64_t)&arg_98h + iVar8);
        goto code_r0x0001801c76b0;
    }
    if ((piVar9[0x21] & 2U) != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c8044;
        iVar6 = func_0x0001801a4880(piVar9, piVar16, 0);
        if (iVar6 != 0) {
            piVar9[0x1a] = 1;
            return 0;
        }
        return 0xffffffff;
    }
    cVar1 = *(char *)(piVar16 + 3);
    if ((char)placeholder_1 == cVar1) {
code_r0x0001801c7f45:
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7f4d;
        iVar6 = fcn.18019b2a0(placeholder_0);
        if (((iVar6 == 0) || ((char)placeholder_1 != '\x17')) ||
           ((*(int64_t *)(piVar9 + 0x98) != 0 && (*(int64_t *)(piVar9 + 0xba) != 0)))) {
            if ((undefined *)arg3 != (undefined *)0x0) {
                *(undefined *)arg3 = *(undefined *)(piVar16 + 3);
            }
            uVar11 = *(uint64_t *)((int64_t)&arg_a8h + iVar8);
            uVar18 = *(uint64_t *)(piVar16 + 8);
            if (uVar11 == 0) {
                if (uVar18 != 0) {
                    return 0;
                }
                goto code_r0x0001801c7fb9;
            }
            iVar10 = *(int64_t *)(piVar16 + 10);
            if (uVar18 < uVar11) {
                uVar11 = uVar18;
            }
            iVar13 = *(int64_t *)(piVar16 + 4);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7ff5;
            func_0x000180498030(*(undefined8 *)((int64_t)&arg_a0h + iVar8), iVar10 + iVar13, uVar11);
            uVar18 = uVar11;
            if (*(int32_t *)((int64_t)&arg_b0h + iVar8) != 0) {
                if (*(int64_t *)(piVar16 + 8) != 0) goto code_r0x0001801c8021;
                uVar18 = 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c8019;
            iVar6 = func_0x0001801a4880(piVar9, piVar16, uVar18);
            if (iVar6 == 0) {
                return 0xffffffff;
            }
code_r0x0001801c8021:
            **(uint64_t **)((int64_t)&arg_b8h + iVar8) = uVar11;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7f70;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7f88;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8));
        uVar14 = 10;
        uVar17 = 100;
        goto code_r0x0001801c765b;
    }
    if (cVar1 == '\x14') {
        if (((char)placeholder_1 == '\x16') && ((undefined *)arg3 != (undefined *)0x0)) goto code_r0x0001801c7f45;
    } else if (cVar1 == '\x15') {
        uVar11 = *(uint64_t *)(piVar16 + 8);
        if ((((0x7fffffffffffffff < uVar11) || (uVar11 == 0)) ||
            (cVar1 = *(char *)(*(int64_t *)(piVar16 + 10) + *(int64_t *)(piVar16 + 4)), uVar11 == 1)) ||
           (uVar2 = ((char *)(*(int64_t *)(piVar16 + 10) + *(int64_t *)(piVar16 + 4)))[1], uVar11 != 2)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7e53;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7e6b;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8));
            uVar14 = 10;
            uVar17 = 0xcd;
            goto code_r0x0001801c765b;
        }
        pcVar19 = *(code **)(piVar9 + 0x13e);
        if (pcVar19 != (code *)0x0) {
            iVar6 = piVar9[0x12];
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = *(undefined8 *)(piVar9 + 0x140);
            *(int32_t **)(&stack0xfffffffffffffff0 + iVar8) = placeholder_0;
            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 2;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7b0d;
            (*pcVar19)(0, iVar6);
        }
        uVar15 = (uint32_t)uVar2;
        pcVar19 = *(code **)(piVar9 + 0x256);
        if (((*(code **)(piVar9 + 0x256) != (code *)0x0) ||
            (pcVar19 = *(code **)(*(int64_t *)(placeholder_0 + 2) + 0x120),
            *(code **)(*(int64_t *)(placeholder_0 + 2) + 0x120) != (code *)0x0)) ||
           (pcVar19 = pcVar20, pcVar20 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7b46;
            (*pcVar19)(placeholder_0, 0x4004);
        }
        if (cVar1 != '\x01') {
            if (cVar1 == '\x02') {
                piVar9[0x1a] = 1;
                piVar9[0x70] = uVar15;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7db4;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7dcc;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
                *(uint32_t *)(&stack0xffffffffffffffe8 + iVar8) = uVar15;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7deb;
                func_0x00018019b5e0(piVar9, 0xffffffff, uVar2 + 1000, 0x1804ad928);
                piVar9[0x21] = piVar9[0x21] | 2;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7dff;
                iVar6 = func_0x0001801a4880(piVar9, piVar16, 0);
                if (iVar6 != 0) {
                    uVar14 = *(undefined8 *)(piVar9 + 0x23e);
                    uVar17 = *(undefined8 *)(piVar9 + 0x2e2);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7e1a;
                    func_0x00018019c8a0(uVar17, uVar14);
                    return 0;
                }
                return 0xffffffff;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7e26;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7e3e;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8));
            uVar14 = 0x2f;
            uVar17 = 0xf6;
            goto code_r0x0001801c765b;
        }
        piVar9[0x6f] = uVar15;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7b63;
        iVar6 = func_0x0001801a4880(piVar9, piVar16, 0);
        if (iVar6 == 0) {
            return 0xffffffff;
        }
        piVar9[0x334] = piVar9[0x334] + 1;
        if (piVar9[0x334] == 5) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7d75;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7d8d;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8));
            uVar14 = 10;
            uVar17 = 0x199;
            goto code_r0x0001801c765b;
        }
        if (uVar15 == 0) {
            piVar9[0x21] = piVar9[0x21] | 2;
            return 0;
        }
        if (uVar15 == 100) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7d3a;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7d52;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                          *(int64_t *)((int64_t)&var_18h + iVar8));
            uVar14 = 0x28;
            uVar17 = 0x153;
            goto code_r0x0001801c765b;
        }
        arg3 = *(undefined8 *)((int64_t)&arg_98h + iVar8);
        pcVar20 = pcVar19;
        goto code_r0x0001801c76b0;
    }
    if ((piVar9[0x21] & 1U) != 0) {
        piVar9[0x1a] = 1;
code_r0x0001801c7fb9:
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7fc7;
        iVar6 = func_0x0001801a4880(piVar9, piVar16, 0);
        if (iVar6 != 0) {
            return 0;
        }
        return 0xffffffff;
    }
    if (cVar1 == '\x14') {
code_r0x0001801c7a75:
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7a83;
        iVar6 = func_0x0001801a4880(piVar9, piVar16, 0);
        pcVar19 = pcVar20;
joined_r0x0001801c76ab:
        pcVar20 = pcVar19;
        if (iVar6 == 0) {
            return 0xffffffff;
        }
    } else {
        if (cVar1 != '\x16') {
code_r0x0001801c7e91:
            cVar1 = *(char *)(piVar16 + 3);
            if (((cVar1 == '\x14') || (cVar1 == '\x15')) || (cVar1 == '\x16')) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7f14;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7f2c;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
                uVar14 = 10;
                uVar17 = 0xc0103;
            } else {
                if (cVar1 == '\x17') {
                    if ((piVar9[0x76] != 0) && (piVar9[0x74] != 0)) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7ef0;
                        iVar6 = func_0x00018019b380(piVar9);
                        if (iVar6 != 0) {
                            piVar9[0x76] = 2;
                            return 0xffffffff;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7f08;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                } else {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7eae;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7ec6;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
                uVar14 = 10;
                uVar17 = 0xf5;
            }
            goto code_r0x0001801c765b;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7bae;
        iVar6 = fcn.18019b680(piVar9);
        if (iVar6 != 0) goto code_r0x0001801c7e91;
        if ((*(int16_t *)(piVar16 + 0xc) != **(int16_t **)(piVar9 + 0x336)) || (*(uint64_t *)(piVar16 + 8) < 0xc))
        goto code_r0x0001801c7a75;
        uVar14 = *(undefined8 *)(piVar16 + 4);
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7be3;
        func_0x0001801cade0(uVar14, (int64_t)&var_8h + iVar8);
        if (*(char *)((int64_t)&var_8h + iVar8) == '\x14') {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7bf6;
            iVar6 = func_0x0001801c2340(piVar9);
            if (iVar6 < 0) {
                return 0xffffffff;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7c06;
            iVar6 = func_0x0001801cb7e0(piVar9);
            if (iVar6 < 1) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7c12;
                iVar6 = func_0x00018019b690(piVar9);
                if (iVar6 != 0) {
                    return 0xffffffff;
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7c28;
            iVar6 = func_0x0001801a4880(piVar9, piVar16, 0);
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7c92;
            iVar6 = func_0x00018019b2e0(placeholder_0);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7e80;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                goto code_r0x0001801c7644;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7ca7;
            func_0x00018019b750(piVar9, 1);
            pcVar19 = *(code **)(piVar9 + 0x1c);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7cb0;
            uVar14 = (*pcVar19)(placeholder_0);
            iVar6 = (int32_t)uVar14;
            if (iVar6 < 0) {
                return uVar14;
            }
        }
        if (iVar6 == 0) {
            return 0xffffffff;
        }
        if ((*(uint8_t *)(piVar9 + 0x26c) & 4) == 0) {
            uVar14 = *(undefined8 *)(piVar9 + 0x31e);
            pcVar19 = *(code **)(*(int64_t *)(piVar9 + 0x31a) + 0x10);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7c51;
            iVar6 = (*pcVar19)(uVar14);
            if (iVar6 == 0) {
                piVar9[0x1a] = 3;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7c68;
                uVar14 = func_0x000180193c40(placeholder_0);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7c78;
                func_0x000180219ce0(uVar14, 0xf);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c7c85;
                func_0x00018021b250(uVar14, 9);
                return 0xffffffff;
            }
        }
    }
    goto code_r0x0001801c76b0;
}

// ============================================================
// Function: FUN_1801c8060
// Address: 0x1801c8060
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

undefined8
fcn.1801c8060(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    int32_t iVar1;
    code *pcVar2;
    int32_t *piVar3;
    int64_t iVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined in_DL;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    uint64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c807b;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_R9 < 0x4001) {
        iVar1 = *(int32_t *)(in_RCX + 0x1c4);
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
        *(undefined4 *)(in_RCX + 0x68) = 1;
        if (0 < iVar1) {
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x90);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80f2;
            uVar8 = (*pcVar2)();
            if ((int32_t)uVar8 < 1) {
                return uVar8;
            }
        }
        if (in_R9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8107;
            uVar5 = func_0x0001801976c0(in_RCX);
            if (in_R9 <= uVar5) {
                piVar3 = *(int32_t **)(in_RCX + 0x18);
                *(undefined *)((int64_t)&arg_28h + iVar7) = in_DL;
                if ((*piVar3 == 0x1ffff) && (*(int32_t *)(in_RCX + 0x9b8) != 0x100)) {
                    *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = 0xfeff;
                } else {
                    *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = *(undefined4 *)(in_RCX + 0x48);
                }
                iVar4 = *(int64_t *)(in_RCX + 0xc70);
                uVar8 = *(undefined8 *)(in_RCX + 0xc80);
                *(undefined8 *)((int64_t)&arg_30h + iVar7) = in_R8;
                *(uint64_t *)((int64_t)&arg_38h + iVar7) = in_R9;
                pcVar2 = *(code **)(iVar4 + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c81a0;
                uVar6 = (*pcVar2)(uVar8, (int64_t)&arg_28h + iVar7, 1);
                *(undefined4 *)((int64_t)&var_18h + iVar7) = 0x2a0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c81bf;
                uVar8 = func_0x0001801a32c0(in_RCX, 1, uVar6, 0x1804b3188);
                if ((int32_t)uVar8 < 1) {
                    return uVar8;
                }
                **(int64_t **)((int64_t)&arg_78h + iVar7) = (int64_t)(int32_t)in_R9;
                return uVar8;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8113;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c812b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8141;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc2, 0);
        }
        uVar8 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8098;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80b0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80c6;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        uVar8 = 0xffffffff;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801c80d7
// Address: 0x1801c80d7
// Size: 255 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

undefined8
fcn.1801c8060(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    int32_t iVar1;
    code *pcVar2;
    int32_t *piVar3;
    int64_t iVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined in_DL;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    uint64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c807b;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_R9 < 0x4001) {
        iVar1 = *(int32_t *)(in_RCX + 0x1c4);
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
        *(undefined4 *)(in_RCX + 0x68) = 1;
        if (0 < iVar1) {
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x90);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80f2;
            uVar8 = (*pcVar2)();
            if ((int32_t)uVar8 < 1) {
                return uVar8;
            }
        }
        if (in_R9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8107;
            uVar5 = func_0x0001801976c0(in_RCX);
            if (in_R9 <= uVar5) {
                piVar3 = *(int32_t **)(in_RCX + 0x18);
                *(undefined *)((int64_t)&arg_28h + iVar7) = in_DL;
                if ((*piVar3 == 0x1ffff) && (*(int32_t *)(in_RCX + 0x9b8) != 0x100)) {
                    *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = 0xfeff;
                } else {
                    *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = *(undefined4 *)(in_RCX + 0x48);
                }
                iVar4 = *(int64_t *)(in_RCX + 0xc70);
                uVar8 = *(undefined8 *)(in_RCX + 0xc80);
                *(undefined8 *)((int64_t)&arg_30h + iVar7) = in_R8;
                *(uint64_t *)((int64_t)&arg_38h + iVar7) = in_R9;
                pcVar2 = *(code **)(iVar4 + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c81a0;
                uVar6 = (*pcVar2)(uVar8, (int64_t)&arg_28h + iVar7, 1);
                *(undefined4 *)((int64_t)&var_18h + iVar7) = 0x2a0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c81bf;
                uVar8 = func_0x0001801a32c0(in_RCX, 1, uVar6, 0x1804b3188);
                if ((int32_t)uVar8 < 1) {
                    return uVar8;
                }
                **(int64_t **)((int64_t)&arg_78h + iVar7) = (int64_t)(int32_t)in_R9;
                return uVar8;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8113;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c812b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8141;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc2, 0);
        }
        uVar8 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8098;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80b0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80c6;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        uVar8 = 0xffffffff;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801c81d6
// Address: 0x1801c81d6
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

undefined8
fcn.1801c8060(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    int32_t iVar1;
    code *pcVar2;
    int32_t *piVar3;
    int64_t iVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined in_DL;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    uint64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c807b;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_R9 < 0x4001) {
        iVar1 = *(int32_t *)(in_RCX + 0x1c4);
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
        *(undefined4 *)(in_RCX + 0x68) = 1;
        if (0 < iVar1) {
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x90);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80f2;
            uVar8 = (*pcVar2)();
            if ((int32_t)uVar8 < 1) {
                return uVar8;
            }
        }
        if (in_R9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8107;
            uVar5 = func_0x0001801976c0(in_RCX);
            if (in_R9 <= uVar5) {
                piVar3 = *(int32_t **)(in_RCX + 0x18);
                *(undefined *)((int64_t)&arg_28h + iVar7) = in_DL;
                if ((*piVar3 == 0x1ffff) && (*(int32_t *)(in_RCX + 0x9b8) != 0x100)) {
                    *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = 0xfeff;
                } else {
                    *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = *(undefined4 *)(in_RCX + 0x48);
                }
                iVar4 = *(int64_t *)(in_RCX + 0xc70);
                uVar8 = *(undefined8 *)(in_RCX + 0xc80);
                *(undefined8 *)((int64_t)&arg_30h + iVar7) = in_R8;
                *(uint64_t *)((int64_t)&arg_38h + iVar7) = in_R9;
                pcVar2 = *(code **)(iVar4 + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c81a0;
                uVar6 = (*pcVar2)(uVar8, (int64_t)&arg_28h + iVar7, 1);
                *(undefined4 *)((int64_t)&var_18h + iVar7) = 0x2a0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c81bf;
                uVar8 = func_0x0001801a32c0(in_RCX, 1, uVar6, 0x1804b3188);
                if ((int32_t)uVar8 < 1) {
                    return uVar8;
                }
                **(int64_t **)((int64_t)&arg_78h + iVar7) = (int64_t)(int32_t)in_R9;
                return uVar8;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8113;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c812b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8141;
            func_0x00018019b5e0(in_RCX, 0x50, 0xc2, 0);
        }
        uVar8 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c8098;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80b0;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801c80c6;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        uVar8 = 0xffffffff;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1801c81f0
// Address: 0x1801c81f0
// Size: 207 bytes
// ============================================================
undefined8 fcn.1801c81f0(int64_t param_1, undefined8 param_2, int32_t param_3)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c81fc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int32_t *)(param_1 + 0x78) == 0) {
        if (((*(uint32_t *)(param_1 + 0x9a8) & 0x40004) == 0) && (param_3 == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8228;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8240;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)(&stack0x00000048 + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8256;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0;
        }
    } else if (((*(int32_t *)(param_1 + 0xba0) != 0) && ((*(uint32_t *)(param_1 + 0x9a8) >> 0x12 & 1) == 0)) &&
              (param_3 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c827e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8296;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c82ac;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c82c0
// Address: 0x1801c82c0
// Size: 81 bytes
// ============================================================
undefined8 fcn.1801c82c0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c82cc;
    iVar2 = fcn.18045a350();
    if (*(int32_t *)(param_1 + 0x78) != 0) {
        *(undefined4 *)(param_1 + 0xb60) = 0;
        uVar1 = *(undefined8 *)(param_1 + 0xa18);
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801c82fb;
        fcn.180224990(uVar1, 0x1804b3878, 0x3d8);
        *(undefined8 *)(param_1 + 0xa18) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c8320
// Address: 0x1801c8320
// Size: 780 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel

undefined8 fcn.1801c8320(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    int32_t in_R8D;
    undefined8 uVar10;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c833e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar7 = *(undefined8 *)(in_RCX + 0x40);
    iVar9 = *(int64_t *)(in_RCX + 8);
    iVar4 = 3;
    *(undefined4 *)((int64_t)&arg_28h + iVar5) = 0x70;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8361;
    uVar3 = func_0x000180193b40();
    if ((iVar9 == 0) || (iVar2 = *(int64_t *)(in_RCX + 0xb88), iVar2 == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c85e3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
    } else {
        pcVar6 = *(code **)(iVar9 + 0x230);
        if (pcVar6 == (code *)0x0) {
            pcVar6 = *(code **)(iVar2 + 0x230);
            if (pcVar6 != (code *)0x0) {
                uVar10 = *(undefined8 *)(iVar2 + 0x238);
                goto code_r0x0001801c83ac;
            }
        } else {
            uVar10 = *(undefined8 *)(iVar9 + 0x238);
code_r0x0001801c83ac:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c83b6;
            iVar4 = (*pcVar6)(uVar7, (int64_t)&arg_28h + iVar5, uVar10);
        }
        if ((((*(int32_t *)(in_RCX + 0x78) != 0) && (in_R8D != 0)) && (iVar4 == 0)) &&
           (*(int32_t *)(in_RCX + 0x508) == 0)) {
            uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x318);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c83ff;
            fcn.180224990(uVar7, 0x1804b3878, 0x3ff);
            uVar7 = *(undefined8 *)(in_RCX + 0xa18);
            iVar2 = *(int64_t *)(in_RCX + 0x8f8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c841f;
            uVar7 = func_0x0001802231e0(uVar7, 0x1804b3878, 0x400);
            *(undefined8 *)(iVar2 + 0x318) = uVar7;
            if ((*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x318) == 0) && (*(int64_t *)(in_RCX + 0xa18) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8446;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c845e;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8474;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar5));
            }
        }
        if (((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) &&
           ((iVar9 != *(int64_t *)(in_RCX + 0xb88) && (*(int32_t *)(in_RCX + 0x8c8) == 0)))) {
            LOCK();
            *(int32_t *)(iVar9 + 0x84) = *(int32_t *)(iVar9 + 0x84) + 1;
            UNLOCK();
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x84);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
        }
        if (iVar4 != 0) {
            if (iVar4 == 1) {
                if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                    (iVar4 = **(int32_t **)(in_RCX + 0x18), iVar4 < 0x304)) || (iVar4 == 0x10000)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c85cf;
                    fcn.1801c6e50(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                }
code_r0x0001801c85cf:
                *(undefined4 *)(in_RCX + 0xb60) = 0;
                return 1;
            }
            if (iVar4 != 2) {
                if (iVar4 != 3) {
                    return 1;
                }
                goto code_r0x0001801c85cf;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8578;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8590;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            goto code_r0x0001801c8606;
        }
        if (*(int32_t *)(in_RCX + 0xa60) == 0) {
            return 1;
        }
        if ((uVar3 & 0x4000) != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c84d4;
        uVar8 = func_0x000180193b40(in_RCX);
        if ((uVar8 >> 0xe & 1) == 0) {
            return 1;
        }
        *(undefined4 *)(in_RCX + 0xa60) = 0;
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c84f7;
        iVar9 = func_0x00018019ce40(in_RCX);
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8550;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        } else {
            uVar7 = *(undefined8 *)(iVar9 + 800);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8518;
            fcn.180224990(uVar7, 0x1804b3878, 0x41f);
            *(undefined8 *)(iVar9 + 800) = 0;
            *(undefined8 *)(iVar9 + 0x328) = 0;
            *(undefined8 *)(iVar9 + 0x330) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8538;
            iVar4 = func_0x00018019d220(in_RCX, iVar9);
            if (iVar4 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8541;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c85fb;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_38h + iVar5));
code_r0x0001801c8606:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c8611;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801c8630
// Address: 0x1801c8630
// Size: 192 bytes
// ============================================================
undefined8 fcn.1801c8630(int64_t param_1)
{
    char cVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    char *pcVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c863c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((((*(int32_t *)(param_1 + 0x78) == 0) && (*(int64_t *)(param_1 + 0xa70) != 0)) &&
        (*(int64_t *)(param_1 + 0xa68) != 0)) &&
       (((pcVar5 = *(char **)(param_1 + 0xa80), pcVar5 != (char *)0x0 &&
         (uVar2 = *(uint64_t *)(param_1 + 0xa78), uVar2 != 0)) &&
        (((*(uint8_t *)(*(int64_t *)(param_1 + 0x300) + 0x1c) & 4) != 0 ||
         ((*(uint8_t *)(*(int64_t *)(param_1 + 0x300) + 0x20) & 8) != 0)))))) {
        uVar4 = 0;
        do {
            cVar1 = *pcVar5;
            pcVar5 = pcVar5 + 1;
            if (cVar1 == '\0') {
                return 1;
            }
            uVar4 = uVar4 + 1;
        } while (uVar4 < uVar2);
        if (uVar4 == uVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c86af;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c86c7;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c86dd;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c8710
// Address: 0x1801c8710
// Size: 148 bytes
// ============================================================
undefined8 fcn.1801c8710(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c871c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int32_t *)(param_1 + 0x78) != 0) {
        *(undefined4 *)(param_1 + 0xa20) = 0xffffffff;
        return 1;
    }
    uVar1 = *(undefined8 *)(param_1 + 0xa48);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8756;
    fcn.180224990(uVar1, 0x1804b3878, 0x47d);
    uVar1 = *(undefined8 *)(param_1 + 0xa58);
    *(undefined8 *)(param_1 + 0xa48) = 0;
    *(undefined8 *)(param_1 + 0xa50) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c877f;
    fcn.180222290(uVar1, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c878e;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000050 + iVar2));
    *(undefined8 *)(param_1 + 0xa58) = 0;
    return 1;
}

// ============================================================
// Function: FUN_1801c87c0
// Address: 0x1801c87c0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801c87c0(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c87d0;
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(in_RCX + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801c87ef;
    fcn.180224990(uVar1, 0x1804b3878, 0x494);
    *(undefined8 *)(in_RCX + 0x4b8) = 0;
    *(undefined8 *)(in_RCX + 0x4c0) = 0;
    if (*(int32_t *)(in_RCX + 0x78) != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x4c8);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801c881d;
        fcn.180224990(uVar1, 0x1804b3878, 0x498);
        *(undefined8 *)(in_RCX + 0x4c8) = 0;
        *(undefined8 *)(in_RCX + 0x4d0) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c8840
// Address: 0x1801c8840
// Size: 100 bytes
// ============================================================
undefined8
fcn.1801c8840(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint8_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        if ((in_R8D == 0) && (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) != 0)) {
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
        }
        return 1;
    }
    if ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) {
        return 1;
    }
    iVar4 = **(int32_t **)(in_RCX + 0x18);
    if (iVar4 < 0x304) {
        return 1;
    }
    if (iVar4 == 0x10000) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + 0x18) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar8) = 0x1801b9933;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar6 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_68h + iVar5 + iVar8) = 0;
    *(undefined *)((int64_t)&arg_60h + iVar5 + iVar8) = 0;
    pcVar2 = *(code **)(iVar6 + 0x2c0);
    if ((pcVar2 != (code *)0x0) && (*(int64_t *)(in_RCX + 0x4c8) != 0)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar5 + iVar8) = *(undefined8 *)(iVar6 + 0x2c8);
        uVar7 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined4 *)((int64_t)&arg_30h + iVar5 + iVar8) = *(undefined4 *)(in_RCX + 0x4d0);
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9991;
        iVar4 = (*pcVar2)(uVar7, (int64_t)&arg_68h + iVar5 + iVar8, (int64_t)&arg_60h + iVar5 + iVar8);
        if (iVar4 == 0) {
            uVar7 = *(undefined8 *)(in_RCX + 0x4b8);
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b99b2;
            fcn.180224990(uVar7, 0x1804afc90, 0x8b9);
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b99ce;
            iVar6 = fcn.180223170(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8));
            *(int64_t *)(in_RCX + 0x4b8) = iVar6;
            if (iVar6 == 0) {
                *(undefined8 *)(in_RCX + 0x4c0) = 0;
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b99e6;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar8));
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b99fe;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar8), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar8), 
                              *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar8));
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9a14;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8));
                return 0;
            }
            iVar6 = *(int64_t *)(in_RCX + 0x8f8);
            uVar1 = *(uint8_t *)((int64_t)&arg_60h + iVar5 + iVar8);
            *(uint64_t *)(in_RCX + 0x4c0) = (uint64_t)uVar1;
            *(undefined4 *)(in_RCX + 0x4b4) = 0;
            iVar3 = *(int64_t *)(iVar6 + 0x340);
            if ((iVar3 != 0) && ((uint64_t)uVar1 == *(uint64_t *)(iVar6 + 0x348))) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9a60;
                iVar4 = fcn.180497f30(*(undefined8 *)((int64_t)&arg_68h + iVar5 + iVar8), iVar3, uVar1);
                if (iVar4 == 0) {
                    return 1;
                }
            }
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
            if (*(int32_t *)(in_RCX + 0x508) != 0) {
                return 1;
            }
            if (*(int64_t *)(iVar6 + 0x340) != 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9a8a;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar8));
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9aa2;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar8), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar8), 
                              *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar8));
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9ab8;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8));
                return 0;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9ae2;
            uVar7 = fcn.180223170(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8));
            *(undefined8 *)(iVar6 + 0x340) = uVar7;
            if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) != 0) {
                *(uint64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x348) =
                     (uint64_t)*(uint8_t *)((int64_t)&arg_60h + iVar5 + iVar8);
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9afe;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9b16;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar8), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9b2c;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8));
            return 0;
        }
        if (iVar4 != 3) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9b54;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9b6c;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5 + iVar8), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar8) = 0x1801b9b82;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8));
            return 0;
        }
    }
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) != 0) {
        *(undefined4 *)(in_RCX + 0xb1c) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c88b0
// Address: 0x1801c88b0
// Size: 70 bytes
// ============================================================
undefined8 fcn.1801c88b0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c88bc;
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 1000);
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801c88db;
    fcn.180224990(uVar1, 0x1804b3878, 0x4c1);
    *(undefined8 *)(param_1 + 1000) = 0;
    *(undefined8 *)(param_1 + 0x3f8) = 0;
    return 1;
}

// ============================================================
// Function: FUN_1801c8900
// Address: 0x1801c8900
// Size: 70 bytes
// ============================================================
undefined8 fcn.1801c8900(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c890c;
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801c892b;
    fcn.180224990(uVar1, 0x1804b3878, 0x4b6);
    *(undefined8 *)(param_1 + 0x3e0) = 0;
    *(undefined8 *)(param_1 + 0x3f0) = 0;
    return 1;
}

// ============================================================
// Function: FUN_1801c8990
// Address: 0x1801c8990
// Size: 59 bytes
// ============================================================
undefined8 fcn.1801c8990(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c899c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c89b5;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)(param_1 + 0x358) = 0;
    return 1;
}

// ============================================================
// Function: FUN_1801c89d0
// Address: 0x1801c89d0
// Size: 321 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801c89d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c89e5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c89f3;
    iVar3 = fcn.1801ae4b0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8a07;
    iVar1 = fcn.180222010(iVar3);
    if (iVar1 == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8a22;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8a37;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8a49;
            iVar1 = fcn.1801ae110(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8a59;
            iVar1 = fcn.180244000(in_RDX);
            if (iVar1 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8a62;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8a7a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8a90;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8abc;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8ad4;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8aea;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801c8b20
// Address: 0x1801c8b20
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801c8b20(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c8b30;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8b3e;
    iVar1 = fcn.1801ae830(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 != 0) {
        if (*(int64_t *)(in_RDX + 8) == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8b4e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8b66;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8b7c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c8ba0
// Address: 0x1801c8ba0
// Size: 65 bytes
// ============================================================
undefined8 fcn.1801c8ba0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c8bac;
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 0xbf0);
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801c8bcb;
    fcn.180224990(uVar1, 0x1804b3878, 0x4cb);
    *(undefined8 *)(param_1 + 0xbf0) = 0;
    return 1;
}

// ============================================================
// Function: FUN_1801c8bf0
// Address: 0x1801c8bf0
// Size: 70 bytes
// ============================================================
undefined8 fcn.1801c8bf0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c8bfc;
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 0xa80);
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801c8c1b;
    fcn.180224990(uVar1, 0x1804b3878, 0x4d4);
    *(undefined8 *)(param_1 + 0xa80) = 0;
    *(undefined8 *)(param_1 + 0xa78) = 0;
    return 1;
}

// ============================================================
// Function: FUN_1801c8c70
// Address: 0x1801c8c70
// Size: 213 bytes
// ============================================================
undefined8 fcn.1801c8c70(int64_t param_1)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c8c7c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar2 = *(uint32_t *)(param_1 + 0x160) & 0x200;
    if ((uVar2 == 0) && ((*(uint32_t *)(param_1 + 0x160) >> 0xc & 1) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8c9d;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8cb5;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8ccb;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    if ((*(int32_t *)(param_1 + 0x78) == 0) &&
       ((*(int32_t *)(param_1 + 0x508) != 0 &&
        ((uint32_t)(uVar2 == 0) != (~*(uint32_t *)(*(int64_t *)(param_1 + 0x8f8) + 0x370) & 1))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8d04;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8d1c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c8d32;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c8d60
// Address: 0x1801c8d60
// Size: 561 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801c8d60(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint32_t in_EDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c8d70;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) {
        return 1;
    }
    iVar1 = **(int32_t **)(in_RCX + 0x18);
    if (iVar1 < 0x304) {
        return 1;
    }
    if (iVar1 == 0x10000) {
        return 1;
    }
    if ((in_EDX >> 0xb & 1) != 0) {
        return 1;
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        if (in_R8D != 0) {
            return 1;
        }
        if ((*(uint8_t *)(in_RCX + 0xb10) & 1) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8dd1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8de9;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            goto code_r0x0001801c8df4;
        }
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8e1a;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8e32;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            goto code_r0x0001801c8df4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8e46;
        iVar1 = fcn.1801b3c40(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
        if (iVar1 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8e53;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    } else if (*(int64_t *)(in_RCX + 0x4e0) == 0) {
        if ((((*(int32_t *)(in_RCX + 0x8c8) == 0) && (in_R8D != 0)) &&
            ((*(int32_t *)(in_RCX + 0x508) == 0 || ((*(uint8_t *)(in_RCX + 0xb10) & 2) != 0)))) &&
           (*(int16_t *)(in_RCX + 0x4e8) != 0)) {
            *(int16_t *)(in_RCX + 0x4de) = *(int16_t *)(in_RCX + 0x4e8);
code_r0x0001801c8ee9:
            *(undefined4 *)(in_RCX + 0x8c8) = 1;
            return 1;
        }
        if ((*(int32_t *)(in_RCX + 0x508) == 0) || ((*(uint8_t *)(in_RCX + 0xb10) & 1) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8f65;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8f7d;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            goto code_r0x0001801c8df4;
        }
        if (((*(uint32_t *)(in_RCX + 0x160) & 0x800) == 0) || (*(int32_t *)(in_RCX + 0xb30) != 0))
        goto code_r0x0001801c8f3d;
        if (*(int32_t *)(in_RCX + 0x8c8) == 0) goto code_r0x0001801c8ee9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8f33;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    } else {
        if (((*(uint32_t *)(in_RCX + 0x160) & 0x800) == 0) || (*(int32_t *)(in_RCX + 0xb30) != 0)) {
code_r0x0001801c8f3d:
            if (*(int32_t *)(in_RCX + 0x8c8) != 1) {
                return 1;
            }
            *(undefined4 *)(in_RCX + 0x8c8) = 2;
            return 1;
        }
        if (*(int32_t *)(in_RCX + 0x8c8) == 0) goto code_r0x0001801c8ee9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8eb0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8e6b;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
code_r0x0001801c8df4:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c8dff;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801c8fc0
// Address: 0x1801c8fc0
// Size: 135 bytes
// ============================================================
undefined8 fcn.1801c8fc0(int64_t param_1, undefined8 param_2, int32_t param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c8fcc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((param_3 == 0) && ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(param_1 + 0x18) + 0x36) + 0x50) & 8) == 0)) &&
        (iVar1 = **(int32_t **)(param_1 + 0x18), 0x303 < iVar1)) &&
       ((iVar1 != 0x10000 && (*(int32_t *)(param_1 + 0x508) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c9006;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c901e;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c9034;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c9050
// Address: 0x1801c9050
// Size: 101 bytes
// ============================================================
undefined8 fcn.1801c9050(undefined8 param_1, int32_t param_2, int32_t param_3)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c905c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((param_3 == 0) && (param_2 == 0x800)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c9074;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c908c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c90a2;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c90c0
// Address: 0x1801c90c0
// Size: 250 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h

bool fcn.1801c90c0(int64_t param_1, int32_t param_2, int32_t param_3)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c90cc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (param_3 != 0) {
        if (*(int32_t *)(param_1 + 0x78) == 0) {
            if ((param_2 == 0x400) && (*(int32_t *)(param_1 + 0xb1c) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c90ff;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c9117;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c912d;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
                return false;
            }
        } else {
            if ((((*(int32_t *)(param_1 + 0x1538) != 0) && (*(int32_t *)(param_1 + 0x508) != 0)) &&
                (*(int32_t *)(param_1 + 0xf0) == 9)) &&
               ((*(int32_t *)(param_1 + 0xb1c) != 0 && (*(int32_t *)(param_1 + 0x8c8) == 0)))) {
                pcVar1 = *(code **)(param_1 + 0x1560);
                if (pcVar1 == (code *)0x0) {
code_r0x0001801c917f:
                    *(undefined4 *)(param_1 + 0xb18) = 2;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c9196;
                    iVar4 = fcn.1801b2cf0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5)
                                          , *(int64_t *)(&stack0x00000038 + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x000001f8 + iVar5)
                                         );
                    return iVar4 != 0;
                }
                uVar2 = *(undefined8 *)(param_1 + 0x1568);
                uVar3 = *(undefined8 *)(param_1 + 0x40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c917b;
                iVar4 = (*pcVar1)(uVar3, uVar2);
                if (iVar4 != 0) goto code_r0x0001801c917f;
            }
            *(undefined4 *)(param_1 + 0xb18) = 1;
        }
    }
    return true;
}

// ============================================================
// Function: FUN_1801c91c0
// Address: 0x1801c91c0
// Size: 81 bytes
// ============================================================
undefined8 fcn.1801c91c0(int64_t arg_28h)
{
    char cVar1;
    int64_t iVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c91cc;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)(in_RCX + 0x8f8);
    if (iVar2 != 0) {
        if (*(char *)(iVar2 + 0x350) == -1) {
            *(undefined *)(iVar2 + 0x350) = 0;
        }
        cVar1 = *(char *)(*(int64_t *)(in_RCX + 0x8f8) + 0x350);
        if ((uint8_t)(cVar1 - 1U) < 4) {
            iVar2 = *(int64_t *)(in_RCX + 0xc68);
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            uVar3 = *(undefined8 *)(in_RCX + 0xc78);
            pcVar4 = *(code **)(iVar2 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c9229;
            (*pcVar4)(uVar3, 0x200 << (cVar1 - 1U & 0x1f));
            iVar2 = *(int64_t *)(in_RCX + 0xc70);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c9238;
            uVar5 = func_0x0001801976c0(in_RCX);
            uVar3 = *(undefined8 *)(in_RCX + 0xc80);
            pcVar4 = *(code **)(iVar2 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c924a;
            (*pcVar4)(uVar3, uVar5);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c9211
// Address: 0x1801c9211
// Size: 62 bytes
// ============================================================
undefined8 fcn.1801c91c0(int64_t arg_28h)
{
    char cVar1;
    int64_t iVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c91cc;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)(in_RCX + 0x8f8);
    if (iVar2 != 0) {
        if (*(char *)(iVar2 + 0x350) == -1) {
            *(undefined *)(iVar2 + 0x350) = 0;
        }
        cVar1 = *(char *)(*(int64_t *)(in_RCX + 0x8f8) + 0x350);
        if ((uint8_t)(cVar1 - 1U) < 4) {
            iVar2 = *(int64_t *)(in_RCX + 0xc68);
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            uVar3 = *(undefined8 *)(in_RCX + 0xc78);
            pcVar4 = *(code **)(iVar2 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c9229;
            (*pcVar4)(uVar3, 0x200 << (cVar1 - 1U & 0x1f));
            iVar2 = *(int64_t *)(in_RCX + 0xc70);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c9238;
            uVar5 = func_0x0001801976c0(in_RCX);
            uVar3 = *(undefined8 *)(in_RCX + 0xc80);
            pcVar4 = *(code **)(iVar2 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c924a;
            (*pcVar4)(uVar3, uVar5);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c924f
// Address: 0x1801c924f
// Size: 11 bytes
// ============================================================
undefined8 fcn.1801c91c0(int64_t arg_28h)
{
    char cVar1;
    int64_t iVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c91cc;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *(int64_t *)(in_RCX + 0x8f8);
    if (iVar2 != 0) {
        if (*(char *)(iVar2 + 0x350) == -1) {
            *(undefined *)(iVar2 + 0x350) = 0;
        }
        cVar1 = *(char *)(*(int64_t *)(in_RCX + 0x8f8) + 0x350);
        if ((uint8_t)(cVar1 - 1U) < 4) {
            iVar2 = *(int64_t *)(in_RCX + 0xc68);
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
            uVar3 = *(undefined8 *)(in_RCX + 0xc78);
            pcVar4 = *(code **)(iVar2 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c9229;
            (*pcVar4)(uVar3, 0x200 << (cVar1 - 1U & 0x1f));
            iVar2 = *(int64_t *)(in_RCX + 0xc70);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c9238;
            uVar5 = func_0x0001801976c0(in_RCX);
            uVar3 = *(undefined8 *)(in_RCX + 0xc80);
            pcVar4 = *(code **)(iVar2 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c924a;
            (*pcVar4)(uVar3, uVar5);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c9270
// Address: 0x1801c9270
// Size: 127 bytes
// ============================================================
undefined8 fcn.1801c9270(int64_t param_1, undefined8 param_2, int32_t param_3)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c927c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((((*(int32_t *)(param_1 + 0x78) != 0) && (param_3 != 0)) && (*(int64_t *)(param_1 + 0xb58) != 0)) &&
       (*(int32_t *)(*(int64_t *)(*(int64_t *)(param_1 + 0xb58) + 0x288) + 0x330) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c92ae;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c92c6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c92dc;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c93d0
// Address: 0x1801c93d0
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801c93d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint32_t in_EDX;
    uint32_t in_R8D;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c93ea;
    iVar2 = fcn.18045a350();
    if ((in_R8D & in_EDX) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801c9402;
        iVar1 = func_0x0001801c9310();
        if (iVar1 != 0) {
            if (((in_EDX & 0x20) == 0) || (-1 < (char)in_R8D)) {
                return true;
            }
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                return 0x303 < in_R9D;
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801c9450
// Address: 0x1801c9450
// Size: 209 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a10h because it doesn't fit into ProtoModel

undefined8
fcn.1801c9450(int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_78h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h)
{
    uint32_t uVar1;
    undefined *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t in_RCX;
    uint64_t uVar15;
    undefined8 *in_RDX;
    uint64_t uVar16;
    uint32_t uVar17;
    undefined8 unaff_RBX;
    uint64_t uVar18;
    undefined8 unaff_RDI;
    uint32_t uVar19;
    uint64_t in_R8;
    undefined8 *puVar20;
    undefined8 unaff_R13;
    uint64_t uVar21;
    int64_t iVar22;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801c9467;
    var_20h = arg4;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x878);
    uVar18 = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar10) = unaff_XMM6_Da;
    *(undefined4 *)((int64_t)&arg_48h + iVar10 + 4) = unaff_XMM6_Db;
    *(undefined4 *)(&stack0x00000050 + iVar10) = unaff_XMM6_Dc;
    *(undefined4 *)(&stack0x00000054 + iVar10) = unaff_XMM6_Dd;
    iVar22 = iVar11 + 0x80;
    uVar14 = *in_RDX;
    uVar16 = in_RDX[1];
    uVar19 = (uint32_t)in_R8;
    *(undefined8 *)arg4 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = uVar14;
    *(uint64_t *)((int64_t)&var_20h + iVar10) = uVar16;
    if ((in_R8 & 0x80) != 0) {
        iVar13 = *(int64_t *)(in_RCX + 0x878);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c94a9;
        func_0x00018019ac20(iVar13 + 0x80);
    }
    uVar21 = uVar18;
    if (iVar22 != 0) {
        uVar21 = *(uint64_t *)(iVar11 + 0x88);
    }
    *(uint64_t *)((int64_t)&iStackX_10 + iVar10 + -8) = uVar21 + 0x1d;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c94da;
    iVar11 = func_0x000180224e40(uVar21 + 0x1d, 0x28, 0x1804b3878, 0x276);
    *(int64_t *)((int64_t)&arg_98h + iVar10) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c94ec;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9504;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar10 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar10), 
                      *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c951a;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar10));
        uVar14 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_a8h + iVar10) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_60h + iVar10) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_58h + iVar10) = unaff_R13;
        uVar21 = uVar18;
        if (uVar16 == 0) {
code_r0x0001801c9865:
            if (*(int32_t *)((int64_t)&arg_c0h + iVar10) != 0) {
                puVar12 = (uint32_t *)0x1804b3204;
                do {
                    pcVar3 = *(code **)(puVar12 + 1);
                    if ((pcVar3 != (code *)0x0) && (uVar17 = *puVar12, (uVar19 & uVar17) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9890;
                        iVar9 = func_0x0001801c9310(in_RCX, uVar17, in_R8 & 0xffffffff);
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c989c;
                            iVar9 = (*pcVar3)(in_RCX, in_R8 & 0xffffffff);
                            if (iVar9 == 0) goto code_r0x0001801c981d;
                        }
                    }
                    uVar18 = uVar18 + 1;
                    puVar12 = puVar12 + 0xe;
                } while (uVar18 < 0x1d);
            }
            **(undefined8 **)((int64_t)&arg_b0h + iVar10) = *(undefined8 *)((int64_t)&arg_98h + iVar10);
            if (*(undefined8 **)((int64_t)&arg_b8h + iVar10) != (undefined8 *)0x0) {
                **(undefined8 **)((int64_t)&arg_b8h + iVar10) = *(undefined8 *)((int64_t)&iStackX_10 + iVar10 + -8);
            }
            uVar14 = 1;
        } else {
            while (1 < uVar16) {
                puVar2 = *(undefined **)((int64_t)&var_18h + iVar10);
                *(uint64_t *)((int64_t)&var_20h + iVar10) = uVar16 - 2;
                uVar17 = (uint32_t)CONCAT11(*puVar2, puVar2[1]);
                if (uVar16 - 2 < 2) break;
                uVar16 = uVar16 - 4;
                uVar15 = (uint64_t)CONCAT11(puVar2[2], puVar2[3]);
                *(uint64_t *)((int64_t)&arg_30h + iVar10) = uVar16;
                if (uVar16 < uVar15) break;
                *(undefined **)((int64_t)&arg_38h + iVar10) = puVar2 + 4;
                *(undefined **)((int64_t)&arg_28h + iVar10) = puVar2 + 4 + uVar15;
                iVar11 = uVar16 - uVar15;
                *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
                puVar12 = (uint32_t *)0x1804b3200;
                uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                uVar6 = *(undefined4 *)((int64_t)&arg_30h + iVar10);
                uVar7 = *(undefined4 *)((int64_t)&arg_30h + iVar10 + 4);
                *(undefined4 *)((int64_t)&var_18h + iVar10) = *(undefined4 *)((int64_t)&arg_28h + iVar10);
                *(undefined4 *)((int64_t)&var_18h + iVar10 + 4) = uVar5;
                *(undefined4 *)((int64_t)&var_20h + iVar10) = uVar6;
                *(undefined4 *)((int64_t)&var_20h + iVar10 + 4) = uVar7;
                *(uint64_t *)((int64_t)&arg_40h + iVar10) = uVar15;
                uVar16 = uVar18;
                do {
                    if (uVar17 == *puVar12) {
                        uVar1 = puVar12[1];
                        if ((uVar19 & uVar1) == 0) goto code_r0x0001801c97ea;
                        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                            uVar1 = uVar1 & 2;
                        } else {
                            uVar1 = uVar1 & 1;
                        }
                        if (uVar1 != 0) goto code_r0x0001801c97ea;
                        goto code_r0x0001801c96c2;
                    }
                    uVar16 = uVar16 + 1;
                    puVar12 = puVar12 + 0xe;
                } while (uVar16 < 0x1d);
                if (iVar22 != 0) {
                    *(undefined8 *)((int64_t)&arg_a0h + iVar10) = 0;
                    if ((in_R8 & 0x80) == 0) {
                        uVar16 = 2;
                        if ((uVar19 >> 8 & 1) != 0) {
                            uVar16 = uVar18;
                        }
                    } else {
                        uVar16 = 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9635;
                    iVar13 = func_0x00018019aba0(iVar22, uVar16, uVar17, (int64_t)&arg_a0h + iVar10);
                    if (iVar13 == 0) goto code_r0x0001801c9687;
                    uVar1 = *(uint32_t *)(iVar13 + 8);
                    if ((uVar19 & uVar1) != 0) {
                        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                            uVar1 = uVar1 & 2;
                        } else {
                            uVar1 = uVar1 & 1;
                        }
                        if (uVar1 != 0) goto code_r0x0001801c97ea;
                        uVar16 = *(int64_t *)((int64_t)&arg_a0h + iVar10) + 0x1d;
code_r0x0001801c96c2:
                        iVar13 = *(int64_t *)((int64_t)&arg_98h + iVar10);
                        puVar20 = (undefined8 *)(iVar13 + uVar16 * 0x28);
                        if ((puVar20 != (undefined8 *)0x0) && (*(int32_t *)(puVar20 + 2) == 1))
                        goto code_r0x0001801c97ea;
                        goto code_r0x0001801c96e2;
                    }
code_r0x0001801c97ea:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c97ef;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9807;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar10 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10))
                    ;
                    goto code_r0x0001801c9815;
                }
code_r0x0001801c9687:
                iVar13 = *(int64_t *)((int64_t)&arg_98h + iVar10);
                puVar20 = (undefined8 *)0x0;
code_r0x0001801c96e2:
                if (((uVar17 == 0x29) && ((in_R8 & 0x80) != 0)) && (iVar11 != 0)) goto code_r0x0001801c97ea;
                uVar16 = ((int64_t)puVar20 - iVar13) / 0x28;
                if ((((((uint32_t)uVar16 < 0x1d) && ((in_R8 & 0x6080) == 0)) &&
                     ((uVar17 != 0x2c && ((uVar17 != 0xff01 && (uVar17 != 0x12)))))) &&
                    ((*(uint8_t *)((uVar16 & 0xffffffff) + 0x9e8 + in_RCX) & 2) == 0)) &&
                   (((uVar19 >> 8 & 1) == 0 || (uVar17 != 65000)))) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c97c2;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c97da;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar10 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10))
                    ;
                    goto code_r0x0001801c9815;
                }
                if (puVar20 != (undefined8 *)0x0) {
                    uVar5 = *(undefined4 *)((int64_t)&arg_38h + iVar10);
                    uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar10 + 4);
                    uVar7 = *(undefined4 *)((int64_t)&arg_40h + iVar10);
                    uVar8 = *(undefined4 *)((int64_t)&arg_40h + iVar10 + 4);
                    puVar20[4] = uVar21;
                    uVar21 = uVar21 + 1;
                    *(undefined4 *)(puVar20 + 2) = 1;
                    *(undefined4 *)puVar20 = uVar5;
                    *(undefined4 *)((int64_t)puVar20 + 4) = uVar6;
                    *(undefined4 *)(puVar20 + 1) = uVar7;
                    *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar8;
                    *(uint32_t *)(puVar20 + 3) = uVar17;
                    pcVar3 = *(code **)(in_RCX + 0xa08);
                    if (pcVar3 != (code *)0x0) {
                        iVar9 = *(int32_t *)(in_RCX + 0x78);
                        uVar14 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)(&stack0x00000000 + iVar10) = *(undefined8 *)(in_RCX + 0xa10);
                        uVar4 = *puVar20;
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = *(undefined4 *)(puVar20 + 1);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c97a0;
                        (*pcVar3)(uVar14, iVar9 == 0, uVar17, uVar4);
                    }
                }
                if (iVar11 == 0) goto code_r0x0001801c9865;
                uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar10);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9843;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c985b;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar10 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar10)
                          , *(int64_t *)((int64_t)&arg_28h + iVar10));
code_r0x0001801c9815:
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c981d;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar10));
code_r0x0001801c981d:
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9837;
            fcn.180224990(*(undefined8 *)((int64_t)&arg_98h + iVar10), 0x1804b3878, 0x2d7);
            uVar14 = 0;
        }
    }
    return uVar14;
}

// ============================================================
// Function: FUN_1801c9521
// Address: 0x1801c9521
// Size: 981 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a10h because it doesn't fit into ProtoModel

undefined8
fcn.1801c9450(int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_78h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h)
{
    uint32_t uVar1;
    undefined *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t in_RCX;
    uint64_t uVar15;
    undefined8 *in_RDX;
    uint64_t uVar16;
    uint32_t uVar17;
    undefined8 unaff_RBX;
    uint64_t uVar18;
    undefined8 unaff_RDI;
    uint32_t uVar19;
    uint64_t in_R8;
    undefined8 *puVar20;
    undefined8 unaff_R13;
    uint64_t uVar21;
    int64_t iVar22;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801c9467;
    var_20h = arg4;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x878);
    uVar18 = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar10) = unaff_XMM6_Da;
    *(undefined4 *)((int64_t)&arg_48h + iVar10 + 4) = unaff_XMM6_Db;
    *(undefined4 *)(&stack0x00000050 + iVar10) = unaff_XMM6_Dc;
    *(undefined4 *)(&stack0x00000054 + iVar10) = unaff_XMM6_Dd;
    iVar22 = iVar11 + 0x80;
    uVar14 = *in_RDX;
    uVar16 = in_RDX[1];
    uVar19 = (uint32_t)in_R8;
    *(undefined8 *)arg4 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = uVar14;
    *(uint64_t *)((int64_t)&var_20h + iVar10) = uVar16;
    if ((in_R8 & 0x80) != 0) {
        iVar13 = *(int64_t *)(in_RCX + 0x878);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c94a9;
        func_0x00018019ac20(iVar13 + 0x80);
    }
    uVar21 = uVar18;
    if (iVar22 != 0) {
        uVar21 = *(uint64_t *)(iVar11 + 0x88);
    }
    *(uint64_t *)((int64_t)&iStackX_10 + iVar10 + -8) = uVar21 + 0x1d;
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c94da;
    iVar11 = func_0x000180224e40(uVar21 + 0x1d, 0x28, 0x1804b3878, 0x276);
    *(int64_t *)((int64_t)&arg_98h + iVar10) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c94ec;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9504;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar10 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar10), 
                      *(int64_t *)((int64_t)&arg_28h + iVar10));
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c951a;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar10));
        uVar14 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_a8h + iVar10) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_60h + iVar10) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_58h + iVar10) = unaff_R13;
        uVar21 = uVar18;
        if (uVar16 == 0) {
code_r0x0001801c9865:
            if (*(int32_t *)((int64_t)&arg_c0h + iVar10) != 0) {
                puVar12 = (uint32_t *)0x1804b3204;
                do {
                    pcVar3 = *(code **)(puVar12 + 1);
                    if ((pcVar3 != (code *)0x0) && (uVar17 = *puVar12, (uVar19 & uVar17) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9890;
                        iVar9 = func_0x0001801c9310(in_RCX, uVar17, in_R8 & 0xffffffff);
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c989c;
                            iVar9 = (*pcVar3)(in_RCX, in_R8 & 0xffffffff);
                            if (iVar9 == 0) goto code_r0x0001801c981d;
                        }
                    }
                    uVar18 = uVar18 + 1;
                    puVar12 = puVar12 + 0xe;
                } while (uVar18 < 0x1d);
            }
            **(undefined8 **)((int64_t)&arg_b0h + iVar10) = *(undefined8 *)((int64_t)&arg_98h + iVar10);
            if (*(undefined8 **)((int64_t)&arg_b8h + iVar10) != (undefined8 *)0x0) {
                **(undefined8 **)((int64_t)&arg_b8h + iVar10) = *(undefined8 *)((int64_t)&iStackX_10 + iVar10 + -8);
            }
            uVar14 = 1;
        } else {
            while (1 < uVar16) {
                puVar2 = *(undefined **)((int64_t)&var_18h + iVar10);
                *(uint64_t *)((int64_t)&var_20h + iVar10) = uVar16 - 2;
                uVar17 = (uint32_t)CONCAT11(*puVar2, puVar2[1]);
                if (uVar16 - 2 < 2) break;
                uVar16 = uVar16 - 4;
                uVar15 = (uint64_t)CONCAT11(puVar2[2], puVar2[3]);
                *(uint64_t *)((int64_t)&arg_30h + iVar10) = uVar16;
                if (uVar16 < uVar15) break;
                *(undefined **)((int64_t)&arg_38h + iVar10) = puVar2 + 4;
                *(undefined **)((int64_t)&arg_28h + iVar10) = puVar2 + 4 + uVar15;
                iVar11 = uVar16 - uVar15;
                *(int64_t *)((int64_t)&arg_30h + iVar10) = iVar11;
                puVar12 = (uint32_t *)0x1804b3200;
                uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                uVar6 = *(undefined4 *)((int64_t)&arg_30h + iVar10);
                uVar7 = *(undefined4 *)((int64_t)&arg_30h + iVar10 + 4);
                *(undefined4 *)((int64_t)&var_18h + iVar10) = *(undefined4 *)((int64_t)&arg_28h + iVar10);
                *(undefined4 *)((int64_t)&var_18h + iVar10 + 4) = uVar5;
                *(undefined4 *)((int64_t)&var_20h + iVar10) = uVar6;
                *(undefined4 *)((int64_t)&var_20h + iVar10 + 4) = uVar7;
                *(uint64_t *)((int64_t)&arg_40h + iVar10) = uVar15;
                uVar16 = uVar18;
                do {
                    if (uVar17 == *puVar12) {
                        uVar1 = puVar12[1];
                        if ((uVar19 & uVar1) == 0) goto code_r0x0001801c97ea;
                        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                            uVar1 = uVar1 & 2;
                        } else {
                            uVar1 = uVar1 & 1;
                        }
                        if (uVar1 != 0) goto code_r0x0001801c97ea;
                        goto code_r0x0001801c96c2;
                    }
                    uVar16 = uVar16 + 1;
                    puVar12 = puVar12 + 0xe;
                } while (uVar16 < 0x1d);
                if (iVar22 != 0) {
                    *(undefined8 *)((int64_t)&arg_a0h + iVar10) = 0;
                    if ((in_R8 & 0x80) == 0) {
                        uVar16 = 2;
                        if ((uVar19 >> 8 & 1) != 0) {
                            uVar16 = uVar18;
                        }
                    } else {
                        uVar16 = 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9635;
                    iVar13 = func_0x00018019aba0(iVar22, uVar16, uVar17, (int64_t)&arg_a0h + iVar10);
                    if (iVar13 == 0) goto code_r0x0001801c9687;
                    uVar1 = *(uint32_t *)(iVar13 + 8);
                    if ((uVar19 & uVar1) != 0) {
                        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                            uVar1 = uVar1 & 2;
                        } else {
                            uVar1 = uVar1 & 1;
                        }
                        if (uVar1 != 0) goto code_r0x0001801c97ea;
                        uVar16 = *(int64_t *)((int64_t)&arg_a0h + iVar10) + 0x1d;
code_r0x0001801c96c2:
                        iVar13 = *(int64_t *)((int64_t)&arg_98h + iVar10);
                        puVar20 = (undefined8 *)(iVar13 + uVar16 * 0x28);
                        if ((puVar20 != (undefined8 *)0x0) && (*(int32_t *)(puVar20 + 2) == 1))
                        goto code_r0x0001801c97ea;
                        goto code_r0x0001801c96e2;
                    }
code_r0x0001801c97ea:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c97ef;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9807;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar10 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10))
                    ;
                    goto code_r0x0001801c9815;
                }
code_r0x0001801c9687:
                iVar13 = *(int64_t *)((int64_t)&arg_98h + iVar10);
                puVar20 = (undefined8 *)0x0;
code_r0x0001801c96e2:
                if (((uVar17 == 0x29) && ((in_R8 & 0x80) != 0)) && (iVar11 != 0)) goto code_r0x0001801c97ea;
                uVar16 = ((int64_t)puVar20 - iVar13) / 0x28;
                if ((((((uint32_t)uVar16 < 0x1d) && ((in_R8 & 0x6080) == 0)) &&
                     ((uVar17 != 0x2c && ((uVar17 != 0xff01 && (uVar17 != 0x12)))))) &&
                    ((*(uint8_t *)((uVar16 & 0xffffffff) + 0x9e8 + in_RCX) & 2) == 0)) &&
                   (((uVar19 >> 8 & 1) == 0 || (uVar17 != 65000)))) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c97c2;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c97da;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)(&stack0x00000000 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar10 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar10), *(int64_t *)((int64_t)&arg_28h + iVar10))
                    ;
                    goto code_r0x0001801c9815;
                }
                if (puVar20 != (undefined8 *)0x0) {
                    uVar5 = *(undefined4 *)((int64_t)&arg_38h + iVar10);
                    uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar10 + 4);
                    uVar7 = *(undefined4 *)((int64_t)&arg_40h + iVar10);
                    uVar8 = *(undefined4 *)((int64_t)&arg_40h + iVar10 + 4);
                    puVar20[4] = uVar21;
                    uVar21 = uVar21 + 1;
                    *(undefined4 *)(puVar20 + 2) = 1;
                    *(undefined4 *)puVar20 = uVar5;
                    *(undefined4 *)((int64_t)puVar20 + 4) = uVar6;
                    *(undefined4 *)(puVar20 + 1) = uVar7;
                    *(undefined4 *)((int64_t)puVar20 + 0xc) = uVar8;
                    *(uint32_t *)(puVar20 + 3) = uVar17;
                    pcVar3 = *(code **)(in_RCX + 0xa08);
                    if (pcVar3 != (code *)0x0) {
                        iVar9 = *(int32_t *)(in_RCX + 0x78);
                        uVar14 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)(&stack0x00000000 + iVar10) = *(undefined8 *)(in_RCX + 0xa10);
                        uVar4 = *puVar20;
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = *(undefined4 *)(puVar20 + 1);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c97a0;
                        (*pcVar3)(uVar14, iVar9 == 0, uVar17, uVar4);
                    }
                }
                if (iVar11 == 0) goto code_r0x0001801c9865;
                uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar10);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9843;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c985b;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), *(int64_t *)(&stack0x00000000 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar10 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar10)
                          , *(int64_t *)((int64_t)&arg_28h + iVar10));
code_r0x0001801c9815:
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c981d;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar10));
code_r0x0001801c981d:
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1801c9837;
            fcn.180224990(*(undefined8 *)((int64_t)&arg_98h + iVar10), 0x1804b3878, 0x2d7);
            uVar14 = 0;
        }
    }
    return uVar14;
}

