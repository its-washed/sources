// Chunk 120 - 50 functions

// ============================================================
// Function: FUN_18019c667
// Address: 0x18019c667
// Size: 205 bytes
// ============================================================
int32_t fcn.18019c667(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int32_t unaff_R12D;
    
    do {
        iVar1 = *(int64_t *)(unaff_RBX + 0x48);
        if ((iVar1 == 0) || (*(int64_t *)(iVar1 + 0x250) == 0)) break;
        iVar4 = func_0x000180229240(*(undefined8 *)(unaff_RBX + 0x30), iVar1);
        iVar2 = 0;
        if (iVar4 != 0) {
            iVar4 = func_0x000180228b10(*(undefined8 *)(unaff_RBX + 0x30), iVar4);
            func_0x00018019cc80();
            iVar2 = unaff_R12D;
        }
        *(int32_t *)(iVar1 + 0x2b0) = unaff_R12D;
        if (*(code **)(unaff_RBX + 0x68) != (code *)0x0) {
            (**(code **)(unaff_RBX + 0x68))();
        }
        if (iVar2 == 0) break;
        func_0x00018019c980(iVar4);
        LOCK();
        *(int32_t *)(unaff_RBX + 0x98) = *(int32_t *)(unaff_RBX + 0x98) + 1;
        UNLOCK();
        iVar2 = func_0x000180191a20();
        iVar3 = func_0x000180191a20();
    } while (iVar2 <= iVar3);
    func_0x00018019cb50();
    if (unaff_RBP != 0) {
        func_0x00018019c980();
        unaff_R12D = 0;
    }
    func_0x000180222910(*(undefined8 *)(unaff_RBX + 0x3e0));
    return unaff_R12D;
}

// ============================================================
// Function: FUN_18019c734
// Address: 0x18019c734
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_48h
// WARNING: Variable defined which should be unmapped: arg_58h

int32_t fcn.18019c667(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int32_t unaff_R12D;
    
    do {
        iVar1 = *(int64_t *)(unaff_RBX + 0x48);
        if ((iVar1 == 0) || (*(int64_t *)(iVar1 + 0x250) == 0)) break;
        iVar4 = func_0x000180229240(*(undefined8 *)(unaff_RBX + 0x30), iVar1);
        iVar2 = 0;
        if (iVar4 != 0) {
            iVar4 = func_0x000180228b10(*(undefined8 *)(unaff_RBX + 0x30), iVar4);
            func_0x00018019cc80();
            iVar2 = unaff_R12D;
        }
        *(int32_t *)(iVar1 + 0x2b0) = unaff_R12D;
        if (*(code **)(unaff_RBX + 0x68) != (code *)0x0) {
            (**(code **)(unaff_RBX + 0x68))();
        }
        if (iVar2 == 0) break;
        func_0x00018019c980(iVar4);
        LOCK();
        *(int32_t *)(unaff_RBX + 0x98) = *(int32_t *)(unaff_RBX + 0x98) + 1;
        UNLOCK();
        iVar2 = func_0x000180191a20();
        iVar3 = func_0x000180191a20();
    } while (iVar2 <= iVar3);
    func_0x00018019cb50();
    if (unaff_RBP != 0) {
        func_0x00018019c980();
        unaff_R12D = 0;
    }
    func_0x000180222910(*(undefined8 *)(unaff_RBX + 0x3e0));
    return unaff_R12D;
}

// ============================================================
// Function: FUN_18019c739
// Address: 0x18019c739
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_48h
// WARNING: Variable defined which should be unmapped: arg_58h

int32_t fcn.18019c667(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int32_t unaff_R12D;
    
    do {
        iVar1 = *(int64_t *)(unaff_RBX + 0x48);
        if ((iVar1 == 0) || (*(int64_t *)(iVar1 + 0x250) == 0)) break;
        iVar4 = func_0x000180229240(*(undefined8 *)(unaff_RBX + 0x30), iVar1);
        iVar2 = 0;
        if (iVar4 != 0) {
            iVar4 = func_0x000180228b10(*(undefined8 *)(unaff_RBX + 0x30), iVar4);
            func_0x00018019cc80();
            iVar2 = unaff_R12D;
        }
        *(int32_t *)(iVar1 + 0x2b0) = unaff_R12D;
        if (*(code **)(unaff_RBX + 0x68) != (code *)0x0) {
            (**(code **)(unaff_RBX + 0x68))();
        }
        if (iVar2 == 0) break;
        func_0x00018019c980(iVar4);
        LOCK();
        *(int32_t *)(unaff_RBX + 0x98) = *(int32_t *)(unaff_RBX + 0x98) + 1;
        UNLOCK();
        iVar2 = func_0x000180191a20();
        iVar3 = func_0x000180191a20();
    } while (iVar2 <= iVar3);
    func_0x00018019cb50();
    if (unaff_RBP != 0) {
        func_0x00018019c980();
        unaff_R12D = 0;
    }
    func_0x000180222910(*(undefined8 *)(unaff_RBX + 0x3e0));
    return unaff_R12D;
}

// ============================================================
// Function: FUN_18019c780
// Address: 0x18019c780
// Size: 51 bytes
// ============================================================
void fcn.18019c780(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019c78f;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    uVar7 = *(undefined8 *)(in_RCX + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7ab;
    iVar3 = func_0x000180222950(uVar7);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7c7;
        iVar6 = func_0x000180221f20();
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7d3;
        uVar4 = func_0x000180228fa0(uVar7);
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7e1;
        func_0x000180229280(uVar7, 0);
        iVar1 = *(int64_t *)(in_RCX + 0x48);
        while ((iVar1 != 0 &&
               ((in_RDX == 0 ||
                (*(uint64_t *)(iVar1 + 0x2e8) <= (uint64_t)(in_RDX * 1000000000) &&
                 in_RDX * 1000000000 - *(uint64_t *)(iVar1 + 0x2e8) != 0))))) {
            uVar7 = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c80a;
            func_0x000180228b10(uVar7, iVar1);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c815;
            func_0x00018019cc80(in_RCX, iVar1);
            *(undefined4 *)(iVar1 + 0x2b0) = 1;
            pcVar2 = *(code **)(in_RCX + 0x68);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c82d;
                (*pcVar2)(in_RCX);
            }
            if (iVar6 == 0) {
code_r0x00018019c841:
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c849;
                func_0x00018019c980(iVar1);
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c83d;
                iVar3 = func_0x000180222110(iVar6, iVar1);
                if (iVar3 == 0) goto code_r0x00018019c841;
            }
            iVar1 = *(int64_t *)(in_RCX + 0x48);
        }
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c85e;
        func_0x000180229280(uVar7, uVar4);
        uVar7 = *(undefined8 *)(in_RCX + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c86a;
        func_0x000180222910(uVar7);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c879;
        uVar7 = func_0x000180222290(iVar6, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c888;
        func_0x000180222050(uVar7, 0x18019c980);
    }
    return;
}

// ============================================================
// Function: FUN_18019c7b3
// Address: 0x18019c7b3
// Size: 228 bytes
// ============================================================
void fcn.18019c780(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019c78f;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    uVar7 = *(undefined8 *)(in_RCX + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7ab;
    iVar3 = func_0x000180222950(uVar7);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7c7;
        iVar6 = func_0x000180221f20();
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7d3;
        uVar4 = func_0x000180228fa0(uVar7);
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7e1;
        func_0x000180229280(uVar7, 0);
        iVar1 = *(int64_t *)(in_RCX + 0x48);
        while ((iVar1 != 0 &&
               ((in_RDX == 0 ||
                (*(uint64_t *)(iVar1 + 0x2e8) <= (uint64_t)(in_RDX * 1000000000) &&
                 in_RDX * 1000000000 - *(uint64_t *)(iVar1 + 0x2e8) != 0))))) {
            uVar7 = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c80a;
            func_0x000180228b10(uVar7, iVar1);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c815;
            func_0x00018019cc80(in_RCX, iVar1);
            *(undefined4 *)(iVar1 + 0x2b0) = 1;
            pcVar2 = *(code **)(in_RCX + 0x68);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c82d;
                (*pcVar2)(in_RCX);
            }
            if (iVar6 == 0) {
code_r0x00018019c841:
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c849;
                func_0x00018019c980(iVar1);
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c83d;
                iVar3 = func_0x000180222110(iVar6, iVar1);
                if (iVar3 == 0) goto code_r0x00018019c841;
            }
            iVar1 = *(int64_t *)(in_RCX + 0x48);
        }
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c85e;
        func_0x000180229280(uVar7, uVar4);
        uVar7 = *(undefined8 *)(in_RCX + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c86a;
        func_0x000180222910(uVar7);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c879;
        uVar7 = func_0x000180222290(iVar6, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c888;
        func_0x000180222050(uVar7, 0x18019c980);
    }
    return;
}

// ============================================================
// Function: FUN_18019c897
// Address: 0x18019c897
// Size: 9 bytes
// ============================================================
void fcn.18019c780(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    undefined8 unaff_R15;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019c78f;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    uVar7 = *(undefined8 *)(in_RCX + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7ab;
    iVar3 = func_0x000180222950(uVar7);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7c7;
        iVar6 = func_0x000180221f20();
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7d3;
        uVar4 = func_0x000180228fa0(uVar7);
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c7e1;
        func_0x000180229280(uVar7, 0);
        iVar1 = *(int64_t *)(in_RCX + 0x48);
        while ((iVar1 != 0 &&
               ((in_RDX == 0 ||
                (*(uint64_t *)(iVar1 + 0x2e8) <= (uint64_t)(in_RDX * 1000000000) &&
                 in_RDX * 1000000000 - *(uint64_t *)(iVar1 + 0x2e8) != 0))))) {
            uVar7 = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c80a;
            func_0x000180228b10(uVar7, iVar1);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c815;
            func_0x00018019cc80(in_RCX, iVar1);
            *(undefined4 *)(iVar1 + 0x2b0) = 1;
            pcVar2 = *(code **)(in_RCX + 0x68);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c82d;
                (*pcVar2)(in_RCX);
            }
            if (iVar6 == 0) {
code_r0x00018019c841:
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c849;
                func_0x00018019c980(iVar1);
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c83d;
                iVar3 = func_0x000180222110(iVar6, iVar1);
                if (iVar3 == 0) goto code_r0x00018019c841;
            }
            iVar1 = *(int64_t *)(in_RCX + 0x48);
        }
        uVar7 = *(undefined8 *)(in_RCX + 0x30);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c85e;
        func_0x000180229280(uVar7, uVar4);
        uVar7 = *(undefined8 *)(in_RCX + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c86a;
        func_0x000180222910(uVar7);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c879;
        uVar7 = func_0x000180222290(iVar6, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18019c888;
        func_0x000180222050(uVar7, 0x18019c980);
    }
    return;
}

// ============================================================
// Function: FUN_18019c8a0
// Address: 0x18019c8a0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18019c8a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    bool bVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019c8b5;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    bVar6 = false;
    if ((in_RDX != 0) && (*(int64_t *)(in_RDX + 0x250) != 0)) {
        uVar1 = *(undefined8 *)(in_RCX + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c8e2;
        iVar3 = func_0x000180222950(uVar1);
        if (iVar3 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c8f7;
            iVar5 = func_0x000180229240(uVar1, in_RDX);
            bVar6 = iVar5 != 0;
            if (bVar6) {
                uVar1 = *(undefined8 *)(in_RCX + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c910;
                iVar5 = func_0x000180228b10(uVar1, iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c91e;
                func_0x00018019cc80(in_RCX, iVar5);
            }
            *(undefined4 *)(in_RDX + 0x2b0) = 1;
            uVar1 = *(undefined8 *)(in_RCX + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c934;
            func_0x000180222910(uVar1);
            pcVar2 = *(code **)(in_RCX + 0x68);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c945;
                (*pcVar2)(in_RCX, in_RDX);
            }
            if (bVar6) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c951;
                func_0x00018019c980(iVar5);
            }
        }
    }
    return bVar6;
}

// ============================================================
// Function: FUN_18019c8ed
// Address: 0x18019c8ed
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18019c8a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    bool bVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019c8b5;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    bVar6 = false;
    if ((in_RDX != 0) && (*(int64_t *)(in_RDX + 0x250) != 0)) {
        uVar1 = *(undefined8 *)(in_RCX + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c8e2;
        iVar3 = func_0x000180222950(uVar1);
        if (iVar3 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c8f7;
            iVar5 = func_0x000180229240(uVar1, in_RDX);
            bVar6 = iVar5 != 0;
            if (bVar6) {
                uVar1 = *(undefined8 *)(in_RCX + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c910;
                iVar5 = func_0x000180228b10(uVar1, iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c91e;
                func_0x00018019cc80(in_RCX, iVar5);
            }
            *(undefined4 *)(in_RDX + 0x2b0) = 1;
            uVar1 = *(undefined8 *)(in_RCX + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c934;
            func_0x000180222910(uVar1);
            pcVar2 = *(code **)(in_RCX + 0x68);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c945;
                (*pcVar2)(in_RCX, in_RDX);
            }
            if (bVar6) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c951;
                func_0x00018019c980(iVar5);
            }
        }
    }
    return bVar6;
}

// ============================================================
// Function: FUN_18019c956
// Address: 0x18019c956
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.18019c8a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    bool bVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019c8b5;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    bVar6 = false;
    if ((in_RDX != 0) && (*(int64_t *)(in_RDX + 0x250) != 0)) {
        uVar1 = *(undefined8 *)(in_RCX + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c8e2;
        iVar3 = func_0x000180222950(uVar1);
        if (iVar3 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c8f7;
            iVar5 = func_0x000180229240(uVar1, in_RDX);
            bVar6 = iVar5 != 0;
            if (bVar6) {
                uVar1 = *(undefined8 *)(in_RCX + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c910;
                iVar5 = func_0x000180228b10(uVar1, iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c91e;
                func_0x00018019cc80(in_RCX, iVar5);
            }
            *(undefined4 *)(in_RDX + 0x2b0) = 1;
            uVar1 = *(undefined8 *)(in_RCX + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c934;
            func_0x000180222910(uVar1);
            pcVar2 = *(code **)(in_RCX + 0x68);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c945;
                (*pcVar2)(in_RCX, in_RDX);
            }
            if (bVar6) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c951;
                func_0x00018019c980(iVar5);
            }
        }
    }
    return bVar6;
}

// ============================================================
// Function: FUN_18019c980
// Address: 0x18019c980
// Size: 342 bytes
// ============================================================
void fcn.18019c980(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18019c994;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x390);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c9c4;
            fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x00000100 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c9d2;
            fcn.180244fc0(arg1 + 0x50, 0x200);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c9e3;
            fcn.180244fc0(arg1 + 600, 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c9ef;
            fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000048 + iVar4));
            uVar3 = *(undefined8 *)(arg1 + 0x2b8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019c9fb;
            fcn.18022ecc0(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x2c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019ca07;
            fcn.180238640(uVar3);
            uVar3 = *(undefined8 *)(arg1 + 0x318);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019ca20;
            fcn.180224990(uVar3, 0x1804ab630, 0x363);
            uVar3 = *(undefined8 *)(arg1 + 800);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019ca39;
            fcn.180224990(uVar3, 0x1804ab630, 0x364);
            uVar3 = *(undefined8 *)(arg1 + 0x2a0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019ca52;
            fcn.180224990(uVar3, 0x1804ab630, 0x366);
            uVar3 = *(undefined8 *)(arg1 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019ca6b;
            fcn.180224990(uVar3, 0x1804ab630, 0x367);
            uVar3 = *(undefined8 *)(arg1 + 0x358);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019ca84;
            fcn.180224990(uVar3, 0x1804ab630, 0x36a);
            uVar3 = *(undefined8 *)(arg1 + 0x340);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019ca9d;
            fcn.180224990(uVar3, 0x1804ab630, 0x36c);
            uVar3 = *(undefined8 *)(arg1 + 0x360);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019cab6;
            fcn.180224990(uVar3, 0x1804ab630, 0x36d);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019cad0;
            fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019cb50
// Address: 0x18019cb50
// Size: 299 bytes
// ============================================================
void fcn.18019cb50(int64_t param_1, int64_t param_2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019cb5a;
    iVar4 = fcn.18045a350();
    if ((*(int64_t *)(param_2 + 0x388) != 0) && (*(int64_t *)(param_2 + 0x380) != 0)) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar4) = 0x18019cb79;
        func_0x00018019cc80();
    }
    iVar4 = *(int64_t *)(param_1 + 0x40);
    piVar1 = (int64_t *)(param_1 + 0x40);
    if (iVar4 == 0) {
        *(int64_t *)(param_1 + 0x48) = param_2;
        *piVar1 = param_2;
        *(int64_t **)(param_2 + 0x380) = piVar1;
        *(int64_t *)(param_2 + 0x388) = param_1 + 0x48;
        *(int64_t *)(param_2 + 0x378) = param_1;
        return;
    }
    uVar2 = *(uint64_t *)(param_2 + 0x2e8);
    if (uVar2 < *(uint64_t *)(iVar4 + 0x2e8)) {
        iVar3 = *(int64_t *)(param_1 + 0x48);
        piVar1 = (int64_t *)(param_1 + 0x48);
        if (uVar2 < *(uint64_t *)(iVar3 + 0x2e8)) {
            *(int64_t *)(param_2 + 0x380) = iVar3;
            *(int64_t *)(iVar3 + 0x388) = param_2;
            *(int64_t **)(param_2 + 0x388) = piVar1;
            *piVar1 = param_2;
            *(int64_t *)(param_2 + 0x378) = param_1;
            return;
        }
        piVar5 = *(int64_t **)(iVar4 + 0x388);
        if (piVar5 != piVar1) {
            do {
                if ((uint64_t)piVar5[0x5d] <= uVar2) {
                    *(int64_t **)(param_2 + 0x388) = piVar5;
                    *(int64_t *)(param_2 + 0x380) = piVar5[0x70];
                    *(int64_t *)(piVar5[0x70] + 0x388) = param_2;
                    piVar5[0x70] = param_2;
                    *(int64_t *)(param_2 + 0x378) = param_1;
                    return;
                }
                piVar5 = (int64_t *)piVar5[0x71];
            } while (piVar5 != piVar1);
            *(int64_t *)(param_2 + 0x378) = param_1;
            return;
        }
    } else {
        *(int64_t *)(param_2 + 0x388) = iVar4;
        *(int64_t *)(iVar4 + 0x380) = param_2;
        *(int64_t **)(param_2 + 0x380) = piVar1;
        *piVar1 = param_2;
    }
    *(int64_t *)(param_2 + 0x378) = param_1;
    return;
}

// ============================================================
// Function: FUN_18019cd20
// Address: 0x18019cd20
// Size: 224 bytes
// ============================================================
int64_t fcn.18019cd20(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019cd2c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019cd3b;
    iVar1 = func_0x00018019a3b0(0x200000, 0);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019cd5a;
        iVar3 = func_0x000180224d60(0x398, 0x1804ab630, 0x6d);
        if (iVar3 != 0) {
            *(undefined *)(iVar3 + 0x350) = 0xff;
            *(undefined4 *)(iVar3 + 0x2d0) = 1;
            *(undefined8 *)(iVar3 + 0x2d8) = 304000000000;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019cd8d;
            iVar4 = func_0x0001802450c0();
            iVar5 = -1;
            *(int64_t *)(iVar3 + 0x2e0) = iVar4;
            if (*(uint64_t *)(iVar3 + 0x2d8) <= -iVar4 - 1U) {
                iVar5 = iVar4 + *(uint64_t *)(iVar3 + 0x2d8);
            }
            *(int64_t *)(iVar3 + 0x2e8) = iVar5;
            *(undefined4 *)(iVar3 + 0x390) = 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019cdd6;
            iVar1 = func_0x000180224430(2, iVar3, iVar3 + 0x308);
            if (iVar1 != 0) {
                return iVar3;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019cdef;
            fcn.180224990(iVar3, 0x1804ab630, 0x7e);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019ce40
// Address: 0x18019ce40
// Size: 60 bytes
// ============================================================
undefined8 fcn.18019ce40(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019ce4a;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        if (*param_1 == 0) {
code_r0x00018019ce69:
            return *(undefined8 *)(param_1 + 0x23e);
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18019ce61;
            param_1 = (int32_t *)func_0x0001801bda50();
            if (param_1 != (int32_t *)0x0) goto code_r0x00018019ce69;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019ce80
// Address: 0x18019ce80
// Size: 263 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18019ce80(int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t arg1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int32_t *in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019ce95;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar4 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019cebf;
        piVar4 = (int32_t *)func_0x0001801bda50();
        if (piVar4 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (in_RDX != 0) {
        LOCK();
        piVar1 = (int32_t *)(in_RDX + 0x390);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        if (iVar2 + 1 < 2) {
            return 0;
        }
    }
    if ((*(int64_t *)(piVar4 + 0x23e) != 0) && ((*(uint8_t *)(piVar4 + 0x21) & 1) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019cefb;
        iVar2 = func_0x00018019b2a0(piVar4);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019cf07;
            iVar2 = func_0x00018019b250(piVar4);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019cf1e;
                fcn.18019c8a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
            }
        }
    }
    if (*(int64_t *)(in_RCX + 4) != *(int64_t *)(in_RCX + 6)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019cf30;
        iVar2 = func_0x000180194c50(in_RCX);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019cf3c;
            fcn.18019c980(in_RDX);
            return 0;
        }
    }
    if (in_RDX != 0) {
        piVar4[0x264] = *(int32_t *)(in_RDX + 0x2d0);
    }
    arg1 = *(int64_t *)(piVar4 + 0x23e);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019cf6b;
    fcn.18019c980(arg1);
    *(int64_t *)(piVar4 + 0x23e) = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_18019cf90
// Address: 0x18019cf90
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18019cf90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint32_t uVar5;
    undefined4 *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019cfaa;
    iVar4 = fcn.18045a350();
    uVar5 = 0;
    while( true ) {
        uVar1 = *in_R8;
        uVar2 = **(undefined8 **)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18019cfd5;
        iVar3 = func_0x00018021b9c0(uVar2, in_RDX, uVar1, 0);
        if (iVar3 < 1) {
            return 0;
        }
        uVar1 = *in_R8;
        *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18019cfe7;
        iVar3 = func_0x000180193f00(in_RCX, in_RDX, uVar1);
        if (iVar3 == 0) break;
        uVar5 = uVar5 + 1;
        if (9 < uVar5) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18019d010
// Address: 0x18019d010
// Size: 423 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel

void fcn.18019d010(int64_t param_1, undefined8 param_2, uint64_t param_3)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 auStackX_8 [6];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18019d026;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)(&stack0x000003a8 + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    iVar7 = *(int64_t *)(param_1 + 0xb88);
    if ((*(uint32_t *)(iVar7 + 0x50) & 0x100) == 0) {
        *(undefined4 *)((int64_t)auStackX_8 + iVar6) = *(undefined4 *)(param_1 + 0x48);
        if (0x20 < param_3) goto code_r0x00018019d190;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d07a;
        func_0x000180498030(&stack0x00000260 + iVar6);
        *(uint64_t *)(&stack0x00000258 + iVar6) = param_3;
        uVar2 = *(undefined8 *)(iVar7 + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d08e;
        iVar5 = func_0x000180222850(uVar2);
        if (iVar5 == 0) goto code_r0x00018019d190;
        uVar2 = *(undefined8 *)(*(int64_t *)(param_1 + 0xb88) + 0x30);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d0a7;
        iVar7 = func_0x000180229240(uVar2, (int64_t)auStackX_8 + iVar6);
        if (iVar7 != 0) {
            LOCK();
            piVar1 = (int32_t *)(iVar7 + 0x390);
            iVar5 = *piVar1;
            *piVar1 = *piVar1 + 1;
            UNLOCK();
            if (iVar5 + 1 < 2) {
                uVar2 = *(undefined8 *)(*(int64_t *)(param_1 + 0xb88) + 0x3e0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d0d2;
                func_0x000180222910(uVar2);
                goto code_r0x00018019d190;
            }
        }
        uVar2 = *(undefined8 *)(*(int64_t *)(param_1 + 0xb88) + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d0ec;
        func_0x000180222910(uVar2);
        if (iVar7 != 0) goto code_r0x00018019d190;
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(param_1 + 0xb88) + 0x90);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    pcVar3 = *(code **)(*(int64_t *)(param_1 + 0xb88) + 0x70);
    if (pcVar3 != (code *)0x0) {
        uVar2 = *(undefined8 *)(param_1 + 0x40);
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d129;
        iVar7 = (*pcVar3)(uVar2, param_2, param_3 & 0xffffffff, (int64_t)&var_8h + iVar6);
        if (iVar7 != 0) {
            if (*(int32_t *)(iVar7 + 0x2b0) == 0) {
                LOCK();
                piVar1 = (int32_t *)(*(int64_t *)(param_1 + 0xb88) + 0xa0);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
                if (*(int32_t *)((int64_t)&var_8h + iVar6) != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(iVar7 + 0x390);
                    iVar5 = *piVar1;
                    *piVar1 = *piVar1 + 1;
                    UNLOCK();
                    if (iVar5 + 1 < 2) goto code_r0x00018019d190;
                }
                iVar4 = *(int64_t *)(param_1 + 0xb88);
                if ((*(uint32_t *)(iVar4 + 0x50) & 0x200) == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d18d;
                    func_0x00018019c530(iVar4, iVar7);
                }
            } else if (*(int32_t *)((int64_t)&var_8h + iVar6) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d149;
                fcn.18019c980(iVar7);
            }
        }
    }
code_r0x00018019d190:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18019d1a0;
    func_0x000180459870(*(uint64_t *)(&stack0x000003a8 + iVar6) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_18019d1c0
// Address: 0x18019d1c0
// Size: 96 bytes
// ============================================================
undefined8 fcn.18019d1c0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019d1cc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(int64_t *)(param_1 + 0x8f8) != 0) && ((*(uint8_t *)(param_1 + 0x84) & 1) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019d1ea;
        iVar1 = fcn.18019b2a0();
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019d1f6;
            iVar1 = fcn.18019b250(param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019d20d;
                fcn.18019c8a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2));
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019d220
// Address: 0x18019d220
// Size: 310 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18019d220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar6;
    undefined8 uVar7;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019d230;
    iVar5 = fcn.18045a350();
    iVar3 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 0x48);
    if (iVar4 < 0x304) {
        if ((((iVar4 == 0x303) || (iVar4 == 0x100)) || (iVar4 == 0x300)) || (iVar4 == 0x301)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0x302;
    } else {
        if ((iVar4 == 0x304) || (iVar4 == 0xfefd)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0xfeff;
    }
    if (!bVar8) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d283;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d29b;
        func_0x0001802295a0(0x1804ab630, 0x171, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2b1;
        func_0x00018019b5e0(in_RCX, 0x50, 0x103, 0);
        return 0;
    }
code_r0x00018019d2be:
    *(int64_t *)(in_RDX + 0x250) = iVar5;
    if (*(int32_t *)(in_RCX + 0xa60) != 0) {
        *(undefined8 *)(in_RDX + 0x250) = 0;
        return 1;
    }
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2f2;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        return 0;
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d309;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        uVar7 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d316;
        func_0x000180222910(uVar7);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d31b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d333;
        func_0x0001802295a0(0x1804ab630, 399, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d349;
        func_0x00018019b5e0(in_RCX, 0x50, 0x115, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    pcVar6 = *(code **)(in_RCX + 0x918);
    if (*(code **)(in_RCX + 0x918) == (code *)0x0) {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x1b8);
        pcVar6 = fcn.18019cf90;
        if (pcVar2 != (code *)0x0) {
            pcVar6 = pcVar2;
        }
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d39b;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3a4;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3b9;
    func_0x0001804986e0(in_RDX + 600, 0, uVar7);
    *(undefined4 *)((int64_t)&arg_28h + iVar3) = *(undefined4 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3d4;
    iVar4 = (*pcVar6)(in_RCX, in_RDX + 600, (int64_t)&arg_28h + iVar3);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3e2;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3fa;
        func_0x0001802295a0(0x1804ab630, 0x19e, 0x1804ab658);
        uVar7 = 0x12d;
    } else {
        uVar1 = *(uint32_t *)((int64_t)&arg_28h + iVar3);
        if ((uVar1 == 0) || (*(uint64_t *)(in_RDX + 0x250) < (uint64_t)uVar1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d472;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d48a;
            func_0x0001802295a0(0x1804ab630, 0x1a8, 0x1804ab658);
            uVar7 = 0x12f;
        } else {
            *(uint64_t *)(in_RDX + 0x250) = (uint64_t)uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d42f;
            iVar4 = func_0x000180193f00(in_RCX, in_RDX + 600, uVar1);
            if (iVar4 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d438;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d450;
            func_0x0001802295a0(0x1804ab630, 0x1af, 0x1804ab658);
            uVar7 = 0x12e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d4a0;
    func_0x00018019b5e0(in_RCX, 0x50, uVar7, 0);
    return 0;
}

// ============================================================
// Function: FUN_18019d356
// Address: 0x18019d356
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18019d220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar6;
    undefined8 uVar7;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019d230;
    iVar5 = fcn.18045a350();
    iVar3 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 0x48);
    if (iVar4 < 0x304) {
        if ((((iVar4 == 0x303) || (iVar4 == 0x100)) || (iVar4 == 0x300)) || (iVar4 == 0x301)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0x302;
    } else {
        if ((iVar4 == 0x304) || (iVar4 == 0xfefd)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0xfeff;
    }
    if (!bVar8) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d283;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d29b;
        func_0x0001802295a0(0x1804ab630, 0x171, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2b1;
        func_0x00018019b5e0(in_RCX, 0x50, 0x103, 0);
        return 0;
    }
code_r0x00018019d2be:
    *(int64_t *)(in_RDX + 0x250) = iVar5;
    if (*(int32_t *)(in_RCX + 0xa60) != 0) {
        *(undefined8 *)(in_RDX + 0x250) = 0;
        return 1;
    }
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2f2;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        return 0;
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d309;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        uVar7 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d316;
        func_0x000180222910(uVar7);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d31b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d333;
        func_0x0001802295a0(0x1804ab630, 399, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d349;
        func_0x00018019b5e0(in_RCX, 0x50, 0x115, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    pcVar6 = *(code **)(in_RCX + 0x918);
    if (*(code **)(in_RCX + 0x918) == (code *)0x0) {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x1b8);
        pcVar6 = fcn.18019cf90;
        if (pcVar2 != (code *)0x0) {
            pcVar6 = pcVar2;
        }
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d39b;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3a4;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3b9;
    func_0x0001804986e0(in_RDX + 600, 0, uVar7);
    *(undefined4 *)((int64_t)&arg_28h + iVar3) = *(undefined4 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3d4;
    iVar4 = (*pcVar6)(in_RCX, in_RDX + 600, (int64_t)&arg_28h + iVar3);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3e2;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3fa;
        func_0x0001802295a0(0x1804ab630, 0x19e, 0x1804ab658);
        uVar7 = 0x12d;
    } else {
        uVar1 = *(uint32_t *)((int64_t)&arg_28h + iVar3);
        if ((uVar1 == 0) || (*(uint64_t *)(in_RDX + 0x250) < (uint64_t)uVar1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d472;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d48a;
            func_0x0001802295a0(0x1804ab630, 0x1a8, 0x1804ab658);
            uVar7 = 0x12f;
        } else {
            *(uint64_t *)(in_RDX + 0x250) = (uint64_t)uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d42f;
            iVar4 = func_0x000180193f00(in_RCX, in_RDX + 600, uVar1);
            if (iVar4 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d438;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d450;
            func_0x0001802295a0(0x1804ab630, 0x1af, 0x1804ab658);
            uVar7 = 0x12e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d4a0;
    func_0x00018019b5e0(in_RCX, 0x50, uVar7, 0);
    return 0;
}

// ============================================================
// Function: FUN_18019d35b
// Address: 0x18019d35b
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18019d220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar6;
    undefined8 uVar7;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019d230;
    iVar5 = fcn.18045a350();
    iVar3 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 0x48);
    if (iVar4 < 0x304) {
        if ((((iVar4 == 0x303) || (iVar4 == 0x100)) || (iVar4 == 0x300)) || (iVar4 == 0x301)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0x302;
    } else {
        if ((iVar4 == 0x304) || (iVar4 == 0xfefd)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0xfeff;
    }
    if (!bVar8) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d283;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d29b;
        func_0x0001802295a0(0x1804ab630, 0x171, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2b1;
        func_0x00018019b5e0(in_RCX, 0x50, 0x103, 0);
        return 0;
    }
code_r0x00018019d2be:
    *(int64_t *)(in_RDX + 0x250) = iVar5;
    if (*(int32_t *)(in_RCX + 0xa60) != 0) {
        *(undefined8 *)(in_RDX + 0x250) = 0;
        return 1;
    }
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2f2;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        return 0;
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d309;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        uVar7 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d316;
        func_0x000180222910(uVar7);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d31b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d333;
        func_0x0001802295a0(0x1804ab630, 399, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d349;
        func_0x00018019b5e0(in_RCX, 0x50, 0x115, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    pcVar6 = *(code **)(in_RCX + 0x918);
    if (*(code **)(in_RCX + 0x918) == (code *)0x0) {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x1b8);
        pcVar6 = fcn.18019cf90;
        if (pcVar2 != (code *)0x0) {
            pcVar6 = pcVar2;
        }
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d39b;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3a4;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3b9;
    func_0x0001804986e0(in_RDX + 600, 0, uVar7);
    *(undefined4 *)((int64_t)&arg_28h + iVar3) = *(undefined4 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3d4;
    iVar4 = (*pcVar6)(in_RCX, in_RDX + 600, (int64_t)&arg_28h + iVar3);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3e2;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3fa;
        func_0x0001802295a0(0x1804ab630, 0x19e, 0x1804ab658);
        uVar7 = 0x12d;
    } else {
        uVar1 = *(uint32_t *)((int64_t)&arg_28h + iVar3);
        if ((uVar1 == 0) || (*(uint64_t *)(in_RDX + 0x250) < (uint64_t)uVar1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d472;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d48a;
            func_0x0001802295a0(0x1804ab630, 0x1a8, 0x1804ab658);
            uVar7 = 0x12f;
        } else {
            *(uint64_t *)(in_RDX + 0x250) = (uint64_t)uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d42f;
            iVar4 = func_0x000180193f00(in_RCX, in_RDX + 600, uVar1);
            if (iVar4 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d438;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d450;
            func_0x0001802295a0(0x1804ab630, 0x1af, 0x1804ab658);
            uVar7 = 0x12e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d4a0;
    func_0x00018019b5e0(in_RCX, 0x50, uVar7, 0);
    return 0;
}

// ============================================================
// Function: FUN_18019d3dd
// Address: 0x18019d3dd
// Size: 144 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18019d220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar6;
    undefined8 uVar7;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019d230;
    iVar5 = fcn.18045a350();
    iVar3 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 0x48);
    if (iVar4 < 0x304) {
        if ((((iVar4 == 0x303) || (iVar4 == 0x100)) || (iVar4 == 0x300)) || (iVar4 == 0x301)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0x302;
    } else {
        if ((iVar4 == 0x304) || (iVar4 == 0xfefd)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0xfeff;
    }
    if (!bVar8) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d283;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d29b;
        func_0x0001802295a0(0x1804ab630, 0x171, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2b1;
        func_0x00018019b5e0(in_RCX, 0x50, 0x103, 0);
        return 0;
    }
code_r0x00018019d2be:
    *(int64_t *)(in_RDX + 0x250) = iVar5;
    if (*(int32_t *)(in_RCX + 0xa60) != 0) {
        *(undefined8 *)(in_RDX + 0x250) = 0;
        return 1;
    }
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2f2;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        return 0;
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d309;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        uVar7 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d316;
        func_0x000180222910(uVar7);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d31b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d333;
        func_0x0001802295a0(0x1804ab630, 399, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d349;
        func_0x00018019b5e0(in_RCX, 0x50, 0x115, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    pcVar6 = *(code **)(in_RCX + 0x918);
    if (*(code **)(in_RCX + 0x918) == (code *)0x0) {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x1b8);
        pcVar6 = fcn.18019cf90;
        if (pcVar2 != (code *)0x0) {
            pcVar6 = pcVar2;
        }
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d39b;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3a4;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3b9;
    func_0x0001804986e0(in_RDX + 600, 0, uVar7);
    *(undefined4 *)((int64_t)&arg_28h + iVar3) = *(undefined4 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3d4;
    iVar4 = (*pcVar6)(in_RCX, in_RDX + 600, (int64_t)&arg_28h + iVar3);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3e2;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3fa;
        func_0x0001802295a0(0x1804ab630, 0x19e, 0x1804ab658);
        uVar7 = 0x12d;
    } else {
        uVar1 = *(uint32_t *)((int64_t)&arg_28h + iVar3);
        if ((uVar1 == 0) || (*(uint64_t *)(in_RDX + 0x250) < (uint64_t)uVar1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d472;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d48a;
            func_0x0001802295a0(0x1804ab630, 0x1a8, 0x1804ab658);
            uVar7 = 0x12f;
        } else {
            *(uint64_t *)(in_RDX + 0x250) = (uint64_t)uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d42f;
            iVar4 = func_0x000180193f00(in_RCX, in_RDX + 600, uVar1);
            if (iVar4 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d438;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d450;
            func_0x0001802295a0(0x1804ab630, 0x1af, 0x1804ab658);
            uVar7 = 0x12e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d4a0;
    func_0x00018019b5e0(in_RCX, 0x50, uVar7, 0);
    return 0;
}

// ============================================================
// Function: FUN_18019d46d
// Address: 0x18019d46d
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18019d220(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    code *pcVar6;
    undefined8 uVar7;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019d230;
    iVar5 = fcn.18045a350();
    iVar3 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 0x48);
    if (iVar4 < 0x304) {
        if ((((iVar4 == 0x303) || (iVar4 == 0x100)) || (iVar4 == 0x300)) || (iVar4 == 0x301)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0x302;
    } else {
        if ((iVar4 == 0x304) || (iVar4 == 0xfefd)) goto code_r0x00018019d2be;
        bVar8 = iVar4 == 0xfeff;
    }
    if (!bVar8) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d283;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d29b;
        func_0x0001802295a0(0x1804ab630, 0x171, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2b1;
        func_0x00018019b5e0(in_RCX, 0x50, 0x103, 0);
        return 0;
    }
code_r0x00018019d2be:
    *(int64_t *)(in_RDX + 0x250) = iVar5;
    if (*(int32_t *)(in_RCX + 0xa60) != 0) {
        *(undefined8 *)(in_RDX + 0x250) = 0;
        return 1;
    }
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d2f2;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        return 0;
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d309;
    iVar4 = func_0x000180222850(uVar7);
    if (iVar4 == 0) {
        uVar7 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d316;
        func_0x000180222910(uVar7);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d31b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d333;
        func_0x0001802295a0(0x1804ab630, 399, 0x1804ab658);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d349;
        func_0x00018019b5e0(in_RCX, 0x50, 0x115, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    pcVar6 = *(code **)(in_RCX + 0x918);
    if (*(code **)(in_RCX + 0x918) == (code *)0x0) {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x1b8);
        pcVar6 = fcn.18019cf90;
        if (pcVar2 != (code *)0x0) {
            pcVar6 = pcVar2;
        }
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d39b;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3a4;
    func_0x000180222910(uVar7);
    uVar7 = *(undefined8 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3b9;
    func_0x0001804986e0(in_RDX + 600, 0, uVar7);
    *(undefined4 *)((int64_t)&arg_28h + iVar3) = *(undefined4 *)(in_RDX + 0x250);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3d4;
    iVar4 = (*pcVar6)(in_RCX, in_RDX + 600, (int64_t)&arg_28h + iVar3);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3e2;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d3fa;
        func_0x0001802295a0(0x1804ab630, 0x19e, 0x1804ab658);
        uVar7 = 0x12d;
    } else {
        uVar1 = *(uint32_t *)((int64_t)&arg_28h + iVar3);
        if ((uVar1 == 0) || (*(uint64_t *)(in_RDX + 0x250) < (uint64_t)uVar1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d472;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d48a;
            func_0x0001802295a0(0x1804ab630, 0x1a8, 0x1804ab658);
            uVar7 = 0x12f;
        } else {
            *(uint64_t *)(in_RDX + 0x250) = (uint64_t)uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d42f;
            iVar4 = func_0x000180193f00(in_RCX, in_RDX + 600, uVar1);
            if (iVar4 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d438;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d450;
            func_0x0001802295a0(0x1804ab630, 0x1af, 0x1804ab658);
            uVar7 = 0x12e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d4a0;
    func_0x00018019b5e0(in_RCX, 0x50, uVar7, 0);
    return 0;
}

// ============================================================
// Function: FUN_18019d4c0
// Address: 0x18019d4c0
// Size: 628 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18019d4c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 *arg1;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019d4e0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d4f4;
    iVar2 = func_0x00018019a3b0(0x200000, 0);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d513;
        arg1 = (undefined4 *)func_0x000180224d60(0x398, 0x1804ab630, 0x6d);
        if (arg1 != (undefined4 *)0x0) {
            *(undefined *)(arg1 + 0xd4) = 0xff;
            arg1[0xb4] = 1;
            *(undefined8 *)(arg1 + 0xb6) = 304000000000;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d546;
            iVar4 = func_0x0001802450c0();
            iVar6 = -1;
            *(int64_t *)(arg1 + 0xb8) = iVar4;
            if (-iVar4 - 1U < *(uint64_t *)(arg1 + 0xb6)) {
                iVar4 = -1;
            } else {
                iVar4 = iVar4 + *(uint64_t *)(arg1 + 0xb6);
            }
            *(int64_t *)(arg1 + 0xba) = iVar4;
            arg1[0xe4] = 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d593;
            iVar2 = func_0x000180224430(2, arg1, arg1 + 0xc2);
            if (iVar2 != 0) {
                uVar5 = *(uint64_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x58);
                if (uVar5 == 0) {
                    pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0xd0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d616;
                    uVar5 = (*pcVar1)();
                }
                *(uint64_t *)(arg1 + 0xb6) = uVar5;
                if (uVar5 <= ~*(uint64_t *)(arg1 + 0xb8)) {
                    iVar6 = *(uint64_t *)(arg1 + 0xb8) + uVar5;
                }
                *(int64_t *)(arg1 + 0xba) = iVar6;
                iVar6 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d646;
                fcn.18019c980(iVar6);
                *(undefined8 *)(in_RCX + 0x8f8) = 0;
                if ((in_EDX == 0) ||
                   ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
                     (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)))) {
                    *(undefined8 *)(arg1 + 0x94) = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d67f;
                    iVar2 = fcn.18019d220(*(int64_t *)((int64_t)&var_18h + iVar3), 
                                          *(int64_t *)((int64_t)&var_20h + iVar3), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar3));
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d68b;
                        fcn.18019c980((int64_t)arg1);
                        return 0;
                    }
                }
                if (0x20 < *(uint64_t *)(in_RCX + 0x8d0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d6a9;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d6c1;
                    func_0x0001802295a0(0x1804ab630, 0x1dd, 0x1804ab670);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d6d7;
                    func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d6df;
                    fcn.18019c980((int64_t)arg1);
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d6f7;
                func_0x000180498030(arg1 + 0xa0, in_RCX + 0x8d8);
                *(undefined8 *)(arg1 + 0x9e) = *(undefined8 *)(in_RCX + 0x8d0);
                *(undefined4 **)(in_RCX + 0x8f8) = arg1;
                *arg1 = *(undefined4 *)(in_RCX + 0x48);
                arg1[0xb4] = 0;
                if ((*(uint32_t *)(in_RCX + 0x160) & 0x200) != 0) {
                    arg1[0xdc] = arg1[0xdc] | 1;
                }
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d5ac;
            fcn.180224990(arg1, 0x1804ab630, 0x7e);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d5b1;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d5c9;
    func_0x0001802295a0(0x1804ab630, 0x1bd, 0x1804ab670);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019d5df;
    func_0x00018019b5e0(in_RCX, 0x50, 0x80014, 0);
    return 0;
}

// ============================================================
// Function: FUN_18019d740
// Address: 0x18019d740
// Size: 1191 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_400h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel

int32_t fcn.18019d740(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    uint8_t uVar5;
    uint8_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int32_t *piVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019d759;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    bVar4 = false;
    piVar10 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_38h + iVar9) = 0;
    uVar6 = 0;
    bVar3 = false;
    if ((((*(uint8_t *)(*(int64_t *)(piVar10 + 0x36) + 0x50) & 8) == 0) && (iVar7 = *piVar10, 0x303 < iVar7)) &&
       (iVar7 != 0x10000)) {
        iVar1 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d7a9;
        fcn.18019c980(iVar1);
        *(undefined8 *)(in_RCX + 0x8f8) = 0;
        *(undefined4 *)(in_RCX + 0xa60) = 1;
        uVar2 = *(undefined8 *)(in_RDX + 0x288);
        *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar9) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d7de;
        iVar7 = func_0x0001801c9d00(in_RCX, 0x14, 0x80, uVar2);
        if (iVar7 == 0) {
            return -1;
        }
        uVar2 = *(undefined8 *)(in_RDX + 0x288);
        *(undefined8 *)((int64_t)&var_10h + iVar9) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar9) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d806;
        iVar7 = func_0x0001801c9d00(in_RCX, 0x1c, 0x80, uVar2);
        if (iVar7 == 0) {
            return -1;
        }
        piVar10 = *(int32_t **)(in_RCX + 0x8f8);
        *(int32_t **)((int64_t)&arg_38h + iVar9) = piVar10;
        bVar3 = false;
code_r0x00018019d876:
        if (piVar10 == (int32_t *)0x0) {
            return 0;
        }
        uVar5 = 0;
        if ((*piVar10 != *(int32_t *)(in_RCX + 0x48)) ||
           (uVar5 = uVar6, *(int64_t *)(piVar10 + 0x9e) != *(int64_t *)(in_RCX + 0x8d0))) goto code_r0x00018019db8b;
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d8b1;
        iVar7 = func_0x000180497f30(piVar10 + 0xa0, in_RCX + 0x8d8);
        if (iVar7 != 0) goto code_r0x00018019db8b;
        bVar4 = bVar3;
        if (((*(uint8_t *)(in_RCX + 0x948) & 1) == 0) || (*(int64_t *)(in_RCX + 0x8d0) != 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d90d;
            uVar11 = func_0x0001802450c0();
            if (*(uint64_t *)(piVar10 + 0xba) < uVar11) {
                LOCK();
                piVar10 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x94);
                *piVar10 = *piVar10 + 1;
                UNLOCK();
                uVar5 = 0;
                if (bVar3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d93e;
                    fcn.18019c8a0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                                  *(int64_t *)((int64_t)&var_18h + iVar9));
                    uVar5 = uVar6;
                }
            } else {
                piVar10 = *(int32_t **)((int64_t)&arg_38h + iVar9);
                uVar8 = *(uint32_t *)(in_RCX + 0x160) & 0x200;
                if ((*(uint8_t *)(piVar10 + 0xdc) & 1) == 0) {
                    if (uVar8 != 0) goto code_r0x00018019db8b;
code_r0x00018019d9a5:
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                        (iVar7 = **(int32_t **)(in_RCX + 0x18), iVar7 < 0x304)) || (iVar7 == 0x10000)) {
                        iVar1 = *(int64_t *)(in_RCX + 0x8f8);
                        if (iVar1 != 0) {
                            LOCK();
                            piVar10 = (int32_t *)(iVar1 + 0x390);
                            iVar7 = *piVar10;
                            *piVar10 = *piVar10 + -1;
                            UNLOCK();
                            if (iVar7 < 2) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da04;
                                fcn.180223fb0(*(int64_t *)(&stack0x00000088 + iVar9), 
                                              *(int64_t *)(&stack0x000000f0 + iVar9));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da12;
                                fcn.180244fc0(iVar1 + 0x50, 0x200);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da23;
                                fcn.180244fc0(iVar1 + 600, 0x20);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da2f;
                                fcn.18021fe80(*(int64_t *)((int64_t)&var_10h + iVar9), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar9));
                                uVar2 = *(undefined8 *)(iVar1 + 0x2b8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da3b;
                                fcn.18022ecc0(uVar2);
                                uVar2 = *(undefined8 *)(iVar1 + 0x2c8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da47;
                                fcn.180238640(uVar2);
                                uVar2 = *(undefined8 *)(iVar1 + 0x318);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da60;
                                fcn.180224990(uVar2, 0x1804ab630, 0x363);
                                uVar2 = *(undefined8 *)(iVar1 + 800);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da79;
                                fcn.180224990(uVar2, 0x1804ab630, 0x364);
                                uVar2 = *(undefined8 *)(iVar1 + 0x2a0);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019da92;
                                fcn.180224990(uVar2, 0x1804ab630, 0x366);
                                uVar2 = *(undefined8 *)(iVar1 + 0x2a8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019daab;
                                fcn.180224990(uVar2, 0x1804ab630, 0x367);
                                uVar2 = *(undefined8 *)(iVar1 + 0x358);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019dac4;
                                fcn.180224990(uVar2, 0x1804ab630, 0x36a);
                                uVar2 = *(undefined8 *)(iVar1 + 0x340);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019dadd;
                                fcn.180224990(uVar2, 0x1804ab630, 0x36c);
                                uVar2 = *(undefined8 *)(iVar1 + 0x360);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019daf6;
                                fcn.180224990(uVar2, 0x1804ab630, 0x36d);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019db10;
                                fcn.180224b90(*(int64_t *)((int64_t)&var_8h + iVar9), 
                                              *(int64_t *)((int64_t)&var_10h + iVar9));
                            }
                            piVar10 = *(int32_t **)((int64_t)&arg_38h + iVar9);
                        }
                        *(int32_t **)(in_RCX + 0x8f8) = piVar10;
                    }
                    LOCK();
                    piVar10 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x9c);
                    *piVar10 = *piVar10 + 1;
                    UNLOCK();
                    *(undefined4 *)(in_RCX + 0x990) = *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0);
                    return 1;
                }
                if (uVar8 != 0) goto code_r0x00018019d9a5;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d965;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d97d;
                func_0x0001802295a0(0x1804ab630, 0x2ae, 0x1804ab688);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d993;
                func_0x00018019b5e0(in_RCX, 0x2f, 0x68, 0);
                uVar5 = 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d8d0;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d8e8;
            func_0x0001802295a0(0x1804ab630, 0x29c, 0x1804ab688);
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d8fe;
            func_0x00018019b5e0(in_RCX, 0x50, 0x115, 0);
            uVar5 = 1;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d82f;
        iVar7 = func_0x0001801ad970(in_RCX);
        if ((iVar7 != 0) && (iVar7 != 1)) {
            if (((iVar7 == 2) || (iVar7 == 3)) && (*(int64_t *)(in_RDX + 0x28) != 0)) {
                bVar3 = true;
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019d867;
                piVar10 = (int32_t *)fcn.18019d010(in_RCX, in_RDX + 0x30);
                *(int32_t **)((int64_t)&arg_38h + iVar9) = piVar10;
            } else {
                piVar10 = *(int32_t **)((int64_t)&arg_38h + iVar9);
            }
            goto code_r0x00018019d876;
        }
        uVar5 = 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019db58;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019db70;
        func_0x0001802295a0(0x1804ab630, 0x26d, 0x1804ab688);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019db86;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
    }
    piVar10 = *(int32_t **)((int64_t)&arg_38h + iVar9);
    bVar3 = bVar4;
code_r0x00018019db8b:
    if (piVar10 != (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18019db98;
        fcn.18019c980((int64_t)piVar10);
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
            *(undefined8 *)(in_RCX + 0x8f8) = 0;
        }
        if (!bVar3) {
            *(undefined4 *)(in_RCX + 0xa60) = 1;
        }
    }
    return -(uint32_t)uVar5;
}

// ============================================================
// Function: FUN_18019dc20
// Address: 0x18019dc20
// Size: 38 bytes
// ============================================================
void fcn.18019dc20(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019dc2a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019dc32;
    iVar1 = fcn.18019dc50(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1));
    if (iVar1 != 0) {
        *(undefined4 *)(iVar1 + 0x2b0) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18019dc50
// Address: 0x18019dc50
// Size: 1089 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined4 * fcn.18019dc50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *arg1;
    undefined4 *puVar6;
    undefined4 *in_RCX;
    undefined4 *puVar7;
    int32_t in_EDX;
    int64_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019dc65;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019dc84;
    arg1 = (undefined4 *)fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5))
    ;
    if (arg1 == (undefined4 *)0x0) {
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
    iVar8 = 7;
    puVar6 = in_RCX;
    puVar7 = arg1;
    do {
        uVar1 = puVar6[1];
        uVar2 = puVar6[2];
        uVar3 = puVar6[3];
        *puVar7 = *puVar6;
        puVar7[1] = uVar1;
        puVar7[2] = uVar2;
        puVar7[3] = uVar3;
        uVar1 = puVar6[5];
        uVar2 = puVar6[6];
        uVar3 = puVar6[7];
        puVar7[4] = puVar6[4];
        puVar7[5] = uVar1;
        puVar7[6] = uVar2;
        puVar7[7] = uVar3;
        uVar1 = puVar6[9];
        uVar2 = puVar6[10];
        uVar3 = puVar6[0xb];
        puVar7[8] = puVar6[8];
        puVar7[9] = uVar1;
        puVar7[10] = uVar2;
        puVar7[0xb] = uVar3;
        uVar1 = puVar6[0xd];
        uVar2 = puVar6[0xe];
        uVar3 = puVar6[0xf];
        puVar7[0xc] = puVar6[0xc];
        puVar7[0xd] = uVar1;
        puVar7[0xe] = uVar2;
        puVar7[0xf] = uVar3;
        uVar1 = puVar6[0x11];
        uVar2 = puVar6[0x12];
        uVar3 = puVar6[0x13];
        puVar7[0x10] = puVar6[0x10];
        puVar7[0x11] = uVar1;
        puVar7[0x12] = uVar2;
        puVar7[0x13] = uVar3;
        uVar1 = puVar6[0x15];
        uVar2 = puVar6[0x16];
        uVar3 = puVar6[0x17];
        puVar7[0x14] = puVar6[0x14];
        puVar7[0x15] = uVar1;
        puVar7[0x16] = uVar2;
        puVar7[0x17] = uVar3;
        uVar1 = puVar6[0x19];
        uVar2 = puVar6[0x1a];
        uVar3 = puVar6[0x1b];
        puVar7[0x18] = puVar6[0x18];
        puVar7[0x19] = uVar1;
        puVar7[0x1a] = uVar2;
        puVar7[0x1b] = uVar3;
        uVar1 = puVar6[0x1d];
        uVar2 = puVar6[0x1e];
        uVar3 = puVar6[0x1f];
        puVar7[0x1c] = puVar6[0x1c];
        puVar7[0x1d] = uVar1;
        puVar7[0x1e] = uVar2;
        puVar7[0x1f] = uVar3;
        iVar8 = iVar8 + -1;
        puVar6 = puVar6 + 0x20;
        puVar7 = puVar7 + 0x20;
    } while (iVar8 != 0);
    *(undefined8 *)(arg1 + 0xa8) = 0;
    *(undefined8 *)(arg1 + 0xaa) = 0;
    *(undefined8 *)(arg1 + 0xc6) = 0;
    *(undefined8 *)(arg1 + 200) = 0;
    *(undefined8 *)(arg1 + 0xd0) = 0;
    *(undefined8 *)(arg1 + 0xd6) = 0;
    *(undefined8 *)(arg1 + 0xb2) = 0;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xae) = 0;
    *(undefined8 *)(arg1 + 0xd8) = 0;
    *(undefined (*) [16])(arg1 + 0xc2) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0xe0) = 0;
    *(undefined8 *)(arg1 + 0xe2) = 0;
    *(undefined8 *)(arg1 + 0xde) = 0;
    arg1[0xe4] = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019dd8a;
    iVar4 = fcn.180224430(*(int64_t *)(&stack0x00000058 + iVar5));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019dd93;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019ddab;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019ddbd;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019ddc5;
        fcn.18019c980((int64_t)arg1);
        return (undefined4 *)0x0;
    }
    if (*(int64_t *)(in_RCX + 0xb0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019dddd;
        iVar4 = fcn.1802375f0();
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019dde6;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019ddfe;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019de10;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019de18;
            fcn.18019c980((int64_t)arg1);
            return (undefined4 *)0x0;
        }
        *(undefined8 *)(arg1 + 0xb0) = *(undefined8 *)(in_RCX + 0xb0);
    }
    if (*(int64_t *)(in_RCX + 0xb2) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019de3e;
        iVar8 = fcn.180238060(*(int64_t *)((int64_t)&var_18h + iVar5));
        *(int64_t *)(arg1 + 0xb2) = iVar8;
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019de4f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019de67;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019de79;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019de81;
            fcn.18019c980((int64_t)arg1);
            return (undefined4 *)0x0;
        }
    }
    if (*(int64_t *)(in_RCX + 0xae) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019de99;
        iVar4 = fcn.1802308d0();
        if (iVar4 == 0) goto code_r0x00018019e068;
        *(undefined8 *)(arg1 + 0xae) = *(undefined8 *)(in_RCX + 0xae);
    }
    if (*(int64_t *)(in_RCX + 0xa8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019decd;
        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(int64_t *)(arg1 + 0xa8) = iVar8;
        if (iVar8 == 0) goto code_r0x00018019e068;
    }
    if (*(int64_t *)(in_RCX + 0xaa) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019defb;
        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(int64_t *)(arg1 + 0xaa) = iVar8;
        if (iVar8 == 0) goto code_r0x00018019e068;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019df23;
    iVar4 = fcn.180223d20(*(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x000000c0 + iVar5));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019df2c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019df44;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019df56;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019df5e;
        fcn.18019c980((int64_t)arg1);
        return (undefined4 *)0x0;
    }
    if (*(int64_t *)(in_RCX + 0xc6) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019df83;
        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(int64_t *)(arg1 + 0xc6) = iVar8;
        if (iVar8 == 0) goto code_r0x00018019e068;
    }
    if ((in_EDX == 0) || (*(int64_t *)(in_RCX + 200) == 0)) {
        arg1[0xcc] = 0;
        *(undefined8 *)(arg1 + 0xca) = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019dfbc;
        iVar8 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar5));
        *(int64_t *)(arg1 + 200) = iVar8;
        if (iVar8 == 0) goto code_r0x00018019e068;
    }
    if (*(int64_t *)(in_RCX + 0xd0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019e001;
        iVar8 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar5));
        *(int64_t *)(arg1 + 0xd0) = iVar8;
        if (iVar8 == 0) goto code_r0x00018019e068;
    }
    if (*(int64_t *)(in_RCX + 0xd6) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019e02b;
        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(int64_t *)(arg1 + 0xd6) = iVar8;
        if (iVar8 == 0) goto code_r0x00018019e068;
    }
    if (*(int64_t *)(in_RCX + 0xd8) == 0) {
        return arg1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019e05c;
    iVar8 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar5));
    *(int64_t *)(arg1 + 0xd8) = iVar8;
    if (iVar8 != 0) {
        return arg1;
    }
code_r0x00018019e068:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019e070;
    fcn.18019c980((int64_t)arg1);
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_18019e0c0
// Address: 0x18019e0c0
// Size: 34 bytes
// ============================================================
void fcn.18019e0c0(int64_t param_1, undefined8 param_2)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x00018019e0df. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(*(int64_t *)(param_1 + 0x18) + 0xa8))(param_2);
    return;
}

// ============================================================
// Function: FUN_18019e120
// Address: 0x18019e120
// Size: 43 bytes
// ============================================================
undefined8 fcn.18019e120(void)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019e12a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18019e139;
    puVar2 = (undefined8 *)fcn.180245210(0, 0x15);
    if (puVar2 != (undefined8 *)0x0) {
        return *puVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_18019e150
// Address: 0x18019e150
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18019e150(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e160;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e16e;
    iVar1 = fcn.18019e360(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
    if ((iVar1 != 0) && (*(int64_t *)(in_RCX + 0x10) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e18d;
        fcn.1801a0940(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
    }
    return;
}

// ============================================================
// Function: FUN_18019e1a0
// Address: 0x18019e1a0
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18019e1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e1b5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = in_RCX;
        if (*in_RCX == 0) {
code_r0x00018019e1eb:
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e204;
            uVar1 = fcn.18019e360(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            uVar6 = (uint64_t)uVar1;
            if (*(int64_t *)(piVar3 + 0x156) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e218;
                iVar4 = func_0x000180193a50(in_RCX);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e225;
                    uVar5 = fcn.180221950(*(int64_t *)((int64_t)&var_18h + iVar2));
                    *(undefined8 *)(piVar3 + 0x156) = uVar5;
                }
            }
            if ((uVar1 != 0) && (*(int64_t *)(piVar3 + 0x156) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e258;
                uVar6 = fcn.1801a0940(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            }
            return uVar6;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e1df;
            piVar3 = (int32_t *)func_0x0001801bda50();
            if (piVar3 != (int32_t *)0x0) goto code_r0x00018019e1eb;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019e1eb
// Address: 0x18019e1eb
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18019e1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e1b5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = in_RCX;
        if (*in_RCX == 0) {
code_r0x00018019e1eb:
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e204;
            uVar1 = fcn.18019e360(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            uVar6 = (uint64_t)uVar1;
            if (*(int64_t *)(piVar3 + 0x156) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e218;
                iVar4 = func_0x000180193a50(in_RCX);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e225;
                    uVar5 = fcn.180221950(*(int64_t *)((int64_t)&var_18h + iVar2));
                    *(undefined8 *)(piVar3 + 0x156) = uVar5;
                }
            }
            if ((uVar1 != 0) && (*(int64_t *)(piVar3 + 0x156) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e258;
                uVar6 = fcn.1801a0940(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            }
            return uVar6;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e1df;
            piVar3 = (int32_t *)func_0x0001801bda50();
            if (piVar3 != (int32_t *)0x0) goto code_r0x00018019e1eb;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019e272
// Address: 0x18019e272
// Size: 4 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18019e1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e1b5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = in_RCX;
        if (*in_RCX == 0) {
code_r0x00018019e1eb:
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e204;
            uVar1 = fcn.18019e360(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            uVar6 = (uint64_t)uVar1;
            if (*(int64_t *)(piVar3 + 0x156) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e218;
                iVar4 = func_0x000180193a50(in_RCX);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e225;
                    uVar5 = fcn.180221950(*(int64_t *)((int64_t)&var_18h + iVar2));
                    *(undefined8 *)(piVar3 + 0x156) = uVar5;
                }
            }
            if ((uVar1 != 0) && (*(int64_t *)(piVar3 + 0x156) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e258;
                uVar6 = fcn.1801a0940(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            }
            return uVar6;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e1df;
            piVar3 = (int32_t *)func_0x0001801bda50();
            if (piVar3 != (int32_t *)0x0) goto code_r0x00018019e1eb;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019e276
// Address: 0x18019e276
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18019e1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t *in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e1b5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = in_RCX;
        if (*in_RCX == 0) {
code_r0x00018019e1eb:
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e204;
            uVar1 = fcn.18019e360(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            uVar6 = (uint64_t)uVar1;
            if (*(int64_t *)(piVar3 + 0x156) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e218;
                iVar4 = func_0x000180193a50(in_RCX);
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e225;
                    uVar5 = fcn.180221950(*(int64_t *)((int64_t)&var_18h + iVar2));
                    *(undefined8 *)(piVar3 + 0x156) = uVar5;
                }
            }
            if ((uVar1 != 0) && (*(int64_t *)(piVar3 + 0x156) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e258;
                uVar6 = fcn.1801a0940(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2));
            }
            return uVar6;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e1df;
            piVar3 = (int32_t *)func_0x0001801bda50();
            if (piVar3 != (int32_t *)0x0) goto code_r0x00018019e1eb;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019e290
// Address: 0x18019e290
// Size: 194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18019e290(int64_t arg_68h, int64_t arg_a0h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int32_t in_EDX;
    uint64_t uVar5;
    undefined8 in_R8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e2a0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3);
    if (in_EDX < 0x50) {
        uVar5 = (uint64_t)in_EDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e2cd;
        fcn.180498030((int64_t)&var_18h + iVar3, in_RCX, uVar5);
        if (0x4f < uVar5) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e351;
            func_0x000180459e6c();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        *(undefined *)((int64_t)&var_18h + uVar5 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e2e2;
        iVar4 = func_0x0001801c5250((int64_t)&var_18h + iVar3);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e2f2;
            iVar2 = func_0x000180222110(in_R8, iVar4);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e2fb;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e313;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e325;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e33b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_18019e360
// Address: 0x18019e360
// Size: 200 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18019e360(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    char *in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e375;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e383;
    iVar4 = func_0x000180221f20();
    if (iVar4 != 0) {
        if (*in_RDX == '\0') {
code_r0x00018019e408:
            iVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e410;
            fcn.180221d50(iVar1);
            *in_RCX = iVar4;
            return 1;
        }
        *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8) = iVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e3af;
        iVar2 = func_0x00018024a850(in_RDX, 0x3a, 1, fcn.18019e290);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e3bb;
            iVar2 = fcn.180222010(iVar4);
            if (iVar2 != 0) goto code_r0x00018019e408;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e3c4;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e3dc;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e3ee;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019e3f6;
        fcn.180221d50(iVar4);
    }
    return 0;
}

// ============================================================
// Function: FUN_18019e430
// Address: 0x18019e430
// Size: 69 bytes
// ============================================================
undefined8 fcn.18019e430(int64_t param_1, int32_t param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e43c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((param_2 != 0) && (param_1 != 0)) {
        *(int32_t *)((int64_t)&var_18h + iVar2) = param_2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e459;
        iVar1 = fcn.180221a50(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (-1 < iVar1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019e467;
            uVar3 = fcn.180222340(param_1, iVar1);
            return uVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019e480
// Address: 0x18019e480
// Size: 85 bytes
// ============================================================
bool fcn.18019e480(int64_t param_1, uint64_t param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019e48c;
    iVar1 = fcn.18045a350();
    if (8 < param_2) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18019e4ae;
    iVar1 = fcn.1801a1fe0(param_2, param_1);
    if (iVar1 != 0) {
        return (*(uint32_t *)(iVar1 + 4) & *(uint32_t *)(param_1 + 0x69c)) != 0;
    }
    return true;
}

// ============================================================
// Function: FUN_18019e4e0
// Address: 0x18019e4e0
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18019e4e0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int32_t in_ECX;
    uint64_t uVar10;
    uint32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint32_t in_R8D;
    int64_t *piVar11;
    uint32_t in_R9D;
    int64_t *piVar12;
    bool bVar13;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int32_t *)((int64_t)&arg_50h + iVar8);
    uVar10 = 0;
    *(undefined4 *)((int64_t)&var_28h + iVar8) = 0;
    if ((iVar1 == 3) || (iVar1 == 6)) {
        uVar10 = 1;
        *(undefined4 *)((int64_t)&var_28h + iVar8) = 1;
    }
    ppiVar3 = *(int64_t ***)((int64_t)&arg_60h + iVar8);
    ppiVar4 = *(int64_t ***)((int64_t)&arg_68h + iVar8);
    piVar12 = *ppiVar3;
    piVar11 = *ppiVar4;
    piVar9 = piVar12;
    if ((int32_t)uVar10 == 0) {
        piVar9 = piVar11;
    }
    *(int64_t **)((int64_t)&arg_60h + iVar8) = piVar9;
    if (piVar9 == (int64_t *)0x0) {
        *ppiVar3 = piVar12;
        *ppiVar4 = piVar11;
        return;
    }
    uVar2 = *(uint32_t *)(&stack0x00000048 + iVar8);
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_RSI;
    piVar9 = piVar11;
    if ((int32_t)uVar10 == 0) {
        piVar9 = piVar12;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_RBP;
    do {
        if (piVar9 == (int64_t *)0x0) break;
        piVar5 = (int64_t *)piVar9[uVar10 + 2];
        iVar6 = *piVar9;
        if (*(int32_t *)((int64_t)&arg_58h + iVar8) < 0) {
            if (((((((in_ECX == 0) || (in_ECX == *(int32_t *)(iVar6 + 0x18))) &&
                   ((in_EDX == 0 || ((*(uint32_t *)(iVar6 + 0x1c) & in_EDX) != 0)))) &&
                  ((in_R8D == 0 || ((*(uint32_t *)(iVar6 + 0x20) & in_R8D) != 0)))) &&
                 ((in_R9D == 0 || ((*(uint32_t *)(iVar6 + 0x24) & in_R9D) != 0)))) &&
                ((((*(uint32_t *)((int64_t)&arg_38h + iVar8) == 0 ||
                   ((*(uint32_t *)(iVar6 + 0x28) & *(uint32_t *)((int64_t)&arg_38h + iVar8)) != 0)) &&
                  ((*(int32_t *)((int64_t)&arg_40h + iVar8) == 0 ||
                   (*(int32_t *)((int64_t)&arg_40h + iVar8) == *(int32_t *)(iVar6 + 0x2c))))) &&
                 (((uVar2 & 0x1f) == 0 || ((*(uint32_t *)(iVar6 + 0x3c) & uVar2 & 0x1f) != 0)))))) &&
               (((uVar2 & 0x20) == 0 || ((*(uint32_t *)(iVar6 + 0x3c) & uVar2 & 0x20) != 0))))
            goto code_r0x00018019e625;
        } else if (*(int32_t *)((int64_t)&arg_58h + iVar8) == *(int32_t *)(iVar6 + 0x44)) {
code_r0x00018019e625:
            if (iVar1 == 1) {
                if (*(int32_t *)(piVar9 + 1) == 0) {
                    if (piVar9 != piVar11) {
                        if (piVar9 == piVar12) {
                            piVar12 = (int64_t *)piVar9[2];
                        }
                        if (piVar9[3] != 0) {
                            *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                        }
                        if (piVar9[2] != 0) {
                            *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                        }
                        piVar11[2] = (int64_t)piVar9;
                        piVar9[3] = (int64_t)piVar11;
                        piVar9[2] = 0;
                        piVar11 = piVar9;
                    }
                    *(undefined4 *)(piVar9 + 1) = 1;
                }
            } else if (iVar1 == 4) {
                if ((*(int32_t *)(piVar9 + 1) != 0) && (piVar9 != piVar11)) {
                    if (piVar9 == piVar12) {
                        piVar12 = (int64_t *)piVar9[2];
                    }
                    if (piVar9[3] != 0) {
                        *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                    }
                    if (piVar9[2] != 0) {
                        *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                    }
                    piVar11[2] = (int64_t)piVar9;
                    piVar9[3] = (int64_t)piVar11;
                    piVar9[2] = 0;
                    piVar11 = piVar9;
                }
            } else if (iVar1 == 3) {
                if (*(int32_t *)(piVar9 + 1) != 0) {
                    if (piVar9 == piVar12) {
                        *(undefined4 *)(piVar9 + 1) = 0;
                    } else {
                        if (piVar9 == piVar11) {
                            piVar11 = (int64_t *)piVar9[3];
                        }
                        if (piVar9[2] != 0) {
                            *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                        }
                        if (piVar9[3] != 0) {
                            *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                        }
                        piVar12[3] = (int64_t)piVar9;
                        piVar9[2] = (int64_t)piVar12;
                        piVar9[3] = 0;
                        *(undefined4 *)(piVar9 + 1) = 0;
                        piVar12 = piVar9;
                    }
                }
            } else if (iVar1 == 6) {
                if ((*(int32_t *)(piVar9 + 1) != 0) && (piVar9 != piVar12)) {
                    if (piVar9 == piVar11) {
                        piVar11 = (int64_t *)piVar9[3];
                    }
                    if (piVar9[2] != 0) {
                        *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                    }
                    if (piVar9[3] != 0) {
                        *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                    }
                    piVar12[3] = (int64_t)piVar9;
                    piVar9[2] = (int64_t)piVar12;
                    piVar9[3] = 0;
                    piVar12 = piVar9;
                }
            } else if (iVar1 == 2) {
                piVar7 = (int64_t *)piVar9[2];
                if (piVar12 != piVar9) {
                    *(int64_t **)(piVar9[3] + 0x10) = (int64_t *)piVar9[2];
                    piVar7 = piVar12;
                }
                piVar12 = piVar7;
                if (piVar11 == piVar9) {
                    piVar11 = (int64_t *)piVar9[3];
                }
                *(undefined4 *)(piVar9 + 1) = 0;
                if (piVar9[2] != 0) {
                    *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                }
                if (piVar9[3] != 0) {
                    *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                }
                piVar9[2] = 0;
                piVar9[3] = 0;
            }
        }
        uVar10 = (uint64_t)*(uint32_t *)((int64_t)&var_28h + iVar8);
        bVar13 = piVar9 != *(int64_t **)((int64_t)&arg_60h + iVar8);
        piVar9 = piVar5;
    } while (bVar13);
    *ppiVar3 = piVar12;
    *ppiVar4 = piVar11;
    return;
}

// ============================================================
// Function: FUN_18019e55f
// Address: 0x18019e55f
// Size: 716 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18019e4e0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int32_t in_ECX;
    uint64_t uVar10;
    uint32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint32_t in_R8D;
    int64_t *piVar11;
    uint32_t in_R9D;
    int64_t *piVar12;
    bool bVar13;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int32_t *)((int64_t)&arg_50h + iVar8);
    uVar10 = 0;
    *(undefined4 *)((int64_t)&var_28h + iVar8) = 0;
    if ((iVar1 == 3) || (iVar1 == 6)) {
        uVar10 = 1;
        *(undefined4 *)((int64_t)&var_28h + iVar8) = 1;
    }
    ppiVar3 = *(int64_t ***)((int64_t)&arg_60h + iVar8);
    ppiVar4 = *(int64_t ***)((int64_t)&arg_68h + iVar8);
    piVar12 = *ppiVar3;
    piVar11 = *ppiVar4;
    piVar9 = piVar12;
    if ((int32_t)uVar10 == 0) {
        piVar9 = piVar11;
    }
    *(int64_t **)((int64_t)&arg_60h + iVar8) = piVar9;
    if (piVar9 == (int64_t *)0x0) {
        *ppiVar3 = piVar12;
        *ppiVar4 = piVar11;
        return;
    }
    uVar2 = *(uint32_t *)(&stack0x00000048 + iVar8);
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_RSI;
    piVar9 = piVar11;
    if ((int32_t)uVar10 == 0) {
        piVar9 = piVar12;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_RBP;
    do {
        if (piVar9 == (int64_t *)0x0) break;
        piVar5 = (int64_t *)piVar9[uVar10 + 2];
        iVar6 = *piVar9;
        if (*(int32_t *)((int64_t)&arg_58h + iVar8) < 0) {
            if (((((((in_ECX == 0) || (in_ECX == *(int32_t *)(iVar6 + 0x18))) &&
                   ((in_EDX == 0 || ((*(uint32_t *)(iVar6 + 0x1c) & in_EDX) != 0)))) &&
                  ((in_R8D == 0 || ((*(uint32_t *)(iVar6 + 0x20) & in_R8D) != 0)))) &&
                 ((in_R9D == 0 || ((*(uint32_t *)(iVar6 + 0x24) & in_R9D) != 0)))) &&
                ((((*(uint32_t *)((int64_t)&arg_38h + iVar8) == 0 ||
                   ((*(uint32_t *)(iVar6 + 0x28) & *(uint32_t *)((int64_t)&arg_38h + iVar8)) != 0)) &&
                  ((*(int32_t *)((int64_t)&arg_40h + iVar8) == 0 ||
                   (*(int32_t *)((int64_t)&arg_40h + iVar8) == *(int32_t *)(iVar6 + 0x2c))))) &&
                 (((uVar2 & 0x1f) == 0 || ((*(uint32_t *)(iVar6 + 0x3c) & uVar2 & 0x1f) != 0)))))) &&
               (((uVar2 & 0x20) == 0 || ((*(uint32_t *)(iVar6 + 0x3c) & uVar2 & 0x20) != 0))))
            goto code_r0x00018019e625;
        } else if (*(int32_t *)((int64_t)&arg_58h + iVar8) == *(int32_t *)(iVar6 + 0x44)) {
code_r0x00018019e625:
            if (iVar1 == 1) {
                if (*(int32_t *)(piVar9 + 1) == 0) {
                    if (piVar9 != piVar11) {
                        if (piVar9 == piVar12) {
                            piVar12 = (int64_t *)piVar9[2];
                        }
                        if (piVar9[3] != 0) {
                            *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                        }
                        if (piVar9[2] != 0) {
                            *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                        }
                        piVar11[2] = (int64_t)piVar9;
                        piVar9[3] = (int64_t)piVar11;
                        piVar9[2] = 0;
                        piVar11 = piVar9;
                    }
                    *(undefined4 *)(piVar9 + 1) = 1;
                }
            } else if (iVar1 == 4) {
                if ((*(int32_t *)(piVar9 + 1) != 0) && (piVar9 != piVar11)) {
                    if (piVar9 == piVar12) {
                        piVar12 = (int64_t *)piVar9[2];
                    }
                    if (piVar9[3] != 0) {
                        *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                    }
                    if (piVar9[2] != 0) {
                        *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                    }
                    piVar11[2] = (int64_t)piVar9;
                    piVar9[3] = (int64_t)piVar11;
                    piVar9[2] = 0;
                    piVar11 = piVar9;
                }
            } else if (iVar1 == 3) {
                if (*(int32_t *)(piVar9 + 1) != 0) {
                    if (piVar9 == piVar12) {
                        *(undefined4 *)(piVar9 + 1) = 0;
                    } else {
                        if (piVar9 == piVar11) {
                            piVar11 = (int64_t *)piVar9[3];
                        }
                        if (piVar9[2] != 0) {
                            *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                        }
                        if (piVar9[3] != 0) {
                            *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                        }
                        piVar12[3] = (int64_t)piVar9;
                        piVar9[2] = (int64_t)piVar12;
                        piVar9[3] = 0;
                        *(undefined4 *)(piVar9 + 1) = 0;
                        piVar12 = piVar9;
                    }
                }
            } else if (iVar1 == 6) {
                if ((*(int32_t *)(piVar9 + 1) != 0) && (piVar9 != piVar12)) {
                    if (piVar9 == piVar11) {
                        piVar11 = (int64_t *)piVar9[3];
                    }
                    if (piVar9[2] != 0) {
                        *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                    }
                    if (piVar9[3] != 0) {
                        *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                    }
                    piVar12[3] = (int64_t)piVar9;
                    piVar9[2] = (int64_t)piVar12;
                    piVar9[3] = 0;
                    piVar12 = piVar9;
                }
            } else if (iVar1 == 2) {
                piVar7 = (int64_t *)piVar9[2];
                if (piVar12 != piVar9) {
                    *(int64_t **)(piVar9[3] + 0x10) = (int64_t *)piVar9[2];
                    piVar7 = piVar12;
                }
                piVar12 = piVar7;
                if (piVar11 == piVar9) {
                    piVar11 = (int64_t *)piVar9[3];
                }
                *(undefined4 *)(piVar9 + 1) = 0;
                if (piVar9[2] != 0) {
                    *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                }
                if (piVar9[3] != 0) {
                    *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                }
                piVar9[2] = 0;
                piVar9[3] = 0;
            }
        }
        uVar10 = (uint64_t)*(uint32_t *)((int64_t)&var_28h + iVar8);
        bVar13 = piVar9 != *(int64_t **)((int64_t)&arg_60h + iVar8);
        piVar9 = piVar5;
    } while (bVar13);
    *ppiVar3 = piVar12;
    *ppiVar4 = piVar11;
    return;
}

// ============================================================
// Function: FUN_18019e82b
// Address: 0x18019e82b
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18019e4e0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int32_t in_ECX;
    uint64_t uVar10;
    uint32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint32_t in_R8D;
    int64_t *piVar11;
    uint32_t in_R9D;
    int64_t *piVar12;
    bool bVar13;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar1 = *(int32_t *)((int64_t)&arg_50h + iVar8);
    uVar10 = 0;
    *(undefined4 *)((int64_t)&var_28h + iVar8) = 0;
    if ((iVar1 == 3) || (iVar1 == 6)) {
        uVar10 = 1;
        *(undefined4 *)((int64_t)&var_28h + iVar8) = 1;
    }
    ppiVar3 = *(int64_t ***)((int64_t)&arg_60h + iVar8);
    ppiVar4 = *(int64_t ***)((int64_t)&arg_68h + iVar8);
    piVar12 = *ppiVar3;
    piVar11 = *ppiVar4;
    piVar9 = piVar12;
    if ((int32_t)uVar10 == 0) {
        piVar9 = piVar11;
    }
    *(int64_t **)((int64_t)&arg_60h + iVar8) = piVar9;
    if (piVar9 == (int64_t *)0x0) {
        *ppiVar3 = piVar12;
        *ppiVar4 = piVar11;
        return;
    }
    uVar2 = *(uint32_t *)(&stack0x00000048 + iVar8);
    *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_RSI;
    piVar9 = piVar11;
    if ((int32_t)uVar10 == 0) {
        piVar9 = piVar12;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_RBP;
    do {
        if (piVar9 == (int64_t *)0x0) break;
        piVar5 = (int64_t *)piVar9[uVar10 + 2];
        iVar6 = *piVar9;
        if (*(int32_t *)((int64_t)&arg_58h + iVar8) < 0) {
            if (((((((in_ECX == 0) || (in_ECX == *(int32_t *)(iVar6 + 0x18))) &&
                   ((in_EDX == 0 || ((*(uint32_t *)(iVar6 + 0x1c) & in_EDX) != 0)))) &&
                  ((in_R8D == 0 || ((*(uint32_t *)(iVar6 + 0x20) & in_R8D) != 0)))) &&
                 ((in_R9D == 0 || ((*(uint32_t *)(iVar6 + 0x24) & in_R9D) != 0)))) &&
                ((((*(uint32_t *)((int64_t)&arg_38h + iVar8) == 0 ||
                   ((*(uint32_t *)(iVar6 + 0x28) & *(uint32_t *)((int64_t)&arg_38h + iVar8)) != 0)) &&
                  ((*(int32_t *)((int64_t)&arg_40h + iVar8) == 0 ||
                   (*(int32_t *)((int64_t)&arg_40h + iVar8) == *(int32_t *)(iVar6 + 0x2c))))) &&
                 (((uVar2 & 0x1f) == 0 || ((*(uint32_t *)(iVar6 + 0x3c) & uVar2 & 0x1f) != 0)))))) &&
               (((uVar2 & 0x20) == 0 || ((*(uint32_t *)(iVar6 + 0x3c) & uVar2 & 0x20) != 0))))
            goto code_r0x00018019e625;
        } else if (*(int32_t *)((int64_t)&arg_58h + iVar8) == *(int32_t *)(iVar6 + 0x44)) {
code_r0x00018019e625:
            if (iVar1 == 1) {
                if (*(int32_t *)(piVar9 + 1) == 0) {
                    if (piVar9 != piVar11) {
                        if (piVar9 == piVar12) {
                            piVar12 = (int64_t *)piVar9[2];
                        }
                        if (piVar9[3] != 0) {
                            *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                        }
                        if (piVar9[2] != 0) {
                            *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                        }
                        piVar11[2] = (int64_t)piVar9;
                        piVar9[3] = (int64_t)piVar11;
                        piVar9[2] = 0;
                        piVar11 = piVar9;
                    }
                    *(undefined4 *)(piVar9 + 1) = 1;
                }
            } else if (iVar1 == 4) {
                if ((*(int32_t *)(piVar9 + 1) != 0) && (piVar9 != piVar11)) {
                    if (piVar9 == piVar12) {
                        piVar12 = (int64_t *)piVar9[2];
                    }
                    if (piVar9[3] != 0) {
                        *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                    }
                    if (piVar9[2] != 0) {
                        *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                    }
                    piVar11[2] = (int64_t)piVar9;
                    piVar9[3] = (int64_t)piVar11;
                    piVar9[2] = 0;
                    piVar11 = piVar9;
                }
            } else if (iVar1 == 3) {
                if (*(int32_t *)(piVar9 + 1) != 0) {
                    if (piVar9 == piVar12) {
                        *(undefined4 *)(piVar9 + 1) = 0;
                    } else {
                        if (piVar9 == piVar11) {
                            piVar11 = (int64_t *)piVar9[3];
                        }
                        if (piVar9[2] != 0) {
                            *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                        }
                        if (piVar9[3] != 0) {
                            *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                        }
                        piVar12[3] = (int64_t)piVar9;
                        piVar9[2] = (int64_t)piVar12;
                        piVar9[3] = 0;
                        *(undefined4 *)(piVar9 + 1) = 0;
                        piVar12 = piVar9;
                    }
                }
            } else if (iVar1 == 6) {
                if ((*(int32_t *)(piVar9 + 1) != 0) && (piVar9 != piVar12)) {
                    if (piVar9 == piVar11) {
                        piVar11 = (int64_t *)piVar9[3];
                    }
                    if (piVar9[2] != 0) {
                        *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                    }
                    if (piVar9[3] != 0) {
                        *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                    }
                    piVar12[3] = (int64_t)piVar9;
                    piVar9[2] = (int64_t)piVar12;
                    piVar9[3] = 0;
                    piVar12 = piVar9;
                }
            } else if (iVar1 == 2) {
                piVar7 = (int64_t *)piVar9[2];
                if (piVar12 != piVar9) {
                    *(int64_t **)(piVar9[3] + 0x10) = (int64_t *)piVar9[2];
                    piVar7 = piVar12;
                }
                piVar12 = piVar7;
                if (piVar11 == piVar9) {
                    piVar11 = (int64_t *)piVar9[3];
                }
                *(undefined4 *)(piVar9 + 1) = 0;
                if (piVar9[2] != 0) {
                    *(int64_t *)(piVar9[2] + 0x18) = piVar9[3];
                }
                if (piVar9[3] != 0) {
                    *(int64_t *)(piVar9[3] + 0x10) = piVar9[2];
                }
                piVar9[2] = 0;
                piVar9[3] = 0;
            }
        }
        uVar10 = (uint64_t)*(uint32_t *)((int64_t)&var_28h + iVar8);
        bVar13 = piVar9 != *(int64_t **)((int64_t)&arg_60h + iVar8);
        piVar9 = piVar5;
    } while (bVar13);
    *ppiVar3 = piVar12;
    *ppiVar4 = piVar11;
    return;
}

// ============================================================
// Function: FUN_18019e850
// Address: 0x18019e850
// Size: 56 bytes
// ============================================================
void fcn.18019e850(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_98h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 *puVar11;
    int32_t iVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined auVar17 [16];
    undefined in_XMM2 [16];
    undefined auVar18 [16];
    uint64_t uVar20;
    undefined auVar19 [16];
    undefined auVar21 [16];
    undefined auVar22 [16];
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_8h;
    undefined4 auStackX_10 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    iVar10 = (int32_t)arg2;
    if (0 < iVar10) {
        var_20h._0_4_ = (undefined4)arg4;
        var_18h._0_4_ = (undefined4)arg3;
        uStack_30 = 0x18019e873;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        iVar9 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        iVar13 = 0;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -4) = unaff_XMM6_Db;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7) = unaff_XMM6_Dc;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + 4) = unaff_XMM6_Dd;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R12;
        iVar12 = 0;
        uVar6 = *(uint32_t *)((int64_t)&arg_80h + iVar7);
        puVar11 = (undefined8 *)(iVar9 + 0x18);
        *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R13;
        uVar1 = *(uint32_t *)((int64_t)&arg_78h + iVar7);
        uVar2 = *(uint32_t *)((int64_t)&arg_70h + iVar7);
        do {
            pcVar4 = *(code **)(placeholder_0 + 200);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019e8ce;
            piVar8 = (int32_t *)(*pcVar4)(iVar12);
            if (((((piVar8 != (int32_t *)0x0) && (*piVar8 != 0)) &&
                 ((piVar8[7] & *(uint32_t *)((int64_t)&arg_68h + iVar7)) == 0)) &&
                (((piVar8[8] & uVar2) == 0 && ((piVar8[9] & uVar1) == 0)))) && ((piVar8[10] & uVar6) == 0)) {
                if ((*(uint8_t *)(*(int64_t *)(placeholder_0 + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = piVar8[0xb];
                } else {
                    iVar3 = piVar8[0xd];
                }
                if (iVar3 != 0) {
                    iVar13 = iVar13 + 1;
                    puVar11[-3] = piVar8;
                    puVar11[-1] = 0;
                    *puVar11 = 0;
                    *(undefined4 *)(puVar11 + -2) = 0;
                    puVar11 = puVar11 + 4;
                }
            }
            iVar12 = iVar12 + 1;
        } while (iVar12 < iVar10);
        iVar5 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        if (0 < iVar13) {
            *(undefined8 *)(iVar5 + 0x18) = 0;
            if (1 < iVar13) {
                iVar10 = 1;
                *(int64_t *)(iVar5 + 0x10) = iVar5 + 0x20;
                if (((1 < iVar13 + -1) && (3 < iVar13 - 2U)) && (1 < *(int32_t *)0x1806a3990)) {
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar7) = unaff_XMM7_Da;
                    *(undefined4 *)(&stack0xfffffffffffffffc + iVar7) = unaff_XMM7_Db;
                    *(undefined4 *)(&stack0x00000000 + iVar7) = unaff_XMM7_Dc;
                    *(undefined4 *)(&stack0x00000004 + iVar7) = unaff_XMM7_Dd;
                    uVar6 = iVar13 - 2U & 0x80000003;
                    if ((int32_t)uVar6 < 0) {
                        uVar6 = (uVar6 - 1 | 0xfffffffc) + 1;
                    }
                    piVar14 = (int64_t *)(iVar5 + 0x50);
                    iVar12 = iVar10;
                    do {
                        iVar3 = iVar12 + 2;
                        iVar10 = iVar12 + 4;
                        auVar17._0_4_ = iVar12 + -1;
                        auVar17._4_4_ = iVar12;
                        auVar17._8_4_ = iVar12;
                        auVar17._12_4_ = iVar12;
                        auVar21._0_4_ = iVar12 + 1;
                        auVar21._4_4_ = iVar12 + 2;
                        auVar21._8_4_ = iVar12;
                        auVar21._12_4_ = iVar12;
                        auVar18 = pmovsxdq(in_XMM2, auVar17);
                        uVar20 = auVar18._8_8_ * 0x20 + iVar9;
                        piVar14[-3] = auVar18._0_8_ * 0x20 + iVar9;
                        auVar19._8_8_ = 0;
                        auVar19._0_8_ = uVar20;
                        piVar14[1] = uVar20;
                        auVar17 = pmovsxdq(auVar17, auVar21);
                        piVar14[-4] = auVar17._0_8_ * 0x20 + iVar9;
                        *piVar14 = auVar17._8_8_ * 0x20 + iVar9;
                        auVar18._0_4_ = iVar12 + 1;
                        auVar18._4_4_ = iVar12 + 2;
                        auVar18._8_4_ = iVar3;
                        auVar18._12_4_ = iVar3;
                        auVar22._0_4_ = iVar12 + 3;
                        auVar22._4_4_ = iVar12 + 4;
                        auVar22._8_4_ = iVar3;
                        auVar22._12_4_ = iVar3;
                        auVar17 = pmovsxdq(auVar19, auVar18);
                        uVar20 = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14[5] = auVar17._0_8_ * 0x20 + iVar9;
                        in_XMM2._8_8_ = 0;
                        in_XMM2._0_8_ = uVar20;
                        piVar14[9] = uVar20;
                        auVar17 = pmovsxdq(auVar18, auVar22);
                        piVar14[4] = auVar17._0_8_ * 0x20 + iVar9;
                        piVar14[8] = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14 = piVar14 + 0x10;
                        iVar12 = iVar10;
                    } while (iVar10 < (int32_t)((iVar13 + -1) - uVar6));
                }
                iVar16 = (int64_t)iVar13 + -1;
                iVar9 = (int64_t)iVar10;
                if (iVar9 < iVar16) {
                    iVar15 = iVar16 - iVar9;
                    piVar14 = (int64_t *)(iVar9 * 0x20 + 0x10 + iVar5);
                    do {
                        *piVar14 = (int64_t)(iVar10 + 1) * 0x20 + iVar5;
                        piVar14[1] = (int64_t)(iVar10 + -1) * 0x20 + iVar5;
                        iVar15 = iVar15 + -1;
                        piVar14 = piVar14 + 4;
                        iVar10 = iVar10 + 1;
                    } while (iVar15 != 0);
                }
                *(int64_t *)(iVar16 * 0x20 + 0x18 + iVar5) = (int64_t)(iVar13 + -2) * 0x20 + iVar5;
            }
            piVar14 = *(int64_t **)((int64_t)&arg_90h + iVar7);
            iVar9 = (int64_t)iVar13 * 0x20 + -0x20 + iVar5;
            *(undefined8 *)(iVar9 + 0x10) = 0;
            *piVar14 = iVar5;
            **(int64_t **)((int64_t)&arg_98h + iVar7) = iVar9;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019e888
// Address: 0x18019e888
// Size: 207 bytes
// ============================================================
void fcn.18019e850(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_98h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 *puVar11;
    int32_t iVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined auVar17 [16];
    undefined in_XMM2 [16];
    undefined auVar18 [16];
    uint64_t uVar20;
    undefined auVar19 [16];
    undefined auVar21 [16];
    undefined auVar22 [16];
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_8h;
    undefined4 auStackX_10 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    iVar10 = (int32_t)arg2;
    if (0 < iVar10) {
        var_20h._0_4_ = (undefined4)arg4;
        var_18h._0_4_ = (undefined4)arg3;
        uStack_30 = 0x18019e873;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        iVar9 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        iVar13 = 0;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -4) = unaff_XMM6_Db;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7) = unaff_XMM6_Dc;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + 4) = unaff_XMM6_Dd;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R12;
        iVar12 = 0;
        uVar6 = *(uint32_t *)((int64_t)&arg_80h + iVar7);
        puVar11 = (undefined8 *)(iVar9 + 0x18);
        *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R13;
        uVar1 = *(uint32_t *)((int64_t)&arg_78h + iVar7);
        uVar2 = *(uint32_t *)((int64_t)&arg_70h + iVar7);
        do {
            pcVar4 = *(code **)(placeholder_0 + 200);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019e8ce;
            piVar8 = (int32_t *)(*pcVar4)(iVar12);
            if (((((piVar8 != (int32_t *)0x0) && (*piVar8 != 0)) &&
                 ((piVar8[7] & *(uint32_t *)((int64_t)&arg_68h + iVar7)) == 0)) &&
                (((piVar8[8] & uVar2) == 0 && ((piVar8[9] & uVar1) == 0)))) && ((piVar8[10] & uVar6) == 0)) {
                if ((*(uint8_t *)(*(int64_t *)(placeholder_0 + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = piVar8[0xb];
                } else {
                    iVar3 = piVar8[0xd];
                }
                if (iVar3 != 0) {
                    iVar13 = iVar13 + 1;
                    puVar11[-3] = piVar8;
                    puVar11[-1] = 0;
                    *puVar11 = 0;
                    *(undefined4 *)(puVar11 + -2) = 0;
                    puVar11 = puVar11 + 4;
                }
            }
            iVar12 = iVar12 + 1;
        } while (iVar12 < iVar10);
        iVar5 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        if (0 < iVar13) {
            *(undefined8 *)(iVar5 + 0x18) = 0;
            if (1 < iVar13) {
                iVar10 = 1;
                *(int64_t *)(iVar5 + 0x10) = iVar5 + 0x20;
                if (((1 < iVar13 + -1) && (3 < iVar13 - 2U)) && (1 < *(int32_t *)0x1806a3990)) {
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar7) = unaff_XMM7_Da;
                    *(undefined4 *)(&stack0xfffffffffffffffc + iVar7) = unaff_XMM7_Db;
                    *(undefined4 *)(&stack0x00000000 + iVar7) = unaff_XMM7_Dc;
                    *(undefined4 *)(&stack0x00000004 + iVar7) = unaff_XMM7_Dd;
                    uVar6 = iVar13 - 2U & 0x80000003;
                    if ((int32_t)uVar6 < 0) {
                        uVar6 = (uVar6 - 1 | 0xfffffffc) + 1;
                    }
                    piVar14 = (int64_t *)(iVar5 + 0x50);
                    iVar12 = iVar10;
                    do {
                        iVar3 = iVar12 + 2;
                        iVar10 = iVar12 + 4;
                        auVar17._0_4_ = iVar12 + -1;
                        auVar17._4_4_ = iVar12;
                        auVar17._8_4_ = iVar12;
                        auVar17._12_4_ = iVar12;
                        auVar21._0_4_ = iVar12 + 1;
                        auVar21._4_4_ = iVar12 + 2;
                        auVar21._8_4_ = iVar12;
                        auVar21._12_4_ = iVar12;
                        auVar18 = pmovsxdq(in_XMM2, auVar17);
                        uVar20 = auVar18._8_8_ * 0x20 + iVar9;
                        piVar14[-3] = auVar18._0_8_ * 0x20 + iVar9;
                        auVar19._8_8_ = 0;
                        auVar19._0_8_ = uVar20;
                        piVar14[1] = uVar20;
                        auVar17 = pmovsxdq(auVar17, auVar21);
                        piVar14[-4] = auVar17._0_8_ * 0x20 + iVar9;
                        *piVar14 = auVar17._8_8_ * 0x20 + iVar9;
                        auVar18._0_4_ = iVar12 + 1;
                        auVar18._4_4_ = iVar12 + 2;
                        auVar18._8_4_ = iVar3;
                        auVar18._12_4_ = iVar3;
                        auVar22._0_4_ = iVar12 + 3;
                        auVar22._4_4_ = iVar12 + 4;
                        auVar22._8_4_ = iVar3;
                        auVar22._12_4_ = iVar3;
                        auVar17 = pmovsxdq(auVar19, auVar18);
                        uVar20 = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14[5] = auVar17._0_8_ * 0x20 + iVar9;
                        in_XMM2._8_8_ = 0;
                        in_XMM2._0_8_ = uVar20;
                        piVar14[9] = uVar20;
                        auVar17 = pmovsxdq(auVar18, auVar22);
                        piVar14[4] = auVar17._0_8_ * 0x20 + iVar9;
                        piVar14[8] = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14 = piVar14 + 0x10;
                        iVar12 = iVar10;
                    } while (iVar10 < (int32_t)((iVar13 + -1) - uVar6));
                }
                iVar16 = (int64_t)iVar13 + -1;
                iVar9 = (int64_t)iVar10;
                if (iVar9 < iVar16) {
                    iVar15 = iVar16 - iVar9;
                    piVar14 = (int64_t *)(iVar9 * 0x20 + 0x10 + iVar5);
                    do {
                        *piVar14 = (int64_t)(iVar10 + 1) * 0x20 + iVar5;
                        piVar14[1] = (int64_t)(iVar10 + -1) * 0x20 + iVar5;
                        iVar15 = iVar15 + -1;
                        piVar14 = piVar14 + 4;
                        iVar10 = iVar10 + 1;
                    } while (iVar15 != 0);
                }
                *(int64_t *)(iVar16 * 0x20 + 0x18 + iVar5) = (int64_t)(iVar13 + -2) * 0x20 + iVar5;
            }
            piVar14 = *(int64_t **)((int64_t)&arg_90h + iVar7);
            iVar9 = (int64_t)iVar13 * 0x20 + -0x20 + iVar5;
            *(undefined8 *)(iVar9 + 0x10) = 0;
            *piVar14 = iVar5;
            **(int64_t **)((int64_t)&arg_98h + iVar7) = iVar9;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019e957
// Address: 0x18019e957
// Size: 69 bytes
// ============================================================
void fcn.18019e850(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_98h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 *puVar11;
    int32_t iVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined auVar17 [16];
    undefined in_XMM2 [16];
    undefined auVar18 [16];
    uint64_t uVar20;
    undefined auVar19 [16];
    undefined auVar21 [16];
    undefined auVar22 [16];
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_8h;
    undefined4 auStackX_10 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    iVar10 = (int32_t)arg2;
    if (0 < iVar10) {
        var_20h._0_4_ = (undefined4)arg4;
        var_18h._0_4_ = (undefined4)arg3;
        uStack_30 = 0x18019e873;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        iVar9 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        iVar13 = 0;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -4) = unaff_XMM6_Db;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7) = unaff_XMM6_Dc;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + 4) = unaff_XMM6_Dd;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R12;
        iVar12 = 0;
        uVar6 = *(uint32_t *)((int64_t)&arg_80h + iVar7);
        puVar11 = (undefined8 *)(iVar9 + 0x18);
        *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R13;
        uVar1 = *(uint32_t *)((int64_t)&arg_78h + iVar7);
        uVar2 = *(uint32_t *)((int64_t)&arg_70h + iVar7);
        do {
            pcVar4 = *(code **)(placeholder_0 + 200);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019e8ce;
            piVar8 = (int32_t *)(*pcVar4)(iVar12);
            if (((((piVar8 != (int32_t *)0x0) && (*piVar8 != 0)) &&
                 ((piVar8[7] & *(uint32_t *)((int64_t)&arg_68h + iVar7)) == 0)) &&
                (((piVar8[8] & uVar2) == 0 && ((piVar8[9] & uVar1) == 0)))) && ((piVar8[10] & uVar6) == 0)) {
                if ((*(uint8_t *)(*(int64_t *)(placeholder_0 + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = piVar8[0xb];
                } else {
                    iVar3 = piVar8[0xd];
                }
                if (iVar3 != 0) {
                    iVar13 = iVar13 + 1;
                    puVar11[-3] = piVar8;
                    puVar11[-1] = 0;
                    *puVar11 = 0;
                    *(undefined4 *)(puVar11 + -2) = 0;
                    puVar11 = puVar11 + 4;
                }
            }
            iVar12 = iVar12 + 1;
        } while (iVar12 < iVar10);
        iVar5 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        if (0 < iVar13) {
            *(undefined8 *)(iVar5 + 0x18) = 0;
            if (1 < iVar13) {
                iVar10 = 1;
                *(int64_t *)(iVar5 + 0x10) = iVar5 + 0x20;
                if (((1 < iVar13 + -1) && (3 < iVar13 - 2U)) && (1 < *(int32_t *)0x1806a3990)) {
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar7) = unaff_XMM7_Da;
                    *(undefined4 *)(&stack0xfffffffffffffffc + iVar7) = unaff_XMM7_Db;
                    *(undefined4 *)(&stack0x00000000 + iVar7) = unaff_XMM7_Dc;
                    *(undefined4 *)(&stack0x00000004 + iVar7) = unaff_XMM7_Dd;
                    uVar6 = iVar13 - 2U & 0x80000003;
                    if ((int32_t)uVar6 < 0) {
                        uVar6 = (uVar6 - 1 | 0xfffffffc) + 1;
                    }
                    piVar14 = (int64_t *)(iVar5 + 0x50);
                    iVar12 = iVar10;
                    do {
                        iVar3 = iVar12 + 2;
                        iVar10 = iVar12 + 4;
                        auVar17._0_4_ = iVar12 + -1;
                        auVar17._4_4_ = iVar12;
                        auVar17._8_4_ = iVar12;
                        auVar17._12_4_ = iVar12;
                        auVar21._0_4_ = iVar12 + 1;
                        auVar21._4_4_ = iVar12 + 2;
                        auVar21._8_4_ = iVar12;
                        auVar21._12_4_ = iVar12;
                        auVar18 = pmovsxdq(in_XMM2, auVar17);
                        uVar20 = auVar18._8_8_ * 0x20 + iVar9;
                        piVar14[-3] = auVar18._0_8_ * 0x20 + iVar9;
                        auVar19._8_8_ = 0;
                        auVar19._0_8_ = uVar20;
                        piVar14[1] = uVar20;
                        auVar17 = pmovsxdq(auVar17, auVar21);
                        piVar14[-4] = auVar17._0_8_ * 0x20 + iVar9;
                        *piVar14 = auVar17._8_8_ * 0x20 + iVar9;
                        auVar18._0_4_ = iVar12 + 1;
                        auVar18._4_4_ = iVar12 + 2;
                        auVar18._8_4_ = iVar3;
                        auVar18._12_4_ = iVar3;
                        auVar22._0_4_ = iVar12 + 3;
                        auVar22._4_4_ = iVar12 + 4;
                        auVar22._8_4_ = iVar3;
                        auVar22._12_4_ = iVar3;
                        auVar17 = pmovsxdq(auVar19, auVar18);
                        uVar20 = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14[5] = auVar17._0_8_ * 0x20 + iVar9;
                        in_XMM2._8_8_ = 0;
                        in_XMM2._0_8_ = uVar20;
                        piVar14[9] = uVar20;
                        auVar17 = pmovsxdq(auVar18, auVar22);
                        piVar14[4] = auVar17._0_8_ * 0x20 + iVar9;
                        piVar14[8] = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14 = piVar14 + 0x10;
                        iVar12 = iVar10;
                    } while (iVar10 < (int32_t)((iVar13 + -1) - uVar6));
                }
                iVar16 = (int64_t)iVar13 + -1;
                iVar9 = (int64_t)iVar10;
                if (iVar9 < iVar16) {
                    iVar15 = iVar16 - iVar9;
                    piVar14 = (int64_t *)(iVar9 * 0x20 + 0x10 + iVar5);
                    do {
                        *piVar14 = (int64_t)(iVar10 + 1) * 0x20 + iVar5;
                        piVar14[1] = (int64_t)(iVar10 + -1) * 0x20 + iVar5;
                        iVar15 = iVar15 + -1;
                        piVar14 = piVar14 + 4;
                        iVar10 = iVar10 + 1;
                    } while (iVar15 != 0);
                }
                *(int64_t *)(iVar16 * 0x20 + 0x18 + iVar5) = (int64_t)(iVar13 + -2) * 0x20 + iVar5;
            }
            piVar14 = *(int64_t **)((int64_t)&arg_90h + iVar7);
            iVar9 = (int64_t)iVar13 * 0x20 + -0x20 + iVar5;
            *(undefined8 *)(iVar9 + 0x10) = 0;
            *piVar14 = iVar5;
            **(int64_t **)((int64_t)&arg_98h + iVar7) = iVar9;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019e99c
// Address: 0x18019e99c
// Size: 278 bytes
// ============================================================
void fcn.18019e850(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_98h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 *puVar11;
    int32_t iVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined auVar17 [16];
    undefined in_XMM2 [16];
    undefined auVar18 [16];
    uint64_t uVar20;
    undefined auVar19 [16];
    undefined auVar21 [16];
    undefined auVar22 [16];
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_8h;
    undefined4 auStackX_10 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    iVar10 = (int32_t)arg2;
    if (0 < iVar10) {
        var_20h._0_4_ = (undefined4)arg4;
        var_18h._0_4_ = (undefined4)arg3;
        uStack_30 = 0x18019e873;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        iVar9 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        iVar13 = 0;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -4) = unaff_XMM6_Db;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7) = unaff_XMM6_Dc;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + 4) = unaff_XMM6_Dd;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R12;
        iVar12 = 0;
        uVar6 = *(uint32_t *)((int64_t)&arg_80h + iVar7);
        puVar11 = (undefined8 *)(iVar9 + 0x18);
        *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R13;
        uVar1 = *(uint32_t *)((int64_t)&arg_78h + iVar7);
        uVar2 = *(uint32_t *)((int64_t)&arg_70h + iVar7);
        do {
            pcVar4 = *(code **)(placeholder_0 + 200);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019e8ce;
            piVar8 = (int32_t *)(*pcVar4)(iVar12);
            if (((((piVar8 != (int32_t *)0x0) && (*piVar8 != 0)) &&
                 ((piVar8[7] & *(uint32_t *)((int64_t)&arg_68h + iVar7)) == 0)) &&
                (((piVar8[8] & uVar2) == 0 && ((piVar8[9] & uVar1) == 0)))) && ((piVar8[10] & uVar6) == 0)) {
                if ((*(uint8_t *)(*(int64_t *)(placeholder_0 + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = piVar8[0xb];
                } else {
                    iVar3 = piVar8[0xd];
                }
                if (iVar3 != 0) {
                    iVar13 = iVar13 + 1;
                    puVar11[-3] = piVar8;
                    puVar11[-1] = 0;
                    *puVar11 = 0;
                    *(undefined4 *)(puVar11 + -2) = 0;
                    puVar11 = puVar11 + 4;
                }
            }
            iVar12 = iVar12 + 1;
        } while (iVar12 < iVar10);
        iVar5 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        if (0 < iVar13) {
            *(undefined8 *)(iVar5 + 0x18) = 0;
            if (1 < iVar13) {
                iVar10 = 1;
                *(int64_t *)(iVar5 + 0x10) = iVar5 + 0x20;
                if (((1 < iVar13 + -1) && (3 < iVar13 - 2U)) && (1 < *(int32_t *)0x1806a3990)) {
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar7) = unaff_XMM7_Da;
                    *(undefined4 *)(&stack0xfffffffffffffffc + iVar7) = unaff_XMM7_Db;
                    *(undefined4 *)(&stack0x00000000 + iVar7) = unaff_XMM7_Dc;
                    *(undefined4 *)(&stack0x00000004 + iVar7) = unaff_XMM7_Dd;
                    uVar6 = iVar13 - 2U & 0x80000003;
                    if ((int32_t)uVar6 < 0) {
                        uVar6 = (uVar6 - 1 | 0xfffffffc) + 1;
                    }
                    piVar14 = (int64_t *)(iVar5 + 0x50);
                    iVar12 = iVar10;
                    do {
                        iVar3 = iVar12 + 2;
                        iVar10 = iVar12 + 4;
                        auVar17._0_4_ = iVar12 + -1;
                        auVar17._4_4_ = iVar12;
                        auVar17._8_4_ = iVar12;
                        auVar17._12_4_ = iVar12;
                        auVar21._0_4_ = iVar12 + 1;
                        auVar21._4_4_ = iVar12 + 2;
                        auVar21._8_4_ = iVar12;
                        auVar21._12_4_ = iVar12;
                        auVar18 = pmovsxdq(in_XMM2, auVar17);
                        uVar20 = auVar18._8_8_ * 0x20 + iVar9;
                        piVar14[-3] = auVar18._0_8_ * 0x20 + iVar9;
                        auVar19._8_8_ = 0;
                        auVar19._0_8_ = uVar20;
                        piVar14[1] = uVar20;
                        auVar17 = pmovsxdq(auVar17, auVar21);
                        piVar14[-4] = auVar17._0_8_ * 0x20 + iVar9;
                        *piVar14 = auVar17._8_8_ * 0x20 + iVar9;
                        auVar18._0_4_ = iVar12 + 1;
                        auVar18._4_4_ = iVar12 + 2;
                        auVar18._8_4_ = iVar3;
                        auVar18._12_4_ = iVar3;
                        auVar22._0_4_ = iVar12 + 3;
                        auVar22._4_4_ = iVar12 + 4;
                        auVar22._8_4_ = iVar3;
                        auVar22._12_4_ = iVar3;
                        auVar17 = pmovsxdq(auVar19, auVar18);
                        uVar20 = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14[5] = auVar17._0_8_ * 0x20 + iVar9;
                        in_XMM2._8_8_ = 0;
                        in_XMM2._0_8_ = uVar20;
                        piVar14[9] = uVar20;
                        auVar17 = pmovsxdq(auVar18, auVar22);
                        piVar14[4] = auVar17._0_8_ * 0x20 + iVar9;
                        piVar14[8] = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14 = piVar14 + 0x10;
                        iVar12 = iVar10;
                    } while (iVar10 < (int32_t)((iVar13 + -1) - uVar6));
                }
                iVar16 = (int64_t)iVar13 + -1;
                iVar9 = (int64_t)iVar10;
                if (iVar9 < iVar16) {
                    iVar15 = iVar16 - iVar9;
                    piVar14 = (int64_t *)(iVar9 * 0x20 + 0x10 + iVar5);
                    do {
                        *piVar14 = (int64_t)(iVar10 + 1) * 0x20 + iVar5;
                        piVar14[1] = (int64_t)(iVar10 + -1) * 0x20 + iVar5;
                        iVar15 = iVar15 + -1;
                        piVar14 = piVar14 + 4;
                        iVar10 = iVar10 + 1;
                    } while (iVar15 != 0);
                }
                *(int64_t *)(iVar16 * 0x20 + 0x18 + iVar5) = (int64_t)(iVar13 + -2) * 0x20 + iVar5;
            }
            piVar14 = *(int64_t **)((int64_t)&arg_90h + iVar7);
            iVar9 = (int64_t)iVar13 * 0x20 + -0x20 + iVar5;
            *(undefined8 *)(iVar9 + 0x10) = 0;
            *piVar14 = iVar5;
            **(int64_t **)((int64_t)&arg_98h + iVar7) = iVar9;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019eab2
// Address: 0x18019eab2
// Size: 173 bytes
// ============================================================
void fcn.18019e850(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_98h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 *puVar11;
    int32_t iVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined auVar17 [16];
    undefined in_XMM2 [16];
    undefined auVar18 [16];
    uint64_t uVar20;
    undefined auVar19 [16];
    undefined auVar21 [16];
    undefined auVar22 [16];
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_8h;
    undefined4 auStackX_10 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    iVar10 = (int32_t)arg2;
    if (0 < iVar10) {
        var_20h._0_4_ = (undefined4)arg4;
        var_18h._0_4_ = (undefined4)arg3;
        uStack_30 = 0x18019e873;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        iVar9 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        iVar13 = 0;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -8) = unaff_XMM6_Da;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + -4) = unaff_XMM6_Db;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7) = unaff_XMM6_Dc;
        *(undefined4 *)((int64_t)auStackX_10 + iVar7 + 4) = unaff_XMM6_Dd;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R12;
        iVar12 = 0;
        uVar6 = *(uint32_t *)((int64_t)&arg_80h + iVar7);
        puVar11 = (undefined8 *)(iVar9 + 0x18);
        *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R13;
        uVar1 = *(uint32_t *)((int64_t)&arg_78h + iVar7);
        uVar2 = *(uint32_t *)((int64_t)&arg_70h + iVar7);
        do {
            pcVar4 = *(code **)(placeholder_0 + 200);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019e8ce;
            piVar8 = (int32_t *)(*pcVar4)(iVar12);
            if (((((piVar8 != (int32_t *)0x0) && (*piVar8 != 0)) &&
                 ((piVar8[7] & *(uint32_t *)((int64_t)&arg_68h + iVar7)) == 0)) &&
                (((piVar8[8] & uVar2) == 0 && ((piVar8[9] & uVar1) == 0)))) && ((piVar8[10] & uVar6) == 0)) {
                if ((*(uint8_t *)(*(int64_t *)(placeholder_0 + 0xd8) + 0x50) & 8) == 0) {
                    iVar3 = piVar8[0xb];
                } else {
                    iVar3 = piVar8[0xd];
                }
                if (iVar3 != 0) {
                    iVar13 = iVar13 + 1;
                    puVar11[-3] = piVar8;
                    puVar11[-1] = 0;
                    *puVar11 = 0;
                    *(undefined4 *)(puVar11 + -2) = 0;
                    puVar11 = puVar11 + 4;
                }
            }
            iVar12 = iVar12 + 1;
        } while (iVar12 < iVar10);
        iVar5 = *(int64_t *)((int64_t)&arg_88h + iVar7);
        if (0 < iVar13) {
            *(undefined8 *)(iVar5 + 0x18) = 0;
            if (1 < iVar13) {
                iVar10 = 1;
                *(int64_t *)(iVar5 + 0x10) = iVar5 + 0x20;
                if (((1 < iVar13 + -1) && (3 < iVar13 - 2U)) && (1 < *(int32_t *)0x1806a3990)) {
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar7) = unaff_XMM7_Da;
                    *(undefined4 *)(&stack0xfffffffffffffffc + iVar7) = unaff_XMM7_Db;
                    *(undefined4 *)(&stack0x00000000 + iVar7) = unaff_XMM7_Dc;
                    *(undefined4 *)(&stack0x00000004 + iVar7) = unaff_XMM7_Dd;
                    uVar6 = iVar13 - 2U & 0x80000003;
                    if ((int32_t)uVar6 < 0) {
                        uVar6 = (uVar6 - 1 | 0xfffffffc) + 1;
                    }
                    piVar14 = (int64_t *)(iVar5 + 0x50);
                    iVar12 = iVar10;
                    do {
                        iVar3 = iVar12 + 2;
                        iVar10 = iVar12 + 4;
                        auVar17._0_4_ = iVar12 + -1;
                        auVar17._4_4_ = iVar12;
                        auVar17._8_4_ = iVar12;
                        auVar17._12_4_ = iVar12;
                        auVar21._0_4_ = iVar12 + 1;
                        auVar21._4_4_ = iVar12 + 2;
                        auVar21._8_4_ = iVar12;
                        auVar21._12_4_ = iVar12;
                        auVar18 = pmovsxdq(in_XMM2, auVar17);
                        uVar20 = auVar18._8_8_ * 0x20 + iVar9;
                        piVar14[-3] = auVar18._0_8_ * 0x20 + iVar9;
                        auVar19._8_8_ = 0;
                        auVar19._0_8_ = uVar20;
                        piVar14[1] = uVar20;
                        auVar17 = pmovsxdq(auVar17, auVar21);
                        piVar14[-4] = auVar17._0_8_ * 0x20 + iVar9;
                        *piVar14 = auVar17._8_8_ * 0x20 + iVar9;
                        auVar18._0_4_ = iVar12 + 1;
                        auVar18._4_4_ = iVar12 + 2;
                        auVar18._8_4_ = iVar3;
                        auVar18._12_4_ = iVar3;
                        auVar22._0_4_ = iVar12 + 3;
                        auVar22._4_4_ = iVar12 + 4;
                        auVar22._8_4_ = iVar3;
                        auVar22._12_4_ = iVar3;
                        auVar17 = pmovsxdq(auVar19, auVar18);
                        uVar20 = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14[5] = auVar17._0_8_ * 0x20 + iVar9;
                        in_XMM2._8_8_ = 0;
                        in_XMM2._0_8_ = uVar20;
                        piVar14[9] = uVar20;
                        auVar17 = pmovsxdq(auVar18, auVar22);
                        piVar14[4] = auVar17._0_8_ * 0x20 + iVar9;
                        piVar14[8] = auVar17._8_8_ * 0x20 + iVar9;
                        piVar14 = piVar14 + 0x10;
                        iVar12 = iVar10;
                    } while (iVar10 < (int32_t)((iVar13 + -1) - uVar6));
                }
                iVar16 = (int64_t)iVar13 + -1;
                iVar9 = (int64_t)iVar10;
                if (iVar9 < iVar16) {
                    iVar15 = iVar16 - iVar9;
                    piVar14 = (int64_t *)(iVar9 * 0x20 + 0x10 + iVar5);
                    do {
                        *piVar14 = (int64_t)(iVar10 + 1) * 0x20 + iVar5;
                        piVar14[1] = (int64_t)(iVar10 + -1) * 0x20 + iVar5;
                        iVar15 = iVar15 + -1;
                        piVar14 = piVar14 + 4;
                        iVar10 = iVar10 + 1;
                    } while (iVar15 != 0);
                }
                *(int64_t *)(iVar16 * 0x20 + 0x18 + iVar5) = (int64_t)(iVar13 + -2) * 0x20 + iVar5;
            }
            piVar14 = *(int64_t **)((int64_t)&arg_90h + iVar7);
            iVar9 = (int64_t)iVar13 * 0x20 + -0x20 + iVar5;
            *(undefined8 *)(iVar9 + 0x10) = 0;
            *piVar14 = iVar5;
            **(int64_t **)((int64_t)&arg_98h + iVar7) = iVar9;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019eb60
// Address: 0x18019eb60
// Size: 762 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8
fcn.18019eb60(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h,
             int64_t arg_e8h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    undefined8 *in_RCX;
    int32_t *piVar14;
    uint32_t *in_RDX;
    int64_t iVar15;
    int64_t *in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18019eb82;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar13 = *(int64_t *)(in_RDX + 0xbe);
    if (iVar13 != 0) {
        puVar1 = *(undefined8 **)(&stack0x00000078 + iVar7);
        uVar12 = 0;
        if (puVar1 == (undefined8 *)0x0) {
            if (in_R8 == (int64_t *)0x0) {
                return 0;
            }
        } else {
            *puVar1 = 0;
            *(uint32_t *)(&stack0xfffffffffffffff8 + iVar7) = in_RDX[0xbc];
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ebca;
            piVar8 = (int64_t *)fcn.180245210(0, 0x15);
            if ((piVar8 != (int64_t *)0x0) && (iVar11 = *piVar8, iVar11 != 0)) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ebe4;
                iVar4 = fcn.180221a50(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                if (-1 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ebf2;
                    uVar9 = fcn.180222340(iVar11, iVar4);
                    *puVar1 = uVar9;
                }
            }
            if (in_R8 == (int64_t *)0x0) {
                if (in_R9 == (int64_t *)0x0) {
                    return 1;
                }
                return 0;
            }
        }
        if (in_R9 != (int64_t *)0x0) {
            piVar14 = (int32_t *)0x1804ab6a0;
            uVar10 = uVar12;
            do {
                if (*piVar14 == *(int32_t *)(iVar13 + 0x24)) {
                    iVar4 = (int32_t)uVar10;
                    if (iVar4 == -1) {
                        *in_R8 = 0;
                    } else if (iVar4 == 5) {
                        uVar9 = in_RCX[0x8c];
                        uVar2 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ec62;
                        iVar11 = func_0x0001802119f0(uVar2, 0x180645710, uVar9);
                        *in_R8 = iVar11;
                        if (iVar11 == 0) {
                            return 0;
                        }
                    } else {
                        if (in_RCX[(int64_t)iVar4 + 0x94] == 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ec8b;
                        iVar5 = func_0x000180197510();
                        if (iVar5 == 0) {
                            return 0;
                        }
                        *in_R8 = in_RCX[(int64_t)iVar4 + 0x94];
                    }
                    goto code_r0x00018019ec9d;
                }
                uVar10 = uVar10 + 1;
                piVar14 = piVar14 + 2;
            } while (uVar10 < 0x18);
            *in_R8 = 0;
code_r0x00018019ec9d:
            piVar14 = (int32_t *)0x1804ab760;
            do {
                if (*piVar14 == *(int32_t *)(iVar13 + 0x28)) {
                    if ((int32_t)uVar12 != -1) {
                        iVar15 = (int64_t)(int32_t)uVar12;
                        iVar11 = in_RCX[iVar15 + 0xac];
                        if (iVar11 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ed09;
                            iVar4 = func_0x0001801975f0(iVar11);
                            if (iVar4 != 0) {
                                *in_R9 = iVar11;
                                piVar14 = *(int32_t **)((int64_t)&arg_68h + iVar7);
                                if (piVar14 != (int32_t *)0x0) {
                                    *piVar14 = *(int32_t *)((int64_t)in_RCX + iVar15 * 4 + 0x468);
                                }
                                if (*(undefined8 **)((int64_t)&arg_70h + iVar7) != (undefined8 *)0x0) {
                                    **(undefined8 **)((int64_t)&arg_70h + iVar7) = in_RCX[iVar15 + 0xba];
                                }
                                goto code_r0x00018019ed42;
                            }
                        }
                        iVar13 = *in_R8;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ee38;
                        func_0x0001801974e0(iVar13);
                        return 0;
                    }
                    break;
                }
                uVar12 = uVar12 + 1;
                piVar14 = piVar14 + 2;
            } while (uVar12 < 0xe);
            piVar14 = *(int32_t **)((int64_t)&arg_68h + iVar7);
            *in_R9 = 0;
            if (piVar14 != (int32_t *)0x0) {
                *piVar14 = 0;
            }
            if (*(undefined8 **)((int64_t)&arg_70h + iVar7) != (undefined8 *)0x0) {
                **(undefined8 **)((int64_t)&arg_70h + iVar7) = 0;
            }
code_r0x00018019ed42:
            if (*in_R8 != 0) {
                if (*in_R9 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ed58;
                    uVar6 = func_0x00018020ef80();
                    if ((uVar6 >> 0x15 & 1) == 0) {
                        return 0;
                    }
                }
                iVar4 = *(int32_t *)(iVar13 + 0x28);
                if (((iVar4 == 0x40) || (piVar14 == (int32_t *)0x0)) || (*piVar14 != 0)) {
                    if (((*(int32_t *)((int64_t)&arg_80h + iVar7) == 0) && ((*in_RDX & 0xffffff00) == 0x300)) &&
                       (0x300 < (int32_t)*in_RDX)) {
                        iVar5 = *(int32_t *)(iVar13 + 0x24);
                        if (iVar5 == 4) {
                            if (iVar4 != 1) {
                                return 1;
                            }
                            uVar9 = 0x393;
                        } else if (iVar5 == 0x40) {
                            if (iVar4 == 2) {
                                uVar9 = 0x394;
                            } else {
                                if (iVar4 != 0x10) {
                                    return 1;
                                }
                                uVar9 = 0x3b4;
                            }
                        } else {
                            if (iVar5 != 0x80) {
                                return 1;
                            }
                            if (iVar4 == 2) {
                                uVar9 = 0x396;
                            } else {
                                if (iVar4 != 0x10) {
                                    return 1;
                                }
                                uVar9 = 0x3b6;
                            }
                        }
                        uVar2 = *in_RCX;
                        uVar3 = in_RCX[0x8c];
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ee0b;
                        iVar13 = func_0x0001801973d0(uVar2, uVar9, uVar3);
                        if (iVar13 != 0) {
                            iVar11 = *in_R8;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ee1b;
                            func_0x0001801974e0(iVar11);
                            iVar11 = *in_R9;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18019ee23;
                            func_0x0001801975c0(iVar11);
                            *in_R8 = iVar13;
                            *in_R9 = 0;
                        }
                    }
                    return 1;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18019ee60
// Address: 0x18019ee60
// Size: 206 bytes
// ============================================================
undefined8 fcn.18019ee60(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t *in_R8;
    int32_t *piVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019ee6c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar1 = *(int32_t *)(in_RDX + 0x24);
    piVar4 = (int32_t *)0x1804ab6a0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    uVar3 = 0;
    while (*piVar4 != iVar1) {
        uVar3 = uVar3 + 1;
        piVar4 = piVar4 + 2;
        if (0x17 < uVar3) {
            *in_R8 = 0;
            return 1;
        }
    }
    iVar1 = (int32_t)uVar3;
    if (iVar1 != -1) {
        if (iVar1 == 5) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019eee4;
            iVar2 = fcn.1802119f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *in_R8 = iVar2;
            if (iVar2 != 0) {
                return 1;
            }
        } else {
            in_RCX = in_RCX + (int64_t)iVar1 * 8;
            if (*(int64_t *)(in_RCX + 0x4a0) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019ef10;
                iVar1 = fcn.180197510();
                if (iVar1 != 0) {
                    *in_R8 = *(int64_t *)(in_RCX + 0x4a0);
                    return 1;
                }
            }
        }
        return 0;
    }
    *in_R8 = 0;
    return 1;
}

// ============================================================
// Function: FUN_18019ef30
// Address: 0x18019ef30
// Size: 221 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_560h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel

undefined8 fcn.18019ef30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    int64_t *in_R8;
    undefined4 *in_R9;
    int32_t *piVar6;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019ef46;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    piVar6 = (int32_t *)0x1804ab760;
    do {
        if (*piVar6 == *(int32_t *)(in_RDX + 0x28)) {
            if ((int32_t)uVar4 != -1) {
                iVar5 = (int64_t)(int32_t)uVar4;
                iVar1 = *(int64_t *)(in_RCX + 0x560 + iVar5 * 8);
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019efbf;
                    iVar2 = func_0x0001801975f0(iVar1);
                    if (iVar2 != 0) {
                        *in_R8 = iVar1;
                        if (in_R9 != (undefined4 *)0x0) {
                            *in_R9 = *(undefined4 *)(in_RCX + 0x468 + iVar5 * 4);
                        }
                        if (*(undefined8 **)((int64_t)&arg_48h + iVar3) == (undefined8 *)0x0) {
                            return 1;
                        }
                        **(undefined8 **)((int64_t)&arg_48h + iVar3) = *(undefined8 *)(in_RCX + 0x5d0 + iVar5 * 8);
                        return 1;
                    }
                }
                return 0;
            }
            break;
        }
        uVar4 = uVar4 + 1;
        piVar6 = piVar6 + 2;
    } while (uVar4 < 0xe);
    *in_R8 = 0;
    if (in_R9 != (undefined4 *)0x0) {
        *in_R9 = 0;
    }
    if (*(undefined8 **)((int64_t)&arg_48h + iVar3) != (undefined8 *)0x0) {
        **(undefined8 **)((int64_t)&arg_48h + iVar3) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18019f010
// Address: 0x18019f010
// Size: 1259 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

undefined4
fcn.18019f010(uint8_t *placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
             int64_t arg_c0h)
{
    undefined8 uVar1;
    int32_t *piVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint8_t *puVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_48;
    
    uStack_48 = 0x18019f035;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar9 = 1;
    *(undefined4 *)((int64_t)&arg_38h + iVar7) = 1;
    uVar3 = *placeholder_0;
joined_r0x00018019f049:
    if (uVar3 == 0) {
        return uVar9;
    }
    do {
        if (uVar3 == 0x2d) {
            placeholder_0 = placeholder_0 + 1;
            *(undefined4 *)((int64_t)&var_20h + iVar7) = 3;
        } else if (uVar3 == 0x2b) {
            placeholder_0 = placeholder_0 + 1;
            *(undefined4 *)((int64_t)&var_20h + iVar7) = 4;
        } else if (uVar3 == 0x21) {
            placeholder_0 = placeholder_0 + 1;
            *(undefined4 *)((int64_t)&var_20h + iVar7) = 2;
        } else if (uVar3 == 0x40) {
            placeholder_0 = placeholder_0 + 1;
            *(undefined4 *)((int64_t)&var_20h + iVar7) = 5;
        } else {
            *(undefined4 *)((int64_t)&var_20h + iVar7) = 1;
            if ((uVar3 < 0x3c) && ((0xc00100100000000U >> ((int64_t)(char)uVar3 & 0x3fU) & 1) != 0)) break;
        }
        *(undefined4 *)((int64_t)&var_20h + iVar7 + 4) = 0;
        *(undefined4 *)(&stack0x00000028 + iVar7) = 0;
        *(undefined4 *)(&stack0x0000002c + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_30h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_30h + iVar7 + 4) = 0;
        *(undefined4 *)((int64_t)&arg_a0h + iVar7) = 0;
        puVar13 = placeholder_0;
code_r0x00018019f125:
        uVar11 = 0;
        uVar10 = uVar11;
        uVar12 = uVar11;
        placeholder_0 = puVar13;
        while( true ) {
            uVar3 = *placeholder_0;
            iVar6 = (int32_t)uVar10;
            if (((0x32 < (uint8_t)(uVar3 - 0x2d)) ||
                ((0x43ffffff11ffbU >> ((int64_t)(char)(uVar3 - 0x2d) & 0x3fU) & 1) == 0)) &&
               (0x19 < (uint8_t)(uVar3 + 0x9f))) break;
            placeholder_0 = placeholder_0 + 1;
            uVar10 = (uint64_t)(iVar6 + 1);
            uVar12 = uVar12 + 1;
        }
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f4ca;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)(&stack0xffffffffffffffe8 + iVar7)
                         );
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f4e2;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)(&stack0xffffffffffffffe8 + iVar7)
                          , *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f4f4;
            fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar7));
            return 0;
        }
        if (*(int32_t *)((int64_t)&var_20h + iVar7) == 5) {
            if (iVar6 == 8) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f3e9;
                iVar6 = func_0x000180498f90(puVar13, 0x1804ad4c8, 8);
                if (iVar6 != 0) goto code_r0x00018019f44f;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f402;
                iVar6 = func_0x00018019f500(*(undefined8 *)((int64_t)&arg_a8h + iVar7), 
                                            *(undefined8 *)((int64_t)&arg_b0h + iVar7));
                if (iVar6 == 0) goto code_r0x00018019f47e;
            } else {
                if (iVar6 == 10) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f422;
                    iVar6 = func_0x000180498f90(puVar13, 0x1804ad4d8, 9);
                    if (iVar6 != 0) goto code_r0x00018019f44f;
                    if ((int32_t)(char)puVar13[9] - 0x30U < 6) {
                        *(uint32_t *)(*(int64_t *)((int64_t)&arg_c0h + iVar7) + 0x98) =
                             (int32_t)(char)puVar13[9] - 0x30U;
                        goto code_r0x00018019f483;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f448;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar7));
                } else {
code_r0x00018019f44f:
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f454;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar7));
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f46c;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), 
                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar7), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f47e;
                fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar7));
code_r0x00018019f47e:
                *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0;
            }
code_r0x00018019f483:
            uVar3 = *placeholder_0;
            while ((uVar3 != 0 && ((0x3b < uVar3 || ((0xc00100100000000U >> ((uint64_t)uVar3 & 0x3f) & 1) == 0))))) {
                uVar3 = placeholder_0[1];
                placeholder_0 = placeholder_0 + 1;
            }
        } else {
            if (uVar3 == 0x2b) {
                placeholder_0 = placeholder_0 + 1;
            }
            iVar8 = *(int64_t *)arg4;
            if (iVar8 == 0) {
code_r0x00018019f1f0:
                uVar3 = *placeholder_0;
                while ((uVar3 != 0 && ((0x3b < uVar3 || ((0xc00100100000000U >> ((uint64_t)uVar3 & 0x3f) & 1) == 0)))))
                {
                    uVar3 = placeholder_0[1];
                    placeholder_0 = placeholder_0 + 1;
                }
                goto code_r0x00018019f4a9;
            }
            while( true ) {
                uVar1 = *(undefined8 *)(iVar8 + 8);
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f19f;
                iVar4 = func_0x000180498f90(puVar13, uVar1, (int64_t)iVar6);
                if ((iVar4 == 0) && (*(char *)(uVar12 + *(int64_t *)(*(int64_t *)arg4 + 8)) == '\0')) break;
                iVar8 = *(int64_t *)(*(int64_t *)arg4 + 0x10);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f1c7;
                    iVar4 = func_0x000180498f90(puVar13, iVar8, (int64_t)iVar6);
                    if ((iVar4 == 0) && (*(char *)(uVar12 + *(int64_t *)(*(int64_t *)arg4 + 0x10)) == '\0')) break;
                }
                uVar11 = uVar11 + 1;
                iVar8 = *(int64_t *)(*(int64_t *)((int64_t)&arg_b8h + iVar7) + uVar11 * 8);
                arg4 = *(int64_t *)((int64_t)&arg_b8h + iVar7) + uVar11 * 8;
                if (iVar8 == 0) goto code_r0x00018019f1f0;
            }
            uVar15 = *(uint32_t *)((int64_t)&var_20h + iVar7 + 4);
            piVar2 = *(int32_t **)(*(int64_t *)((int64_t)&arg_b8h + iVar7) + uVar11 * 8);
            uVar16 = piVar2[7];
            if (uVar16 != 0) {
                if (uVar15 == 0) {
                    *(uint32_t *)((int64_t)&var_20h + iVar7 + 4) = uVar16;
                } else {
                    uVar15 = uVar15 & uVar16;
                    *(uint32_t *)((int64_t)&var_20h + iVar7 + 4) = uVar15;
                    if (uVar15 == 0) goto code_r0x00018019f1f0;
                }
            }
            uVar15 = piVar2[8];
            if (uVar15 != 0) {
                if (*(uint32_t *)(&stack0x00000028 + iVar7) == 0) {
                    *(uint32_t *)(&stack0x00000028 + iVar7) = uVar15;
                } else {
                    uVar15 = *(uint32_t *)(&stack0x00000028 + iVar7) & uVar15;
                    *(uint32_t *)(&stack0x00000028 + iVar7) = uVar15;
                    if (uVar15 == 0) goto code_r0x00018019f1f0;
                }
            }
            uVar15 = piVar2[9];
            if (uVar15 != 0) {
                if (*(uint32_t *)(&stack0x0000002c + iVar7) == 0) {
                    *(uint32_t *)(&stack0x0000002c + iVar7) = uVar15;
                } else {
                    uVar15 = *(uint32_t *)(&stack0x0000002c + iVar7) & uVar15;
                    *(uint32_t *)(&stack0x0000002c + iVar7) = uVar15;
                    if (uVar15 == 0) goto code_r0x00018019f1f0;
                }
            }
            uVar15 = piVar2[10];
            uVar16 = *(uint32_t *)((int64_t)&arg_30h + iVar7);
            if (uVar15 != 0) {
                if (uVar16 == 0) {
                    *(uint32_t *)((int64_t)&arg_30h + iVar7) = uVar15;
                    uVar16 = uVar15;
                } else {
                    uVar16 = uVar16 & uVar15;
                    *(uint32_t *)((int64_t)&arg_30h + iVar7) = uVar16;
                    if (uVar16 == 0) goto code_r0x00018019f1f0;
                }
            }
            uVar15 = piVar2[0xf];
            uVar14 = *(uint32_t *)((int64_t)&arg_a0h + iVar7);
            uVar5 = uVar15 & 0x1f;
            if (uVar5 != 0) {
                if ((uVar14 & 0x1f) == 0) {
                    *(uint32_t *)((int64_t)&arg_a0h + iVar7) = uVar5;
                    uVar14 = uVar5;
                } else {
                    uVar14 = uVar14 & (uVar15 | 0xffffffe0);
                    *(uint32_t *)((int64_t)&arg_a0h + iVar7) = uVar14;
                    if ((uVar14 & 0x1f) == 0) goto code_r0x00018019f1f0;
                }
            }
            if ((uVar15 & 0x20) != 0) {
                if ((uVar14 & 0x20) == 0) {
                    uVar14 = uVar14 | uVar15 & 0x20;
                    *(uint32_t *)((int64_t)&arg_a0h + iVar7) = uVar14;
                } else {
                    uVar14 = uVar14 & (uVar15 | 0xffffffdf);
                    *(uint32_t *)((int64_t)&arg_a0h + iVar7) = uVar14;
                    if ((uVar14 & 0x20) == 0) goto code_r0x00018019f1f0;
                }
            }
            if ((*piVar2 == 0) && (iVar6 = piVar2[0xb], iVar6 != 0)) {
                iVar4 = *(int32_t *)((int64_t)&arg_30h + iVar7 + 4);
                if ((iVar4 != 0) && (iVar4 != iVar6)) goto code_r0x00018019f1f0;
                *(int32_t *)((int64_t)&arg_30h + iVar7 + 4) = iVar6;
            } else {
                iVar6 = *(int32_t *)((int64_t)&arg_30h + iVar7 + 4);
            }
            if (uVar3 == 0x2b) goto code_r0x00018019f110;
            *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)((int64_t)&arg_b0h + iVar7);
            *(undefined8 *)((int64_t)&var_8h + iVar7) = *(undefined8 *)((int64_t)&arg_a8h + iVar7);
            *(undefined4 *)(&stack0x00000000 + iVar7) = 0xffffffff;
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar7) = *(undefined4 *)((int64_t)&var_20h + iVar7);
            *(uint32_t *)(&stack0xfffffffffffffff0 + iVar7) = uVar14;
            *(int32_t *)(&stack0xffffffffffffffe8 + iVar7) = iVar6;
            *(uint32_t *)(&stack0xffffffffffffffe0 + iVar7) = uVar16;
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18019f3a8;
            fcn.18019e4e0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar7), *(int64_t *)(&stack0xfffffffffffffff0 + iVar7)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)(&stack0x00000040 + iVar7));
        }
code_r0x00018019f4a9:
        uVar3 = *placeholder_0;
        uVar9 = *(undefined4 *)((int64_t)&arg_38h + iVar7);
        if (uVar3 == 0) {
            return uVar9;
        }
        arg4 = *(int64_t *)((int64_t)&arg_b8h + iVar7);
    } while( true );
    uVar3 = placeholder_0[1];
    placeholder_0 = placeholder_0 + 1;
    *(undefined4 *)((int64_t)&arg_38h + iVar7) = uVar9;
    goto joined_r0x00018019f049;
code_r0x00018019f110:
    arg4 = *(int64_t *)((int64_t)&arg_b8h + iVar7);
    puVar13 = placeholder_0;
    goto code_r0x00018019f125;
}

// ============================================================
// Function: FUN_18019f500
// Address: 0x18019f500
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18019f500(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t **in_RCX;
    int64_t **in_RDX;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined8 unaff_RDI;
    int64_t *piVar10;
    bool bVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18019f51f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar8 = 0;
    for (piVar2 = *in_RCX; piVar2 != (int64_t *)0x0; piVar2 = (int64_t *)piVar2[2]) {
        if ((*(int32_t *)(piVar2 + 1) != 0) && (iVar8 < *(int32_t *)(*piVar2 + 0x44))) {
            iVar8 = *(int32_t *)(*piVar2 + 0x44);
        }
    }
    iVar9 = (int64_t)iVar8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18019f56d;
    iVar5 = func_0x000180224e40(iVar9 + 1, 4, 0x1804ad498, 0x3b7);
    if (iVar5 != 0) {
        for (piVar2 = *in_RCX; piVar2 != (int64_t *)0x0; piVar2 = (int64_t *)piVar2[2]) {
            if (*(int32_t *)(piVar2 + 1) != 0) {
                piVar1 = (int32_t *)(iVar5 + (int64_t)*(int32_t *)(*piVar2 + 0x44) * 4);
                *piVar1 = *piVar1 + 1;
            }
        }
        if (-1 < iVar8) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            do {
                if (0 < *(int32_t *)(iVar5 + iVar9 * 4)) {
                    piVar2 = *in_RDX;
                    piVar6 = *in_RCX;
                    piVar7 = piVar2;
                    piVar10 = piVar6;
                    if (piVar2 != (int64_t *)0x0) {
                        do {
                            if (piVar6 == (int64_t *)0x0) break;
                            piVar3 = (int64_t *)piVar6[2];
                            if (((iVar8 == *(int32_t *)(*piVar6 + 0x44)) && (*(int32_t *)(piVar6 + 1) != 0)) &&
                               (piVar6 != piVar7)) {
                                if (piVar6 == piVar10) {
                                    piVar10 = piVar3;
                                }
                                if (piVar6[3] != 0) {
                                    *(int64_t **)(piVar6[3] + 0x10) = piVar3;
                                }
                                if (piVar6[2] != 0) {
                                    *(int64_t *)(piVar6[2] + 0x18) = piVar6[3];
                                }
                                piVar7[2] = (int64_t)piVar6;
                                piVar6[3] = (int64_t)piVar7;
                                piVar6[2] = 0;
                                piVar7 = piVar6;
                            }
                            bVar11 = piVar6 != piVar2;
                            piVar6 = piVar3;
                        } while (bVar11);
                    }
                    *in_RCX = piVar10;
                    *in_RDX = piVar7;
                }
                iVar8 = iVar8 + -1;
                iVar9 = iVar9 + -1;
            } while (-1 < iVar9);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18019f647;
        fcn.180224990(iVar5, 0x1804ad498, 0x3cd);
        iVar5 = 1;
    }
    return iVar5;
}

