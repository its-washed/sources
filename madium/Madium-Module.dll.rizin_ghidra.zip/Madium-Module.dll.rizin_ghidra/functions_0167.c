// Chunk 167 - 50 functions

// ============================================================
// Function: FUN_180221da0
// Address: 0x180221da0
// Size: 213 bytes
// ============================================================
int32_t fcn.180221da0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180221db5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221dcb;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221de3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221df5;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    } else {
        if (*in_RCX == 0x7fffffff) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e14;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e2c;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e3e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e5d;
        iVar2 = fcn.1802225d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        if (iVar2 != 0) {
            iVar2 = *in_RCX;
            if ((in_R8D < iVar2) && (-1 < in_R8D)) {
                iVar1 = *(int64_t *)(in_RCX + 2);
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e99;
                fcn.180498030(iVar1 + (int64_t)(in_R8D + 1) * 8, (int64_t)in_R8D * 8 + iVar1, 
                              (int64_t)(iVar2 - in_R8D) << 3);
                *(undefined8 *)((int64_t)in_R8D * 8 + *(int64_t *)(in_RCX + 2)) = in_RDX;
            } else {
                *(undefined8 *)(*(int64_t *)(in_RCX + 2) + (int64_t)iVar2 * 8) = in_RDX;
            }
            *in_RCX = *in_RCX + 1;
            in_RCX[4] = 0;
            return *in_RCX;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180221e75
// Address: 0x180221e75
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.180221da0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180221db5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221dcb;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221de3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221df5;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    } else {
        if (*in_RCX == 0x7fffffff) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e14;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e2c;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e3e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e5d;
        iVar2 = fcn.1802225d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        if (iVar2 != 0) {
            iVar2 = *in_RCX;
            if ((in_R8D < iVar2) && (-1 < in_R8D)) {
                iVar1 = *(int64_t *)(in_RCX + 2);
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e99;
                fcn.180498030(iVar1 + (int64_t)(in_R8D + 1) * 8, (int64_t)in_R8D * 8 + iVar1, 
                              (int64_t)(iVar2 - in_R8D) << 3);
                *(undefined8 *)((int64_t)in_R8D * 8 + *(int64_t *)(in_RCX + 2)) = in_RDX;
            } else {
                *(undefined8 *)(*(int64_t *)(in_RCX + 2) + (int64_t)iVar2 * 8) = in_RDX;
            }
            *in_RCX = *in_RCX + 1;
            in_RCX[4] = 0;
            return *in_RCX;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180221ea8
// Address: 0x180221ea8
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.180221da0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180221db5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221dcb;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221de3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221df5;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    } else {
        if (*in_RCX == 0x7fffffff) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e14;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e2c;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e3e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e5d;
        iVar2 = fcn.1802225d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        if (iVar2 != 0) {
            iVar2 = *in_RCX;
            if ((in_R8D < iVar2) && (-1 < in_R8D)) {
                iVar1 = *(int64_t *)(in_RCX + 2);
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221e99;
                fcn.180498030(iVar1 + (int64_t)(in_R8D + 1) * 8, (int64_t)in_R8D * 8 + iVar1, 
                              (int64_t)(iVar2 - in_R8D) << 3);
                *(undefined8 *)((int64_t)in_R8D * 8 + *(int64_t *)(in_RCX + 2)) = in_RDX;
            } else {
                *(undefined8 *)(*(int64_t *)(in_RCX + 2) + (int64_t)iVar2 * 8) = in_RDX;
            }
            *in_RCX = *in_RCX + 1;
            in_RCX[4] = 0;
            return *in_RCX;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180221ee0
// Address: 0x180221ee0
// Size: 62 bytes
// ============================================================
void fcn.180221ee0(undefined8 param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180221eec;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180221f09;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)(iVar1 + 0x18) = param_1;
    return;
}

// ============================================================
// Function: FUN_180221f20
// Address: 0x180221f20
// Size: 56 bytes
// ============================================================
void fcn.180221f20(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180221f2a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180221f41;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)(iVar1 + 0x18) = 0;
    return;
}

// ============================================================
// Function: FUN_180221f60
// Address: 0x180221f60
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180221f60(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180221f75;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221f94;
    iVar4 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)(iVar4 + 0x18) = in_RCX;
    if (0 < in_EDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221fb4;
        iVar2 = fcn.1802225d0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        if (iVar2 == 0) {
            uVar1 = *(undefined8 *)(iVar4 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221fce;
            fcn.180224990(uVar1, 0x1804bf768, 0x1ce);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221fe3;
            fcn.180224990(iVar4, 0x1804bf768, 0x1cf);
            return 0;
        }
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180222020
// Address: 0x180222020
// Size: 42 bytes
// ============================================================
undefined8 fcn.180222020(int64_t arg_30h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    uint32_t uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX != (int32_t *)0x0) && (*in_RCX != 0)) {
        uVar6 = *in_RCX - 1;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180222580;
        iVar5 = fcn.18045a350();
        iVar2 = *(int64_t *)(in_RCX + 2);
        uVar3 = *(undefined8 *)(iVar2 + (int64_t)(int32_t)uVar6 * 8);
        iVar1 = *in_RCX;
        if (uVar6 != iVar1 - 1U) {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar4 - iVar5)) = 0x1802225be;
            fcn.180498030(iVar2 + (int64_t)(int32_t)uVar6 * 8, iVar2 + (int64_t)(int32_t)(uVar6 + 1) * 8, 
                          (int64_t)(int32_t)(~uVar6 + iVar1) << 3);
        }
        *in_RCX = *in_RCX + -1;
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180222050
// Address: 0x180222050
// Size: 28 bytes
// ============================================================
void fcn.180222050(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *in_RDX;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
        if (0 < *(int32_t *)arg1) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
            iVar6 = 0;
            do {
                iVar1 = *(int64_t *)(iVar6 + *(int64_t *)(arg1 + 8));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(arg1 + 0x20);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220b2;
                        (*in_RDX)();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ae;
                        (*pcVar2)(in_RDX, iVar1);
                    }
                }
                iVar5 = iVar5 + 1;
                iVar6 = iVar6 + 8;
            } while (iVar5 < *(int32_t *)arg1);
        }
        uVar3 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ec;
        fcn.180224990(arg1, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_18022206c
// Address: 0x18022206c
// Size: 22 bytes
// ============================================================
void fcn.180222050(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *in_RDX;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
        if (0 < *(int32_t *)arg1) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
            iVar6 = 0;
            do {
                iVar1 = *(int64_t *)(iVar6 + *(int64_t *)(arg1 + 8));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(arg1 + 0x20);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220b2;
                        (*in_RDX)();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ae;
                        (*pcVar2)(in_RDX, iVar1);
                    }
                }
                iVar5 = iVar5 + 1;
                iVar6 = iVar6 + 8;
            } while (iVar5 < *(int32_t *)arg1);
        }
        uVar3 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ec;
        fcn.180224990(arg1, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_180222082
// Address: 0x180222082
// Size: 63 bytes
// ============================================================
void fcn.180222050(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *in_RDX;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
        if (0 < *(int32_t *)arg1) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
            iVar6 = 0;
            do {
                iVar1 = *(int64_t *)(iVar6 + *(int64_t *)(arg1 + 8));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(arg1 + 0x20);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220b2;
                        (*in_RDX)();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ae;
                        (*pcVar2)(in_RDX, iVar1);
                    }
                }
                iVar5 = iVar5 + 1;
                iVar6 = iVar6 + 8;
            } while (iVar5 < *(int32_t *)arg1);
        }
        uVar3 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ec;
        fcn.180224990(arg1, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_1802220c1
// Address: 0x1802220c1
// Size: 63 bytes
// ============================================================
void fcn.180222050(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *in_RDX;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
        if (0 < *(int32_t *)arg1) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
            iVar6 = 0;
            do {
                iVar1 = *(int64_t *)(iVar6 + *(int64_t *)(arg1 + 8));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(arg1 + 0x20);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220b2;
                        (*in_RDX)();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ae;
                        (*pcVar2)(in_RDX, iVar1);
                    }
                }
                iVar5 = iVar5 + 1;
                iVar6 = iVar6 + 8;
            } while (iVar5 < *(int32_t *)arg1);
        }
        uVar3 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ec;
        fcn.180224990(arg1, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_180222100
// Address: 0x180222100
// Size: 1 bytes
// ============================================================
void fcn.180222050(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *in_RDX;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
        if (0 < *(int32_t *)arg1) {
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
            iVar6 = 0;
            do {
                iVar1 = *(int64_t *)(iVar6 + *(int64_t *)(arg1 + 8));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(arg1 + 0x20);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220b2;
                        (*in_RDX)();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ae;
                        (*pcVar2)(in_RDX, iVar1);
                    }
                }
                iVar5 = iVar5 + 1;
                iVar6 = iVar6 + 8;
            } while (iVar5 < *(int32_t *)arg1);
        }
        uVar3 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802220ec;
        fcn.180224990(arg1, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_180222110
// Address: 0x180222110
// Size: 37 bytes
// ============================================================
int32_t fcn.180222110(int32_t *param_1, undefined8 param_2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar5;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    iVar5 = *param_1;
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180221db5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221dcb;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000048 + iVar3 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221de3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000048 + iVar3 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar4), *(int64_t *)(&stack0x00000058 + iVar3 + iVar4), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221df5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar4));
    } else {
        if (*param_1 == 0x7fffffff) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e14;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000048 + iVar3 + iVar4)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e2c;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000048 + iVar3 + iVar4)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar4), *(int64_t *)(&stack0x00000070 + iVar3 + iVar4)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e3e;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar4));
            return 0;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e5d;
        iVar2 = fcn.1802225d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar4));
        if (iVar2 != 0) {
            iVar2 = *param_1;
            if ((iVar5 < iVar2) && (-1 < iVar5)) {
                iVar1 = *(int64_t *)(param_1 + 2);
                *(undefined8 *)(&stack0x00000050 + iVar3 + iVar4) = unaff_RBX;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e99;
                fcn.180498030(iVar1 + (int64_t)(iVar5 + 1) * 8, (int64_t)iVar5 * 8 + iVar1, 
                              (int64_t)(iVar2 - iVar5) << 3);
                *(undefined8 *)((int64_t)iVar5 * 8 + *(int64_t *)(param_1 + 2)) = param_2;
            } else {
                *(undefined8 *)(*(int64_t *)(param_1 + 2) + (int64_t)iVar2 * 8) = param_2;
            }
            *param_1 = *param_1 + 1;
            param_1[4] = 0;
            return *param_1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180222140
// Address: 0x180222140
// Size: 101 bytes
// ============================================================
undefined8 fcn.180222140(int32_t *param_1, int32_t param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int32_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18022214a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180222157;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022216f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180222181;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    if (param_2 < 0) {
        return 1;
    }
    iVar5 = 1;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2) = 0x1802225dc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *param_1;
    if (0x7fffffff - iVar4 < param_2) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802225f4;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x18022260c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x18022261e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        return 0;
    }
    *(undefined8 *)(&stack0x00000060 + iVar3 + iVar2) = unaff_RBX;
    iVar4 = iVar4 + param_2;
    if (iVar4 < 4) {
        iVar4 = 4;
    }
    if (*(int64_t *)(param_1 + 2) == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x180222658;
        iVar2 = fcn.180224e40(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2));
        *(int64_t *)(param_1 + 2) = iVar2;
        if (iVar2 != 0) {
            param_1[5] = iVar4;
            return 1;
        }
    } else {
        iVar1 = param_1[5];
        if (iVar5 == 0) {
            if (iVar4 <= iVar1) {
                return 1;
            }
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x180222689;
            iVar4 = fcn.180222360(iVar4, iVar1);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x180222694;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802226ac;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
                *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802226be;
                fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
                return 0;
            }
        } else if (iVar4 == iVar1) {
            return 1;
        }
        *(undefined4 *)(&stack0x00000040 + iVar3 + iVar2) = 0xda;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar2) = 0x1802226f0;
        iVar2 = fcn.180224f60(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000070 + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar2));
        if (iVar2 != 0) {
            *(int64_t *)(param_1 + 2) = iVar2;
            param_1[5] = iVar4;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802221b0
// Address: 0x1802221b0
// Size: 189 bytes
// ============================================================
undefined8 fcn.1802221b0(int32_t *param_1, int32_t param_2, undefined8 param_3)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802221bc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802221cf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802221e7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802221f9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    if ((-1 < param_2) && (param_2 < *param_1)) {
        *(undefined8 *)((int64_t)param_2 * 8 + *(int64_t *)(param_1 + 2)) = param_3;
        param_1[4] = 0;
        return *(undefined8 *)((int64_t)param_2 * 8 + *(int64_t *)(param_1 + 2));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180222234;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022224c;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180222265;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_1802222a0
// Address: 0x1802222a0
// Size: 41 bytes
// ============================================================
undefined8 fcn.1802222a0(int32_t *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((param_1 != (int32_t *)0x0) && (*param_1 != 0)) {
        uVar6 = 0;
        *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180222580;
        iVar5 = fcn.18045a350();
        iVar2 = *(int64_t *)(param_1 + 2);
        uVar3 = *(undefined8 *)(iVar2 + (int64_t)(int32_t)uVar6 * 8);
        iVar1 = *param_1;
        if (uVar6 != iVar1 - 1U) {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar4 - iVar5)) = 0x1802225be;
            fcn.180498030(iVar2 + (int64_t)(int32_t)uVar6 * 8, iVar2 + (int64_t)(int32_t)(uVar6 + 1) * 8, 
                          (int64_t)(int32_t)(~uVar6 + iVar1) << 3);
        }
        *param_1 = *param_1 + -1;
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802222d0
// Address: 0x1802222d0
// Size: 76 bytes
// ============================================================
void fcn.1802222d0(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802222e0;
        iVar1 = fcn.18045a350();
        if ((*(int32_t *)(arg1 + 0x10) == 0) && (*(int64_t *)(arg1 + 0x18) != 0)) {
            if (1 < *(int32_t *)arg1) {
                *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18022230f;
                fcn.18046f0d0(*(int64_t *)(&stack0x00000028 + -iVar1));
            }
            *(int32_t *)(arg1 + 0x10) = 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180222320
// Address: 0x180222320
// Size: 25 bytes
// ============================================================
int32_t fcn.180222320(int32_t *param_1, undefined8 param_2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar5;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = 0;
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180221db5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221dcb;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000048 + iVar3 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221de3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000048 + iVar3 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar4), *(int64_t *)(&stack0x00000058 + iVar3 + iVar4), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221df5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar4));
    } else {
        if (*param_1 == 0x7fffffff) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e14;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000048 + iVar3 + iVar4)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e2c;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4), *(int64_t *)(&stack0x00000048 + iVar3 + iVar4)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar4), *(int64_t *)(&stack0x00000070 + iVar3 + iVar4)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e3e;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar4));
            return 0;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e5d;
        iVar2 = fcn.1802225d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar4));
        if (iVar2 != 0) {
            iVar2 = *param_1;
            if ((iVar5 < iVar2) && (-1 < iVar5)) {
                iVar1 = *(int64_t *)(param_1 + 2);
                *(undefined8 *)(&stack0x00000050 + iVar3 + iVar4) = unaff_RBX;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x180221e99;
                fcn.180498030(iVar1 + (int64_t)(iVar5 + 1) * 8, (int64_t)iVar5 * 8 + iVar1, 
                              (int64_t)(iVar2 - iVar5) << 3);
                *(undefined8 *)((int64_t)iVar5 * 8 + *(int64_t *)(param_1 + 2)) = param_2;
            } else {
                *(undefined8 *)(*(int64_t *)(param_1 + 2) + (int64_t)iVar2 * 8) = param_2;
            }
            *param_1 = *param_1 + 1;
            param_1[4] = 0;
            return *param_1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180222360
// Address: 0x180222360
// Size: 513 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180222360(int64_t arg1, int64_t arg2)
{
    bool bVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    bVar1 = false;
    uVar6 = (uint32_t)arg2;
    uVar7 = arg2 & 0xffffffff;
    do {
        if ((int32_t)arg1 <= (int32_t)uVar6) {
            return uVar7;
        }
        uVar6 = (uint32_t)uVar7;
        if (0x7ffffffe < (int32_t)uVar6) {
            return 0;
        }
        if (uVar6 == 0) {
            iVar3 = 0;
code_r0x000180222527:
            uVar6 = iVar3 / 5;
        } else {
            if (uVar6 == 1) {
                iVar3 = 8;
                goto code_r0x000180222527;
            }
            if (uVar6 == 0x80000000) {
code_r0x000180222409:
                uVar2 = 1;
                uVar4 = 3;
code_r0x000180222415:
                uVar5 = uVar6;
                uVar8 = uVar5;
                if ((uVar4 != 1) && (uVar8 = uVar4, uVar5 != 1)) {
                    if ((uVar4 != 0x80000000) && (uVar5 != 0x80000000)) {
                        uVar6 = -uVar5;
                        if (0 < (int32_t)uVar5) {
                            uVar6 = uVar5;
                        }
                        uVar8 = -uVar4;
                        if (0 < (int32_t)uVar4) {
                            uVar8 = uVar4;
                        }
                        if ((int32_t)uVar8 <= (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar6)) {
                            uVar8 = uVar4 * uVar5;
                            goto code_r0x000180222466;
                        }
                    }
                    bVar1 = true;
                    uVar8 = 0x7fffffff;
                    if ((int32_t)(uVar4 ^ uVar5) < 0) {
                        uVar8 = 0x80000000;
                    }
                }
            } else {
                uVar2 = -uVar6;
                if (0 < (int32_t)uVar6) {
                    uVar2 = uVar6;
                }
                if ((int32_t)uVar2 < 0x10000000) {
                    iVar3 = uVar6 * 8;
                    goto code_r0x000180222527;
                }
                if ((int32_t)uVar6 < 8) goto code_r0x000180222409;
                uVar2 = (int32_t)uVar6 / 5;
                uVar4 = (int32_t)uVar6 % 5;
                uVar5 = 8;
                uVar6 = 8;
                if (uVar4 != 0) goto code_r0x000180222415;
                uVar8 = 0;
            }
code_r0x000180222466:
            if ((uVar2 == 0) || (uVar5 == 0)) {
                uVar6 = 0;
            } else {
                uVar6 = uVar5;
                if ((uVar2 != 1) && (uVar6 = uVar2, uVar5 != 1)) {
                    if ((uVar2 != 0x80000000) && (uVar5 != 0x80000000)) {
                        uVar6 = -uVar5;
                        if (0 < (int32_t)uVar5) {
                            uVar6 = uVar5;
                        }
                        uVar4 = -uVar2;
                        if (0 < (int32_t)uVar2) {
                            uVar4 = uVar2;
                        }
                        if ((int32_t)uVar4 <= (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar6)) {
                            uVar6 = uVar5 * uVar2;
                            goto code_r0x0001802224c4;
                        }
                    }
                    bVar1 = true;
                    uVar6 = 0x7fffffff;
                    if ((int32_t)(uVar2 ^ uVar5) < 0) {
                        uVar6 = 0x80000000;
                    }
                }
            }
code_r0x0001802224c4:
            uVar8 = (int32_t)uVar8 / 5;
            if ((int32_t)(uVar8 ^ uVar6) < 0) {
code_r0x0001802224ec:
                uVar6 = uVar6 + uVar8;
            } else {
                if ((int32_t)uVar6 < 1) {
                    if ((((int32_t)uVar6 < 0) && ((int32_t)(-uVar6 + -0x80000000) <= (int32_t)uVar8)) || (uVar6 == 0))
                    goto code_r0x0001802224ec;
                } else if ((int32_t)uVar8 <= (int32_t)(-uVar6 + 0x7fffffff)) goto code_r0x0001802224ec;
                bVar1 = true;
                uVar6 = ((int32_t)uVar6 >> 0x1f & 1U) + 0x7fffffff;
            }
            if (bVar1) {
                return 0;
            }
        }
        if (0x7ffffffe < (int32_t)uVar6) {
            uVar6 = 0x7fffffff;
        }
        uVar7 = (uint64_t)uVar6;
    } while( true );
}

// ============================================================
// Function: FUN_180222570
// Address: 0x180222570
// Size: 94 bytes
// ============================================================
undefined8 fcn.180222020(int64_t arg_30h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    uint32_t uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX != (int32_t *)0x0) && (*in_RCX != 0)) {
        uVar6 = *in_RCX - 1;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180222580;
        iVar5 = fcn.18045a350();
        iVar2 = *(int64_t *)(in_RCX + 2);
        uVar3 = *(undefined8 *)(iVar2 + (int64_t)(int32_t)uVar6 * 8);
        iVar1 = *in_RCX;
        if (uVar6 != iVar1 - 1U) {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar4 - iVar5)) = 0x1802225be;
            fcn.180498030(iVar2 + (int64_t)(int32_t)uVar6 * 8, iVar2 + (int64_t)(int32_t)(uVar6 + 1) * 8, 
                          (int64_t)(int32_t)(~uVar6 + iVar1) << 3);
        }
        *in_RCX = *in_RCX + -1;
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802225d0
// Address: 0x1802225d0
// Size: 86 bytes
// ============================================================
undefined8 fcn.1802225d0(int64_t arg_38h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    int32_t in_EDX;
    uint32_t uVar4;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802225dc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *in_RCX;
    if (0x7fffffff - iVar1 < in_EDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802225f4;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022260c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022261e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    uVar4 = iVar1 + in_EDX;
    if ((int32_t)uVar4 < 4) {
        uVar4 = 4;
    }
    if (*(int64_t *)(in_RCX + 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222658;
        iVar3 = fcn.180224e40(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        *(int64_t *)(in_RCX + 2) = iVar3;
        if (iVar3 != 0) {
            in_RCX[5] = uVar4;
            return 1;
        }
    } else {
        uVar2 = in_RCX[5];
        if (in_R8D == 0) {
            if ((int32_t)uVar4 <= (int32_t)uVar2) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222689;
            uVar4 = fcn.180222360((uint64_t)uVar4, (uint64_t)uVar2);
            if (uVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222694;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226ac;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226be;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                return 0;
            }
        } else if (uVar4 == uVar2) {
            return 1;
        }
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0xda;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226f0;
        iVar3 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar3 != 0) {
            *(int64_t *)(in_RCX + 2) = iVar3;
            in_RCX[5] = uVar4;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180222626
// Address: 0x180222626
// Size: 78 bytes
// ============================================================
undefined8 fcn.1802225d0(int64_t arg_38h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    int32_t in_EDX;
    uint32_t uVar4;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802225dc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *in_RCX;
    if (0x7fffffff - iVar1 < in_EDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802225f4;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022260c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022261e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    uVar4 = iVar1 + in_EDX;
    if ((int32_t)uVar4 < 4) {
        uVar4 = 4;
    }
    if (*(int64_t *)(in_RCX + 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222658;
        iVar3 = fcn.180224e40(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        *(int64_t *)(in_RCX + 2) = iVar3;
        if (iVar3 != 0) {
            in_RCX[5] = uVar4;
            return 1;
        }
    } else {
        uVar2 = in_RCX[5];
        if (in_R8D == 0) {
            if ((int32_t)uVar4 <= (int32_t)uVar2) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222689;
            uVar4 = fcn.180222360((uint64_t)uVar4, (uint64_t)uVar2);
            if (uVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222694;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226ac;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226be;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                return 0;
            }
        } else if (uVar4 == uVar2) {
            return 1;
        }
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0xda;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226f0;
        iVar3 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar3 != 0) {
            *(int64_t *)(in_RCX + 2) = iVar3;
            in_RCX[5] = uVar4;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180222674
// Address: 0x180222674
// Size: 87 bytes
// ============================================================
undefined8 fcn.1802225d0(int64_t arg_38h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    int32_t in_EDX;
    uint32_t uVar4;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802225dc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *in_RCX;
    if (0x7fffffff - iVar1 < in_EDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802225f4;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022260c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022261e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    uVar4 = iVar1 + in_EDX;
    if ((int32_t)uVar4 < 4) {
        uVar4 = 4;
    }
    if (*(int64_t *)(in_RCX + 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222658;
        iVar3 = fcn.180224e40(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        *(int64_t *)(in_RCX + 2) = iVar3;
        if (iVar3 != 0) {
            in_RCX[5] = uVar4;
            return 1;
        }
    } else {
        uVar2 = in_RCX[5];
        if (in_R8D == 0) {
            if ((int32_t)uVar4 <= (int32_t)uVar2) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222689;
            uVar4 = fcn.180222360((uint64_t)uVar4, (uint64_t)uVar2);
            if (uVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222694;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226ac;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226be;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                return 0;
            }
        } else if (uVar4 == uVar2) {
            return 1;
        }
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0xda;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226f0;
        iVar3 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar3 != 0) {
            *(int64_t *)(in_RCX + 2) = iVar3;
            in_RCX[5] = uVar4;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802226cb
// Address: 0x1802226cb
// Size: 65 bytes
// ============================================================
undefined8 fcn.1802225d0(int64_t arg_38h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    int32_t in_EDX;
    uint32_t uVar4;
    undefined8 unaff_RBX;
    int32_t in_R8D;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802225dc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *in_RCX;
    if (0x7fffffff - iVar1 < in_EDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802225f4;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022260c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022261e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBX;
    uVar4 = iVar1 + in_EDX;
    if ((int32_t)uVar4 < 4) {
        uVar4 = 4;
    }
    if (*(int64_t *)(in_RCX + 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222658;
        iVar3 = fcn.180224e40(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        *(int64_t *)(in_RCX + 2) = iVar3;
        if (iVar3 != 0) {
            in_RCX[5] = uVar4;
            return 1;
        }
    } else {
        uVar2 = in_RCX[5];
        if (in_R8D == 0) {
            if ((int32_t)uVar4 <= (int32_t)uVar2) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222689;
            uVar4 = fcn.180222360((uint64_t)uVar4, (uint64_t)uVar2);
            if (uVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222694;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226ac;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226be;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                return 0;
            }
        } else if (uVar4 == uVar2) {
            return 1;
        }
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0xda;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802226f0;
        iVar3 = fcn.180224f60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar3 != 0) {
            *(int64_t *)(in_RCX + 2) = iVar3;
            in_RCX[5] = uVar4;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180222710
// Address: 0x180222710
// Size: 35 bytes
// ============================================================
bool fcn.180222710(undefined4 *param_1)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022271a;
    iVar3 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_8 - iVar3) = 0x180222725;
    iVar2 = (*(code *)0x699fb2)(uVar1);
    return iVar2 != 0;
}

// ============================================================
// Function: FUN_180222740
// Address: 0x180222740
// Size: 24 bytes
// ============================================================
void fcn.180222740(void)
{
    fcn.18045a350();
    // WARNING: Treating indirect jump as call
    (*(code *)0x699ddc)();
    return;
}

// ============================================================
// Function: FUN_180222760
// Address: 0x180222760
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180222760(int64_t arg_28h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined4 *in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180222770;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022277c;
    uVar2 = (*(code *)0x699ff6)();
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222786;
    uVar4 = (*(code *)0x699f96)(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222791;
    (*(code *)0x69a006)(uVar2);
    return uVar4;
}

// ============================================================
// Function: FUN_1802227a0
// Address: 0x1802227a0
// Size: 42 bytes
// ============================================================
bool fcn.1802227a0(int32_t *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802227ac;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1802227b8;
    iVar1 = (*(code *)0x699f8a)();
    *param_1 = iVar1;
    return iVar1 != -1;
}

// ============================================================
// Function: FUN_1802227d0
// Address: 0x1802227d0
// Size: 41 bytes
// ============================================================
void fcn.1802227d0(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    if (arg1 != 0) {
        uStack_8 = 0x1802227df;
        iVar1 = fcn.18045a350();
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x1802227f4;
        fcn.180224990();
    }
    return;
}

// ============================================================
// Function: FUN_180222800
// Address: 0x180222800
// Size: 70 bytes
// ============================================================
int64_t fcn.180222800(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022280c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180222826;
    iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022283d;
    (*(code *)0x69a04e)(iVar2);
    return iVar2;
}

// ============================================================
// Function: FUN_180222850
// Address: 0x180222850
// Size: 29 bytes
// ============================================================
undefined8 fcn.180222850(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022285a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180222863;
    (*(code *)0x69a0ae)();
    return 1;
}

// ============================================================
// Function: FUN_180222870
// Address: 0x180222870
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180222870(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *in_RCX;
    code *in_RDX;
    bool bVar3;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180222880;
    iVar2 = fcn.18045a350();
    if (*in_RCX == 2) {
        return true;
    }
    while( true ) {
        LOCK();
        iVar1 = *in_RCX;
        bVar3 = iVar1 == 0;
        if (bVar3) {
            *in_RCX = 1;
            iVar1 = 0;
        }
        UNLOCK();
        if (bVar3) break;
        if (iVar1 != 1) {
            return *in_RCX == 2;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1802228c5;
    (*in_RDX)();
    *in_RCX = 2;
    return true;
}

// ============================================================
// Function: FUN_1802228e0
// Address: 0x1802228e0
// Size: 35 bytes
// ============================================================
bool fcn.1802228e0(undefined4 *param_1)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802228ea;
    iVar3 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_8 - iVar3) = 0x1802228f5;
    iVar2 = (*(code *)0x699fa4)(uVar1);
    return iVar2 != 0;
}

// ============================================================
// Function: FUN_180222910
// Address: 0x180222910
// Size: 58 bytes
// ============================================================
undefined8 fcn.180222910(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022291a;
    iVar1 = fcn.18045a350();
    if (*(int32_t *)(param_1 + 8) != 0) {
        *(undefined4 *)(param_1 + 8) = 0;
        *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180222930;
        (*(code *)0x69a062)();
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180222940;
    (*(code *)0x69a07c)();
    return 1;
}

// ============================================================
// Function: FUN_180222950
// Address: 0x180222950
// Size: 42 bytes
// ============================================================
undefined8 fcn.180222950(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022295c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180222968;
    (*(code *)0x69a094)();
    *(undefined4 *)(param_1 + 8) = 1;
    return 1;
}

// ============================================================
// Function: FUN_180222a10
// Address: 0x180222a10
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180222a10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180222a25;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180222a48;
    puVar2 = (undefined8 *)
             fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1));
    if (puVar2 == (undefined8 *)0x0) {
        return 0;
    }
    *puVar2 = in_RDX;
    puVar2[1] = in_R8;
    puVar2[2] = *in_RCX;
    *in_RCX = (int64_t)puVar2;
    return 1;
}

// ============================================================
// Function: FUN_180222a90
// Address: 0x180222a90
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180222a90(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined8 in_RCX;
    int64_t var_8h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180222aa0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180222ab0;
    iVar5 = func_0x00018028a240(0, in_RCX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180222ac0;
    func_0x00018028a2c0(0, in_RCX, 0);
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18022499a;
    iVar6 = fcn.18045a350(iVar5, 0x1804bf7d8, 0xe4);
    iVar6 = -iVar6;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (iVar5 != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4) = 0x18047ca3c;
            iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4) = 0x18047ca46;
                uVar3 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4) = 0x18047ca4d;
                uVar3 = fcn.18046b63c(uVar3);
                *(undefined8 *)((int64_t)auStackX_18 + iVar6 + iVar4) = 0x18047ca54;
                puVar7 = (undefined4 *)fcn.18046b77c();
                *puVar7 = uVar3;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180222ae0
// Address: 0x180222ae0
// Size: 138 bytes
// ============================================================
void fcn.180222ae0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180222aec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *(int64_t *)(param_1 + 0x58);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222b0d;
        fcn.180224990(iVar4, 0x1804bf7d8, 0x20c);
    }
    uVar6 = *(undefined8 *)(param_1 + 0x10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222b23;
    fcn.180224990(uVar6, 0x1804bf7d8, 0xbd);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222b2c;
    func_0x00018026d400(param_1 + 0x40);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222b35;
    func_0x00018026d400(param_1 + 0x50);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222b3e;
    func_0x00018026d840(param_1 + 0x38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222b47;
    func_0x00018026d840(param_1 + 0x48);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222b50;
    func_0x00018026d840(param_1 + 0x30);
    uVar6 = *(undefined8 *)((int64_t)auStackX_18 + iVar3);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350(param_1, 0x1804bf7d8, 0xc3);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = uVar6;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180222b70
// Address: 0x180222b70
// Size: 82 bytes
// ============================================================
int64_t fcn.180222b70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t in_ECX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar5;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x180222b7e;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar5 = 2;
    if (1 < in_ECX) {
        iVar5 = in_ECX;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222b93;
    iVar2 = func_0x000180245b10(in_RDX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222bb6;
        iVar3 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_8 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_R12;
            *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_R14;
            *(undefined8 *)((int64_t)&arg_40h + iVar1) = unaff_R15;
            *(int64_t *)(iVar3 + 8) = iVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222bf1;
            iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_8 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c02;
                (*(code *)0x69a04e)(iVar2);
            }
            *(int64_t *)(iVar3 + 0x58) = iVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c0b;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x30) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c14;
            uVar4 = func_0x00018026d4a0();
            *(undefined8 *)(iVar3 + 0x40) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c1d;
            uVar4 = func_0x00018026d4a0();
            *(undefined8 *)(iVar3 + 0x50) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c26;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x38) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c2f;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x48) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c4c;
            iVar2 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
            *(int32_t *)(iVar3 + 0x1c) = iVar5;
            *(int64_t *)(iVar3 + 0x10) = iVar2;
            if ((((iVar2 == 0) || (*(int64_t *)(iVar3 + 0x40) == 0)) || (*(int64_t *)(iVar3 + 0x50) == 0)) ||
               (((*(int64_t *)(iVar3 + 0x30) == 0 || (*(int64_t *)(iVar3 + 0x38) == 0)) ||
                ((*(int64_t *)(iVar3 + 0x48) == 0 || (*(int64_t *)(iVar3 + 0x58) == 0)))))) {
                iVar2 = *(int64_t *)(iVar3 + 0x58);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c9d;
                    fcn.180224990(iVar2, 0x1804bf7d8, 0x20c);
                }
                uVar4 = *(undefined8 *)(iVar3 + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cb3;
                fcn.180224990(uVar4, 0x1804bf7d8, 0xac);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cbc;
                func_0x00018026d400(iVar3 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cc5;
                func_0x00018026d400(iVar3 + 0x50);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cce;
                func_0x00018026d840(iVar3 + 0x38);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cd7;
                func_0x00018026d840(iVar3 + 0x48);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222ce0;
                func_0x00018026d840(iVar3 + 0x30);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cf5;
                fcn.180224990(iVar3, 0x1804bf7d8, 0xb2);
                iVar3 = 0;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180222bc2
// Address: 0x180222bc2
// Size: 340 bytes
// ============================================================
int64_t fcn.180222b70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t in_ECX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar5;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x180222b7e;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar5 = 2;
    if (1 < in_ECX) {
        iVar5 = in_ECX;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222b93;
    iVar2 = func_0x000180245b10(in_RDX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222bb6;
        iVar3 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_8 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_R12;
            *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_R14;
            *(undefined8 *)((int64_t)&arg_40h + iVar1) = unaff_R15;
            *(int64_t *)(iVar3 + 8) = iVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222bf1;
            iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_8 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c02;
                (*(code *)0x69a04e)(iVar2);
            }
            *(int64_t *)(iVar3 + 0x58) = iVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c0b;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x30) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c14;
            uVar4 = func_0x00018026d4a0();
            *(undefined8 *)(iVar3 + 0x40) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c1d;
            uVar4 = func_0x00018026d4a0();
            *(undefined8 *)(iVar3 + 0x50) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c26;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x38) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c2f;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x48) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c4c;
            iVar2 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
            *(int32_t *)(iVar3 + 0x1c) = iVar5;
            *(int64_t *)(iVar3 + 0x10) = iVar2;
            if ((((iVar2 == 0) || (*(int64_t *)(iVar3 + 0x40) == 0)) || (*(int64_t *)(iVar3 + 0x50) == 0)) ||
               (((*(int64_t *)(iVar3 + 0x30) == 0 || (*(int64_t *)(iVar3 + 0x38) == 0)) ||
                ((*(int64_t *)(iVar3 + 0x48) == 0 || (*(int64_t *)(iVar3 + 0x58) == 0)))))) {
                iVar2 = *(int64_t *)(iVar3 + 0x58);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c9d;
                    fcn.180224990(iVar2, 0x1804bf7d8, 0x20c);
                }
                uVar4 = *(undefined8 *)(iVar3 + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cb3;
                fcn.180224990(uVar4, 0x1804bf7d8, 0xac);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cbc;
                func_0x00018026d400(iVar3 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cc5;
                func_0x00018026d400(iVar3 + 0x50);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cce;
                func_0x00018026d840(iVar3 + 0x38);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cd7;
                func_0x00018026d840(iVar3 + 0x48);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222ce0;
                func_0x00018026d840(iVar3 + 0x30);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cf5;
                fcn.180224990(iVar3, 0x1804bf7d8, 0xb2);
                iVar3 = 0;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180222d16
// Address: 0x180222d16
// Size: 10 bytes
// ============================================================
int64_t fcn.180222b70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t in_ECX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar5;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x180222b7e;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar5 = 2;
    if (1 < in_ECX) {
        iVar5 = in_ECX;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222b93;
    iVar2 = func_0x000180245b10(in_RDX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222bb6;
        iVar3 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_8 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_R12;
            *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_R14;
            *(undefined8 *)((int64_t)&arg_40h + iVar1) = unaff_R15;
            *(int64_t *)(iVar3 + 8) = iVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222bf1;
            iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_8 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c02;
                (*(code *)0x69a04e)(iVar2);
            }
            *(int64_t *)(iVar3 + 0x58) = iVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c0b;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x30) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c14;
            uVar4 = func_0x00018026d4a0();
            *(undefined8 *)(iVar3 + 0x40) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c1d;
            uVar4 = func_0x00018026d4a0();
            *(undefined8 *)(iVar3 + 0x50) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c26;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x38) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c2f;
            uVar4 = func_0x00018026d8b0();
            *(undefined8 *)(iVar3 + 0x48) = uVar4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c4c;
            iVar2 = fcn.180224e40(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
            *(int32_t *)(iVar3 + 0x1c) = iVar5;
            *(int64_t *)(iVar3 + 0x10) = iVar2;
            if ((((iVar2 == 0) || (*(int64_t *)(iVar3 + 0x40) == 0)) || (*(int64_t *)(iVar3 + 0x50) == 0)) ||
               (((*(int64_t *)(iVar3 + 0x30) == 0 || (*(int64_t *)(iVar3 + 0x38) == 0)) ||
                ((*(int64_t *)(iVar3 + 0x48) == 0 || (*(int64_t *)(iVar3 + 0x58) == 0)))))) {
                iVar2 = *(int64_t *)(iVar3 + 0x58);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222c9d;
                    fcn.180224990(iVar2, 0x1804bf7d8, 0x20c);
                }
                uVar4 = *(undefined8 *)(iVar3 + 0x10);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cb3;
                fcn.180224990(uVar4, 0x1804bf7d8, 0xac);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cbc;
                func_0x00018026d400(iVar3 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cc5;
                func_0x00018026d400(iVar3 + 0x50);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cce;
                func_0x00018026d840(iVar3 + 0x38);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cd7;
                func_0x00018026d840(iVar3 + 0x48);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222ce0;
                func_0x00018026d840(iVar3 + 0x30);
                *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180222cf5;
                fcn.180224990(iVar3, 0x1804bf7d8, 0xb2);
                iVar3 = 0;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180222d20
// Address: 0x180222d20
// Size: 456 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180222d20(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    int64_t in_RCX;
    int32_t iVar8;
    uint64_t uVar9;
    bool bVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180222d35;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar8 = -1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180222d4b;
    piVar6 = (int64_t *)fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    if (piVar6 != (int64_t *)0x0) {
code_r0x000180222dfa:
        iVar2 = 0;
        piVar7 = piVar6;
        while( true ) {
            if ((*piVar7 == 0) && (iVar8 == -1)) {
                iVar8 = iVar2;
            }
            if (piVar7[2] == in_RCX) break;
            iVar2 = iVar2 + 1;
            piVar7 = piVar7 + 3;
            if (9 < iVar2) {
                uVar3 = *(uint32_t *)(in_RCX + 0x20);
                do {
                    LOCK();
                    uVar4 = *(uint32_t *)(in_RCX + 0x20);
                    bVar10 = uVar3 == uVar4;
                    if (bVar10) {
                        *(uint32_t *)(in_RCX + 0x20) = uVar3;
                        uVar4 = uVar3;
                    }
                    uVar3 = uVar4;
                    UNLOCK();
                } while (!bVar10);
                uVar9 = (uint64_t)uVar3;
                iVar5 = uVar9 * 8;
                LOCK();
                piVar7 = (int64_t *)(iVar5 + *(int64_t *)(in_RCX + 0x10));
                *piVar7 = *piVar7 + 1;
                UNLOCK();
                uVar4 = *(uint32_t *)(in_RCX + 0x20);
                do {
                    LOCK();
                    uVar1 = *(uint32_t *)(in_RCX + 0x20);
                    bVar10 = uVar4 == uVar1;
                    if (bVar10) {
                        *(uint32_t *)(in_RCX + 0x20) = uVar4;
                        uVar1 = uVar4;
                    }
                    uVar4 = uVar1;
                    UNLOCK();
                } while (!bVar10);
                if (uVar3 != uVar4) {
                    do {
                        LOCK();
                        piVar7 = (int64_t *)(iVar5 + *(int64_t *)(in_RCX + 0x10));
                        *piVar7 = *piVar7 + -1;
                        UNLOCK();
                        uVar3 = *(uint32_t *)(in_RCX + 0x20);
                        do {
                            LOCK();
                            uVar4 = *(uint32_t *)(in_RCX + 0x20);
                            bVar10 = uVar3 == uVar4;
                            if (bVar10) {
                                *(uint32_t *)(in_RCX + 0x20) = uVar3;
                                uVar4 = uVar3;
                            }
                            uVar3 = uVar4;
                            UNLOCK();
                        } while (!bVar10);
                        uVar9 = (uint64_t)uVar3;
                        iVar5 = uVar9 * 8;
                        LOCK();
                        piVar7 = (int64_t *)(iVar5 + *(int64_t *)(in_RCX + 0x10));
                        *piVar7 = *piVar7 + 1;
                        UNLOCK();
                        uVar4 = *(uint32_t *)(in_RCX + 0x20);
                        do {
                            LOCK();
                            uVar1 = *(uint32_t *)(in_RCX + 0x20);
                            bVar10 = uVar4 == uVar1;
                            if (bVar10) {
                                *(uint32_t *)(in_RCX + 0x20) = uVar4;
                                uVar1 = uVar4;
                            }
                            uVar4 = uVar1;
                            UNLOCK();
                        } while (!bVar10);
                    } while (uVar3 != uVar4);
                }
                iVar5 = *(int64_t *)(in_RCX + 0x10);
                piVar6 = piVar6 + (int64_t)iVar8 * 3;
                *(undefined4 *)(piVar6 + 1) = 1;
                piVar6[2] = in_RCX;
                *piVar6 = iVar5 + uVar9 * 8;
                return 1;
            }
        }
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180222d6e;
    piVar6 = (int64_t *)
             fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5));
    if (piVar6 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180222d84;
        iVar2 = fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180222dc1;
            iVar2 = fcn.18028c680(*(int64_t *)((int64_t)aiStackX_18 + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar5));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180222dda;
                fcn.180224990(piVar6, 0x1804bf7d8, 0xfc);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180222de8;
                fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5));
                return 0;
            }
            goto code_r0x000180222dfa;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180222d9d;
        fcn.180224990(piVar6, 0x1804bf7d8, 0xf8);
    }
    return 0;
}

// ============================================================
// Function: FUN_180222ef0
// Address: 0x180222ef0
// Size: 161 bytes
// ============================================================
void fcn.180222ef0(int64_t param_1)
{
    int64_t **ppiVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180222efc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222f0d;
    iVar4 = fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    iVar7 = 0;
    iVar6 = 0;
    piVar5 = (int64_t *)(iVar4 + 0x10);
    do {
        if (*piVar5 == param_1) {
            piVar2 = (int32_t *)(iVar4 + 8 + (int64_t)iVar7 * 0x18);
            *piVar2 = *piVar2 + -1;
            ppiVar1 = (int64_t **)(iVar4 + (int64_t)iVar7 * 0x18);
            if (*piVar2 == 0) {
                piVar5 = *ppiVar1;
                LOCK();
                iVar4 = *piVar5;
                *piVar5 = *piVar5 + -1;
                UNLOCK();
                if (iVar4 + -1 < 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180222f7c;
                    fcn.18027bb50(0x1804bf7f0, 0x1804bf7d8, 0x12e);
                }
                *ppiVar1 = (int64_t *)0x0;
                ppiVar1[2] = (int64_t *)0x0;
            }
            return;
        }
        iVar7 = iVar7 + 1;
        iVar6 = iVar6 + 1;
        piVar5 = piVar5 + 3;
    } while (iVar6 < 10);
    return;
}

// ============================================================
// Function: FUN_180222fa0
// Address: 0x180222fa0
// Size: 26 bytes
// ============================================================
void fcn.180222fa0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 0x30);
    *(undefined8 *)((int64_t)&uStackX_20 - iVar2) = 0x18026d89a;
    fcn.18045a350(uVar1);
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f1c)();
    return;
}

// ============================================================
// Function: FUN_180222fc0
// Address: 0x180222fc0
// Size: 26 bytes
// ============================================================
void fcn.180222fc0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 0x30);
    *(undefined8 *)((int64_t)&uStackX_20 - iVar2) = 0x18026d90a;
    fcn.18045a350(uVar1);
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f34)();
    return;
}

// ============================================================
// Function: FUN_180222fe0
// Address: 0x180222fe0
// Size: 390 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180222fe0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    code **ppcVar7;
    int64_t iVar8;
    undefined8 uVar9;
    code *pcVar10;
    code **ppcVar11;
    code *pcVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined8 *in_RCX;
    undefined4 uVar17;
    bool bVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180223000;
    iVar14 = fcn.18045a350();
    iVar14 = -iVar14;
    uVar6 = in_RCX[6];
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x18022300f;
    func_0x00018026d890(uVar6);
    ppcVar7 = (code **)*in_RCX;
    uVar6 = in_RCX[6];
    *in_RCX = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x180223022;
    func_0x00018026d900(uVar6);
    uVar6 = in_RCX[7];
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x18022302b;
    func_0x00018026d890(uVar6);
    uVar3 = *(uint32_t *)((int64_t)in_RCX + 0x1c);
    iVar4 = *(int32_t *)((int64_t)in_RCX + 0x2c);
    uVar13 = uVar3 - iVar4;
    while (uVar13 < 2) {
        uVar6 = in_RCX[8];
        *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x18022304d;
        func_0x00018026d610(uVar6);
        uVar3 = *(uint32_t *)((int64_t)in_RCX + 0x1c);
        iVar4 = *(int32_t *)((int64_t)in_RCX + 0x2c);
        uVar13 = uVar3 - iVar4;
    }
    uVar13 = *(uint32_t *)(in_RCX + 5);
    iVar5 = *(int32_t *)(in_RCX + 3);
    *(int32_t *)((int64_t)in_RCX + 0x2c) = iVar4 + 1;
    uVar17 = (undefined4)((uint64_t)(uVar13 + 1) % (uint64_t)uVar3);
    *(undefined4 *)(in_RCX + 5) = uVar17;
    *(int32_t *)(in_RCX + 3) = iVar5 + 1;
    LOCK();
    uVar2 = *(undefined4 *)(in_RCX + 4);
    *(undefined4 *)(in_RCX + 4) = uVar17;
    UNLOCK();
    uVar6 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x180223089;
    func_0x00018026d390(uVar6, uVar2);
    uVar6 = in_RCX[7];
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x180223092;
    func_0x00018026d900(uVar6);
    uVar6 = in_RCX[9];
    iVar8 = in_RCX[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x1802230a1;
    func_0x00018026d890(uVar6);
    iVar4 = *(int32_t *)((int64_t)in_RCX + 0x24);
    while (iVar4 != iVar5) {
        uVar6 = in_RCX[9];
        uVar9 = in_RCX[10];
        *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x1802230bd;
        func_0x00018026d610(uVar9, uVar6);
        iVar4 = *(int32_t *)((int64_t)in_RCX + 0x24);
    }
    do {
        iVar15 = *(int64_t *)(iVar8 + (uint64_t)uVar13 * 8);
        do {
            piVar1 = (int64_t *)(iVar8 + (uint64_t)uVar13 * 8);
            LOCK();
            iVar16 = *piVar1;
            bVar18 = iVar15 == iVar16;
            if (bVar18) {
                *piVar1 = iVar15;
                iVar16 = iVar15;
            }
            UNLOCK();
            iVar15 = iVar16;
        } while (!bVar18);
    } while (iVar16 != 0);
    uVar6 = in_RCX[10];
    *(int32_t *)((int64_t)in_RCX + 0x24) = *(int32_t *)((int64_t)in_RCX + 0x24) + 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x1802230ec;
    func_0x00018026d390(uVar6);
    uVar6 = in_RCX[9];
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x1802230f5;
    func_0x00018026d900(uVar6);
    uVar6 = in_RCX[7];
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x1802230fe;
    func_0x00018026d890(uVar6);
    uVar6 = in_RCX[8];
    *(int32_t *)((int64_t)in_RCX + 0x2c) = *(int32_t *)((int64_t)in_RCX + 0x2c) + -1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x18022310a;
    func_0x00018026d390(uVar6);
    uVar6 = in_RCX[7];
    *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x180223113;
    func_0x00018026d900(uVar6);
    while (ppcVar7 != (code **)0x0) {
        pcVar10 = *ppcVar7;
        ppcVar11 = (code **)ppcVar7[2];
        pcVar12 = ppcVar7[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x180223131;
        (*pcVar10)(pcVar12);
        *(undefined8 *)((int64_t)&uStack_10 + iVar14) = 0x180223146;
        fcn.180224990(ppcVar7, 0x1804bf7d8, 0x195);
        ppcVar7 = ppcVar11;
    }
    return;
}

// ============================================================
// Function: FUN_180223170
// Address: 0x180223170
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined (*) [32] fcn.180223170(int64_t arg_28h)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    undefined uVar3;
    undefined2 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    int64_t iVar20;
    undefined (*pauVar21) [32];
    undefined (*in_RCX) [32];
    undefined (*pauVar22) [32];
    undefined (*pauVar23) [32];
    undefined4 *puVar24;
    undefined (*pauVar25) [16];
    undefined (*pauVar26) [16];
    uint64_t in_RDX;
    undefined (*pauVar27) [32];
    undefined4 *puVar28;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    uint64_t in_R9;
    uint64_t uVar29;
    uint64_t uVar30;
    undefined auVar31 [16];
    undefined auVar32 [32];
    undefined auVar33 [32];
    undefined auVar34 [32];
    undefined auVar35 [32];
    undefined auVar36 [32];
    undefined auVar37 [32];
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180223180;
    iVar20 = fcn.18045a350();
    iVar20 = -iVar20;
    if ((in_RCX != (undefined (*) [32])0x0) && (in_RDX < 0x7fffffff)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar20) = 0x1802231a8;
        pauVar21 = (undefined (*) [32])func_0x0001802248d0(in_RDX, in_R8, in_R9 & 0xffffffff);
        if (pauVar21 != (undefined (*) [32])0x0) {
            switch(in_RDX) {
            case 0:
                return pauVar21;
            case 1:
                (*pauVar21)[0] = (*in_RCX)[0];
                return pauVar21;
            case 2:
                *(undefined2 *)*pauVar21 = *(undefined2 *)*in_RCX;
                return pauVar21;
            case 3:
                uVar3 = (*in_RCX)[2];
                *(undefined2 *)*pauVar21 = *(undefined2 *)*in_RCX;
                (*pauVar21)[2] = uVar3;
                return pauVar21;
            case 4:
                *(undefined4 *)*pauVar21 = *(undefined4 *)*in_RCX;
                return pauVar21;
            case 5:
                uVar3 = (*in_RCX)[4];
                *(undefined4 *)*pauVar21 = *(undefined4 *)*in_RCX;
                (*pauVar21)[4] = uVar3;
                return pauVar21;
            case 6:
                uVar4 = *(undefined2 *)(*in_RCX + 4);
                *(undefined4 *)*pauVar21 = *(undefined4 *)*in_RCX;
                *(undefined2 *)(*pauVar21 + 4) = uVar4;
                return pauVar21;
            case 7:
                uVar4 = *(undefined2 *)(*in_RCX + 4);
                uVar3 = (*in_RCX)[6];
                *(undefined4 *)*pauVar21 = *(undefined4 *)*in_RCX;
                *(undefined2 *)(*pauVar21 + 4) = uVar4;
                (*pauVar21)[6] = uVar3;
                return pauVar21;
            case 8:
                *(undefined8 *)*pauVar21 = *(undefined8 *)*in_RCX;
                return pauVar21;
            case 9:
                uVar3 = (*in_RCX)[8];
                *(undefined8 *)*pauVar21 = *(undefined8 *)*in_RCX;
                (*pauVar21)[8] = uVar3;
                return pauVar21;
            case 10:
                uVar4 = *(undefined2 *)(*in_RCX + 8);
                *(undefined8 *)*pauVar21 = *(undefined8 *)*in_RCX;
                *(undefined2 *)(*pauVar21 + 8) = uVar4;
                return pauVar21;
            case 0xb:
                uVar4 = *(undefined2 *)(*in_RCX + 8);
                uVar3 = (*in_RCX)[10];
                *(undefined8 *)*pauVar21 = *(undefined8 *)*in_RCX;
                *(undefined2 *)(*pauVar21 + 8) = uVar4;
                (*pauVar21)[10] = uVar3;
                return pauVar21;
            case 0xc:
                uVar5 = *(undefined4 *)(*in_RCX + 8);
                *(undefined8 *)*pauVar21 = *(undefined8 *)*in_RCX;
                *(undefined4 *)(*pauVar21 + 8) = uVar5;
                return pauVar21;
            case 0xd:
                uVar5 = *(undefined4 *)(*in_RCX + 8);
                uVar3 = (*in_RCX)[0xc];
                *(undefined8 *)*pauVar21 = *(undefined8 *)*in_RCX;
                *(undefined4 *)(*pauVar21 + 8) = uVar5;
                (*pauVar21)[0xc] = uVar3;
                return pauVar21;
            case 0xe:
                uVar5 = *(undefined4 *)(*in_RCX + 8);
                uVar4 = *(undefined2 *)(*in_RCX + 0xc);
                *(undefined8 *)*pauVar21 = *(undefined8 *)*in_RCX;
                *(undefined4 *)(*pauVar21 + 8) = uVar5;
                *(undefined2 *)(*pauVar21 + 0xc) = uVar4;
                return pauVar21;
            case 0xf:
                uVar5 = *(undefined4 *)(*in_RCX + 8);
                uVar4 = *(undefined2 *)(*in_RCX + 0xc);
                uVar3 = (*in_RCX)[0xe];
                *(undefined8 *)*pauVar21 = *(undefined8 *)*in_RCX;
                *(undefined4 *)(*pauVar21 + 8) = uVar5;
                *(undefined2 *)(*pauVar21 + 0xc) = uVar4;
                (*pauVar21)[0xe] = uVar3;
                return pauVar21;
            }
            if (in_RDX < 0x21) {
                uVar5 = *(undefined4 *)(*in_RCX + 4);
                uVar6 = *(undefined4 *)(*in_RCX + 8);
                uVar7 = *(undefined4 *)(*in_RCX + 0xc);
                puVar24 = (undefined4 *)(in_RCX[-1] + in_RDX + 0x10);
                uVar8 = *puVar24;
                uVar9 = puVar24[1];
                uVar10 = puVar24[2];
                uVar11 = puVar24[3];
                *(undefined4 *)*pauVar21 = *(undefined4 *)*in_RCX;
                *(undefined4 *)(*pauVar21 + 4) = uVar5;
                *(undefined4 *)(*pauVar21 + 8) = uVar6;
                *(undefined4 *)(*pauVar21 + 0xc) = uVar7;
                puVar24 = (undefined4 *)(pauVar21[-1] + in_RDX + 0x10);
                *puVar24 = uVar8;
                puVar24[1] = uVar9;
                puVar24[2] = uVar10;
                puVar24[3] = uVar11;
                return pauVar21;
            }
            pauVar22 = (undefined (*) [32])(*in_RCX + in_RDX);
            if (pauVar21 <= in_RCX) {
                pauVar22 = pauVar21;
            }
            if (pauVar21 < pauVar22) {
                uVar5 = *(undefined4 *)*in_RCX;
                uVar6 = *(undefined4 *)(*in_RCX + 4);
                uVar7 = *(undefined4 *)(*in_RCX + 8);
                uVar8 = *(undefined4 *)(*in_RCX + 0xc);
                iVar20 = (int64_t)in_RCX - (int64_t)pauVar21;
                auVar1 = *(undefined (*) [16])((int64_t)pauVar21 + iVar20 + (in_RDX - 0x10));
                pauVar26 = (undefined (*) [16])(pauVar21[-1] + in_RDX + 0x10);
                in_RDX = in_RDX - 0x10;
                pauVar25 = pauVar26;
                auVar31 = auVar1;
                if (((uint64_t)pauVar26 & 0xf) != 0) {
                    pauVar25 = (undefined (*) [16])((uint64_t)pauVar26 & 0xfffffffffffffff0);
                    auVar31 = *(undefined (*) [16])((int64_t)pauVar25 + iVar20);
                    *pauVar26 = auVar1;
                    in_RDX = (int64_t)pauVar25 - (int64_t)pauVar21;
                }
                uVar30 = in_RDX >> 7;
                if (uVar30 != 0) {
                    *pauVar25 = auVar31;
                    pauVar26 = pauVar25;
                    while( true ) {
                        puVar24 = (undefined4 *)((int64_t)pauVar26 + iVar20 + -0x10);
                        uVar9 = puVar24[1];
                        uVar10 = puVar24[2];
                        uVar11 = puVar24[3];
                        puVar28 = (undefined4 *)((int64_t)pauVar26 + iVar20 + -0x20);
                        uVar12 = *puVar28;
                        uVar13 = puVar28[1];
                        uVar14 = puVar28[2];
                        uVar15 = puVar28[3];
                        pauVar25 = pauVar26 + -8;
                        *(undefined4 *)pauVar26[-1] = *puVar24;
                        *(undefined4 *)(pauVar26[-1] + 4) = uVar9;
                        *(undefined4 *)(pauVar26[-1] + 8) = uVar10;
                        *(undefined4 *)(pauVar26[-1] + 0xc) = uVar11;
                        *(undefined4 *)pauVar26[-2] = uVar12;
                        *(undefined4 *)(pauVar26[-2] + 4) = uVar13;
                        *(undefined4 *)(pauVar26[-2] + 8) = uVar14;
                        *(undefined4 *)(pauVar26[-2] + 0xc) = uVar15;
                        puVar24 = (undefined4 *)((int64_t)pauVar26 + iVar20 + -0x30);
                        uVar9 = puVar24[1];
                        uVar10 = puVar24[2];
                        uVar11 = puVar24[3];
                        puVar28 = (undefined4 *)((int64_t)pauVar26 + iVar20 + -0x40);
                        uVar12 = *puVar28;
                        uVar13 = puVar28[1];
                        uVar14 = puVar28[2];
                        uVar15 = puVar28[3];
                        uVar30 = uVar30 - 1;
                        *(undefined4 *)pauVar26[-3] = *puVar24;
                        *(undefined4 *)(pauVar26[-3] + 4) = uVar9;
                        *(undefined4 *)(pauVar26[-3] + 8) = uVar10;
                        *(undefined4 *)(pauVar26[-3] + 0xc) = uVar11;
                        *(undefined4 *)pauVar26[-4] = uVar12;
                        *(undefined4 *)(pauVar26[-4] + 4) = uVar13;
                        *(undefined4 *)(pauVar26[-4] + 8) = uVar14;
                        *(undefined4 *)(pauVar26[-4] + 0xc) = uVar15;
                        puVar24 = (undefined4 *)((int64_t)pauVar26 + iVar20 + -0x50);
                        uVar9 = puVar24[1];
                        uVar10 = puVar24[2];
                        uVar11 = puVar24[3];
                        puVar28 = (undefined4 *)((int64_t)pauVar26 + iVar20 + -0x60);
                        uVar12 = *puVar28;
                        uVar13 = puVar28[1];
                        uVar14 = puVar28[2];
                        uVar15 = puVar28[3];
                        *(undefined4 *)pauVar26[-5] = *puVar24;
                        *(undefined4 *)(pauVar26[-5] + 4) = uVar9;
                        *(undefined4 *)(pauVar26[-5] + 8) = uVar10;
                        *(undefined4 *)(pauVar26[-5] + 0xc) = uVar11;
                        *(undefined4 *)pauVar26[-6] = uVar12;
                        *(undefined4 *)(pauVar26[-6] + 4) = uVar13;
                        *(undefined4 *)(pauVar26[-6] + 8) = uVar14;
                        *(undefined4 *)(pauVar26[-6] + 0xc) = uVar15;
                        puVar24 = (undefined4 *)((int64_t)pauVar26 + iVar20 + -0x70);
                        uVar9 = puVar24[1];
                        uVar10 = puVar24[2];
                        uVar11 = puVar24[3];
                        auVar31 = *(undefined (*) [16])((int64_t)pauVar25 + iVar20);
                        if (uVar30 == 0) break;
                        *(undefined4 *)pauVar26[-7] = *puVar24;
                        *(undefined4 *)(pauVar26[-7] + 4) = uVar9;
                        *(undefined4 *)(pauVar26[-7] + 8) = uVar10;
                        *(undefined4 *)(pauVar26[-7] + 0xc) = uVar11;
                        *pauVar25 = auVar31;
                        pauVar26 = pauVar25;
                    }
                    *(undefined4 *)pauVar26[-7] = *puVar24;
                    *(undefined4 *)(pauVar26[-7] + 4) = uVar9;
                    *(undefined4 *)(pauVar26[-7] + 8) = uVar10;
                    *(undefined4 *)(pauVar26[-7] + 0xc) = uVar11;
                    in_RDX = in_RDX & 0x7f;
                }
                for (uVar30 = in_RDX >> 4; uVar30 != 0; uVar30 = uVar30 - 1) {
                    *pauVar25 = auVar31;
                    pauVar25 = pauVar25 + -1;
                    auVar31 = *(undefined (*) [16])((int64_t)pauVar25 + iVar20);
                }
                if ((in_RDX & 0xf) != 0) {
                    *(undefined4 *)*pauVar21 = uVar5;
                    *(undefined4 *)(*pauVar21 + 4) = uVar6;
                    *(undefined4 *)(*pauVar21 + 8) = uVar7;
                    *(undefined4 *)(*pauVar21 + 0xc) = uVar8;
                }
                *pauVar25 = auVar31;
                return pauVar21;
            }
            if (*(uint32_t *)0x1806a3990 < 3) {
                if ((in_RDX < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
                    if (0x80 < in_RDX) {
                        iVar20 = ((uint64_t)pauVar21 & 0xf) - 0x10;
                        puVar24 = (undefined4 *)((int64_t)pauVar21 - iVar20);
                        puVar28 = (undefined4 *)((int64_t)in_RCX - iVar20);
                        in_RDX = in_RDX + iVar20;
                        if (0x80 < in_RDX) {
                            do {
                                uVar5 = puVar28[1];
                                uVar6 = puVar28[2];
                                uVar7 = puVar28[3];
                                uVar8 = puVar28[4];
                                uVar9 = puVar28[5];
                                uVar10 = puVar28[6];
                                uVar11 = puVar28[7];
                                uVar12 = puVar28[8];
                                uVar13 = puVar28[9];
                                uVar14 = puVar28[10];
                                uVar15 = puVar28[0xb];
                                uVar16 = puVar28[0xc];
                                uVar17 = puVar28[0xd];
                                uVar18 = puVar28[0xe];
                                uVar19 = puVar28[0xf];
                                *puVar24 = *puVar28;
                                puVar24[1] = uVar5;
                                puVar24[2] = uVar6;
                                puVar24[3] = uVar7;
                                puVar24[4] = uVar8;
                                puVar24[5] = uVar9;
                                puVar24[6] = uVar10;
                                puVar24[7] = uVar11;
                                puVar24[8] = uVar12;
                                puVar24[9] = uVar13;
                                puVar24[10] = uVar14;
                                puVar24[0xb] = uVar15;
                                puVar24[0xc] = uVar16;
                                puVar24[0xd] = uVar17;
                                puVar24[0xe] = uVar18;
                                puVar24[0xf] = uVar19;
                                auVar1 = *(undefined (*) [16])(puVar28 + 0x14);
                                auVar31 = *(undefined (*) [16])(puVar28 + 0x18);
                                auVar2 = *(undefined (*) [16])(puVar28 + 0x1c);
                                *(undefined (*) [16])(puVar24 + 0x10) = *(undefined (*) [16])(puVar28 + 0x10);
                                *(undefined (*) [16])(puVar24 + 0x14) = auVar1;
                                *(undefined (*) [16])(puVar24 + 0x18) = auVar31;
                                *(undefined (*) [16])(puVar24 + 0x1c) = auVar2;
                                puVar24 = puVar24 + 0x20;
                                puVar28 = puVar28 + 0x20;
                                in_RDX = in_RDX - 0x80;
                            } while (0x7f < in_RDX);
                        }
                    }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
                    pauVar21 = (undefined (*) [32])
                               (*(code *)((uint64_t)*(uint32_t *)((in_RDX + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))
                                         ();
                    return pauVar21;
                }
code_r0x000180498020:
                *(undefined8 *)((int64_t)auStackX_10 + iVar20 + 8) = *(undefined8 *)((int64_t)auStackX_10 + iVar20 + 8);
                *(undefined8 *)((int64_t)auStackX_10 + iVar20) = unaff_RSI;
                pauVar22 = pauVar21;
                for (; in_RDX != 0; in_RDX = in_RDX - 1) {
                    (*pauVar22)[0] = (*in_RCX)[0];
                    in_RCX = (undefined (*) [32])(*in_RCX + 1);
                    pauVar22 = (undefined (*) [32])(*pauVar22 + 1);
                }
                return pauVar21;
            }
            if ((0x2000 < in_RDX) && (in_RDX < 0x180001)) {
                pauVar22 = pauVar21 + 2;
                if (in_RCX < pauVar21) {
                    pauVar22 = in_RCX;
                }
                if ((pauVar22 <= in_RCX) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
            }
            auVar32 = vmovdqu_avx(*in_RCX);
            auVar37 = vmovdqu_avx(*(undefined (*) [32])(in_RCX[-1] + in_RDX));
            if (0x100 < in_RDX) {
                iVar20 = ((uint64_t)pauVar21 & 0x1f) - 0x20;
                pauVar22 = (undefined (*) [32])((int64_t)pauVar21 - iVar20);
                in_RCX = (undefined (*) [32])((int64_t)in_RCX - iVar20);
                in_RDX = in_RDX + iVar20;
                if (0x100 < in_RDX) {
                    if (0x180000 < in_RDX) {
                        do {
                            uVar30 = in_RDX;
                            pauVar27 = in_RCX;
                            pauVar23 = pauVar22;
                            auVar33 = vmovdqu_avx(*pauVar27);
                            auVar35 = vmovdqu_avx(pauVar27[1]);
                            auVar34 = vmovdqu_avx(pauVar27[2]);
                            auVar36 = vmovdqu_avx(pauVar27[3]);
                            auVar33 = vmovntdq_avx(auVar33);
                            *pauVar23 = auVar33;
                            auVar33 = vmovntdq_avx(auVar35);
                            pauVar23[1] = auVar33;
                            auVar33 = vmovntdq_avx(auVar34);
                            pauVar23[2] = auVar33;
                            auVar33 = vmovntdq_avx(auVar36);
                            pauVar23[3] = auVar33;
                            auVar33 = vmovdqu_avx(pauVar27[4]);
                            auVar35 = vmovdqu_avx(pauVar27[5]);
                            auVar34 = vmovdqu_avx(pauVar27[6]);
                            auVar36 = vmovdqu_avx(pauVar27[7]);
                            auVar33 = vmovntdq_avx(auVar33);
                            pauVar23[4] = auVar33;
                            auVar33 = vmovntdq_avx(auVar35);
                            pauVar23[5] = auVar33;
                            auVar33 = vmovntdq_avx(auVar34);
                            pauVar23[6] = auVar33;
                            auVar33 = vmovntdq_avx(auVar36);
                            pauVar23[7] = auVar33;
                            pauVar22 = pauVar23 + 8;
                            in_RCX = pauVar27 + 8;
                            in_RDX = uVar30 - 0x100;
                        } while (0xff < uVar30 - 0x100);
                        uVar29 = uVar30 - 0xe1 & 0xffffffffffffffe0;
                        switch(uVar30) {
                        case 0x1e1:
                        case 0x1e2:
                        case 0x1e3:
                        case 0x1e4:
                        case 0x1e5:
                        case 0x1e6:
                        case 0x1e7:
                        case 0x1e8:
                        case 0x1e9:
                        case 0x1ea:
                        case 0x1eb:
                        case 0x1ec:
                        case 0x1ed:
                        case 0x1ee:
                        case 0x1ef:
                        case 0x1f0:
                        case 0x1f1:
                        case 0x1f2:
                        case 499:
                        case 500:
                        case 0x1f5:
                        case 0x1f6:
                        case 0x1f7:
                        case 0x1f8:
                        case 0x1f9:
                        case 0x1fa:
                        case 0x1fb:
                        case 0x1fc:
                        case 0x1fd:
                        case 0x1fe:
                        case 0x1ff:
                            auVar33 = vmovdqu_avx(*(undefined (*) [32])(*pauVar27 + uVar29));
                            auVar33 = vmovntdq_avx(auVar33);
                            *(undefined (*) [32])(*pauVar23 + uVar29) = auVar33;
                        case 0x1c1:
                        case 0x1c2:
                        case 0x1c3:
                        case 0x1c4:
                        case 0x1c5:
                        case 0x1c6:
                        case 0x1c7:
                        case 0x1c8:
                        case 0x1c9:
                        case 0x1ca:
                        case 0x1cb:
                        case 0x1cc:
                        case 0x1cd:
                        case 0x1ce:
                        case 0x1cf:
                        case 0x1d0:
                        case 0x1d1:
                        case 0x1d2:
                        case 0x1d3:
                        case 0x1d4:
                        case 0x1d5:
                        case 0x1d6:
                        case 0x1d7:
                        case 0x1d8:
                        case 0x1d9:
                        case 0x1da:
                        case 0x1db:
                        case 0x1dc:
                        case 0x1dd:
                        case 0x1de:
                        case 0x1df:
                        case 0x1e0:
                            auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[1] + uVar29));
                            auVar33 = vmovntdq_avx(auVar33);
                            *(undefined (*) [32])(pauVar23[1] + uVar29) = auVar33;
                        case 0x1a1:
                        case 0x1a2:
                        case 0x1a3:
                        case 0x1a4:
                        case 0x1a5:
                        case 0x1a6:
                        case 0x1a7:
                        case 0x1a8:
                        case 0x1a9:
                        case 0x1aa:
                        case 0x1ab:
                        case 0x1ac:
                        case 0x1ad:
                        case 0x1ae:
                        case 0x1af:
                        case 0x1b0:
                        case 0x1b1:
                        case 0x1b2:
                        case 0x1b3:
                        case 0x1b4:
                        case 0x1b5:
                        case 0x1b6:
                        case 0x1b7:
                        case 0x1b8:
                        case 0x1b9:
                        case 0x1ba:
                        case 0x1bb:
                        case 0x1bc:
                        case 0x1bd:
                        case 0x1be:
                        case 0x1bf:
                        case 0x1c0:
                            auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[2] + uVar29));
                            auVar33 = vmovntdq_avx(auVar33);
                            *(undefined (*) [32])(pauVar23[2] + uVar29) = auVar33;
                        case 0x181:
                        case 0x182:
                        case 0x183:
                        case 0x184:
                        case 0x185:
                        case 0x186:
                        case 0x187:
                        case 0x188:
                        case 0x189:
                        case 0x18a:
                        case 0x18b:
                        case 0x18c:
                        case 0x18d:
                        case 0x18e:
                        case 399:
                        case 400:
                        case 0x191:
                        case 0x192:
                        case 0x193:
                        case 0x194:
                        case 0x195:
                        case 0x196:
                        case 0x197:
                        case 0x198:
                        case 0x199:
                        case 0x19a:
                        case 0x19b:
                        case 0x19c:
                        case 0x19d:
                        case 0x19e:
                        case 0x19f:
                        case 0x1a0:
                            auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[3] + uVar29));
                            auVar33 = vmovntdq_avx(auVar33);
                            *(undefined (*) [32])(pauVar23[3] + uVar29) = auVar33;
                        case 0x161:
                        case 0x162:
                        case 0x163:
                        case 0x164:
                        case 0x165:
                        case 0x166:
                        case 0x167:
                        case 0x168:
                        case 0x169:
                        case 0x16a:
                        case 0x16b:
                        case 0x16c:
                        case 0x16d:
                        case 0x16e:
                        case 0x16f:
                        case 0x170:
                        case 0x171:
                        case 0x172:
                        case 0x173:
                        case 0x174:
                        case 0x175:
                        case 0x176:
                        case 0x177:
                        case 0x178:
                        case 0x179:
                        case 0x17a:
                        case 0x17b:
                        case 0x17c:
                        case 0x17d:
                        case 0x17e:
                        case 0x17f:
                        case 0x180:
                            auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[4] + uVar29));
                            auVar33 = vmovntdq_avx(auVar33);
                            *(undefined (*) [32])(pauVar23[4] + uVar29) = auVar33;
                        case 0x141:
                        case 0x142:
                        case 0x143:
                        case 0x144:
                        case 0x145:
                        case 0x146:
                        case 0x147:
                        case 0x148:
                        case 0x149:
                        case 0x14a:
                        case 0x14b:
                        case 0x14c:
                        case 0x14d:
                        case 0x14e:
                        case 0x14f:
                        case 0x150:
                        case 0x151:
                        case 0x152:
                        case 0x153:
                        case 0x154:
                        case 0x155:
                        case 0x156:
                        case 0x157:
                        case 0x158:
                        case 0x159:
                        case 0x15a:
                        case 0x15b:
                        case 0x15c:
                        case 0x15d:
                        case 0x15e:
                        case 0x15f:
                        case 0x160:
                            auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[5] + uVar29));
                            auVar33 = vmovntdq_avx(auVar33);
                            *(undefined (*) [32])(pauVar23[5] + uVar29) = auVar33;
                        case 0x121:
                        case 0x122:
                        case 0x123:
                        case 0x124:
                        case 0x125:
                        case 0x126:
                        case 0x127:
                        case 0x128:
                        case 0x129:
                        case 0x12a:
                        case 299:
                        case 300:
                        case 0x12d:
                        case 0x12e:
                        case 0x12f:
                        case 0x130:
                        case 0x131:
                        case 0x132:
                        case 0x133:
                        case 0x134:
                        case 0x135:
                        case 0x136:
                        case 0x137:
                        case 0x138:
                        case 0x139:
                        case 0x13a:
                        case 0x13b:
                        case 0x13c:
                        case 0x13d:
                        case 0x13e:
                        case 0x13f:
                        case 0x140:
                            auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar27[6] + uVar29));
                            auVar33 = vmovntdq_avx(auVar33);
                            *(undefined (*) [32])(pauVar23[6] + uVar29) = auVar33;
                        default:
                            auVar37 = vmovdqu_avx(auVar37);
                            *(undefined (*) [32])(pauVar23[-1] + uVar30) = auVar37;
                        case 0x100:
                            auVar32 = vmovdqu_avx(auVar32);
                            *pauVar21 = auVar32;
                            return pauVar21;
                        }
                    }
                    do {
                        auVar32 = vmovdqu_avx(*in_RCX);
                        auVar37 = vmovdqu_avx(in_RCX[1]);
                        auVar33 = vmovdqu_avx(in_RCX[2]);
                        auVar35 = vmovdqu_avx(in_RCX[3]);
                        *pauVar22 = auVar32;
                        pauVar22[1] = auVar37;
                        pauVar22[2] = auVar33;
                        pauVar22[3] = auVar35;
                        auVar32 = vmovdqu_avx(in_RCX[4]);
                        auVar37 = vmovdqu_avx(in_RCX[5]);
                        auVar33 = vmovdqu_avx(in_RCX[6]);
                        auVar35 = vmovdqu_avx(in_RCX[7]);
                        pauVar22[4] = auVar32;
                        pauVar22[5] = auVar37;
                        pauVar22[6] = auVar33;
                        pauVar22[7] = auVar35;
                        pauVar22 = pauVar22 + 8;
                        in_RCX = in_RCX + 8;
                        in_RDX = in_RDX - 0x100;
                    } while (0xff < in_RDX);
                }
            }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
            pauVar21 = (undefined (*) [32])
                       (*(code *)((uint64_t)*(uint32_t *)((in_RDX + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
            return pauVar21;
        }
    }
    return (undefined (*) [32])0x0;
}

// ============================================================
// Function: FUN_1802231e0
// Address: 0x1802231e0
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802231e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802231f5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180223222;
    iVar2 = fcn.180498cd0();
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180223234;
    iVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022324a;
        fcn.180498030(iVar3, in_RCX, iVar2 + 1);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180223270
// Address: 0x180223270
// Size: 131 bytes
// ============================================================
int64_t fcn.180223270(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    char *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    char *pcVar3;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022327c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX != (char *)0x0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RDI;
        for (pcVar3 = in_RCX; (in_RDX != 0 && (in_RDX = in_RDX + -1, *pcVar3 != '\0')); pcVar3 = pcVar3 + 1) {
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802232c6;
        iVar2 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                             );
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802232dc;
            fcn.180498030(iVar2, in_RCX, (int64_t)pcVar3 - (int64_t)in_RCX);
            *(undefined *)(iVar2 + ((int64_t)pcVar3 - (int64_t)in_RCX)) = 0;
        }
        return iVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180223300
// Address: 0x180223300
// Size: 305 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined * fcn.180223300(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined *puVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t in_RCX;
    undefined8 uVar6;
    uint64_t uVar7;
    int32_t in_EDX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined *puVar9;
    undefined8 uStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180223310;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_EDX == 0) {
        uVar6 = 1;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)((int64_t)&arg_38h + iVar2);
        *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar2) = 0x180224d70;
        iVar4 = fcn.18045a350(1, 0x1804bf850, 0x152);
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar4 + iVar2) = 0x180224d7b;
        puVar5 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar4 + iVar2), 
                               *(int64_t *)(&stack0x00000040 + iVar4 + iVar2));
        if (puVar5 != (undefined *)0x0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar4 + iVar2) = 0x180224d90;
            func_0x0001804986e0(puVar5, 0, uVar6);
        }
        return puVar5;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022335c;
    puVar5 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    if (puVar5 != (undefined *)0x0) {
        uVar8 = (int64_t)in_EDX * 3;
        uVar7 = 1;
        if (uVar8 != 0) {
            uVar7 = uVar8;
        }
        if (uVar7 <= (uint64_t)(int64_t)(in_EDX * 3)) {
            uVar8 = 0;
            puVar3 = puVar5;
            puVar9 = puVar5;
            if (in_EDX != 0) {
                do {
                    uVar1 = *(uint8_t *)(uVar8 + in_RCX);
                    uVar8 = uVar8 + 1;
                    *puVar9 = *(undefined *)((uint64_t)(uVar1 >> 4) + 0x1804bf828);
                    puVar9[1] = *(undefined *)((uint64_t)(uVar1 & 0xf) + 0x1804bf828);
                    puVar3 = puVar9 + 2;
                    *puVar3 = 0x3a;
                    puVar9 = puVar9 + 3;
                } while (uVar8 < (uint64_t)(int64_t)in_EDX);
            }
            *puVar3 = 0;
            return puVar5;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022337e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180223396;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802233a8;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802233bd;
        fcn.180224990(puVar5, 0x1804bf850, 0x15a);
    }
    return (undefined *)0x0;
}

