// Chunk 169 - 50 functions

// ============================================================
// Function: FUN_180225556
// Address: 0x180225556
// Size: 93 bytes
// ============================================================
uint64_t fcn.180225556(int64_t arg_30h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    
    uVar1 = fcn.180225bb0(in_stack_00000020);
    iVar2 = fcn.1802261e0(in_stack_00000020, in_stack_00000028);
    if (iVar2 == 0) {
        fcn.18027bb50(0x1804bfdd0, 0x1804bf8e8, 0x2ea);
    }
    return *(uint64_t *)0x18077e468 / (uint64_t)(1LL << (uVar1 & 0x3f));
}

// ============================================================
// Function: FUN_1802255b3
// Address: 0x1802255b3
// Size: 8 bytes
// ============================================================
undefined8 fcn.1802255b3(void)
{
    return 0;
}

// ============================================================
// Function: FUN_1802255c0
// Address: 0x1802255c0
// Size: 251 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1802255c0(int64_t arg_28h)
{
    uint64_t *puVar1;
    int64_t iVar2;
    uint64_t **in_RCX;
    uint64_t *in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802255d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX < *(uint64_t ***)0x18077e470) || (*(uint64_t ***)0x18077e470 + *(int64_t *)0x18077e478 <= in_RCX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022560e;
        fcn.18027bb50(0x1804bfa38, 0x1804bf8e8, 0x18e);
    }
    if ((in_RDX < *(uint64_t **)0x18077e460) ||
       ((uint64_t *)((int64_t)*(uint64_t **)0x18077e460 + *(int64_t *)0x18077e468) <= in_RDX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022563f;
        fcn.18027bb50(0x1804bfa60, 0x1804bf8e8, 399);
    }
    puVar1 = *in_RCX;
    *in_RDX = (uint64_t)puVar1;
    if ((puVar1 != (uint64_t *)0x0) &&
       ((puVar1 < *(uint64_t **)0x18077e460 ||
        ((uint64_t)((int64_t)*(uint64_t **)0x18077e460 + *(int64_t *)0x18077e468) <= puVar1)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022567b;
        fcn.18027bb50(0x1804bfa90, 0x1804bf8e8, 0x193);
    }
    in_RDX[1] = (uint64_t)in_RCX;
    if (*in_RDX != 0) {
        if (*(uint64_t ***)(*in_RDX + 8) != in_RCX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802256a6;
            fcn.18027bb50(0x1804bfad8, 0x1804bf8e8, 0x197);
        }
        *(uint64_t **)(*in_RDX + 8) = in_RDX;
    }
    *in_RCX = in_RDX;
    return;
}

// ============================================================
// Function: FUN_1802256c0
// Address: 0x1802256c0
// Size: 294 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1802256c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int32_t in_EDX;
    uint64_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802256da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_EDX < 0) || (*(int64_t *)0x18077e478 <= in_EDX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022570c;
        fcn.18027bb50(0x1804bf928, 0x1804bf8e8, 0x176);
    }
    uVar1 = (uint8_t)in_EDX;
    if ((in_RCX - *(int64_t *)0x18077e460 & (*(uint64_t *)0x18077e468 >> (uVar1 & 0x3f)) - 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180225749;
        fcn.18027bb50(0x1804bf960, 0x1804bf8e8, 0x177);
    }
    uVar3 = (1LL << (uVar1 & 0x3f)) +
            (uint64_t)(in_RCX - *(int64_t *)0x18077e460) / (*(uint64_t *)0x18077e468 >> (uVar1 & 0x3f));
    if ((uVar3 == 0) || (*(uint64_t *)0x18077e498 <= uVar3)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180225798;
        fcn.18027bb50(0x1804bf9b0, 0x1804bf8e8, 0x179);
    }
    uVar4 = uVar3 >> 3;
    uVar5 = (uint32_t)uVar3 & 7;
    if ((*(uint8_t *)(uVar4 + in_R8) & (uint8_t)(1LL << (int8_t)uVar5)) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802257c6;
        fcn.18027bb50(0x1804bf9e8, 0x1804bf8e8, 0x17a);
    }
    *(uint8_t *)(uVar4 + in_R8) = *(uint8_t *)(uVar4 + in_R8) & ~(uint8_t)(1LL << uVar5);
    return;
}

// ============================================================
// Function: FUN_1802257f0
// Address: 0x1802257f0
// Size: 167 bytes
// ============================================================
void fcn.1802257f0(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802257fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180225816;
    fcn.180224990(*(undefined8 *)0x18077e470, 0x1804bf8e8, 600);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022582f;
    fcn.180224990(*(undefined8 *)0x18077e488, 0x1804bf8e8, 0x259);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180225848;
    fcn.180224990(*(undefined8 *)0x18077e490, 0x1804bf8e8, 0x25a);
    if ((*(int64_t *)0x18077e450 != 0) && (*(int64_t *)0x18077e458 != 0)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18022586c;
        (*(code *)0x69a13a)(*(int64_t *)0x18077e450, 0, 0x8000);
    }
    *(undefined (*) [16])0x18077e450 = ZEXT816(0);
    *(undefined (*) [16])0x18077e460 = ZEXT816(0);
    *(undefined (*) [16])0x18077e470 = ZEXT816(0);
    *(undefined (*) [16])0x18077e480 = ZEXT816(0);
    *(undefined (*) [16])0x18077e490 = ZEXT816(0);
    return;
}

// ============================================================
// Function: FUN_180225910
// Address: 0x180225910
// Size: 115 bytes
// ============================================================
void fcn.180225910(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined (*pauVar1) [16];
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    undefined (*pauVar6) [16];
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180225924;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (((uint64_t)arg1 < *(undefined (**) [16])0x18077e460) ||
           ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468) <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022595f;
            fcn.18027bb50(0x1804bfa60, 0x1804bf8e8, 0x2c0);
        }
        if ((*(undefined (**) [16])0x18077e460 <= (uint64_t)arg1) &&
           ((uint64_t)arg1 < (undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468))) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225995;
            uVar4 = fcn.180225bb0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259a9;
            iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259c6;
                fcn.18027bb50(0x1804bfcc0, 0x1804bf8e8, 0x2c5);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259d7;
            fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259ea;
            fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259f4;
            pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
            if (pauVar5 != (undefined (*) [16])0x0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a1a;
                    pauVar6 = (undefined (*) [16])func_0x0001802258a0(pauVar5, uVar4 & 0xffffffff);
                    if ((undefined (*) [16])arg1 != pauVar6) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a38;
                        fcn.18027bb50(0x1804bfd00, 0x1804bf8e8, 0x2cb);
                    }
                    if ((undefined (*) [16])arg1 == (undefined (*) [16])0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a56;
                        fcn.18027bb50(0x1804bfd40, 0x1804bf8e8, 0x2cc);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a67;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a84;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2cd);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a95;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a9d;
                    func_0x000180226020(arg1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225aae;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225acb;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2d0);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225adc;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225ae4;
                    func_0x000180226020(pauVar5);
                    uVar4 = uVar4 - 1;
                    pauVar1 = pauVar5;
                    pauVar6 = (undefined (*) [16])arg1;
                    if ((uint64_t)arg1 <= pauVar5) {
                        pauVar1 = (undefined (*) [16])arg1;
                        pauVar6 = pauVar5;
                    }
                    arg1 = (int64_t)pauVar1;
                    *pauVar6 = ZEXT816(0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b11;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b2e;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2db);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b3f;
                    func_0x0001802260b0(arg1, uVar4 & 0xffffffff, *(undefined8 *)0x18077e488);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b52;
                    fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                    if (*(undefined (**) [16])(*(int64_t *)0x18077e470 + uVar4 * 8) != (undefined (*) [16])arg1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b78;
                        fcn.18027bb50(0x1804bfda0, 0x1804bf8e8, 0x2de);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b82;
                    pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
                } while (pauVar5 != (undefined (*) [16])0x0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180225983
// Address: 0x180225983
// Size: 125 bytes
// ============================================================
void fcn.180225910(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined (*pauVar1) [16];
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    undefined (*pauVar6) [16];
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180225924;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (((uint64_t)arg1 < *(undefined (**) [16])0x18077e460) ||
           ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468) <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022595f;
            fcn.18027bb50(0x1804bfa60, 0x1804bf8e8, 0x2c0);
        }
        if ((*(undefined (**) [16])0x18077e460 <= (uint64_t)arg1) &&
           ((uint64_t)arg1 < (undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468))) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225995;
            uVar4 = fcn.180225bb0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259a9;
            iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259c6;
                fcn.18027bb50(0x1804bfcc0, 0x1804bf8e8, 0x2c5);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259d7;
            fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259ea;
            fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259f4;
            pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
            if (pauVar5 != (undefined (*) [16])0x0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a1a;
                    pauVar6 = (undefined (*) [16])func_0x0001802258a0(pauVar5, uVar4 & 0xffffffff);
                    if ((undefined (*) [16])arg1 != pauVar6) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a38;
                        fcn.18027bb50(0x1804bfd00, 0x1804bf8e8, 0x2cb);
                    }
                    if ((undefined (*) [16])arg1 == (undefined (*) [16])0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a56;
                        fcn.18027bb50(0x1804bfd40, 0x1804bf8e8, 0x2cc);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a67;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a84;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2cd);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a95;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a9d;
                    func_0x000180226020(arg1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225aae;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225acb;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2d0);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225adc;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225ae4;
                    func_0x000180226020(pauVar5);
                    uVar4 = uVar4 - 1;
                    pauVar1 = pauVar5;
                    pauVar6 = (undefined (*) [16])arg1;
                    if ((uint64_t)arg1 <= pauVar5) {
                        pauVar1 = (undefined (*) [16])arg1;
                        pauVar6 = pauVar5;
                    }
                    arg1 = (int64_t)pauVar1;
                    *pauVar6 = ZEXT816(0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b11;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b2e;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2db);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b3f;
                    func_0x0001802260b0(arg1, uVar4 & 0xffffffff, *(undefined8 *)0x18077e488);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b52;
                    fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                    if (*(undefined (**) [16])(*(int64_t *)0x18077e470 + uVar4 * 8) != (undefined (*) [16])arg1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b78;
                        fcn.18027bb50(0x1804bfda0, 0x1804bf8e8, 0x2de);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b82;
                    pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
                } while (pauVar5 != (undefined (*) [16])0x0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180225a00
// Address: 0x180225a00
// Size: 403 bytes
// ============================================================
void fcn.180225910(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined (*pauVar1) [16];
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    undefined (*pauVar6) [16];
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180225924;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (((uint64_t)arg1 < *(undefined (**) [16])0x18077e460) ||
           ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468) <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022595f;
            fcn.18027bb50(0x1804bfa60, 0x1804bf8e8, 0x2c0);
        }
        if ((*(undefined (**) [16])0x18077e460 <= (uint64_t)arg1) &&
           ((uint64_t)arg1 < (undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468))) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225995;
            uVar4 = fcn.180225bb0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259a9;
            iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259c6;
                fcn.18027bb50(0x1804bfcc0, 0x1804bf8e8, 0x2c5);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259d7;
            fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259ea;
            fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259f4;
            pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
            if (pauVar5 != (undefined (*) [16])0x0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a1a;
                    pauVar6 = (undefined (*) [16])func_0x0001802258a0(pauVar5, uVar4 & 0xffffffff);
                    if ((undefined (*) [16])arg1 != pauVar6) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a38;
                        fcn.18027bb50(0x1804bfd00, 0x1804bf8e8, 0x2cb);
                    }
                    if ((undefined (*) [16])arg1 == (undefined (*) [16])0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a56;
                        fcn.18027bb50(0x1804bfd40, 0x1804bf8e8, 0x2cc);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a67;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a84;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2cd);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a95;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a9d;
                    func_0x000180226020(arg1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225aae;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225acb;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2d0);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225adc;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225ae4;
                    func_0x000180226020(pauVar5);
                    uVar4 = uVar4 - 1;
                    pauVar1 = pauVar5;
                    pauVar6 = (undefined (*) [16])arg1;
                    if ((uint64_t)arg1 <= pauVar5) {
                        pauVar1 = (undefined (*) [16])arg1;
                        pauVar6 = pauVar5;
                    }
                    arg1 = (int64_t)pauVar1;
                    *pauVar6 = ZEXT816(0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b11;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b2e;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2db);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b3f;
                    func_0x0001802260b0(arg1, uVar4 & 0xffffffff, *(undefined8 *)0x18077e488);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b52;
                    fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                    if (*(undefined (**) [16])(*(int64_t *)0x18077e470 + uVar4 * 8) != (undefined (*) [16])arg1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b78;
                        fcn.18027bb50(0x1804bfda0, 0x1804bf8e8, 0x2de);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b82;
                    pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
                } while (pauVar5 != (undefined (*) [16])0x0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180225b93
// Address: 0x180225b93
// Size: 10 bytes
// ============================================================
void fcn.180225910(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined (*pauVar1) [16];
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    undefined (*pauVar6) [16];
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180225924;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (((uint64_t)arg1 < *(undefined (**) [16])0x18077e460) ||
           ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468) <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022595f;
            fcn.18027bb50(0x1804bfa60, 0x1804bf8e8, 0x2c0);
        }
        if ((*(undefined (**) [16])0x18077e460 <= (uint64_t)arg1) &&
           ((uint64_t)arg1 < (undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468))) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225995;
            uVar4 = fcn.180225bb0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259a9;
            iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259c6;
                fcn.18027bb50(0x1804bfcc0, 0x1804bf8e8, 0x2c5);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259d7;
            fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259ea;
            fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259f4;
            pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
            if (pauVar5 != (undefined (*) [16])0x0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a1a;
                    pauVar6 = (undefined (*) [16])func_0x0001802258a0(pauVar5, uVar4 & 0xffffffff);
                    if ((undefined (*) [16])arg1 != pauVar6) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a38;
                        fcn.18027bb50(0x1804bfd00, 0x1804bf8e8, 0x2cb);
                    }
                    if ((undefined (*) [16])arg1 == (undefined (*) [16])0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a56;
                        fcn.18027bb50(0x1804bfd40, 0x1804bf8e8, 0x2cc);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a67;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a84;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2cd);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a95;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a9d;
                    func_0x000180226020(arg1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225aae;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225acb;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2d0);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225adc;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225ae4;
                    func_0x000180226020(pauVar5);
                    uVar4 = uVar4 - 1;
                    pauVar1 = pauVar5;
                    pauVar6 = (undefined (*) [16])arg1;
                    if ((uint64_t)arg1 <= pauVar5) {
                        pauVar1 = (undefined (*) [16])arg1;
                        pauVar6 = pauVar5;
                    }
                    arg1 = (int64_t)pauVar1;
                    *pauVar6 = ZEXT816(0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b11;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b2e;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2db);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b3f;
                    func_0x0001802260b0(arg1, uVar4 & 0xffffffff, *(undefined8 *)0x18077e488);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b52;
                    fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                    if (*(undefined (**) [16])(*(int64_t *)0x18077e470 + uVar4 * 8) != (undefined (*) [16])arg1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b78;
                        fcn.18027bb50(0x1804bfda0, 0x1804bf8e8, 0x2de);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b82;
                    pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
                } while (pauVar5 != (undefined (*) [16])0x0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180225b9d
// Address: 0x180225b9d
// Size: 6 bytes
// ============================================================
void fcn.180225910(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined (*pauVar1) [16];
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    undefined (*pauVar6) [16];
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180225924;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (((uint64_t)arg1 < *(undefined (**) [16])0x18077e460) ||
           ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468) <= (uint64_t)arg1)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022595f;
            fcn.18027bb50(0x1804bfa60, 0x1804bf8e8, 0x2c0);
        }
        if ((*(undefined (**) [16])0x18077e460 <= (uint64_t)arg1) &&
           ((uint64_t)arg1 < (undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(int64_t *)0x18077e468))) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225995;
            uVar4 = fcn.180225bb0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259a9;
            iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259c6;
                fcn.18027bb50(0x1804bfcc0, 0x1804bf8e8, 0x2c5);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259d7;
            fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259ea;
            fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802259f4;
            pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
            if (pauVar5 != (undefined (*) [16])0x0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a1a;
                    pauVar6 = (undefined (*) [16])func_0x0001802258a0(pauVar5, uVar4 & 0xffffffff);
                    if ((undefined (*) [16])arg1 != pauVar6) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a38;
                        fcn.18027bb50(0x1804bfd00, 0x1804bf8e8, 0x2cb);
                    }
                    if ((undefined (*) [16])arg1 == (undefined (*) [16])0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a56;
                        fcn.18027bb50(0x1804bfd40, 0x1804bf8e8, 0x2cc);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a67;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a84;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2cd);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a95;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225a9d;
                    func_0x000180226020(arg1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225aae;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225acb;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2d0);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225adc;
                    fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225ae4;
                    func_0x000180226020(pauVar5);
                    uVar4 = uVar4 - 1;
                    pauVar1 = pauVar5;
                    pauVar6 = (undefined (*) [16])arg1;
                    if ((uint64_t)arg1 <= pauVar5) {
                        pauVar1 = (undefined (*) [16])arg1;
                        pauVar6 = pauVar5;
                    }
                    arg1 = (int64_t)pauVar1;
                    *pauVar6 = ZEXT816(0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b11;
                    iVar2 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b2e;
                        fcn.18027bb50(0x1804bfd60, 0x1804bf8e8, 0x2db);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b3f;
                    func_0x0001802260b0(arg1, uVar4 & 0xffffffff, *(undefined8 *)0x18077e488);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b52;
                    fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
                    if (*(undefined (**) [16])(*(int64_t *)0x18077e470 + uVar4 * 8) != (undefined (*) [16])arg1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b78;
                        fcn.18027bb50(0x1804bfda0, 0x1804bf8e8, 0x2de);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180225b82;
                    pauVar5 = (undefined (*) [16])func_0x0001802258a0(arg1, uVar4 & 0xffffffff);
                } while (pauVar5 != (undefined (*) [16])0x0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180225bb0
// Address: 0x180225bb0
// Size: 149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180225bb0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180225bc0;
    iVar2 = fcn.18045a350();
    uVar3 = (uint64_t)((*(int64_t *)0x18077e468 - *(int64_t *)0x18077e460) + in_RCX) / *(uint64_t *)0x18077e480;
    iVar1 = *(int64_t *)0x18077e478;
    while ((iVar1 = iVar1 + -1, uVar3 != 0 &&
           ((*(uint8_t *)((uVar3 >> 3) + *(int64_t *)0x18077e488) & (uint8_t)(1LL << ((uint8_t)uVar3 & 7))) == 0))) {
        if ((uVar3 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x180225c2f;
            fcn.18027bb50(0x1804bf900, 0x1804bf8e8, 0x160);
        }
        uVar3 = uVar3 >> 1;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180225c50
// Address: 0x180225c50
// Size: 111 bytes
// ============================================================
undefined (*) [16] fcn.180225c50(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t *piVar1;
    undefined (*pauVar2) [16];
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    uint64_t in_RCX;
    uint64_t uVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t iVar14;
    undefined8 unaff_R15;
    uint64_t uVar15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x180225c5d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = *(uint64_t *)0x18077e480;
    uVar4 = *(uint64_t *)0x18077e478;
    if (in_RCX <= *(uint64_t *)0x18077e468) {
        for (; uVar3 = uVar4 - 1, uVar8 = uVar3, uVar10 < in_RCX; uVar10 = uVar10 * 2) {
            uVar4 = uVar3;
        }
        for (; -1 < (int64_t)uVar8; uVar8 = uVar8 - 1) {
            if (*(int64_t *)(**(undefined (**) [16])0x18077e470 + uVar8 * 8) != 0) {
                if (uVar8 != uVar3) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
                    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R14;
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
                    do {
                        piVar1 = *(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225cf5;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d12;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x293);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d23;
                        fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        if (*piVar1 != 0) {
                            *(int64_t *)(*piVar1 + 8) = piVar1[1];
                        }
                        *(int64_t *)piVar1[1] = *piVar1;
                        if (((*piVar1 != 0) &&
                            ((pauVar2 = *(undefined (**) [16])(*piVar1 + 8), pauVar2 < *(undefined (**) [16])0x18077e470
                             || ((undefined (*) [16])(**(undefined (**) [16])0x18077e470 + *(uint64_t *)0x18077e478 * 8)
                                 <= pauVar2)))) &&
                           ((pauVar2 < *(undefined (**) [16])0x18077e460 ||
                            ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(uint64_t *)0x18077e468) <=
                             pauVar2)))) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d96;
                            fcn.18027bb50(0x1804bfb10, 0x1804bf8e8, 0x1aa);
                        }
                        if (piVar1 == *(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225dbc;
                            fcn.18027bb50(0x1804bfba0, 0x1804bf8e8, 0x296);
                        }
                        uVar10 = uVar8 + 1;
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225dd2;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225def;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x29c);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e00;
                        func_0x0001802260b0(piVar1, uVar10 & 0xffffffff, *(int64_t *)0x18077e488);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e13;
                        fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
                        if (*(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8 + 8) != piVar1) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e39;
                            fcn.18027bb50(0x1804bfbd0, 0x1804bf8e8, 0x29f);
                        }
                        uVar7 = (uint8_t)uVar10;
                        iVar11 = (int64_t)piVar1 + (*(uint64_t *)0x18077e468 >> (uVar7 & 0x3f));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e5a;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e77;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x2a3);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e88;
                        func_0x0001802260b0(iVar11, uVar10 & 0xffffffff);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e9b;
                        fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
                        if (*(int64_t *)(**(undefined (**) [16])0x18077e470 + uVar8 * 8 + 8) != iVar11) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225ec1;
                            fcn.18027bb50(0x1804bfbd0);
                        }
                        uVar15 = *(uint64_t *)0x18077e468 >> (uVar7 & 0x3f);
                        iVar14 = 1LL << (uVar7 & 0x3f);
                        puVar12 = (undefined *)0x0;
                        uVar8 = iVar14 + (uint64_t)(iVar11 - (int64_t)*(undefined (**) [16])0x18077e460) / uVar15;
                        uVar13 = uVar8 ^ 1;
                        uVar8 = uVar8 >> 3;
                        uVar9 = (uint8_t)(1LL << ((uint8_t)uVar13 & 7));
                        if (((*(uint8_t *)(uVar8 + *(int64_t *)0x18077e488) & uVar9) != 0) &&
                           ((*(uint8_t *)(uVar8 + *(int64_t *)0x18077e490) & uVar9) == 0)) {
                            puVar12 = **(undefined (**) [16])0x18077e460 + (iVar14 - 1U & uVar13) * uVar15;
                        }
                        if ((undefined *)(iVar11 - (*(uint64_t *)0x18077e468 >> (uVar7 & 0x3f))) != puVar12) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225f60;
                            fcn.18027bb50(0x1804bfc00, 0x1804bf8e8, 0x2a8);
                        }
                        uVar8 = uVar10;
                    } while (uVar10 != uVar3);
                }
                pauVar2 = *(undefined (**) [16])((*(undefined (**) [16])0x18077e470)[-1] + uVar4 * 8 + 8);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225f9e;
                iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fbb;
                    fcn.18027bb50(0x1804bfc58, 0x1804bf8e8, 0x2ad);
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fcc;
                func_0x0001802260b0(pauVar2, uVar3 & 0xffffffff, *(int64_t *)0x18077e490);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fd4;
                func_0x000180226020(pauVar2);
                if ((pauVar2 < *(undefined (**) [16])0x18077e460) ||
                   ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(uint64_t *)0x18077e468) <= pauVar2)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180226008;
                    fcn.18027bb50(0x1804bfc98, 0x1804bf8e8, 0x2b1);
                }
                *pauVar2 = ZEXT816(0);
                return pauVar2;
            }
        }
    }
    return (undefined (*) [16])0x0;
}

// ============================================================
// Function: FUN_180225cbf
// Address: 0x180225cbf
// Size: 714 bytes
// ============================================================
undefined (*) [16] fcn.180225c50(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t *piVar1;
    undefined (*pauVar2) [16];
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    uint64_t in_RCX;
    uint64_t uVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t iVar14;
    undefined8 unaff_R15;
    uint64_t uVar15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x180225c5d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = *(uint64_t *)0x18077e480;
    uVar4 = *(uint64_t *)0x18077e478;
    if (in_RCX <= *(uint64_t *)0x18077e468) {
        for (; uVar3 = uVar4 - 1, uVar8 = uVar3, uVar10 < in_RCX; uVar10 = uVar10 * 2) {
            uVar4 = uVar3;
        }
        for (; -1 < (int64_t)uVar8; uVar8 = uVar8 - 1) {
            if (*(int64_t *)(**(undefined (**) [16])0x18077e470 + uVar8 * 8) != 0) {
                if (uVar8 != uVar3) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
                    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R14;
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
                    do {
                        piVar1 = *(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225cf5;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d12;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x293);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d23;
                        fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        if (*piVar1 != 0) {
                            *(int64_t *)(*piVar1 + 8) = piVar1[1];
                        }
                        *(int64_t *)piVar1[1] = *piVar1;
                        if (((*piVar1 != 0) &&
                            ((pauVar2 = *(undefined (**) [16])(*piVar1 + 8), pauVar2 < *(undefined (**) [16])0x18077e470
                             || ((undefined (*) [16])(**(undefined (**) [16])0x18077e470 + *(uint64_t *)0x18077e478 * 8)
                                 <= pauVar2)))) &&
                           ((pauVar2 < *(undefined (**) [16])0x18077e460 ||
                            ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(uint64_t *)0x18077e468) <=
                             pauVar2)))) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d96;
                            fcn.18027bb50(0x1804bfb10, 0x1804bf8e8, 0x1aa);
                        }
                        if (piVar1 == *(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225dbc;
                            fcn.18027bb50(0x1804bfba0, 0x1804bf8e8, 0x296);
                        }
                        uVar10 = uVar8 + 1;
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225dd2;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225def;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x29c);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e00;
                        func_0x0001802260b0(piVar1, uVar10 & 0xffffffff, *(int64_t *)0x18077e488);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e13;
                        fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
                        if (*(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8 + 8) != piVar1) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e39;
                            fcn.18027bb50(0x1804bfbd0, 0x1804bf8e8, 0x29f);
                        }
                        uVar7 = (uint8_t)uVar10;
                        iVar11 = (int64_t)piVar1 + (*(uint64_t *)0x18077e468 >> (uVar7 & 0x3f));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e5a;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e77;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x2a3);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e88;
                        func_0x0001802260b0(iVar11, uVar10 & 0xffffffff);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e9b;
                        fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
                        if (*(int64_t *)(**(undefined (**) [16])0x18077e470 + uVar8 * 8 + 8) != iVar11) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225ec1;
                            fcn.18027bb50(0x1804bfbd0);
                        }
                        uVar15 = *(uint64_t *)0x18077e468 >> (uVar7 & 0x3f);
                        iVar14 = 1LL << (uVar7 & 0x3f);
                        puVar12 = (undefined *)0x0;
                        uVar8 = iVar14 + (uint64_t)(iVar11 - (int64_t)*(undefined (**) [16])0x18077e460) / uVar15;
                        uVar13 = uVar8 ^ 1;
                        uVar8 = uVar8 >> 3;
                        uVar9 = (uint8_t)(1LL << ((uint8_t)uVar13 & 7));
                        if (((*(uint8_t *)(uVar8 + *(int64_t *)0x18077e488) & uVar9) != 0) &&
                           ((*(uint8_t *)(uVar8 + *(int64_t *)0x18077e490) & uVar9) == 0)) {
                            puVar12 = **(undefined (**) [16])0x18077e460 + (iVar14 - 1U & uVar13) * uVar15;
                        }
                        if ((undefined *)(iVar11 - (*(uint64_t *)0x18077e468 >> (uVar7 & 0x3f))) != puVar12) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225f60;
                            fcn.18027bb50(0x1804bfc00, 0x1804bf8e8, 0x2a8);
                        }
                        uVar8 = uVar10;
                    } while (uVar10 != uVar3);
                }
                pauVar2 = *(undefined (**) [16])((*(undefined (**) [16])0x18077e470)[-1] + uVar4 * 8 + 8);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225f9e;
                iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fbb;
                    fcn.18027bb50(0x1804bfc58, 0x1804bf8e8, 0x2ad);
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fcc;
                func_0x0001802260b0(pauVar2, uVar3 & 0xffffffff, *(int64_t *)0x18077e490);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fd4;
                func_0x000180226020(pauVar2);
                if ((pauVar2 < *(undefined (**) [16])0x18077e460) ||
                   ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(uint64_t *)0x18077e468) <= pauVar2)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180226008;
                    fcn.18027bb50(0x1804bfc98, 0x1804bf8e8, 0x2b1);
                }
                *pauVar2 = ZEXT816(0);
                return pauVar2;
            }
        }
    }
    return (undefined (*) [16])0x0;
}

// ============================================================
// Function: FUN_180225f89
// Address: 0x180225f89
// Size: 143 bytes
// ============================================================
undefined (*) [16] fcn.180225c50(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t *piVar1;
    undefined (*pauVar2) [16];
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    uint64_t in_RCX;
    uint64_t uVar8;
    uint8_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar11;
    undefined *puVar12;
    uint64_t uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t iVar14;
    undefined8 unaff_R15;
    uint64_t uVar15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x180225c5d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = *(uint64_t *)0x18077e480;
    uVar4 = *(uint64_t *)0x18077e478;
    if (in_RCX <= *(uint64_t *)0x18077e468) {
        for (; uVar3 = uVar4 - 1, uVar8 = uVar3, uVar10 < in_RCX; uVar10 = uVar10 * 2) {
            uVar4 = uVar3;
        }
        for (; -1 < (int64_t)uVar8; uVar8 = uVar8 - 1) {
            if (*(int64_t *)(**(undefined (**) [16])0x18077e470 + uVar8 * 8) != 0) {
                if (uVar8 != uVar3) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
                    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R14;
                    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
                    do {
                        piVar1 = *(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225cf5;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d12;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x293);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d23;
                        fcn.1802256c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        if (*piVar1 != 0) {
                            *(int64_t *)(*piVar1 + 8) = piVar1[1];
                        }
                        *(int64_t *)piVar1[1] = *piVar1;
                        if (((*piVar1 != 0) &&
                            ((pauVar2 = *(undefined (**) [16])(*piVar1 + 8), pauVar2 < *(undefined (**) [16])0x18077e470
                             || ((undefined (*) [16])(**(undefined (**) [16])0x18077e470 + *(uint64_t *)0x18077e478 * 8)
                                 <= pauVar2)))) &&
                           ((pauVar2 < *(undefined (**) [16])0x18077e460 ||
                            ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(uint64_t *)0x18077e468) <=
                             pauVar2)))) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225d96;
                            fcn.18027bb50(0x1804bfb10, 0x1804bf8e8, 0x1aa);
                        }
                        if (piVar1 == *(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225dbc;
                            fcn.18027bb50(0x1804bfba0, 0x1804bf8e8, 0x296);
                        }
                        uVar10 = uVar8 + 1;
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225dd2;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225def;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x29c);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e00;
                        func_0x0001802260b0(piVar1, uVar10 & 0xffffffff, *(int64_t *)0x18077e488);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e13;
                        fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
                        if (*(int64_t **)(**(undefined (**) [16])0x18077e470 + uVar8 * 8 + 8) != piVar1) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e39;
                            fcn.18027bb50(0x1804bfbd0, 0x1804bf8e8, 0x29f);
                        }
                        uVar7 = (uint8_t)uVar10;
                        iVar11 = (int64_t)piVar1 + (*(uint64_t *)0x18077e468 >> (uVar7 & 0x3f));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e5a;
                        iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e77;
                            fcn.18027bb50(0x1804bfb60, 0x1804bf8e8, 0x2a3);
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e88;
                        func_0x0001802260b0(iVar11, uVar10 & 0xffffffff);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225e9b;
                        fcn.1802255c0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
                        if (*(int64_t *)(**(undefined (**) [16])0x18077e470 + uVar8 * 8 + 8) != iVar11) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225ec1;
                            fcn.18027bb50(0x1804bfbd0);
                        }
                        uVar15 = *(uint64_t *)0x18077e468 >> (uVar7 & 0x3f);
                        iVar14 = 1LL << (uVar7 & 0x3f);
                        puVar12 = (undefined *)0x0;
                        uVar8 = iVar14 + (uint64_t)(iVar11 - (int64_t)*(undefined (**) [16])0x18077e460) / uVar15;
                        uVar13 = uVar8 ^ 1;
                        uVar8 = uVar8 >> 3;
                        uVar9 = (uint8_t)(1LL << ((uint8_t)uVar13 & 7));
                        if (((*(uint8_t *)(uVar8 + *(int64_t *)0x18077e488) & uVar9) != 0) &&
                           ((*(uint8_t *)(uVar8 + *(int64_t *)0x18077e490) & uVar9) == 0)) {
                            puVar12 = **(undefined (**) [16])0x18077e460 + (iVar14 - 1U & uVar13) * uVar15;
                        }
                        if ((undefined *)(iVar11 - (*(uint64_t *)0x18077e468 >> (uVar7 & 0x3f))) != puVar12) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225f60;
                            fcn.18027bb50(0x1804bfc00, 0x1804bf8e8, 0x2a8);
                        }
                        uVar8 = uVar10;
                    } while (uVar10 != uVar3);
                }
                pauVar2 = *(undefined (**) [16])((*(undefined (**) [16])0x18077e470)[-1] + uVar4 * 8 + 8);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225f9e;
                iVar5 = fcn.1802261e0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fbb;
                    fcn.18027bb50(0x1804bfc58, 0x1804bf8e8, 0x2ad);
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fcc;
                func_0x0001802260b0(pauVar2, uVar3 & 0xffffffff, *(int64_t *)0x18077e490);
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180225fd4;
                func_0x000180226020(pauVar2);
                if ((pauVar2 < *(undefined (**) [16])0x18077e460) ||
                   ((undefined (*) [16])(**(undefined (**) [16])0x18077e460 + *(uint64_t *)0x18077e468) <= pauVar2)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x180226008;
                    fcn.18027bb50(0x1804bfc98, 0x1804bf8e8, 0x2b1);
                }
                *pauVar2 = ZEXT816(0);
                return pauVar2;
            }
        }
    }
    return (undefined (*) [16])0x0;
}

// ============================================================
// Function: FUN_180226020
// Address: 0x180226020
// Size: 140 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_280h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_22eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h

void fcn.180226020(int64_t *param_1)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*param_1 != 0) {
        *(int64_t *)(*param_1 + 8) = param_1[1];
    }
    *(int64_t *)param_1[1] = *param_1;
    if (*param_1 != 0) {
        uVar1 = *(uint64_t *)(*param_1 + 8);
        if (((uVar1 < *(uint64_t *)0x18077e470) || (*(uint64_t *)0x18077e470 + *(int64_t *)0x18077e478 * 8 <= uVar1)) &&
           ((uVar1 < *(uint64_t *)0x18077e460 || (*(uint64_t *)0x18077e460 + *(int64_t *)0x18077e468 <= uVar1)))) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18027bb5a;
            iVar4 = fcn.18045a350(0x1804bfb10, 0x1804bf8e8, 0x1aa);
            iVar4 = -iVar4;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18027bb6c;
            fcn.18027bd00(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18027bb76;
            fcn.1804730d0(0x16);
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18027bb80;
            fcn.18046df68(3);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802260b0
// Address: 0x1802260b0
// Size: 294 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1802260b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int32_t in_EDX;
    uint64_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802260ca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_EDX < 0) || (*(int64_t *)0x18077e478 <= in_EDX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802260fc;
        fcn.18027bb50(0x1804bf928, 0x1804bf8e8, 0x182);
    }
    uVar1 = (uint8_t)in_EDX;
    if ((in_RCX - *(int64_t *)0x18077e460 & (*(uint64_t *)0x18077e468 >> (uVar1 & 0x3f)) - 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180226139;
        fcn.18027bb50(0x1804bf960, 0x1804bf8e8, 0x183);
    }
    uVar3 = (1LL << (uVar1 & 0x3f)) +
            (uint64_t)(in_RCX - *(int64_t *)0x18077e460) / (*(uint64_t *)0x18077e468 >> (uVar1 & 0x3f));
    if ((uVar3 == 0) || (*(uint64_t *)0x18077e498 <= uVar3)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180226188;
        fcn.18027bb50(0x1804bf9b0, 0x1804bf8e8, 0x185);
    }
    uVar4 = uVar3 >> 3;
    uVar5 = (uint32_t)uVar3 & 7;
    if ((*(uint8_t *)(uVar4 + in_R8) & (uint8_t)(1LL << (int8_t)uVar5)) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802261b6;
        fcn.18027bb50(0x1804bfa10, 0x1804bf8e8, 0x186);
    }
    *(uint8_t *)(uVar4 + in_R8) = *(uint8_t *)(uVar4 + in_R8) | (uint8_t)(1LL << uVar5);
    return;
}

// ============================================================
// Function: FUN_1802261e0
// Address: 0x1802261e0
// Size: 246 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint32_t fcn.1802261e0(int64_t arg_28h, int64_t arg_30h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int32_t in_EDX;
    uint64_t uVar3;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802261f5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_EDX < 0) || (*(int64_t *)0x18077e478 <= in_EDX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180226227;
        fcn.18027bb50(0x1804bf928, 0x1804bf8e8, 0x16b);
    }
    uVar1 = (uint8_t)in_EDX;
    if ((in_RCX - *(int64_t *)0x18077e460 & (*(uint64_t *)0x18077e468 >> (uVar1 & 0x3f)) - 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180226264;
        fcn.18027bb50(0x1804bf960, 0x1804bf8e8, 0x16c);
    }
    uVar3 = (1LL << (uVar1 & 0x3f)) +
            (uint64_t)(in_RCX - *(int64_t *)0x18077e460) / (*(uint64_t *)0x18077e468 >> (uVar1 & 0x3f));
    if ((uVar3 == 0) || (*(uint64_t *)0x18077e498 <= uVar3)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802262b3;
        fcn.18027bb50(0x1804bf9b0, 0x1804bf8e8, 0x16e);
    }
    return (uint32_t)*(uint8_t *)((uVar3 >> 3) + in_R8) & (uint32_t)(1LL << ((uint8_t)uVar3 & 7));
}

// ============================================================
// Function: FUN_180226310
// Address: 0x180226310
// Size: 99 bytes
// ============================================================
void fcn.180226310(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180226320;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        iVar1 = *(int64_t *)(arg1 + 8);
        if (iVar1 != 0) {
            uVar2 = *(undefined8 *)(arg1 + 0x10);
            if ((*(uint8_t *)(arg1 + 0x18) & 1) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226358;
                func_0x000180224b90(iVar1, uVar2, 0x1804bfe08, 0x31);
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022634b;
                func_0x000180225130();
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022636d;
        fcn.180224990(arg1, 0x1804bfe08, 0x33);
    }
    return;
}

// ============================================================
// Function: FUN_180226380
// Address: 0x180226380
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180226380(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180226390;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = *in_RCX;
    if (uVar4 < in_RDX) {
        if (in_RCX[2] < in_RDX) {
            if (0x5ffffffc < in_RDX) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263df;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263f7;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226409;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
            if ((*(uint8_t *)(in_RCX + 3) & 1) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022645f;
                uVar4 = fcn.1802249c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226447;
                uVar4 = fcn.1802266e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            }
            if (uVar4 == 0) {
                return 0;
            }
            in_RCX[1] = uVar4;
            uVar1 = *in_RCX;
            uVar2 = *in_RCX;
            in_RCX[2] = (in_RDX + 3) / 3 << 2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226493;
            fcn.1804986e0(uVar4 + uVar2, 0, in_RDX - uVar1);
            *in_RCX = in_RDX;
            return in_RDX;
        }
        uVar1 = in_RCX[1];
        if (uVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263c0;
            fcn.1804986e0(uVar1 + uVar4, 0, in_RDX - uVar4);
        }
    }
    *in_RCX = in_RDX;
    return in_RDX;
}

// ============================================================
// Function: FUN_180226416
// Address: 0x180226416
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180226380(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180226390;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = *in_RCX;
    if (uVar4 < in_RDX) {
        if (in_RCX[2] < in_RDX) {
            if (0x5ffffffc < in_RDX) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263df;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263f7;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226409;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
            if ((*(uint8_t *)(in_RCX + 3) & 1) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022645f;
                uVar4 = fcn.1802249c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226447;
                uVar4 = fcn.1802266e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            }
            if (uVar4 == 0) {
                return 0;
            }
            in_RCX[1] = uVar4;
            uVar1 = *in_RCX;
            uVar2 = *in_RCX;
            in_RCX[2] = (in_RDX + 3) / 3 << 2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226493;
            fcn.1804986e0(uVar4 + uVar2, 0, in_RDX - uVar1);
            *in_RCX = in_RDX;
            return in_RDX;
        }
        uVar1 = in_RCX[1];
        if (uVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263c0;
            fcn.1804986e0(uVar1 + uVar4, 0, in_RDX - uVar4);
        }
    }
    *in_RCX = in_RDX;
    return in_RDX;
}

// ============================================================
// Function: FUN_18022647b
// Address: 0x18022647b
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180226380(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180226390;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = *in_RCX;
    if (uVar4 < in_RDX) {
        if (in_RCX[2] < in_RDX) {
            if (0x5ffffffc < in_RDX) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263df;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263f7;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226409;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
            if ((*(uint8_t *)(in_RCX + 3) & 1) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022645f;
                uVar4 = fcn.1802249c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226447;
                uVar4 = fcn.1802266e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            }
            if (uVar4 == 0) {
                return 0;
            }
            in_RCX[1] = uVar4;
            uVar1 = *in_RCX;
            uVar2 = *in_RCX;
            in_RCX[2] = (in_RDX + 3) / 3 << 2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226493;
            fcn.1804986e0(uVar4 + uVar2, 0, in_RDX - uVar1);
            *in_RCX = in_RDX;
            return in_RDX;
        }
        uVar1 = in_RCX[1];
        if (uVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802263c0;
            fcn.1804986e0(uVar1 + uVar4, 0, in_RDX - uVar4);
        }
    }
    *in_RCX = in_RDX;
    return in_RDX;
}

// ============================================================
// Function: FUN_1802264b0
// Address: 0x1802264b0
// Size: 191 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1802264b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802264c0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = *in_RCX;
    if (in_RDX <= uVar4) {
        uVar1 = in_RCX[1];
        if (uVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802264eb;
            fcn.1804986e0(uVar1 + in_RDX, 0, uVar4 - in_RDX);
        }
        *in_RCX = in_RDX;
        return in_RDX;
    }
    if (in_RDX <= in_RCX[2]) {
        uVar1 = in_RCX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226519;
        fcn.1804986e0(uVar1 + uVar4, 0, in_RDX - uVar4);
        *in_RCX = in_RDX;
        return in_RDX;
    }
    if (0x5ffffffc < in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226538;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226550;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226562;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    if ((*(uint8_t *)(in_RCX + 3) & 1) == 0) {
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0x84;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265c0;
        uVar4 = fcn.180224c10(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265a0;
        uVar4 = fcn.1802266e0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
    }
    if (uVar4 == 0) {
        return 0;
    }
    in_RCX[1] = uVar4;
    uVar1 = *in_RCX;
    uVar2 = *in_RCX;
    in_RCX[2] = (in_RDX + 3) / 3 << 2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265f4;
    fcn.1804986e0(uVar4 + uVar2, 0, in_RDX - uVar1);
    *in_RCX = in_RDX;
    return in_RDX;
}

// ============================================================
// Function: FUN_18022656f
// Address: 0x18022656f
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1802264b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802264c0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = *in_RCX;
    if (in_RDX <= uVar4) {
        uVar1 = in_RCX[1];
        if (uVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802264eb;
            fcn.1804986e0(uVar1 + in_RDX, 0, uVar4 - in_RDX);
        }
        *in_RCX = in_RDX;
        return in_RDX;
    }
    if (in_RDX <= in_RCX[2]) {
        uVar1 = in_RCX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226519;
        fcn.1804986e0(uVar1 + uVar4, 0, in_RDX - uVar4);
        *in_RCX = in_RDX;
        return in_RDX;
    }
    if (0x5ffffffc < in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226538;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226550;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226562;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    if ((*(uint8_t *)(in_RCX + 3) & 1) == 0) {
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0x84;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265c0;
        uVar4 = fcn.180224c10(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265a0;
        uVar4 = fcn.1802266e0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
    }
    if (uVar4 == 0) {
        return 0;
    }
    in_RCX[1] = uVar4;
    uVar1 = *in_RCX;
    uVar2 = *in_RCX;
    in_RCX[2] = (in_RDX + 3) / 3 << 2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265f4;
    fcn.1804986e0(uVar4 + uVar2, 0, in_RDX - uVar1);
    *in_RCX = in_RDX;
    return in_RDX;
}

// ============================================================
// Function: FUN_1802265dc
// Address: 0x1802265dc
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1802264b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_78h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802264c0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = *in_RCX;
    if (in_RDX <= uVar4) {
        uVar1 = in_RCX[1];
        if (uVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802264eb;
            fcn.1804986e0(uVar1 + in_RDX, 0, uVar4 - in_RDX);
        }
        *in_RCX = in_RDX;
        return in_RDX;
    }
    if (in_RDX <= in_RCX[2]) {
        uVar1 = in_RCX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226519;
        fcn.1804986e0(uVar1 + uVar4, 0, in_RDX - uVar4);
        *in_RCX = in_RDX;
        return in_RDX;
    }
    if (0x5ffffffc < in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226538;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226550;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226562;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    if ((*(uint8_t *)(in_RCX + 3) & 1) == 0) {
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0x84;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265c0;
        uVar4 = fcn.180224c10(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265a0;
        uVar4 = fcn.1802266e0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
    }
    if (uVar4 == 0) {
        return 0;
    }
    in_RCX[1] = uVar4;
    uVar1 = *in_RCX;
    uVar2 = *in_RCX;
    in_RCX[2] = (in_RDX + 3) / 3 << 2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802265f4;
    fcn.1804986e0(uVar4 + uVar2, 0, in_RDX - uVar1);
    *in_RCX = in_RDX;
    return in_RDX;
}

// ============================================================
// Function: FUN_180226610
// Address: 0x180226610
// Size: 40 bytes
// ============================================================
int64_t fcn.180226610(int64_t arg_30h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0x20;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180224d70;
    iVar1 = fcn.18045a350(0x20, 0x1804bfe08, 0x23);
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224d7b;
    iVar2 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar1 + iVar3), *(int64_t *)(&stack0x00000048 + iVar1 + iVar3)
                          , *(int64_t *)(&stack0x00000060 + iVar1 + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar1 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224d90;
        fcn.1804986e0(iVar2, 0, uVar4);
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180226640
// Address: 0x180226640
// Size: 57 bytes
// ============================================================
void fcn.180226640(undefined4 param_1)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022664c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180226665;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 0x18) = param_1;
    return;
}

// ============================================================
// Function: FUN_1802266e0
// Address: 0x1802266e0
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1802266e0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802266f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022670e;
    iVar4 = fcn.1802252b0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
    iVar1 = in_RCX[1];
    if ((iVar1 != 0) && (iVar4 != 0)) {
        uVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022672a;
        fcn.180498030(iVar4, iVar1, uVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226743;
        fcn.180225130(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        in_RCX[1] = 0;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180226760
// Address: 0x180226760
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.180226760(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180226775;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226789;
    (*(code *)0x8000000000000070)(0);
    iVar1 = *(int32_t *)(in_RCX + 0x38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022679c;
    iVar1 = (*(code *)0x8000000000000013)((int64_t)iVar1, in_RDX, in_R8 & 0xffffffff, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802267ab;
    fcn.180219ce0(in_RCX, 0xf);
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802267b6;
        iVar2 = fcn.180226c30(iVar1);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802267c7;
            fcn.18021b250(in_RCX, 10);
        }
    }
    return iVar1;
}

// ============================================================
// Function: FUN_1802267e0
// Address: 0x1802267e0
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.1802267e0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802267f5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RDX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022680e;
    (*(code *)0x8000000000000070)(0);
    iVar1 = *(int32_t *)(in_RCX + 0x38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226821;
    iVar1 = (*(code *)0x8000000000000010)((int64_t)iVar1, in_RDX, in_R8 & 0xffffffff, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226830;
    fcn.180219ce0(in_RCX, 0xf);
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022683b;
        iVar2 = fcn.180226c30(iVar1);
        if (iVar2 == 0) {
            if (iVar1 != 0) {
                return iVar1;
            }
            *(uint32_t *)(in_RCX + 0x30) = *(uint32_t *)(in_RCX + 0x30) | 0x800;
            return iVar1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022684c;
        fcn.18021b250(in_RCX, 9);
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180226890
// Address: 0x180226890
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.180226890(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802268a5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802268b6;
    uVar4 = fcn.180498cd0(in_RDX);
    if (0x7fffffff < uVar4) {
        return -1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802268de;
    (*(code *)0x8000000000000070)(0);
    iVar1 = *(int32_t *)(in_RCX + 0x38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802268f1;
    iVar1 = (*(code *)0x8000000000000013)((int64_t)iVar1, in_RDX, uVar4 & 0xffffffff, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180226900;
    fcn.180219ce0(in_RCX, 0xf);
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022690b;
        iVar2 = fcn.180226c30(iVar1);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022691c;
            fcn.18021b250(in_RCX, 10);
        }
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180226930
// Address: 0x180226930
// Size: 486 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

uint32_t fcn.180226930(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined4 uVar1;
    undefined (*pauVar2) [16];
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined4 in_EDX;
    int32_t in_R8D;
    undefined (**in_R9) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180226950;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    pauVar2 = *(undefined (**) [16])(in_RCX + 0x40);
    uVar3 = 1;
    // switch table (122 cases) at 0x180226a74
    switch(in_EDX) {
    case 2:
        uVar3 = *(uint32_t *)(in_RCX + 0x30) >> 0xb & 1;
        break;
    default:
        goto code_r0x000180226a52;
    case 8:
        uVar3 = *(uint32_t *)(in_RCX + 0x2c);
        break;
    case 9:
        *(int32_t *)(in_RCX + 0x2c) = in_R8D;
        break;
    case 0xb:
    case 0xc:
        break;
    case 0x5b:
    case 0x5c:
        if (*(int32_t *)(in_RCX + 0x28) != 0) {
            *(undefined4 *)in_R9 = 1;
            *(undefined4 *)(in_R9 + 1) = *(undefined4 *)(in_RCX + 0x38);
            return 1;
        }
        goto code_r0x000180226a52;
    case 100:
        if ((in_R9 != (undefined (**) [16])0x0) && (in_R8D == 2)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180226a38;
            uVar5 = func_0x00018000ce10(in_R9);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180226a43;
            uVar3 = func_0x00018026bf20(pauVar2, uVar5);
            if (uVar3 == 0) {
                return 0;
            }
            *(undefined4 *)(pauVar2[1] + 0xc) = 1;
            return uVar3;
        }
        goto code_r0x000180226a52;
    case 0x68:
        if (*(int32_t *)(in_RCX + 0x2c) != 0) {
            if (*(int32_t *)(in_RCX + 0x28) != 0) {
                uVar1 = *(undefined4 *)(in_RCX + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802269a3;
                func_0x000180274b10(uVar1);
            }
            *(undefined4 *)(in_RCX + 0x30) = 0;
        }
        *(undefined4 *)(in_RCX + 0x38) = *(undefined4 *)in_R9;
        *(int32_t *)(in_RCX + 0x2c) = in_R8D;
        *(undefined4 *)(in_RCX + 0x28) = 1;
        *(undefined8 *)(pauVar2[1] + 8) = 0;
        *pauVar2 = ZEXT816(0);
        *(undefined8 *)pauVar2[1] = 0;
        break;
    case 0x69:
        if (*(int32_t *)(in_RCX + 0x28) == 0) {
            uVar3 = 0xffffffff;
        } else {
            if (in_R9 != (undefined (**) [16])0x0) {
                *(undefined4 *)in_R9 = *(undefined4 *)(in_RCX + 0x38);
            }
            uVar3 = *(uint32_t *)(in_RCX + 0x38);
        }
        break;
    case 0x7b:
        if ((in_R9 != (undefined (**) [16])0x0) && (in_R8D == 2)) {
            *in_R9 = pauVar2;
            return 1;
        }
code_r0x000180226a52:
        uVar3 = 0;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180226b20
// Address: 0x180226b20
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180226b20(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180226b30;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)(in_RCX + 0x28) = 0;
    *(undefined4 *)(in_RCX + 0x38) = 0;
    *(undefined4 *)(in_RCX + 0x30) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180226b55;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1));
    *(int64_t *)(in_RCX + 0x40) = iVar1;
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_180226b70
// Address: 0x180226b70
// Size: 106 bytes
// ============================================================
undefined8 fcn.180226b70(int64_t param_1)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x180226b7c;
    iVar3 = fcn.18045a350();
    if (param_1 == 0) {
        return 0;
    }
    if (*(int32_t *)(param_1 + 0x2c) != 0) {
        if (*(int32_t *)(param_1 + 0x28) != 0) {
            uVar1 = *(undefined4 *)(param_1 + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x180226ba3;
            fcn.180274b10(uVar1);
        }
        *(undefined4 *)(param_1 + 0x28) = 0;
        *(undefined4 *)(param_1 + 0x30) = 0;
    }
    uVar2 = *(undefined8 *)(param_1 + 0x40);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x180226bc7;
    fcn.180224990(uVar2, 0x1804bfec0, 0x6f);
    *(undefined8 *)(param_1 + 0x40) = 0;
    return 1;
}

// ============================================================
// Function: FUN_180226c30
// Address: 0x180226c30
// Size: 100 bytes
// ============================================================
undefined8 fcn.180226c30(int32_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    bool bVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x180226c3a;
    iVar2 = fcn.18045a350();
    if (param_1 + 1U < 2) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x180226c4b;
        iVar1 = (*(code *)0x800000000000006f)();
        if (iVar1 < 0x7f) {
            if ((iVar1 - 0x67U < 0x18) && ((0x800201U >> (iVar1 - 0x67U & 0x1f) & 1) != 0)) {
                return 1;
            }
            if (iVar1 == 4) {
                return 1;
            }
            bVar3 = iVar1 == 0xb;
        } else {
            if (iVar1 == 0x86) {
                return 1;
            }
            if (iVar1 == 0x8c) {
                return 1;
            }
            bVar3 = iVar1 == 0x2733;
        }
        if (bVar3) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180226ca0
// Address: 0x180226ca0
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180226ca0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int32_t iVar12;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180226cb8;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    uVar11 = in_R8 & 0xffffffff;
    if ((((in_RDX == 0) || ((int32_t)in_R8 < 1)) || (iVar3 = *(int64_t *)(in_RCX + 0x40), iVar3 == 0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d07;
    fcn.180219ce0();
    iVar8 = *(int32_t *)(iVar3 + 4);
    do {
        do {
            iVar6 = *(int32_t *)(iVar3 + 0x20);
            iVar2 = *(int32_t *)(iVar3 + 0x24);
            iVar8 = (iVar8 - iVar6) - iVar2;
            iVar9 = (int32_t)uVar11;
            if (iVar9 <= iVar8) {
                iVar4 = *(int64_t *)(iVar3 + 0x18);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226df7;
                fcn.180498030((iVar6 + iVar2) + iVar4, in_RDX, (int64_t)iVar9);
                *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar9;
                return iVar12 + iVar9;
            }
            if (iVar6 != 0) {
                if (0 < iVar8) {
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d3f;
                    fcn.180498030((iVar6 + iVar2) + iVar4, in_RDX, (int64_t)iVar8);
                    in_RDX = in_RDX + iVar8;
                    uVar11 = (uint64_t)(uint32_t)(iVar9 - iVar8);
                    iVar12 = iVar12 + iVar8;
                    *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar8;
                    iVar6 = *(int32_t *)(iVar3 + 0x20);
                }
                do {
                    iVar8 = *(int32_t *)(iVar3 + 0x24);
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    uVar5 = *(undefined8 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d64;
                    iVar8 = func_0x00018021b2c0(uVar5, iVar8 + iVar4, iVar6);
                    if (iVar8 < 1) goto code_r0x000180226dac;
                    *(int32_t *)(iVar3 + 0x24) = *(int32_t *)(iVar3 + 0x24) + iVar8;
                    piVar1 = (int32_t *)(iVar3 + 0x20);
                    *piVar1 = *piVar1 - iVar8;
                    iVar6 = *(int32_t *)(iVar3 + 0x20);
                } while (*piVar1 != 0);
            }
            iVar8 = *(int32_t *)(iVar3 + 4);
            *(undefined4 *)(iVar3 + 0x24) = 0;
        } while ((int32_t)uVar11 < iVar8);
        do {
            uVar5 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d8f;
            iVar8 = func_0x00018021b2c0(uVar5, in_RDX, uVar11);
            if (iVar8 < 1) {
code_r0x000180226dac:
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226db4;
                func_0x000180219cf0(in_RCX);
                if (-1 < iVar8) {
                    return iVar12;
                }
                if (iVar12 < 1) {
                    return iVar8;
                }
                return iVar12;
            }
            iVar12 = iVar12 + iVar8;
            in_RDX = in_RDX + iVar8;
            uVar10 = (int32_t)uVar11 - iVar8;
            uVar11 = (uint64_t)uVar10;
            if (uVar10 == 0) {
                return iVar12;
            }
            iVar8 = *(int32_t *)(iVar3 + 4);
        } while (iVar8 <= (int32_t)uVar10);
    } while( true );
}

// ============================================================
// Function: FUN_180226cf3
// Address: 0x180226cf3
// Size: 229 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180226ca0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int32_t iVar12;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180226cb8;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    uVar11 = in_R8 & 0xffffffff;
    if ((((in_RDX == 0) || ((int32_t)in_R8 < 1)) || (iVar3 = *(int64_t *)(in_RCX + 0x40), iVar3 == 0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d07;
    fcn.180219ce0();
    iVar8 = *(int32_t *)(iVar3 + 4);
    do {
        do {
            iVar6 = *(int32_t *)(iVar3 + 0x20);
            iVar2 = *(int32_t *)(iVar3 + 0x24);
            iVar8 = (iVar8 - iVar6) - iVar2;
            iVar9 = (int32_t)uVar11;
            if (iVar9 <= iVar8) {
                iVar4 = *(int64_t *)(iVar3 + 0x18);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226df7;
                fcn.180498030((iVar6 + iVar2) + iVar4, in_RDX, (int64_t)iVar9);
                *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar9;
                return iVar12 + iVar9;
            }
            if (iVar6 != 0) {
                if (0 < iVar8) {
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d3f;
                    fcn.180498030((iVar6 + iVar2) + iVar4, in_RDX, (int64_t)iVar8);
                    in_RDX = in_RDX + iVar8;
                    uVar11 = (uint64_t)(uint32_t)(iVar9 - iVar8);
                    iVar12 = iVar12 + iVar8;
                    *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar8;
                    iVar6 = *(int32_t *)(iVar3 + 0x20);
                }
                do {
                    iVar8 = *(int32_t *)(iVar3 + 0x24);
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    uVar5 = *(undefined8 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d64;
                    iVar8 = func_0x00018021b2c0(uVar5, iVar8 + iVar4, iVar6);
                    if (iVar8 < 1) goto code_r0x000180226dac;
                    *(int32_t *)(iVar3 + 0x24) = *(int32_t *)(iVar3 + 0x24) + iVar8;
                    piVar1 = (int32_t *)(iVar3 + 0x20);
                    *piVar1 = *piVar1 - iVar8;
                    iVar6 = *(int32_t *)(iVar3 + 0x20);
                } while (*piVar1 != 0);
            }
            iVar8 = *(int32_t *)(iVar3 + 4);
            *(undefined4 *)(iVar3 + 0x24) = 0;
        } while ((int32_t)uVar11 < iVar8);
        do {
            uVar5 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d8f;
            iVar8 = func_0x00018021b2c0(uVar5, in_RDX, uVar11);
            if (iVar8 < 1) {
code_r0x000180226dac:
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226db4;
                func_0x000180219cf0(in_RCX);
                if (-1 < iVar8) {
                    return iVar12;
                }
                if (iVar12 < 1) {
                    return iVar8;
                }
                return iVar12;
            }
            iVar12 = iVar12 + iVar8;
            in_RDX = in_RDX + iVar8;
            uVar10 = (int32_t)uVar11 - iVar8;
            uVar11 = (uint64_t)uVar10;
            if (uVar10 == 0) {
                return iVar12;
            }
            iVar8 = *(int32_t *)(iVar3 + 4);
        } while (iVar8 <= (int32_t)uVar10);
    } while( true );
}

// ============================================================
// Function: FUN_180226dd8
// Address: 0x180226dd8
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180226ca0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int32_t iVar12;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180226cb8;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    uVar11 = in_R8 & 0xffffffff;
    if ((((in_RDX == 0) || ((int32_t)in_R8 < 1)) || (iVar3 = *(int64_t *)(in_RCX + 0x40), iVar3 == 0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d07;
    fcn.180219ce0();
    iVar8 = *(int32_t *)(iVar3 + 4);
    do {
        do {
            iVar6 = *(int32_t *)(iVar3 + 0x20);
            iVar2 = *(int32_t *)(iVar3 + 0x24);
            iVar8 = (iVar8 - iVar6) - iVar2;
            iVar9 = (int32_t)uVar11;
            if (iVar9 <= iVar8) {
                iVar4 = *(int64_t *)(iVar3 + 0x18);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226df7;
                fcn.180498030((iVar6 + iVar2) + iVar4, in_RDX, (int64_t)iVar9);
                *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar9;
                return iVar12 + iVar9;
            }
            if (iVar6 != 0) {
                if (0 < iVar8) {
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d3f;
                    fcn.180498030((iVar6 + iVar2) + iVar4, in_RDX, (int64_t)iVar8);
                    in_RDX = in_RDX + iVar8;
                    uVar11 = (uint64_t)(uint32_t)(iVar9 - iVar8);
                    iVar12 = iVar12 + iVar8;
                    *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar8;
                    iVar6 = *(int32_t *)(iVar3 + 0x20);
                }
                do {
                    iVar8 = *(int32_t *)(iVar3 + 0x24);
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    uVar5 = *(undefined8 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d64;
                    iVar8 = func_0x00018021b2c0(uVar5, iVar8 + iVar4, iVar6);
                    if (iVar8 < 1) goto code_r0x000180226dac;
                    *(int32_t *)(iVar3 + 0x24) = *(int32_t *)(iVar3 + 0x24) + iVar8;
                    piVar1 = (int32_t *)(iVar3 + 0x20);
                    *piVar1 = *piVar1 - iVar8;
                    iVar6 = *(int32_t *)(iVar3 + 0x20);
                } while (*piVar1 != 0);
            }
            iVar8 = *(int32_t *)(iVar3 + 4);
            *(undefined4 *)(iVar3 + 0x24) = 0;
        } while ((int32_t)uVar11 < iVar8);
        do {
            uVar5 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d8f;
            iVar8 = func_0x00018021b2c0(uVar5, in_RDX, uVar11);
            if (iVar8 < 1) {
code_r0x000180226dac:
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226db4;
                func_0x000180219cf0(in_RCX);
                if (-1 < iVar8) {
                    return iVar12;
                }
                if (iVar12 < 1) {
                    return iVar8;
                }
                return iVar12;
            }
            iVar12 = iVar12 + iVar8;
            in_RDX = in_RDX + iVar8;
            uVar10 = (int32_t)uVar11 - iVar8;
            uVar11 = (uint64_t)uVar10;
            if (uVar10 == 0) {
                return iVar12;
            }
            iVar8 = *(int32_t *)(iVar3 + 4);
        } while (iVar8 <= (int32_t)uVar10);
    } while( true );
}

// ============================================================
// Function: FUN_180226e00
// Address: 0x180226e00
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180226ca0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int32_t iVar12;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180226cb8;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    uVar11 = in_R8 & 0xffffffff;
    if ((((in_RDX == 0) || ((int32_t)in_R8 < 1)) || (iVar3 = *(int64_t *)(in_RCX + 0x40), iVar3 == 0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d07;
    fcn.180219ce0();
    iVar8 = *(int32_t *)(iVar3 + 4);
    do {
        do {
            iVar6 = *(int32_t *)(iVar3 + 0x20);
            iVar2 = *(int32_t *)(iVar3 + 0x24);
            iVar8 = (iVar8 - iVar6) - iVar2;
            iVar9 = (int32_t)uVar11;
            if (iVar9 <= iVar8) {
                iVar4 = *(int64_t *)(iVar3 + 0x18);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226df7;
                fcn.180498030((iVar6 + iVar2) + iVar4, in_RDX, (int64_t)iVar9);
                *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar9;
                return iVar12 + iVar9;
            }
            if (iVar6 != 0) {
                if (0 < iVar8) {
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d3f;
                    fcn.180498030((iVar6 + iVar2) + iVar4, in_RDX, (int64_t)iVar8);
                    in_RDX = in_RDX + iVar8;
                    uVar11 = (uint64_t)(uint32_t)(iVar9 - iVar8);
                    iVar12 = iVar12 + iVar8;
                    *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar8;
                    iVar6 = *(int32_t *)(iVar3 + 0x20);
                }
                do {
                    iVar8 = *(int32_t *)(iVar3 + 0x24);
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    uVar5 = *(undefined8 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d64;
                    iVar8 = func_0x00018021b2c0(uVar5, iVar8 + iVar4, iVar6);
                    if (iVar8 < 1) goto code_r0x000180226dac;
                    *(int32_t *)(iVar3 + 0x24) = *(int32_t *)(iVar3 + 0x24) + iVar8;
                    piVar1 = (int32_t *)(iVar3 + 0x20);
                    *piVar1 = *piVar1 - iVar8;
                    iVar6 = *(int32_t *)(iVar3 + 0x20);
                } while (*piVar1 != 0);
            }
            iVar8 = *(int32_t *)(iVar3 + 4);
            *(undefined4 *)(iVar3 + 0x24) = 0;
        } while ((int32_t)uVar11 < iVar8);
        do {
            uVar5 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226d8f;
            iVar8 = func_0x00018021b2c0(uVar5, in_RDX, uVar11);
            if (iVar8 < 1) {
code_r0x000180226dac:
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180226db4;
                func_0x000180219cf0(in_RCX);
                if (-1 < iVar8) {
                    return iVar12;
                }
                if (iVar12 < 1) {
                    return iVar8;
                }
                return iVar12;
            }
            iVar12 = iVar12 + iVar8;
            in_RDX = in_RDX + iVar8;
            uVar10 = (int32_t)uVar11 - iVar8;
            uVar11 = (uint64_t)uVar10;
            if (uVar10 == 0) {
                return iVar12;
            }
            iVar8 = *(int32_t *)(iVar3 + 4);
        } while (iVar8 <= (int32_t)uVar10);
    } while( true );
}

// ============================================================
// Function: FUN_180226e20
// Address: 0x180226e20
// Size: 61 bytes
// ============================================================
int32_t fcn.180226e20(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int32_t iVar10;
    undefined8 unaff_R14;
    undefined8 uStack_28;
    
    uStack_28 = 0x180226e30;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    in_R8 = in_R8 & 0xffffffff;
    if (((in_RDX == 0) || (piVar1 = *(int32_t **)(in_RCX + 0x40), piVar1 == (int32_t *)0x0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R13;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226e77;
    fcn.180219ce0();
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    while( true ) {
        iVar5 = piVar1[4];
        if (iVar5 != 0) {
            iVar6 = piVar1[5];
            iVar9 = (int32_t)in_R8;
            iVar10 = iVar9;
            if (iVar5 <= iVar9) {
                iVar10 = iVar5;
            }
            iVar2 = *(int64_t *)(piVar1 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226ea7;
            fcn.180498030(in_RDX, iVar6 + iVar2, (int64_t)iVar10);
            piVar1[5] = piVar1[5] + iVar10;
            iVar8 = iVar8 + iVar10;
            piVar1[4] = piVar1[4] - iVar10;
            if (iVar9 == iVar10) {
                return iVar8;
            }
            in_R8 = (uint64_t)(uint32_t)(iVar9 - iVar10);
            in_RDX = in_RDX + iVar10;
        }
        if (*piVar1 < (int32_t)in_R8) break;
        uVar3 = *(undefined8 *)(piVar1 + 2);
        uVar4 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226ed6;
        iVar5 = func_0x00018021ac80(uVar4, uVar3);
        if (iVar5 < 1) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226eee;
            func_0x000180219cf0(in_RCX);
            iVar6 = iVar8;
            if ((iVar5 < 0) && (iVar6 = iVar5, 0 < iVar8)) {
                iVar6 = iVar8;
            }
            return iVar6;
        }
        piVar1[5] = 0;
        piVar1[4] = iVar5;
    }
    while( true ) {
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226f2f;
        iVar5 = func_0x00018021ac80(uVar3, in_RDX, in_R8);
        if (iVar5 < 1) break;
        iVar8 = iVar8 + iVar5;
        if ((int32_t)in_R8 == iVar5) {
            return iVar8;
        }
        in_RDX = in_RDX + iVar5;
        in_R8 = (uint64_t)(uint32_t)((int32_t)in_R8 - iVar5);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226f4b;
    func_0x000180219cf0(in_RCX);
    if (-1 < iVar5) {
        return iVar8;
    }
    if (iVar8 < 1) {
        return iVar5;
    }
    return iVar8;
}

// ============================================================
// Function: FUN_180226e5d
// Address: 0x180226e5d
// Size: 195 bytes
// ============================================================
int32_t fcn.180226e20(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int32_t iVar10;
    undefined8 unaff_R14;
    undefined8 uStack_28;
    
    uStack_28 = 0x180226e30;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    in_R8 = in_R8 & 0xffffffff;
    if (((in_RDX == 0) || (piVar1 = *(int32_t **)(in_RCX + 0x40), piVar1 == (int32_t *)0x0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R13;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226e77;
    fcn.180219ce0();
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    while( true ) {
        iVar5 = piVar1[4];
        if (iVar5 != 0) {
            iVar6 = piVar1[5];
            iVar9 = (int32_t)in_R8;
            iVar10 = iVar9;
            if (iVar5 <= iVar9) {
                iVar10 = iVar5;
            }
            iVar2 = *(int64_t *)(piVar1 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226ea7;
            fcn.180498030(in_RDX, iVar6 + iVar2, (int64_t)iVar10);
            piVar1[5] = piVar1[5] + iVar10;
            iVar8 = iVar8 + iVar10;
            piVar1[4] = piVar1[4] - iVar10;
            if (iVar9 == iVar10) {
                return iVar8;
            }
            in_R8 = (uint64_t)(uint32_t)(iVar9 - iVar10);
            in_RDX = in_RDX + iVar10;
        }
        if (*piVar1 < (int32_t)in_R8) break;
        uVar3 = *(undefined8 *)(piVar1 + 2);
        uVar4 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226ed6;
        iVar5 = func_0x00018021ac80(uVar4, uVar3);
        if (iVar5 < 1) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226eee;
            func_0x000180219cf0(in_RCX);
            iVar6 = iVar8;
            if ((iVar5 < 0) && (iVar6 = iVar5, 0 < iVar8)) {
                iVar6 = iVar8;
            }
            return iVar6;
        }
        piVar1[5] = 0;
        piVar1[4] = iVar5;
    }
    while( true ) {
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226f2f;
        iVar5 = func_0x00018021ac80(uVar3, in_RDX, in_R8);
        if (iVar5 < 1) break;
        iVar8 = iVar8 + iVar5;
        if ((int32_t)in_R8 == iVar5) {
            return iVar8;
        }
        in_RDX = in_RDX + iVar5;
        in_R8 = (uint64_t)(uint32_t)((int32_t)in_R8 - iVar5);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226f4b;
    func_0x000180219cf0(in_RCX);
    if (-1 < iVar5) {
        return iVar8;
    }
    if (iVar8 < 1) {
        return iVar5;
    }
    return iVar8;
}

// ============================================================
// Function: FUN_180226f20
// Address: 0x180226f20
// Size: 60 bytes
// ============================================================
int32_t fcn.180226e20(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int32_t iVar10;
    undefined8 unaff_R14;
    undefined8 uStack_28;
    
    uStack_28 = 0x180226e30;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    in_R8 = in_R8 & 0xffffffff;
    if (((in_RDX == 0) || (piVar1 = *(int32_t **)(in_RCX + 0x40), piVar1 == (int32_t *)0x0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R13;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226e77;
    fcn.180219ce0();
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    while( true ) {
        iVar5 = piVar1[4];
        if (iVar5 != 0) {
            iVar6 = piVar1[5];
            iVar9 = (int32_t)in_R8;
            iVar10 = iVar9;
            if (iVar5 <= iVar9) {
                iVar10 = iVar5;
            }
            iVar2 = *(int64_t *)(piVar1 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226ea7;
            fcn.180498030(in_RDX, iVar6 + iVar2, (int64_t)iVar10);
            piVar1[5] = piVar1[5] + iVar10;
            iVar8 = iVar8 + iVar10;
            piVar1[4] = piVar1[4] - iVar10;
            if (iVar9 == iVar10) {
                return iVar8;
            }
            in_R8 = (uint64_t)(uint32_t)(iVar9 - iVar10);
            in_RDX = in_RDX + iVar10;
        }
        if (*piVar1 < (int32_t)in_R8) break;
        uVar3 = *(undefined8 *)(piVar1 + 2);
        uVar4 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226ed6;
        iVar5 = func_0x00018021ac80(uVar4, uVar3);
        if (iVar5 < 1) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226eee;
            func_0x000180219cf0(in_RCX);
            iVar6 = iVar8;
            if ((iVar5 < 0) && (iVar6 = iVar5, 0 < iVar8)) {
                iVar6 = iVar8;
            }
            return iVar6;
        }
        piVar1[5] = 0;
        piVar1[4] = iVar5;
    }
    while( true ) {
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226f2f;
        iVar5 = func_0x00018021ac80(uVar3, in_RDX, in_R8);
        if (iVar5 < 1) break;
        iVar8 = iVar8 + iVar5;
        if ((int32_t)in_R8 == iVar5) {
            return iVar8;
        }
        in_RDX = in_RDX + iVar5;
        in_R8 = (uint64_t)(uint32_t)((int32_t)in_R8 - iVar5);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226f4b;
    func_0x000180219cf0(in_RCX);
    if (-1 < iVar5) {
        return iVar8;
    }
    if (iVar8 < 1) {
        return iVar5;
    }
    return iVar8;
}

// ============================================================
// Function: FUN_180226f5c
// Address: 0x180226f5c
// Size: 12 bytes
// ============================================================
int32_t fcn.180226e20(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    int32_t iVar9;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int32_t iVar10;
    undefined8 unaff_R14;
    undefined8 uStack_28;
    
    uStack_28 = 0x180226e30;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    in_R8 = in_R8 & 0xffffffff;
    if (((in_RDX == 0) || (piVar1 = *(int32_t **)(in_RCX + 0x40), piVar1 == (int32_t *)0x0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R13;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226e77;
    fcn.180219ce0();
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    while( true ) {
        iVar5 = piVar1[4];
        if (iVar5 != 0) {
            iVar6 = piVar1[5];
            iVar9 = (int32_t)in_R8;
            iVar10 = iVar9;
            if (iVar5 <= iVar9) {
                iVar10 = iVar5;
            }
            iVar2 = *(int64_t *)(piVar1 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226ea7;
            fcn.180498030(in_RDX, iVar6 + iVar2, (int64_t)iVar10);
            piVar1[5] = piVar1[5] + iVar10;
            iVar8 = iVar8 + iVar10;
            piVar1[4] = piVar1[4] - iVar10;
            if (iVar9 == iVar10) {
                return iVar8;
            }
            in_R8 = (uint64_t)(uint32_t)(iVar9 - iVar10);
            in_RDX = in_RDX + iVar10;
        }
        if (*piVar1 < (int32_t)in_R8) break;
        uVar3 = *(undefined8 *)(piVar1 + 2);
        uVar4 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226ed6;
        iVar5 = func_0x00018021ac80(uVar4, uVar3);
        if (iVar5 < 1) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226eee;
            func_0x000180219cf0(in_RCX);
            iVar6 = iVar8;
            if ((iVar5 < 0) && (iVar6 = iVar5, 0 < iVar8)) {
                iVar6 = iVar8;
            }
            return iVar6;
        }
        piVar1[5] = 0;
        piVar1[4] = iVar5;
    }
    while( true ) {
        uVar3 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226f2f;
        iVar5 = func_0x00018021ac80(uVar3, in_RDX, in_R8);
        if (iVar5 < 1) break;
        iVar8 = iVar8 + iVar5;
        if ((int32_t)in_R8 == iVar5) {
            return iVar8;
        }
        in_RDX = in_RDX + iVar5;
        in_R8 = (uint64_t)(uint32_t)((int32_t)in_R8 - iVar5);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180226f4b;
    func_0x000180219cf0(in_RCX);
    if (-1 < iVar5) {
        return iVar8;
    }
    if (iVar8 < 1) {
        return iVar5;
    }
    return iVar8;
}

// ============================================================
// Function: FUN_180226f70
// Address: 0x180226f70
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.180226f70(int64_t arg_28h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar9;
    undefined8 unaff_RBP;
    int32_t iVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    undefined8 unaff_RSI;
    undefined8 uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x180226f80;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180226f91;
    uVar8 = fcn.180498cd0(in_RDX);
    if (0x7fffffff < uVar8) {
        return -1;
    }
    uVar8 = uVar8 & 0xffffffff;
    uVar13 = *(undefined8 *)((int64_t)auStackX_10 + iVar7 + 8);
    *(undefined8 *)(&stack0x00000038 + iVar7) = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + -8) = unaff_R13;
    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + -0x10) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180226cb8;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar14 = 0;
    uVar12 = uVar8 & 0xffffffff;
    if ((((in_RDX == 0) || ((int32_t)uVar8 < 1)) || (iVar3 = *(int64_t *)(in_RCX + 0x40), iVar3 == 0)) ||
       (*(int64_t *)(in_RCX + 0x48) == 0)) {
        return 0;
    }
    *(undefined8 *)(&stack0x00000048 + iVar6 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000050 + iVar6 + iVar7) = uVar13;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar7) = 0x180226d07;
    fcn.180219ce0();
    iVar9 = *(int32_t *)(iVar3 + 4);
    do {
        do {
            iVar5 = *(int32_t *)(iVar3 + 0x20);
            iVar2 = *(int32_t *)(iVar3 + 0x24);
            iVar9 = (iVar9 - iVar5) - iVar2;
            iVar10 = (int32_t)uVar12;
            if (iVar10 <= iVar9) {
                iVar4 = *(int64_t *)(iVar3 + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar7) = 0x180226df7;
                fcn.180498030((iVar5 + iVar2) + iVar4, in_RDX, (int64_t)iVar10);
                *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar10;
                return iVar14 + iVar10;
            }
            if (iVar5 != 0) {
                if (0 < iVar9) {
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar7) = 0x180226d3f;
                    fcn.180498030((iVar5 + iVar2) + iVar4, in_RDX, (int64_t)iVar9);
                    in_RDX = in_RDX + iVar9;
                    uVar12 = (uint64_t)(uint32_t)(iVar10 - iVar9);
                    iVar14 = iVar14 + iVar9;
                    *(int32_t *)(iVar3 + 0x20) = *(int32_t *)(iVar3 + 0x20) + iVar9;
                    iVar5 = *(int32_t *)(iVar3 + 0x20);
                }
                do {
                    iVar9 = *(int32_t *)(iVar3 + 0x24);
                    iVar4 = *(int64_t *)(iVar3 + 0x18);
                    uVar13 = *(undefined8 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar7) = 0x180226d64;
                    iVar9 = func_0x00018021b2c0(uVar13, iVar9 + iVar4, iVar5);
                    if (iVar9 < 1) goto code_r0x000180226dac;
                    *(int32_t *)(iVar3 + 0x24) = *(int32_t *)(iVar3 + 0x24) + iVar9;
                    piVar1 = (int32_t *)(iVar3 + 0x20);
                    *piVar1 = *piVar1 - iVar9;
                    iVar5 = *(int32_t *)(iVar3 + 0x20);
                } while (*piVar1 != 0);
            }
            iVar9 = *(int32_t *)(iVar3 + 4);
            *(undefined4 *)(iVar3 + 0x24) = 0;
        } while ((int32_t)uVar12 < iVar9);
        do {
            uVar13 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar7) = 0x180226d8f;
            iVar9 = func_0x00018021b2c0(uVar13, in_RDX, uVar12);
            if (iVar9 < 1) {
code_r0x000180226dac:
                *(undefined8 *)((int64_t)&uStack_10 + iVar6 + iVar7) = 0x180226db4;
                func_0x000180219cf0(in_RCX);
                if (-1 < iVar9) {
                    return iVar14;
                }
                if (iVar14 < 1) {
                    return iVar9;
                }
                return iVar14;
            }
            iVar14 = iVar14 + iVar9;
            in_RDX = in_RDX + iVar9;
            uVar11 = (int32_t)uVar12 - iVar9;
            uVar12 = (uint64_t)uVar11;
            if (uVar11 == 0) {
                return iVar14;
            }
            iVar9 = *(int32_t *)(iVar3 + 4);
        } while (iVar9 <= (int32_t)uVar11);
    } while( true );
}

// ============================================================
// Function: FUN_180226fd0
// Address: 0x180226fd0
// Size: 273 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180226fd0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t in_RCX;
    char *in_RDX;
    char *pcVar8;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    char *pcVar9;
    int32_t iVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180226fed;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar3 = *(undefined4 **)(in_RCX + 0x40);
    in_R8D = in_R8D + -1;
    iVar10 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18022700e;
    fcn.180219ce0();
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    do {
        piVar1 = puVar3 + 5;
        while (iVar4 = *(int64_t *)(puVar3 + 2), (int32_t)puVar3[4] < 1) {
            uVar2 = *puVar3;
            uVar5 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18022708e;
            iVar7 = func_0x00018021ac80(uVar5, iVar4, uVar2);
            if (iVar7 < 1) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1802270b4;
                func_0x000180219cf0(in_RCX);
                *in_RDX = '\0';
                if (-1 < iVar7) {
                    return iVar10;
                }
                if (iVar10 < 1) {
                    return iVar7;
                }
                return iVar10;
            }
            puVar3[4] = iVar7;
            *piVar1 = 0;
        }
        iVar7 = 0;
        pcVar9 = (char *)(*piVar1 + iVar4);
        pcVar8 = pcVar9;
        do {
            if ((int64_t)in_R8D <= (int64_t)pcVar8 - (int64_t)pcVar9) {
                puVar3[4] = puVar3[4] - iVar7;
                *piVar1 = *piVar1 + iVar7;
                goto code_r0x00018022707c;
            }
            *in_RDX = *pcVar8;
            in_RDX = in_RDX + 1;
            iVar7 = iVar7 + 1;
            if (*pcVar8 == '\n') {
                puVar3[4] = puVar3[4] - iVar7;
                *piVar1 = *piVar1 + iVar7;
                iVar10 = iVar10 + iVar7;
                goto code_r0x0001802270a4;
            }
            pcVar8 = pcVar8 + 1;
        } while (iVar7 < (int32_t)puVar3[4]);
        puVar3[4] = puVar3[4] - iVar7;
        *piVar1 = *piVar1 + iVar7;
code_r0x00018022707c:
        iVar10 = iVar10 + iVar7;
        in_R8D = in_R8D - iVar7;
        if (in_R8D == 0) {
code_r0x0001802270a4:
            *in_RDX = '\0';
            return iVar10;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1802270f0
// Address: 0x1802270f0
// Size: 1326 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

uint64_t fcn.1802270f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    int32_t iVar2;
    int32_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    char *pcVar13;
    uint64_t in_RDX;
    uint64_t uVar14;
    int32_t iVar15;
    uint64_t uVar16;
    uint64_t in_R8;
    int32_t *in_R9;
    int32_t iVar17;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x180227112;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar3 = *(int32_t **)(in_RCX + 0x40);
    iVar8 = (int32_t)in_R8;
    uVar16 = in_RDX & 0xffffffff;
    // switch table (122 cases) at 0x180227570
    switch((int32_t)in_RDX) {
    case 1:
        *(undefined8 *)(piVar3 + 4) = 0;
        *(undefined8 *)(piVar3 + 8) = 0;
        goto code_r0x00018022715d;
    case 2:
        if (0 < piVar3[4]) {
            return 0;
        }
        iVar11 = *(int64_t *)(in_RCX + 0x48);
        goto code_r0x00018022716a;
    case 3:
        return (uint64_t)(uint32_t)piVar3[8];
    default:
        iVar11 = *(int64_t *)(in_RCX + 0x48);
        goto joined_r0x000180227563;
    case 10:
        uVar7 = piVar3[4];
        goto code_r0x0001802271da;
    case 0xb:
        iVar11 = *(int64_t *)(in_RCX + 0x48);
        if (iVar11 != 0) {
            if (piVar3[8] < 1) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802273b6;
                uVar7 = func_0x000180219d10(iVar11, uVar16, in_R8 & 0xffffffff);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802273c0;
                func_0x000180219cf0(in_RCX);
                return (uint64_t)uVar7;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802273d2;
            fcn.180219ce0(in_RCX, 0xf);
            iVar8 = piVar3[8];
            while( true ) {
                if (iVar8 < 1) {
                    *(undefined8 *)(piVar3 + 8) = 0;
                    uVar4 = *(undefined8 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227438;
                    uVar7 = func_0x000180219d10(uVar4, uVar16, in_R8 & 0xffffffff, in_R9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227442;
                    func_0x000180219cf0(in_RCX);
                    return (uint64_t)uVar7;
                }
                iVar15 = piVar3[9];
                iVar11 = *(int64_t *)(piVar3 + 6);
                uVar4 = *(undefined8 *)(in_RCX + 0x48);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802273f4;
                uVar7 = func_0x00018021b2c0(uVar4, iVar15 + iVar11, iVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802273fe;
                func_0x000180219cf0(in_RCX);
                if ((int32_t)uVar7 < 1) break;
                piVar3[9] = piVar3[9] + uVar7;
                piVar3[8] = piVar3[8] - uVar7;
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227419;
                fcn.180219ce0(in_RCX, 0xf);
                iVar8 = piVar3[8];
            }
            return (uint64_t)uVar7;
        }
        break;
    case 0xc:
        iVar8 = *piVar3;
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18022745a;
        iVar8 = func_0x00018021a790(in_R9, 0x75, iVar8, 0);
        if (0 < iVar8) {
            iVar8 = piVar3[1];
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227472;
            iVar8 = func_0x00018021a790(in_R9, 0x75, iVar8, 1);
            if (0 < iVar8) {
                return 1;
            }
        }
        return 0;
    case 0xd:
        uVar7 = piVar3[8];
code_r0x0001802271da:
        if (uVar7 != 0) {
            return (uint64_t)uVar7;
        }
code_r0x00018022715d:
        iVar11 = *(int64_t *)(in_RCX + 0x48);
joined_r0x000180227563:
        if (iVar11 != 0) {
code_r0x00018022716a:
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227175;
            uVar7 = func_0x000180219d10(iVar11, uVar16, in_R8 & 0xffffffff);
            return (uint64_t)uVar7;
        }
        break;
    case 0x1d:
        iVar11 = (int64_t)&arg_30h + iVar10;
        iVar15 = 0;
        if ((piVar3 != (int32_t *)0x0) && (*(int64_t *)(in_RCX + 0x48) != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802274ac;
            fcn.180219ce0(in_RCX, 0xf);
            while( true ) {
                iVar9 = piVar3[4];
                if (iVar9 != 0) {
                    iVar2 = piVar3[5];
                    iVar17 = iVar15;
                    if (iVar9 <= iVar15) {
                        iVar17 = iVar9;
                    }
                    iVar12 = *(int64_t *)(piVar3 + 2);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802274d3;
                    fcn.180498030(iVar11, iVar2 + iVar12, (int64_t)iVar17);
                    piVar3[5] = piVar3[5] + iVar17;
                    piVar3[4] = piVar3[4] - iVar17;
                    if (iVar15 == iVar17) goto code_r0x000180227539;
                    iVar15 = iVar15 - iVar17;
                    iVar11 = iVar11 + iVar17;
                }
                if (*piVar3 < iVar15) goto code_r0x000180227510;
                uVar4 = *(undefined8 *)(piVar3 + 2);
                uVar6 = *(undefined8 *)(in_RCX + 0x48);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802274fe;
                iVar9 = func_0x00018021ac80(uVar6, uVar4);
                if (iVar9 < 1) break;
                piVar3[5] = 0;
                piVar3[4] = iVar9;
            }
code_r0x000180227531:
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227539;
            func_0x000180219cf0(in_RCX);
        }
code_r0x000180227539:
        in_R8 = in_R8 & 0xffffffff;
        iVar15 = piVar3[5];
        if (piVar3[4] < iVar8) {
            in_R8 = (uint64_t)(uint32_t)piVar3[4];
        }
        iVar11 = *(int64_t *)(piVar3 + 2);
        *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227557;
        fcn.180498030(in_R9, iVar15 + iVar11, (int64_t)(int32_t)in_R8);
        return in_R8;
    case 0x65:
        if (*(int64_t *)(in_RCX + 0x48) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227377;
            fcn.180219ce0(in_RCX, 0xf);
            uVar4 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227389;
            uVar7 = func_0x000180219d10(uVar4, uVar16, in_R8 & 0xffffffff, in_R9);
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227393;
            func_0x000180219cf0(in_RCX);
            return (uint64_t)uVar7;
        }
        break;
    case 0x74:
        uVar16 = 0;
        if (0 < piVar3[4]) {
            uVar14 = (uint64_t)(uint32_t)piVar3[4];
            pcVar13 = (char *)((int64_t)piVar3[5] + *(int64_t *)(piVar3 + 2));
            do {
                cVar1 = *pcVar13;
                pcVar13 = pcVar13 + 1;
                uVar7 = (uint32_t)uVar16 + 1;
                if (cVar1 != '\n') {
                    uVar7 = (uint32_t)uVar16;
                }
                uVar16 = (uint64_t)uVar7;
                uVar14 = uVar14 - 1;
            } while (uVar14 != 0);
            return uVar16;
        }
        return 0;
    case 0x75:
        iVar15 = iVar8;
        iVar9 = iVar8;
        if (in_R9 != (int32_t *)0x0) {
            if (*in_R9 == 0) {
                iVar15 = piVar3[1];
            } else {
                iVar9 = *piVar3;
            }
        }
        iVar11 = *(int64_t *)(piVar3 + 2);
        iVar12 = *(int64_t *)(piVar3 + 6);
        if ((0x1000 < iVar9) && (iVar9 != *piVar3)) {
            if (iVar8 < 1) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802272a9;
            iVar11 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                   *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)&var_18h + iVar10), 
                                   *(int64_t *)((int64_t)&var_20h + iVar10));
            if (iVar11 == 0) {
                return 0;
            }
        }
        if ((0x1000 < iVar15) && (iVar15 != piVar3[1])) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x1802272d9;
            iVar12 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                   *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)&var_18h + iVar10), 
                                   *(int64_t *)((int64_t)&var_20h + iVar10));
            if (iVar12 == 0) {
                if (iVar11 == *(int64_t *)(piVar3 + 2)) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227300;
                fcn.180224990(iVar11, 0x1804bff50, 0x14b);
                return 0;
            }
        }
        iVar5 = *(int64_t *)(piVar3 + 2);
        if (iVar5 != iVar11) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227324;
            fcn.180224990(iVar5, 0x1804bff50, 0x150);
            *(int64_t *)(piVar3 + 2) = iVar11;
            *(undefined8 *)(piVar3 + 4) = 0;
            *piVar3 = iVar9;
        }
        iVar11 = *(int64_t *)(piVar3 + 6);
        if (iVar11 != iVar12) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18022734e;
            fcn.180224990(iVar11, 0x1804bff50, 0x157);
            *(int64_t *)(piVar3 + 6) = iVar12;
            *(undefined8 *)(piVar3 + 8) = 0;
            piVar3[1] = iVar15;
            return 1;
        }
        return 1;
    case 0x7a:
        if (iVar8 <= *piVar3) {
code_r0x000180227239:
            uVar4 = *(undefined8 *)(piVar3 + 2);
            piVar3[5] = 0;
            piVar3[4] = iVar8;
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227251;
            fcn.180498030(uVar4, in_R9, (int64_t)iVar8);
            return 1;
        }
        if (0 < iVar8) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18022720e;
            iVar11 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                   *(int64_t *)(&stack0x00000000 + iVar10), *(int64_t *)((int64_t)&var_18h + iVar10), 
                                   *(int64_t *)((int64_t)&var_20h + iVar10));
            if (iVar11 != 0) {
                uVar4 = *(undefined8 *)(piVar3 + 2);
                *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x180227230;
                fcn.180224990(uVar4, 0x1804bff50, 0x127);
                *(int64_t *)(piVar3 + 2) = iVar11;
                goto code_r0x000180227239;
            }
        }
    }
    return 0;
code_r0x000180227510:
    uVar4 = *(undefined8 *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&uStack_30 + iVar10) = 0x18022751f;
    iVar9 = func_0x00018021ac80(uVar4, iVar11, iVar15);
    if (iVar9 < 1) goto code_r0x000180227531;
    if (iVar15 == iVar9) goto code_r0x000180227539;
    iVar11 = iVar11 + iVar9;
    iVar15 = iVar15 - iVar9;
    goto code_r0x000180227510;
}

// ============================================================
// Function: FUN_180227620
// Address: 0x180227620
// Size: 247 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180227620(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180227630;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022764d;
    puVar3 = (undefined4 *)
             fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000040 + iVar2));
    if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0x1000;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180227672;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
        *(int64_t *)(puVar3 + 2) = iVar4;
        if (iVar4 != 0) {
            puVar3[1] = 0x1000;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802276b4;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000038 + iVar2)
                                  , *(int64_t *)(&stack0x00000040 + iVar2));
            *(int64_t *)(puVar3 + 6) = iVar4;
            if (iVar4 == 0) {
                uVar1 = *(undefined8 *)(puVar3 + 2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802276d3;
                fcn.180224990(uVar1, 0x1804bff50, 0x3c);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802276e8;
                fcn.180224990(puVar3, 0x1804bff50, 0x3d);
                return 0;
            }
            *(undefined4 **)(in_RCX + 0x40) = puVar3;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            *(undefined4 *)(in_RCX + 0x30) = 0;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180227690;
        fcn.180224990(puVar3, 0x1804bff50, 0x36);
    }
    return 0;
}

// ============================================================
// Function: FUN_180227720
// Address: 0x180227720
// Size: 134 bytes
// ============================================================
undefined8 fcn.180227720(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022772c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    uVar2 = *(undefined8 *)(iVar1 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022775e;
    fcn.180224990(uVar2, 0x1804bff50, 0x4e);
    uVar2 = *(undefined8 *)(iVar1 + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180227774;
    fcn.180224990(uVar2, 0x1804bff50, 0x4f);
    uVar2 = *(undefined8 *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022778a;
    fcn.180224990(uVar2, 0x1804bff50, 0x50);
    *(undefined8 *)(in_RCX + 0x40) = 0;
    *(undefined4 *)(in_RCX + 0x28) = 0;
    *(undefined4 *)(in_RCX + 0x30) = 0;
    return 1;
}

// ============================================================
// Function: FUN_1802277b0
// Address: 0x1802277b0
// Size: 38 bytes
// ============================================================
undefined8
fcn.1802277b0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_70h, int64_t arg_78h,
             int64_t arg_80h, int64_t arg_88h, int64_t arg_d0h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 uStackX_18;
    int64_t var_20h;
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *(int64_t *)(in_RCX + 0x48);
    if (iVar7 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = in_R8;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6) = 0x180219b60;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (iVar7 == 0) {
        return 0xfffffffe;
    }
    if (((*(int64_t *)(iVar7 + 8) == 0) || (*(int64_t *)(*(int64_t *)(iVar7 + 8) + 0x58) == 0)) || (in_EDX != 0xe)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar6) = 0x180219caa;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar6));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar6) = 0x180219cc2;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar6), 
                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar6), 
                      *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar6));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar6) = 0x180219cd4;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar6));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(iVar7 + 0x10);
    *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_78h + iVar3 + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_88h + iVar3 + iVar6) = unaff_RDI;
    ppcVar1 = (code **)(iVar7 + 0x18);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219c1b;
        pcVar4 = *ppcVar1;
code_r0x000180219bc9:
        *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar6) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar3 + iVar6) = 1;
        *(undefined4 *)((int64_t)&arg_48h + iVar3 + iVar6) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar6) = 0xe;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar6) = 0x180219bf1;
        uVar5 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(iVar7 + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219bc9;
        *(undefined4 *)((int64_t)&arg_48h + iVar3 + iVar6) = 1;
        *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar6) = 0x180219c12;
        uVar5 = (*pcVar2)();
    }
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
code_r0x000180219c1b:
    pcVar2 = *(code **)(*(int64_t *)(iVar7 + 8) + 0x58);
    *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar6) = 0x180219c2e;
    uVar5 = (*pcVar2)(iVar7, 0xe);
    pcVar2 = *(code **)(iVar7 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar5;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&arg_48h + iVar3 + iVar6) = (int32_t)uVar5;
            *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar6) = 0x180219ca3;
            uVar5 = (*pcVar2)(iVar7, 0x86, (int64_t)&arg_80h + iVar3 + iVar6, 0xe);
            return uVar5;
        }
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar6) = 0;
    *(int32_t *)((int64_t)&arg_50h + iVar3 + iVar6) = (int32_t)uVar5;
    *(undefined4 *)((int64_t)&arg_48h + iVar3 + iVar6) = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar6) = 0xe;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar3 + iVar6) = 0x180219c70;
    uVar5 = (*pcVar4)(iVar7, 0x86, (int64_t)&arg_80h + iVar3 + iVar6, 0);
    return uVar5;
}

// ============================================================
// Function: FUN_1802277f0
// Address: 0x1802277f0
// Size: 24 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch

int32_t fcn.1802277f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802277fe;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227820;
    (*(code *)0x8000000000000070)(0);
    if (*(int32_t *)(iVar1 + 0x38) == 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227848;
        uVar4 = func_0x000180184b50(iVar1);
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227856;
        uVar6 = func_0x00018000ce10(iVar1);
        *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar4;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227871;
        iVar2 = (*(code *)0x8000000000000014)((int64_t)iVar2, in_RDX, in_R8 & 0xffffffff, 0);
    } else {
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227839;
        iVar2 = (*(code *)0x8000000000000013)((int64_t)iVar2, in_RDX, in_R8 & 0xffffffff, 0);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227885;
    fcn.180219ce0(in_RCX, 0xf);
    if (iVar2 < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18022789a;
        iVar3 = func_0x000180228650(iVar2);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802278ab;
            fcn.18021b250(in_RCX, 10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802278b1;
            uVar4 = (*(code *)0x800000000000006f)();
            *(undefined4 *)(iVar1 + 0x3c) = uVar4;
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180227808
// Address: 0x180227808
// Size: 54 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch

int32_t fcn.1802277f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802277fe;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227820;
    (*(code *)0x8000000000000070)(0);
    if (*(int32_t *)(iVar1 + 0x38) == 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227848;
        uVar4 = func_0x000180184b50(iVar1);
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227856;
        uVar6 = func_0x00018000ce10(iVar1);
        *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar4;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = uVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227871;
        iVar2 = (*(code *)0x8000000000000014)((int64_t)iVar2, in_RDX, in_R8 & 0xffffffff, 0);
    } else {
        iVar2 = *(int32_t *)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227839;
        iVar2 = (*(code *)0x8000000000000013)((int64_t)iVar2, in_RDX, in_R8 & 0xffffffff, 0);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180227885;
    fcn.180219ce0(in_RCX, 0xf);
    if (iVar2 < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18022789a;
        iVar3 = func_0x000180228650(iVar2);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802278ab;
            fcn.18021b250(in_RCX, 10);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802278b1;
            uVar4 = (*(code *)0x800000000000006f)();
            *(undefined4 *)(iVar1 + 0x3c) = uVar4;
        }
    }
    return iVar2;
}

