// Chunk 24 - 50 functions

// ============================================================
// Function: FUN_180048adc
// Address: 0x180048adc
// Size: 37 bytes
// ============================================================
void fcn.180048adc(int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t unaff_RDI;
    undefined auStack_30 [8];
    undefined auStack_28 [24];
    
    if (0xf < *(uint64_t *)(unaff_RDI + 0x60)) {
        iVar1 = *(int64_t *)(unaff_RDI + 0x48);
        iVar3 = iVar1;
        puVar4 = auStack_30;
        if ((0xfff < *(uint64_t *)(unaff_RDI + 0x60) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_30, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_28;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(unaff_RDI + 0x58) = 0;
    *(undefined8 *)(unaff_RDI + 0x60) = 0xf;
    *(undefined *)(int64_t *)(unaff_RDI + 0x48) = 0;
    return;
}

// ============================================================
// Function: FUN_180048b10
// Address: 0x180048b10
// Size: 5199 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_227h
// WARNING: [rz-ghidra] Detected overlap for variable var_25ch
// WARNING: [rz-ghidra] Detected overlap for variable var_21ch

void fcn.180048b10(int64_t arg1)
{
    int64_t **ppiVar1;
    code *pcVar2;
    float fVar3;
    float fVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    char cVar13;
    undefined uVar14;
    int32_t iVar15;
    int64_t *piVar16;
    undefined8 uVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int64_t iVar20;
    uint64_t uVar21;
    int64_t iVar22;
    float *pfVar23;
    undefined8 *puVar24;
    uint64_t unaff_RBX;
    int64_t *piVar25;
    undefined8 *puVar26;
    undefined *puVar27;
    undefined *puVar28;
    undefined *puVar29;
    uint32_t uVar30;
    int64_t *unaff_RSI;
    uint64_t unaff_RDI;
    int64_t *piVar31;
    uint64_t uVar32;
    uint64_t uVar33;
    undefined8 *puVar34;
    int64_t *unaff_R15;
    int64_t unaff_GS_OFFSET;
    float fVar35;
    undefined4 extraout_XMM0_Da;
    undefined4 uVar36;
    float fVar37;
    float unaff_XMM6_Da;
    undefined auStack_388 [32];
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_300h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2d0h;
    int64_t var_2b0h;
    int64_t var_290h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    undefined8 uStack_240;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    undefined8 uStack_1e0;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar28 = auStack_388;
    puVar27 = auStack_388;
    var_68h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_388;
    puVar34 = (undefined8 *)0x0;
    piVar16 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar16 = *(int64_t **)0x180782430;
    }
    if ((piVar16 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar16 + 0xc) != 7)) {
        func_0x000180088470(arg1, 1, 7);
    } else {
        func_0x000180086cc0(arg1, 1, 0x180623830);
        piVar16 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        puVar29 = auStack_388;
        if (piVar16 == *(int64_t **)0x180782430) goto code_r0x000180049b8c;
        puVar29 = auStack_388;
        if (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 6) goto code_r0x000180049b8c;
        iVar20 = *piVar16;
        uVar30 = *(uint32_t *)(iVar20 + 0x14);
        unaff_RDI = (uint64_t)uVar30;
        unaff_RSI = (int64_t *)(iVar20 + 0x18);
        _var_1e8h = ZEXT816(0);
        var_1d8h = 0;
        var_1d0h = 0;
        unaff_R15 = (int64_t *)0x7fffffffffffffff;
        if (unaff_RDI < 0x10) {
            var_1d0h = 0xf;
            var_1d8h = unaff_RDI;
            func_0x000180498030(&var_1e8h, unaff_RSI, uVar30);
            *(undefined *)((int64_t)&var_1e8h + unaff_RDI) = 0;
        } else {
            var_338h = unaff_RDI | 0xf;
            if ((uint64_t)var_338h < 0x8000000000000000) {
                if ((uint64_t)var_338h < 0x16) {
                    var_338h = 0x16;
                }
            } else {
                var_338h = 0x7fffffffffffffff;
            }
            unaff_RBX = func_0x000180004930(&var_1e8h, &var_338h);
            var_1e8h = unaff_RBX;
            var_1d0h = var_338h;
            var_1d8h = unaff_RDI;
            func_0x000180498030(unaff_RBX, unaff_RSI, unaff_RDI);
            *(undefined *)(unaff_RBX + unaff_RDI) = 0;
        }
        func_0x0001800858c0(arg1, 0xfffffffe);
        cVar13 = func_0x000180047b80(&var_1e8h);
        if (cVar13 != '\0') {
            var_338h = CONCAT44(var_338h._4_4_, 1);
            func_0x000180086cc0(arg1, 1, 0x180623838);
            puVar28 = auStack_388;
            if ((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) == *(int64_t **)0x180782430) goto code_r0x000180048e8a;
            iVar15 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
            if ((iVar15 != 6) && (puVar28 = auStack_388, iVar15 != 3)) goto code_r0x000180048e8a;
            uVar17 = func_0x0001800860c0(arg1, 0xffffffff, 0);
            _var_208h = ZEXT816(0);
            var_1f8h = 0;
            var_1f0h = 0;
            uVar18 = func_0x000180498cd0(uVar17);
            func_0x000180004830(&var_208h, uVar17, uVar18);
            piVar16 = &var_208h;
            if (0xf < (uint64_t)var_1f0h) {
                piVar16 = (int64_t *)var_208h;
            }
            piVar25 = &var_208h;
            if (0xf < (uint64_t)var_1f0h) {
                piVar25 = (int64_t *)var_208h;
            }
            piVar25 = (int64_t *)((int64_t)piVar25 + var_1f8h);
            piVar31 = &var_208h;
            if (0xf < (uint64_t)var_1f0h) {
                piVar31 = (int64_t *)var_208h;
            }
            if (piVar31 != piVar25) {
                do {
                    uVar14 = func_0x000180460320(*(undefined *)piVar31);
                    *(undefined *)piVar16 = uVar14;
                    piVar16 = (int64_t *)((int64_t)piVar16 + 1);
                    piVar31 = (int64_t *)((int64_t)piVar31 + 1);
                } while (piVar31 != piVar25);
            }
            puVar29 = auStack_388;
            piVar16 = (int64_t *)var_208h;
            if (*(int32_t *)
                 (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
                *(int32_t *)0x1807828a0) goto code_r0x000180049ba9;
            goto code_r0x000180048ddc;
        }
    }
    iVar20 = 0x180623780;
    fVar35 = (float)func_0x000180088560();
code_r0x000180049d99:
    fVar37 = (float)(unaff_RBX >> 1 | (uint64_t)((uint32_t)unaff_RBX & 1));
    fVar37 = fVar37 + fVar37;
    do {
        if (*(float *)0x180782860 < fVar35 / fVar37) {
            *(undefined8 *)(puVar28 + -8) = 0x180049dd2;
            fVar35 = (float)func_0x000180471c90(fVar35 / *(float *)0x180782860);
            iVar20 = 0;
            if ((unaff_XMM6_Da <= fVar35) && (fVar35 = fVar35 - unaff_XMM6_Da, fVar35 < unaff_XMM6_Da)) {
                iVar20 = -0x8000000000000000;
            }
            uVar33 = 8;
            if (8 < (uint64_t)((int64_t)fVar35 + iVar20)) {
                uVar33 = (int64_t)fVar35 + iVar20;
            }
            uVar32 = unaff_RBX;
            if ((unaff_RBX < uVar33) && ((0x1ff < unaff_RBX || (uVar32 = unaff_RBX * 8, unaff_RBX * 8 < uVar33)))) {
                uVar32 = uVar33;
            }
            *(undefined8 *)(puVar28 + -8) = 0x180049e29;
            uVar36 = func_0x00018004c4b0(uVar33, uVar32);
            *(undefined8 *)(puVar28 + -8) = 0x180049e3a;
            pfVar23 = (float *)func_0x00018004a560(uVar36, puVar28 + 0x50, unaff_RSI + 2, unaff_RDI);
            fVar35 = *pfVar23;
            fVar37 = pfVar23[1];
            fVar3 = pfVar23[2];
            fVar4 = pfVar23[3];
            *(float *)(puVar28 + 0x30) = fVar35;
            *(float *)(puVar28 + 0x34) = fVar37;
            *(float *)(puVar28 + 0x38) = fVar3;
            *(float *)(puVar28 + 0x3c) = fVar4;
            iVar20 = *(int64_t *)0x180782870;
        }
        var_220h = (int64_t)puVar34;
        iVar19 = *(int64_t *)(puVar28 + 0x30);
        ppiVar1 = *(int64_t ***)(iVar19 + 8);
        *(int64_t *)0x180782870 = iVar20 + 1;
        *unaff_RSI = iVar19;
        unaff_RSI[1] = (int64_t)ppiVar1;
        *ppiVar1 = unaff_RSI;
        *(int64_t **)(iVar19 + 8) = unaff_RSI;
        puVar24 = *(undefined8 **)0x180782878;
        uVar33 = unaff_RDI & *(uint64_t *)0x180782890;
        if ((*(undefined8 **)0x180782878)[uVar33 * 2] == *(int64_t *)0x180782868) {
            (*(undefined8 **)0x180782878)[uVar33 * 2] = unaff_RSI;
code_r0x000180049ea4:
            puVar24[uVar33 * 2 + 1] = unaff_RSI;
        } else if ((*(undefined8 **)0x180782878)[uVar33 * 2] == iVar19) {
            (*(undefined8 **)0x180782878)[uVar33 * 2] = unaff_RSI;
        } else if ((int64_t **)(*(undefined8 **)0x180782878)[uVar33 * 2 + 1] == ppiVar1) goto code_r0x000180049ea4;
        do {
            unaff_R15 = unaff_R15 + 3;
            if (unaff_R15 == &var_70h) {
                *(undefined8 *)(puVar28 + -8) = 0x180049eda;
                func_0x000180459c24(0x1804a24f0);
                *(undefined8 *)(puVar28 + -8) = 0x180049ee7;
                func_0x000180459cac(0x1807828a0);
                puVar27 = puVar28;
                do {
                    piVar16 = (int64_t *)var_208h;
code_r0x000180048ddc:
                    iVar20 = var_1f0h;
                    var_228h = (int64_t)&var_208h;
                    if (0xf < (uint64_t)var_1f0h) {
                        var_228h = (int64_t)piVar16;
                    }
                    var_220h = var_1f8h;
                    uVar33 = 0xcbf29ce484222325;
                    puVar24 = puVar34;
                    if (var_1f8h != 0) {
                        do {
                            uVar33 = (uVar33 ^ *(uint8_t *)(var_228h + (int64_t)puVar24)) * 0x100000001b3;
                            puVar24 = (undefined8 *)((int64_t)puVar24 + 1);
                        } while (puVar24 < (uint64_t)var_1f8h);
                    }
                    *(undefined8 *)(puVar27 + -8) = 0x180048e41;
                    iVar19 = func_0x00018004a560(puVar24, puVar27 + 0x30, &var_228h, uVar33);
                    iVar19 = *(int64_t *)(iVar19 + 8);
                    puVar28 = puVar27;
                    if ((iVar19 == 0) || (iVar19 == *(int64_t *)0x180782868)) goto code_r0x000180049eff;
                    *(undefined4 *)(puVar27 + 0x50) = *(undefined4 *)(iVar19 + 0x20);
                    if (0xf < (uint64_t)iVar20) {
                        *(undefined8 *)(puVar27 + -8) = 0x180048e7a;
                        func_0x000180005a60(&var_208h, piVar16, iVar20);
                    }
code_r0x000180048e8a:
                    *(undefined8 *)(puVar28 + -8) = 0x180048e97;
                    func_0x0001800858c0(arg1, 0xfffffffe);
                    var_1b0h = 0xf;
                    stack0xfffffffffffffe39 = SUB1615(ZEXT816(0), 1);
                    auVar7[15] = 0;
                    auVar7._0_15_ = stack0xfffffffffffffe39;
                    _var_1c8h = auVar7 << 8;
                    var_1b8h = (int64_t)puVar34;
                    *(undefined8 *)(puVar28 + -8) = 0x180048ece;
                    func_0x000180086cc0(arg1, 1, 0x1806237cc);
                    if (((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430) &&
                       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 6)) {
                        *(undefined8 **)(puVar28 + 0x30) = puVar34;
                        *(undefined8 *)(puVar28 + -8) = 0x180048f04;
                        uVar17 = func_0x0001800860c0(arg1, 0xffffffff, puVar28 + 0x30);
                        uVar33 = *(uint64_t *)(puVar28 + 0x30);
                        _var_268h = ZEXT816(0);
                        if (0x7fffffffffffffff < uVar33) {
                            *(undefined8 *)(puVar28 + -8) = 0x180049ef1;
                            func_0x0001800047c0();
                            goto code_r0x000180049ef2;
                        }
                        if (uVar33 < 0x10) {
                            var_250h = 0xf;
                            var_258h = uVar33;
                            *(undefined8 *)(puVar28 + -8) = 0x180048f3d;
                            func_0x000180498030(&var_268h, uVar17, uVar33);
                            *(undefined *)((int64_t)&var_268h + uVar33) = 0;
                        } else {
                            uVar32 = uVar33 | 0xf;
                            if (uVar32 < 0x8000000000000000) {
                                if (uVar32 < 0x16) {
                                    uVar32 = 0x16;
                                }
                            } else {
                                uVar32 = 0x7fffffffffffffff;
                            }
                            *(uint64_t *)(puVar28 + 0x30) = uVar32;
                            *(undefined8 *)(puVar28 + -8) = 0x180048f70;
                            iVar20 = func_0x000180004930(&var_268h, puVar28 + 0x30);
                            var_268h = iVar20;
                            var_258h = uVar33;
                            var_250h = *(int64_t *)(puVar28 + 0x30);
                            *(undefined8 *)(puVar28 + -8) = 0x180048f92;
                            func_0x000180498030(iVar20, uVar17, uVar33);
                            *(undefined *)(iVar20 + uVar33) = 0;
                        }
                        _var_1c8h = _var_268h;
                        var_1b8h = var_258h;
                        var_1b0h = var_250h;
                        var_250h = 0xf;
                        auVar8[15] = 0;
                        auVar8._0_15_ = stack0xfffffffffffffd99;
                        _var_268h = auVar8 << 8;
                        var_258h = (int64_t)puVar34;
                        *(undefined8 *)(puVar28 + -8) = 0x180048fc5;
                        func_0x000180004e40(&var_268h);
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x180048fd2;
                    func_0x0001800858c0(arg1, 0xfffffffe);
                    *(undefined8 **)(puVar28 + 0x40) = puVar34;
                    *(undefined8 **)(puVar28 + 0x48) = puVar34;
                    *(undefined8 *)(puVar28 + -8) = 0x180048fe6;
                    iVar20 = func_0x000180459890(0x60);
                    *(int64_t *)iVar20 = iVar20;
                    *(int64_t *)(iVar20 + 8) = iVar20;
                    *(int64_t *)(iVar20 + 0x10) = iVar20;
                    *(undefined2 *)(iVar20 + 0x18) = 0x101;
                    *(int64_t *)(puVar28 + 0x40) = iVar20;
                    *(undefined8 *)(puVar28 + -8) = 0x180049010;
                    func_0x000180086cc0(arg1, 1, 0x180623808);
                    if (((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430) &&
                       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
                        *(undefined8 *)(puVar28 + -8) = 0x180049037;
                        func_0x000180086510(arg1);
                        while( true ) {
                            *(undefined8 *)(puVar28 + -8) = 0x180049044;
                            iVar15 = func_0x000180087970(arg1, 0xfffffffe);
                            if (iVar15 == 0) break;
                            iVar20 = *(int64_t *)(arg1 + 0x40);
                            if (((((int64_t *)(iVar20 - 0x10U) == *(int64_t **)0x180782430) ||
                                 (*(int32_t *)(iVar20 + -4) != 6)) ||
                                ((int64_t *)(iVar20 - 0x20U) == *(int64_t **)0x180782430)) ||
                               (*(int32_t *)(iVar20 + -0x14) != 6)) goto code_r0x000180049f30;
                            iVar19 = *(int64_t *)(iVar20 - 0x20U);
                            puVar34 = (undefined8 *)(uint64_t)*(uint32_t *)(iVar19 + 0x14);
                            uVar30 = *(uint32_t *)(*(int64_t *)(iVar20 + -0x10) + 0x14);
                            uVar33 = (uint64_t)uVar30;
                            iVar20 = *(int64_t *)(iVar20 + -0x10) + 0x18;
                            _var_248h = ZEXT816(0);
                            var_238h = 0;
                            var_230h = 0;
                            if (0xf < uVar33) {
                                uVar32 = uVar33 | 0xf;
                                if (uVar32 < 0x8000000000000000) {
                                    if (uVar32 < 0x16) {
                                        uVar32 = 0x16;
                                    }
                                    if (uVar32 + 1 < 0x1000) {
                                        *(undefined8 *)(puVar28 + -8) = 0x18004914b;
                                        uVar21 = func_0x000180459890();
code_r0x00018004914e:
                                        var_248h = uVar21;
                                        var_238h = uVar33;
                                        var_230h = uVar32;
                                        *(undefined8 *)(puVar28 + -8) = 0x180049168;
                                        func_0x000180498030(uVar21, iVar20, uVar33);
                                        *(undefined *)(uVar33 + uVar21) = 0;
                                        goto code_r0x00018004916c;
                                    }
                                    uVar21 = uVar32 + 0x28;
                                    if (uVar32 + 1 < uVar21) goto code_r0x000180049127;
                                    goto code_r0x000180049f1e;
                                }
                                uVar32 = 0x7fffffffffffffff;
                                uVar21 = 0x8000000000000027;
code_r0x000180049127:
                                *(undefined8 *)(puVar28 + -8) = 0x18004912f;
                                iVar22 = func_0x000180459890(uVar21);
                                if (iVar22 != 0) {
                                    uVar21 = iVar22 + 0x27U & 0xffffffffffffffe0;
                                    *(int64_t *)(uVar21 - 8) = iVar22;
                                    goto code_r0x00018004914e;
                                }
code_r0x0001800493f2:
                                pcVar2 = (code *)swi(0x29);
                                (*pcVar2)(5);
                                puVar28 = puVar28 + 8;
                                break;
                            }
                            var_230h = 0xf;
                            var_238h = uVar33;
                            *(undefined8 *)(puVar28 + -8) = 0x1800490d4;
                            func_0x000180498030(&var_248h, iVar20, uVar30);
                            *(undefined *)((int64_t)&var_248h + uVar33) = 0;
                            uVar32 = var_230h;
code_r0x00018004916c:
                            _var_268h = ZEXT816(0);
                            var_258h = 0;
                            var_250h = 0;
                            if ((undefined8 *)0xf < puVar34) {
                                uVar33 = (uint64_t)puVar34 | 0xf;
                                if (0x7fffffffffffffff < uVar33) {
                                    uVar33 = 0x7fffffffffffffff;
                                    uVar21 = 0x8000000000000027;
code_r0x0001800491f7:
                                    *(undefined8 *)(puVar28 + -8) = 0x1800491ff;
                                    iVar20 = func_0x000180459890(uVar21);
                                    if (iVar20 != 0) {
                                        uVar21 = iVar20 + 0x27U & 0xffffffffffffffe0;
                                        *(int64_t *)(uVar21 - 8) = iVar20;
                                        goto code_r0x00018004921e;
                                    }
code_r0x0001800493eb:
                                    pcVar2 = (code *)swi(0x29);
                                    (*pcVar2)(5);
                                    puVar28 = puVar28 + 8;
                                    goto code_r0x0001800493f2;
                                }
                                if (uVar33 < 0x16) {
                                    uVar33 = 0x16;
                                }
                                if (uVar33 + 1 < 0x1000) {
                                    *(undefined8 *)(puVar28 + -8) = 0x18004921b;
                                    uVar21 = func_0x000180459890();
code_r0x00018004921e:
                                    var_268h = uVar21;
                                    var_258h = (int64_t)puVar34;
                                    var_250h = uVar33;
                                    *(undefined8 *)(puVar28 + -8) = 0x18004923a;
                                    func_0x000180498030(uVar21, iVar19 + 0x18, puVar34);
                                    *(undefined *)((int64_t)puVar34 + uVar21) = 0;
                                    goto code_r0x000180049240;
                                }
                                uVar21 = uVar33 + 0x28;
                                if (uVar33 + 1 < uVar21) goto code_r0x0001800491f7;
                                goto code_r0x000180049f24;
                            }
                            var_250h = 0xf;
                            var_258h = (int64_t)puVar34;
                            *(undefined8 *)(puVar28 + -8) = 0x1800491a0;
                            func_0x000180498030(&var_268h, iVar19 + 0x18, puVar34);
                            *(undefined *)((int64_t)&var_268h + (int64_t)puVar34) = 0;
code_r0x000180049240:
                            puVar34 = *(undefined8 **)(puVar28 + 0x40);
                            puVar24 = (undefined8 *)puVar34[1];
                            puVar26 = puVar24;
                            if (*(char *)((int64_t)puVar24 + 0x19) == '\0') {
                                do {
                                    puVar24 = puVar26;
                                    *(undefined8 *)(puVar28 + -8) = 0x180049275;
                                    cVar13 = func_0x00018016b240(puVar28 + 0x40, puVar24 + 4, &var_268h);
                                    if (cVar13 == '\0') {
                                        puVar26 = (undefined8 *)*puVar24;
                                        puVar34 = puVar24;
                                    } else {
                                        puVar26 = (undefined8 *)puVar24[2];
                                    }
                                    uVar30 = (uint32_t)(cVar13 == '\0');
                                } while (*(char *)((int64_t)puVar26 + 0x19) == '\0');
                                puVar26 = *(undefined8 **)(puVar28 + 0x40);
                            } else {
                                uVar30 = 0;
                                puVar26 = puVar34;
                            }
                            if (*(char *)((int64_t)puVar34 + 0x19) == '\0') {
                                *(undefined8 *)(puVar28 + -8) = 0x1800492b7;
                                cVar13 = func_0x00018016b240(puVar28 + 0x40, &var_268h, puVar34 + 4);
                                if (cVar13 != '\0') {
                                    puVar26 = *(undefined8 **)(puVar28 + 0x40);
                                    goto code_r0x0001800492c4;
                                }
                            } else {
code_r0x0001800492c4:
                                if (*(int64_t *)(puVar28 + 0x48) == 0x2aaaaaaaaaaaaaa) goto code_r0x000180049f2a;
                                *(undefined **)(puVar28 + 0x30) = puVar28 + 0x40;
                                *(undefined8 *)(puVar28 + 0x38) = 0;
                                *(undefined8 *)(puVar28 + -8) = 0x1800492f5;
                                piVar16 = (int64_t *)func_0x000180459890(0x60);
                                *(undefined4 *)(piVar16 + 4) = (undefined4)var_268h;
                                *(undefined4 *)((int64_t)piVar16 + 0x24) = var_268h._4_4_;
                                *(undefined4 *)(piVar16 + 5) = (undefined4)var_260h;
                                *(undefined4 *)((int64_t)piVar16 + 0x2c) = var_260h._4_4_;
                                *(undefined4 *)(piVar16 + 6) = (undefined4)var_258h;
                                *(undefined4 *)((int64_t)piVar16 + 0x34) = var_258h._4_4_;
                                *(undefined4 *)(piVar16 + 7) = (undefined4)var_250h;
                                *(undefined4 *)((int64_t)piVar16 + 0x3c) = var_250h._4_4_;
                                var_258h = 0;
                                var_250h = 0xf;
                                auVar9[15] = 0;
                                auVar9._0_15_ = stack0xfffffffffffffd99;
                                _var_268h = auVar9 << 8;
                                *(undefined4 *)(piVar16 + 8) = (undefined4)var_248h;
                                *(undefined4 *)((int64_t)piVar16 + 0x44) = var_248h._4_4_;
                                *(undefined4 *)(piVar16 + 9) = (undefined4)uStack_240;
                                *(undefined4 *)((int64_t)piVar16 + 0x4c) = uStack_240._4_4_;
                                *(undefined4 *)(piVar16 + 10) = (undefined4)var_238h;
                                *(undefined4 *)((int64_t)piVar16 + 0x54) = var_238h._4_4_;
                                *(undefined4 *)(piVar16 + 0xb) = (undefined4)var_230h;
                                *(undefined4 *)((int64_t)piVar16 + 0x5c) = var_230h._4_4_;
                                uVar32 = 0xf;
                                auVar10[15] = 0;
                                auVar10._0_15_ = stack0xfffffffffffffdb9;
                                _var_248h = auVar10 << 8;
                                *piVar16 = (int64_t)puVar26;
                                piVar16[1] = (int64_t)puVar26;
                                piVar16[2] = (int64_t)puVar26;
                                *(undefined2 *)(piVar16 + 3) = 0;
                                *(undefined8 *)(puVar28 + 0x38) = 0;
                                var_220h._0_4_ = uVar30;
                                var_228h = (int64_t)puVar24;
                                var_220h._4_4_ = var_260h._4_4_;
                                *(undefined8 *)(puVar28 + -8) = 0x180049361;
                                func_0x0001800156d0(puVar28 + 0x40, &var_228h, piVar16);
                            }
                            puVar34 = (undefined8 *)0x0;
                            if (0xf < (uint64_t)var_250h) {
                                uVar33 = var_250h + 1;
                                iVar20 = var_268h;
                                if (0xfff < uVar33) {
                                    iVar20 = *(int64_t *)(var_268h + -8);
                                    if (0x1f < (var_268h - iVar20) - 8U) goto code_r0x0001800493eb;
                                    uVar33 = var_250h + 0x28;
                                }
                                *(undefined8 *)(puVar28 + -8) = 0x18004939d;
                                func_0x000180459c3c(iVar20, uVar33);
                            }
                            var_258h = 0;
                            var_250h = 0xf;
                            auVar11[15] = 0;
                            auVar11._0_15_ = stack0xfffffffffffffd99;
                            _var_268h = auVar11 << 8;
                            if (0xf < uVar32) {
                                uVar33 = uVar32 + 1;
                                iVar20 = var_248h;
                                if (0xfff < uVar33) {
                                    iVar20 = *(int64_t *)(var_248h + -8);
                                    if (0x1f < (var_248h - iVar20) - 8U) goto code_r0x0001800493f2;
                                    uVar33 = uVar32 + 0x28;
                                }
                                *(undefined8 *)(puVar28 + -8) = 0x1800493e1;
                                func_0x000180459c3c(iVar20, uVar33);
                            }
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        }
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x180049406;
                    func_0x0001800858c0(arg1, 0xfffffffe);
                    puVar28[0x70] = 1;
                    *(undefined (*) [16])(puVar28 + 0x78) = ZEXT816(0);
                    var_300h = (int64_t)puVar34;
                    *(undefined8 *)(puVar28 + -8) = 0x18004942c;
                    func_0x000180086cc0(arg1, 1, 0x1806238e0);
                    if (((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) == *(int64_t **)0x180782430) ||
                       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
code_r0x0001800497dd:
                        *(undefined8 *)(puVar28 + -8) = 0x1800497ea;
                        func_0x0001800858c0(arg1, 0xfffffffe);
                        *(undefined8 *)(puVar28 + -8) = 0x1800497f7;
                        func_0x0001800205e0(puVar28 + 0x60, arg1);
                        *(undefined8 *)(puVar28 + -8) = 0x1800497fd;
                        piVar16 = (int64_t *)func_0x000180008740();
                        iVar20 = *(int64_t *)(*piVar16 + 0x18);
                        *(undefined8 *)(puVar28 + -8) = 0x180049809;
                        func_0x0001800137d0();
                        *(int64_t **)(puVar28 + 0x30) = &var_2f8h;
                        var_2f8h = iVar20;
                        *(undefined8 *)(puVar28 + -8) = 0x180049826;
                        func_0x00018000b4d0(&var_2f0h, &var_1e8h);
                        *(undefined8 *)(puVar28 + -8) = 0x180049837;
                        func_0x00018000b4d0(&var_2d0h, &var_1c8h);
                        *(undefined8 *)(puVar28 + -8) = 0x180049846;
                        func_0x00018003c450(&var_2b0h, puVar28 + 0x70);
                        *(undefined8 *)(puVar28 + -8) = 0x180049855;
                        func_0x00018003e190(&var_290h, puVar28 + 0x40);
                        var_280h._0_4_ = *(undefined4 *)(puVar28 + 0x50);
                        _var_278h = ZEXT816(0);
                        var_270h = *(int64_t *)(puVar28 + 0x68);
                        if (var_270h != 0) {
                            LOCK();
                            *(int32_t *)(var_270h + 8) = *(int32_t *)(var_270h + 8) + 1;
                            UNLOCK();
                            var_270h = *(int64_t *)(puVar28 + 0x68);
                        }
                        var_278h = *(undefined8 *)(puVar28 + 0x60);
                        *(int64_t **)(puVar28 + 0x30) = &var_2f8h;
                        *(undefined8 *)(puVar28 + -8) = 0x180049892;
                        iVar20 = func_0x00018045838c();
                        *(int64_t **)(puVar28 + 0x50) = &var_1a8h;
                        var_1a8h = var_2f8h;
                        *(undefined8 *)(puVar28 + -8) = 0x1800498bc;
                        func_0x00018000b4d0(&var_1a0h, &var_2f0h);
                        *(undefined8 *)(puVar28 + -8) = 0x1800498cd;
                        func_0x00018000b4d0(&var_180h, &var_2d0h);
                        *(undefined8 *)(puVar28 + -8) = 0x1800498de;
                        func_0x00018003c450(&var_160h, &var_2b0h);
                        *(undefined8 *)(puVar28 + -8) = 0x1800498ef;
                        func_0x00018003e190(&var_140h, &var_290h);
                        var_130h._0_4_ = (undefined4)var_280h;
                        if (var_270h != 0) {
                            LOCK();
                            *(int32_t *)(var_270h + 8) = *(int32_t *)(var_270h + 8) + 1;
                            UNLOCK();
                        }
                        var_128h = var_278h;
                        var_120h = var_270h;
                        _var_268h = ZEXT816(0);
                        var_118h = iVar20;
                        *(undefined8 *)(puVar28 + -8) = 0x18004993a;
                        func_0x0001800049a0(&var_258h);
                        *(undefined8 *)(puVar28 + -8) = 0x180049945;
                        piVar16 = (int64_t *)func_0x000180459890(0x98);
                        *(int64_t **)(puVar28 + 0x50) = piVar16;
                        *piVar16 = var_1a8h;
                        var_228h = (int64_t)piVar16;
                        *(undefined8 *)(puVar28 + -8) = 0x18004996b;
                        func_0x00018000b4d0(piVar16 + 1, &var_1a0h);
                        *(undefined (*) [16])(piVar16 + 5) = ZEXT816(0);
                        piVar16[7] = (int64_t)puVar34;
                        piVar16[8] = (int64_t)puVar34;
                        piVar16[5] = CONCAT71(var_180h._1_7_, (undefined)var_180h);
                        piVar16[6] = var_178h;
                        piVar16[7] = var_170h;
                        piVar16[8] = var_168h;
                        var_168h = 0xf;
                        var_180h._0_1_ = 0;
                        *(undefined *)(piVar16 + 9) = (undefined)var_160h;
                        piVar16[10] = var_158h;
                        piVar16[0xb] = var_150h;
                        piVar16[0xc] = var_148h;
                        var_170h = (int64_t)puVar34;
                        var_158h = (int64_t)puVar34;
                        var_150h = (int64_t)puVar34;
                        var_148h = (int64_t)puVar34;
                        *(undefined8 *)(puVar28 + -8) = 0x180049a10;
                        func_0x00018004c700(piVar16 + 0xd, &var_140h);
                        *(undefined4 *)(piVar16 + 0xf) = (undefined4)var_130h;
                        piVar16[0x10] = (int64_t)puVar34;
                        piVar16[0x11] = (int64_t)puVar34;
                        piVar16[0x10] = var_128h;
                        piVar16[0x11] = var_120h;
                        _var_128h = ZEXT816(0);
                        piVar16[0x12] = var_118h;
                        var_228h = (int64_t)piVar16;
                        *(int64_t **)(puVar28 + 0x28) = &var_260h;
                        *(int32_t *)(puVar28 + 0x20) = (int32_t)puVar34;
                        *(undefined8 *)(puVar28 + -8) = 0x180049a81;
                        iVar20 = func_0x00018045f6e8(0, 0, 0x18004ad00, piVar16);
                        var_268h = iVar20;
                        if (iVar20 != 0) {
                            *(undefined8 *)(puVar28 + -8) = 0x180049a97;
                            func_0x000180004c40(&var_268h);
                            *(undefined8 *)(puVar28 + -8) = 0x180049aa1;
                            func_0x000180004ab0(&var_268h);
                            *(undefined8 *)(puVar28 + -8) = 0x180049aae;
                            func_0x000180049f80(&var_1a8h);
                            *(undefined8 *)(puVar28 + -8) = 0x180049ab8;
                            func_0x000180049f80(&var_2f8h);
                            *(undefined8 *)(puVar28 + -8) = 0x180049ac2;
                            func_0x000180094040(arg1, 0);
                            *(undefined8 *)(puVar28 + -8) = 0x180049ace;
                            func_0x000180008300(puVar28 + 0x60);
                            *(undefined8 *)(puVar28 + -8) = 0x180049ad9;
                            func_0x00018003e790(puVar28 + 0x78);
                            uVar17 = *(undefined8 *)(*(int64_t *)(puVar28 + 0x40) + 8);
                            *(undefined8 *)(puVar28 + -8) = 0x180049af2;
                            func_0x000180015170(puVar28 + 0x40, puVar28 + 0x40, uVar17);
                            *(undefined8 *)(puVar28 + -8) = 0x180049b01;
                            func_0x000180459c3c(*(undefined8 *)(puVar28 + 0x40), 0x60);
                            if (0xf < (uint64_t)var_1b0h) {
                                iVar20 = var_1c8h;
                                *(undefined8 *)(puVar28 + -8) = 0x180049b22;
                                func_0x000180005a60(&var_1c8h, iVar20);
                            }
                            if (0xf < (uint64_t)var_1d0h) {
                                iVar20 = var_1e8h;
                                *(undefined8 *)(puVar28 + -8) = 0x180049b43;
                                func_0x000180005a60(&var_1e8h, iVar20);
                            }
                            uVar33 = var_68h ^ (uint64_t)puVar28;
                            *(undefined8 *)(puVar28 + -8) = 0x180049b54;
                            func_0x000180459870(uVar33);
                            return;
                        }
                        goto code_r0x000180049f50;
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x180049453;
                    func_0x000180086510(arg1);
                    *(undefined8 *)(puVar28 + -8) = 0x180049460;
                    iVar15 = func_0x000180087970(arg1, 0xfffffffe);
                    while( true ) {
                        if (iVar15 == 0) goto code_r0x0001800497dd;
                        iVar20 = *(int64_t *)(arg1 + 0x40);
                        if ((((int64_t *)(iVar20 - 0x10U) == *(int64_t **)0x180782430) ||
                            (*(int32_t *)(iVar20 + -4) != 6)) ||
                           (((int64_t *)(iVar20 - 0x20U) == *(int64_t **)0x180782430 ||
                            (*(int32_t *)(iVar20 + -0x14) != 6)))) goto code_r0x000180049f40;
                        iVar19 = *(int64_t *)(iVar20 - 0x20U);
                        uVar32 = (uint64_t)*(uint32_t *)(iVar19 + 0x14);
                        iVar19 = iVar19 + 0x18;
                        uVar30 = *(uint32_t *)(*(int64_t *)(iVar20 + -0x10) + 0x14);
                        uVar33 = (uint64_t)uVar30;
                        iVar20 = *(int64_t *)(iVar20 + -0x10) + 0x18;
                        var_218h = 1;
                        var_210h = 0xf;
                        stack0xfffffffffffffdda = SUB1614(ZEXT816(0), 2);
                        var_228h._0_2_ = 0x2f;
                        var_f0h = 0xf;
                        stack0xfffffffffffffef9 = SUB1615(ZEXT816(0), 1);
                        auVar12[15] = 0;
                        auVar12._0_15_ = stack0xfffffffffffffef9;
                        _var_108h = auVar12 << 8;
                        _var_268h = ZEXT816(0);
                        var_f8h = (int64_t)puVar34;
                        if (uVar33 < 0x10) {
                            var_250h = 0xf;
                            var_258h = uVar33;
                            *(undefined8 *)(puVar28 + -8) = 0x180049530;
                            func_0x000180498030(&var_268h, iVar20, uVar30);
                            *(undefined *)((int64_t)&var_268h + uVar33) = 0;
                        } else {
                            uVar21 = uVar33 | 0xf;
                            if (uVar21 < 0x8000000000000000) {
                                if (uVar21 < 0x16) {
                                    uVar21 = 0x16;
                                }
                            } else {
                                uVar21 = 0x7fffffffffffffff;
                            }
                            var_258h = (int64_t)puVar34;
                            var_250h = (int64_t)puVar34;
                            *(uint64_t *)(puVar28 + 0x30) = uVar21;
                            *(undefined8 *)(puVar28 + -8) = 0x180049572;
                            iVar22 = func_0x000180004930(&var_268h, puVar28 + 0x30);
                            var_268h = iVar22;
                            var_258h = uVar33;
                            var_250h = *(int64_t *)(puVar28 + 0x30);
                            *(undefined8 *)(puVar28 + -8) = 0x180049594;
                            func_0x000180498030(iVar22, iVar20, uVar33);
                            *(undefined *)(iVar22 + uVar33) = 0;
                        }
                        _var_248h = ZEXT816(0);
                        if (uVar32 < 0x10) {
                            var_230h = 0xf;
                            var_238h = uVar32;
                            *(undefined8 *)(puVar28 + -8) = 0x1800495c8;
                            func_0x000180498030(&var_248h, iVar19, uVar32);
                            *(undefined *)((int64_t)&var_248h + uVar32) = 0;
                        } else {
                            uVar33 = uVar32 | 0xf;
                            if (uVar33 < 0x8000000000000000) {
                                if (uVar33 < 0x16) {
                                    uVar33 = 0x16;
                                }
                            } else {
                                uVar33 = 0x7fffffffffffffff;
                            }
                            var_238h = (int64_t)puVar34;
                            var_230h = (int64_t)puVar34;
                            *(uint64_t *)(puVar28 + 0x30) = uVar33;
                            *(undefined8 *)(puVar28 + -8) = 0x18004960a;
                            iVar20 = func_0x000180004930(&var_248h, puVar28 + 0x30);
                            var_248h = iVar20;
                            var_238h = uVar32;
                            var_230h = *(int64_t *)(puVar28 + 0x30);
                            *(undefined8 *)(puVar28 + -8) = 0x18004962c;
                            func_0x000180498030(iVar20, iVar19, uVar32);
                            *(undefined *)(iVar20 + uVar32) = 0;
                        }
                        *(undefined8 *)(puVar28 + -8) = 0x180049640;
                        func_0x00018000b4d0(&var_1a8h, &var_248h);
                        *(undefined8 *)(puVar28 + -8) = 0x180049651;
                        func_0x00018000b4d0(&var_188h, &var_268h);
                        *(undefined8 *)(puVar28 + -8) = 0x180049665;
                        func_0x00018000b4d0(&var_168h, &var_108h);
                        var_148h = var_148h & 0xffffffffffffff00;
                        *(undefined8 *)(puVar28 + -8) = 0x18004967d;
                        func_0x00018000b4d0(&var_140h, &var_228h);
                        var_120h._0_1_ = 0;
                        var_118h = (int64_t)puVar34;
                        *(undefined8 *)(puVar28 + -8) = 0x18004969c;
                        func_0x00018016c230(puVar28 + 0x70, &var_1a8h);
                        *(undefined8 *)(puVar28 + -8) = 0x1800496a9;
                        func_0x000180004e40(&var_140h);
                        *(undefined8 *)(puVar28 + -8) = 0x1800496b5;
                        func_0x000180004e40(&var_168h);
                        *(undefined8 *)(puVar28 + -8) = 0x1800496c1;
                        func_0x000180004e40(&var_188h);
                        *(undefined8 *)(puVar28 + -8) = 0x1800496cd;
                        func_0x000180004e40(&var_1a8h);
                        if (0xf < (uint64_t)var_230h) break;
code_r0x00018004970a:
                        if (0xf < (uint64_t)var_250h) {
                            uVar33 = var_250h + 1;
                            iVar20 = var_268h;
                            if (0xfff < uVar33) {
                                iVar20 = *(int64_t *)(var_268h + -8);
                                if (0x1f < (var_268h - iVar20) - 8U) goto code_r0x000180049b77;
                                uVar33 = var_250h + 0x28;
                            }
                            *(undefined8 *)(puVar28 + -8) = 0x180049745;
                            func_0x000180459c3c(iVar20, uVar33);
                        }
                        if (0xf < (uint64_t)var_f0h) {
                            uVar33 = var_f0h + 1;
                            iVar20 = var_108h;
                            if (0xfff < uVar33) {
                                iVar20 = *(int64_t *)(var_108h + -8);
                                if (0x1f < (var_108h - iVar20) - 8U) goto code_r0x000180049b7e;
                                uVar33 = var_f0h + 0x28;
                            }
                            *(undefined8 *)(puVar28 + -8) = 0x180049787;
                            func_0x000180459c3c(iVar20, uVar33);
                        }
                        if (0xf < (uint64_t)var_210h) {
                            uVar33 = var_210h + 1;
                            iVar20 = var_228h;
                            if (0xfff < uVar33) {
                                iVar20 = *(int64_t *)(var_228h + -8);
                                if (0x1f < (var_228h - iVar20) - 8U) goto code_r0x000180049b85;
                                uVar33 = var_210h + 0x28;
                            }
                            *(undefined8 *)(puVar28 + -8) = 0x1800497c3;
                            func_0x000180459c3c(iVar20, uVar33);
                        }
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        *(undefined8 *)(puVar28 + -8) = 0x1800497d5;
                        iVar15 = func_0x000180087970(arg1, 0xfffffffe);
                    }
                    uVar33 = var_230h + 1;
                    iVar20 = var_248h;
                    if (uVar33 < 0x1000) {
code_r0x000180049704:
                        *(undefined8 *)(puVar28 + -8) = 0x180049709;
                        func_0x000180459c3c(iVar20, uVar33);
                        goto code_r0x00018004970a;
                    }
                    iVar20 = *(int64_t *)(var_248h + -8);
                    if ((var_248h - iVar20) - 8U < 0x20) {
                        uVar33 = var_230h + 0x28;
                        goto code_r0x000180049704;
                    }
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar28 = puVar28 + 8;
code_r0x000180049b77:
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar28 = puVar28 + 8;
code_r0x000180049b7e:
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar28 = puVar28 + 8;
code_r0x000180049b85:
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar29 = puVar28 + 8;
code_r0x000180049b8c:
                    *(undefined8 *)(puVar29 + -8) = 0x180049b99;
                    func_0x0001800858c0(arg1, 0xfffffffe);
                    *(undefined8 *)(puVar29 + -8) = 0x180049ba8;
                    func_0x000180088560(arg1, 0x180623818);
code_r0x000180049ba9:
                    *(undefined8 *)(puVar29 + -8) = 0x180049bb5;
                    func_0x000180459d18(0x1807828a0);
                    puVar27 = puVar29;
                } while (*(int32_t *)0x1807828a0 != -1);
                var_e8h = 0x180623834;
                var_e0h = 3;
                var_d8h._0_4_ = 1;
                var_d0h = 0x180623848;
                var_c8h = 4;
                var_c0h._0_4_ = 2;
                var_b8h = 0x180623840;
                var_b0h = 5;
                var_a8h._0_4_ = 3;
                var_a0h = 0x180623858;
                var_98h = 3;
                var_90h._0_4_ = 4;
                *(undefined8 *)(puVar29 + -8) = 0x180049c61;
                func_0x000180005d50(&var_88h, 0x180623850);
                var_78h._0_4_ = 5;
                *(undefined8 *)(puVar29 + -8) = 0x180049c75;
                *(int64_t *)0x180782868 = func_0x000180459890(0x28);
                *(int64_t *)*(int64_t *)0x180782868 = *(int64_t *)0x180782868;
                *(int64_t *)(*(int64_t *)0x180782868 + 8) = *(int64_t *)0x180782868;
                *(undefined (*) [16])0x180782880 = ZEXT816(0);
                *(uint64_t *)0x180782890 = 7;
                *(uint64_t *)0x180782898 = 8;
                *(float *)0x180782860 = 1.0;
                *(undefined8 *)(puVar29 + -8) = 0x180049cc9;
                *(undefined8 **)0x180782878 = puVar34;
                fVar35 = (float)func_0x00018000f7e0(0x180782878, 0x10, *(int64_t *)0x180782868);
                unaff_R15 = &var_e8h;
                unaff_XMM6_Da = 9.223372e+18;
                puVar28 = puVar29;
            }
            *(undefined8 *)(puVar28 + -8) = 0x180049cf8;
            unaff_RDI = func_0x00018004a460(fVar35, unaff_R15);
            *(undefined8 *)(puVar28 + -8) = 0x180049d0b;
            fVar35 = (float)func_0x00018004a560(extraout_XMM0_Da, puVar28 + 0x30, unaff_R15, unaff_RDI);
        } while (*(int64_t *)(puVar28 + 0x38) != 0);
        if (*(int64_t *)0x180782870 == 0x666666666666666) {
code_r0x000180049ef2:
            *(undefined8 *)(puVar28 + -8) = 0x180049efe;
            func_0x0001804546d4(0x180620428);
code_r0x000180049eff:
            *(undefined8 *)(puVar28 + -8) = 0x180049f0b;
            uVar17 = func_0x00018000b450(&var_208h);
            *(undefined8 *)(puVar28 + -8) = 0x180049f1d;
            func_0x000180088560(arg1, 0x180623890, uVar17);
code_r0x000180049f1e:
            *(undefined8 *)(puVar28 + -8) = 0x180049f23;
            func_0x000180004720();
code_r0x000180049f24:
            *(undefined8 *)(puVar28 + -8) = 0x180049f29;
            func_0x000180004720();
code_r0x000180049f2a:
            *(undefined8 *)(puVar28 + -8) = 0x180049f2f;
            func_0x000180013c00();
code_r0x000180049f30:
            *(undefined8 *)(puVar28 + -8) = 0x180049f3f;
            func_0x000180088560(arg1, 0x180623860);
code_r0x000180049f40:
            *(undefined8 *)(puVar28 + -8) = 0x180049f4f;
            func_0x000180088560(arg1, 0x1806238b0);
code_r0x000180049f50:
            var_260h._0_4_ = (int32_t)puVar34;
            *(undefined8 *)(puVar28 + -8) = 0x180049f5e;
            func_0x0001804542e8(6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        var_220h = (int64_t)puVar34;
        var_228h = 0x180782868;
        *(undefined8 *)(puVar28 + -8) = 0x180049d36;
        unaff_RSI = (int64_t *)func_0x000180459890(0x28);
        var_220h = (int64_t)unaff_RSI;
        uVar36 = *(undefined4 *)((int64_t)unaff_R15 + 4);
        uVar5 = *(undefined4 *)(unaff_R15 + 1);
        uVar6 = *(undefined4 *)((int64_t)unaff_R15 + 0xc);
        *(undefined4 *)(unaff_RSI + 2) = *(undefined4 *)unaff_R15;
        *(undefined4 *)((int64_t)unaff_RSI + 0x14) = uVar36;
        *(undefined4 *)(unaff_RSI + 3) = uVar5;
        *(undefined4 *)((int64_t)unaff_RSI + 0x1c) = uVar6;
        unaff_RSI[4] = unaff_R15[2];
        uVar33 = *(int64_t *)0x180782870 + 1;
        if ((int64_t)uVar33 < 0) {
            fVar35 = (float)(uVar33 >> 1 | (uint64_t)((uint32_t)uVar33 & 1));
            fVar35 = fVar35 + fVar35;
        } else {
            fVar35 = (float)uVar33;
        }
        iVar20 = *(int64_t *)0x180782870;
        unaff_RBX = *(uint64_t *)0x180782898;
        if ((int64_t)*(uint64_t *)0x180782898 < 0) goto code_r0x000180049d99;
        fVar37 = (float)*(uint64_t *)0x180782898;
    } while( true );
}

// ============================================================
// Function: FUN_180049f60
// Address: 0x180049f60
// Size: 32 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018004a1d8: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004a1dd)
// WARNING: Removing unreachable block (ram,0x00018004a1e5)

void fcn.180049f60(int64_t arg1, int64_t arg_38h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    undefined8 unaff_RBX;
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    auStack_30[0] = 0x180049f72;
    func_0x00018000ace0(arg1 + 0x18);
    piVar4 = *(int64_t **)(arg1 + 8);
    *(undefined8 *)piVar4[1] = 0;
    piVar4 = (int64_t *)*piVar4;
    if (piVar4 == (int64_t *)0x0) {
        piVar4 = *(int64_t **)(arg1 + 8);
    } else {
        unaff_RBX = *piVar4;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18004a1dd;
    }
    if (piVar4 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, piVar4);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar2 = func_0x00018046b63c(uVar2);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar3 = (undefined4 *)func_0x00018046b77c();
            *puVar3 = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180049f80
// Address: 0x180049f80
// Size: 25 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180049fff: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004a004)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180049f80(int64_t arg1, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t *piStack_38;
    undefined8 uStack_30;
    
    piVar5 = *(int64_t **)(arg1 + 0x88);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            uStack_30 = 0x180049fb7;
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                uStack_30 = 0x180049fca;
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    uStack_30 = 0x180049fe4;
    func_0x000180015170(arg1 + 0x68, arg1 + 0x68, *(undefined8 *)(*(int64_t *)(arg1 + 0x68) + 8));
    uStack_30 = 0x180049ff2;
    func_0x000180459c3c(*(undefined8 *)(arg1 + 0x68), 0x60);
    uStack_30 = 0x180049ffb;
    func_0x00018003e790(arg1 + 0x50);
    uStack_30 = 0x18004a004;
    if (0xf < *(uint64_t *)(arg1 + 0x40)) {
        iVar4 = *(int64_t *)(arg1 + 0x28);
        iVar7 = iVar4;
        puVar8 = auStack_58;
        piStack_38 = piVar5;
        if ((0xfff < *(uint64_t *)(arg1 + 0x40) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_58, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_50;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x28) = 0;
    return;
}

// ============================================================
// Function: FUN_180049f99
// Address: 0x180049f99
// Size: 54 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180049fff: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004a004)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180049f80(int64_t arg1, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t *piStack_38;
    undefined8 uStack_30;
    
    piVar5 = *(int64_t **)(arg1 + 0x88);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            uStack_30 = 0x180049fb7;
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                uStack_30 = 0x180049fca;
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    uStack_30 = 0x180049fe4;
    func_0x000180015170(arg1 + 0x68, arg1 + 0x68, *(undefined8 *)(*(int64_t *)(arg1 + 0x68) + 8));
    uStack_30 = 0x180049ff2;
    func_0x000180459c3c(*(undefined8 *)(arg1 + 0x68), 0x60);
    uStack_30 = 0x180049ffb;
    func_0x00018003e790(arg1 + 0x50);
    uStack_30 = 0x18004a004;
    if (0xf < *(uint64_t *)(arg1 + 0x40)) {
        iVar4 = *(int64_t *)(arg1 + 0x28);
        iVar7 = iVar4;
        puVar8 = auStack_58;
        piStack_38 = piVar5;
        if ((0xfff < *(uint64_t *)(arg1 + 0x40) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_58, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_50;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x28) = 0;
    return;
}

// ============================================================
// Function: FUN_180049fcf
// Address: 0x180049fcf
// Size: 72 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180049fff: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004a004)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180049f80(int64_t arg1, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t *piStack_38;
    undefined8 uStack_30;
    
    piVar5 = *(int64_t **)(arg1 + 0x88);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            uStack_30 = 0x180049fb7;
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                uStack_30 = 0x180049fca;
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    uStack_30 = 0x180049fe4;
    func_0x000180015170(arg1 + 0x68, arg1 + 0x68, *(undefined8 *)(*(int64_t *)(arg1 + 0x68) + 8));
    uStack_30 = 0x180049ff2;
    func_0x000180459c3c(*(undefined8 *)(arg1 + 0x68), 0x60);
    uStack_30 = 0x180049ffb;
    func_0x00018003e790(arg1 + 0x50);
    uStack_30 = 0x18004a004;
    if (0xf < *(uint64_t *)(arg1 + 0x40)) {
        iVar4 = *(int64_t *)(arg1 + 0x28);
        iVar7 = iVar4;
        puVar8 = auStack_58;
        piStack_38 = piVar5;
        if ((0xfff < *(uint64_t *)(arg1 + 0x40) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_58, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_50;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x28) = 0;
    return;
}

// ============================================================
// Function: FUN_18004a020
// Address: 0x18004a020
// Size: 372 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018004a071: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004a0bc: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004a160: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004a106: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004a0c1)
// WARNING: Removing unreachable block (ram,0x00018004a0d0)
// WARNING: Removing unreachable block (ram,0x00018004a0f2)
// WARNING: Removing unreachable block (ram,0x00018004a0fe)
// WARNING: Removing unreachable block (ram,0x00018004a0f8)
// WARNING: Removing unreachable block (ram,0x00018004a10b)
// WARNING: Removing unreachable block (ram,0x00018004a119)
// WARNING: Removing unreachable block (ram,0x00018004a076)
// WARNING: Removing unreachable block (ram,0x00018004a165)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18004a020(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_a8 [32];
    undefined8 uStack_88;
    undefined4 uStack_7c;
    uint64_t uStack_78;
    int64_t iStack_68;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    func_0x000180018f70();
    iVar4 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    func_0x0001800869f0(arg2, 0x180047c30, 0x1806238e8, 0);
    uStack_78 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = (int32_t)iVar4;
    iStack_68 = iVar4;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            uVar3 = func_0x000180085370();
        } else {
            uVar3 = (int64_t)iVar2 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar3 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar3) {
            uVar3 = *(uint64_t *)0x180782430;
        }
    }
    piVar5 = (int64_t *)(arg2 + 0x40);
    uVar1 = func_0x000180498cd0(0x1806238e8);
    uStack_88 = func_0x00018009a8e0(arg2, 0x1806238e8, uVar1);
    uStack_7c = 6;
    func_0x0001800a8680(arg2, uVar3, &uStack_88, *piVar5 + -0x10);
    *piVar5 = *piVar5 + -0x10;
    func_0x000180459870(uStack_78 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_18004a1a0
// Address: 0x18004a1a0
// Size: 31 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018004a1d8: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004a1dd)
// WARNING: Removing unreachable block (ram,0x00018004a1e5)

void fcn.180049f60(int64_t arg1, int64_t arg_38h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    undefined8 unaff_RBX;
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    auStack_30[0] = 0x180049f72;
    func_0x00018000ace0(arg1 + 0x18);
    piVar4 = *(int64_t **)(arg1 + 8);
    *(undefined8 *)piVar4[1] = 0;
    piVar4 = (int64_t *)*piVar4;
    if (piVar4 == (int64_t *)0x0) {
        piVar4 = *(int64_t **)(arg1 + 8);
    } else {
        unaff_RBX = *piVar4;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18004a1dd;
    }
    if (piVar4 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, piVar4);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar2 = func_0x00018046b63c(uVar2);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar3 = (undefined4 *)func_0x00018046b77c();
            *puVar3 = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004a1bf
// Address: 0x18004a1bf
// Size: 43 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018004a1d8: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004a1dd)
// WARNING: Removing unreachable block (ram,0x00018004a1e5)

void fcn.180049f60(int64_t arg1, int64_t arg_38h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    undefined8 unaff_RBX;
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    auStack_30[0] = 0x180049f72;
    func_0x00018000ace0(arg1 + 0x18);
    piVar4 = *(int64_t **)(arg1 + 8);
    *(undefined8 *)piVar4[1] = 0;
    piVar4 = (int64_t *)*piVar4;
    if (piVar4 == (int64_t *)0x0) {
        piVar4 = *(int64_t **)(arg1 + 8);
    } else {
        unaff_RBX = *piVar4;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18004a1dd;
    }
    if (piVar4 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, piVar4);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar2 = func_0x00018046b63c(uVar2);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar3 = (undefined4 *)func_0x00018046b77c();
            *puVar3 = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004a1ea
// Address: 0x18004a1ea
// Size: 18 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018004a1d8: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004a1dd)
// WARNING: Removing unreachable block (ram,0x00018004a1e5)

void fcn.180049f60(int64_t arg1, int64_t arg_38h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    undefined8 unaff_RBX;
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    auStack_30[0] = 0x180049f72;
    func_0x00018000ace0(arg1 + 0x18);
    piVar4 = *(int64_t **)(arg1 + 8);
    *(undefined8 *)piVar4[1] = 0;
    piVar4 = (int64_t *)*piVar4;
    if (piVar4 == (int64_t *)0x0) {
        piVar4 = *(int64_t **)(arg1 + 8);
    } else {
        unaff_RBX = *piVar4;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18004a1dd;
    }
    if (piVar4 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, piVar4);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar2 = func_0x00018046b63c(uVar2);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar3 = (undefined4 *)func_0x00018046b77c();
            *puVar3 = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004a200
// Address: 0x18004a200
// Size: 323 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

undefined8 * fcn.18004a200(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    char cVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    uint32_t uVar11;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar9 = *(undefined8 **)arg1;
    puVar10 = (undefined8 *)puVar9[1];
    uVar11 = 0;
    cVar8 = *(char *)((int64_t)puVar10 + 0x19);
    puVar7 = puVar10;
    while (puVar6 = puVar10, cVar8 == '\0') {
        cVar8 = func_0x00018016b240(arg1, puVar6 + 4, arg2);
        if (cVar8 == '\0') {
            puVar10 = (undefined8 *)*puVar6;
            puVar9 = puVar6;
        } else {
            puVar10 = (undefined8 *)puVar6[2];
        }
        uVar11 = (uint32_t)(cVar8 == '\0');
        cVar8 = *(char *)((int64_t)puVar10 + 0x19);
        puVar7 = puVar6;
    }
    if ((*(char *)((int64_t)puVar9 + 0x19) != '\0') ||
       (cVar8 = func_0x00018016b240(arg1, arg2, puVar9 + 4), cVar8 != '\0')) {
        if (*(int64_t *)(arg1 + 8) == 0x2aaaaaaaaaaaaaa) {
            func_0x000180013c00();
            pcVar2 = (code *)swi(3);
            puVar9 = (undefined8 *)(*pcVar2)();
            return puVar9;
        }
        uVar1 = *(undefined8 *)arg1;
        var_50h = 0;
        var_58h = arg1;
        puVar9 = (undefined8 *)func_0x000180459890(0x60);
        *(undefined (*) [16])(puVar9 + 4) = ZEXT816(0);
        puVar9[6] = 0;
        puVar9[7] = 0;
        uVar3 = *(undefined4 *)(arg2 + 4);
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar5 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)(puVar9 + 4) = *(undefined4 *)arg2;
        *(undefined4 *)((int64_t)puVar9 + 0x24) = uVar3;
        *(undefined4 *)(puVar9 + 5) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x2c) = uVar5;
        uVar3 = *(undefined4 *)(arg2 + 0x14);
        uVar4 = *(undefined4 *)(arg2 + 0x18);
        uVar5 = *(undefined4 *)(arg2 + 0x1c);
        *(undefined4 *)(puVar9 + 6) = *(undefined4 *)(arg2 + 0x10);
        *(undefined4 *)((int64_t)puVar9 + 0x34) = uVar3;
        *(undefined4 *)(puVar9 + 7) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x3c) = uVar5;
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        *(undefined (*) [16])(puVar9 + 8) = ZEXT816(0);
        puVar9[10] = 0;
        puVar9[0xb] = 0xf;
        *(undefined *)(puVar9 + 8) = 0;
        *puVar9 = uVar1;
        puVar9[1] = uVar1;
        puVar9[2] = uVar1;
        *(undefined2 *)(puVar9 + 3) = 0;
        var_50h = CONCAT44(var_50h._4_4_, uVar11);
        var_58h = (int64_t)puVar7;
        puVar9 = (undefined8 *)func_0x0001800156d0(arg1, &var_58h, puVar9);
    }
    return puVar9 + 8;
}

// ============================================================
// Function: FUN_18004a3c0
// Address: 0x18004a3c0
// Size: 112 bytes
// ============================================================
uint64_t fcn.18004a3c0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    uint64_t uVar2;
    
    uVar1 = func_0x000180498cd0(arg4);
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)arg3) {
        arg3 = *(uint64_t *)(arg1 + 0x10);
    }
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    uVar2 = arg3;
    if (uVar1 < (uint64_t)arg3) {
        uVar2 = uVar1;
    }
    uVar2 = func_0x000180497f30(arg1, arg4, uVar2);
    if ((int32_t)uVar2 == 0) {
        if ((uint64_t)arg3 < uVar1) {
            return 0xffffffff;
        }
        uVar2 = (uint64_t)(uVar1 < (uint64_t)arg3);
    }
    return uVar2;
}

// ============================================================
// Function: FUN_18004a4b0
// Address: 0x18004a4b0
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18004a4b0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 0x78);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x58);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x20));
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18004a4ba
// Address: 0x18004a4ba
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18004a4b0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 0x78);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x58);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x20));
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18004a4c7
// Address: 0x18004a4c7
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18004a4b0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 0x78);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x58);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x20));
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18004a4fd
// Address: 0x18004a4fd
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18004a4b0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 0x78);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x58);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x20));
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18004a50f
// Address: 0x18004a50f
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18004a4b0(int64_t arg1, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 0x78);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x58);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x20));
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18004a530
// Address: 0x18004a530
// Size: 43 bytes
// ============================================================
int64_t fcn.18004a530(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180623990;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x88);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18004a560
// Address: 0x18004a560
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18004a560(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = (int64_t *)((*(uint64_t *)0x180782890 & arg4) * 0x10 + *(int64_t *)0x180782878);
    puVar5 = (undefined8 *)piVar6[1];
    if (puVar5 == *(undefined8 **)0x180782868) {
        *(undefined8 **)arg2 = *(undefined8 **)0x180782868;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    puVar1 = (undefined8 *)*piVar6;
    iVar2 = *(int64_t *)(arg3 + 8);
    uVar3 = *(undefined8 *)arg3;
    while ((iVar2 != puVar5[3] || ((iVar2 != 0 && (iVar4 = fcn.180497f30(uVar3, puVar5[2], iVar2), iVar4 != 0))))) {
        if (puVar5 == puVar1) {
            *(undefined8 **)arg2 = puVar5;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        puVar5 = (undefined8 *)puVar5[1];
    }
    *(undefined8 *)arg2 = *puVar5;
    *(undefined8 **)(arg2 + 8) = puVar5;
    return arg2;
}

// ============================================================
// Function: FUN_18004a630
// Address: 0x18004a630
// Size: 680 bytes
// ============================================================
void fcn.18004a630(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *piVar7;
    undefined8 *puVar8;
    undefined8 uVar9;
    undefined auStack_238 [32];
    int64_t var_218h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_180h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_238;
    uVar3 = *(undefined8 *)(arg1 + 0x38);
    uVar5 = func_0x000180459890(0x80);
    var_208h = 0;
    var_200h = 0;
    var_208h = func_0x000180459890(0x60);
    *(int64_t *)var_208h = var_208h;
    *(int64_t *)(var_208h + 8) = var_208h;
    *(int64_t *)(var_208h + 0x10) = var_208h;
    *(undefined2 *)(var_208h + 0x18) = 0x101;
    var_1f8h = CONCAT71(var_1f8h._1_7_, 1);
    _var_1f0h = ZEXT816(0);
    var_1e0h = 0;
    var_218h._0_4_ = 0;
    iVar6 = func_0x000180083a90(uVar5, arg1 + 8, &var_1f8h, &var_208h);
    func_0x000180084280(iVar6, &var_198h, 1);
    piVar7 = (int64_t *)func_0x0001800137d0();
    var_208h = *piVar7;
    func_0x00018000b4d0(&var_1f8h, &var_180h);
    puVar8 = (undefined8 *)func_0x000180459890(0x88);
    *(undefined4 *)(puVar8 + 1) = 1;
    *(undefined4 *)((int64_t)puVar8 + 0xc) = 1;
    *puVar8 = 0x180623990;
    uVar5 = *(undefined8 *)arg1;
    var_1d8h = 0x180623930;
    var_1c8h = var_1f0h;
    var_1d0h = var_1f8h;
    var_1c0h = var_1e8h;
    var_1b8h = var_1e0h;
    var_1a0h = (int64_t)&var_1d8h;
    *(undefined4 *)(puVar8 + 3) = 2;
    puVar8[2] = 0x180623918;
    puVar8[0xb] = 0;
    uVar9 = (*(code *)0x18004c480)(&var_1d8h, puVar8 + 4);
    puVar8[0xb] = uVar9;
    puVar8[0xc] = uVar5;
    puVar8[0xd] = uVar3;
    puVar8[0xe] = 0;
    puVar8[0xf] = 0;
    if (*(int64_t *)(arg1 + 0x30) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x30) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    puVar8[0xe] = *(undefined8 *)(arg1 + 0x28);
    puVar8[0xf] = *(undefined8 *)(arg1 + 0x30);
    *(undefined *)(puVar8 + 0x10) = 0;
    *(undefined4 *)(puVar8 + 3) = 1;
    if (var_1a0h != 0) {
        (**(code **)(*(int64_t *)var_1a0h + 0x20))
                  (var_1a0h, CONCAT71((unkint7)((uint64_t)&var_1d8h >> 8), (int64_t *)var_1a0h != &var_1d8h));
    }
    var_1f0h = (int64_t)puVar8;
    var_1f8h = (int64_t)(puVar8 + 2);
    func_0x00018000a9d0(var_208h, &var_1f8h);
    iVar4 = var_1f0h;
    if (var_1f0h != 0) {
        LOCK();
        piVar1 = (int32_t *)(var_1f0h + 8);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (***(code ***)var_1f0h)(var_1f0h);
            LOCK();
            piVar1 = (int32_t *)(iVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*(int64_t *)iVar4 + 8))(iVar4);
            }
        }
    }
    func_0x00018003c510(&var_198h);
    if (iVar6 != 0) {
        func_0x000180015170(iVar6 + 0x70, iVar6 + 0x70, *(undefined8 *)(*(int64_t *)(iVar6 + 0x70) + 8));
        fcn.180459c3c(*(undefined8 *)(iVar6 + 0x70), 0x60);
        func_0x00018003e790(iVar6 + 0x58);
        func_0x000180004e40(iVar6 + 0x30);
        func_0x000180004e40(iVar6 + 8);
        fcn.180459c3c(iVar6, 0x80);
    }
    func_0x00018045476c();
    func_0x000180048130(arg1);
    fcn.180459c3c(arg1, 0x40);
    func_0x000180459870(var_58h ^ (uint64_t)auStack_238);
    return;
}

// ============================================================
// Function: FUN_18004a8e0
// Address: 0x18004a8e0
// Size: 1054 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2eeh
// WARNING: [rz-ghidra] Detected overlap for variable var_2ech
// WARNING: [rz-ghidra] Detected overlap for variable var_38ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

void fcn.18004a8e0(int64_t arg1)
{
    undefined8 uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    char cVar5;
    int64_t iVar6;
    int64_t *piVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    undefined8 *puVar12;
    uint64_t uVar13;
    undefined *puVar14;
    undefined auStack_3d8 [8];
    undefined auStack_3d0 [24];
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_390h;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_318h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    undefined auStack_2d8 [320];
    int64_t var_198h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3d8;
    uVar1 = *(undefined8 *)(arg1 + 0x78);
    var_3a8h = 0;
    var_3a0h = 0;
    iVar6 = func_0x000180459890(0x60);
    *(int64_t *)iVar6 = iVar6;
    *(int64_t *)(iVar6 + 8) = iVar6;
    *(int64_t *)(iVar6 + 0x10) = iVar6;
    *(undefined2 *)(iVar6 + 0x18) = 0x101;
    var_2e8h = 10;
    var_2e0h = 0xf;
    var_2f0h._0_2_ = 0x746e;
    var_2f8h = 0x6567412d72657355;
    var_2f0h._2_6_ = 0;
    var_3a8h = iVar6;
    if ((*(char *)(iVar6 + 0x19) != '\0') ||
       (cVar5 = func_0x00018016b240(&var_3a8h, &var_2f8h, iVar6 + 0x20), cVar5 != '\0')) {
        iVar4 = var_3a8h;
        if (var_3a0h == 0x2aaaaaaaaaaaaaa) {
            func_0x000180013c00();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        piVar7 = (int64_t *)func_0x000180459890(0x60);
        var_390h._4_4_ = var_2f0h._4_4_;
        *(undefined4 *)(piVar7 + 4) = (undefined4)var_2f8h;
        *(undefined4 *)((int64_t)piVar7 + 0x24) = var_2f8h._4_4_;
        *(undefined4 *)(piVar7 + 5) = (undefined4)var_2f0h;
        *(undefined4 *)((int64_t)piVar7 + 0x2c) = var_2f0h._4_4_;
        *(undefined4 *)(piVar7 + 6) = (undefined4)var_2e8h;
        *(undefined4 *)((int64_t)piVar7 + 0x34) = var_2e8h._4_4_;
        *(undefined4 *)(piVar7 + 7) = (undefined4)var_2e0h;
        *(undefined4 *)((int64_t)piVar7 + 0x3c) = var_2e0h._4_4_;
        var_2e8h = 0;
        var_2e0h = 0xf;
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xfffffffffffffd09;
        _var_2f8h = auVar3 << 8;
        *(undefined (*) [16])(piVar7 + 8) = ZEXT816(0);
        piVar7[10] = 0;
        piVar7[0xb] = 0xf;
        *(undefined *)(piVar7 + 8) = 0;
        *piVar7 = iVar4;
        piVar7[1] = iVar4;
        piVar7[2] = iVar4;
        *(undefined2 *)(piVar7 + 3) = 0;
        var_390h._0_4_ = 0;
        var_398h = iVar6;
        iVar6 = func_0x0001800156d0(&var_3a8h, &var_398h, piVar7);
    }
    func_0x00018000f180(iVar6 + 0x40, 0x1806237b0, 0xe);
    if ((uint64_t)var_2e0h < 0x10) {
code_r0x00018004aa7e:
        puVar14 = auStack_3d8;
        if (*(int64_t *)(arg1 + 0x58) == 0) goto code_r0x00018004ab29;
        var_2e8h = 0xc;
        var_2e0h = 0xf;
        var_2f0h._0_4_ = 0x65707954;
        var_2f8h = 0x2d746e65746e6f43;
        var_2f0h._4_4_ = 0;
        piVar7 = (int64_t *)(arg1 + 0x48);
        iVar6 = fcn.18004a200((int64_t)&var_3a8h, (int64_t)&var_2f8h);
        if ((int64_t *)iVar6 != piVar7) {
            if (0xf < *(uint64_t *)(arg1 + 0x60)) {
                piVar7 = (int64_t *)*piVar7;
            }
            func_0x00018000f180(iVar6, piVar7, *(undefined8 *)(arg1 + 0x58));
        }
        puVar14 = auStack_3d8;
        if ((uint64_t)var_2e0h < 0x10) goto code_r0x00018004ab29;
        iVar6 = var_2f8h;
        puVar14 = auStack_3d8;
        if ((0xfff < var_2e0h + 1U) &&
           (iVar6 = *(int64_t *)(var_2f8h + -8), puVar14 = auStack_3d8,
           0x1f < (var_2f8h - *(int64_t *)(var_2f8h + -8)) - 8U)) goto code_r0x00018004ab1a;
    } else {
        uVar13 = var_2e0h + 1;
        iVar6 = var_2f8h;
        if (uVar13 < 0x1000) {
code_r0x00018004aa79:
            fcn.180459c3c(iVar6, uVar13);
            goto code_r0x00018004aa7e;
        }
        if ((var_2f8h - *(int64_t *)(var_2f8h + -8)) - 8U < 0x20) {
            uVar13 = var_2e0h + 0x28;
            iVar6 = *(int64_t *)(var_2f8h + -8);
            goto code_r0x00018004aa79;
        }
code_r0x00018004ab1a:
        pcVar2 = (code *)swi(0x29);
        iVar6 = (*pcVar2)(5);
        puVar14 = auStack_3d0;
    }
    *(undefined8 *)(puVar14 + -8) = 0x18004ab29;
    fcn.180459c3c(iVar6);
code_r0x00018004ab29:
    *(undefined8 *)(puVar14 + -8) = 0x18004ab33;
    uVar8 = func_0x000180459890(0x80);
    *(undefined8 *)(puVar14 + -8) = 0x18004ab44;
    uVar9 = func_0x00018003e190(&var_2f8h, puVar14 + 0x30);
    puVar14[0x40] = 1;
    *(undefined (*) [16])(puVar14 + 0x48) = ZEXT816(0);
    *(undefined8 *)(puVar14 + 0x58) = 0;
    *(undefined8 *)(puVar14 + -8) = 0x18004ab67;
    uVar10 = func_0x00018000b4d0(&var_338h, arg1 + 0x28);
    *(undefined8 *)(puVar14 + -8) = 0x18004ab77;
    uVar11 = func_0x00018000b4d0(&var_318h, arg1 + 8);
    *(undefined4 *)(puVar14 + 0x28) = 1;
    *(undefined8 *)(puVar14 + 0x20) = uVar9;
    *(undefined8 *)(puVar14 + -8) = 0x18004ab97;
    uVar8 = func_0x000180083dc0(uVar8, uVar11, uVar10, puVar14 + 0x40);
    *(undefined8 *)(puVar14 + 0x40) = uVar8;
    *(undefined8 *)(puVar14 + -8) = 0x18004abb1;
    func_0x000180084280(uVar8, &var_198h, 2);
    *(undefined8 *)(puVar14 + -8) = 0x18004abb6;
    puVar12 = (undefined8 *)func_0x0001800137d0();
    uVar8 = *puVar12;
    *(undefined8 *)(puVar14 + -8) = 0x18004abc9;
    func_0x00018003c320(auStack_2d8, &var_198h);
    *(undefined8 *)(puVar14 + -8) = 0x18004abd3;
    puVar12 = (undefined8 *)func_0x000180459890(0x88);
    *(undefined4 *)(puVar12 + 1) = 1;
    *(undefined4 *)((int64_t)puVar12 + 0xc) = 1;
    *puVar12 = 0x180623990;
    uVar9 = *(undefined8 *)arg1;
    *(undefined8 *)(puVar14 + -8) = 0x18004ac00;
    piVar7 = (int64_t *)func_0x000180459890(0x140);
    *piVar7 = 0x180623960;
    *(undefined8 *)(puVar14 + -8) = 0x18004ac1a;
    func_0x00018003c320(piVar7 + 1, auStack_2d8);
    puVar14[0x28] = 0;
    *(undefined8 *)(puVar14 + 0x20) = uVar9;
    *(undefined8 *)(puVar14 + -8) = 0x18004ac3c;
    var_340h = (int64_t)piVar7;
    func_0x000180047960(puVar12 + 2, puVar14 + 0x60, uVar1, arg1 + 0x68);
    pcVar2 = *(code **)(*piVar7 + 0x20);
    *(undefined8 *)(puVar14 + -8) = 0x18004ac51;
    (*pcVar2)(piVar7, piVar7 != (int64_t *)(puVar14 + 0x60));
    *(undefined8 *)(puVar14 + -8) = 0x18004ac65;
    var_2f8h = (int64_t)(puVar12 + 2);
    var_2f0h = (int64_t)puVar12;
    func_0x00018000a9d0(uVar8, &var_2f8h);
    if (var_2f0h != 0) {
        *(undefined8 *)(puVar14 + -8) = 0x18004ac73;
        func_0x000180005cf0();
    }
    *(undefined8 *)(puVar14 + -8) = 0x18004ac7c;
    func_0x00018003c510(auStack_2d8);
    *(undefined8 *)(puVar14 + -8) = 0x18004ac88;
    func_0x00018003c510(&var_198h);
    *(undefined8 *)(puVar14 + -8) = 0x18004ac92;
    func_0x00018003ded0(puVar14 + 0x40);
    uVar1 = *(undefined8 *)(*(int64_t *)(puVar14 + 0x30) + 8);
    *(undefined8 *)(puVar14 + -8) = 0x18004acaa;
    func_0x000180015170(puVar14 + 0x30, puVar14 + 0x30, uVar1);
    *(undefined8 *)(puVar14 + -8) = 0x18004acb9;
    fcn.180459c3c(*(undefined8 *)(puVar14 + 0x30), 0x60);
    *(undefined8 *)(puVar14 + -8) = 0x18004acbe;
    func_0x00018045476c();
    *(undefined8 *)(puVar14 + -8) = 0x18004acc6;
    func_0x000180048a90(arg1);
    *(undefined8 *)(puVar14 + -8) = 0x18004acd3;
    fcn.180459c3c(arg1, 0x80);
    *(undefined8 *)(puVar14 + -8) = 0x18004ace4;
    func_0x000180459870(var_58h ^ (uint64_t)puVar14);
    return;
}

// ============================================================
// Function: FUN_18004ad00
// Address: 0x18004ad00
// Size: 877 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_3b0h
// WARNING: Removing unreachable block (ram,0x00018004ae15)

void fcn.18004ad00(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int64_t var_8h;
    undefined auStackY_3d8 [32];
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_390h;
    int64_t var_380h;
    int64_t var_360h;
    int64_t var_340h;
    int64_t var_318h;
    int64_t var_2d8h;
    int64_t var_198h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_3d8;
    var_3a0h = *(int64_t *)(arg1 + 0x90);
    if (*(int64_t *)(arg1 + 0x38) == 0) {
        uVar4 = func_0x000180459890(0x80);
        uVar5 = func_0x00018003e190(&var_390h, arg1 + 0x68);
        uVar6 = func_0x00018003c450(&var_380h, arg1 + 0x48);
        var_3b8h = CONCAT44(var_3b8h._4_4_, 1);
        iVar7 = func_0x000180083a90(uVar4, arg1 + 8, uVar6, uVar5);
        var_3a8h = 0;
    } else {
        uVar4 = func_0x000180459890(0x80);
        iVar7 = func_0x00018003e190(&var_390h, arg1 + 0x68);
        uVar5 = func_0x00018003c450(&var_380h, arg1 + 0x48);
        uVar6 = func_0x00018000b4d0(&var_360h, arg1 + 0x28);
        uVar8 = func_0x00018000b4d0(&var_340h, arg1 + 8);
        var_3b0h._0_4_ = 1;
        var_3b8h = iVar7;
        iVar7 = func_0x000180083dc0(uVar4, uVar8, uVar6, uVar5);
        var_390h = 0;
    }
    func_0x000180084280(iVar7, &var_198h, *(undefined4 *)(arg1 + 0x78));
    puVar9 = (undefined8 *)func_0x0001800137d0();
    uVar4 = *puVar9;
    func_0x00018003c320(&var_2d8h, &var_198h);
    puVar9 = (undefined8 *)func_0x000180459890(0x88);
    *(undefined4 *)(puVar9 + 1) = 1;
    *(undefined4 *)((int64_t)puVar9 + 0xc) = 1;
    *puVar9 = 0x180623990;
    uVar5 = *(undefined8 *)arg1;
    piVar10 = (int64_t *)func_0x000180459890(0x140);
    *piVar10 = 0x1806239b0;
    func_0x00018003c320(piVar10 + 1, &var_2d8h);
    *(undefined4 *)(puVar9 + 3) = 2;
    puVar9[2] = 0x180623918;
    puVar9[0xb] = 0;
    uVar6 = (**(code **)*piVar10)(piVar10, puVar9 + 4);
    puVar9[0xb] = uVar6;
    puVar9[0xc] = uVar5;
    puVar9[0xd] = var_3a0h;
    puVar9[0xe] = 0;
    puVar9[0xf] = 0;
    if (*(int64_t *)(arg1 + 0x88) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x88) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    puVar9[0xe] = *(undefined8 *)(arg1 + 0x80);
    puVar9[0xf] = *(undefined8 *)(arg1 + 0x88);
    *(undefined *)(puVar9 + 0x10) = 0;
    *(undefined4 *)(puVar9 + 3) = 1;
    (**(code **)(*piVar10 + 0x20))(piVar10, piVar10 != &var_318h);
    var_3a0h = (int64_t)(puVar9 + 2);
    var_398h = (int64_t)puVar9;
    func_0x00018000a9d0(uVar4, &var_3a0h);
    iVar3 = var_398h;
    if (var_398h != 0) {
        LOCK();
        piVar1 = (int32_t *)(var_398h + 8);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (***(code ***)var_398h)(var_398h);
            LOCK();
            piVar1 = (int32_t *)(iVar3 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*(int64_t *)iVar3 + 8))(iVar3);
            }
        }
    }
    func_0x00018003c510(&var_2d8h);
    func_0x00018003c510(&var_198h);
    if (iVar7 != 0) {
        func_0x000180015170(iVar7 + 0x70, iVar7 + 0x70, *(undefined8 *)(*(int64_t *)(iVar7 + 0x70) + 8));
        fcn.180459c3c(*(undefined8 *)(iVar7 + 0x70), 0x60);
        func_0x00018003e790(iVar7 + 0x58);
        func_0x000180004e40(iVar7 + 0x30);
        func_0x000180004e40(iVar7 + 8);
        fcn.180459c3c(iVar7, 0x80);
    }
    func_0x00018045476c();
    fcn.180049f80(arg1, CONCAT44(var_3b0h._4_4_, (undefined4)var_3b0h));
    fcn.180459c3c(arg1, 0x98);
    func_0x000180459870(var_58h ^ (uint64_t)auStackY_3d8);
    return;
}

// ============================================================
// Function: FUN_18004b070
// Address: 0x18004b070
// Size: 46 bytes
// ============================================================
void fcn.18004b070(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t unaff_retaddr;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    fcn.180049f80(arg1, unaff_retaddr);
    if ((arg1 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar2 == 0))
    {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar1 = (undefined4 *)func_0x00018046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18004b0a0
// Address: 0x18004b0a0
// Size: 46 bytes
// ============================================================
void fcn.18004b0a0(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    func_0x000180048a90(arg1);
    if ((arg1 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar2 == 0))
    {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar1 = (undefined4 *)func_0x00018046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18004b0d0
// Address: 0x18004b0d0
// Size: 46 bytes
// ============================================================
void fcn.18004b0d0(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    func_0x000180048130(arg1);
    if ((arg1 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar2 == 0))
    {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar1 = (undefined4 *)func_0x00018046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18004b100
// Address: 0x18004b100
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18004b100(int64_t arg1)
{
    char in_DL;
    int64_t var_8h;
    
    fcn.18003c510(arg1 + 8);
    if (in_DL != '\0') {
        fcn.180459c3c(arg1, 0x140);
    }
    return;
}

// ============================================================
// Function: FUN_18004b150
// Address: 0x18004b150
// Size: 4487 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_33h
// WARNING: [rz-ghidra] Detected overlap for variable var_3fh
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h

void fcn.18004b150(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined auVar4 [16];
    undefined4 *puVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t var_18h;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    undefined8 var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    arg2 = *(int64_t *)arg2;
    func_0x000180086fd0(arg2, 0, 0);
    piVar7 = (int64_t *)(arg1 + 0x20);
    if (0xf < *(uint64_t *)(arg1 + 0x38)) {
        piVar7 = (int64_t *)*piVar7;
    }
    func_0x0001800867f0(arg2, piVar7, *(undefined8 *)(arg1 + 0x30));
    func_0x000180087370(arg2, 0xfffffffe, 0x1806237cc);
    iVar2 = *(int32_t *)(arg1 + 0x18);
    if (iVar2 < 0x191) {
        if (iVar2 == 400) {
            var_30h = 0xb;
            _var_40h = ZEXT816(0x7571655220646142);
            stack0xffffffffffffffc7 = 0x74736575;
            var_38h._3_5_ = 0;
            goto code_r0x00018004bf10;
        }
    // switch table (209 cases) at 0x18004c0a0
        switch(iVar2) {
        case 100:
            var_30h = 8;
            _var_40h = (unkuint9)0x65756e69746e6f43;
            var_38h._1_7_ = 0;
            goto code_r0x00018004bf10;
        case 0x65:
            _var_40h = ZEXT816(0);
            var_30h = 0;
            var_28h = 0;
            func_0x000180004830(&var_40h, 0x1806232f0, 0x13);
            break;
        case 0x66:
            var_30h = 10;
            var_38h._0_2_ = 0x676e;
            var_40h = 0x69737365636f7250;
            var_38h._2_6_ = 0;
            goto code_r0x00018004bf10;
        case 0x67:
            var_30h = 0xb;
            _var_40h = ZEXT816(0x694820796c726145);
            stack0xffffffffffffffc7 = 0x73746e69;
            var_38h._3_5_ = 0;
            goto code_r0x00018004bf10;
        default:
            goto code_r0x00018004bf01;
        case 200:
            var_30h = 2;
            stack0xffffffffffffffc3 = SUB1613(ZEXT816(0), 3);
            var_40h._0_3_ = 0x4b4f;
            goto code_r0x00018004bf10;
        case 0xc9:
            var_30h = 7;
            _var_40h = ZEXT716(0x64657461657243);
            goto code_r0x00018004bf10;
        case 0xca:
            func_0x0001800047e0(&var_40h, 0x180623318);
            break;
        case 0xcb:
            func_0x0001800047e0(&var_40h, 0x180623340);
            break;
        case 0xcc:
            func_0x0001800047e0(&var_40h, 0x180623330);
            break;
        case 0xcd:
            func_0x0001800047e0(&var_40h, 0x180623370);
            break;
        case 0xce:
            func_0x0001800047e0(&var_40h, 0x180623360);
            break;
        case 0xcf:
            func_0x0001800047e0(&var_40h, 0x180623398);
            break;
        case 0xd0:
            func_0x0001800047e0(&var_40h, 0x180623380);
            break;
        case 0xe2:
            func_0x0001800047e0(&var_40h, 0x1806233c0);
            break;
        case 300:
            func_0x0001800047e0(&var_40h, 0x1806233a8);
            break;
        case 0x12d:
            func_0x0001800047e0(&var_40h, 0x1806233d0);
            break;
        case 0x12e:
            func_0x0001800047e0(&var_40h, 0x1806233c8);
            break;
        case 0x12f:
            func_0x0001800047e0(&var_40h, 0x1806233f8);
            break;
        case 0x130:
            func_0x0001800047e0(&var_40h, 0x1806233e8);
            break;
        case 0x131:
            func_0x0001800047e0(&var_40h, 0x180623420);
            break;
        case 0x133:
            func_0x0001800047e0(&var_40h, 0x180623408);
            break;
        case 0x134:
            func_0x0001800047e0(&var_40h, 0x180623440);
        }
        goto code_r0x00018004bf18;
    }
    // switch table (111 cases) at 0x18004c1d0
    switch(iVar2) {
    case 0x191:
        var_30h = 0xc;
        var_38h._0_4_ = 0x64657a69;
        var_40h = 0x726f687475616e55;
        var_38h._4_4_ = 0;
        goto code_r0x00018004bf10;
    case 0x192:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623458, 0x10);
        break;
    case 0x193:
        var_30h = 9;
        var_38h._0_1_ = 0x6e;
        var_40h = 0x6564646962726f46;
        var_38h._1_7_ = 0;
        goto code_r0x00018004bf10;
    case 0x194:
        var_30h = 9;
        var_38h._0_1_ = 100;
        var_40h = 0x6e756f4620746f4e;
        var_38h._1_7_ = 0;
        goto code_r0x00018004bf10;
    case 0x195:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x1806234b0, 0x12);
        break;
    case 0x196:
        var_30h = 0xe;
        var_38h._0_4_ = 0x62617470;
        var_40h = 0x6563634120746f4e;
        var_38h._4_2_ = 0x656c;
        var_38h._6_2_ = 0;
        goto code_r0x00018004bf10;
    case 0x197:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x1806234d8, 0x1d);
        break;
    case 0x198:
        var_30h = 0xf;
        var_38h._0_4_ = 0x656d6954;
        var_40h = 0x2074736575716552;
        var_38h._4_2_ = 0x756f;
        var_38h._6_1_ = 0x74;
        var_38h._7_1_ = 0;
        goto code_r0x00018004bf10;
    case 0x199:
        var_30h = 8;
        _var_40h = (unkuint9)0x7463696c666e6f43;
        var_38h._1_7_ = 0;
        goto code_r0x00018004bf10;
    case 0x19a:
        var_30h = 4;
        stack0xffffffffffffffc5 = SUB1611(ZEXT816(0), 5);
        var_40h._0_5_ = 0x656e6f47;
        goto code_r0x00018004bf10;
    case 0x19b:
        var_30h = 0xf;
        var_38h._0_4_ = 0x69757165;
        var_40h = 0x52206874676e654c;
        var_38h._4_2_ = 0x6572;
        var_38h._6_1_ = 100;
        var_38h._7_1_ = 0;
        goto code_r0x00018004bf10;
    case 0x19c:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623510, 0x13);
        break;
    case 0x19d:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623548, 0x11);
        break;
    case 0x19e:
        var_30h = 0xc;
        var_38h._0_4_ = 0x676e6f4c;
        var_40h = 0x206f6f5420495255;
        var_38h._4_4_ = 0;
        goto code_r0x00018004bf10;
    case 0x19f:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623578, 0x16);
        break;
    case 0x1a0:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623560, 0x15);
        break;
    case 0x1a1:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        puVar5 = (undefined4 *)func_0x000180459890(0x20);
        var_40h = (int64_t)puVar5;
        var_30h = 0x12;
        var_28h = 0x1f;
        *puVar5 = 0x65707845;
        puVar5[1] = 0x74617463;
        puVar5[2] = 0x206e6f69;
        puVar5[3] = 0x6c696146;
        *(undefined2 *)(puVar5 + 4) = 0x6465;
        *(undefined *)((int64_t)puVar5 + 0x12) = 0;
        break;
    case 0x1a2:
        var_30h = 0xc;
        var_38h._0_4_ = 0x746f7061;
        var_40h = 0x65742061206d2749;
        var_38h._4_4_ = 0;
        goto code_r0x00018004bf10;
    default:
code_r0x00018004bf01:
        var_30h = 0;
        stack0xffffffffffffffc1 = SUB1615(ZEXT816(0), 1);
        auVar4[15] = 0;
        auVar4._0_15_ = stack0xffffffffffffffc1;
        _var_40h = auVar4 << 8;
        goto code_r0x00018004bf10;
    case 0x1a6:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        puVar5 = (undefined4 *)func_0x000180459890(0x20);
        var_40h = (int64_t)puVar5;
        var_30h = 0x14;
        var_28h = 0x1f;
        *puVar5 = 0x72706e55;
        puVar5[1] = 0x7365636f;
        puVar5[2] = 0x6c626173;
        puVar5[3] = 0x6e452065;
        puVar5[4] = 0x79746974;
        *(undefined *)(puVar5 + 5) = 0;
        break;
    case 0x1a7:
        var_30h = 6;
        stack0xffffffffffffffc7 = SUB169(ZEXT816(0), 7);
        var_40h._0_7_ = 0x64656b636f4c;
        goto code_r0x00018004bf10;
    case 0x1a8:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        puVar5 = (undefined4 *)func_0x000180459890(0x20);
        var_40h = (int64_t)puVar5;
        var_30h = 0x11;
        var_28h = 0x1f;
        *puVar5 = 0x6c696146;
        puVar5[1] = 0x44206465;
        puVar5[2] = 0x6e657065;
        puVar5[3] = 0x636e6564;
        *(undefined *)(puVar5 + 4) = 0x79;
        *(undefined *)((int64_t)puVar5 + 0x11) = 0;
        break;
    case 0x1aa:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        puVar5 = (undefined4 *)func_0x000180459890(0x20);
        var_40h = (int64_t)puVar5;
        var_30h = 0x10;
        var_28h = 0x1f;
        *puVar5 = 0x72677055;
        puVar5[1] = 0x20656461;
        puVar5[2] = 0x75716552;
        puVar5[3] = 0x64657269;
        *(undefined *)(puVar5 + 4) = 0;
        break;
    case 0x1ac:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        puVar5 = (undefined4 *)func_0x000180459890(0x20);
        var_40h = (int64_t)puVar5;
        var_30h = 0x15;
        var_28h = 0x1f;
        *puVar5 = 0x63657250;
        puVar5[1] = 0x69646e6f;
        puVar5[2] = 0x6e6f6974;
        puVar5[3] = 0x71655220;
        *(undefined8 *)((int64_t)puVar5 + 0xd) = 0x6465726975716552;
        *(undefined *)((int64_t)puVar5 + 0x15) = 0;
        break;
    case 0x1ad:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623608, 0x11);
        break;
    case 0x1af:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        puVar5 = (undefined4 *)func_0x000180459890(0x20);
        var_40h = (int64_t)puVar5;
        var_30h = 0x1f;
        var_28h = 0x1f;
        *puVar5 = 0x75716552;
        puVar5[1] = 0x20747365;
        puVar5[2] = 0x64616548;
        puVar5[3] = 0x46207265;
        *(undefined4 *)((int64_t)puVar5 + 0xf) = 0x6c656946;
        *(undefined4 *)((int64_t)puVar5 + 0x13) = 0x54207364;
        *(undefined4 *)((int64_t)puVar5 + 0x17) = 0x4c206f6f;
        *(undefined4 *)((int64_t)puVar5 + 0x1b) = 0x65677261;
        *(undefined *)((int64_t)puVar5 + 0x1f) = 0;
        break;
    case 0x1c3:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        puVar5 = (undefined4 *)func_0x000180459890(0x20);
        var_40h = (int64_t)puVar5;
        var_30h = 0x1d;
        var_28h = 0x1f;
        *puVar5 = 0x76616e55;
        puVar5[1] = 0x616c6961;
        puVar5[2] = 0x20656c62;
        puVar5[3] = 0x20726f46;
        *(undefined4 *)((int64_t)puVar5 + 0xd) = 0x4c20726f;
        *(undefined4 *)((int64_t)puVar5 + 0x11) = 0x6c616765;
        *(undefined4 *)((int64_t)puVar5 + 0x15) = 0x61655220;
        *(undefined4 *)((int64_t)puVar5 + 0x19) = 0x736e6f73;
        *(undefined *)((int64_t)puVar5 + 0x1d) = 0;
        break;
    case 500:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        var_48h = 0x1f;
        puVar5 = (undefined4 *)func_0x000180004930(&var_40h, &var_48h);
        var_40h = (int64_t)puVar5;
        var_30h = 0x15;
        var_28h = var_48h;
        *puVar5 = 0x65746e49;
        puVar5[1] = 0x6c616e72;
        puVar5[2] = 0x72655320;
        puVar5[3] = 0x20726576;
        *(undefined8 *)((int64_t)puVar5 + 0xd) = 0x726f727245207265;
        *(undefined *)((int64_t)puVar5 + 0x15) = 0;
        break;
    case 0x1f5:
        var_30h = 0xf;
        var_38h._0_4_ = 0x6e656d65;
        var_40h = 0x6c706d4920746f4e;
        var_38h._4_2_ = 0x6574;
        var_38h._6_1_ = 100;
        var_38h._7_1_ = 0;
        goto code_r0x00018004bf10;
    case 0x1f6:
        var_30h = 0xb;
        _var_40h = ZEXT816(0x6574614720646142);
        stack0xffffffffffffffc7 = 0x79617765;
        var_38h._3_5_ = 0;
        goto code_r0x00018004bf10;
    case 0x1f7:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        var_48h = 0x1f;
        puVar5 = (undefined4 *)func_0x000180004930(&var_40h, &var_48h);
        var_40h = (int64_t)puVar5;
        var_30h = 0x13;
        var_28h = var_48h;
        *puVar5 = 0x76726553;
        puVar5[1] = 0x20656369;
        puVar5[2] = 0x76616e55;
        puVar5[3] = 0x616c6961;
        *(undefined4 *)((int64_t)puVar5 + 0xf) = 0x656c6261;
        *(undefined *)((int64_t)puVar5 + 0x13) = 0;
        break;
    case 0x1f8:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x1806236e8, 0x10);
        break;
    case 0x1f9:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        var_48h = 0x1f;
        puVar5 = (undefined4 *)func_0x000180004930(&var_40h, &var_48h);
        var_40h = (int64_t)puVar5;
        var_30h = 0x1a;
        var_28h = var_48h;
        *puVar5 = 0x50545448;
        puVar5[1] = 0x72655620;
        puVar5[2] = 0x6e6f6973;
        puVar5[3] = 0x746f4e20;
        *(undefined4 *)((int64_t)puVar5 + 10) = 0x4e206e6f;
        *(undefined4 *)((int64_t)puVar5 + 0xe) = 0x5320746f;
        *(undefined4 *)((int64_t)puVar5 + 0x12) = 0x6f707075;
        *(undefined4 *)((int64_t)puVar5 + 0x16) = 0x64657472;
        *(undefined *)((int64_t)puVar5 + 0x1a) = 0;
        break;
    case 0x1fa:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623718, 0x17);
        break;
    case 0x1fb:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623700, 0x14);
        break;
    case 0x1fc:
        var_30h = 0xd;
        var_38h._0_4_ = 0x65746365;
        var_40h = 0x74654420706f6f4c;
        var_38h._4_1_ = 100;
        var_38h._5_3_ = 0;
        goto code_r0x00018004bf10;
    case 0x1fe:
        var_30h = 0xc;
        var_38h._0_4_ = 0x6465646e;
        var_40h = 0x6574784520746f4e;
        var_38h._4_4_ = 0;
code_r0x00018004bf10:
        var_28h = 0xf;
        break;
    case 0x1ff:
        _var_40h = ZEXT816(0);
        var_30h = 0;
        var_28h = 0;
        func_0x000180004830(&var_40h, 0x180623750, 0x1f);
    }
code_r0x00018004bf18:
    uVar6 = func_0x00018000b450(&var_40h);
    func_0x0001800868c0(arg2, uVar6);
    fcn.180004e40(&var_40h);
    func_0x000180087370(arg2, 0xfffffffe, 0x1806237f8);
    func_0x000180086570(arg2, (double)*(int32_t *)(arg1 + 0x18));
    func_0x000180087370(arg2, 0xfffffffe, 0x1806237e8);
    func_0x000180086b20(arg2, *(int32_t *)(arg1 + 0x18) - 200U < 100);
    func_0x000180087370(arg2, 0xfffffffe, 0x180623810);
    func_0x000180086fd0(arg2, 0, 0);
    ppiVar9 = (int64_t **)**(int64_t ***)(arg1 + 0x40);
    cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
    while (cVar1 == '\0') {
        ppiVar8 = ppiVar9 + 4;
        ppiVar10 = ppiVar9 + 8;
        if ((int64_t *)0xf < ppiVar9[7]) {
            ppiVar8 = (int64_t **)*ppiVar8;
        }
        func_0x0001800867f0(arg2, ppiVar8, ppiVar9[6]);
        if ((int64_t *)0xf < ppiVar9[0xb]) {
            ppiVar10 = (int64_t **)*ppiVar10;
        }
        func_0x0001800867f0(arg2, ppiVar10, ppiVar9[10]);
        iVar3 = *(int64_t *)(arg2 + 0x40);
        func_0x0001800a8680(arg2, iVar3 + -0x30, iVar3 + -0x20, iVar3 + -0x10);
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x20;
        ppiVar8 = (int64_t **)ppiVar9[2];
        if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
            ppiVar9 = ppiVar8;
            ppiVar8 = (int64_t **)*ppiVar8;
            while (cVar1 == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                ppiVar9 = ppiVar8;
                ppiVar8 = (int64_t **)*ppiVar8;
            }
        } else {
            cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
            ppiVar10 = (int64_t **)ppiVar9[1];
            ppiVar8 = ppiVar9;
            while ((ppiVar9 = ppiVar10, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar9[2]))) {
                cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                ppiVar10 = (int64_t **)ppiVar9[1];
                ppiVar8 = ppiVar9;
            }
        }
        cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
    }
    func_0x000180087370(arg2, 0xfffffffe, 0x180623808);
    func_0x000180459870(var_20h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_18004c2e0
// Address: 0x18004c2e0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18004c2e0(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = (undefined8 *)fcn.180459890(0x140);
    *puVar1 = 0x1806239b0;
    fcn.18003c320(puVar1 + 1, arg1 + 8);
    return puVar1;
}

// ============================================================
// Function: FUN_18004c340
// Address: 0x18004c340
// Size: 43 bytes
// ============================================================
undefined8 fcn.18004c340(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    
    piVar1 = (int64_t *)(arg1 + 0x20);
    if (0xf < *(uint64_t *)(arg1 + 0x38)) {
        piVar1 = (int64_t *)*piVar1;
    }
    fcn.1800867f0(*(undefined8 *)arg2, piVar1, *(undefined8 *)(arg1 + 0x30));
    return 1;
}

// ============================================================
// Function: FUN_18004c370
// Address: 0x18004c370
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18004c370(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = (undefined8 *)fcn.180459890(0x140);
    *puVar1 = 0x180623960;
    fcn.18003c320(puVar1 + 1, arg1 + 8);
    return puVar1;
}

// ============================================================
// Function: FUN_18004c3c0
// Address: 0x18004c3c0
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18004c3c0(int64_t arg1)
{
    char in_DL;
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 8);
    if (in_DL != '\0') {
        fcn.180459c3c(arg1, 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_18004c410
// Address: 0x18004c410
// Size: 46 bytes
// ============================================================
undefined8 fcn.18004c410(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)(arg1 + 8);
    if (0xf < *(uint64_t *)(arg1 + 0x20)) {
        puVar1 = (undefined8 *)*puVar1;
    }
    fcn.1800867f0(*(undefined8 *)arg2, puVar1, *(undefined8 *)(arg1 + 0x18));
    return 1;
}

// ============================================================
// Function: FUN_18004c480
// Address: 0x18004c480
// Size: 41 bytes
// ============================================================
int64_t fcn.18004c480(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg2 = 0x180623930;
    fcn.18000b4d0(arg2 + 8, arg1 + 8);
    return arg2;
}

// ============================================================
// Function: FUN_18004c4b0
// Address: 0x18004c4b0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18004c4b0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    code *pcVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar11 = *(int64_t ***)0x180782868;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar9 = (code *)swi(3);
        (*pcVar9)();
        return;
    }
    uVar13 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar13 != 0) {
        for (; uVar13 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    func_0x00018000f7e0(0x180782878, iVar15 * 2, *(int64_t ***)0x180782868);
    *(uint64_t *)0x180782890 = iVar15 - 1;
    *(int64_t *)0x180782898 = iVar15;
    ppiVar10 = (int64_t **)**(int64_t ***)0x180782868;
joined_r0x00018004c536:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar10 == ppiVar11) {
                    return;
                }
                piVar3 = ppiVar10[3];
                piVar14 = (int64_t *)0x0;
                ppiVar4 = (int64_t **)*ppiVar10;
                piVar5 = ppiVar10[2];
                uVar13 = 0xcbf29ce484222325;
                if (piVar3 != (int64_t *)0x0) {
                    do {
                        puVar1 = (uint8_t *)((int64_t)piVar14 + (int64_t)piVar5);
                        piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                        uVar13 = (uVar13 ^ *puVar1) * 0x100000001b3;
                    } while (piVar14 < piVar3);
                }
                uVar13 = uVar13 & *(uint64_t *)0x180782890;
                ppiVar6 = *(int64_t ***)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                ppiVar2 = (int64_t **)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                iVar15 = *(int64_t *)0x180782878 + uVar13 * 0x10;
                if (ppiVar6 != ppiVar11) break;
                *ppiVar2 = (int64_t *)ppiVar10;
                *(int64_t ***)(iVar15 + 8) = ppiVar10;
                ppiVar10 = ppiVar4;
            }
            ppiVar7 = *(int64_t ***)(iVar15 + 8);
            if ((piVar3 != ppiVar7[3]) ||
               ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0)))) break;
            ppiVar7 = (int64_t **)*ppiVar7;
            if (ppiVar7 != ppiVar10) {
                ppiVar2 = (int64_t **)ppiVar10[1];
                *ppiVar2 = (int64_t *)ppiVar4;
                ppiVar6 = (int64_t **)ppiVar4[1];
                *ppiVar6 = (int64_t *)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = (int64_t *)ppiVar6;
                ppiVar4[1] = (int64_t *)ppiVar2;
                ppiVar10[1] = (int64_t *)ppiVar8;
            }
            *(int64_t ***)(iVar15 + 8) = ppiVar10;
            ppiVar10 = ppiVar4;
        }
        do {
            if (ppiVar6 == ppiVar7) {
                ppiVar6 = (int64_t **)ppiVar10[1];
                *ppiVar6 = (int64_t *)ppiVar4;
                piVar3 = ppiVar4[1];
                *piVar3 = (int64_t)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = piVar3;
                ppiVar4[1] = (int64_t *)ppiVar6;
                ppiVar10[1] = (int64_t *)ppiVar8;
                *ppiVar2 = (int64_t *)ppiVar10;
                ppiVar10 = ppiVar4;
                goto joined_r0x00018004c536;
            }
            ppiVar7 = (int64_t **)ppiVar7[1];
        } while ((piVar3 != ppiVar7[3]) ||
                ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0))));
        iVar15 = (int64_t)*ppiVar7;
        ppiVar2 = (int64_t **)ppiVar10[1];
        *ppiVar2 = (int64_t *)ppiVar4;
        piVar3 = ppiVar4[1];
        *piVar3 = iVar15;
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        *ppiVar6 = (int64_t *)ppiVar10;
        *(int64_t **)(iVar15 + 8) = piVar3;
        ppiVar4[1] = (int64_t *)ppiVar2;
        ppiVar10[1] = (int64_t *)ppiVar6;
        ppiVar10 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_18004c4df
// Address: 0x18004c4df
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18004c4b0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    code *pcVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar11 = *(int64_t ***)0x180782868;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar9 = (code *)swi(3);
        (*pcVar9)();
        return;
    }
    uVar13 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar13 != 0) {
        for (; uVar13 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    func_0x00018000f7e0(0x180782878, iVar15 * 2, *(int64_t ***)0x180782868);
    *(uint64_t *)0x180782890 = iVar15 - 1;
    *(int64_t *)0x180782898 = iVar15;
    ppiVar10 = (int64_t **)**(int64_t ***)0x180782868;
joined_r0x00018004c536:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar10 == ppiVar11) {
                    return;
                }
                piVar3 = ppiVar10[3];
                piVar14 = (int64_t *)0x0;
                ppiVar4 = (int64_t **)*ppiVar10;
                piVar5 = ppiVar10[2];
                uVar13 = 0xcbf29ce484222325;
                if (piVar3 != (int64_t *)0x0) {
                    do {
                        puVar1 = (uint8_t *)((int64_t)piVar14 + (int64_t)piVar5);
                        piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                        uVar13 = (uVar13 ^ *puVar1) * 0x100000001b3;
                    } while (piVar14 < piVar3);
                }
                uVar13 = uVar13 & *(uint64_t *)0x180782890;
                ppiVar6 = *(int64_t ***)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                ppiVar2 = (int64_t **)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                iVar15 = *(int64_t *)0x180782878 + uVar13 * 0x10;
                if (ppiVar6 != ppiVar11) break;
                *ppiVar2 = (int64_t *)ppiVar10;
                *(int64_t ***)(iVar15 + 8) = ppiVar10;
                ppiVar10 = ppiVar4;
            }
            ppiVar7 = *(int64_t ***)(iVar15 + 8);
            if ((piVar3 != ppiVar7[3]) ||
               ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0)))) break;
            ppiVar7 = (int64_t **)*ppiVar7;
            if (ppiVar7 != ppiVar10) {
                ppiVar2 = (int64_t **)ppiVar10[1];
                *ppiVar2 = (int64_t *)ppiVar4;
                ppiVar6 = (int64_t **)ppiVar4[1];
                *ppiVar6 = (int64_t *)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = (int64_t *)ppiVar6;
                ppiVar4[1] = (int64_t *)ppiVar2;
                ppiVar10[1] = (int64_t *)ppiVar8;
            }
            *(int64_t ***)(iVar15 + 8) = ppiVar10;
            ppiVar10 = ppiVar4;
        }
        do {
            if (ppiVar6 == ppiVar7) {
                ppiVar6 = (int64_t **)ppiVar10[1];
                *ppiVar6 = (int64_t *)ppiVar4;
                piVar3 = ppiVar4[1];
                *piVar3 = (int64_t)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = piVar3;
                ppiVar4[1] = (int64_t *)ppiVar6;
                ppiVar10[1] = (int64_t *)ppiVar8;
                *ppiVar2 = (int64_t *)ppiVar10;
                ppiVar10 = ppiVar4;
                goto joined_r0x00018004c536;
            }
            ppiVar7 = (int64_t **)ppiVar7[1];
        } while ((piVar3 != ppiVar7[3]) ||
                ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0))));
        iVar15 = (int64_t)*ppiVar7;
        ppiVar2 = (int64_t **)ppiVar10[1];
        *ppiVar2 = (int64_t *)ppiVar4;
        piVar3 = ppiVar4[1];
        *piVar3 = iVar15;
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        *ppiVar6 = (int64_t *)ppiVar10;
        *(int64_t **)(iVar15 + 8) = piVar3;
        ppiVar4[1] = (int64_t *)ppiVar2;
        ppiVar10[1] = (int64_t *)ppiVar6;
        ppiVar10 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_18004c53c
// Address: 0x18004c53c
// Size: 386 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18004c4b0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    code *pcVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar11 = *(int64_t ***)0x180782868;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar9 = (code *)swi(3);
        (*pcVar9)();
        return;
    }
    uVar13 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar13 != 0) {
        for (; uVar13 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    func_0x00018000f7e0(0x180782878, iVar15 * 2, *(int64_t ***)0x180782868);
    *(uint64_t *)0x180782890 = iVar15 - 1;
    *(int64_t *)0x180782898 = iVar15;
    ppiVar10 = (int64_t **)**(int64_t ***)0x180782868;
joined_r0x00018004c536:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar10 == ppiVar11) {
                    return;
                }
                piVar3 = ppiVar10[3];
                piVar14 = (int64_t *)0x0;
                ppiVar4 = (int64_t **)*ppiVar10;
                piVar5 = ppiVar10[2];
                uVar13 = 0xcbf29ce484222325;
                if (piVar3 != (int64_t *)0x0) {
                    do {
                        puVar1 = (uint8_t *)((int64_t)piVar14 + (int64_t)piVar5);
                        piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                        uVar13 = (uVar13 ^ *puVar1) * 0x100000001b3;
                    } while (piVar14 < piVar3);
                }
                uVar13 = uVar13 & *(uint64_t *)0x180782890;
                ppiVar6 = *(int64_t ***)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                ppiVar2 = (int64_t **)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                iVar15 = *(int64_t *)0x180782878 + uVar13 * 0x10;
                if (ppiVar6 != ppiVar11) break;
                *ppiVar2 = (int64_t *)ppiVar10;
                *(int64_t ***)(iVar15 + 8) = ppiVar10;
                ppiVar10 = ppiVar4;
            }
            ppiVar7 = *(int64_t ***)(iVar15 + 8);
            if ((piVar3 != ppiVar7[3]) ||
               ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0)))) break;
            ppiVar7 = (int64_t **)*ppiVar7;
            if (ppiVar7 != ppiVar10) {
                ppiVar2 = (int64_t **)ppiVar10[1];
                *ppiVar2 = (int64_t *)ppiVar4;
                ppiVar6 = (int64_t **)ppiVar4[1];
                *ppiVar6 = (int64_t *)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = (int64_t *)ppiVar6;
                ppiVar4[1] = (int64_t *)ppiVar2;
                ppiVar10[1] = (int64_t *)ppiVar8;
            }
            *(int64_t ***)(iVar15 + 8) = ppiVar10;
            ppiVar10 = ppiVar4;
        }
        do {
            if (ppiVar6 == ppiVar7) {
                ppiVar6 = (int64_t **)ppiVar10[1];
                *ppiVar6 = (int64_t *)ppiVar4;
                piVar3 = ppiVar4[1];
                *piVar3 = (int64_t)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = piVar3;
                ppiVar4[1] = (int64_t *)ppiVar6;
                ppiVar10[1] = (int64_t *)ppiVar8;
                *ppiVar2 = (int64_t *)ppiVar10;
                ppiVar10 = ppiVar4;
                goto joined_r0x00018004c536;
            }
            ppiVar7 = (int64_t **)ppiVar7[1];
        } while ((piVar3 != ppiVar7[3]) ||
                ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0))));
        iVar15 = (int64_t)*ppiVar7;
        ppiVar2 = (int64_t **)ppiVar10[1];
        *ppiVar2 = (int64_t *)ppiVar4;
        piVar3 = ppiVar4[1];
        *piVar3 = iVar15;
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        *ppiVar6 = (int64_t *)ppiVar10;
        *(int64_t **)(iVar15 + 8) = piVar3;
        ppiVar4[1] = (int64_t *)ppiVar2;
        ppiVar10[1] = (int64_t *)ppiVar6;
        ppiVar10 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_18004c6be
// Address: 0x18004c6be
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18004c4b0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    code *pcVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar11 = *(int64_t ***)0x180782868;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar9 = (code *)swi(3);
        (*pcVar9)();
        return;
    }
    uVar13 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar13 != 0) {
        for (; uVar13 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    func_0x00018000f7e0(0x180782878, iVar15 * 2, *(int64_t ***)0x180782868);
    *(uint64_t *)0x180782890 = iVar15 - 1;
    *(int64_t *)0x180782898 = iVar15;
    ppiVar10 = (int64_t **)**(int64_t ***)0x180782868;
joined_r0x00018004c536:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar10 == ppiVar11) {
                    return;
                }
                piVar3 = ppiVar10[3];
                piVar14 = (int64_t *)0x0;
                ppiVar4 = (int64_t **)*ppiVar10;
                piVar5 = ppiVar10[2];
                uVar13 = 0xcbf29ce484222325;
                if (piVar3 != (int64_t *)0x0) {
                    do {
                        puVar1 = (uint8_t *)((int64_t)piVar14 + (int64_t)piVar5);
                        piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                        uVar13 = (uVar13 ^ *puVar1) * 0x100000001b3;
                    } while (piVar14 < piVar3);
                }
                uVar13 = uVar13 & *(uint64_t *)0x180782890;
                ppiVar6 = *(int64_t ***)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                ppiVar2 = (int64_t **)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                iVar15 = *(int64_t *)0x180782878 + uVar13 * 0x10;
                if (ppiVar6 != ppiVar11) break;
                *ppiVar2 = (int64_t *)ppiVar10;
                *(int64_t ***)(iVar15 + 8) = ppiVar10;
                ppiVar10 = ppiVar4;
            }
            ppiVar7 = *(int64_t ***)(iVar15 + 8);
            if ((piVar3 != ppiVar7[3]) ||
               ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0)))) break;
            ppiVar7 = (int64_t **)*ppiVar7;
            if (ppiVar7 != ppiVar10) {
                ppiVar2 = (int64_t **)ppiVar10[1];
                *ppiVar2 = (int64_t *)ppiVar4;
                ppiVar6 = (int64_t **)ppiVar4[1];
                *ppiVar6 = (int64_t *)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = (int64_t *)ppiVar6;
                ppiVar4[1] = (int64_t *)ppiVar2;
                ppiVar10[1] = (int64_t *)ppiVar8;
            }
            *(int64_t ***)(iVar15 + 8) = ppiVar10;
            ppiVar10 = ppiVar4;
        }
        do {
            if (ppiVar6 == ppiVar7) {
                ppiVar6 = (int64_t **)ppiVar10[1];
                *ppiVar6 = (int64_t *)ppiVar4;
                piVar3 = ppiVar4[1];
                *piVar3 = (int64_t)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = piVar3;
                ppiVar4[1] = (int64_t *)ppiVar6;
                ppiVar10[1] = (int64_t *)ppiVar8;
                *ppiVar2 = (int64_t *)ppiVar10;
                ppiVar10 = ppiVar4;
                goto joined_r0x00018004c536;
            }
            ppiVar7 = (int64_t **)ppiVar7[1];
        } while ((piVar3 != ppiVar7[3]) ||
                ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0))));
        iVar15 = (int64_t)*ppiVar7;
        ppiVar2 = (int64_t **)ppiVar10[1];
        *ppiVar2 = (int64_t *)ppiVar4;
        piVar3 = ppiVar4[1];
        *piVar3 = iVar15;
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        *ppiVar6 = (int64_t *)ppiVar10;
        *(int64_t **)(iVar15 + 8) = piVar3;
        ppiVar4[1] = (int64_t *)ppiVar2;
        ppiVar10[1] = (int64_t *)ppiVar6;
        ppiVar10 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_18004c6d3
// Address: 0x18004c6d3
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18004c4b0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    code *pcVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar11 = *(int64_t ***)0x180782868;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar9 = (code *)swi(3);
        (*pcVar9)();
        return;
    }
    uVar13 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar13 != 0) {
        for (; uVar13 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    func_0x00018000f7e0(0x180782878, iVar15 * 2, *(int64_t ***)0x180782868);
    *(uint64_t *)0x180782890 = iVar15 - 1;
    *(int64_t *)0x180782898 = iVar15;
    ppiVar10 = (int64_t **)**(int64_t ***)0x180782868;
joined_r0x00018004c536:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar10 == ppiVar11) {
                    return;
                }
                piVar3 = ppiVar10[3];
                piVar14 = (int64_t *)0x0;
                ppiVar4 = (int64_t **)*ppiVar10;
                piVar5 = ppiVar10[2];
                uVar13 = 0xcbf29ce484222325;
                if (piVar3 != (int64_t *)0x0) {
                    do {
                        puVar1 = (uint8_t *)((int64_t)piVar14 + (int64_t)piVar5);
                        piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                        uVar13 = (uVar13 ^ *puVar1) * 0x100000001b3;
                    } while (piVar14 < piVar3);
                }
                uVar13 = uVar13 & *(uint64_t *)0x180782890;
                ppiVar6 = *(int64_t ***)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                ppiVar2 = (int64_t **)(*(int64_t *)0x180782878 + uVar13 * 0x10);
                iVar15 = *(int64_t *)0x180782878 + uVar13 * 0x10;
                if (ppiVar6 != ppiVar11) break;
                *ppiVar2 = (int64_t *)ppiVar10;
                *(int64_t ***)(iVar15 + 8) = ppiVar10;
                ppiVar10 = ppiVar4;
            }
            ppiVar7 = *(int64_t ***)(iVar15 + 8);
            if ((piVar3 != ppiVar7[3]) ||
               ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0)))) break;
            ppiVar7 = (int64_t **)*ppiVar7;
            if (ppiVar7 != ppiVar10) {
                ppiVar2 = (int64_t **)ppiVar10[1];
                *ppiVar2 = (int64_t *)ppiVar4;
                ppiVar6 = (int64_t **)ppiVar4[1];
                *ppiVar6 = (int64_t *)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = (int64_t *)ppiVar6;
                ppiVar4[1] = (int64_t *)ppiVar2;
                ppiVar10[1] = (int64_t *)ppiVar8;
            }
            *(int64_t ***)(iVar15 + 8) = ppiVar10;
            ppiVar10 = ppiVar4;
        }
        do {
            if (ppiVar6 == ppiVar7) {
                ppiVar6 = (int64_t **)ppiVar10[1];
                *ppiVar6 = (int64_t *)ppiVar4;
                piVar3 = ppiVar4[1];
                *piVar3 = (int64_t)ppiVar7;
                ppiVar8 = (int64_t **)ppiVar7[1];
                *ppiVar8 = (int64_t *)ppiVar10;
                ppiVar7[1] = piVar3;
                ppiVar4[1] = (int64_t *)ppiVar6;
                ppiVar10[1] = (int64_t *)ppiVar8;
                *ppiVar2 = (int64_t *)ppiVar10;
                ppiVar10 = ppiVar4;
                goto joined_r0x00018004c536;
            }
            ppiVar7 = (int64_t **)ppiVar7[1];
        } while ((piVar3 != ppiVar7[3]) ||
                ((piVar3 != (int64_t *)0x0 && (iVar12 = fcn.180497f30(piVar5, ppiVar7[2], piVar3), iVar12 != 0))));
        iVar15 = (int64_t)*ppiVar7;
        ppiVar2 = (int64_t **)ppiVar10[1];
        *ppiVar2 = (int64_t *)ppiVar4;
        piVar3 = ppiVar4[1];
        *piVar3 = iVar15;
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        *ppiVar6 = (int64_t *)ppiVar10;
        *(int64_t **)(iVar15 + 8) = piVar3;
        ppiVar4[1] = (int64_t *)ppiVar2;
        ppiVar10[1] = (int64_t *)ppiVar6;
        ppiVar10 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_18004c700
// Address: 0x18004c700
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18004c700(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    iVar2 = fcn.180459890(0x60);
    *(int64_t *)iVar2 = iVar2;
    *(int64_t *)(iVar2 + 8) = iVar2;
    *(int64_t *)(iVar2 + 0x10) = iVar2;
    *(undefined2 *)(iVar2 + 0x18) = 0x101;
    *(int64_t *)arg1 = iVar2;
    *(undefined8 *)arg1 = *(undefined8 *)arg2;
    *(int64_t *)arg2 = iVar2;
    uVar1 = *(undefined8 *)(arg1 + 8);
    *(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg2 + 8);
    *(undefined8 *)(arg2 + 8) = uVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18004c760
// Address: 0x18004c760
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004c760(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    piVar1 = (int64_t *)fcn.180008740();
    iVar2 = (*(code *)0x69a404)();
    fcn.180086b20(arg1, iVar2 == *(int64_t *)(*piVar1 + 8));
    return 1;
}

// ============================================================
// Function: FUN_18004c7a0
// Address: 0x18004c7a0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004c7a0(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t var_18h;
    
    piVar2 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar2 + 8);
    iVar3 = (*(code *)0x69a404)();
    if (iVar3 == iVar1) {
        (*(code *)0x69a3f6)(6, 0, 0, 0, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004c7f0
// Address: 0x18004c7f0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004c7f0(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t var_18h;
    
    piVar2 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar2 + 8);
    iVar3 = (*(code *)0x69a404)();
    if (iVar3 == iVar1) {
        (*(code *)0x69a3f6)(2, 0, 0, 0, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004c840
// Address: 0x18004c840
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004c840(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t var_18h;
    
    piVar2 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar2 + 8);
    iVar3 = (*(code *)0x69a404)();
    if (iVar3 == iVar1) {
        (*(code *)0x69a3f6)(4, 0, 0, 0, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004c890
// Address: 0x18004c890
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004c890(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t var_18h;
    
    piVar2 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar2 + 8);
    iVar3 = (*(code *)0x69a404)();
    if (iVar3 == iVar1) {
        (*(code *)0x69a3f6)(0x18, 0, 0, 0, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004c8e0
// Address: 0x18004c8e0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004c8e0(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t var_18h;
    
    piVar2 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar2 + 8);
    iVar3 = (*(code *)0x69a404)();
    if (iVar3 == iVar1) {
        (*(code *)0x69a3f6)(8, 0, 0, 0, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004c930
// Address: 0x18004c930
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004c930(void)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t var_18h;
    
    piVar2 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar2 + 8);
    iVar3 = (*(code *)0x69a404)();
    if (iVar3 == iVar1) {
        (*(code *)0x69a3f6)(0x10, 0, 0, 0, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004c980
// Address: 0x18004c980
// Size: 248 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.18004c980(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined auStack_78 [32];
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    iVar2 = fcn.180088860(arg1, 1);
    iVar3 = fcn.180088860(arg1, 2);
    iVar4 = (*(code *)0x69a43e)(0);
    iVar5 = (*(code *)0x69a43e)(1);
    uVar6 = (*(code *)0x69a404)();
    (*(code *)0x69a3e6)(uVar6, &var_40h);
    var_48h._0_4_ = (int32_t)var_40h;
    var_48h._4_4_ = var_40h._4_4_;
    uVar6 = (*(code *)0x69a404)();
    (*(code *)0x69a42c)(uVar6, &var_48h);
    iVar2 = iVar2 + (int32_t)var_48h;
    iVar3 = var_48h._4_4_ + iVar3;
    piVar7 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar7 + 8);
    iVar8 = (*(code *)0x69a404)();
    if (iVar8 == iVar1) {
        var_58h = 0;
        (*(code *)0x69a3f6)(0x8001, iVar2 * (int32_t)(0xffff / (int64_t)(iVar4 + -1)), 
                            iVar3 * (int32_t)(0xffff / (int64_t)(iVar5 + -1)), 0);
    }
    fcn.180459870(var_30h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_18004ca80
// Address: 0x18004ca80
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18004ca80(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = fcn.180088860(arg1, 1);
    uVar3 = fcn.180088860(arg1, 2);
    piVar4 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar4 + 8);
    iVar5 = (*(code *)0x69a404)();
    if (iVar5 == iVar1) {
        (*(code *)0x69a3f6)(1, uVar2, uVar3, 0, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004cb00
// Address: 0x18004cb00
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004cb00(undefined8 param_1)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_18h;
    
    uVar2 = fcn.180088860(param_1, 1);
    piVar3 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(*piVar3 + 8);
    iVar4 = (*(code *)0x69a404)();
    if (iVar4 == iVar1) {
        (*(code *)0x69a3f6)(1, 0, 0, uVar2, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004cb60
// Address: 0x18004cb60
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18004cb60(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar3 = (int64_t *)fcn.180008740();
    uVar2 = fcn.180088860(arg1, 1);
    iVar1 = *(int64_t *)(*piVar3 + 8);
    iVar4 = (*(code *)0x69a404)();
    if (iVar4 == iVar1) {
        uVar2 = (*(code *)0x69a41a)(uVar2, 0);
        (*(code *)0x69a452)(0, uVar2, 8, 0);
    }
    return 0;
}

