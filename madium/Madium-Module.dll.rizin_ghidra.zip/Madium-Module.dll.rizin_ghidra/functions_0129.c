// Chunk 129 - 50 functions

// ============================================================
// Function: FUN_1801bd000
// Address: 0x1801bd000
// Size: 99 bytes
// ============================================================
undefined8 fcn.1801bd000(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd00c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar2 = *(undefined8 *)(in_RCX + 0xc00);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd025;
    iVar4 = fcn.180255960(uVar2, uVar1);
    if (iVar4 < 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar2 = *(undefined8 *)(in_RCX + 0xc10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd040;
        iVar4 = fcn.180255960(uVar2, uVar1);
        if (iVar4 < 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0xc10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd054;
            iVar4 = fcn.1802553f0(uVar1);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
                iVar4 = *(int32_t *)(in_RCX + 0xc40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd073;
                iVar5 = fcn.180255500(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
                if (iVar5 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd081;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
code_r0x0001801bd086:
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd099;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0af;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
                    return 0;
                }
                pcVar3 = *(code **)(in_RCX + 0xbe0);
                if (pcVar3 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd122;
                    iVar7 = fcn.18026bb70(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd12c;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        goto code_r0x0001801bd086;
                    }
                } else {
                    uVar1 = *(undefined8 *)(in_RCX + 0xbd0);
                    uVar2 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0d0;
                    iVar4 = (*pcVar3)(uVar2, uVar1);
                    if (iVar4 < 1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0d9;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0f1;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd107;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
                        return 0;
                    }
                }
                return 1;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd146;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd15e;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd174;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801bd063
// Address: 0x1801bd063
// Size: 25 bytes
// ============================================================
undefined8 fcn.1801bd000(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd00c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar2 = *(undefined8 *)(in_RCX + 0xc00);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd025;
    iVar4 = fcn.180255960(uVar2, uVar1);
    if (iVar4 < 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar2 = *(undefined8 *)(in_RCX + 0xc10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd040;
        iVar4 = fcn.180255960(uVar2, uVar1);
        if (iVar4 < 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0xc10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd054;
            iVar4 = fcn.1802553f0(uVar1);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
                iVar4 = *(int32_t *)(in_RCX + 0xc40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd073;
                iVar5 = fcn.180255500(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
                if (iVar5 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd081;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
code_r0x0001801bd086:
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd099;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0af;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
                    return 0;
                }
                pcVar3 = *(code **)(in_RCX + 0xbe0);
                if (pcVar3 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd122;
                    iVar7 = fcn.18026bb70(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd12c;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        goto code_r0x0001801bd086;
                    }
                } else {
                    uVar1 = *(undefined8 *)(in_RCX + 0xbd0);
                    uVar2 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0d0;
                    iVar4 = (*pcVar3)(uVar2, uVar1);
                    if (iVar4 < 1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0d9;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0f1;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd107;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
                        return 0;
                    }
                }
                return 1;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd146;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd15e;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd174;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801bd07c
// Address: 0x1801bd07c
// Size: 256 bytes
// ============================================================
undefined8 fcn.1801bd000(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd00c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *(undefined8 *)(in_RCX + 0xbf8);
    uVar2 = *(undefined8 *)(in_RCX + 0xc00);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd025;
    iVar4 = fcn.180255960(uVar2, uVar1);
    if (iVar4 < 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0xbf8);
        uVar2 = *(undefined8 *)(in_RCX + 0xc10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd040;
        iVar4 = fcn.180255960(uVar2, uVar1);
        if (iVar4 < 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0xc10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd054;
            iVar4 = fcn.1802553f0(uVar1);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
                iVar4 = *(int32_t *)(in_RCX + 0xc40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd073;
                iVar5 = fcn.180255500(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                                      *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6));
                if (iVar5 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd081;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
code_r0x0001801bd086:
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd099;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0af;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
                    return 0;
                }
                pcVar3 = *(code **)(in_RCX + 0xbe0);
                if (pcVar3 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd122;
                    iVar7 = fcn.18026bb70(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar6), 
                                          *(int64_t *)(&stack0x00000030 + iVar6));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd12c;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        goto code_r0x0001801bd086;
                    }
                } else {
                    uVar1 = *(undefined8 *)(in_RCX + 0xbd0);
                    uVar2 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0d0;
                    iVar4 = (*pcVar3)(uVar2, uVar1);
                    if (iVar4 < 1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0d9;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd0f1;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd107;
                        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
                        return 0;
                    }
                }
                return 1;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd146;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd15e;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801bd174;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801bd180
// Address: 0x1801bd180
// Size: 259 bytes
// ============================================================
undefined8 fcn.1801bd180(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd18c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 == 0) {
        return 0;
    }
    uVar1 = *(undefined8 *)(param_1 + 0x360);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd1b8;
    fcn.180224990(uVar1, 0x1804b01a8, 0x25);
    uVar1 = *(undefined8 *)(param_1 + 0x3a8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd1d1;
    fcn.180224990(uVar1, 0x1804b01a8, 0x26);
    uVar1 = *(undefined8 *)(param_1 + 0x368);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd1dd;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd1e9;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0x378);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd1f5;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0x380);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd201;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0x388);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd20d;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0x390);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd219;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0x398);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd225;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0x3a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd231;
    fcn.180255290(uVar1);
    *(undefined (*) [16])(param_1 + 0x340) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x350) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x360) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x370) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x380) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x390) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x3a0) = ZEXT816(0);
    *(undefined8 *)(param_1 + 0x3b0) = 0;
    *(undefined4 *)(param_1 + 0x3b0) = 0x400;
    return 1;
}

// ============================================================
// Function: FUN_1801bd2f0
// Address: 0x1801bd2f0
// Size: 190 bytes
// ============================================================
void fcn.1801bd2f0(int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd2fc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_48h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd32b;
    iVar1 = fcn.18021be60(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    if (0 < iVar1) {
        uVar3 = *(undefined8 *)(in_RCX + 0xc20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd345;
        uVar3 = fcn.180254c30((int64_t)&var_18h + iVar2, 0x30, uVar3);
        *(undefined8 *)(in_RCX + 0xc20) = uVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd35b;
        fcn.180244fc0((int64_t)&var_18h + iVar2, 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd375;
        uVar3 = fcn.18026b230(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
        *(undefined8 *)(in_RCX + 0xc18) = uVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd393;
        fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
        return;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd3a8;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1801bd3b0
// Address: 0x1801bd3b0
// Size: 259 bytes
// ============================================================
undefined8 fcn.1801bd3b0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd3bc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 == 0) {
        return 0;
    }
    uVar1 = *(undefined8 *)(param_1 + 0xbf0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd3e8;
    fcn.180224990(uVar1, 0x1804b01a8, 0x41);
    uVar1 = *(undefined8 *)(param_1 + 0xc38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd401;
    fcn.180224990(uVar1, 0x1804b01a8, 0x42);
    uVar1 = *(undefined8 *)(param_1 + 0xbf8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd40d;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0xc00);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd419;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0xc08);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd425;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0xc10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd431;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0xc18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd43d;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0xc20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd449;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0xc28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd455;
    fcn.180255290(uVar1);
    uVar1 = *(undefined8 *)(param_1 + 0xc30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd461;
    fcn.180255290(uVar1);
    *(undefined (*) [16])(param_1 + 0xbd0) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0xc30) = ZEXT816(0);
    *(undefined8 *)(param_1 + 0xc40) = 0;
    *(undefined4 *)(param_1 + 0xc40) = 0x400;
    return 1;
}

// ============================================================
// Function: FUN_1801bd4c0
// Address: 0x1801bd4c0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801bd4c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar4;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd4d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX == 0) || (iVar1 = *(int64_t *)(in_RCX + 8), iVar1 == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
    *(undefined (*) [16])(in_RCX + 0xbd0) = ZEXT816(0);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RSI;
    *(undefined (*) [16])(in_RCX + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc30) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0xc40) = 0;
    *(undefined8 *)(in_RCX + 0xbd0) = *(undefined8 *)(iVar1 + 0x340);
    *(undefined8 *)(in_RCX + 0xbd8) = *(undefined8 *)(iVar1 + 0x348);
    *(undefined8 *)(in_RCX + 0xbe0) = *(undefined8 *)(iVar1 + 0x350);
    *(undefined8 *)(in_RCX + 0xbe8) = *(undefined8 *)(iVar1 + 0x358);
    *(undefined4 *)(in_RCX + 0xc40) = *(undefined4 *)(iVar1 + 0x3b0);
    if (*(int64_t *)(iVar1 + 0x368) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd588;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xbf8) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd598;
code_r0x0001801bd66b:
        uVar4 = 0x80003;
        goto code_r0x0001801bd6f5;
    }
code_r0x0001801bd598:
    if (*(int64_t *)(iVar1 + 0x370) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5a9;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc00) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x378) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5ca;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc08) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x380) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5eb;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc10) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x388) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd608;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc18) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x390) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd625;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc20) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x3a0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd642;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc30) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x398) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd65f;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc28) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    iVar3 = *(int64_t *)(iVar1 + 0x360);
    if (iVar3 == 0) {
code_r0x0001801bd6b9:
        iVar3 = *(int64_t *)(iVar1 + 0x3a8);
        if (iVar3 == 0) {
code_r0x0001801bd7fe:
            *(undefined4 *)(in_RCX + 0xc44) = *(undefined4 *)(iVar1 + 0x3b4);
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd6db;
        iVar3 = func_0x0001802231e0(iVar3, 0x1804b01a8, 0x8b);
        *(int64_t *)(in_RCX + 0xc38) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd7fe;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd69c;
        iVar3 = func_0x0001802231e0(iVar3, 0x1804b01a8, 0x86);
        *(int64_t *)(in_RCX + 0xbf0) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd6b9;
    }
    uVar4 = 0xc0103;
code_r0x0001801bd6f5:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd6fa;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd70f;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd71e;
    func_0x0001802296d0(0x14, uVar4, 0);
    uVar4 = *(undefined8 *)(in_RCX + 0xbf0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd733;
    fcn.180224990(uVar4, 0x1804b01a8, 0x93);
    uVar4 = *(undefined8 *)(in_RCX + 0xc38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd74c;
    fcn.180224990(uVar4, 0x1804b01a8, 0x94);
    uVar4 = *(undefined8 *)(in_RCX + 0xbf8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd758;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc00);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd764;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc08);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd770;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd77c;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd788;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd794;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd7a0;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd7ac;
    fcn.180255290(uVar4);
    *(undefined (*) [16])(in_RCX + 0xbd0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc30) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0xc40) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801bd4ef
// Address: 0x1801bd4ef
// Size: 783 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801bd4c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar4;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd4d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX == 0) || (iVar1 = *(int64_t *)(in_RCX + 8), iVar1 == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
    *(undefined (*) [16])(in_RCX + 0xbd0) = ZEXT816(0);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RSI;
    *(undefined (*) [16])(in_RCX + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc30) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0xc40) = 0;
    *(undefined8 *)(in_RCX + 0xbd0) = *(undefined8 *)(iVar1 + 0x340);
    *(undefined8 *)(in_RCX + 0xbd8) = *(undefined8 *)(iVar1 + 0x348);
    *(undefined8 *)(in_RCX + 0xbe0) = *(undefined8 *)(iVar1 + 0x350);
    *(undefined8 *)(in_RCX + 0xbe8) = *(undefined8 *)(iVar1 + 0x358);
    *(undefined4 *)(in_RCX + 0xc40) = *(undefined4 *)(iVar1 + 0x3b0);
    if (*(int64_t *)(iVar1 + 0x368) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd588;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xbf8) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd598;
code_r0x0001801bd66b:
        uVar4 = 0x80003;
        goto code_r0x0001801bd6f5;
    }
code_r0x0001801bd598:
    if (*(int64_t *)(iVar1 + 0x370) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5a9;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc00) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x378) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5ca;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc08) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x380) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5eb;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc10) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x388) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd608;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc18) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x390) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd625;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc20) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x3a0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd642;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc30) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x398) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd65f;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc28) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    iVar3 = *(int64_t *)(iVar1 + 0x360);
    if (iVar3 == 0) {
code_r0x0001801bd6b9:
        iVar3 = *(int64_t *)(iVar1 + 0x3a8);
        if (iVar3 == 0) {
code_r0x0001801bd7fe:
            *(undefined4 *)(in_RCX + 0xc44) = *(undefined4 *)(iVar1 + 0x3b4);
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd6db;
        iVar3 = func_0x0001802231e0(iVar3, 0x1804b01a8, 0x8b);
        *(int64_t *)(in_RCX + 0xc38) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd7fe;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd69c;
        iVar3 = func_0x0001802231e0(iVar3, 0x1804b01a8, 0x86);
        *(int64_t *)(in_RCX + 0xbf0) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd6b9;
    }
    uVar4 = 0xc0103;
code_r0x0001801bd6f5:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd6fa;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd70f;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd71e;
    func_0x0001802296d0(0x14, uVar4, 0);
    uVar4 = *(undefined8 *)(in_RCX + 0xbf0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd733;
    fcn.180224990(uVar4, 0x1804b01a8, 0x93);
    uVar4 = *(undefined8 *)(in_RCX + 0xc38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd74c;
    fcn.180224990(uVar4, 0x1804b01a8, 0x94);
    uVar4 = *(undefined8 *)(in_RCX + 0xbf8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd758;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc00);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd764;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc08);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd770;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd77c;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd788;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd794;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd7a0;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd7ac;
    fcn.180255290(uVar4);
    *(undefined (*) [16])(in_RCX + 0xbd0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc30) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0xc40) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801bd7fe
// Address: 0x1801bd7fe
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801bd4c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar4;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd4d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX == 0) || (iVar1 = *(int64_t *)(in_RCX + 8), iVar1 == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
    *(undefined (*) [16])(in_RCX + 0xbd0) = ZEXT816(0);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RSI;
    *(undefined (*) [16])(in_RCX + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc30) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0xc40) = 0;
    *(undefined8 *)(in_RCX + 0xbd0) = *(undefined8 *)(iVar1 + 0x340);
    *(undefined8 *)(in_RCX + 0xbd8) = *(undefined8 *)(iVar1 + 0x348);
    *(undefined8 *)(in_RCX + 0xbe0) = *(undefined8 *)(iVar1 + 0x350);
    *(undefined8 *)(in_RCX + 0xbe8) = *(undefined8 *)(iVar1 + 0x358);
    *(undefined4 *)(in_RCX + 0xc40) = *(undefined4 *)(iVar1 + 0x3b0);
    if (*(int64_t *)(iVar1 + 0x368) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd588;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xbf8) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd598;
code_r0x0001801bd66b:
        uVar4 = 0x80003;
        goto code_r0x0001801bd6f5;
    }
code_r0x0001801bd598:
    if (*(int64_t *)(iVar1 + 0x370) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5a9;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc00) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x378) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5ca;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc08) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x380) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5eb;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc10) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x388) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd608;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc18) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x390) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd625;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc20) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x3a0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd642;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc30) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x398) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd65f;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc28) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    iVar3 = *(int64_t *)(iVar1 + 0x360);
    if (iVar3 == 0) {
code_r0x0001801bd6b9:
        iVar3 = *(int64_t *)(iVar1 + 0x3a8);
        if (iVar3 == 0) {
code_r0x0001801bd7fe:
            *(undefined4 *)(in_RCX + 0xc44) = *(undefined4 *)(iVar1 + 0x3b4);
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd6db;
        iVar3 = func_0x0001802231e0(iVar3, 0x1804b01a8, 0x8b);
        *(int64_t *)(in_RCX + 0xc38) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd7fe;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd69c;
        iVar3 = func_0x0001802231e0(iVar3, 0x1804b01a8, 0x86);
        *(int64_t *)(in_RCX + 0xbf0) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd6b9;
    }
    uVar4 = 0xc0103;
code_r0x0001801bd6f5:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd6fa;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd70f;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd71e;
    func_0x0001802296d0(0x14, uVar4, 0);
    uVar4 = *(undefined8 *)(in_RCX + 0xbf0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd733;
    fcn.180224990(uVar4, 0x1804b01a8, 0x93);
    uVar4 = *(undefined8 *)(in_RCX + 0xc38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd74c;
    fcn.180224990(uVar4, 0x1804b01a8, 0x94);
    uVar4 = *(undefined8 *)(in_RCX + 0xbf8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd758;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc00);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd764;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc08);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd770;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd77c;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd788;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd794;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd7a0;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd7ac;
    fcn.180255290(uVar4);
    *(undefined (*) [16])(in_RCX + 0xbd0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc30) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0xc40) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801bd811
// Address: 0x1801bd811
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801bd4c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar4;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd4d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX == 0) || (iVar1 = *(int64_t *)(in_RCX + 8), iVar1 == 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBP;
    *(undefined (*) [16])(in_RCX + 0xbd0) = ZEXT816(0);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RSI;
    *(undefined (*) [16])(in_RCX + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc30) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0xc40) = 0;
    *(undefined8 *)(in_RCX + 0xbd0) = *(undefined8 *)(iVar1 + 0x340);
    *(undefined8 *)(in_RCX + 0xbd8) = *(undefined8 *)(iVar1 + 0x348);
    *(undefined8 *)(in_RCX + 0xbe0) = *(undefined8 *)(iVar1 + 0x350);
    *(undefined8 *)(in_RCX + 0xbe8) = *(undefined8 *)(iVar1 + 0x358);
    *(undefined4 *)(in_RCX + 0xc40) = *(undefined4 *)(iVar1 + 0x3b0);
    if (*(int64_t *)(iVar1 + 0x368) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd588;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xbf8) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd598;
code_r0x0001801bd66b:
        uVar4 = 0x80003;
        goto code_r0x0001801bd6f5;
    }
code_r0x0001801bd598:
    if (*(int64_t *)(iVar1 + 0x370) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5a9;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc00) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x378) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5ca;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc08) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x380) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd5eb;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc10) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x388) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd608;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc18) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x390) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd625;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc20) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x3a0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd642;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc30) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    if (*(int64_t *)(iVar1 + 0x398) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd65f;
        iVar3 = func_0x0001802551a0();
        *(int64_t *)(in_RCX + 0xc28) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801bd66b;
    }
    iVar3 = *(int64_t *)(iVar1 + 0x360);
    if (iVar3 == 0) {
code_r0x0001801bd6b9:
        iVar3 = *(int64_t *)(iVar1 + 0x3a8);
        if (iVar3 == 0) {
code_r0x0001801bd7fe:
            *(undefined4 *)(in_RCX + 0xc44) = *(undefined4 *)(iVar1 + 0x3b4);
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd6db;
        iVar3 = func_0x0001802231e0(iVar3, 0x1804b01a8, 0x8b);
        *(int64_t *)(in_RCX + 0xc38) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd7fe;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd69c;
        iVar3 = func_0x0001802231e0(iVar3, 0x1804b01a8, 0x86);
        *(int64_t *)(in_RCX + 0xbf0) = iVar3;
        if (iVar3 != 0) goto code_r0x0001801bd6b9;
    }
    uVar4 = 0xc0103;
code_r0x0001801bd6f5:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd6fa;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd70f;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd71e;
    func_0x0001802296d0(0x14, uVar4, 0);
    uVar4 = *(undefined8 *)(in_RCX + 0xbf0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd733;
    fcn.180224990(uVar4, 0x1804b01a8, 0x93);
    uVar4 = *(undefined8 *)(in_RCX + 0xc38);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd74c;
    fcn.180224990(uVar4, 0x1804b01a8, 0x94);
    uVar4 = *(undefined8 *)(in_RCX + 0xbf8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd758;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc00);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd764;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc08);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd770;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd77c;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd788;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd794;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd7a0;
    fcn.180255290(uVar4);
    uVar4 = *(undefined8 *)(in_RCX + 0xc30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801bd7ac;
    fcn.180255290(uVar4);
    *(undefined (*) [16])(in_RCX + 0xbd0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbe0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xbf0) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc00) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc10) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc20) = ZEXT816(0);
    *(undefined (*) [16])(in_RCX + 0xc30) = ZEXT816(0);
    *(undefined8 *)(in_RCX + 0xc40) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801bd820
// Address: 0x1801bd820
// Size: 333 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801bd820(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined4 *in_RDX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd835;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_58h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7);
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *in_RDX = 0x73;
    pcVar2 = *(code **)(in_RCX + 0xbd8);
    if (pcVar2 != (code *)0x0) {
        uVar8 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801bd870;
        iVar6 = (*pcVar2)(uVar8);
        if (iVar6 != 0) goto code_r0x0001801bd94e;
    }
    *in_RDX = 0x50;
    if ((((*(int64_t *)(in_RCX + 0xbf8) != 0) && (*(int64_t *)(in_RCX + 0xc00) != 0)) &&
        (*(int64_t *)(in_RCX + 0xc08) != 0)) && (*(int64_t *)(in_RCX + 0xc30) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801bd8d0;
        iVar6 = fcn.18021be60(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)(&stack0x00000038 + iVar7), 
                              *(int64_t *)(&stack0x00000040 + iVar7), *(int64_t *)(&stack0x00000048 + iVar7), 
                              *(int64_t *)(&stack0x00000050 + iVar7));
        if (0 < iVar6) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801bd8e6;
            uVar8 = fcn.180254c30((int64_t)&arg_28h + iVar7, 0x30, 0);
            *(undefined8 *)(in_RCX + 0xc28) = uVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801bd8fc;
            fcn.180244fc0((int64_t)&arg_28h + iVar7, 0x30);
            uVar8 = *(undefined8 *)(in_RCX + 0xc30);
            uVar3 = *(undefined8 *)(in_RCX + 0xc00);
            uVar4 = *(undefined8 *)(in_RCX + 0xbf8);
            uVar5 = *(undefined8 *)(in_RCX + 0xc28);
            *(undefined8 *)((int64_t)&var_20h + iVar7) = puVar1[0x8c];
            *(undefined8 *)((int64_t)&var_18h + iVar7) = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801bd931;
            uVar8 = func_0x00018026b2e0(uVar5, uVar4, uVar3, uVar8);
            *(undefined8 *)(in_RCX + 0xc10) = uVar8;
        }
    }
code_r0x0001801bd94e:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801bd95b;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar7) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801bd970
// Address: 0x1801bd970
// Size: 74 bytes
// ============================================================
undefined8 fcn.1801bd970(int64_t arg_28h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd97c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(uint32_t *)(in_RCX + 0x70);
    iVar2 = in_RCX;
    while (uVar1 = uVar1 >> 3 & 3, uVar1 == 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x40);
        if (iVar2 == 0) goto code_r0x0001801bd9b4;
        uVar1 = *(uint32_t *)(iVar2 + 0x70);
    }
    if (uVar1 == 1) {
        return 0;
    }
code_r0x0001801bd9b4:
    uVar5 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9c4;
    func_0x0001801dd860(uVar5, 0);
    uVar5 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9cd;
    uVar5 = func_0x0001801dd6d0(uVar5);
    if ((*(uint8_t *)(in_RCX + 0x68) & 0x18) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9de;
    iVar3 = func_0x0001801dd110(uVar5);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9ea;
        iVar3 = func_0x0001801dd120(uVar5);
        if (iVar3 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801bd9ba
// Address: 0x1801bd9ba
// Size: 65 bytes
// ============================================================
undefined8 fcn.1801bd970(int64_t arg_28h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd97c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(uint32_t *)(in_RCX + 0x70);
    iVar2 = in_RCX;
    while (uVar1 = uVar1 >> 3 & 3, uVar1 == 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x40);
        if (iVar2 == 0) goto code_r0x0001801bd9b4;
        uVar1 = *(uint32_t *)(iVar2 + 0x70);
    }
    if (uVar1 == 1) {
        return 0;
    }
code_r0x0001801bd9b4:
    uVar5 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9c4;
    func_0x0001801dd860(uVar5, 0);
    uVar5 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9cd;
    uVar5 = func_0x0001801dd6d0(uVar5);
    if ((*(uint8_t *)(in_RCX + 0x68) & 0x18) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9de;
    iVar3 = func_0x0001801dd110(uVar5);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9ea;
        iVar3 = func_0x0001801dd120(uVar5);
        if (iVar3 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801bd9fb
// Address: 0x1801bd9fb
// Size: 16 bytes
// ============================================================
undefined8 fcn.1801bd970(int64_t arg_28h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bd97c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(uint32_t *)(in_RCX + 0x70);
    iVar2 = in_RCX;
    while (uVar1 = uVar1 >> 3 & 3, uVar1 == 0) {
        iVar2 = *(int64_t *)(iVar2 + 0x40);
        if (iVar2 == 0) goto code_r0x0001801bd9b4;
        uVar1 = *(uint32_t *)(iVar2 + 0x70);
    }
    if (uVar1 == 1) {
        return 0;
    }
code_r0x0001801bd9b4:
    uVar5 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9c4;
    func_0x0001801dd860(uVar5, 0);
    uVar5 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9cd;
    uVar5 = func_0x0001801dd6d0(uVar5);
    if ((*(uint8_t *)(in_RCX + 0x68) & 0x18) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9de;
    iVar3 = func_0x0001801dd110(uVar5);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bd9ea;
        iVar3 = func_0x0001801dd120(uVar5);
        if (iVar3 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801bda70
// Address: 0x1801bda70
// Size: 311 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_6b8h because it doesn't fit into ProtoModel

undefined8 fcn.1801bda70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint32_t uVar4;
    int64_t in_RDX;
    char in_R8B;
    uint8_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bda8a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (((((in_RCX != 0) && ((*(uint8_t *)(in_RCX + 0x70) & 1) == 0)) && (in_R8B < '\0')) &&
        ((in_R9 == (uint8_t *)0x0 || ((*in_R9 & 0x80) != 0)))) &&
       ((iVar1 = *(int64_t *)((int64_t)&arg_48h + iVar3), iVar1 == 0 || (in_R9 == (uint8_t *)0x0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bdadc;
        iVar2 = func_0x000180196e10();
        if (iVar2 != 0) {
            iVar3 = *(int64_t *)((int64_t)&arg_50h + iVar3);
            *(undefined8 *)(in_RCX + 0x68) = *(undefined8 *)(in_RDX + 0x6c0);
            *(int64_t *)(in_RCX + 0x58) = iVar1;
            *(int64_t *)(in_RCX + 0x60) = iVar3;
            *(uint8_t **)(in_RCX + 0x40) = in_R9;
            uVar4 = -(uint32_t)(iVar1 != 0) & 2 | *(uint32_t *)(in_RCX + 0x70) & 0xffffffe1 |
                    -(uint32_t)(iVar3 != 0) & 4;
            *(uint32_t *)(in_RCX + 0x70) = uVar4;
            iVar3 = in_RCX;
            do {
                if ((*(uint32_t *)(iVar3 + 0x70) & 2) != 0) {
                    *(int64_t *)(in_RCX + 0x48) = iVar3;
                    *(undefined8 *)(in_RCX + 0x58) = *(undefined8 *)(iVar3 + 0x58);
                    iVar3 = in_RCX;
                    goto code_r0x0001801bdb67;
                }
            } while (((iVar3 == in_RCX) || ((*(uint32_t *)(iVar3 + 0x70) & 1) != 0)) &&
                    (iVar3 = *(int64_t *)(iVar3 + 0x40), iVar3 != 0));
        }
        *(uint32_t *)(in_RCX + 0x70) = *(uint32_t *)(in_RCX + 0x70) & 0xfffffff9;
    }
    return 0;
    while (iVar3 = *(int64_t *)(iVar3 + 0x40), iVar3 != 0) {
code_r0x0001801bdb67:
        if ((*(uint8_t *)(iVar3 + 0x70) & 4) != 0) break;
    }
    *(int64_t *)(in_RCX + 0x50) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)(in_RCX + 0x60) = 0;
        *(uint32_t *)(in_RCX + 0x70) = uVar4 | 1;
    } else {
        *(undefined8 *)(in_RCX + 0x60) = *(undefined8 *)(iVar3 + 0x60);
        *(uint32_t *)(in_RCX + 0x70) = uVar4 | 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801bdbb0
// Address: 0x1801bdbb0
// Size: 296 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_6b8h because it doesn't fit into ProtoModel

int64_t fcn.1801bdbb0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bdbca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bdbea;
    iVar5 = func_0x000180224d60(0xc0, 0x1804b0248, 0x8cc);
    if (iVar5 == 0) {
        uVar2 = 0x8000f;
        uVar6 = 0x8cd;
    } else {
        *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bdc20;
        iVar3 = fcn.1801bda70(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4));
        if (iVar3 == 0) {
            uVar2 = 0xc0103;
            uVar6 = 0x8d3;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bdc39;
            iVar3 = func_0x000180194eb0(in_RCX);
            if (iVar3 != 0) {
                *(int64_t *)(iVar5 + 0x78) = in_RCX;
                *(undefined4 *)(iVar5 + 0xa8) = *(undefined4 *)(in_RCX + 0x108);
                uVar1 = *(uint32_t *)(in_RCX + 0x110);
                *(undefined4 *)(iVar5 + 0xb8) = 0;
                *(uint64_t *)(iVar5 + 0xb0) = (uint64_t)uVar1 & 0xde0fa987;
                *(undefined8 *)(iVar5 + 0x80) = in_RDX;
                *(int64_t *)(in_RCX + 0xf8) = *(int64_t *)(in_RCX + 0xf8) + 1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bdcc0;
                func_0x0001801c22c0(iVar5);
                return iVar5;
            }
            uVar2 = 0x80014;
            uVar6 = 0x8d9;
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar4) = uVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bdc66;
    func_0x0001801c1390(0, 0x1804b0248, uVar6, 0x1804b0408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bdc7b;
    fcn.180224990(iVar5, 0x1804b0248, 0x8ea);
    return 0;
}

// ============================================================
// Function: FUN_1801bdce0
// Address: 0x1801bdce0
// Size: 148 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801bdce0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *in_RCX;
    int32_t **in_RDX;
    uint64_t uVar9;
    int32_t iVar10;
    uint64_t in_R8;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801bdcf6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar10 = 0;
    *in_RDX = (int32_t *)0x0;
    in_RDX[1] = (int32_t *)0x0;
    in_RDX[2] = (int32_t *)0x0;
    in_RDX[3] = (int32_t *)0x0;
    in_RDX[4] = (int32_t *)0x0;
    in_RDX[5] = (int32_t *)0x0;
    *(undefined4 *)(in_RDX + 6) = 0;
    bVar3 = false;
    uVar9 = (uint64_t)((uint32_t)in_R8 | 2);
    if ((in_R8 & 8) == 0) {
        uVar9 = in_R8 & 0xffffffff;
    }
    *(uint32_t *)((int64_t)in_RDX + 0x34) = (uint32_t)((uVar9 & 0x40) != 0);
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0102;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdd6d;
        func_0x0001801c1390(0, 0x1804b0248, 0x115, 0x1804b0260);
        return 0;
    }
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
    if (iVar4 == 0x80) {
        *in_RDX = in_RCX;
        in_RDX[1] = *(int32_t **)(in_RCX + 0x22);
        in_RDX[2] = *(int32_t **)(in_RCX + 0x20);
        in_RDX[3] = in_RCX;
        bVar3 = false;
        if ((uVar9 & 8) == 0) {
code_r0x0001801bdf18:
            if (((uVar9 & 1) != 0) || ((*(int64_t *)(in_RCX + 0x2c) != 0 && ((uVar9 & 2) != 0)))) {
                in_RDX[4] = *(int32_t **)(in_RCX + 0x2c);
                goto code_r0x0001801be03e;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf3f;
            func_0x0001801c2160(in_RCX, uVar9);
code_r0x0001801be099:
            if (!bVar3) {
                return iVar10;
            }
            if ((iVar10 != 0) && ((in_R8 & 0x20) != 0)) {
                return iVar10;
            }
        } else {
            uVar8 = *(undefined8 *)(in_RCX + 0x16);
            if ((uVar9 & 0x40) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdeb7;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdebf;
                func_0x00018026d890(uVar8);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde7c;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde84;
                func_0x00018026d890(uVar8);
                *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                if (*(int32_t *)(in_RDX + 5) == 0) {
                    if (in_RDX[3] != (int32_t *)0x0) {
                        in_RDX[3][0x4a] = 0;
                    }
                } else if (in_RDX[4] != (int32_t *)0x0) {
                    in_RDX[4][0x2e] = 0;
                }
            }
            bVar3 = true;
            if (*(int64_t *)(in_RCX + 0x2c) != 0) goto code_r0x0001801bdf18;
            if ((*(uint8_t *)(in_RCX + 0x40) & 0x20) == 0) {
                uVar8 = *(undefined8 *)(in_RCX + 0x28);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdee7;
                iVar4 = func_0x0001801e3b50(uVar8);
                if (iVar4 != 0) goto code_r0x0001801be008;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdef7;
                iVar4 = func_0x0001801c0be0(in_RDX);
                if (0 < iVar4) {
                    if ((uVar9 & 0x10) == 0) {
                        piVar1 = in_RDX[3];
                        if (((*(uint8_t *)(piVar1 + 0x40) & 0x10) == 0) && (iVar4 = piVar1[0x41], iVar4 != 0)) {
                            *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R15;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf7a;
                            iVar7 = func_0x0001801c0980(in_RDX, iVar4 == 2, 0);
                            iVar2 = *(int64_t *)(piVar1 + 0x2c);
                            if (iVar2 != iVar7) {
                                *(int64_t *)(piVar1 + 0x2c) = iVar7;
                                if (iVar7 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf9a;
                                    func_0x000180194eb0(piVar1);
                                } else {
                                    LOCK();
                                    piVar1[8] = piVar1[8] + -1;
                                    UNLOCK();
                                }
                                if (iVar2 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfae;
                                    func_0x000180193500(iVar2);
                                }
                            }
                            if (*(int64_t *)(piVar1 + 0x2c) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfd1;
                                func_0x0001801c05d0(piVar1);
                                goto code_r0x0001801bdf18;
                            }
                            uVar8 = 0x84b;
                            uVar5 = 0xc0103;
                        } else {
                            uVar8 = 0x841;
                            uVar5 = 0x163;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = uVar5;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be003;
                        iVar4 = func_0x0001801c1390(in_RDX, 0x1804b0248, uVar8, 0x1804b03a0);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf10;
                        iVar4 = func_0x0001801c0620(in_RDX, 0);
                    }
                    if (iVar4 != 0) goto code_r0x0001801bdf18;
                }
            } else {
code_r0x0001801be008:
                *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xcf;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be031;
                func_0x0001801c1390(in_RDX, 0x1804b0248, 0x145, 0x1804b0260);
            }
        }
        uVar8 = *(undefined8 *)(*in_RDX + 0x16);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0b3;
        uVar8 = func_0x0001801dd6c0(uVar8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0bb;
        func_0x00018026d900(uVar8);
    } else {
        if (iVar4 == 0x81) {
            if ((uVar9 & 2) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x88);
                in_RDX[2] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x80);
                in_RDX[3] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[4] = in_RCX;
                *(undefined4 *)(in_RDX + 5) = 1;
                goto code_r0x0001801be03e;
            }
        } else {
            if (iVar4 != 0x82) {
                if (iVar4 != 0x83) {
                    *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0103;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddbc;
                    func_0x0001801c1390(0, 0x1804b0248, 0x170, 0x1804b0260);
                    return 0;
                }
                if (-1 < (char)uVar9) goto code_r0x0001801bddc6;
                *in_RDX = in_RCX;
                in_RDX[1] = in_RCX;
                *(undefined4 *)(in_RDX + 6) = 1;
                bVar3 = false;
code_r0x0001801be03e:
                if (((in_R8 & 0x20) != 0) && (!bVar3)) {
                    uVar8 = *(undefined8 *)(*in_RDX + 0x16);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be054;
                    uVar8 = func_0x0001801dd6c0(uVar8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be05c;
                    func_0x00018026d890(uVar8);
                    if ((uVar9 & 0x40) != 0) {
                        *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                        if (*(int32_t *)(in_RDX + 5) == 0) {
                            if (in_RDX[3] != (int32_t *)0x0) {
                                in_RDX[3][0x4a] = 0;
                            }
                        } else if (in_RDX[4] != (int32_t *)0x0) {
                            in_RDX[4][0x2e] = 0;
                        }
                    }
                    bVar3 = true;
                }
                iVar10 = 1;
                goto code_r0x0001801be099;
            }
            if ((uVar9 & 4) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[2] = in_RCX;
                *(undefined4 *)((int64_t)in_RDX + 0x2c) = 1;
                goto code_r0x0001801be03e;
            }
        }
code_r0x0001801bddc6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddd0;
        func_0x0001801c2160(in_RCX, uVar9);
    }
    return iVar10;
}

// ============================================================
// Function: FUN_1801bdd74
// Address: 0x1801bdd74
// Size: 496 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801bdce0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *in_RCX;
    int32_t **in_RDX;
    uint64_t uVar9;
    int32_t iVar10;
    uint64_t in_R8;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801bdcf6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar10 = 0;
    *in_RDX = (int32_t *)0x0;
    in_RDX[1] = (int32_t *)0x0;
    in_RDX[2] = (int32_t *)0x0;
    in_RDX[3] = (int32_t *)0x0;
    in_RDX[4] = (int32_t *)0x0;
    in_RDX[5] = (int32_t *)0x0;
    *(undefined4 *)(in_RDX + 6) = 0;
    bVar3 = false;
    uVar9 = (uint64_t)((uint32_t)in_R8 | 2);
    if ((in_R8 & 8) == 0) {
        uVar9 = in_R8 & 0xffffffff;
    }
    *(uint32_t *)((int64_t)in_RDX + 0x34) = (uint32_t)((uVar9 & 0x40) != 0);
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0102;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdd6d;
        func_0x0001801c1390(0, 0x1804b0248, 0x115, 0x1804b0260);
        return 0;
    }
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
    if (iVar4 == 0x80) {
        *in_RDX = in_RCX;
        in_RDX[1] = *(int32_t **)(in_RCX + 0x22);
        in_RDX[2] = *(int32_t **)(in_RCX + 0x20);
        in_RDX[3] = in_RCX;
        bVar3 = false;
        if ((uVar9 & 8) == 0) {
code_r0x0001801bdf18:
            if (((uVar9 & 1) != 0) || ((*(int64_t *)(in_RCX + 0x2c) != 0 && ((uVar9 & 2) != 0)))) {
                in_RDX[4] = *(int32_t **)(in_RCX + 0x2c);
                goto code_r0x0001801be03e;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf3f;
            func_0x0001801c2160(in_RCX, uVar9);
code_r0x0001801be099:
            if (!bVar3) {
                return iVar10;
            }
            if ((iVar10 != 0) && ((in_R8 & 0x20) != 0)) {
                return iVar10;
            }
        } else {
            uVar8 = *(undefined8 *)(in_RCX + 0x16);
            if ((uVar9 & 0x40) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdeb7;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdebf;
                func_0x00018026d890(uVar8);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde7c;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde84;
                func_0x00018026d890(uVar8);
                *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                if (*(int32_t *)(in_RDX + 5) == 0) {
                    if (in_RDX[3] != (int32_t *)0x0) {
                        in_RDX[3][0x4a] = 0;
                    }
                } else if (in_RDX[4] != (int32_t *)0x0) {
                    in_RDX[4][0x2e] = 0;
                }
            }
            bVar3 = true;
            if (*(int64_t *)(in_RCX + 0x2c) != 0) goto code_r0x0001801bdf18;
            if ((*(uint8_t *)(in_RCX + 0x40) & 0x20) == 0) {
                uVar8 = *(undefined8 *)(in_RCX + 0x28);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdee7;
                iVar4 = func_0x0001801e3b50(uVar8);
                if (iVar4 != 0) goto code_r0x0001801be008;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdef7;
                iVar4 = func_0x0001801c0be0(in_RDX);
                if (0 < iVar4) {
                    if ((uVar9 & 0x10) == 0) {
                        piVar1 = in_RDX[3];
                        if (((*(uint8_t *)(piVar1 + 0x40) & 0x10) == 0) && (iVar4 = piVar1[0x41], iVar4 != 0)) {
                            *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R15;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf7a;
                            iVar7 = func_0x0001801c0980(in_RDX, iVar4 == 2, 0);
                            iVar2 = *(int64_t *)(piVar1 + 0x2c);
                            if (iVar2 != iVar7) {
                                *(int64_t *)(piVar1 + 0x2c) = iVar7;
                                if (iVar7 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf9a;
                                    func_0x000180194eb0(piVar1);
                                } else {
                                    LOCK();
                                    piVar1[8] = piVar1[8] + -1;
                                    UNLOCK();
                                }
                                if (iVar2 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfae;
                                    func_0x000180193500(iVar2);
                                }
                            }
                            if (*(int64_t *)(piVar1 + 0x2c) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfd1;
                                func_0x0001801c05d0(piVar1);
                                goto code_r0x0001801bdf18;
                            }
                            uVar8 = 0x84b;
                            uVar5 = 0xc0103;
                        } else {
                            uVar8 = 0x841;
                            uVar5 = 0x163;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = uVar5;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be003;
                        iVar4 = func_0x0001801c1390(in_RDX, 0x1804b0248, uVar8, 0x1804b03a0);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf10;
                        iVar4 = func_0x0001801c0620(in_RDX, 0);
                    }
                    if (iVar4 != 0) goto code_r0x0001801bdf18;
                }
            } else {
code_r0x0001801be008:
                *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xcf;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be031;
                func_0x0001801c1390(in_RDX, 0x1804b0248, 0x145, 0x1804b0260);
            }
        }
        uVar8 = *(undefined8 *)(*in_RDX + 0x16);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0b3;
        uVar8 = func_0x0001801dd6c0(uVar8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0bb;
        func_0x00018026d900(uVar8);
    } else {
        if (iVar4 == 0x81) {
            if ((uVar9 & 2) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x88);
                in_RDX[2] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x80);
                in_RDX[3] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[4] = in_RCX;
                *(undefined4 *)(in_RDX + 5) = 1;
                goto code_r0x0001801be03e;
            }
        } else {
            if (iVar4 != 0x82) {
                if (iVar4 != 0x83) {
                    *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0103;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddbc;
                    func_0x0001801c1390(0, 0x1804b0248, 0x170, 0x1804b0260);
                    return 0;
                }
                if (-1 < (char)uVar9) goto code_r0x0001801bddc6;
                *in_RDX = in_RCX;
                in_RDX[1] = in_RCX;
                *(undefined4 *)(in_RDX + 6) = 1;
                bVar3 = false;
code_r0x0001801be03e:
                if (((in_R8 & 0x20) != 0) && (!bVar3)) {
                    uVar8 = *(undefined8 *)(*in_RDX + 0x16);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be054;
                    uVar8 = func_0x0001801dd6c0(uVar8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be05c;
                    func_0x00018026d890(uVar8);
                    if ((uVar9 & 0x40) != 0) {
                        *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                        if (*(int32_t *)(in_RDX + 5) == 0) {
                            if (in_RDX[3] != (int32_t *)0x0) {
                                in_RDX[3][0x4a] = 0;
                            }
                        } else if (in_RDX[4] != (int32_t *)0x0) {
                            in_RDX[4][0x2e] = 0;
                        }
                    }
                    bVar3 = true;
                }
                iVar10 = 1;
                goto code_r0x0001801be099;
            }
            if ((uVar9 & 4) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[2] = in_RCX;
                *(undefined4 *)((int64_t)in_RDX + 0x2c) = 1;
                goto code_r0x0001801be03e;
            }
        }
code_r0x0001801bddc6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddd0;
        func_0x0001801c2160(in_RCX, uVar9);
    }
    return iVar10;
}

// ============================================================
// Function: FUN_1801bdf64
// Address: 0x1801bdf64
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801bdce0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *in_RCX;
    int32_t **in_RDX;
    uint64_t uVar9;
    int32_t iVar10;
    uint64_t in_R8;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801bdcf6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar10 = 0;
    *in_RDX = (int32_t *)0x0;
    in_RDX[1] = (int32_t *)0x0;
    in_RDX[2] = (int32_t *)0x0;
    in_RDX[3] = (int32_t *)0x0;
    in_RDX[4] = (int32_t *)0x0;
    in_RDX[5] = (int32_t *)0x0;
    *(undefined4 *)(in_RDX + 6) = 0;
    bVar3 = false;
    uVar9 = (uint64_t)((uint32_t)in_R8 | 2);
    if ((in_R8 & 8) == 0) {
        uVar9 = in_R8 & 0xffffffff;
    }
    *(uint32_t *)((int64_t)in_RDX + 0x34) = (uint32_t)((uVar9 & 0x40) != 0);
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0102;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdd6d;
        func_0x0001801c1390(0, 0x1804b0248, 0x115, 0x1804b0260);
        return 0;
    }
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
    if (iVar4 == 0x80) {
        *in_RDX = in_RCX;
        in_RDX[1] = *(int32_t **)(in_RCX + 0x22);
        in_RDX[2] = *(int32_t **)(in_RCX + 0x20);
        in_RDX[3] = in_RCX;
        bVar3 = false;
        if ((uVar9 & 8) == 0) {
code_r0x0001801bdf18:
            if (((uVar9 & 1) != 0) || ((*(int64_t *)(in_RCX + 0x2c) != 0 && ((uVar9 & 2) != 0)))) {
                in_RDX[4] = *(int32_t **)(in_RCX + 0x2c);
                goto code_r0x0001801be03e;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf3f;
            func_0x0001801c2160(in_RCX, uVar9);
code_r0x0001801be099:
            if (!bVar3) {
                return iVar10;
            }
            if ((iVar10 != 0) && ((in_R8 & 0x20) != 0)) {
                return iVar10;
            }
        } else {
            uVar8 = *(undefined8 *)(in_RCX + 0x16);
            if ((uVar9 & 0x40) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdeb7;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdebf;
                func_0x00018026d890(uVar8);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde7c;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde84;
                func_0x00018026d890(uVar8);
                *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                if (*(int32_t *)(in_RDX + 5) == 0) {
                    if (in_RDX[3] != (int32_t *)0x0) {
                        in_RDX[3][0x4a] = 0;
                    }
                } else if (in_RDX[4] != (int32_t *)0x0) {
                    in_RDX[4][0x2e] = 0;
                }
            }
            bVar3 = true;
            if (*(int64_t *)(in_RCX + 0x2c) != 0) goto code_r0x0001801bdf18;
            if ((*(uint8_t *)(in_RCX + 0x40) & 0x20) == 0) {
                uVar8 = *(undefined8 *)(in_RCX + 0x28);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdee7;
                iVar4 = func_0x0001801e3b50(uVar8);
                if (iVar4 != 0) goto code_r0x0001801be008;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdef7;
                iVar4 = func_0x0001801c0be0(in_RDX);
                if (0 < iVar4) {
                    if ((uVar9 & 0x10) == 0) {
                        piVar1 = in_RDX[3];
                        if (((*(uint8_t *)(piVar1 + 0x40) & 0x10) == 0) && (iVar4 = piVar1[0x41], iVar4 != 0)) {
                            *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R15;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf7a;
                            iVar7 = func_0x0001801c0980(in_RDX, iVar4 == 2, 0);
                            iVar2 = *(int64_t *)(piVar1 + 0x2c);
                            if (iVar2 != iVar7) {
                                *(int64_t *)(piVar1 + 0x2c) = iVar7;
                                if (iVar7 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf9a;
                                    func_0x000180194eb0(piVar1);
                                } else {
                                    LOCK();
                                    piVar1[8] = piVar1[8] + -1;
                                    UNLOCK();
                                }
                                if (iVar2 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfae;
                                    func_0x000180193500(iVar2);
                                }
                            }
                            if (*(int64_t *)(piVar1 + 0x2c) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfd1;
                                func_0x0001801c05d0(piVar1);
                                goto code_r0x0001801bdf18;
                            }
                            uVar8 = 0x84b;
                            uVar5 = 0xc0103;
                        } else {
                            uVar8 = 0x841;
                            uVar5 = 0x163;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = uVar5;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be003;
                        iVar4 = func_0x0001801c1390(in_RDX, 0x1804b0248, uVar8, 0x1804b03a0);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf10;
                        iVar4 = func_0x0001801c0620(in_RDX, 0);
                    }
                    if (iVar4 != 0) goto code_r0x0001801bdf18;
                }
            } else {
code_r0x0001801be008:
                *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xcf;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be031;
                func_0x0001801c1390(in_RDX, 0x1804b0248, 0x145, 0x1804b0260);
            }
        }
        uVar8 = *(undefined8 *)(*in_RDX + 0x16);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0b3;
        uVar8 = func_0x0001801dd6c0(uVar8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0bb;
        func_0x00018026d900(uVar8);
    } else {
        if (iVar4 == 0x81) {
            if ((uVar9 & 2) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x88);
                in_RDX[2] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x80);
                in_RDX[3] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[4] = in_RCX;
                *(undefined4 *)(in_RDX + 5) = 1;
                goto code_r0x0001801be03e;
            }
        } else {
            if (iVar4 != 0x82) {
                if (iVar4 != 0x83) {
                    *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0103;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddbc;
                    func_0x0001801c1390(0, 0x1804b0248, 0x170, 0x1804b0260);
                    return 0;
                }
                if (-1 < (char)uVar9) goto code_r0x0001801bddc6;
                *in_RDX = in_RCX;
                in_RDX[1] = in_RCX;
                *(undefined4 *)(in_RDX + 6) = 1;
                bVar3 = false;
code_r0x0001801be03e:
                if (((in_R8 & 0x20) != 0) && (!bVar3)) {
                    uVar8 = *(undefined8 *)(*in_RDX + 0x16);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be054;
                    uVar8 = func_0x0001801dd6c0(uVar8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be05c;
                    func_0x00018026d890(uVar8);
                    if ((uVar9 & 0x40) != 0) {
                        *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                        if (*(int32_t *)(in_RDX + 5) == 0) {
                            if (in_RDX[3] != (int32_t *)0x0) {
                                in_RDX[3][0x4a] = 0;
                            }
                        } else if (in_RDX[4] != (int32_t *)0x0) {
                            in_RDX[4][0x2e] = 0;
                        }
                    }
                    bVar3 = true;
                }
                iVar10 = 1;
                goto code_r0x0001801be099;
            }
            if ((uVar9 & 4) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[2] = in_RCX;
                *(undefined4 *)((int64_t)in_RDX + 0x2c) = 1;
                goto code_r0x0001801be03e;
            }
        }
code_r0x0001801bddc6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddd0;
        func_0x0001801c2160(in_RCX, uVar9);
    }
    return iVar10;
}

// ============================================================
// Function: FUN_1801bdfbc
// Address: 0x1801bdfbc
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801bdce0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *in_RCX;
    int32_t **in_RDX;
    uint64_t uVar9;
    int32_t iVar10;
    uint64_t in_R8;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801bdcf6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar10 = 0;
    *in_RDX = (int32_t *)0x0;
    in_RDX[1] = (int32_t *)0x0;
    in_RDX[2] = (int32_t *)0x0;
    in_RDX[3] = (int32_t *)0x0;
    in_RDX[4] = (int32_t *)0x0;
    in_RDX[5] = (int32_t *)0x0;
    *(undefined4 *)(in_RDX + 6) = 0;
    bVar3 = false;
    uVar9 = (uint64_t)((uint32_t)in_R8 | 2);
    if ((in_R8 & 8) == 0) {
        uVar9 = in_R8 & 0xffffffff;
    }
    *(uint32_t *)((int64_t)in_RDX + 0x34) = (uint32_t)((uVar9 & 0x40) != 0);
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0102;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdd6d;
        func_0x0001801c1390(0, 0x1804b0248, 0x115, 0x1804b0260);
        return 0;
    }
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
    if (iVar4 == 0x80) {
        *in_RDX = in_RCX;
        in_RDX[1] = *(int32_t **)(in_RCX + 0x22);
        in_RDX[2] = *(int32_t **)(in_RCX + 0x20);
        in_RDX[3] = in_RCX;
        bVar3 = false;
        if ((uVar9 & 8) == 0) {
code_r0x0001801bdf18:
            if (((uVar9 & 1) != 0) || ((*(int64_t *)(in_RCX + 0x2c) != 0 && ((uVar9 & 2) != 0)))) {
                in_RDX[4] = *(int32_t **)(in_RCX + 0x2c);
                goto code_r0x0001801be03e;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf3f;
            func_0x0001801c2160(in_RCX, uVar9);
code_r0x0001801be099:
            if (!bVar3) {
                return iVar10;
            }
            if ((iVar10 != 0) && ((in_R8 & 0x20) != 0)) {
                return iVar10;
            }
        } else {
            uVar8 = *(undefined8 *)(in_RCX + 0x16);
            if ((uVar9 & 0x40) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdeb7;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdebf;
                func_0x00018026d890(uVar8);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde7c;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde84;
                func_0x00018026d890(uVar8);
                *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                if (*(int32_t *)(in_RDX + 5) == 0) {
                    if (in_RDX[3] != (int32_t *)0x0) {
                        in_RDX[3][0x4a] = 0;
                    }
                } else if (in_RDX[4] != (int32_t *)0x0) {
                    in_RDX[4][0x2e] = 0;
                }
            }
            bVar3 = true;
            if (*(int64_t *)(in_RCX + 0x2c) != 0) goto code_r0x0001801bdf18;
            if ((*(uint8_t *)(in_RCX + 0x40) & 0x20) == 0) {
                uVar8 = *(undefined8 *)(in_RCX + 0x28);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdee7;
                iVar4 = func_0x0001801e3b50(uVar8);
                if (iVar4 != 0) goto code_r0x0001801be008;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdef7;
                iVar4 = func_0x0001801c0be0(in_RDX);
                if (0 < iVar4) {
                    if ((uVar9 & 0x10) == 0) {
                        piVar1 = in_RDX[3];
                        if (((*(uint8_t *)(piVar1 + 0x40) & 0x10) == 0) && (iVar4 = piVar1[0x41], iVar4 != 0)) {
                            *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R15;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf7a;
                            iVar7 = func_0x0001801c0980(in_RDX, iVar4 == 2, 0);
                            iVar2 = *(int64_t *)(piVar1 + 0x2c);
                            if (iVar2 != iVar7) {
                                *(int64_t *)(piVar1 + 0x2c) = iVar7;
                                if (iVar7 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf9a;
                                    func_0x000180194eb0(piVar1);
                                } else {
                                    LOCK();
                                    piVar1[8] = piVar1[8] + -1;
                                    UNLOCK();
                                }
                                if (iVar2 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfae;
                                    func_0x000180193500(iVar2);
                                }
                            }
                            if (*(int64_t *)(piVar1 + 0x2c) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfd1;
                                func_0x0001801c05d0(piVar1);
                                goto code_r0x0001801bdf18;
                            }
                            uVar8 = 0x84b;
                            uVar5 = 0xc0103;
                        } else {
                            uVar8 = 0x841;
                            uVar5 = 0x163;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = uVar5;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be003;
                        iVar4 = func_0x0001801c1390(in_RDX, 0x1804b0248, uVar8, 0x1804b03a0);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf10;
                        iVar4 = func_0x0001801c0620(in_RDX, 0);
                    }
                    if (iVar4 != 0) goto code_r0x0001801bdf18;
                }
            } else {
code_r0x0001801be008:
                *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xcf;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be031;
                func_0x0001801c1390(in_RDX, 0x1804b0248, 0x145, 0x1804b0260);
            }
        }
        uVar8 = *(undefined8 *)(*in_RDX + 0x16);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0b3;
        uVar8 = func_0x0001801dd6c0(uVar8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0bb;
        func_0x00018026d900(uVar8);
    } else {
        if (iVar4 == 0x81) {
            if ((uVar9 & 2) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x88);
                in_RDX[2] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x80);
                in_RDX[3] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[4] = in_RCX;
                *(undefined4 *)(in_RDX + 5) = 1;
                goto code_r0x0001801be03e;
            }
        } else {
            if (iVar4 != 0x82) {
                if (iVar4 != 0x83) {
                    *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0103;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddbc;
                    func_0x0001801c1390(0, 0x1804b0248, 0x170, 0x1804b0260);
                    return 0;
                }
                if (-1 < (char)uVar9) goto code_r0x0001801bddc6;
                *in_RDX = in_RCX;
                in_RDX[1] = in_RCX;
                *(undefined4 *)(in_RDX + 6) = 1;
                bVar3 = false;
code_r0x0001801be03e:
                if (((in_R8 & 0x20) != 0) && (!bVar3)) {
                    uVar8 = *(undefined8 *)(*in_RDX + 0x16);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be054;
                    uVar8 = func_0x0001801dd6c0(uVar8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be05c;
                    func_0x00018026d890(uVar8);
                    if ((uVar9 & 0x40) != 0) {
                        *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                        if (*(int32_t *)(in_RDX + 5) == 0) {
                            if (in_RDX[3] != (int32_t *)0x0) {
                                in_RDX[3][0x4a] = 0;
                            }
                        } else if (in_RDX[4] != (int32_t *)0x0) {
                            in_RDX[4][0x2e] = 0;
                        }
                    }
                    bVar3 = true;
                }
                iVar10 = 1;
                goto code_r0x0001801be099;
            }
            if ((uVar9 & 4) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[2] = in_RCX;
                *(undefined4 *)((int64_t)in_RDX + 0x2c) = 1;
                goto code_r0x0001801be03e;
            }
        }
code_r0x0001801bddc6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddd0;
        func_0x0001801c2160(in_RCX, uVar9);
    }
    return iVar10;
}

// ============================================================
// Function: FUN_1801be0c0
// Address: 0x1801be0c0
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801bdce0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int32_t *in_RCX;
    int32_t **in_RDX;
    uint64_t uVar9;
    int32_t iVar10;
    uint64_t in_R8;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801bdcf6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar10 = 0;
    *in_RDX = (int32_t *)0x0;
    in_RDX[1] = (int32_t *)0x0;
    in_RDX[2] = (int32_t *)0x0;
    in_RDX[3] = (int32_t *)0x0;
    in_RDX[4] = (int32_t *)0x0;
    in_RDX[5] = (int32_t *)0x0;
    *(undefined4 *)(in_RDX + 6) = 0;
    bVar3 = false;
    uVar9 = (uint64_t)((uint32_t)in_R8 | 2);
    if ((in_R8 & 8) == 0) {
        uVar9 = in_R8 & 0xffffffff;
    }
    *(uint32_t *)((int64_t)in_RDX + 0x34) = (uint32_t)((uVar9 & 0x40) != 0);
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0102;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdd6d;
        func_0x0001801c1390(0, 0x1804b0248, 0x115, 0x1804b0260);
        return 0;
    }
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
    if (iVar4 == 0x80) {
        *in_RDX = in_RCX;
        in_RDX[1] = *(int32_t **)(in_RCX + 0x22);
        in_RDX[2] = *(int32_t **)(in_RCX + 0x20);
        in_RDX[3] = in_RCX;
        bVar3 = false;
        if ((uVar9 & 8) == 0) {
code_r0x0001801bdf18:
            if (((uVar9 & 1) != 0) || ((*(int64_t *)(in_RCX + 0x2c) != 0 && ((uVar9 & 2) != 0)))) {
                in_RDX[4] = *(int32_t **)(in_RCX + 0x2c);
                goto code_r0x0001801be03e;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf3f;
            func_0x0001801c2160(in_RCX, uVar9);
code_r0x0001801be099:
            if (!bVar3) {
                return iVar10;
            }
            if ((iVar10 != 0) && ((in_R8 & 0x20) != 0)) {
                return iVar10;
            }
        } else {
            uVar8 = *(undefined8 *)(in_RCX + 0x16);
            if ((uVar9 & 0x40) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdeb7;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdebf;
                func_0x00018026d890(uVar8);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde7c;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bde84;
                func_0x00018026d890(uVar8);
                *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                if (*(int32_t *)(in_RDX + 5) == 0) {
                    if (in_RDX[3] != (int32_t *)0x0) {
                        in_RDX[3][0x4a] = 0;
                    }
                } else if (in_RDX[4] != (int32_t *)0x0) {
                    in_RDX[4][0x2e] = 0;
                }
            }
            bVar3 = true;
            if (*(int64_t *)(in_RCX + 0x2c) != 0) goto code_r0x0001801bdf18;
            if ((*(uint8_t *)(in_RCX + 0x40) & 0x20) == 0) {
                uVar8 = *(undefined8 *)(in_RCX + 0x28);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdee7;
                iVar4 = func_0x0001801e3b50(uVar8);
                if (iVar4 != 0) goto code_r0x0001801be008;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdef7;
                iVar4 = func_0x0001801c0be0(in_RDX);
                if (0 < iVar4) {
                    if ((uVar9 & 0x10) == 0) {
                        piVar1 = in_RDX[3];
                        if (((*(uint8_t *)(piVar1 + 0x40) & 0x10) == 0) && (iVar4 = piVar1[0x41], iVar4 != 0)) {
                            *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R15;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf7a;
                            iVar7 = func_0x0001801c0980(in_RDX, iVar4 == 2, 0);
                            iVar2 = *(int64_t *)(piVar1 + 0x2c);
                            if (iVar2 != iVar7) {
                                *(int64_t *)(piVar1 + 0x2c) = iVar7;
                                if (iVar7 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf9a;
                                    func_0x000180194eb0(piVar1);
                                } else {
                                    LOCK();
                                    piVar1[8] = piVar1[8] + -1;
                                    UNLOCK();
                                }
                                if (iVar2 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfae;
                                    func_0x000180193500(iVar2);
                                }
                            }
                            if (*(int64_t *)(piVar1 + 0x2c) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdfd1;
                                func_0x0001801c05d0(piVar1);
                                goto code_r0x0001801bdf18;
                            }
                            uVar8 = 0x84b;
                            uVar5 = 0xc0103;
                        } else {
                            uVar8 = 0x841;
                            uVar5 = 0x163;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                        *(undefined4 *)((int64_t)&var_8h + iVar6) = uVar5;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be003;
                        iVar4 = func_0x0001801c1390(in_RDX, 0x1804b0248, uVar8, 0x1804b03a0);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bdf10;
                        iVar4 = func_0x0001801c0620(in_RDX, 0);
                    }
                    if (iVar4 != 0) goto code_r0x0001801bdf18;
                }
            } else {
code_r0x0001801be008:
                *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xcf;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be031;
                func_0x0001801c1390(in_RDX, 0x1804b0248, 0x145, 0x1804b0260);
            }
        }
        uVar8 = *(undefined8 *)(*in_RDX + 0x16);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0b3;
        uVar8 = func_0x0001801dd6c0(uVar8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be0bb;
        func_0x00018026d900(uVar8);
    } else {
        if (iVar4 == 0x81) {
            if ((uVar9 & 2) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x88);
                in_RDX[2] = *(int32_t **)(*(int64_t *)(in_RCX + 0x1e) + 0x80);
                in_RDX[3] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[4] = in_RCX;
                *(undefined4 *)(in_RDX + 5) = 1;
                goto code_r0x0001801be03e;
            }
        } else {
            if (iVar4 != 0x82) {
                if (iVar4 != 0x83) {
                    *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
                    *(undefined4 *)((int64_t)&var_8h + iVar6) = 0xc0103;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddbc;
                    func_0x0001801c1390(0, 0x1804b0248, 0x170, 0x1804b0260);
                    return 0;
                }
                if (-1 < (char)uVar9) goto code_r0x0001801bddc6;
                *in_RDX = in_RCX;
                in_RDX[1] = in_RCX;
                *(undefined4 *)(in_RDX + 6) = 1;
                bVar3 = false;
code_r0x0001801be03e:
                if (((in_R8 & 0x20) != 0) && (!bVar3)) {
                    uVar8 = *(undefined8 *)(*in_RDX + 0x16);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be054;
                    uVar8 = func_0x0001801dd6c0(uVar8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be05c;
                    func_0x00018026d890(uVar8);
                    if ((uVar9 & 0x40) != 0) {
                        *(undefined4 *)((int64_t)in_RDX + 0x34) = 1;
                        if (*(int32_t *)(in_RDX + 5) == 0) {
                            if (in_RDX[3] != (int32_t *)0x0) {
                                in_RDX[3][0x4a] = 0;
                            }
                        } else if (in_RDX[4] != (int32_t *)0x0) {
                            in_RDX[4][0x2e] = 0;
                        }
                    }
                    bVar3 = true;
                }
                iVar10 = 1;
                goto code_r0x0001801be099;
            }
            if ((uVar9 & 4) != 0) {
                *in_RDX = in_RCX;
                in_RDX[1] = *(int32_t **)(in_RCX + 0x1e);
                in_RDX[2] = in_RCX;
                *(undefined4 *)((int64_t)in_RDX + 0x2c) = 1;
                goto code_r0x0001801be03e;
            }
        }
code_r0x0001801bddc6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801bddd0;
        func_0x0001801c2160(in_RCX, uVar9);
    }
    return iVar10;
}

// ============================================================
// Function: FUN_1801be0e0
// Address: 0x1801be0e0
// Size: 54 bytes
// ============================================================
void fcn.1801be0e0(int32_t *param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    LOCK();
    iVar1 = *param_1;
    *param_1 = *param_1 + -1;
    UNLOCK();
    if (1 < iVar1) {
        return;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != (int32_t *)0x0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801be120
// Address: 0x1801be120
// Size: 134 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_c4h

uint64_t fcn.1801be120(int64_t arg_28h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a8h, int64_t arg_b8h,
                      int64_t arg_c0h, int64_t arg_d0h, int64_t arg_120h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 in_RCX;
    undefined8 uVar7;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be12c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801be142;
    iVar2 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    if (iVar2 == 0) {
        return 0xffffffff;
    }
    uVar3 = *(uint32_t *)(*(int64_t *)(&stack0x00000040 + iVar4) + 0x100);
    if ((uVar3 & 4) == 0) {
        if ((uVar3 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0;
            *(undefined4 *)((int64_t)&uStackX_20 + iVar4 + -8) = 0x118;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801be185;
            fcn.1801c1390(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            return 0xffffffff;
        }
        *(uint32_t *)(*(int64_t *)(&stack0x00000040 + iVar4) + 0x100) = uVar3 | 4;
    }
    uVar7 = *(undefined8 *)(&stack0x00000068 + iVar4);
    *(undefined8 *)(&stack0x00000068 + iVar4) = 0x1801bedca;
    iVar5 = fcn.18045a350(in_RCX);
    iVar5 = -iVar5;
    *(undefined8 *)(&stack0x00000068 + iVar5 + iVar4) = 0x1801beddd;
    uVar6 = fcn.1801bdce0(*(int64_t *)(&stack0x000000a0 + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_a8h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_b8h + iVar5 + iVar4));
    if ((int32_t)uVar6 != 0) {
        *(undefined8 *)((int64_t)&arg_d0h + iVar5 + iVar4) = uVar7;
        uVar7 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_90h + iVar5 + iVar4) + 0x58);
        *(undefined8 *)(&stack0x00000068 + iVar5 + iVar4) = 0x1801bedf9;
        uVar7 = fcn.1801dd6c0(uVar7);
        *(undefined8 *)(&stack0x00000068 + iVar5 + iVar4) = 0x1801bee01;
        fcn.18026d890(uVar7);
        iVar2 = *(int32_t *)((int64_t)&arg_b8h + iVar5 + iVar4);
        *(undefined4 *)((int64_t)&arg_c0h + iVar5 + iVar4 + 4) = 1;
        if (iVar2 == 0) {
            iVar1 = *(int64_t *)((int64_t)&arg_a8h + iVar5 + iVar4);
            if (iVar1 != 0) {
                *(undefined4 *)(iVar1 + 0x128) = 0;
            }
        } else if (*(int64_t *)(&stack0x000000b0 + iVar5 + iVar4) != 0) {
            *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar5 + iVar4) + 0xb8) = 0;
        }
        *(undefined8 *)(&stack0x00000068 + iVar5 + iVar4) = 0x1801bee44;
        uVar3 = fcn.1801c0be0(*(int64_t *)(&stack0x000000a0 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_a8h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x000000b0 + iVar5 + iVar4));
        uVar7 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_90h + iVar5 + iVar4) + 0x58);
        *(undefined8 *)(&stack0x00000068 + iVar5 + iVar4) = 0x1801bee54;
        uVar7 = fcn.1801dd6c0(uVar7);
        *(undefined8 *)(&stack0x00000068 + iVar5 + iVar4) = 0x1801bee5c;
        fcn.18026d900(uVar7);
        return (uint64_t)uVar3;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801be1b0
// Address: 0x1801be1b0
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.1801be1b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_80h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined2 uVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801be1cc;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (in_RDX == 0) {
        if (in_R8 != 0) {
            return (undefined4 *)0x0;
        }
    } else if (in_R8 == 0) {
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be215;
    iVar4 = func_0x00018026bf70();
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be221;
        uVar5 = func_0x00018026bea0(in_RCX);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be22c;
        uVar3 = func_0x00018026bff0(in_RCX);
        iVar1 = *(int64_t *)((int64_t)&arg_30h + iVar6);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be252;
        puVar7 = (undefined4 *)func_0x000180224d60(iVar1 + 0x2e + in_R8, 0x1804b0248, 0x1313);
        if (puVar7 != (undefined4 *)0x0) {
            *puVar7 = 1;
            *(undefined4 **)(puVar7 + 2) = puVar7 + 10;
            *(int64_t *)(puVar7 + 4) = iVar1 + 6;
            *(int64_t *)(puVar7 + 6) = iVar1 + 0x2e + (int64_t)puVar7;
            *(int64_t *)(puVar7 + 8) = in_R8;
            puVar7[10] = uVar5;
            *(undefined2 *)(puVar7 + 0xb) = uVar3;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be292;
            iVar4 = func_0x00018026bf70(in_RCX, (int64_t)puVar7 + 0x2e, 0);
            if (iVar4 != 0) {
                if (in_RDX != 0) {
                    uVar2 = *(undefined8 *)(puVar7 + 6);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be2b7;
                    func_0x000180498030(uVar2, in_RDX, in_R8);
                    return puVar7;
                }
                return puVar7;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801be29e;
            func_0x0001801bf150(puVar7);
        }
    }
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_1801be2c0
// Address: 0x1801be2c0
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801be2c0(int64_t arg_30h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be2d0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801be2e8;
    iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2));
    if (iVar1 != 0) {
        if (in_EDX == 0xf) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801be317;
            fcn.1801e4c80(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801be32d;
        fcn.1801c3240(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1801be340
// Address: 0x1801be340
// Size: 25 bytes
// ============================================================
undefined8
fcn.1801be340(int64_t arg_40h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_90h, int64_t arg_98h,
             int64_t arg_a0h, int64_t arg_c8h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar7;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801c1130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1149;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_68h + iVar4 + iVar3));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = unaff_RBX;
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1170;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1178;
    fcn.18026d890(uVar5);
    if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11a8;
        fcn.180193130(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c11bc;
        fcn.180194b20(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000080 + iVar4 + iVar3), *(int64_t *)(&stack0x00000088 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_98h + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x000000c0 + iVar4 + iVar3));
        iVar1 = *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3);
        *(uint64_t *)(iVar1 + 0x110) = (*(uint64_t *)(iVar1 + 0x110) & ~in_RDX | uVar7) & 0x3df6ffb87;
    }
    uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3) + 0x110);
    iVar1 = *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3);
    if (iVar1 != 0) {
        *(uint64_t *)(iVar1 + 0xb0) = ((uint32_t)~in_RDX & *(uint32_t *)(iVar1 + 0xb0) | uVar7) & 0xde0fa987;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c121f;
        fcn.1801c22c0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3));
        if (*(int32_t *)((int64_t)&arg_68h + iVar4 + iVar3) != 0) {
            uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) + 0xb0);
        }
    }
    uVar6 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3) + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1240;
    uVar6 = fcn.1801dd6c0(uVar6);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801c1248;
    fcn.18026d900(uVar6);
    return uVar5;
}

// ============================================================
// Function: FUN_1801be360
// Address: 0x1801be360
// Size: 59 bytes
// ============================================================
undefined8 fcn.1801be360(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801be36a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801be37d;
    iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    uVar3 = *(undefined8 *)(*(int64_t *)((int64_t)&var_20h + iVar2) + 0x60);
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801be396;
    uVar3 = fcn.1801e3990(uVar3);
    return uVar3;
}

// ============================================================
// Function: FUN_1801be3a0
// Address: 0x1801be3a0
// Size: 59 bytes
// ============================================================
undefined8 fcn.1801be3a0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801be3aa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801be3bd;
    iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    if (iVar1 == 0) {
        return 0;
    }
    uVar3 = *(undefined8 *)(*(int64_t *)((int64_t)&var_20h + iVar2) + 0x60);
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801be3d6;
    uVar3 = fcn.1801e8e30(uVar3);
    return uVar3;
}

// ============================================================
// Function: FUN_1801be3e0
// Address: 0x1801be3e0
// Size: 43 bytes
// ============================================================
void fcn.1801be3e0(int64_t arg_68h, int64_t arg_70h, int64_t arg_88h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be3ec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be402;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar2 != 0) {
        iVar4 = *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8);
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        uVar1 = *(undefined8 *)(iVar4 + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be421;
        iVar4 = fcn.1801e3990(uVar1);
        if (iVar4 != in_RDX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be434;
            iVar2 = fcn.1801e9050(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be440;
                fcn.18021a070(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be45b;
                    fcn.180219d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)((int64_t)&arg_68h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801be40b
// Address: 0x1801be40b
// Size: 90 bytes
// ============================================================
void fcn.1801be3e0(int64_t arg_68h, int64_t arg_70h, int64_t arg_88h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be3ec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be402;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar2 != 0) {
        iVar4 = *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8);
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        uVar1 = *(undefined8 *)(iVar4 + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be421;
        iVar4 = fcn.1801e3990(uVar1);
        if (iVar4 != in_RDX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be434;
            iVar2 = fcn.1801e9050(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be440;
                fcn.18021a070(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be45b;
                    fcn.180219d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)((int64_t)&arg_68h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801be465
// Address: 0x1801be465
// Size: 6 bytes
// ============================================================
void fcn.1801be3e0(int64_t arg_68h, int64_t arg_70h, int64_t arg_88h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be3ec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be402;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar2 != 0) {
        iVar4 = *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8);
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        uVar1 = *(undefined8 *)(iVar4 + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be421;
        iVar4 = fcn.1801e3990(uVar1);
        if (iVar4 != in_RDX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be434;
            iVar2 = fcn.1801e9050(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be440;
                fcn.18021a070(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be45b;
                    fcn.180219d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)((int64_t)&arg_68h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801be470
// Address: 0x1801be470
// Size: 43 bytes
// ============================================================
void fcn.1801be470(int64_t arg_68h, int64_t arg_70h, int64_t arg_88h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be47c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be492;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar2 != 0) {
        iVar4 = *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8);
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        uVar1 = *(undefined8 *)(iVar4 + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4b1;
        iVar4 = fcn.1801e8e30(uVar1);
        if (iVar4 != in_RDX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4c4;
            iVar2 = fcn.1801e9120(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4d0;
                fcn.18021a070(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4eb;
                    fcn.180219d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)((int64_t)&arg_68h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801be49b
// Address: 0x1801be49b
// Size: 90 bytes
// ============================================================
void fcn.1801be470(int64_t arg_68h, int64_t arg_70h, int64_t arg_88h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be47c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be492;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar2 != 0) {
        iVar4 = *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8);
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        uVar1 = *(undefined8 *)(iVar4 + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4b1;
        iVar4 = fcn.1801e8e30(uVar1);
        if (iVar4 != in_RDX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4c4;
            iVar2 = fcn.1801e9120(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4d0;
                fcn.18021a070(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4eb;
                    fcn.180219d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)((int64_t)&arg_68h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801be4f5
// Address: 0x1801be4f5
// Size: 6 bytes
// ============================================================
void fcn.1801be470(int64_t arg_68h, int64_t arg_70h, int64_t arg_88h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be47c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be492;
    iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar2 != 0) {
        iVar4 = *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8);
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_70h + iVar3) = unaff_RDI;
        uVar1 = *(undefined8 *)(iVar4 + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4b1;
        iVar4 = fcn.1801e8e30(uVar1);
        if (iVar4 != in_RDX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4c4;
            iVar2 = fcn.1801e9120(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4d0;
                fcn.18021a070(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                if (in_RDX != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be4eb;
                    fcn.180219d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)((int64_t)&arg_68h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar3));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801be500
// Address: 0x1801be500
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801be500(int64_t arg_58h, int64_t arg_78h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    uint64_t *in_R8;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_30h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801be521;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be54c;
    iVar2 = fcn.1801bdce0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4));
    if (iVar2 == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_RSI;
    if ((int32_t)var_30h != 0) {
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x164;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be594;
        fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        return 0xffffffff;
    }
    uVar5 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5ab;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5b3;
    fcn.18026d890(uVar5);
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5c3;
    iVar2 = func_0x0001801e3b70(uVar5);
    if (iVar2 != 0) goto code_r0x0001801be81e;
    if ((in_RDX & 8) == 0) {
        if (in_R8 != (uint64_t *)0x0) {
            uVar7 = in_R8[1];
            uVar6 = *in_R8;
            uVar5 = *(undefined8 *)(var_40h + 0xa0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5f0;
            func_0x0001801e4e10(uVar5, uVar6, uVar7);
        }
        if ((in_RDX & 2) == 0) {
            if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
                uVar5 = *(undefined8 *)(var_40h + 0xa0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be612;
                uVar5 = func_0x0001801e39c0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be61a;
                func_0x0001801e7750(uVar5);
                *(uint32_t *)(var_40h + 0x100) = *(uint32_t *)(var_40h + 0x100) | 0x20;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be62d;
            iVar2 = func_0x0001801c0580(var_40h);
            if (iVar2 == 0) {
                if ((in_RDX & 4) == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be643;
                    iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
                    if (iVar2 == 0) goto code_r0x0001801be686;
                    uVar5 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be65d;
                    func_0x0001801dd840(uVar5, 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be665;
                    uVar5 = func_0x0001801dd6d0(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be67a;
                    iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1ae0, var_40h, 0);
                    if (0 < iVar2) goto code_r0x0001801be6cf;
                    goto code_r0x0001801be67f;
                }
code_r0x0001801be686:
                uVar3 = *(uint32_t *)(var_58h + 0x70);
                iVar1 = var_58h;
                while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
                    iVar1 = *(int64_t *)(iVar1 + 0x40);
                    if (iVar1 == 0) goto code_r0x0001801be6bc;
                    uVar3 = *(uint32_t *)(iVar1 + 0x70);
                }
                if (uVar3 != 2) {
code_r0x0001801be6bc:
                    uVar5 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6c5;
                    uVar5 = func_0x0001801dd6d0(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6cf;
                    func_0x0001801dd2b0(uVar5, 0);
                }
            }
code_r0x0001801be6cf:
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6d8;
            iVar2 = func_0x0001801c0580(var_40h);
            if (iVar2 == 0) {
                uVar5 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6ed;
                uVar5 = fcn.1801dd6c0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6f5;
                fcn.18026d900(uVar5);
                return 0;
            }
        }
    } else {
        uVar5 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be70c;
        iVar2 = func_0x0001801e3b50(uVar5);
        if (iVar2 != 0) goto code_r0x0001801be7c7;
        if ((in_RDX & 4) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be722;
            iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar2 == 0) goto code_r0x0001801be765;
            uVar5 = *(undefined8 *)(var_58h + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be73c;
            func_0x0001801dd840(uVar5, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be744;
            uVar5 = func_0x0001801dd6d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be759;
            iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1b40, var_40h, 0);
            if (iVar2 < 1) {
                uVar7 = 0;
                goto code_r0x0001801be8e2;
            }
        } else {
code_r0x0001801be765:
            uVar3 = *(uint32_t *)(var_58h + 0x70);
            iVar1 = var_58h;
            while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
                iVar1 = *(int64_t *)(iVar1 + 0x40);
                if (iVar1 == 0) goto code_r0x0001801be79c;
                uVar3 = *(uint32_t *)(iVar1 + 0x70);
            }
            if (uVar3 != 2) {
code_r0x0001801be79c:
                uVar5 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7a5;
                uVar5 = func_0x0001801dd6d0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7af;
                func_0x0001801dd2b0(uVar5, 0);
            }
        }
        uVar5 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7bf;
        iVar2 = func_0x0001801e3b50(uVar5);
        if (iVar2 == 0) {
code_r0x0001801be67f:
            uVar7 = 0;
            goto code_r0x0001801be8e2;
        }
    }
code_r0x0001801be7c7:
    uVar7 = 0;
    *(uint32_t *)(var_40h + 0x100) = *(uint32_t *)(var_40h + 0x100) | 0x20;
    uVar6 = uVar7;
    uVar8 = uVar7;
    if (in_R8 != (uint64_t *)0x0) {
        uVar6 = *in_R8;
        uVar8 = in_R8[1];
    }
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7f8;
    func_0x0001801e3b90(uVar5, uVar6, uVar8);
    uVar5 = *(undefined8 *)(var_40h + 0x78);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be80a;
    func_0x000180194c30(uVar5, 1);
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be81a;
    iVar2 = func_0x0001801e3b70(uVar5);
    if (iVar2 != 0) {
code_r0x0001801be81e:
        uVar5 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be82b;
        uVar5 = fcn.1801dd6c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be833;
        fcn.18026d900(uVar5);
        return 1;
    }
    if ((in_RDX & 4) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be84b;
        iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
        if ((iVar2 == 0) || ((in_RDX & 1) != 0)) goto code_r0x0001801be88f;
        uVar5 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be86b;
        func_0x0001801dd840(uVar5, 0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be873;
        uVar5 = func_0x0001801dd6d0(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be888;
        iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1b60, var_40h, 0);
        if (iVar2 < 1) goto code_r0x0001801be8e2;
    } else {
code_r0x0001801be88f:
        uVar3 = *(uint32_t *)(var_58h + 0x70);
        iVar1 = var_58h;
        while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
            iVar1 = *(int64_t *)(iVar1 + 0x40);
            if (iVar1 == 0) goto code_r0x0001801be8bd;
            uVar3 = *(uint32_t *)(iVar1 + 0x70);
        }
        if (uVar3 != 2) {
code_r0x0001801be8bd:
            uVar5 = *(undefined8 *)(var_58h + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8c6;
            uVar5 = func_0x0001801dd6d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8d0;
            func_0x0001801dd2b0(uVar5, 0);
        }
    }
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8e0;
    uVar3 = func_0x0001801e3b70(uVar5);
    uVar7 = (uint64_t)uVar3;
code_r0x0001801be8e2:
    uVar5 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8ef;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8f7;
    fcn.18026d900(uVar5);
    return uVar7;
}

// ============================================================
// Function: FUN_1801be55e
// Address: 0x1801be55e
// Size: 931 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801be500(int64_t arg_58h, int64_t arg_78h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    uint64_t *in_R8;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_30h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801be521;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be54c;
    iVar2 = fcn.1801bdce0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4));
    if (iVar2 == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_RSI;
    if ((int32_t)var_30h != 0) {
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x164;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be594;
        fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        return 0xffffffff;
    }
    uVar5 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5ab;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5b3;
    fcn.18026d890(uVar5);
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5c3;
    iVar2 = func_0x0001801e3b70(uVar5);
    if (iVar2 != 0) goto code_r0x0001801be81e;
    if ((in_RDX & 8) == 0) {
        if (in_R8 != (uint64_t *)0x0) {
            uVar7 = in_R8[1];
            uVar6 = *in_R8;
            uVar5 = *(undefined8 *)(var_40h + 0xa0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5f0;
            func_0x0001801e4e10(uVar5, uVar6, uVar7);
        }
        if ((in_RDX & 2) == 0) {
            if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
                uVar5 = *(undefined8 *)(var_40h + 0xa0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be612;
                uVar5 = func_0x0001801e39c0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be61a;
                func_0x0001801e7750(uVar5);
                *(uint32_t *)(var_40h + 0x100) = *(uint32_t *)(var_40h + 0x100) | 0x20;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be62d;
            iVar2 = func_0x0001801c0580(var_40h);
            if (iVar2 == 0) {
                if ((in_RDX & 4) == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be643;
                    iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
                    if (iVar2 == 0) goto code_r0x0001801be686;
                    uVar5 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be65d;
                    func_0x0001801dd840(uVar5, 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be665;
                    uVar5 = func_0x0001801dd6d0(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be67a;
                    iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1ae0, var_40h, 0);
                    if (0 < iVar2) goto code_r0x0001801be6cf;
                    goto code_r0x0001801be67f;
                }
code_r0x0001801be686:
                uVar3 = *(uint32_t *)(var_58h + 0x70);
                iVar1 = var_58h;
                while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
                    iVar1 = *(int64_t *)(iVar1 + 0x40);
                    if (iVar1 == 0) goto code_r0x0001801be6bc;
                    uVar3 = *(uint32_t *)(iVar1 + 0x70);
                }
                if (uVar3 != 2) {
code_r0x0001801be6bc:
                    uVar5 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6c5;
                    uVar5 = func_0x0001801dd6d0(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6cf;
                    func_0x0001801dd2b0(uVar5, 0);
                }
            }
code_r0x0001801be6cf:
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6d8;
            iVar2 = func_0x0001801c0580(var_40h);
            if (iVar2 == 0) {
                uVar5 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6ed;
                uVar5 = fcn.1801dd6c0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6f5;
                fcn.18026d900(uVar5);
                return 0;
            }
        }
    } else {
        uVar5 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be70c;
        iVar2 = func_0x0001801e3b50(uVar5);
        if (iVar2 != 0) goto code_r0x0001801be7c7;
        if ((in_RDX & 4) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be722;
            iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar2 == 0) goto code_r0x0001801be765;
            uVar5 = *(undefined8 *)(var_58h + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be73c;
            func_0x0001801dd840(uVar5, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be744;
            uVar5 = func_0x0001801dd6d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be759;
            iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1b40, var_40h, 0);
            if (iVar2 < 1) {
                uVar7 = 0;
                goto code_r0x0001801be8e2;
            }
        } else {
code_r0x0001801be765:
            uVar3 = *(uint32_t *)(var_58h + 0x70);
            iVar1 = var_58h;
            while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
                iVar1 = *(int64_t *)(iVar1 + 0x40);
                if (iVar1 == 0) goto code_r0x0001801be79c;
                uVar3 = *(uint32_t *)(iVar1 + 0x70);
            }
            if (uVar3 != 2) {
code_r0x0001801be79c:
                uVar5 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7a5;
                uVar5 = func_0x0001801dd6d0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7af;
                func_0x0001801dd2b0(uVar5, 0);
            }
        }
        uVar5 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7bf;
        iVar2 = func_0x0001801e3b50(uVar5);
        if (iVar2 == 0) {
code_r0x0001801be67f:
            uVar7 = 0;
            goto code_r0x0001801be8e2;
        }
    }
code_r0x0001801be7c7:
    uVar7 = 0;
    *(uint32_t *)(var_40h + 0x100) = *(uint32_t *)(var_40h + 0x100) | 0x20;
    uVar6 = uVar7;
    uVar8 = uVar7;
    if (in_R8 != (uint64_t *)0x0) {
        uVar6 = *in_R8;
        uVar8 = in_R8[1];
    }
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7f8;
    func_0x0001801e3b90(uVar5, uVar6, uVar8);
    uVar5 = *(undefined8 *)(var_40h + 0x78);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be80a;
    func_0x000180194c30(uVar5, 1);
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be81a;
    iVar2 = func_0x0001801e3b70(uVar5);
    if (iVar2 != 0) {
code_r0x0001801be81e:
        uVar5 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be82b;
        uVar5 = fcn.1801dd6c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be833;
        fcn.18026d900(uVar5);
        return 1;
    }
    if ((in_RDX & 4) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be84b;
        iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
        if ((iVar2 == 0) || ((in_RDX & 1) != 0)) goto code_r0x0001801be88f;
        uVar5 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be86b;
        func_0x0001801dd840(uVar5, 0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be873;
        uVar5 = func_0x0001801dd6d0(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be888;
        iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1b60, var_40h, 0);
        if (iVar2 < 1) goto code_r0x0001801be8e2;
    } else {
code_r0x0001801be88f:
        uVar3 = *(uint32_t *)(var_58h + 0x70);
        iVar1 = var_58h;
        while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
            iVar1 = *(int64_t *)(iVar1 + 0x40);
            if (iVar1 == 0) goto code_r0x0001801be8bd;
            uVar3 = *(uint32_t *)(iVar1 + 0x70);
        }
        if (uVar3 != 2) {
code_r0x0001801be8bd:
            uVar5 = *(undefined8 *)(var_58h + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8c6;
            uVar5 = func_0x0001801dd6d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8d0;
            func_0x0001801dd2b0(uVar5, 0);
        }
    }
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8e0;
    uVar3 = func_0x0001801e3b70(uVar5);
    uVar7 = (uint64_t)uVar3;
code_r0x0001801be8e2:
    uVar5 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8ef;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8f7;
    fcn.18026d900(uVar5);
    return uVar7;
}

// ============================================================
// Function: FUN_1801be901
// Address: 0x1801be901
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801be500(int64_t arg_58h, int64_t arg_78h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    uint64_t *in_R8;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_30h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801be521;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be54c;
    iVar2 = fcn.1801bdce0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4));
    if (iVar2 == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_RSI;
    if ((int32_t)var_30h != 0) {
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x164;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be594;
        fcn.1801c1390(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        return 0xffffffff;
    }
    uVar5 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5ab;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5b3;
    fcn.18026d890(uVar5);
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5c3;
    iVar2 = func_0x0001801e3b70(uVar5);
    if (iVar2 != 0) goto code_r0x0001801be81e;
    if ((in_RDX & 8) == 0) {
        if (in_R8 != (uint64_t *)0x0) {
            uVar7 = in_R8[1];
            uVar6 = *in_R8;
            uVar5 = *(undefined8 *)(var_40h + 0xa0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be5f0;
            func_0x0001801e4e10(uVar5, uVar6, uVar7);
        }
        if ((in_RDX & 2) == 0) {
            if ((*(uint8_t *)(var_40h + 0x100) & 0x20) == 0) {
                uVar5 = *(undefined8 *)(var_40h + 0xa0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be612;
                uVar5 = func_0x0001801e39c0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be61a;
                func_0x0001801e7750(uVar5);
                *(uint32_t *)(var_40h + 0x100) = *(uint32_t *)(var_40h + 0x100) | 0x20;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be62d;
            iVar2 = func_0x0001801c0580(var_40h);
            if (iVar2 == 0) {
                if ((in_RDX & 4) == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be643;
                    iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
                    if (iVar2 == 0) goto code_r0x0001801be686;
                    uVar5 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be65d;
                    func_0x0001801dd840(uVar5, 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be665;
                    uVar5 = func_0x0001801dd6d0(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be67a;
                    iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1ae0, var_40h, 0);
                    if (0 < iVar2) goto code_r0x0001801be6cf;
                    goto code_r0x0001801be67f;
                }
code_r0x0001801be686:
                uVar3 = *(uint32_t *)(var_58h + 0x70);
                iVar1 = var_58h;
                while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
                    iVar1 = *(int64_t *)(iVar1 + 0x40);
                    if (iVar1 == 0) goto code_r0x0001801be6bc;
                    uVar3 = *(uint32_t *)(iVar1 + 0x70);
                }
                if (uVar3 != 2) {
code_r0x0001801be6bc:
                    uVar5 = *(undefined8 *)(var_58h + 0x58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6c5;
                    uVar5 = func_0x0001801dd6d0(uVar5);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6cf;
                    func_0x0001801dd2b0(uVar5, 0);
                }
            }
code_r0x0001801be6cf:
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6d8;
            iVar2 = func_0x0001801c0580(var_40h);
            if (iVar2 == 0) {
                uVar5 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6ed;
                uVar5 = fcn.1801dd6c0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be6f5;
                fcn.18026d900(uVar5);
                return 0;
            }
        }
    } else {
        uVar5 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be70c;
        iVar2 = func_0x0001801e3b50(uVar5);
        if (iVar2 != 0) goto code_r0x0001801be7c7;
        if ((in_RDX & 4) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be722;
            iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar2 == 0) goto code_r0x0001801be765;
            uVar5 = *(undefined8 *)(var_58h + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be73c;
            func_0x0001801dd840(uVar5, 0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be744;
            uVar5 = func_0x0001801dd6d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be759;
            iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1b40, var_40h, 0);
            if (iVar2 < 1) {
                uVar7 = 0;
                goto code_r0x0001801be8e2;
            }
        } else {
code_r0x0001801be765:
            uVar3 = *(uint32_t *)(var_58h + 0x70);
            iVar1 = var_58h;
            while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
                iVar1 = *(int64_t *)(iVar1 + 0x40);
                if (iVar1 == 0) goto code_r0x0001801be79c;
                uVar3 = *(uint32_t *)(iVar1 + 0x70);
            }
            if (uVar3 != 2) {
code_r0x0001801be79c:
                uVar5 = *(undefined8 *)(var_58h + 0x58);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7a5;
                uVar5 = func_0x0001801dd6d0(uVar5);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7af;
                func_0x0001801dd2b0(uVar5, 0);
            }
        }
        uVar5 = *(undefined8 *)(var_40h + 0xa0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7bf;
        iVar2 = func_0x0001801e3b50(uVar5);
        if (iVar2 == 0) {
code_r0x0001801be67f:
            uVar7 = 0;
            goto code_r0x0001801be8e2;
        }
    }
code_r0x0001801be7c7:
    uVar7 = 0;
    *(uint32_t *)(var_40h + 0x100) = *(uint32_t *)(var_40h + 0x100) | 0x20;
    uVar6 = uVar7;
    uVar8 = uVar7;
    if (in_R8 != (uint64_t *)0x0) {
        uVar6 = *in_R8;
        uVar8 = in_R8[1];
    }
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be7f8;
    func_0x0001801e3b90(uVar5, uVar6, uVar8);
    uVar5 = *(undefined8 *)(var_40h + 0x78);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be80a;
    func_0x000180194c30(uVar5, 1);
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be81a;
    iVar2 = func_0x0001801e3b70(uVar5);
    if (iVar2 != 0) {
code_r0x0001801be81e:
        uVar5 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be82b;
        uVar5 = fcn.1801dd6c0(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be833;
        fcn.18026d900(uVar5);
        return 1;
    }
    if ((in_RDX & 4) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be84b;
        iVar2 = fcn.1801bd970(*(int64_t *)((int64_t)&var_8h + iVar4));
        if ((iVar2 == 0) || ((in_RDX & 1) != 0)) goto code_r0x0001801be88f;
        uVar5 = *(undefined8 *)(var_58h + 0x58);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be86b;
        func_0x0001801dd840(uVar5, 0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be873;
        uVar5 = func_0x0001801dd6d0(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be888;
        iVar2 = func_0x0001801dcf10(uVar5, 0x1801c1b60, var_40h, 0);
        if (iVar2 < 1) goto code_r0x0001801be8e2;
    } else {
code_r0x0001801be88f:
        uVar3 = *(uint32_t *)(var_58h + 0x70);
        iVar1 = var_58h;
        while (uVar3 = uVar3 >> 5 & 3, uVar3 == 0) {
            iVar1 = *(int64_t *)(iVar1 + 0x40);
            if (iVar1 == 0) goto code_r0x0001801be8bd;
            uVar3 = *(uint32_t *)(iVar1 + 0x70);
        }
        if (uVar3 != 2) {
code_r0x0001801be8bd:
            uVar5 = *(undefined8 *)(var_58h + 0x58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8c6;
            uVar5 = func_0x0001801dd6d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8d0;
            func_0x0001801dd2b0(uVar5, 0);
        }
    }
    uVar5 = *(undefined8 *)(var_40h + 0xa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8e0;
    uVar3 = func_0x0001801e3b70(uVar5);
    uVar7 = (uint64_t)uVar3;
code_r0x0001801be8e2:
    uVar5 = *(undefined8 *)(var_58h + 0x58);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8ef;
    uVar5 = fcn.1801dd6c0(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801be8f7;
    fcn.18026d900(uVar5);
    return uVar7;
}

// ============================================================
// Function: FUN_1801be920
// Address: 0x1801be920
// Size: 134 bytes
// ============================================================
uint64_t fcn.1801be920(int64_t arg_28h, int64_t arg_98h, int64_t arg_c0h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    undefined8 uVar6;
    int64_t var_18h;
    undefined8 uStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be92c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be942;
    iVar1 = fcn.1801bdce0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar1 == 0) {
        return 0xffffffff;
    }
    uVar2 = *(uint32_t *)(*(int64_t *)(&stack0x00000040 + iVar3) + 0x100);
    if ((uVar2 & 4) != 0) {
        if ((uVar2 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0;
            *(undefined4 *)((int64_t)&uStackX_20 + iVar3 + -8) = 0x118;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801be985;
            fcn.1801c1390(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            return 0xffffffff;
        }
        *(uint32_t *)(*(int64_t *)(&stack0x00000040 + iVar3) + 0x100) = uVar2 & 0xfffffffb;
    }
    uVar6 = *(undefined8 *)(&stack0x00000068 + iVar3);
    *(undefined8 *)(&stack0x00000068 + iVar3) = 0x1801bedca;
    iVar4 = fcn.18045a350(in_RCX);
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000068 + iVar4 + iVar3) = 0x1801beddd;
    uVar5 = fcn.1801bdce0(*(int64_t *)(&stack0x000000a0 + iVar4 + iVar3), *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x000000b8 + iVar4 + iVar3));
    if ((int32_t)uVar5 != 0) {
        *(undefined8 *)(&stack0x000000d0 + iVar4 + iVar3) = uVar6;
        uVar6 = *(undefined8 *)(*(int64_t *)(&stack0x00000090 + iVar4 + iVar3) + 0x58);
        *(undefined8 *)(&stack0x00000068 + iVar4 + iVar3) = 0x1801bedf9;
        uVar6 = fcn.1801dd6c0(uVar6);
        *(undefined8 *)(&stack0x00000068 + iVar4 + iVar3) = 0x1801bee01;
        fcn.18026d890(uVar6);
        iVar1 = *(int32_t *)(&stack0x000000b8 + iVar4 + iVar3);
        *(undefined4 *)((int64_t)&arg_c0h + iVar4 + iVar3 + 4) = 1;
        if (iVar1 == 0) {
            if (*(int64_t *)(&stack0x000000a8 + iVar4 + iVar3) != 0) {
                *(undefined4 *)(*(int64_t *)(&stack0x000000a8 + iVar4 + iVar3) + 0x128) = 0;
            }
        } else if (*(int64_t *)(&stack0x000000b0 + iVar4 + iVar3) != 0) {
            *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar4 + iVar3) + 0xb8) = 0;
        }
        *(undefined8 *)(&stack0x00000068 + iVar4 + iVar3) = 0x1801bee44;
        uVar2 = fcn.1801c0be0(*(int64_t *)(&stack0x000000a0 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x000000a8 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x000000b0 + iVar4 + iVar3));
        uVar6 = *(undefined8 *)(*(int64_t *)(&stack0x00000090 + iVar4 + iVar3) + 0x58);
        *(undefined8 *)(&stack0x00000068 + iVar4 + iVar3) = 0x1801bee54;
        uVar6 = fcn.1801dd6c0(uVar6);
        *(undefined8 *)(&stack0x00000068 + iVar4 + iVar3) = 0x1801bee5c;
        fcn.18026d900(uVar6);
        return (uint64_t)uVar2;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1801be9b0
// Address: 0x1801be9b0
// Size: 967 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

uint64_t fcn.1801be9b0(int64_t arg_98h)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    uint64_t in_RDX;
    uint32_t uVar10;
    uint64_t in_R8;
    uint64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_60h;
    int64_t var_58h;
    int32_t var_50h;
    int64_t var_4ch;
    int64_t var_40h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801be9d4;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801be9f2;
    iVar3 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    if (iVar3 == 0) {
        return 0;
    }
    uVar10 = (uint32_t)in_R8;
    // switch table (111 cases) at 0x1801becec
    switch((int32_t)in_RDX) {
    case 0x10:
        if ((int32_t)var_4ch == 0) {
            uVar7 = *(undefined8 *)(var_60h + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb0c;
            func_0x0001801e4d00(uVar7, in_R9);
            uVar7 = *(undefined8 *)(var_60h + 0x78);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb22;
            uVar5 = func_0x000180193380(uVar7, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
            return uVar5;
        }
        break;
    default:
        if ((int32_t)var_4ch == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801becca;
            uVar5 = func_0x0001801957d0(var_60h, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
            return uVar5;
        }
        break;
    case 0x21:
        if ((int32_t)var_4ch == 0) {
            if (var_50h == 0) {
                *(uint32_t *)(var_60h + 0x108) = *(uint32_t *)(var_60h + 0x108) | uVar10;
            }
            if (var_58h != 0) {
                uVar8 = uVar10 & 0xfffffffe;
                if ((*(uint8_t *)(var_58h + 0x88) & 4) == 0) {
                    uVar8 = uVar10;
                }
                *(uint32_t *)(var_58h + 0xa8) = *(uint32_t *)(var_58h + 0xa8) | uVar8;
                return (uint64_t)*(uint32_t *)(var_58h + 0xa8);
            }
code_r0x0001801bea98:
            return (uint64_t)*(uint32_t *)(var_60h + 0x108);
        }
        break;
    case 0x28:
    case 0x29:
    case 0x34:
    case 0x7d:
    case 0x7e:
        return 0;
    case 0x49:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb39;
        iVar3 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar4));
        if (iVar3 == 0) {
            return 0;
        }
        uVar7 = *(undefined8 *)(var_40h + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb4e;
        uVar7 = fcn.1801dd6c0(uVar7);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb56;
        fcn.18026d890(uVar7);
        uVar7 = *(undefined8 *)(var_40h + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb63;
        uVar7 = func_0x0001801dd6d0(uVar7);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb6b;
        uVar5 = func_0x0001801dd170(uVar7);
        uVar7 = *(undefined8 *)(var_40h + 0x58);
        if (uVar5 != 0xffffffffffffffff) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb9c;
            uVar6 = func_0x0001801dd6e0(uVar7);
            uVar7 = *(undefined8 *)(var_40h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bebac;
            uVar7 = fcn.1801dd6c0(uVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bebb4;
            fcn.18026d900(uVar7);
            uVar9 = 999;
            if ((uVar6 <= uVar5) && (uVar9 = (uVar5 - uVar6) + 999, ~(uVar5 - uVar6) < 999)) {
                uVar9 = 0xffffffffffffffff;
            }
            auVar1._8_8_ = 0;
            auVar1._0_8_ = uVar9;
            iVar4 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar1, 8);
            uVar5 = (uVar9 - iVar4 >> 1) + iVar4 >> 0x1d;
            uVar9 = uVar9 + uVar5 * -1000000000;
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar9;
            iVar4 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar2, 8);
            *in_R9 = (iVar4 + (uVar9 - iVar4 >> 1) >> 9) << 0x20 | uVar5 & 0xffffffff;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb81;
        uVar7 = fcn.1801dd6c0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801beb89;
        fcn.18026d900(uVar7);
        *in_R9 = 1000000;
        return 0;
    case 0x4a:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bec46;
        iVar3 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar4));
        if (iVar3 != 0) {
            uVar7 = *(undefined8 *)(var_40h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bec62;
            uVar7 = fcn.1801dd6c0(uVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bec6a;
            fcn.18026d890(uVar7);
            uVar7 = *(undefined8 *)(var_40h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bec77;
            uVar7 = func_0x0001801dd6d0(uVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bec81;
            func_0x0001801dd2b0(uVar7, 0);
            uVar7 = *(undefined8 *)(var_40h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bec8e;
            uVar7 = fcn.1801dd6c0(uVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bec96;
            fcn.18026d900(uVar7);
            return 1;
        }
        return 0xffffffff;
    case 0x4e:
        if ((int32_t)var_4ch == 0) {
            if (var_50h == 0) {
                *(uint32_t *)(var_60h + 0x108) = *(uint32_t *)(var_60h + 0x108) & ~uVar10;
            }
            if (var_58h != 0) {
                *(uint32_t *)(var_58h + 0xa8) = *(uint32_t *)(var_58h + 0xa8) & ~uVar10;
                return (uint64_t)*(uint32_t *)(var_58h + 0xa8);
            }
            goto code_r0x0001801bea98;
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0x8010c;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801bea56;
    uVar5 = fcn.1801c1390(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
    return uVar5;
}

// ============================================================
// Function: FUN_1801bed80
// Address: 0x1801bed80
// Size: 22 bytes
// ============================================================
undefined8 fcn.1801bed80(int64_t param_1, undefined4 param_2, undefined8 param_3)
{
    fcn.18045a350();
    // switch table (74 cases) at 0x1801c4600
    switch(param_2) {
    case 6:
        *(undefined8 *)(*(int64_t *)(param_1 + 0x158) + 0x10) = param_3;
        return 1;
    default:
        return 0;
    case 0x35:
        *(undefined8 *)(param_1 + 0x230) = param_3;
        return 1;
    case 0x3f:
        *(undefined8 *)(param_1 + 0x268) = param_3;
        return 1;
    case 0x48:
        *(undefined8 *)(param_1 + 600) = param_3;
        return 1;
    case 0x4b:
        *(uint32_t *)(param_1 + 0x3b4) = *(uint32_t *)(param_1 + 0x3b4) | 0x20;
        *(undefined8 *)(param_1 + 0x348) = param_3;
        return 1;
    case 0x4c:
        *(uint32_t *)(param_1 + 0x3b4) = *(uint32_t *)(param_1 + 0x3b4) | 0x20;
        *(undefined8 *)(param_1 + 0x350) = param_3;
        return 1;
    case 0x4d:
        *(uint32_t *)(param_1 + 0x3b4) = *(uint32_t *)(param_1 + 0x3b4) | 0x20;
        *(undefined8 *)(param_1 + 0x358) = param_3;
        return 1;
    case 0x4f:
        *(undefined8 *)(param_1 + 0x3d8) = param_3;
        return 1;
    }
}

// ============================================================
// Function: FUN_1801beda0
// Address: 0x1801beda0
// Size: 22 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801a247b: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801a2480)
// WARNING: Removing unreachable block (ram,0x0001801a249e)
// WARNING: Removing unreachable block (ram,0x0001801a2484)
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.1801beda0(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                      int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
                      int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c8h, int64_t arg_d0h, int64_t arg_d8h,
                      int64_t arg_100h, int64_t arg_108h, int64_t arg_118h, int64_t arg_150h, int64_t arg_1b8h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    undefined4 uVar12;
    int32_t iVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t **ppiVar16;
    int64_t *piVar17;
    undefined2 *puVar18;
    int64_t iVar19;
    int64_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    int64_t **ppiVar23;
    int64_t *piVar24;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t *piVar25;
    uint64_t uVar26;
    int32_t iVar27;
    int64_t iVar28;
    undefined8 unaff_RBX;
    undefined *puVar29;
    undefined8 unaff_RBP;
    int64_t unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar30;
    uint32_t in_R8D;
    uint64_t uVar31;
    int64_t *in_R9;
    undefined2 *puVar32;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    code *apcStackX_18 [2];
    
    iVar19 = fcn.18045a350();
    iVar19 = -iVar19;
    *(undefined8 *)((int64_t)&arg_30h + iVar19) = unaff_RBX;
    iVar21 = iVar19 + 0x20;
    iVar28 = iVar19 + 0x20;
    iVar14 = iVar19 + 0x20;
    iVar2 = iVar19 + 0x20;
    iVar5 = iVar19 + 0x20;
    iVar6 = iVar19 + 0x20;
    iVar7 = iVar19 + 0x20;
    iVar8 = iVar19 + 0x20;
    *(undefined8 *)((int64_t)apcStackX_18 + iVar19 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)apcStackX_18 + iVar19) = 0x1801c4680;
    iVar20 = fcn.18045a350();
    iVar20 = -iVar20;
    iVar9 = iVar20 + iVar19 + 0x20;
    // switch table (137 cases) at 0x1801c4de4
    switch(in_EDX) {
    case 3:
        if (in_R9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46bc;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                          *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
            goto code_r0x0001801c46c8;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46fb;
        iVar21 = fcn.1801bc7c0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19));
        if (iVar21 != 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4732;
            iVar13 = fcn.180192b80(*(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19));
            if (iVar13 == 0) {
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4742;
                fcn.18022ecc0(iVar21);
                return 0;
            }
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4708;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4720;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 4:
        if (in_R9 != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&arg_50h + iVar20 + iVar19) = in_R9;
            *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19) = in_RCX + 0x2b0;
            *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19) = in_RCX + 0x2b8;
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c47ea;
            uVar22 = fcn.1801bc970(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_90h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_98h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_a0h + iVar20 + iVar19), 
                                   *(int64_t *)((int64_t)&arg_a8h + iVar20 + iVar19));
            return uVar22;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c479b;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
code_r0x0001801c46c8:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c46d4;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    default:
        goto code_r0x0001801c46e6;
    case 6:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4754;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c476c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0xe:
        iVar21 = *(int64_t *)(in_RCX + 0x110);
        if (iVar21 == 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cb3;
            iVar21 = fcn.180221f20();
            *(int64_t *)(in_RCX + 0x110) = iVar21;
            if (iVar21 != 0) goto code_r0x0001801c4ce6;
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cc4;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                          *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        } else {
code_r0x0001801c4ce6:
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cf1;
            iVar13 = fcn.180222110(iVar21, in_R9);
            if (iVar13 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cfa;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                          *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4cdc;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0x36:
        *(int64_t **)(in_RCX + 0x238) = in_R9;
        return 1;
    case 0x3a:
    case 0x3b:
        if (in_R9 == (int64_t *)0x0) {
            return 0x50;
        }
        if (in_R8D == 0x50) {
            if (in_EDX == 0x3b) {
                iVar13 = *(int32_t *)((int64_t)in_R9 + 4);
                iVar27 = *(int32_t *)(in_R9 + 1);
                iVar3 = *(int32_t *)((int64_t)in_R9 + 0xc);
                piVar1 = *(int32_t **)(in_RCX + 0x250);
                *(int32_t *)(in_RCX + 0x240) = *(int32_t *)in_R9;
                *(int32_t *)(in_RCX + 0x244) = iVar13;
                *(int32_t *)(in_RCX + 0x248) = iVar27;
                *(int32_t *)(in_RCX + 0x24c) = iVar3;
                iVar13 = *(int32_t *)((int64_t)in_R9 + 0x14);
                iVar27 = *(int32_t *)(in_R9 + 3);
                iVar3 = *(int32_t *)((int64_t)in_R9 + 0x1c);
                *piVar1 = *(int32_t *)(in_R9 + 2);
                piVar1[1] = iVar13;
                piVar1[2] = iVar27;
                piVar1[3] = iVar3;
                iVar13 = *(int32_t *)((int64_t)in_R9 + 0x24);
                iVar27 = *(int32_t *)(in_R9 + 5);
                iVar3 = *(int32_t *)((int64_t)in_R9 + 0x2c);
                piVar1[4] = *(int32_t *)(in_R9 + 4);
                piVar1[5] = iVar13;
                piVar1[6] = iVar27;
                piVar1[7] = iVar3;
                iVar19 = *(int64_t *)(in_RCX + 0x250);
                iVar13 = *(int32_t *)((int64_t)in_R9 + 0x34);
                iVar27 = *(int32_t *)(in_R9 + 7);
                iVar3 = *(int32_t *)((int64_t)in_R9 + 0x3c);
                *(int32_t *)(iVar19 + 0x20) = *(int32_t *)(in_R9 + 6);
                *(int32_t *)(iVar19 + 0x24) = iVar13;
                *(int32_t *)(iVar19 + 0x28) = iVar27;
                *(int32_t *)(iVar19 + 0x2c) = iVar3;
                iVar13 = *(int32_t *)((int64_t)in_R9 + 0x44);
                iVar27 = *(int32_t *)(in_R9 + 9);
                iVar3 = *(int32_t *)((int64_t)in_R9 + 0x4c);
                *(int32_t *)(iVar19 + 0x30) = *(int32_t *)(in_R9 + 8);
                *(int32_t *)(iVar19 + 0x34) = iVar13;
                *(int32_t *)(iVar19 + 0x38) = iVar27;
                *(int32_t *)(iVar19 + 0x3c) = iVar3;
                return 1;
            }
            iVar13 = *(int32_t *)(in_RCX + 0x244);
            iVar27 = *(int32_t *)(in_RCX + 0x248);
            iVar3 = *(int32_t *)(in_RCX + 0x24c);
            *(int32_t *)in_R9 = *(int32_t *)(in_RCX + 0x240);
            *(int32_t *)((int64_t)in_R9 + 4) = iVar13;
            *(int32_t *)(in_R9 + 1) = iVar27;
            *(int32_t *)((int64_t)in_R9 + 0xc) = iVar3;
            piVar1 = *(int32_t **)(in_RCX + 0x250);
            iVar13 = piVar1[1];
            iVar27 = piVar1[2];
            iVar3 = piVar1[3];
            *(int32_t *)(in_R9 + 2) = *piVar1;
            *(int32_t *)((int64_t)in_R9 + 0x14) = iVar13;
            *(int32_t *)(in_R9 + 3) = iVar27;
            *(int32_t *)((int64_t)in_R9 + 0x1c) = iVar3;
            iVar13 = piVar1[5];
            iVar27 = piVar1[6];
            iVar3 = piVar1[7];
            *(int32_t *)(in_R9 + 4) = piVar1[4];
            *(int32_t *)((int64_t)in_R9 + 0x24) = iVar13;
            *(int32_t *)(in_R9 + 5) = iVar27;
            *(int32_t *)((int64_t)in_R9 + 0x2c) = iVar3;
            iVar19 = *(int64_t *)(in_RCX + 0x250);
            iVar13 = *(int32_t *)(iVar19 + 0x24);
            iVar27 = *(int32_t *)(iVar19 + 0x28);
            iVar3 = *(int32_t *)(iVar19 + 0x2c);
            *(int32_t *)(in_R9 + 6) = *(int32_t *)(iVar19 + 0x20);
            *(int32_t *)((int64_t)in_R9 + 0x34) = iVar13;
            *(int32_t *)(in_R9 + 7) = iVar27;
            *(int32_t *)((int64_t)in_R9 + 0x3c) = iVar3;
            iVar13 = *(int32_t *)(iVar19 + 0x34);
            iVar27 = *(int32_t *)(iVar19 + 0x38);
            iVar3 = *(int32_t *)(iVar19 + 0x3c);
            *(int32_t *)(in_R9 + 8) = *(int32_t *)(iVar19 + 0x30);
            *(int32_t *)((int64_t)in_R9 + 0x44) = iVar13;
            *(int32_t *)(in_R9 + 9) = iVar27;
            *(int32_t *)((int64_t)in_R9 + 0x4c) = iVar3;
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c482c;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4844;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0x40:
        *(int64_t **)(in_RCX + 0x270) = in_R9;
        return 1;
    case 0x41:
        *(uint32_t *)(in_RCX + 0x278) = in_R8D;
        return 1;
    case 0x4e:
        *(uint32_t *)(in_RCX + 0x3b4) = *(uint32_t *)(in_RCX + 0x3b4) | 0x20;
        *(int64_t **)(in_RCX + 0x340) = in_R9;
        return 1;
    case 0x4f:
        uVar15 = *(undefined8 *)(in_RCX + 0x360);
        *(uint32_t *)(in_RCX + 0x3b4) = *(uint32_t *)(in_RCX + 0x3b4) | 0x20;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c497e;
        fcn.180224990(uVar15, 0x1804b3080, 0x1013);
        *(undefined8 *)(in_RCX + 0x360) = 0;
        if (in_R9 == (int64_t *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c499a;
        uVar22 = fcn.180498cd0(in_R9);
        if (uVar22 < 0x100) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49aa;
            iVar21 = fcn.180498cd0(in_R9);
            if (iVar21 != 0) {
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49c5;
                iVar21 = fcn.1802231e0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                                       *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                                       *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19));
                *(int64_t *)(in_RCX + 0x360) = iVar21;
                if (iVar21 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49da;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                              *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
                goto code_r0x0001801c49df;
            }
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a01;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a19;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0x50:
        *(uint32_t *)(in_RCX + 0x3b0) = in_R8D;
        return 1;
    case 0x51:
        iVar21 = *(int64_t *)(in_RCX + 0x3a8);
        *(undefined8 *)(in_RCX + 0x358) = 0x1801c31f0;
        if (iVar21 != 0) {
            *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a4f;
            fcn.180224990(iVar21, 0x1804b3080, 0x1024);
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a64;
        iVar21 = fcn.1802231e0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19));
        *(int64_t *)(in_RCX + 0x3a8) = iVar21;
        if (iVar21 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4a79;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19));
code_r0x0001801c49df:
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c49f2;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                      *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19));
        break;
    case 0x52:
        iVar19 = *(int64_t *)(in_RCX + 0x110);
        if ((iVar19 != 0) || (in_R8D != 0)) goto code_r0x0001801c4d20;
    case 0x73:
        iVar19 = *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x10);
code_r0x0001801c4d20:
        *in_R9 = iVar19;
        return 1;
    case 0x53:
        uVar15 = *(undefined8 *)(in_RCX + 0x110);
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4d3f;
        fcn.180238640(uVar15);
        *(undefined8 *)(in_RCX + 0x110) = 0;
        return 1;
    case 0x58:
        iVar21 = 0;
        if (in_R8D == 0) {
            piVar25 = *(int64_t **)((int64_t)&arg_70h + iVar20 + iVar19);
            iVar28 = *(int64_t *)((int64_t)&arg_60h + iVar20 + iVar19);
            puVar29 = (undefined *)((int64_t)&arg_68h + iVar20 + iVar19);
        } else {
            piVar25 = *(int64_t **)((int64_t)&arg_70h + iVar20 + iVar19);
            *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RSI;
            iVar28 = iVar20 + iVar5 + 0x40;
            *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
            *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a2440;
            iVar19 = fcn.18045a350();
            iVar19 = -iVar19;
            if (in_R9 == (int64_t *)0x0) {
                puVar29 = (undefined *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar5 + -0x20);
                unaff_RSI = *(int64_t *)((int64_t)&arg_98h + iVar19 + iVar20 + iVar5 + -0x20);
                iVar28 = *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar5 + -0x20);
                in_R9 = (int64_t *)0x0;
            } else {
                *(int64_t **)((int64_t)&arg_90h + iVar19 + iVar20 + iVar5 + -0x20) = piVar25;
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar5 + -0x20) = 0x1801a246a;
                piVar25 = (int64_t *)fcn.180238060(*(int64_t *)((int64_t)&arg_a8h + iVar19 + iVar20 + iVar5 + -0x20));
                if (piVar25 == (int64_t *)0x0) {
                    return 0;
                }
                puVar29 = (undefined *)((int64_t)&arg_58h + iVar19 + iVar28 + -0x60);
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar28 + -0x60) = 0x1801a2480;
                unaff_RSI = iVar21;
                iVar28 = in_RCX;
                in_R9 = piVar25;
            }
        }
        *(undefined8 *)(puVar29 + 0x20) = unaff_RBP;
        *(int64_t *)(puVar29 + -8) = unaff_RSI;
        *(int64_t *)(puVar29 + -0x10) = iVar28;
        *(undefined8 *)(puVar29 + -0x18) = unaff_R15;
        *(undefined8 *)(puVar29 + -0x20) = 0x1801a2333;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if (iVar21 == 0) {
            piVar24 = *(int64_t **)(in_RCX + 0x158);
        } else {
            piVar24 = *(int64_t **)(iVar21 + 0x878);
        }
        iVar20 = *piVar24;
        if (iVar20 == 0) {
            return 0;
        }
        *(int64_t **)(puVar29 + iVar19 + 0x38) = piVar25;
        *(undefined8 *)(puVar29 + iVar19 + 0x40) = unaff_R12;
        iVar27 = 0;
        *(undefined8 *)(puVar29 + iVar19 + 0x48) = unaff_R14;
        *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2389;
        iVar13 = fcn.180222010(in_R9);
        if (0 < iVar13) {
            do {
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a239a;
                fcn.180222340(in_R9, iVar27);
                *(undefined4 *)(puVar29 + iVar19 + 8) = 0;
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23b0;
                iVar13 = fcn.1801a8d20(*(int64_t *)(puVar29 + iVar19 + 0x28), *(int64_t *)(puVar29 + iVar19 + 0x30), 
                                       *(int64_t *)(puVar29 + iVar19 + 0x40), *(int64_t *)(puVar29 + iVar19 + 0x48), 
                                       *(int64_t *)(puVar29 + iVar19 + 0xb8));
                if (iVar13 != 1) {
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)(puVar29 + iVar19 + 8), *(int64_t *)(puVar29 + iVar19 + 0x10));
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)(puVar29 + iVar19 + 8), *(int64_t *)(puVar29 + iVar19 + 0x10), 
                                  *(int64_t *)(puVar29 + iVar19 + 0x18), *(int64_t *)(puVar29 + iVar19 + 0x20), 
                                  *(int64_t *)(puVar29 + iVar19 + 0x38));
                    *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(puVar29 + iVar19 + 0x28));
                    return 0;
                }
                iVar27 = iVar27 + 1;
                *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23c2;
                iVar13 = fcn.180222010(in_R9);
            } while (iVar27 < iVar13);
        }
        uVar15 = *(undefined8 *)(iVar20 + 0x10);
        *(undefined8 *)(puVar29 + iVar19 + -0x20) = 0x1801a23cf;
        fcn.180238640(uVar15);
        *(int64_t **)(iVar20 + 0x10) = in_R9;
        return 1;
    case 0x59:
        iVar21 = 0;
        if (in_R8D == 0) {
            uVar15 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
            *(undefined8 *)((int64_t)&arg_80h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
            *(int64_t *)((int64_t)&arg_60h + iVar20 + iVar19) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a17c0;
            iVar19 = fcn.18045a350(0, in_RCX, in_R9);
            iVar19 = -iVar19;
            if (iVar21 == 0) {
                piVar25 = *(int64_t **)(in_RCX + 0x158);
            } else {
                piVar25 = *(int64_t **)(iVar21 + 0x878);
            }
            *(undefined8 *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar28 + -0x20) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_a8h + iVar19 + iVar20 + iVar28 + -0x20) = uVar15;
            iVar21 = *piVar25;
            if (iVar21 != 0) {
                *(undefined4 *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar28 + -0x20) = 0;
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a17fb;
                iVar13 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)((int64_t)&arg_a8h + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)((int64_t)&arg_b8h + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar28 + -0x20), 
                                       *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar28 + -0x20));
                if (iVar13 == 1) {
                    iVar14 = *(int64_t *)(iVar21 + 0x10);
                    if (iVar14 == 0) {
                        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1853;
                        iVar14 = fcn.180221f20();
                        *(int64_t *)(iVar21 + 0x10) = iVar14;
                        if (iVar14 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1867;
                    iVar13 = fcn.180222110(iVar14, in_R9);
                    return (uint64_t)(iVar13 != 0);
                }
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a1807;
                fcn.180229480(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar28 + -0x20));
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a181f;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_98h + iVar19 + iVar20 + iVar28 + -0x20), 
                              *(int64_t *)((int64_t)&arg_b0h + iVar19 + iVar20 + iVar28 + -0x20));
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar28 + -0x20) = 0x1801a182e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar28 + -0x20));
            }
            return 0;
        }
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a1895;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a18a9;
        uVar22 = fcn.1802375f0(in_R9);
        if ((int32_t)uVar22 == 0) {
            return uVar22;
        }
        *(undefined8 *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar14 + -0x20) = uVar15;
        if (iVar21 == 0) {
            piVar25 = *(int64_t **)(in_RCX + 0x158);
        } else {
            piVar25 = *(int64_t **)(iVar21 + 0x878);
        }
        iVar21 = *piVar25;
        if (iVar21 != 0) {
            *(undefined4 *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar14 + -0x20) = 0;
            *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a18f8;
            iVar13 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_a8h + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_b8h + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar14 + -0x20), 
                                   *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar14 + -0x20));
            if (iVar13 == 1) {
                iVar28 = *(int64_t *)(iVar21 + 0x10);
                if (iVar28 == 0) {
                    *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1958;
                    iVar28 = fcn.180221f20();
                    *(int64_t *)(iVar21 + 0x10) = iVar28;
                    if (iVar28 == 0) goto code_r0x0001801a192b;
                }
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a196c;
                iVar13 = fcn.180222110(iVar28, in_R9);
                if (iVar13 != 0) {
                    return 1;
                }
            } else {
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1904;
                fcn.180229480(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar14 + -0x20));
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a191c;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_98h + iVar19 + iVar20 + iVar14 + -0x20), 
                              *(int64_t *)((int64_t)&arg_b0h + iVar19 + iVar20 + iVar14 + -0x20));
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a192b;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_a0h + iVar19 + iVar20 + iVar14 + -0x20));
            }
        }
code_r0x0001801a192b:
        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar14 + -0x20) = 0x1801a1933;
        fcn.18021fe80(in_R9);
        return 0;
    case 0x5b:
        *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19) = (int64_t)(int32_t)in_R8D;
        *(int64_t **)((int64_t)&arg_50h + iVar20 + iVar19) = in_R9;
        *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19) = in_RCX + 0x2b0;
        *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19) = in_RCX + 0x2b8;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4afe;
        uVar22 = fcn.1801abb30(*(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_60h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_68h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_88h + iVar20 + iVar19));
        return uVar22;
    case 0x5c:
        *(int64_t **)((int64_t)&arg_58h + iVar20 + iVar19) = in_R9;
        *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19) = in_RCX + 0x2b0;
        *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19) = in_RCX + 0x2b8;
        *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19) = in_RCX + 0x2a0;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4b4f;
        uVar22 = fcn.1801abdc0(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_90h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_b0h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_b8h + iVar20 + iVar19));
        return uVar22;
    case 0x61:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        iVar13 = 0;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar30 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        goto code_r0x0001801ac640;
    case 0x62:
        iVar13 = 0;
        goto code_r0x0001801c4bb0;
    case 0x65:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        iVar13 = 1;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar30 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
code_r0x0001801ac640:
        uVar22 = (uint64_t)(int32_t)in_R8D;
        *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19) = uVar15;
        *(undefined8 *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = uVar30;
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_50h + iVar20 + iVar19) = unaff_R15;
        *(undefined8 *)((int64_t)&arg_48h + iVar20 + iVar19) = 0x1801ac65e;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if ((uVar22 & 1) == 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar19 + iVar20 + iVar7 + -0x20) = 0x1801ac697;
            puVar18 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar7 + -0x20));
            if (puVar18 != (undefined2 *)0x0) {
                uVar31 = 0;
                puVar32 = puVar18;
                if (uVar22 != 0) {
                    do {
                        iVar27 = *(int32_t *)in_R9;
                        uVar26 = 0;
                        piVar1 = (int32_t *)((int64_t)in_R9 + 4);
                        in_R9 = in_R9 + 1;
                        iVar28 = 0x1804ae0e0;
                        do {
                            if ((*(int32_t *)(iVar28 + 0x14) == iVar27) && (*(int32_t *)(iVar28 + 0x1c) == *piVar1)) {
                                *puVar32 = *(undefined2 *)(iVar28 + 0x10);
                                puVar32 = puVar32 + 1;
                                break;
                            }
                            uVar26 = uVar26 + 1;
                            iVar28 = iVar28 + 0x48;
                        } while (uVar26 < 0x1f);
                        if (uVar26 == 0x1f) {
                            *(undefined8 *)((int64_t)&arg_48h + iVar19 + iVar20 + iVar7 + -0x20) = 0x1801ac744;
                            fcn.180224990(puVar18, 0x1804aeee0, 0xf47);
                            return 0;
                        }
                        uVar31 = uVar31 + 2;
                    } while (uVar31 < uVar22);
                }
                if (iVar13 == 0) {
                    uVar15 = *(undefined8 *)(iVar21 + 0x40);
                    *(undefined8 *)((int64_t)&arg_48h + iVar19 + iVar20 + iVar7 + -0x20) = 0x1801ac76e;
                    fcn.180224990(uVar15, 0x1804aeee0, 0xf3f);
                    *(undefined2 **)(iVar21 + 0x40) = puVar18;
                    *(uint64_t *)(iVar21 + 0x48) = uVar22 >> 1;
                    return 1;
                }
                uVar15 = *(undefined8 *)(iVar21 + 0x50);
                *(undefined8 *)((int64_t)&arg_48h + iVar19 + iVar20 + iVar7 + -0x20) = 0x1801ac720;
                fcn.180224990(uVar15, 0x1804aeee0, 0xf3b);
                *(undefined2 **)(iVar21 + 0x50) = puVar18;
                *(uint64_t *)(iVar21 + 0x58) = uVar22 >> 1;
                return 1;
            }
        }
        return 0;
    case 0x66:
        iVar13 = 1;
code_r0x0001801c4bb0:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        uVar15 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_48h + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_40h + iVar20 + iVar19) = 0x1801ac790;
        iVar28 = fcn.18045a350(in_RCX, iVar21, in_R9);
        iVar28 = -iVar28;
        *(uint64_t *)((int64_t)&arg_108h + iVar28 + iVar20 + iVar8 + -0x20) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&arg_48h + iVar28 + iVar20 + iVar8 + -0x20;
        iVar19 = *(int64_t *)((int64_t)&arg_100h + iVar28 + iVar20 + iVar8 + -0x20);
        *(undefined8 *)((int64_t)&arg_78h + iVar28 + iVar20 + iVar8 + -0x20) = 0;
        if (in_RCX != 0) {
            iVar19 = in_RCX;
        }
        *(int64_t *)((int64_t)&arg_100h + iVar28 + iVar20 + iVar8 + -0x20) = iVar19;
        *(int64_t *)((int64_t)&arg_68h + iVar28 + iVar20 + iVar8 + -0x20) =
             (int64_t)&arg_78h + iVar28 + iVar20 + iVar8 + -0x20;
        *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac7f0;
        iVar27 = fcn.18024a850(*(int64_t *)((int64_t)&arg_70h + iVar28 + iVar20 + iVar8 + -0x20), 
                               *(int64_t *)((int64_t)&arg_78h + iVar28 + iVar20 + iVar8 + -0x20), 
                               *(int64_t *)((int64_t)&arg_80h + iVar28 + iVar20 + iVar8 + -0x20), 
                               *(int64_t *)((int64_t)&arg_90h + iVar28 + iVar20 + iVar8 + -0x20));
        if (iVar27 != 0) {
            *(undefined8 *)((int64_t)&arg_118h + iVar28 + iVar20 + iVar8 + -0x20) = uVar15;
            iVar19 = *(int64_t *)((int64_t)&arg_78h + iVar28 + iVar20 + iVar8 + -0x20);
            if (iVar19 == 0) {
                *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac80f;
                fcn.180229480(*(int64_t *)((int64_t)&arg_68h + iVar28 + iVar20 + iVar8 + -0x20), 
                              *(int64_t *)((int64_t)&arg_70h + iVar28 + iVar20 + iVar8 + -0x20));
                *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac827;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_68h + iVar28 + iVar20 + iVar8 + -0x20), 
                              *(int64_t *)((int64_t)&arg_70h + iVar28 + iVar20 + iVar8 + -0x20), 
                              *(int64_t *)((int64_t)&arg_78h + iVar28 + iVar20 + iVar8 + -0x20), 
                              *(int64_t *)((int64_t)&arg_80h + iVar28 + iVar20 + iVar8 + -0x20), 
                              *(int64_t *)((int64_t)&arg_98h + iVar28 + iVar20 + iVar8 + -0x20));
                *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac840;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_88h + iVar28 + iVar20 + iVar8 + -0x20));
            } else if (iVar21 != 0) {
                *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac86d;
                iVar14 = fcn.180224ed0(*(int64_t *)((int64_t)&arg_68h + iVar28 + iVar20 + iVar8 + -0x20));
                if (iVar14 != 0) {
                    *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac886;
                    fcn.180498030(iVar14, (int64_t)&arg_80h + iVar28 + iVar20 + iVar8 + -0x20, iVar19 * 2);
                    if (iVar13 == 0) {
                        uVar15 = *(undefined8 *)(iVar21 + 0x40);
                        *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac8ba;
                        fcn.180224990(uVar15, 0x1804aeee0, 0xf17);
                        *(int64_t *)(iVar21 + 0x40) = iVar14;
                        *(int64_t *)(iVar21 + 0x48) = iVar19;
                    } else {
                        uVar15 = *(undefined8 *)(iVar21 + 0x50);
                        *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac8a1;
                        fcn.180224990(uVar15, 0x1804aeee0, 0xf13);
                        *(int64_t *)(iVar21 + 0x50) = iVar14;
                        *(int64_t *)(iVar21 + 0x58) = iVar19;
                    }
                }
            }
        }
        uVar22 = *(uint64_t *)((int64_t)&arg_108h + iVar28 + iVar20 + iVar8 + -0x20);
        *(undefined8 *)((int64_t)&arg_40h + iVar28 + iVar20 + iVar8 + -0x20) = 0x1801ac8e1;
        uVar22 = fcn.180459870(uVar22 ^ (int64_t)&arg_48h + iVar28 + iVar20 + iVar8 + -0x20);
        return uVar22;
    case 0x68:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        uVar22 = (uint64_t)(int32_t)in_R8D;
        *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19 + 0x20 + -0x20) =
             *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801c5915;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        uVar15 = *(undefined8 *)(iVar21 + 0x30);
        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar9 + -0x20) = 0x1801c5937;
        fcn.180224990(uVar15, 0x1804b3080, 0x121c);
        *(undefined8 *)(iVar21 + 0x30) = 0;
        *(undefined8 *)(iVar21 + 0x38) = 0;
        if ((in_R9 != (int64_t *)0x0) && (uVar22 != 0)) {
            if (uVar22 < 0x100) {
                *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar9 + -0x20) = 0x1801c596c;
                iVar19 = fcn.180223170(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar9 + -0x20));
                *(int64_t *)(iVar21 + 0x30) = iVar19;
                if (iVar19 != 0) {
                    *(uint64_t *)(iVar21 + 0x38) = uVar22;
                    return 1;
                }
            }
            return 0;
        }
        return 1;
    case 0x69:
        iVar14 = 0;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar30 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar19) = in_RCX;
        *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = uVar15;
        *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_50h + iVar20 + iVar19) = uVar30;
        *(undefined8 *)((int64_t)&arg_48h + iVar20 + iVar19) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_40h + iVar20 + iVar19) = unaff_R13;
        *(undefined8 *)(&stack0x00000038 + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_30h + iVar20 + iVar19) = unaff_R15;
        *(undefined8 *)(&stack0x00000028 + iVar20 + iVar19) = 0x1801a141f;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        iVar28 = 0;
        *(undefined8 *)((int64_t)&arg_d8h + iVar19 + iVar20 + iVar21 + -0x20) = 0;
        if (iVar14 == 0) {
            ppiVar23 = *(int64_t ***)(in_RCX + 0x158);
        } else {
            ppiVar23 = *(int64_t ***)(iVar14 + 0x878);
            in_RCX = *(int64_t *)(iVar14 + 8);
        }
        piVar25 = *ppiVar23;
        *(int64_t **)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20) = piVar25;
        uVar31 = 0;
        uVar11 = 0;
        uVar22 = 0;
        *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20) = in_RCX;
        *(int64_t ***)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20) = ppiVar23;
        *(uint32_t *)((int64_t)&arg_d0h + iVar19 + iVar20 + iVar21 + -0x20) = in_R8D & 4;
        if (*piVar25 == 0) {
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a147d;
            fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1495;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                          *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14a7;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
            uVar22 = uVar31;
code_r0x0001801a1782:
            uVar31 = uVar22;
            if (*(int32_t *)((int64_t)&arg_d0h + iVar19 + iVar20 + iVar21 + -0x20) == 0) goto code_r0x0001801a1794;
        } else {
            if ((in_R8D & 4) == 0) {
                if ((in_R8D & 1) != 0) {
                    *(int64_t *)((int64_t)&arg_d8h + iVar19 + iVar20 + iVar21 + -0x20) = piVar25[2];
                }
code_r0x0001801a1536:
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a154a;
                iVar28 = fcn.18024c080(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                if (iVar28 == 0) {
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1557;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a156f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                  *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1581;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
                    uVar22 = uVar31;
                } else {
                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a159c;
                    iVar13 = fcn.18024bbe0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                           *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                           *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20));
                    if (iVar13 == 0) {
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15a5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                      *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
                        uVar22 = uVar31;
                    } else {
                        uVar10 = *(uint32_t *)((int64_t)ppiVar23 + 0x1c);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15e5;
                        fcn.18024c330(iVar28, uVar10 & 0x30000);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a15ed;
                        iVar13 = fcn.18024c740(*(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_78h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar21 + -0x20));
                        if (iVar13 < 1) {
                            if ((in_R8D & 8) == 0) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16f2;
                                uVar12 = fcn.18024bbd0(iVar28);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16f9;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1711;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1718;
                                fcn.180250ec0(uVar12);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1731;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
                                goto code_r0x0001801a1782;
                            }
                            if ((in_R8D & 0x10) != 0) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1606;
                                fcn.1802203d0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                            }
                            uVar11 = 2;
                        }
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1613;
                        iVar14 = fcn.18024b970(iVar28);
                        *(int64_t *)((int64_t)&arg_d8h + iVar19 + iVar20 + iVar21 + -0x20) = iVar14;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1626;
                        uVar15 = fcn.1802222a0(*(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_78h + iVar19 + iVar20 + iVar21 + -0x20));
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a162e;
                        fcn.18021fe80(uVar15);
                        if ((in_R8D & 2) != 0) {
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a163c;
                            iVar13 = fcn.180222010(iVar14);
                            if (0 < iVar13) {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1648;
                                iVar13 = fcn.180222010(iVar14);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1653;
                                uVar15 = fcn.180222340(iVar14, iVar13 + -1);
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a165b;
                                uVar10 = fcn.18023bbb0(uVar15);
                                if ((uVar10 >> 0xd & 1) != 0) {
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1669;
                                    uVar15 = fcn.180222020(iVar14);
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1671;
                                    fcn.18021fe80(uVar15);
                                }
                            }
                        }
                        iVar27 = 0;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a167b;
                        iVar13 = fcn.180222010(iVar14);
                        if (iVar13 < 1) {
                            iVar2 = piVar25[2];
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1774;
                            fcn.180238640(iVar2);
                            piVar25[2] = iVar14;
                            uVar22 = (uint64_t)uVar11;
                            if (uVar11 == 0) {
                                uVar22 = 1;
                            }
                        } else {
                            do {
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a169d;
                                fcn.180222340(iVar14, iVar27);
                                *(undefined4 *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20) = 0;
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16b6;
                                uVar11 = fcn.1801a8d20(*(int64_t *)
                                                        ((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)
                                                        ((int64_t)&arg_78h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)
                                                        ((int64_t)&arg_88h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)
                                                        ((int64_t)&arg_90h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                       *(int64_t *)
                                                        ((int64_t)&arg_100h + iVar19 + iVar20 + iVar21 + -0x20));
                                uVar22 = (uint64_t)uVar11;
                                if (uVar11 != 1) {
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1738;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1750;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_68h + iVar19 + iVar20 + iVar21 + -0x20), 
                                                  *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a175f;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20));
                                    *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1767;
                                    fcn.180238640(iVar14);
                                    uVar22 = 0;
                                    goto code_r0x0001801a1782;
                                }
                                iVar27 = iVar27 + 1;
                                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16c7;
                                iVar13 = fcn.180222010(iVar14);
                            } while (iVar27 < iVar13);
                            iVar14 = *(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20);
                            uVar15 = *(undefined8 *)(iVar14 + 0x10);
                            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a16d9;
                            fcn.180238640(uVar15);
                            *(undefined8 *)(iVar14 + 0x10) =
                                 *(undefined8 *)((int64_t)&arg_d8h + iVar19 + iVar20 + iVar21 + -0x20);
                        }
                    }
                }
                goto code_r0x0001801a1782;
            }
            *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14b5;
            iVar14 = fcn.18021f3d0(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_70h + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_78h + iVar19 + iVar20 + iVar21 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20));
            if (iVar14 != 0) {
                iVar2 = piVar25[2];
                iVar27 = 0;
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14cc;
                iVar13 = fcn.180222010(iVar2);
                if (0 < iVar13) {
                    do {
                        iVar2 = piVar25[2];
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14db;
                        uVar15 = fcn.180222340(iVar2, iVar27);
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14e6;
                        iVar13 = fcn.18021f070(iVar14, uVar15);
                        if (iVar13 == 0) goto code_r0x0001801a178c;
                        iVar2 = piVar25[2];
                        iVar27 = iVar27 + 1;
                        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a14f9;
                        iVar13 = fcn.180222010(iVar2);
                    } while (iVar27 < iVar13);
                }
                iVar2 = *piVar25;
                *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1508;
                iVar13 = fcn.18021f070(iVar14, iVar2);
                if (iVar13 != 0) {
                    ppiVar23 = *(int64_t ***)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20);
                    goto code_r0x0001801a1536;
                }
            }
        }
code_r0x0001801a178c:
        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a1794;
        fcn.18021f290(*(int64_t *)((int64_t)&arg_50h + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)((int64_t)&arg_60h + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar21 + -0x20), 
                      *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar21 + -0x20));
code_r0x0001801a1794:
        *(undefined8 *)(&stack0x00000028 + iVar19 + iVar20 + iVar21 + -0x20) = 0x1801a179c;
        fcn.18024b910(iVar28);
        return uVar31;
    case 0x6a:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        iVar13 = 0;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar30 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        goto code_r0x0001801a24c0;
    case 0x6b:
        iVar21 = *(int64_t *)(in_RCX + 0x158);
        iVar13 = 1;
        uVar15 = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        uVar30 = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
code_r0x0001801a24c0:
        *(undefined8 *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = uVar30;
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a24d5;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if ((in_R8D != 0) && (in_R9 != (int64_t *)0x0)) {
            *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar6 + -0x20) = 0x1801a24f3;
            uVar22 = fcn.18021f5b0(in_R9);
            if ((int32_t)uVar22 == 0) {
                return uVar22;
            }
        }
        *(undefined8 *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar6 + -0x20) = uVar15;
        iVar28 = 0x70;
        if (iVar13 == 0) {
            iVar28 = 0x78;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar6 + -0x20) = 0x1801a2524;
        fcn.18021f290(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar6 + -0x20), 
                      *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar6 + -0x20), 
                      *(int64_t *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar6 + -0x20), 
                      *(int64_t *)((int64_t)&arg_b0h + iVar19 + iVar20 + iVar6 + -0x20), 
                      *(int64_t *)((int64_t)&arg_b8h + iVar19 + iVar20 + iVar6 + -0x20));
        *(int64_t **)(iVar28 + iVar21) = in_R9;
        return 1;
    case 0x74:
        ppiVar23 = *(int64_t ***)(in_RCX + 0x158);
        *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_70h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_78h + iVar20 + iVar19) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar19) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_88h + iVar20 + iVar19) = *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19);
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar19) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar19) = 0x1801a2280;
        iVar19 = fcn.18045a350();
        iVar19 = -iVar19;
        if (in_R9 != (int64_t *)0x0) {
            piVar25 = (int64_t *)0x0;
            if (ppiVar23[5] != (int64_t *)0x0) {
                ppiVar16 = (int64_t **)ppiVar23[4];
                piVar24 = piVar25;
                do {
                    if ((*ppiVar16 == in_R9) && (ppiVar16[1] != (int64_t *)0x0)) {
                        *ppiVar23 = (int64_t *)ppiVar16;
                        return 1;
                    }
                    piVar24 = (int64_t *)((int64_t)piVar24 + 1);
                    ppiVar16 = ppiVar16 + 5;
                    piVar17 = piVar25;
                } while (piVar24 < ppiVar23[5]);
                do {
                    piVar24 = (int64_t *)((int64_t)ppiVar23[4] + (int64_t)piVar17);
                    if ((piVar24[1] != 0) && (*piVar24 != 0)) {
                        *(undefined8 *)((int64_t)&arg_58h + iVar19 + iVar20 + iVar2 + -0x20) = 0x1801a22de;
                        iVar13 = fcn.180238200(*(int64_t *)((int64_t)&arg_80h + iVar19 + iVar20 + iVar2 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar19 + iVar20 + iVar2 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_90h + iVar19 + iVar20 + iVar2 + -0x20), 
                                               *(int64_t *)(&stack0x000000c0 + iVar19 + iVar20 + iVar2 + -0x20), 
                                               *(int64_t *)((int64_t)&arg_c8h + iVar19 + iVar20 + iVar2 + -0x20), 
                                               *(int64_t *)(&stack0x00000130 + iVar19 + iVar20 + iVar2 + -0x20), 
                                               *(int64_t *)(&stack0x00000178 + iVar19 + iVar20 + iVar2 + -0x20));
                        if (iVar13 == 0) {
                            *ppiVar23 = piVar24;
                            return 1;
                        }
                    }
                    piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                    piVar17 = piVar17 + 5;
                } while (piVar25 < ppiVar23[5]);
            }
        }
        return 0;
    case 0x75:
        ppiVar23 = *(int64_t ***)(in_RCX + 0x158);
        if (ppiVar23 != (int64_t **)0x0) {
            if (in_R8D == 1) {
                piVar24 = ppiVar23[5];
                piVar25 = (int64_t *)0x0;
                if (piVar24 != (int64_t *)0x0) {
code_r0x0001801a25ab:
                    piVar17 = ppiVar23[4] + (int64_t)piVar25 * 5;
                    while ((*piVar17 == 0 || (piVar17[1] == 0))) {
                        piVar25 = (int64_t *)((int64_t)piVar25 + 1);
                        piVar17 = piVar17 + 5;
                        if (piVar24 <= piVar25) {
                            return 0;
                        }
                    }
                    *ppiVar23 = piVar17;
                    return 1;
                }
            } else if ((in_R8D == 2) &&
                      (piVar25 = (int64_t *)(((int64_t)*ppiVar23 - (int64_t)ppiVar23[4]) / 0x28 + 1),
                      piVar25 < ppiVar23[5])) {
                piVar24 = ppiVar23[5];
                goto code_r0x0001801a25ab;
            }
        }
        return 0;
    case 0x76:
        *(uint32_t *)(*(int64_t *)(in_RCX + 0x158) + 0x18) = in_R8D;
        return 1;
    case 0x7f:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x278);
    case 0x80:
        *in_R9 = *(int64_t *)(in_RCX + 0x268);
        return 1;
    case 0x81:
        *in_R9 = *(int64_t *)(in_RCX + 0x270);
        return 1;
    case 0x89:
        iVar19 = *(int64_t *)(in_RCX + 0x158);
        bVar4 = false;
        goto code_r0x0001801a1fc0;
    case 0x8a:
        iVar19 = *(int64_t *)(in_RCX + 0x158);
        bVar4 = true;
code_r0x0001801a1fc0:
        iVar20 = 0x70;
        if (!bVar4) {
            iVar20 = 0x78;
        }
        *in_R9 = *(int64_t *)(iVar20 + iVar19);
        return 1;
    case 0x8b:
        *(int64_t **)((int64_t)&arg_48h + iVar20 + iVar19) = in_R9;
        *(uint32_t *)((int64_t)&arg_40h + iVar20 + iVar19) = in_R8D;
        *(undefined8 *)((int64_t)apcStackX_18 + iVar20 + iVar19) = 0x1801c4b83;
        uVar22 = fcn.1801ab100(*(int64_t *)((int64_t)&arg_40h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_68h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_b0h + iVar20 + iVar19), 
                               *(int64_t *)((int64_t)&arg_b8h + iVar20 + iVar19));
        return uVar22;
    }
    *(code **)((int64_t)apcStackX_18 + iVar20 + iVar19) = case.0x1801c46af.5;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar20 + iVar19));
code_r0x0001801c46e6:
    return 0;
}

// ============================================================
// Function: FUN_1801bedc0
// Address: 0x1801bedc0
// Size: 168 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel

uint64_t fcn.1801bedc0(int64_t arg_90h, int64_t arg_a8h, int64_t arg_b8h, int64_t arg_d0h, int64_t arg_120h)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801bedca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801beddd;
    uVar3 = fcn.1801bdce0(*(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    if ((int32_t)uVar3 == 0) {
        return uVar3;
    }
    *(undefined8 *)(&stack0x00000060 + iVar2) = unaff_RBX;
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&iStackX_20 + iVar2) + 0x58);
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bedf9;
    uVar4 = fcn.1801dd6c0(uVar4);
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bee01;
    fcn.18026d890(uVar4);
    *(undefined4 *)(&stack0x00000054 + iVar2) = 1;
    if (*(int32_t *)(&stack0x00000048 + iVar2) == 0) {
        if (*(int64_t *)(&stack0x00000038 + iVar2) != 0) {
            *(undefined4 *)(*(int64_t *)(&stack0x00000038 + iVar2) + 0x128) = 0;
        }
    } else if (*(int64_t *)(&stack0x00000040 + iVar2) != 0) {
        *(undefined4 *)(*(int64_t *)(&stack0x00000040 + iVar2) + 0xb8) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bee44;
    uVar1 = fcn.1801c0be0(*(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                          *(int64_t *)(&stack0x00000040 + iVar2));
    uVar4 = *(undefined8 *)(*(int64_t *)((int64_t)&iStackX_20 + iVar2) + 0x58);
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bee54;
    uVar4 = fcn.1801dd6c0(uVar4);
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801bee5c;
    fcn.18026d900(uVar4);
    return (uint64_t)uVar1;
}

// ============================================================
// Function: FUN_1801bee70
// Address: 0x1801bee70
// Size: 83 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1801bee70(int64_t arg_68h)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int32_t var_20h;
    int32_t var_1ch;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bee7f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bee91;
    iVar4 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000040 + iVar5));
    if (iVar4 == 0) {
        return;
    }
    if ((int32_t)var_18h == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_RBX;
        if (var_1ch == 0) {
            uVar6 = *(undefined8 *)(var_48h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef5e;
            uVar6 = fcn.1801dd6c0(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef66;
            fcn.18026d890(uVar6);
            if (var_20h != 0) {
                *(int64_t *)(var_30h + 0xf8) = *(int64_t *)(var_30h + 0xf8) + -1;
                cVar2 = *(char *)(*(int64_t *)(var_28h + 0x80) + 0x101);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(*(int64_t *)(var_28h + 0x80) + 0x70);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befa0;
                    iVar4 = fcn.1801e6210(uVar6, 0);
                    if (iVar4 == 0) {
                        uVar6 = *(undefined8 *)(var_30h + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befbf;
                        fcn.1801e39c0(uVar6);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befcd;
                        fcn.1801e7da0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5)
                                     );
                    }
                }
                iVar3 = *(int64_t *)(var_28h + 0x80);
                cVar2 = *(char *)(iVar3 + 0x102);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(var_30h + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beff7;
                    uVar6 = fcn.1801e39c0(uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf005;
                    fcn.1801e7f00(uVar6, iVar3, 0);
                }
                puVar1 = (uint32_t *)(*(int64_t *)(var_28h + 0x80) + 0x104);
                *puVar1 = *puVar1 | 0x20;
                uVar6 = *(undefined8 *)(var_30h + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf032;
                fcn.1801e39c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf03d;
                fcn.1801e7fb0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                              *(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x00000060 + iVar5), 
                              *(int64_t *)((int64_t)&arg_68h + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                              *(int64_t *)(&stack0x00000090 + iVar5));
                iVar3 = *(int64_t *)(var_30h + 0xb0);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf05e;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf066;
                fcn.18026d900(uVar6);
                if (var_28h == iVar3) {
                    return;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf077;
                fcn.180193500(var_30h);
                return;
            }
            iVar3 = *(int64_t *)(var_30h + 0xb0);
            if (iVar3 != 0) {
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf09f;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0a7;
                fcn.18026d900(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0af;
                fcn.180193500(iVar3);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0bc;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0c4;
                fcn.18026d890(uVar6);
                *(undefined8 *)(var_30h + 0xb0) = 0;
            }
            if (((uint8_t)*(undefined4 *)(var_30h + 0x100) & 9) == 9) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0ee;
                fcn.1801e84e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0fe;
                fcn.1801e8400(var_30h + 0xd8);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf10c;
            fcn.1801c0480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            if (*(int64_t *)(var_30h + 0x80) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf121;
                fcn.180193500();
            }
            if (*(int64_t *)(var_30h + 0x88) == 0) {
                return;
            }
        } else {
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee1;
            fcn.1801e3990(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef1;
            fcn.1801e8e30(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef09;
            fcn.1801e8cd0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef19;
            fcn.1801e8db0(uVar6);
            if (*(int64_t *)(var_38h + 0x78) == 0) {
                uVar6 = *(undefined8 *)(var_38h + 0x80);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef36;
                fcn.1801dd680(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef46;
                fcn.18026d840(var_38h + 0x90);
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf136;
        fcn.180193500();
        return;
    }
    uVar6 = *(undefined8 *)(var_40h + 0x78);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeac;
    fcn.1801dd680(uVar6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeb9;
    fcn.18026d840(var_40h + 0x80);
    return;
}

// ============================================================
// Function: FUN_1801beec3
// Address: 0x1801beec3
// Size: 142 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1801bee70(int64_t arg_68h)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int32_t var_20h;
    int32_t var_1ch;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bee7f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bee91;
    iVar4 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000040 + iVar5));
    if (iVar4 == 0) {
        return;
    }
    if ((int32_t)var_18h == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_RBX;
        if (var_1ch == 0) {
            uVar6 = *(undefined8 *)(var_48h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef5e;
            uVar6 = fcn.1801dd6c0(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef66;
            fcn.18026d890(uVar6);
            if (var_20h != 0) {
                *(int64_t *)(var_30h + 0xf8) = *(int64_t *)(var_30h + 0xf8) + -1;
                cVar2 = *(char *)(*(int64_t *)(var_28h + 0x80) + 0x101);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(*(int64_t *)(var_28h + 0x80) + 0x70);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befa0;
                    iVar4 = fcn.1801e6210(uVar6, 0);
                    if (iVar4 == 0) {
                        uVar6 = *(undefined8 *)(var_30h + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befbf;
                        fcn.1801e39c0(uVar6);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befcd;
                        fcn.1801e7da0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5)
                                     );
                    }
                }
                iVar3 = *(int64_t *)(var_28h + 0x80);
                cVar2 = *(char *)(iVar3 + 0x102);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(var_30h + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beff7;
                    uVar6 = fcn.1801e39c0(uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf005;
                    fcn.1801e7f00(uVar6, iVar3, 0);
                }
                puVar1 = (uint32_t *)(*(int64_t *)(var_28h + 0x80) + 0x104);
                *puVar1 = *puVar1 | 0x20;
                uVar6 = *(undefined8 *)(var_30h + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf032;
                fcn.1801e39c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf03d;
                fcn.1801e7fb0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                              *(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x00000060 + iVar5), 
                              *(int64_t *)((int64_t)&arg_68h + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                              *(int64_t *)(&stack0x00000090 + iVar5));
                iVar3 = *(int64_t *)(var_30h + 0xb0);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf05e;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf066;
                fcn.18026d900(uVar6);
                if (var_28h == iVar3) {
                    return;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf077;
                fcn.180193500(var_30h);
                return;
            }
            iVar3 = *(int64_t *)(var_30h + 0xb0);
            if (iVar3 != 0) {
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf09f;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0a7;
                fcn.18026d900(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0af;
                fcn.180193500(iVar3);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0bc;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0c4;
                fcn.18026d890(uVar6);
                *(undefined8 *)(var_30h + 0xb0) = 0;
            }
            if (((uint8_t)*(undefined4 *)(var_30h + 0x100) & 9) == 9) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0ee;
                fcn.1801e84e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0fe;
                fcn.1801e8400(var_30h + 0xd8);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf10c;
            fcn.1801c0480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            if (*(int64_t *)(var_30h + 0x80) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf121;
                fcn.180193500();
            }
            if (*(int64_t *)(var_30h + 0x88) == 0) {
                return;
            }
        } else {
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee1;
            fcn.1801e3990(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef1;
            fcn.1801e8e30(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef09;
            fcn.1801e8cd0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef19;
            fcn.1801e8db0(uVar6);
            if (*(int64_t *)(var_38h + 0x78) == 0) {
                uVar6 = *(undefined8 *)(var_38h + 0x80);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef36;
                fcn.1801dd680(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef46;
                fcn.18026d840(var_38h + 0x90);
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf136;
        fcn.180193500();
        return;
    }
    uVar6 = *(undefined8 *)(var_40h + 0x78);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeac;
    fcn.1801dd680(uVar6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeb9;
    fcn.18026d840(var_40h + 0x80);
    return;
}

// ============================================================
// Function: FUN_1801bef51
// Address: 0x1801bef51
// Size: 305 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1801bee70(int64_t arg_68h)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int32_t var_20h;
    int32_t var_1ch;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bee7f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bee91;
    iVar4 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000040 + iVar5));
    if (iVar4 == 0) {
        return;
    }
    if ((int32_t)var_18h == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_RBX;
        if (var_1ch == 0) {
            uVar6 = *(undefined8 *)(var_48h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef5e;
            uVar6 = fcn.1801dd6c0(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef66;
            fcn.18026d890(uVar6);
            if (var_20h != 0) {
                *(int64_t *)(var_30h + 0xf8) = *(int64_t *)(var_30h + 0xf8) + -1;
                cVar2 = *(char *)(*(int64_t *)(var_28h + 0x80) + 0x101);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(*(int64_t *)(var_28h + 0x80) + 0x70);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befa0;
                    iVar4 = fcn.1801e6210(uVar6, 0);
                    if (iVar4 == 0) {
                        uVar6 = *(undefined8 *)(var_30h + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befbf;
                        fcn.1801e39c0(uVar6);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befcd;
                        fcn.1801e7da0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5)
                                     );
                    }
                }
                iVar3 = *(int64_t *)(var_28h + 0x80);
                cVar2 = *(char *)(iVar3 + 0x102);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(var_30h + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beff7;
                    uVar6 = fcn.1801e39c0(uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf005;
                    fcn.1801e7f00(uVar6, iVar3, 0);
                }
                puVar1 = (uint32_t *)(*(int64_t *)(var_28h + 0x80) + 0x104);
                *puVar1 = *puVar1 | 0x20;
                uVar6 = *(undefined8 *)(var_30h + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf032;
                fcn.1801e39c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf03d;
                fcn.1801e7fb0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                              *(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x00000060 + iVar5), 
                              *(int64_t *)((int64_t)&arg_68h + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                              *(int64_t *)(&stack0x00000090 + iVar5));
                iVar3 = *(int64_t *)(var_30h + 0xb0);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf05e;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf066;
                fcn.18026d900(uVar6);
                if (var_28h == iVar3) {
                    return;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf077;
                fcn.180193500(var_30h);
                return;
            }
            iVar3 = *(int64_t *)(var_30h + 0xb0);
            if (iVar3 != 0) {
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf09f;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0a7;
                fcn.18026d900(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0af;
                fcn.180193500(iVar3);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0bc;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0c4;
                fcn.18026d890(uVar6);
                *(undefined8 *)(var_30h + 0xb0) = 0;
            }
            if (((uint8_t)*(undefined4 *)(var_30h + 0x100) & 9) == 9) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0ee;
                fcn.1801e84e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0fe;
                fcn.1801e8400(var_30h + 0xd8);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf10c;
            fcn.1801c0480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            if (*(int64_t *)(var_30h + 0x80) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf121;
                fcn.180193500();
            }
            if (*(int64_t *)(var_30h + 0x88) == 0) {
                return;
            }
        } else {
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee1;
            fcn.1801e3990(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef1;
            fcn.1801e8e30(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef09;
            fcn.1801e8cd0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef19;
            fcn.1801e8db0(uVar6);
            if (*(int64_t *)(var_38h + 0x78) == 0) {
                uVar6 = *(undefined8 *)(var_38h + 0x80);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef36;
                fcn.1801dd680(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef46;
                fcn.18026d840(var_38h + 0x90);
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf136;
        fcn.180193500();
        return;
    }
    uVar6 = *(undefined8 *)(var_40h + 0x78);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeac;
    fcn.1801dd680(uVar6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeb9;
    fcn.18026d840(var_40h + 0x80);
    return;
}

// ============================================================
// Function: FUN_1801bf082
// Address: 0x1801bf082
// Size: 185 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1801bee70(int64_t arg_68h)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int32_t var_20h;
    int32_t var_1ch;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bee7f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bee91;
    iVar4 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000040 + iVar5));
    if (iVar4 == 0) {
        return;
    }
    if ((int32_t)var_18h == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_RBX;
        if (var_1ch == 0) {
            uVar6 = *(undefined8 *)(var_48h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef5e;
            uVar6 = fcn.1801dd6c0(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef66;
            fcn.18026d890(uVar6);
            if (var_20h != 0) {
                *(int64_t *)(var_30h + 0xf8) = *(int64_t *)(var_30h + 0xf8) + -1;
                cVar2 = *(char *)(*(int64_t *)(var_28h + 0x80) + 0x101);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(*(int64_t *)(var_28h + 0x80) + 0x70);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befa0;
                    iVar4 = fcn.1801e6210(uVar6, 0);
                    if (iVar4 == 0) {
                        uVar6 = *(undefined8 *)(var_30h + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befbf;
                        fcn.1801e39c0(uVar6);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befcd;
                        fcn.1801e7da0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5)
                                     );
                    }
                }
                iVar3 = *(int64_t *)(var_28h + 0x80);
                cVar2 = *(char *)(iVar3 + 0x102);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(var_30h + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beff7;
                    uVar6 = fcn.1801e39c0(uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf005;
                    fcn.1801e7f00(uVar6, iVar3, 0);
                }
                puVar1 = (uint32_t *)(*(int64_t *)(var_28h + 0x80) + 0x104);
                *puVar1 = *puVar1 | 0x20;
                uVar6 = *(undefined8 *)(var_30h + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf032;
                fcn.1801e39c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf03d;
                fcn.1801e7fb0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                              *(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x00000060 + iVar5), 
                              *(int64_t *)((int64_t)&arg_68h + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                              *(int64_t *)(&stack0x00000090 + iVar5));
                iVar3 = *(int64_t *)(var_30h + 0xb0);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf05e;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf066;
                fcn.18026d900(uVar6);
                if (var_28h == iVar3) {
                    return;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf077;
                fcn.180193500(var_30h);
                return;
            }
            iVar3 = *(int64_t *)(var_30h + 0xb0);
            if (iVar3 != 0) {
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf09f;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0a7;
                fcn.18026d900(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0af;
                fcn.180193500(iVar3);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0bc;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0c4;
                fcn.18026d890(uVar6);
                *(undefined8 *)(var_30h + 0xb0) = 0;
            }
            if (((uint8_t)*(undefined4 *)(var_30h + 0x100) & 9) == 9) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0ee;
                fcn.1801e84e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0fe;
                fcn.1801e8400(var_30h + 0xd8);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf10c;
            fcn.1801c0480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            if (*(int64_t *)(var_30h + 0x80) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf121;
                fcn.180193500();
            }
            if (*(int64_t *)(var_30h + 0x88) == 0) {
                return;
            }
        } else {
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee1;
            fcn.1801e3990(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef1;
            fcn.1801e8e30(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef09;
            fcn.1801e8cd0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef19;
            fcn.1801e8db0(uVar6);
            if (*(int64_t *)(var_38h + 0x78) == 0) {
                uVar6 = *(undefined8 *)(var_38h + 0x80);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef36;
                fcn.1801dd680(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef46;
                fcn.18026d840(var_38h + 0x90);
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf136;
        fcn.180193500();
        return;
    }
    uVar6 = *(undefined8 *)(var_40h + 0x78);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeac;
    fcn.1801dd680(uVar6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeb9;
    fcn.18026d840(var_40h + 0x80);
    return;
}

// ============================================================
// Function: FUN_1801bf13b
// Address: 0x1801bf13b
// Size: 6 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1801bee70(int64_t arg_68h)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int32_t var_20h;
    int32_t var_1ch;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801bee7f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bee91;
    iVar4 = fcn.1801bdce0(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000040 + iVar5));
    if (iVar4 == 0) {
        return;
    }
    if ((int32_t)var_18h == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = unaff_RBX;
        if (var_1ch == 0) {
            uVar6 = *(undefined8 *)(var_48h + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef5e;
            uVar6 = fcn.1801dd6c0(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef66;
            fcn.18026d890(uVar6);
            if (var_20h != 0) {
                *(int64_t *)(var_30h + 0xf8) = *(int64_t *)(var_30h + 0xf8) + -1;
                cVar2 = *(char *)(*(int64_t *)(var_28h + 0x80) + 0x101);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(*(int64_t *)(var_28h + 0x80) + 0x70);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befa0;
                    iVar4 = fcn.1801e6210(uVar6, 0);
                    if (iVar4 == 0) {
                        uVar6 = *(undefined8 *)(var_30h + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befbf;
                        fcn.1801e39c0(uVar6);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801befcd;
                        fcn.1801e7da0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5)
                                     );
                    }
                }
                iVar3 = *(int64_t *)(var_28h + 0x80);
                cVar2 = *(char *)(iVar3 + 0x102);
                if ((cVar2 == '\x01') || (cVar2 == '\x02')) {
                    uVar6 = *(undefined8 *)(var_30h + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beff7;
                    uVar6 = fcn.1801e39c0(uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf005;
                    fcn.1801e7f00(uVar6, iVar3, 0);
                }
                puVar1 = (uint32_t *)(*(int64_t *)(var_28h + 0x80) + 0x104);
                *puVar1 = *puVar1 | 0x20;
                uVar6 = *(undefined8 *)(var_30h + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf032;
                fcn.1801e39c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf03d;
                fcn.1801e7fb0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)(&stack0x00000030 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar5), *(int64_t *)(&stack0x00000050 + iVar5), 
                              *(int64_t *)(&stack0x00000058 + iVar5), *(int64_t *)(&stack0x00000060 + iVar5), 
                              *(int64_t *)((int64_t)&arg_68h + iVar5), *(int64_t *)(&stack0x00000078 + iVar5), 
                              *(int64_t *)(&stack0x00000080 + iVar5), *(int64_t *)(&stack0x00000088 + iVar5), 
                              *(int64_t *)(&stack0x00000090 + iVar5));
                iVar3 = *(int64_t *)(var_30h + 0xb0);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf05e;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf066;
                fcn.18026d900(uVar6);
                if (var_28h == iVar3) {
                    return;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf077;
                fcn.180193500(var_30h);
                return;
            }
            iVar3 = *(int64_t *)(var_30h + 0xb0);
            if (iVar3 != 0) {
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf09f;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0a7;
                fcn.18026d900(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0af;
                fcn.180193500(iVar3);
                uVar6 = *(undefined8 *)(var_48h + 0x58);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0bc;
                uVar6 = fcn.1801dd6c0(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0c4;
                fcn.18026d890(uVar6);
                *(undefined8 *)(var_30h + 0xb0) = 0;
            }
            if (((uint8_t)*(undefined4 *)(var_30h + 0x100) & 9) == 9) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0ee;
                fcn.1801e84e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf0fe;
                fcn.1801e8400(var_30h + 0xd8);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf10c;
            fcn.1801c0480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            if (*(int64_t *)(var_30h + 0x80) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf121;
                fcn.180193500();
            }
            if (*(int64_t *)(var_30h + 0x88) == 0) {
                return;
            }
        } else {
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee1;
            fcn.1801e3990(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beee9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef1;
            fcn.1801e8e30(uVar6);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beef9;
            fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef09;
            fcn.1801e8cd0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            uVar6 = *(undefined8 *)(var_38h + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef19;
            fcn.1801e8db0(uVar6);
            if (*(int64_t *)(var_38h + 0x78) == 0) {
                uVar6 = *(undefined8 *)(var_38h + 0x80);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef36;
                fcn.1801dd680(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bef46;
                fcn.18026d840(var_38h + 0x90);
                return;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801bf136;
        fcn.180193500();
        return;
    }
    uVar6 = *(undefined8 *)(var_40h + 0x78);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeac;
    fcn.1801dd680(uVar6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801beeb9;
    fcn.18026d840(var_40h + 0x80);
    return;
}

// ============================================================
// Function: FUN_1801bf150
// Address: 0x1801bf150
// Size: 54 bytes
// ============================================================
void fcn.1801bf150(int32_t *param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    LOCK();
    iVar1 = *param_1;
    *param_1 = *param_1 + -1;
    UNLOCK();
    if (1 < iVar1) {
        return;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != (int32_t *)0x0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801bf190
// Address: 0x1801bf190
// Size: 96 bytes
// ============================================================
void fcn.1801bf190(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801bf1a0;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 8);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf1be;
            fcn.18026d840(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf1cd;
            fcn.180228c50(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf1d5;
            fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801bf1ea;
            fcn.180224990(arg1, 0x1804b0248, 0x12dc);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801bf1f0
// Address: 0x1801bf1f0
// Size: 39 bytes
// ============================================================
int64_t fcn.1801bf1f0(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801bf1fa;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x1801bf202;
    iVar1 = fcn.1801c5160(*(int64_t *)(&stack0x00000030 + -iVar1));
    if ((*(uint32_t *)(iVar1 + 0x40) & 0x40000) == 0) {
        iVar1 = 0;
    }
    return iVar1;
}

