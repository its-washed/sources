// Chunk 186 - 50 functions

// ============================================================
// Function: FUN_18024a9ea
// Address: 0x18024a9ea
// Size: 218 bytes
// ============================================================
undefined8 fcn.18024a9ea(int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t *piVar3;
    
    func_0x000180222fa0();
    uVar2 = func_0x00018001ed90(0x18077e6f0);
    func_0x000180222a00(0x18077e6f0, &arg_30h);
    func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
    func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
    iVar1 = func_0x000180222010(uVar2);
    while (0 < iVar1) {
        piVar3 = (int64_t *)func_0x000180222020(uVar2);
        if (piVar3 != (int64_t *)0x0) {
            if (*(code **)(*piVar3 + 0x18) != (code *)0x0) {
                (**(code **)(*piVar3 + 0x18))(piVar3);
            }
            *(int32_t *)(*piVar3 + 0x20) = *(int32_t *)(*piVar3 + 0x20) + -1;
            func_0x000180224990(piVar3[1], 0x1804e4740, 0x26a);
            func_0x000180224990(piVar3[2], 0x1804e4740, 0x26b);
            func_0x000180224990(piVar3, 0x1804e4740, 0x26c);
        }
        iVar1 = func_0x000180222010(uVar2);
    }
    func_0x000180221d50(uVar2);
    return 1;
}

// ============================================================
// Function: FUN_18024aac4
// Address: 0x18024aac4
// Size: 8 bytes
// ============================================================
undefined8 fcn.18024aac4(void)
{
    return 0;
}

// ============================================================
// Function: FUN_18024aad0
// Address: 0x18024aad0
// Size: 114 bytes
// ============================================================
void fcn.18024aad0(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18024aada;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18024aae9;
    *(int64_t *)0x18077e6e0 =
         fcn.180222b70(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                       *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1));
    if (*(int64_t *)0x18077e6e0 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18024aafa;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18024ab12;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18024ab24;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        *(undefined4 *)0x18077e6f8 = 0;
        return;
    }
    *(undefined4 *)0x18077e6f8 = 1;
    return;
}

// ============================================================
// Function: FUN_18024ab50
// Address: 0x18024ab50
// Size: 38 bytes
// ============================================================
void fcn.18024ab50(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18024ab5a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18024ab62;
    fcn.1802c8c30();
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18024ab67;
    fcn.1802c9970(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1));
    *(undefined4 *)0x18077e6fc = 1;
    return;
}

// ============================================================
// Function: FUN_18024ab80
// Address: 0x18024ab80
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.18024ab80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024ab99;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    puVar7 = (undefined8 *)0x0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abbd;
    iVar2 = fcn.180222870(*(int64_t *)((int64_t)&var_8h + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e6f8;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abe7;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abf3;
        iVar5 = func_0x00018001ed90(0x18077e6e8);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac00;
            iVar6 = func_0x000180221f20();
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac0a;
            iVar6 = func_0x000180221950(iVar5);
        }
        *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac2f;
            puVar7 = (undefined8 *)func_0x000180224d60(0x30, 0x1804e4740, 0x168);
            if (puVar7 != (undefined8 *)0x0) {
                *puVar7 = in_RCX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac4f;
                iVar6 = func_0x0001802231e0(in_RDX, 0x1804e4740, 0x16c);
                puVar7[1] = iVar6;
                puVar7[2] = in_R8;
                puVar7[3] = in_R9;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac6d;
                    iVar3 = func_0x000180222110(*(undefined8 *)((int64_t)&var_8h + iVar4), puVar7);
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac82;
                        func_0x000180222a00(0x18077e6e8, (int64_t)&var_8h + iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac8e;
                        func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac9a;
                        func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024aca2;
                        func_0x000180221d50(iVar5);
                        return puVar7;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024acb3;
        func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        if (puVar7 != (undefined8 *)0x0) {
            uVar1 = puVar7[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024acce;
            func_0x000180224990(uVar1, 0x1804e4740, 0x17f);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ace3;
            func_0x000180224990(puVar7, 0x1804e4740, 0x180);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024aced;
        func_0x000180221d50(*(undefined8 *)((int64_t)&var_8h + iVar4));
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18024abdd
// Address: 0x18024abdd
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.18024ab80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024ab99;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    puVar7 = (undefined8 *)0x0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abbd;
    iVar2 = fcn.180222870(*(int64_t *)((int64_t)&var_8h + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e6f8;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abe7;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abf3;
        iVar5 = func_0x00018001ed90(0x18077e6e8);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac00;
            iVar6 = func_0x000180221f20();
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac0a;
            iVar6 = func_0x000180221950(iVar5);
        }
        *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac2f;
            puVar7 = (undefined8 *)func_0x000180224d60(0x30, 0x1804e4740, 0x168);
            if (puVar7 != (undefined8 *)0x0) {
                *puVar7 = in_RCX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac4f;
                iVar6 = func_0x0001802231e0(in_RDX, 0x1804e4740, 0x16c);
                puVar7[1] = iVar6;
                puVar7[2] = in_R8;
                puVar7[3] = in_R9;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac6d;
                    iVar3 = func_0x000180222110(*(undefined8 *)((int64_t)&var_8h + iVar4), puVar7);
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac82;
                        func_0x000180222a00(0x18077e6e8, (int64_t)&var_8h + iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac8e;
                        func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac9a;
                        func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024aca2;
                        func_0x000180221d50(iVar5);
                        return puVar7;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024acb3;
        func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        if (puVar7 != (undefined8 *)0x0) {
            uVar1 = puVar7[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024acce;
            func_0x000180224990(uVar1, 0x1804e4740, 0x17f);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ace3;
            func_0x000180224990(puVar7, 0x1804e4740, 0x180);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024aced;
        func_0x000180221d50(*(undefined8 *)((int64_t)&var_8h + iVar4));
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18024acf4
// Address: 0x18024acf4
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.18024ab80(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024ab99;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    puVar7 = (undefined8 *)0x0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abbd;
    iVar2 = fcn.180222870(*(int64_t *)((int64_t)&var_8h + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e6f8;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abe7;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024abf3;
        iVar5 = func_0x00018001ed90(0x18077e6e8);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac00;
            iVar6 = func_0x000180221f20();
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac0a;
            iVar6 = func_0x000180221950(iVar5);
        }
        *(int64_t *)((int64_t)&var_8h + iVar4) = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac2f;
            puVar7 = (undefined8 *)func_0x000180224d60(0x30, 0x1804e4740, 0x168);
            if (puVar7 != (undefined8 *)0x0) {
                *puVar7 = in_RCX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac4f;
                iVar6 = func_0x0001802231e0(in_RDX, 0x1804e4740, 0x16c);
                puVar7[1] = iVar6;
                puVar7[2] = in_R8;
                puVar7[3] = in_R9;
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac6d;
                    iVar3 = func_0x000180222110(*(undefined8 *)((int64_t)&var_8h + iVar4), puVar7);
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac82;
                        func_0x000180222a00(0x18077e6e8, (int64_t)&var_8h + iVar4);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac8e;
                        func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ac9a;
                        func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024aca2;
                        func_0x000180221d50(iVar5);
                        return puVar7;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024acb3;
        func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        if (puVar7 != (undefined8 *)0x0) {
            uVar1 = puVar7[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024acce;
            func_0x000180224990(uVar1, 0x1804e4740, 0x17f);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024ace3;
            func_0x000180224990(puVar7, 0x1804e4740, 0x180);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18024aced;
        func_0x000180221d50(*(undefined8 *)((int64_t)&var_8h + iVar4));
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18024ad10
// Address: 0x18024ad10
// Size: 74 bytes
// ============================================================
void fcn.18024ad10(undefined8 *param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024ad1c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024ad2a;
    fcn.1802c9510(uVar6);
    uVar6 = param_1[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024ad40;
    fcn.180224990(uVar6, 0x1804e4740, 0x23a);
    uVar6 = *(undefined8 *)((int64_t)auStackX_18 + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18022499a;
    iVar3 = fcn.18045a350(param_1, 0x1804e4740, 0x23b);
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != (undefined8 *)0x0) {
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar4) = uVar6;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_18024ad60
// Address: 0x18024ad60
// Size: 596 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.18024ad60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024ad82;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar2 = 1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024adb2;
    piVar6 = (int64_t *)func_0x0001802248d0(0x28, 0x1804e4740, 0x1ba);
    iVar9 = 0;
    if (piVar6 != (int64_t *)0x0) {
        *piVar6 = in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024add6;
        iVar7 = func_0x0001802231e0(in_RDX, 0x1804e4740, 0x1bf);
        piVar6[1] = iVar7;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024adef;
        iVar7 = func_0x0001802231e0(in_R8, 0x1804e4740, 0x1c0);
        piVar6[2] = iVar7;
        piVar6[4] = 0;
        if ((piVar6[1] == 0) || (iVar7 == 0)) goto code_r0x00018024aedb;
        pcVar1 = *(code **)(in_RCX + 0x10);
        iVar4 = 0;
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024ae1b;
            iVar2 = (*pcVar1)(piVar6, in_R9);
            iVar9 = 1;
            iVar4 = 1;
            if (iVar2 < 1) goto code_r0x00018024aec3;
        }
        iVar9 = iVar4;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024ae3e;
        iVar3 = fcn.180222870(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5));
        iVar4 = 0;
        if (iVar3 != 0) {
            iVar4 = *(int32_t *)0x18077e6f8;
        }
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024ae57;
            func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024ae63;
            iVar7 = func_0x00018001ed90(0x18077e6f0);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024ae70;
                iVar8 = func_0x000180221f20();
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024ae7a;
                iVar8 = func_0x000180221950(iVar7);
            }
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = iVar8;
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024ae94;
                func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024ae99;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024af49;
                iVar4 = func_0x000180222110(iVar8, piVar6);
                if (iVar4 != 0) {
                    *(int32_t *)(in_RCX + 0x20) = *(int32_t *)(in_RCX + 0x20) + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024af8d;
                    func_0x000180222a00(0x18077e6f0, &stack0xfffffffffffffff8 + iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024af99;
                    func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024afa5;
                    func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024afad;
                    fcn.180221d50(iVar7);
                    return iVar2;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024af59;
                func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024af63;
                fcn.180221d50(*(undefined8 *)(&stack0xfffffffffffffff8 + iVar5));
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024af68;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024aeb1;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                          *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024aec3;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar5));
        }
    }
code_r0x00018024aec3:
    pcVar1 = *(code **)(in_RCX + 0x18);
    if ((pcVar1 != (code *)0x0) && (iVar9 != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024aed6;
        (*pcVar1)(piVar6);
    }
    if (piVar6 == (int64_t *)0x0) {
        return -1;
    }
code_r0x00018024aedb:
    iVar7 = piVar6[1];
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024aef1;
    fcn.180224990(iVar7, 0x1804e4740, 0x1f8);
    iVar7 = piVar6[2];
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024af07;
    fcn.180224990(iVar7, 0x1804e4740, 0x1f9);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024af1c;
    fcn.180224990(piVar6, 0x1804e4740, 0x1fa);
    return -1;
}

// ============================================================
// Function: FUN_18024afc0
// Address: 0x18024afc0
// Size: 697 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.18024afc0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024afe2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b004;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e6fc;
    }
    if (iVar3 == 0) {
        return -1;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b027;
    iVar5 = func_0x00018045b9a8(in_RDX, 0x2e);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b03c;
        iVar5 = func_0x000180498cd0(in_RDX);
    } else {
        iVar5 = iVar5 - in_RDX;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b052;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e6f8;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b06d;
        iVar3 = func_0x000180222d20(*(undefined8 *)0x18077e6e0);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b07d;
            uVar6 = func_0x00018001ed90(0x18077e6e8);
            iVar2 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b08a;
            iVar3 = func_0x000180222010(uVar6);
            if (0 < iVar3) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b09a;
                    iVar7 = func_0x000180222340(uVar6, iVar2);
                    uVar1 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b0ac;
                    iVar3 = func_0x000180498f90(uVar1, in_RDX, iVar5);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b122;
                        func_0x000180222ef0(*(undefined8 *)0x18077e6e0);
                        if (iVar7 == 0) goto code_r0x00018024b0cc;
                        goto code_r0x00018024b127;
                    }
                    iVar2 = iVar2 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b0ba;
                    iVar3 = func_0x000180222010(uVar6);
                } while (iVar2 < iVar3);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b0ca;
            func_0x000180222ef0(*(undefined8 *)0x18077e6e0);
        }
    }
    iVar7 = 0;
code_r0x00018024b0cc:
    if ((in_R9 & 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b0ea;
        iVar5 = func_0x0001802c8e50(in_RCX, in_R8, 0x1804d84c0);
        if (iVar5 == 0) {
            iVar5 = in_RDX;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b104;
        iVar8 = func_0x0001802c9690(0, iVar5, 0, 0);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b199;
            iVar7 = func_0x0001802c92b0(iVar8, 0x1804e47f0);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b1b7;
                func_0x0001802c92b0(iVar8, 0x1804e4800);
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b1c8;
                iVar7 = fcn.18024ab80(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4));
                if (iVar7 != 0) goto code_r0x00018024b212;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b1d8;
        fcn.1802c9510(iVar8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b1dd;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b1f5;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4));
        *(int64_t *)(&stack0xfffffffffffffff8 + iVar4) = iVar5;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b210;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
        iVar7 = 0;
    }
code_r0x00018024b212:
    if (iVar7 == 0) {
        if ((in_R9 & 4) == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b226;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b23e;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b257;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
        }
        return -1;
    }
code_r0x00018024b127:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b138;
    iVar3 = fcn.18024ad60(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4));
    if (0 < iVar3) {
        return iVar3;
    }
    if ((in_R9 & 4) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b149;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b161;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4));
        *(int32_t *)(&stack0x00000000 + iVar4) = iVar3;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = in_R8;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18024b183;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar4));
        return iVar3;
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18024b280
// Address: 0x18024b280
// Size: 38 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b2a6
// Address: 0x18024b2a6
// Size: 60 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b2e2
// Address: 0x18024b2e2
// Size: 5 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b2e7
// Address: 0x18024b2e7
// Size: 30 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b305
// Address: 0x18024b305
// Size: 59 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b340
// Address: 0x18024b340
// Size: 19 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b353
// Address: 0x18024b353
// Size: 99 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b3b6
// Address: 0x18024b3b6
// Size: 5 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b3bb
// Address: 0x18024b3bb
// Size: 64 bytes
// ============================================================
void fcn.18024b280(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b28c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b294;
    iVar1 = func_0x00018024a9a0();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2b0;
        func_0x000180222fa0(*(undefined8 *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2bc;
        uVar3 = func_0x00018001ed90(0x18077e6e8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2c7;
        iVar4 = func_0x000180221950(uVar3);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar4;
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2dd;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RSI;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2f1;
            uVar5 = func_0x000180221f20();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b2fe;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            iVar1 = iVar1 + -1;
            if (-1 < iVar1) {
                *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b31c;
                    uVar6 = func_0x000180222340(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b32b;
                    func_0x000180221890(*(undefined8 *)((int64_t)&arg_38h + iVar2), iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b336;
                    func_0x000180222110(uVar5, uVar6);
                    iVar1 = iVar1 + -1;
                } while (-1 < iVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b34a;
            iVar1 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_38h + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b35d;
                fcn.180221d50(*(undefined8 *)((int64_t)&arg_38h + iVar2));
                *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b373;
            func_0x000180222a00(0x18077e6e8, (int64_t)&arg_38h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b37f;
            func_0x000180222fc0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b38b;
            func_0x000180222fe0(*(undefined8 *)0x18077e6e0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b393;
            fcn.180221d50(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3a2;
            uVar3 = func_0x000180222290(uVar5, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3b1;
            func_0x000180222050(uVar3, fcn.18024ad10);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3c7;
    func_0x000180222ae0(*(undefined8 *)0x18077e6e0);
    *(undefined8 *)0x18077e6e0 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3da;
    fcn.180221d50(*(undefined8 *)0x18077e6e8);
    *(undefined8 *)0x18077e6e8 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b3ed;
    fcn.180221d50(*(undefined8 *)0x18077e6f0);
    *(undefined8 *)0x18077e6f0 = 0;
    return;
}

// ============================================================
// Function: FUN_18024b400
// Address: 0x18024b400
// Size: 89 bytes
// ============================================================
undefined8 fcn.18024b400(int64_t *param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b40c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_1 != (int64_t *)0x0) && (*param_1 != 0)) {
        uVar1 = *(undefined8 *)(*param_1 + 0x250);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024b42c;
        (*(code *)0x69a19e)(uVar1);
        iVar2 = *param_1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024b434;
        fcn.180460d90(iVar2);
        *param_1 = 0;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024b44b;
    puVar4 = (undefined4 *)fcn.18046b77c();
    *puVar4 = 0x16;
    return 0;
}

// ============================================================
// Function: FUN_18024b460
// Address: 0x18024b460
// Size: 1039 bytes
// ============================================================
void fcn.18024b460(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined4 *puVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int16_t iVar4;
    undefined4 uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    int64_t *in_RCX;
    int64_t iVar14;
    uint64_t in_RDX;
    uint64_t *puVar15;
    undefined8 unaff_RBX;
    undefined *puVar16;
    undefined *puVar17;
    undefined *puVar18;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar19;
    undefined (*pauVar20) [16];
    uint64_t uVar21;
    undefined auVar22 [16];
    undefined auVar28 [16];
    undefined auVar29 [16];
    undefined auVar37 [16];
    undefined auVar41 [16];
    undefined auVar49 [16];
    undefined auVar50 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    undefined auVar23 [16];
    undefined auVar24 [16];
    undefined auVar25 [16];
    undefined auVar26 [16];
    undefined auVar27 [16];
    undefined auVar30 [16];
    undefined auVar31 [16];
    undefined auVar32 [16];
    undefined auVar33 [16];
    undefined auVar34 [16];
    undefined auVar35 [16];
    undefined auVar36 [16];
    undefined uVar38;
    undefined uVar39;
    undefined uVar40;
    undefined auVar42 [16];
    undefined auVar43 [16];
    undefined auVar44 [16];
    undefined auVar45 [16];
    undefined auVar46 [16];
    undefined auVar47 [16];
    undefined auVar48 [16];
    undefined auVar51 [16];
    undefined auVar52 [16];
    undefined auVar53 [16];
    undefined auVar54 [16];
    undefined auVar55 [16];
    undefined auVar56 [16];
    undefined auVar57 [16];
    
    uStack_30 = 0x18024b474;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar16 = &stack0xffffffffffffffd8 + iVar8;
    puVar18 = &stack0xffffffffffffffd8 + iVar8;
    puVar1 = (undefined4 *)((int64_t)&var_18h + iVar8);
    *(undefined8 *)((int64_t)&arg_58h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_68h + iVar8) = unaff_RDI;
    *(uint64_t *)((int64_t)&var_20h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)puVar1;
    puVar17 = &stack0xffffffffffffffd8 + iVar8;
    if ((in_RCX != (int64_t *)0x0) && (puVar17 = &stack0xffffffffffffffd8 + iVar8, in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b4b3;
        puVar9 = (undefined4 *)fcn.18046b77c();
        uVar19 = 0;
        *puVar9 = 0;
        iVar11 = *in_RCX;
        if (iVar11 != 0) {
            uVar13 = *(undefined8 *)(iVar11 + 0x250);
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b7d8;
            iVar7 = (*(code *)0x69a1bc)(uVar13, iVar11);
            if (iVar7 == 0) goto code_r0x00018024b764;
code_r0x00018024b7dc:
            iVar14 = *in_RCX;
            iVar4 = *(int16_t *)(iVar14 + 0x2c);
            iVar11 = iVar14 + 0x2c;
            uVar10 = uVar19;
            while ((iVar4 != 0 && (uVar10 < 0xff))) {
                uVar10 = uVar10 + 1;
                iVar4 = *(int16_t *)(iVar11 + uVar10 * 2);
            }
            *(undefined8 *)(puVar16 + 0x38) = 0;
            *(undefined8 *)(puVar16 + 0x30) = 0;
            uVar10 = uVar10 + 1;
            *(undefined4 *)(puVar16 + 0x28) = 0x100;
            *(int64_t *)(puVar16 + 0x20) = iVar14 + 600;
            *(undefined8 *)(puVar16 + -8) = 0x18024b836;
            iVar7 = (*(code *)0x699eb4)(0xfde9, 0, iVar11, uVar10 & 0xffffffff);
            if ((iVar7 == 0) && (uVar10 != 0)) {
                do {
                    *(undefined *)(*in_RCX + 600 + uVar19) = *(undefined *)(iVar11 + uVar19 * 2);
                    uVar19 = uVar19 + 1;
                } while (uVar19 < uVar10);
            }
            *(undefined *)(*in_RCX + 0x357) = 0;
            puVar18 = puVar16;
            goto code_r0x00018024b764;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b4cb;
        uVar10 = func_0x000180498cd0(in_RDX);
        if ((uVar10 == 0) || (0x7ffffffc < uVar10)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b7c0;
            puVar9 = (undefined4 *)fcn.18046b77c();
            *puVar9 = 2;
            puVar18 = &stack0xffffffffffffffd8 + iVar8;
            goto code_r0x00018024b764;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b4ed;
        iVar11 = func_0x00018046d050(0x358);
        *in_RCX = iVar11;
        if (iVar11 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b4fa;
            puVar9 = (undefined4 *)fcn.18046b77c();
            *puVar9 = 0xc;
            puVar18 = &stack0xffffffffffffffd8 + iVar8;
            goto code_r0x00018024b764;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b515;
        func_0x0001804986e0(iVar11, 0, 0x358);
        uVar2 = uVar10 + 1;
        *(undefined4 *)(&stack0x00000000 + iVar8) = 0;
        *puVar1 = 0xfde9;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b53d;
        uVar6 = (*(code *)0x699e90)(0xfde9, 0, in_RDX, uVar2 & 0xffffffff);
        if ((int32_t)uVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b54e;
            iVar7 = (*(code *)0x699ff6)();
            if (iVar7 == 0x459) {
                *(undefined4 *)(&stack0x00000000 + iVar8) = 0;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b56e;
                uVar6 = (*(code *)0x699e90)(0, 0, in_RDX, uVar2 & 0xffffffff);
                *puVar1 = 0;
                if (0 < (int32_t)uVar6) goto code_r0x00018024b6fb;
            }
            uVar6 = (uint32_t)uVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b5a5;
            iVar11 = fcn.18045a350();
            iVar11 = -iVar11;
            uVar21 = (int64_t)&var_18h + iVar11 + iVar8;
            puVar16 = &stack0xffffffffffffffd8 + iVar11 + iVar8;
            if (uVar2 != 0) {
                uVar12 = uVar19;
                if ((3 < uVar2) && ((uVar10 + in_RDX < uVar21 || (uVar21 + uVar10 * 2 < in_RDX)))) {
                    if (uVar2 < 0x20) {
code_r0x00018024b667:
                        do {
                            uVar5 = *(undefined4 *)(in_RDX + uVar12);
                            uVar40 = (undefined)((uint32_t)uVar5 >> 0x18);
                            uVar39 = (undefined)((uint32_t)uVar5 >> 0x10);
                            uVar38 = (undefined)((uint32_t)uVar5 >> 8);
                            auVar37._4_4_ =
                                 (int32_t)(CONCAT35(CONCAT21(CONCAT11(uVar40, uVar40), uVar39), CONCAT14(uVar39, uVar5))
                                          >> 0x20);
                            auVar37[3] = uVar38;
                            auVar37[2] = uVar38;
                            auVar37[0] = (undefined)uVar5;
                            auVar37[1] = auVar37[0];
                            auVar37._8_8_ = 0;
                            auVar28 = psraw(auVar37, 8);
                            *(int64_t *)(uVar21 + uVar12 * 2) = auVar28._0_8_;
                            uVar12 = uVar12 + 4;
                        } while (uVar12 < (uVar2 & 0xfffffffffffffffc));
                    } else {
                        puVar15 = (uint64_t *)(in_RDX + 0x10);
                        pauVar20 = (undefined (*) [16])(&stack0x00000038 + iVar11 + iVar8);
                        do {
                            uVar10 = puVar15[-2];
                            uVar3 = puVar15[-1];
                            uVar38 = (undefined)(uVar10 >> 0x38);
                            auVar27._8_6_ = 0;
                            auVar27._0_8_ = uVar10;
                            auVar27[14] = uVar38;
                            auVar27[15] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x30);
                            auVar26._14_2_ = auVar27._14_2_;
                            auVar26._8_5_ = 0;
                            auVar26._0_8_ = uVar10;
                            auVar26[13] = uVar38;
                            auVar25._13_3_ = auVar26._13_3_;
                            auVar25._8_4_ = 0;
                            auVar25._0_8_ = uVar10;
                            auVar25[12] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x28);
                            auVar24._12_4_ = auVar25._12_4_;
                            auVar24._8_3_ = 0;
                            auVar24._0_8_ = uVar10;
                            auVar24[11] = uVar38;
                            auVar23._11_5_ = auVar24._11_5_;
                            auVar23._8_2_ = 0;
                            auVar23._0_8_ = uVar10;
                            auVar23[10] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x20);
                            auVar22._10_6_ = auVar23._10_6_;
                            auVar22[8] = 0;
                            auVar22._0_8_ = uVar10;
                            auVar22[9] = uVar38;
                            auVar28._9_7_ = auVar22._9_7_;
                            auVar28[8] = uVar38;
                            auVar28._0_8_ = uVar10;
                            uVar38 = (undefined)(uVar10 >> 0x18);
                            auVar49._8_8_ = auVar28._8_8_;
                            auVar49[7] = uVar38;
                            auVar49[6] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x10);
                            auVar49[5] = uVar38;
                            auVar49[4] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 8);
                            auVar49[3] = uVar38;
                            auVar49[2] = uVar38;
                            auVar49[0] = (undefined)uVar10;
                            auVar49[1] = auVar49[0];
                            uVar12 = uVar12 + 0x20;
                            uVar38 = (undefined)(uVar3 >> 0x38);
                            auVar48._8_6_ = 0;
                            auVar48._0_8_ = uVar3;
                            auVar48[14] = uVar38;
                            auVar48[15] = uVar38;
                            uVar38 = (undefined)(uVar3 >> 0x30);
                            auVar47._14_2_ = auVar48._14_2_;
                            auVar47._8_5_ = 0;
                            auVar47._0_8_ = uVar3;
                            auVar47[13] = uVar38;
                            auVar46._13_3_ = auVar47._13_3_;
                            auVar46._8_4_ = 0;
                            auVar46._0_8_ = uVar3;
                            auVar46[12] = uVar38;
                            uVar38 = (undefined)(uVar3 >> 0x28);
                            auVar45._12_4_ = auVar46._12_4_;
                            auVar45._8_3_ = 0;
                            auVar45._0_8_ = uVar3;
                            auVar45[11] = uVar38;
                            auVar44._11_5_ = auVar45._11_5_;
                            auVar44._8_2_ = 0;
                            auVar44._0_8_ = uVar3;
                            auVar44[10] = uVar38;
                            uVar38 = (undefined)(uVar3 >> 0x20);
                            auVar43._10_6_ = auVar44._10_6_;
                            auVar43[8] = 0;
                            auVar43._0_8_ = uVar3;
                            auVar43[9] = uVar38;
                            auVar42._9_7_ = auVar43._9_7_;
                            auVar42[8] = uVar38;
                            auVar42._0_8_ = uVar3;
                            uVar38 = (undefined)(uVar3 >> 0x18);
                            auVar41._8_8_ = auVar42._8_8_;
                            auVar41[7] = uVar38;
                            auVar41[6] = uVar38;
                            uVar38 = (undefined)(uVar3 >> 0x10);
                            auVar41[5] = uVar38;
                            auVar41[4] = uVar38;
                            uVar38 = (undefined)(uVar3 >> 8);
                            auVar41[3] = uVar38;
                            auVar41[2] = uVar38;
                            auVar41[0] = (undefined)uVar3;
                            auVar41[1] = auVar41[0];
                            auVar28 = psraw(auVar49, 8);
                            auVar49 = psraw(auVar41, 8);
                            pauVar20[-2] = auVar28;
                            uVar10 = *puVar15;
                            uVar38 = (undefined)(uVar10 >> 0x38);
                            auVar36._8_6_ = 0;
                            auVar36._0_8_ = uVar10;
                            auVar36[14] = uVar38;
                            auVar36[15] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x30);
                            auVar35._14_2_ = auVar36._14_2_;
                            auVar35._8_5_ = 0;
                            auVar35._0_8_ = uVar10;
                            auVar35[13] = uVar38;
                            auVar34._13_3_ = auVar35._13_3_;
                            auVar34._8_4_ = 0;
                            auVar34._0_8_ = uVar10;
                            auVar34[12] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x28);
                            auVar33._12_4_ = auVar34._12_4_;
                            auVar33._8_3_ = 0;
                            auVar33._0_8_ = uVar10;
                            auVar33[11] = uVar38;
                            auVar32._11_5_ = auVar33._11_5_;
                            auVar32._8_2_ = 0;
                            auVar32._0_8_ = uVar10;
                            auVar32[10] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x20);
                            auVar31._10_6_ = auVar32._10_6_;
                            auVar31[8] = 0;
                            auVar31._0_8_ = uVar10;
                            auVar31[9] = uVar38;
                            auVar30._9_7_ = auVar31._9_7_;
                            auVar30[8] = uVar38;
                            auVar30._0_8_ = uVar10;
                            uVar38 = (undefined)(uVar10 >> 0x18);
                            auVar29._8_8_ = auVar30._8_8_;
                            auVar29[7] = uVar38;
                            auVar29[6] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x10);
                            auVar29[5] = uVar38;
                            auVar29[4] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 8);
                            auVar29[3] = uVar38;
                            auVar29[2] = uVar38;
                            auVar29[0] = (undefined)uVar10;
                            auVar29[1] = auVar29[0];
                            auVar28 = psraw(auVar29, 8);
                            pauVar20[-1] = auVar49;
                            uVar10 = puVar15[1];
                            uVar38 = (undefined)(uVar10 >> 0x38);
                            auVar57._8_6_ = 0;
                            auVar57._0_8_ = uVar10;
                            auVar57[14] = uVar38;
                            auVar57[15] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x30);
                            auVar56._14_2_ = auVar57._14_2_;
                            auVar56._8_5_ = 0;
                            auVar56._0_8_ = uVar10;
                            auVar56[13] = uVar38;
                            auVar55._13_3_ = auVar56._13_3_;
                            auVar55._8_4_ = 0;
                            auVar55._0_8_ = uVar10;
                            auVar55[12] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x28);
                            auVar54._12_4_ = auVar55._12_4_;
                            auVar54._8_3_ = 0;
                            auVar54._0_8_ = uVar10;
                            auVar54[11] = uVar38;
                            auVar53._11_5_ = auVar54._11_5_;
                            auVar53._8_2_ = 0;
                            auVar53._0_8_ = uVar10;
                            auVar53[10] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x20);
                            auVar52._10_6_ = auVar53._10_6_;
                            auVar52[8] = 0;
                            auVar52._0_8_ = uVar10;
                            auVar52[9] = uVar38;
                            auVar51._9_7_ = auVar52._9_7_;
                            auVar51[8] = uVar38;
                            auVar51._0_8_ = uVar10;
                            uVar38 = (undefined)(uVar10 >> 0x18);
                            auVar50._8_8_ = auVar51._8_8_;
                            auVar50[7] = uVar38;
                            auVar50[6] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 0x10);
                            auVar50[5] = uVar38;
                            auVar50[4] = uVar38;
                            uVar38 = (undefined)(uVar10 >> 8);
                            auVar50[3] = uVar38;
                            auVar50[2] = uVar38;
                            auVar50[0] = (undefined)uVar10;
                            auVar50[1] = auVar50[0];
                            auVar49 = psraw(auVar50, 8);
                            *pauVar20 = auVar28;
                            pauVar20[1] = auVar49;
                            puVar15 = puVar15 + 4;
                            pauVar20 = pauVar20 + 4;
                        } while (uVar12 < uVar2 - (uVar6 & 0x1f));
                        if (3 < (uint64_t)(uVar6 & 0x1f)) goto code_r0x00018024b667;
                    }
                    puVar16 = &stack0xffffffffffffffd8 + iVar11 + iVar8;
                    if (uVar2 <= uVar12) goto code_r0x00018024b6b1;
                }
                do {
                    *(int16_t *)(uVar21 + uVar12 * 2) = (int16_t)*(char *)(in_RDX + uVar12);
                    uVar12 = uVar12 + 1;
                    puVar16 = &stack0xffffffffffffffd8 + iVar11 + iVar8;
                } while (uVar12 < uVar2);
            }
code_r0x00018024b6b1:
            iVar4 = *(int16_t *)(uVar21 + (int64_t)(int32_t)(uVar6 - 2) * 2);
            if (iVar4 != 0x2a) {
                if ((iVar4 == 0x2f) || (iVar4 == 0x5c)) {
                    *(undefined4 *)((uVar21 - 2) + (int64_t)(int32_t)uVar6 * 2) = 0x2a;
                } else {
                    iVar11 = uVar21 + (int64_t)(int32_t)uVar6 * 2;
                    *(undefined4 *)(iVar11 + -2) = 0x2a002f;
                    *(undefined2 *)(iVar11 + 2) = 0;
                }
            }
            iVar11 = *in_RCX;
            *(undefined8 *)(puVar16 + -8) = 0x18024b7a5;
            uVar13 = (*(code *)0x69a1aa)(uVar21, iVar11);
            *(undefined8 *)(iVar11 + 0x250) = uVar13;
            iVar14 = *in_RCX;
            if (*(int64_t *)(iVar14 + 0x250) != -1) goto code_r0x00018024b7dc;
        } else {
code_r0x00018024b6fb:
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18024b721;
            iVar11 = fcn.18045a350();
            uVar5 = *puVar1;
            iVar11 = -iVar11;
            puVar16 = &stack0xffffffffffffffd8 + iVar11 + iVar8;
            uVar21 = (int64_t)&var_18h + iVar11 + iVar8;
            *(uint32_t *)(&stack0x00000000 + iVar11 + iVar8) = uVar6;
            *(uint64_t *)(&stack0xfffffffffffffff8 + iVar11 + iVar8) = uVar21;
            *(undefined8 *)((int64_t)&uStack_30 + iVar11 + iVar8) = 0x18024b744;
            iVar7 = (*(code *)0x699e90)(uVar5, 0, in_RDX, uVar2 & 0xffffffff);
            if (iVar7 != 0) goto code_r0x00018024b6b1;
            iVar14 = *in_RCX;
            puVar16 = &stack0xffffffffffffffd8 + iVar11 + iVar8;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18024b754;
        fcn.180460d90(iVar14);
        *in_RCX = 0;
        puVar17 = puVar16;
    }
    *(undefined8 *)(puVar17 + -8) = 0x18024b75c;
    puVar9 = (undefined4 *)fcn.18046b77c();
    *puVar9 = 0x16;
    puVar18 = puVar17;
code_r0x00018024b764:
    uVar19 = *(uint64_t *)((int64_t)&var_20h + iVar8);
    *(undefined8 *)(puVar18 + -8) = 0x18024b770;
    func_0x000180459870(uVar19 ^ (uint64_t)puVar1);
    return;
}

// ============================================================
// Function: FUN_18024b870
// Address: 0x18024b870
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18024b870(int64_t arg_28h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024b880;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x90);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024b896;
        (*pcVar1)();
        *(undefined8 *)(in_RCX + 0x90) = 0;
    }
    if (*(int64_t *)(in_RCX + 0x28) != 0) {
        if (*(int64_t *)(in_RCX + 0xe0) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024b8b4;
            func_0x000180233bc0();
        }
        *(undefined8 *)(in_RCX + 0x28) = 0;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0xa8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024b8c4;
    func_0x0001802c9ee0(uVar2);
    uVar2 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)(in_RCX + 0xa8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024b8d7;
    func_0x000180238640(uVar2);
    *(undefined8 *)(in_RCX + 0xa0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024b8f2;
    func_0x000180223fb0(5, in_RCX, in_RCX + 0xe8);
    *(undefined (*) [16])(in_RCX + 0xe8) = ZEXT816(0);
    return;
}

// ============================================================
// Function: FUN_18024b910
// Address: 0x18024b910
// Size: 79 bytes
// ============================================================
void fcn.18024b910(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18024b920;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b92b;
        fcn.18024b870(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        uVar1 = *(undefined8 *)(arg1 + 0x118);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b944;
        fcn.180224990(uVar1, 0x1804e48c8, 0xa8d);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024b959;
        fcn.180224990(arg1, 0x1804e48c8, 0xa8e);
    }
    return;
}

// ============================================================
// Function: FUN_18024b970
// Address: 0x18024b970
// Size: 41 bytes
// ============================================================
int64_t fcn.18024b970(int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int32_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*(int64_t *)(in_RCX + 0xa0) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x18023806c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar5) = 0x180238074;
    iVar3 = fcn.180221950(*(int64_t *)(&stack0x00000040 + iVar2 + iVar5));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_50h + iVar2 + iVar5) = unaff_RBX;
        iVar6 = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar5) = 0x180238091;
        iVar1 = fcn.180222010(iVar3);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar5) = 0x18023809f;
                uVar4 = fcn.180222340(iVar3, iVar6);
                *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar5) = 0x1802380a7;
                iVar1 = fcn.1802375f0(uVar4);
                if (iVar1 == 0) {
                    while (0 < iVar6) {
                        iVar6 = iVar6 + -1;
                        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar5) = 0x1802380dc;
                        fcn.180222340(iVar3, iVar6);
                        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar5) = 0x1802380e4;
                        fcn.18021fe80(*(int64_t *)(&stack0x00000048 + iVar2 + iVar5), 
                                      *(int64_t *)(&stack0x00000070 + iVar2 + iVar5));
                    }
                    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar5) = 0x1802380f0;
                    fcn.180221d50(iVar3);
                    return 0;
                }
                iVar6 = iVar6 + 1;
                *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar5) = 0x1802380b5;
                iVar1 = fcn.180222010(iVar3);
            } while (iVar6 < iVar1);
        }
        return iVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_18024b9a0
// Address: 0x18024b9a0
// Size: 136 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

int32_t fcn.18024b9a0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    
    uStack_30 = 0x18024b9b8;
    var_8h = arg1;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024b9cc;
    fcn.1801e3990(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024b9d4;
    puVar7 = (undefined4 *)fcn.18021eb70();
    *(undefined8 *)arg1 = 0;
    if (puVar7 == (undefined4 *)0x0) {
        return -1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba0e;
    iVar4 = fcn.18021f5d0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar4 != 1) goto code_r0x00018024bbae;
    pcVar2 = *(code **)(in_RDX + 0x50);
    uVar3 = *(undefined8 *)(puVar7 + 2);
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba35;
    iVar5 = (*pcVar2)(in_RDX, in_R8, uVar3);
    if (iVar5 != 0) {
        uVar3 = *(undefined8 *)(puVar7 + 2);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RDX + 0x28) + 0x14);
        if (((uVar1 & 2) == 0) && ((uVar1 >> 0x15 & 1) != 0)) {
code_r0x00018024ba85:
            *(undefined8 *)arg1 = *(undefined8 *)(puVar7 + 2);
            *puVar7 = 0;
            goto code_r0x00018024bbae;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba5f;
        fcn.1801e8e30(uVar3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba6a;
        iVar5 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
        if (iVar5 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba76;
            fcn.180201ea0(uVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba81;
            iVar5 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
            if (0 < iVar5) goto code_r0x00018024ba85;
        }
    }
    iVar4 = -1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024baaa;
    iVar8 = fcn.18021ed10(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                          *(int64_t *)(&stack0x00000168 + iVar6), *(int64_t *)(&stack0x000001a8 + iVar6), 
                          *(int64_t *)(&stack0x000001b0 + iVar6));
    if (iVar8 != 0) {
        iVar10 = 0;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bac2;
        iVar4 = fcn.180222010(iVar8);
        iVar9 = iVar10;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bada;
                iVar9 = fcn.180222340(iVar8, iVar5);
                pcVar2 = *(code **)(in_RDX + 0x50);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024baec;
                iVar4 = (*pcVar2)(in_RDX, in_R8, iVar9);
                if (iVar4 != 0) {
                    uVar1 = *(uint32_t *)(*(int64_t *)(in_RDX + 0x28) + 0x14);
                    if (((uVar1 & 2) == 0) && ((uVar1 >> 0x15 & 1) != 0)) break;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb11;
                    fcn.1801e8e30(iVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb1c;
                    iVar4 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                          *(int64_t *)(&stack0x00000058 + iVar6));
                    if (iVar4 < 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb28;
                        fcn.180201ea0(iVar9);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb33;
                        iVar4 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                              *(int64_t *)(&stack0x00000058 + iVar6));
                        if (0 < iVar4) break;
                    }
                    if (iVar10 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb44;
                        fcn.180201ea0(iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb4f;
                        fcn.180201ea0(iVar9);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb5a;
                        iVar4 = fcn.1802aa1b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                              *(int64_t *)(&stack0x00000048 + iVar6));
                        if (iVar4 < 1) goto code_r0x00018024bb61;
                    }
                    iVar10 = iVar9;
                }
code_r0x00018024bb61:
                iVar5 = iVar5 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb6b;
                iVar4 = fcn.180222010(iVar8);
                iVar9 = iVar10;
            } while (iVar5 < iVar4);
        }
        iVar4 = 0;
        **(int64_t **)((int64_t)&arg_28h + iVar6) = iVar9;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb8d;
            iVar5 = fcn.1802375f0(iVar9);
            iVar4 = -1;
            if (iVar5 != 0) {
                iVar4 = 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bba4;
        fcn.180238640(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6), 
                      *(int64_t *)(&stack0x00000058 + iVar6));
    }
code_r0x00018024bbae:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bbb6;
    fcn.18021eb10(puVar7);
    return iVar4;
}

// ============================================================
// Function: FUN_18024ba28
// Address: 0x18024ba28
// Size: 390 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

int32_t fcn.18024b9a0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    
    uStack_30 = 0x18024b9b8;
    var_8h = arg1;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024b9cc;
    fcn.1801e3990(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024b9d4;
    puVar7 = (undefined4 *)fcn.18021eb70();
    *(undefined8 *)arg1 = 0;
    if (puVar7 == (undefined4 *)0x0) {
        return -1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba0e;
    iVar4 = fcn.18021f5d0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar4 != 1) goto code_r0x00018024bbae;
    pcVar2 = *(code **)(in_RDX + 0x50);
    uVar3 = *(undefined8 *)(puVar7 + 2);
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba35;
    iVar5 = (*pcVar2)(in_RDX, in_R8, uVar3);
    if (iVar5 != 0) {
        uVar3 = *(undefined8 *)(puVar7 + 2);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RDX + 0x28) + 0x14);
        if (((uVar1 & 2) == 0) && ((uVar1 >> 0x15 & 1) != 0)) {
code_r0x00018024ba85:
            *(undefined8 *)arg1 = *(undefined8 *)(puVar7 + 2);
            *puVar7 = 0;
            goto code_r0x00018024bbae;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba5f;
        fcn.1801e8e30(uVar3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba6a;
        iVar5 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
        if (iVar5 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba76;
            fcn.180201ea0(uVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba81;
            iVar5 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
            if (0 < iVar5) goto code_r0x00018024ba85;
        }
    }
    iVar4 = -1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024baaa;
    iVar8 = fcn.18021ed10(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                          *(int64_t *)(&stack0x00000168 + iVar6), *(int64_t *)(&stack0x000001a8 + iVar6), 
                          *(int64_t *)(&stack0x000001b0 + iVar6));
    if (iVar8 != 0) {
        iVar10 = 0;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bac2;
        iVar4 = fcn.180222010(iVar8);
        iVar9 = iVar10;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bada;
                iVar9 = fcn.180222340(iVar8, iVar5);
                pcVar2 = *(code **)(in_RDX + 0x50);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024baec;
                iVar4 = (*pcVar2)(in_RDX, in_R8, iVar9);
                if (iVar4 != 0) {
                    uVar1 = *(uint32_t *)(*(int64_t *)(in_RDX + 0x28) + 0x14);
                    if (((uVar1 & 2) == 0) && ((uVar1 >> 0x15 & 1) != 0)) break;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb11;
                    fcn.1801e8e30(iVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb1c;
                    iVar4 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                          *(int64_t *)(&stack0x00000058 + iVar6));
                    if (iVar4 < 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb28;
                        fcn.180201ea0(iVar9);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb33;
                        iVar4 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                              *(int64_t *)(&stack0x00000058 + iVar6));
                        if (0 < iVar4) break;
                    }
                    if (iVar10 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb44;
                        fcn.180201ea0(iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb4f;
                        fcn.180201ea0(iVar9);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb5a;
                        iVar4 = fcn.1802aa1b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                              *(int64_t *)(&stack0x00000048 + iVar6));
                        if (iVar4 < 1) goto code_r0x00018024bb61;
                    }
                    iVar10 = iVar9;
                }
code_r0x00018024bb61:
                iVar5 = iVar5 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb6b;
                iVar4 = fcn.180222010(iVar8);
                iVar9 = iVar10;
            } while (iVar5 < iVar4);
        }
        iVar4 = 0;
        **(int64_t **)((int64_t)&arg_28h + iVar6) = iVar9;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb8d;
            iVar5 = fcn.1802375f0(iVar9);
            iVar4 = -1;
            if (iVar5 != 0) {
                iVar4 = 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bba4;
        fcn.180238640(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6), 
                      *(int64_t *)(&stack0x00000058 + iVar6));
    }
code_r0x00018024bbae:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bbb6;
    fcn.18021eb10(puVar7);
    return iVar4;
}

// ============================================================
// Function: FUN_18024bbae
// Address: 0x18024bbae
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

int32_t fcn.18024b9a0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    
    uStack_30 = 0x18024b9b8;
    var_8h = arg1;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024b9cc;
    fcn.1801e3990(in_R8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024b9d4;
    puVar7 = (undefined4 *)fcn.18021eb70();
    *(undefined8 *)arg1 = 0;
    if (puVar7 == (undefined4 *)0x0) {
        return -1;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba0e;
    iVar4 = fcn.18021f5d0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar6));
    if (iVar4 != 1) goto code_r0x00018024bbae;
    pcVar2 = *(code **)(in_RDX + 0x50);
    uVar3 = *(undefined8 *)(puVar7 + 2);
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba35;
    iVar5 = (*pcVar2)(in_RDX, in_R8, uVar3);
    if (iVar5 != 0) {
        uVar3 = *(undefined8 *)(puVar7 + 2);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RDX + 0x28) + 0x14);
        if (((uVar1 & 2) == 0) && ((uVar1 >> 0x15 & 1) != 0)) {
code_r0x00018024ba85:
            *(undefined8 *)arg1 = *(undefined8 *)(puVar7 + 2);
            *puVar7 = 0;
            goto code_r0x00018024bbae;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba5f;
        fcn.1801e8e30(uVar3);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba6a;
        iVar5 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
        if (iVar5 < 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba76;
            fcn.180201ea0(uVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024ba81;
            iVar5 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6));
            if (0 < iVar5) goto code_r0x00018024ba85;
        }
    }
    iVar4 = -1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024baaa;
    iVar8 = fcn.18021ed10(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                          *(int64_t *)(&stack0x00000168 + iVar6), *(int64_t *)(&stack0x000001a8 + iVar6), 
                          *(int64_t *)(&stack0x000001b0 + iVar6));
    if (iVar8 != 0) {
        iVar10 = 0;
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bac2;
        iVar4 = fcn.180222010(iVar8);
        iVar9 = iVar10;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bada;
                iVar9 = fcn.180222340(iVar8, iVar5);
                pcVar2 = *(code **)(in_RDX + 0x50);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024baec;
                iVar4 = (*pcVar2)(in_RDX, in_R8, iVar9);
                if (iVar4 != 0) {
                    uVar1 = *(uint32_t *)(*(int64_t *)(in_RDX + 0x28) + 0x14);
                    if (((uVar1 & 2) == 0) && ((uVar1 >> 0x15 & 1) != 0)) break;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb11;
                    fcn.1801e8e30(iVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb1c;
                    iVar4 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                          *(int64_t *)(&stack0x00000058 + iVar6));
                    if (iVar4 < 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb28;
                        fcn.180201ea0(iVar9);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb33;
                        iVar4 = fcn.18024c3a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                              *(int64_t *)(&stack0x00000058 + iVar6));
                        if (0 < iVar4) break;
                    }
                    if (iVar10 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb44;
                        fcn.180201ea0(iVar10);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb4f;
                        fcn.180201ea0(iVar9);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb5a;
                        iVar4 = fcn.1802aa1b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                                              *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                              *(int64_t *)(&stack0x00000048 + iVar6));
                        if (iVar4 < 1) goto code_r0x00018024bb61;
                    }
                    iVar10 = iVar9;
                }
code_r0x00018024bb61:
                iVar5 = iVar5 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb6b;
                iVar4 = fcn.180222010(iVar8);
                iVar9 = iVar10;
            } while (iVar5 < iVar4);
        }
        iVar4 = 0;
        **(int64_t **)((int64_t)&arg_28h + iVar6) = iVar9;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bb8d;
            iVar5 = fcn.1802375f0(iVar9);
            iVar4 = -1;
            if (iVar5 != 0) {
                iVar4 = 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bba4;
        fcn.180238640(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), *(int64_t *)((int64_t)&arg_28h + iVar6), 
                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6), 
                      *(int64_t *)(&stack0x00000058 + iVar6));
    }
code_r0x00018024bbae:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024bbb6;
    fcn.18021eb10(puVar7);
    return iVar4;
}

// ============================================================
// Function: FUN_18024bbe0
// Address: 0x18024bbe0
// Size: 1029 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18024bbe0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024bbfa;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bc13;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bc2b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bc3d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bc47;
    fcn.18024b870(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    in_RCX[1] = in_R8;
    *in_RCX = in_RDX;
    in_RCX[3] = 0;
    in_RCX[0x13] = 0;
    in_RCX[6] = 0;
    in_RCX[0x14] = 0;
    *(undefined8 *)((int64_t)in_RCX + 0xb4) = 0;
    *(undefined4 *)(in_RCX + 0x16) = 0;
    in_RCX[0x18] = 0;
    in_RCX[0x19] = 0;
    in_RCX[0x1a] = 0;
    in_RCX[0x1b] = 0;
    in_RCX[0x15] = 0;
    in_RCX[0x1c] = 0;
    in_RCX[0x1f] = 0;
    *(undefined4 *)(in_RCX + 0x20) = 0;
    in_RCX[0x21] = 0;
    in_RCX[2] = in_R9;
    *(undefined (*) [16])(in_RCX + 0x1d) = ZEXT816(0);
    in_RCX[4] = 0;
    if (in_RDX == 0) {
        in_RCX[0x12] = 0;
code_r0x00018024bce9:
        in_RCX[10] = 0x18024e930;
        if (in_RDX != 0) goto code_r0x00018024bcf9;
code_r0x00018024bd08:
        in_RCX[9] = (int64_t)fcn.18024b9a0;
        if (in_RDX != 0) goto code_r0x00018024bd18;
code_r0x00018024bd27:
        in_RCX[8] = 0x180250890;
        if (in_RDX != 0) goto code_r0x00018024bd37;
code_r0x00018024bd46:
        in_RCX[7] = 0x180250600;
        if (in_RDX != 0) goto code_r0x00018024bd56;
code_r0x00018024bd65:
        in_RCX[0xb] = 0x18024ef60;
        if (in_RDX != 0) goto code_r0x00018024bd75;
code_r0x00018024bd84:
        in_RCX[0xc] = 0;
        if (in_RDX != 0) goto code_r0x00018024bd8d;
code_r0x00018024bd9c:
        in_RCX[0xd] = 0x18024da60;
        if (in_RDX != 0) goto code_r0x00018024bdac;
code_r0x00018024bdbb:
        in_RCX[0xe] = 0x18024d2a0;
        if (in_RDX != 0) goto code_r0x00018024bdcb;
code_r0x00018024bdda:
        in_RCX[0xf] = 0x18024ed30;
        if (in_RDX != 0) goto code_r0x00018024bdea;
code_r0x00018024bdfc:
        in_RCX[0x10] = (int64_t)fcn.18021ed10;
        if (in_RDX != 0) goto code_r0x00018024be0f;
code_r0x00018024be18:
        iVar7 = 0x18021eee0;
    } else {
        in_RCX[0x12] = *(int64_t *)(in_RDX + 0x78);
        if (*(int64_t *)(in_RDX + 0x38) == 0) goto code_r0x00018024bce9;
        in_RCX[10] = *(int64_t *)(in_RDX + 0x38);
code_r0x00018024bcf9:
        if (*(int64_t *)(in_RDX + 0x30) == 0) goto code_r0x00018024bd08;
        in_RCX[9] = *(int64_t *)(in_RDX + 0x30);
code_r0x00018024bd18:
        if (*(int64_t *)(in_RDX + 0x28) == 0) goto code_r0x00018024bd27;
        in_RCX[8] = *(int64_t *)(in_RDX + 0x28);
code_r0x00018024bd37:
        if (*(int64_t *)(in_RDX + 0x20) == 0) goto code_r0x00018024bd46;
        in_RCX[7] = *(int64_t *)(in_RDX + 0x20);
code_r0x00018024bd56:
        if (*(int64_t *)(in_RDX + 0x40) == 0) goto code_r0x00018024bd65;
        in_RCX[0xb] = *(int64_t *)(in_RDX + 0x40);
code_r0x00018024bd75:
        if (*(int64_t *)(in_RDX + 0x48) == 0) goto code_r0x00018024bd84;
        in_RCX[0xc] = *(int64_t *)(in_RDX + 0x48);
code_r0x00018024bd8d:
        if (*(int64_t *)(in_RDX + 0x50) == 0) goto code_r0x00018024bd9c;
        in_RCX[0xd] = *(int64_t *)(in_RDX + 0x50);
code_r0x00018024bdac:
        if (*(int64_t *)(in_RDX + 0x58) == 0) goto code_r0x00018024bdbb;
        in_RCX[0xe] = *(int64_t *)(in_RDX + 0x58);
code_r0x00018024bdcb:
        if (*(int64_t *)(in_RDX + 0x60) == 0) goto code_r0x00018024bdda;
        in_RCX[0xf] = *(int64_t *)(in_RDX + 0x60);
code_r0x00018024bdea:
        if (*(int64_t *)(in_RDX + 0x68) == 0) goto code_r0x00018024bdfc;
        in_RCX[0x10] = *(int64_t *)(in_RDX + 0x68);
code_r0x00018024be0f:
        iVar7 = *(int64_t *)(in_RDX + 0x70);
        if (iVar7 == 0) goto code_r0x00018024be18;
    }
    in_RCX[0x11] = iVar7;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024be2b;
    iVar7 = func_0x000180234050();
    in_RCX[5] = iVar7;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024be39;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024be51;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
    } else {
        if (in_RDX == 0) {
            *(uint32_t *)(iVar7 + 0x10) = *(uint32_t *)(iVar7 + 0x10) | 0x11;
        } else {
            uVar1 = *(undefined8 *)(in_RDX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024be72;
            iVar4 = func_0x000180233c60(iVar7, uVar1);
            if (iVar4 == 0) goto code_r0x00018024bf57;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024be86;
        iVar7 = func_0x000180233f60(0x1804e2320);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024be90;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bea8;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bec5;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
            goto code_r0x00018024bf57;
        }
        iVar2 = in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bed6;
        iVar4 = func_0x000180233c60(iVar2, iVar7);
        if (iVar4 == 0) goto code_r0x00018024bf57;
        if (*(int32_t *)(in_RCX[5] + 0x1c) == 0) {
            uVar5 = *(undefined4 *)(in_RCX[5] + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024beeb;
            uVar5 = func_0x00018023b810(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bef2;
            iVar7 = func_0x00018023b7c0(uVar5);
            if (iVar7 != 0) {
                iVar2 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bf03;
                uVar5 = func_0x00018023b860(iVar7);
                *(undefined4 *)(iVar2 + 0x1c) = uVar5;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bf1a;
        iVar4 = func_0x000180224430(5, in_RCX, in_RCX + 0x1d);
        if (iVar4 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bf2d;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bf45;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bf57;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x00018024bf57:
    pcVar3 = (code *)in_RCX[0x12];
    if (pcVar3 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bf68;
        (*pcVar3)(in_RCX);
        in_RCX[0x12] = 0;
    }
    if (in_RCX[5] != 0) {
        if (in_RCX[0x1c] == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bf86;
            func_0x000180233bc0();
        }
        in_RCX[5] = 0;
    }
    iVar7 = in_RCX[0x15];
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bf96;
    func_0x0001802c9ee0(iVar7);
    in_RCX[0x15] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bfa9;
    fcn.180238640(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                  *(int64_t *)(&stack0x00000050 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6), 
                  *(int64_t *)(&stack0x00000078 + iVar6));
    in_RCX[0x14] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18024bfc4;
    func_0x000180223fb0(5, in_RCX, in_RCX + 0x1d);
    *(undefined (*) [16])(in_RCX + 0x1d) = ZEXT816(0);
    return 0;
}

// ============================================================
// Function: FUN_18024bff0
// Address: 0x18024bff0
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18024bff0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024c000;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024c014;
    uVar2 = fcn.18024bbe0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1));
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    *(undefined8 *)(in_RCX + 0x108) = in_R8;
    return 1;
}

// ============================================================
// Function: FUN_18024c040
// Address: 0x18024c040
// Size: 62 bytes
// ============================================================
void fcn.18024c040(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18024c04a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x18024c064;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)(iVar1 + 0x110) = 0;
    return;
}

// ============================================================
// Function: FUN_18024c080
// Address: 0x18024c080
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18024c080(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024c095;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024c0b5;
    iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)(iVar2 + 0x110) = in_RCX;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024c0de;
        iVar3 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(int64_t *)(iVar2 + 0x118) = iVar3;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024c0ff;
            fcn.180224990(iVar2, 0x1804e48c8, 0xa78);
            return 0;
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18024c130
// Address: 0x18024c130
// Size: 346 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18024c130(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t iVar4;
    uint64_t in_RDX;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024c14a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = in_R8 & 0xffffffff;
    iVar4 = (int32_t)in_RDX;
    uVar6 = in_RDX & 0xffffffff;
    if ((int32_t)in_R8 == 0) {
        uVar5 = in_RDX & 0xffffffff;
        if (iVar4 != 0) goto code_r0x00018024c16f;
code_r0x00018024c20b:
        if (in_R9D == 0) goto code_r0x00018024c24e;
    } else {
        if (iVar4 == 0) {
            uVar6 = in_R8 & 0xffffffff;
        }
code_r0x00018024c16f:
        iVar4 = (int32_t)uVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c176;
        iVar1 = func_0x00018023b810(uVar5);
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c180;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c198;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c1aa;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c1b8;
        iVar3 = func_0x00018023b7c0(iVar1);
        if (*(int32_t *)(iVar3 + 4) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c1c5;
            iVar1 = func_0x00018023b810(uVar6);
            if (iVar1 == -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c1cf;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c1e7;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c1f9;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c204;
            iVar3 = func_0x00018023b7c0(iVar1);
        }
        if (in_R9D == 0) {
            in_R9D = *(int32_t *)(iVar3 + 4);
            goto code_r0x00018024c20b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c216;
    iVar1 = func_0x0001802a7e10(in_R9D);
    if (iVar1 == -1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c220;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c238;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024c24a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
code_r0x00018024c24e:
    if ((*(int32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x18) == 0) && (iVar4 != 0)) {
        *(int32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x18) = iVar4;
    }
    if ((*(int32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x1c) == 0) && (in_R9D != 0)) {
        *(int32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x1c) = in_R9D;
    }
    return 1;
}

// ============================================================
// Function: FUN_18024c290
// Address: 0x18024c290
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18024c290(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t *puVar11;
    int64_t in_RCX;
    uint32_t uVar12;
    uint32_t uVar13;
    undefined8 unaff_RBP;
    uint64_t uVar14;
    undefined8 unaff_RSI;
    undefined8 uVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar16;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024c2a0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18024c2b1;
    iVar9 = fcn.180233f60(*(int64_t *)((int64_t)aiStackX_10 + iVar8 + 0x10));
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18024c2bb;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar8 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar8 + 0x10))
        ;
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18024c2d3;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar8 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar8 + 0x10)
                      , *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18024c2ec;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8));
        return false;
    }
    iVar10 = *(int64_t *)(in_RCX + 0x28);
    uVar15 = *(undefined8 *)((int64_t)aiStackX_10 + iVar8 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar8 + 8) = uVar15;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar8 + -8) = unaff_R13;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar8 + -0x10) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180233c82;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (iVar9 == 0) {
        return true;
    }
    uVar14 = 0;
    uVar12 = *(uint32_t *)(iVar9 + 0x10) | *(uint32_t *)(iVar10 + 0x10);
    if ((uVar12 & 0x10) != 0) {
        *(undefined4 *)(iVar10 + 0x10) = 0;
    }
    if ((uVar12 & 8) != 0) {
        return true;
    }
    uVar13 = uVar12 & 1;
    uVar16 = uVar12 & 2;
    if ((((((((((uVar16 != 0) ||
               ((*(int32_t *)(iVar9 + 0x18) != 0 && ((uVar13 != 0 || (*(int32_t *)(iVar10 + 0x18) == 0)))))) &&
              (*(undefined4 *)(iVar10 + 0x18) = *(undefined4 *)(iVar9 + 0x18), uVar16 != 0)) ||
             ((*(int32_t *)(iVar9 + 0x1c) != 0 && ((uVar13 != 0 || (*(int32_t *)(iVar10 + 0x1c) == 0)))))) &&
            (*(undefined4 *)(iVar10 + 0x1c) = *(undefined4 *)(iVar9 + 0x1c), uVar16 != 0)) ||
           ((*(int32_t *)(iVar9 + 0x20) != -1 && ((uVar13 != 0 || (*(int32_t *)(iVar10 + 0x20) == -1)))))) &&
          (*(undefined4 *)(iVar10 + 0x20) = *(undefined4 *)(iVar9 + 0x20), uVar16 != 0)) ||
         ((*(int32_t *)(iVar9 + 0x24) != -1 && ((uVar13 != 0 || (*(int32_t *)(iVar10 + 0x24) == -1)))))) &&
        (*(undefined4 *)(iVar10 + 0x24) = *(undefined4 *)(iVar9 + 0x24), uVar16 != 0)) ||
       (uVar1 = *(uint32_t *)(iVar10 + 0x14), (uVar1 & 2) == 0)) {
        puVar11 = (uint32_t *)(iVar10 + 0x14);
        uVar15 = *(undefined8 *)(iVar9 + 8);
        *puVar11 = *puVar11 & 0xfffffffd;
        *(undefined8 *)(iVar10 + 8) = uVar15;
        uVar1 = *puVar11;
    }
    if ((uVar12 & 4) != 0) {
        *(uint32_t *)(iVar10 + 0x14) = 0;
        uVar1 = 0;
    }
    *(uint32_t *)(iVar10 + 0x14) = uVar1 | *(uint32_t *)(iVar9 + 0x14);
    if ((uVar16 == 0) && ((*(int64_t *)(iVar9 + 0x28) == 0 || ((uVar13 == 0 && (*(int64_t *)(iVar10 + 0x28) != 0)))))) {
code_r0x000180233e00:
        if ((*(int32_t *)(iVar9 + 0x38) != 0) && ((uVar13 != 0 || (*(int32_t *)(iVar10 + 0x38) == 0))))
        goto code_r0x000180233e10;
code_r0x000180233e1b:
        if ((*(int64_t *)(iVar9 + 0x30) != 0) && ((uVar13 != 0 || (*(int64_t *)(iVar10 + 0x30) == 0))))
        goto code_r0x000180233e2b;
code_r0x000180233e69:
        if ((*(int64_t *)(iVar9 + 0x48) != 0) && ((uVar13 != 0 || (*(int64_t *)(iVar10 + 0x48) == 0))))
        goto code_r0x000180233e81;
    } else {
        iVar5 = *(int64_t *)(iVar9 + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233d88;
        fcn.180222050(*(int64_t *)(&stack0x00000040 + iVar3 + iVar8), *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar8), 
                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar8), *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar8), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar8));
        if (iVar5 == 0) {
            *(undefined8 *)(iVar10 + 0x28) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233d98;
            iVar4 = fcn.180221f20();
            *(int64_t *)(iVar10 + 0x28) = iVar4;
            if (iVar4 == 0) {
                return false;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233db0;
            iVar2 = fcn.180222010(iVar5);
            uVar6 = uVar14;
            if (0 < iVar2) {
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233dbe;
                    fcn.180222340(iVar5, uVar6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233dc6;
                    iVar4 = fcn.1802983b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + iVar8 + 8));
                    if (iVar4 == 0) {
                        return false;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233dde;
                    iVar2 = fcn.180222110(*(int64_t *)((int64_t)&arg_28h + iVar3 + iVar8), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar8), 
                                          *(int64_t *)(&stack0x00000040 + iVar3 + iVar8), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar8), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar8));
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233ed8;
                        fcn.18027c100(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + iVar8 + 8));
                        return false;
                    }
                    uVar12 = (int32_t)uVar6 + 1;
                    uVar6 = (uint64_t)uVar12;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233df0;
                    iVar2 = fcn.180222010(iVar5);
                } while ((int32_t)uVar12 < iVar2);
            }
            *(uint32_t *)(iVar10 + 0x14) = *(uint32_t *)(iVar10 + 0x14) | 0x80;
        }
        if (uVar16 == 0) goto code_r0x000180233e00;
code_r0x000180233e10:
        *(undefined4 *)(iVar10 + 0x38) = *(undefined4 *)(iVar9 + 0x38);
        if (uVar16 == 0) goto code_r0x000180233e1b;
code_r0x000180233e2b:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233e3b;
        fcn.180222050(*(int64_t *)(&stack0x00000040 + iVar3 + iVar8), *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar8), 
                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar8), *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar8), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar8));
        *(undefined8 *)(iVar10 + 0x30) = 0;
        if (*(int64_t *)(iVar9 + 0x30) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233e5b;
            iVar5 = fcn.180221730(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + iVar8 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar3 + iVar8 + 0x10), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3 + iVar8));
            *(int64_t *)(iVar10 + 0x30) = iVar5;
            if (iVar5 == 0) {
                return false;
            }
        }
        if (uVar16 == 0) goto code_r0x000180233e69;
code_r0x000180233e81:
        iVar5 = *(int64_t *)(iVar9 + 0x48);
        uVar6 = *(uint64_t *)(iVar9 + 0x50);
        uVar7 = uVar14;
        if (iVar5 != 0) {
            if (uVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233e9b;
                uVar6 = fcn.180498cd0(iVar5);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233eb4;
            uVar7 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + iVar8 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar3 + iVar8 + 0x10));
            if (uVar7 == 0) {
                return false;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233eca;
            fcn.180498030(uVar7, iVar5, uVar6);
            *(undefined *)(uVar7 + uVar6) = 0;
            uVar14 = uVar6;
        }
        uVar15 = *(undefined8 *)(iVar10 + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233ef8;
        fcn.180224990(uVar15, 0x1804e2338, 0xfe);
        *(uint64_t *)(iVar10 + 0x48) = uVar7;
        if ((uint64_t *)(iVar10 + 0x50) != (uint64_t *)0x0) {
            *(uint64_t *)(iVar10 + 0x50) = uVar14;
        }
        if (uVar16 != 0) goto code_r0x000180233f1d;
    }
    if ((*(int64_t *)(iVar9 + 0x58) == 0) || ((uVar13 == 0 && (*(int64_t *)(iVar10 + 0x58) != 0)))) {
        return true;
    }
code_r0x000180233f1d:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3 + iVar8) = 0x180233f2d;
    iVar2 = fcn.180234120(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + iVar8 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + iVar8 + 0x10), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3 + iVar8), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar8), 
                          *(int64_t *)(&stack0x00000040 + iVar3 + iVar8));
    return iVar2 != 0;
}

// ============================================================
// Function: FUN_18024c310
// Address: 0x18024c310
// Size: 29 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling

bool fcn.18024c310(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 auStackX_18 [2];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    in_RCX = in_RCX + 0xe8;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6) = 0x180224465;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *(int64_t *)(in_RCX + 8);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18022447e;
        iVar5 = fcn.180221f20();
        *(int64_t *)(in_RCX + 8) = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18022448c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar4 + iVar6));
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x1802244a4;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar4 + iVar6), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar6), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar6), 
                          *(int64_t *)(&stack0x00000070 + iVar4 + iVar6));
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x1802244b6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar6));
            return false;
        }
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x1802244d5;
    iVar2 = fcn.180222010(iVar5);
    while( true ) {
        if (in_EDX < iVar2) {
            uVar1 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224503;
            iVar5 = fcn.1802221b0(uVar1, in_EDX, in_R8);
            if (iVar5 != in_R8) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18022450d;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar6));
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224525;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar6), 
                              *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar6));
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224537;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar6));
            }
            return iVar5 == in_R8;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x1802244eb;
        iVar3 = fcn.180222110(*(int64_t *)((int64_t)&arg_50h + iVar4 + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000068 + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar6));
        if (iVar3 == 0) break;
        iVar2 = iVar2 + 1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224540;
    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), *(int64_t *)(&stack0x00000048 + iVar4 + iVar6));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224558;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), *(int64_t *)(&stack0x00000048 + iVar4 + iVar6), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar6), 
                  *(int64_t *)(&stack0x00000070 + iVar4 + iVar6));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18022456a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar6));
    return false;
}

// ============================================================
// Function: FUN_18024c330
// Address: 0x18024c330
// Size: 26 bytes
// ============================================================
undefined8 fcn.18024c330(int64_t param_1, uint32_t param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    
    fcn.18045a350();
    iVar1 = *(int64_t *)(param_1 + 0x28);
    uVar2 = param_2 | *(uint32_t *)(iVar1 + 0x14);
    *(uint32_t *)(iVar1 + 0x14) = uVar2;
    if ((param_2 & 0x780) != 0) {
        *(uint32_t *)(iVar1 + 0x14) = uVar2 | 0x80;
    }
    return 1;
}

// ============================================================
// Function: FUN_18024c360
// Address: 0x18024c360
// Size: 30 bytes
// ============================================================
undefined8 fcn.18024c360(int64_t param_1, uint64_t param_2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    undefined8 unaff_RDI;
    uint64_t uVar11;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    param_2 = param_2 & 0xffffffff;
    uVar11 = 0;
    uVar7 = 0;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar5) = unaff_RBP;
    *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x18024c14a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar10 = uVar11 & 0xffffffff;
    uVar8 = param_2 & 0xffffffff;
    iVar6 = (int32_t)uVar7;
    uVar9 = uVar7 & 0xffffffff;
    if ((int32_t)param_2 == 0) {
        uVar8 = uVar7 & 0xffffffff;
        if (iVar6 != 0) goto code_r0x00018024c16f;
code_r0x00018024c20b:
        iVar1 = (int32_t)uVar10;
        if (iVar1 == 0) goto code_r0x00018024c24e;
    } else {
        if (iVar6 == 0) {
            uVar9 = param_2 & 0xffffffff;
        }
code_r0x00018024c16f:
        iVar6 = (int32_t)uVar8;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c176;
        iVar1 = func_0x00018023b810(uVar8);
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c180;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c198;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), *(int64_t *)(&stack0x00000070 + iVar3 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1aa;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1b8;
        iVar4 = func_0x00018023b7c0(iVar1);
        if (*(int32_t *)(iVar4 + 4) == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1c5;
            iVar1 = func_0x00018023b810(uVar9);
            if (iVar1 == -1) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1cf;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1e7;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000070 + iVar3 + iVar5));
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1f9;
                fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar5));
                return 0;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c204;
            iVar4 = func_0x00018023b7c0(iVar1);
        }
        if ((int32_t)uVar11 == 0) {
            uVar10 = (uint64_t)*(uint32_t *)(iVar4 + 4);
            goto code_r0x00018024c20b;
        }
    }
    iVar1 = (int32_t)uVar10;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c216;
    iVar2 = func_0x0001802a7e10(uVar10);
    if (iVar2 == -1) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c220;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c238;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar5));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c24a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar5));
        return 0;
    }
code_r0x00018024c24e:
    if ((*(int32_t *)(*(int64_t *)(param_1 + 0x28) + 0x18) == 0) && (iVar6 != 0)) {
        *(int32_t *)(*(int64_t *)(param_1 + 0x28) + 0x18) = iVar6;
    }
    if ((*(int32_t *)(*(int64_t *)(param_1 + 0x28) + 0x1c) == 0) && (iVar1 != 0)) {
        *(int32_t *)(*(int64_t *)(param_1 + 0x28) + 0x1c) = iVar1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18024c380
// Address: 0x18024c380
// Size: 30 bytes
// ============================================================
undefined8 fcn.18024c380(int64_t param_1, uint64_t param_2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    undefined8 unaff_RDI;
    uint64_t uVar11;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    param_2 = param_2 & 0xffffffff;
    uVar11 = 0;
    uVar7 = 0;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar5) = unaff_RBP;
    *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x18024c14a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar10 = param_2 & 0xffffffff;
    uVar8 = uVar11 & 0xffffffff;
    iVar6 = (int32_t)uVar7;
    uVar9 = uVar7 & 0xffffffff;
    if ((int32_t)uVar11 == 0) {
        uVar8 = uVar7 & 0xffffffff;
        if (iVar6 != 0) goto code_r0x00018024c16f;
code_r0x00018024c20b:
        iVar1 = (int32_t)uVar10;
        if (iVar1 == 0) goto code_r0x00018024c24e;
    } else {
        if (iVar6 == 0) {
            uVar9 = uVar11 & 0xffffffff;
        }
code_r0x00018024c16f:
        iVar6 = (int32_t)uVar8;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c176;
        iVar1 = func_0x00018023b810(uVar8);
        if (iVar1 == -1) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c180;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c198;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), *(int64_t *)(&stack0x00000070 + iVar3 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1aa;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1b8;
        iVar4 = func_0x00018023b7c0(iVar1);
        if (*(int32_t *)(iVar4 + 4) == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1c5;
            iVar1 = func_0x00018023b810(uVar9);
            if (iVar1 == -1) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1cf;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1e7;
                fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000070 + iVar3 + iVar5));
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c1f9;
                fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar5));
                return 0;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c204;
            iVar4 = func_0x00018023b7c0(iVar1);
        }
        if ((int32_t)param_2 == 0) {
            uVar10 = (uint64_t)*(uint32_t *)(iVar4 + 4);
            goto code_r0x00018024c20b;
        }
    }
    iVar1 = (int32_t)uVar10;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c216;
    iVar2 = func_0x0001802a7e10(uVar10);
    if (iVar2 == -1) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c220;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c238;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar5), *(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar5));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x18024c24a;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar5));
        return 0;
    }
code_r0x00018024c24e:
    if ((*(int32_t *)(*(int64_t *)(param_1 + 0x28) + 0x18) == 0) && (iVar6 != 0)) {
        *(int32_t *)(*(int64_t *)(param_1 + 0x28) + 0x18) = iVar6;
    }
    if ((*(int32_t *)(*(int64_t *)(param_1 + 0x28) + 0x1c) == 0) && (iVar1 != 0)) {
        *(int32_t *)(*(int64_t *)(param_1 + 0x28) + 0x1c) = iVar1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18024c3a0
// Address: 0x18024c3a0
// Size: 243 bytes
// ============================================================
uint64_t fcn.18024c3a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_88h)
{
    undefined uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t *in_RCX;
    undefined8 *in_RDX;
    undefined8 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    bool bVar10;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024c3b1;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 0;
    if (in_RCX[1] == 0x17) {
        bVar10 = *in_RCX == 0xd;
    } else {
        if (in_RCX[1] != 0x18) {
            return 0;
        }
        bVar10 = *in_RCX == 0xf;
    }
    uVar7 = uVar6;
    uVar9 = uVar6;
    if (bVar10) {
        do {
            uVar1 = *(undefined *)(*(int64_t *)(in_RCX + 2) + uVar7);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024c3ed;
            iVar2 = func_0x000180275480(uVar1);
            if (iVar2 == 0) {
                return 0;
            }
            uVar8 = (int32_t)uVar9 + 1;
            uVar7 = uVar7 + 1;
            uVar9 = (uint64_t)uVar8;
        } while ((int32_t)uVar8 < *in_RCX + -1);
        if (*(char *)((int64_t)*in_RCX + -1 + *(int64_t *)(in_RCX + 2)) == 'Z') {
            if (in_RDX == (undefined8 *)0x0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024c428;
                func_0x000180467bd4((int64_t)&arg_40h + iVar3);
                uVar5 = *(undefined8 *)((int64_t)&arg_40h + iVar3);
            } else {
                uVar5 = *in_RDX;
                *(undefined8 *)((int64_t)&arg_40h + iVar3) = uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024c43a;
            iVar4 = func_0x0001802aa0b0(0, uVar5, 0, 0);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024c457;
                iVar2 = func_0x0001802aa2d0((int64_t)&arg_28h + iVar3, (int64_t)&arg_38h + iVar3, in_RCX, iVar4);
                if ((iVar2 != 0) &&
                   ((*(int32_t *)((int64_t)&arg_28h + iVar3) < 0 ||
                    (uVar6 = 0xffffffff, *(int32_t *)((int64_t)&arg_38h + iVar3) < 0)))) {
                    uVar6 = 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024c479;
            func_0x0001802aa3c0(iVar4);
            return uVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18024c4a0
// Address: 0x18024c4a0
// Size: 300 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18024c4a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024c4ba;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c4cd;
        iVar1 = func_0x00018022fd20();
        if (iVar1 == 0) {
            return 1;
        }
    }
    iVar1 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c4df;
    iVar2 = fcn.180222010(in_RDX);
    if (0 < iVar2) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c4ed;
            uVar4 = fcn.180222340(in_RDX, iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c4f5;
            iVar5 = func_0x000180238400(uVar4);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c5aa;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c5c2;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                goto code_r0x00018024c53d;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c509;
            iVar2 = func_0x00018022fd20(iVar5);
            if (iVar2 == 0) {
                do {
                    iVar1 = iVar1 + -1;
                    if (iVar1 < 0) {
                        if (in_RCX == 0) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c59c;
                        uVar4 = func_0x00018022e6c0(in_RCX, iVar5);
                        return uVar4;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c570;
                    uVar4 = fcn.180222340(in_RDX, iVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c578;
                    uVar4 = func_0x000180238400(uVar4);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c583;
                    iVar2 = func_0x00018022e6c0(uVar4, iVar5);
                } while (iVar2 != 0);
                return 0;
            }
            iVar1 = iVar1 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c517;
            iVar2 = fcn.180222010(in_RDX);
        } while (iVar1 < iVar2);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c520;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c538;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x00018024c53d:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024c54a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18024c5d0
// Address: 0x18024c5d0
// Size: 148 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18024c5d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024c5e0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024c5f2;
    fcn.180467bd4((int64_t)&arg_28h + iVar1);
    if ((in_RCX != 0) && ((*(uint8_t *)(in_RCX + 0x10) & 0x40) == 0)) {
        if (*(int32_t *)(in_RCX + 4) == 0x17) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024c618;
            fcn.1802c9990(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
            return;
        }
        if (*(int32_t *)(in_RCX + 4) == 0x18) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024c63b;
            fcn.1802ae690(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
            return;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18024c659;
    fcn.1802aa0b0(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18024c670
// Address: 0x18024c670
// Size: 203 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.18024c670(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024c685;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024c692;
    iVar6 = fcn.180238400();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024c69f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024c6b7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024c6c9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024c6e6;
        iVar2 = fcn.18023bea0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)(&stack0x00000050 + iVar5));
        if (iVar2 != 0) {
            if ((*(uint32_t *)(in_RCX + 0xd8) & 0x2000) == 0) {
                return 0;
            }
            if (in_EDX == 0) {
                return 1;
            }
            uVar4 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
            uVar1 = *(undefined8 *)((int64_t)&arg_30h + iVar5);
            uVar7 = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = unaff_R12;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = unaff_R14;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = unaff_R15;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -0x18) = 0x1802405b0;
            iVar3 = fcn.18045a350();
            iVar3 = -iVar3;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar5 + -0x18) = 0x1802405c6;
            iVar2 = fcn.18027cfe0(*(int64_t *)((int64_t)&arg_28h + iVar3 + iVar5));
            if (iVar2 != 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_68h + iVar3 + iVar5) = uVar4;
            uVar4 = *(undefined8 *)(in_RCX + 0x168);
            *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_78h + iVar3 + iVar5) = uVar1;
            uVar1 = *(undefined8 *)(in_RCX + 0x158);
            *(undefined8 *)((int64_t)&arg_80h + iVar3 + iVar5) = uVar7;
            uVar7 = *(undefined8 *)(in_RCX + 0x160);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar5 + -0x18) = 0x180240605;
            fcn.18021fb40();
            *(undefined8 *)((int64_t)&arg_40h + iVar3 + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_38h + iVar3 + iVar5) = uVar7;
            *(int64_t *)((int64_t)&arg_30h + iVar3 + iVar5) = iVar6;
            *(undefined8 *)((int64_t)&arg_28h + iVar3 + iVar5) = uVar1;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar3 + iVar5 + -0x18) = 0x180240632;
            uVar4 = fcn.1802afbb0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar5));
            return uVar4;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18024c740
// Address: 0x18024c740
// Size: 103 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_b4h

uint64_t fcn.18024c740(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18024c74a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024c757;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024c76f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024c781;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xffffffff;
    }
    if (*(int64_t *)(in_RCX + 0x108) == 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + 8) = unaff_RBX;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4) = 0x180250d2c;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        if (*(int64_t *)(in_RCX + 8) == 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250d40;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250d58;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250d6a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined4 *)(in_RCX + 0xb8) = 0x45;
            return 0xffffffff;
        }
        iVar8 = *(int64_t *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = unaff_RDI;
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250d93;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250dab;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250dbd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined4 *)(in_RCX + 0xb8) = 0x45;
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250de9;
        iVar2 = fcn.1802385a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000070 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
        if (iVar2 == 0) {
            *(undefined4 *)(in_RCX + 0xb8) = 0x11;
            return 0xffffffff;
        }
        uVar6 = *(undefined8 *)(in_RCX + 8);
        *(undefined4 *)(in_RCX + 0x9c) = 1;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250e1d;
        iVar2 = fcn.18024d7d0(in_RCX, uVar6);
        if (iVar2 == 0) {
            iVar8 = *(int64_t *)(in_RCX + 8);
            *(undefined4 *)(in_RCX + 0xb4) = 0;
            if (iVar8 == 0) {
                uVar6 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250e42;
                iVar8 = fcn.180222340(uVar6, 0);
            }
            *(int64_t *)(in_RCX + 0xc0) = iVar8;
            pcVar1 = *(code **)(in_RCX + 0x40);
            *(undefined4 *)(in_RCX + 0xb8) = 0x42;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250e5e;
            uVar7 = (*pcVar1)(0, in_RCX);
            if ((int32_t)uVar7 == 0) {
                return uVar7;
            }
        }
        if (*(int64_t *)(in_RCX + 0xf8) != 0) {
            uVar6 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250e82;
            iVar2 = fcn.180222010(uVar6);
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250e8e;
                uVar7 = fcn.18024fcc0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                                      *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4));
                goto code_r0x000180250e98;
            }
        }
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250e98;
        uVar7 = fcn.180250a80(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
code_r0x000180250e98:
        if (((int32_t)uVar7 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
            *(undefined4 *)(in_RCX + 0xb8) = 1;
        }
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar4) = 0x180250c05;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar3 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x24);
    if (0 < (int32_t)uVar3) {
        if (*(int64_t *)(in_RCX + 0x108) != 0) {
            if (5 < (int32_t)uVar3) {
                uVar3 = 5;
            }
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250c33;
            iVar2 = fcn.18022fb60();
            if (*(int32_t *)((uint64_t)uVar3 * 4 + 0x1804e4894) <= iVar2) goto code_r0x000180250c84;
        }
        uVar6 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined4 *)(in_RCX + 0xb4) = 0;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250c54;
        uVar6 = fcn.180222340(uVar6, 0);
        *(undefined8 *)(in_RCX + 0xc0) = uVar6;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x42;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250c70;
        uVar7 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar7 == 0) {
            return uVar7;
        }
    }
code_r0x000180250c84:
    iVar8 = *(int64_t *)(in_RCX + 0xf8);
    *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = unaff_RBP;
    *(int32_t *)(in_RCX + 0xb8) = 0x5f;
    if (iVar8 != 0) {
        uVar6 = *(undefined8 *)(iVar8 + 8);
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250cae;
        iVar2 = fcn.180222010(uVar6);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250cba;
            uVar3 = fcn.18024fe60(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000080 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000c8 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000d0 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000d8 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000110 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000120 + iVar5 + iVar4));
            goto code_r0x000180250cf0;
        }
    }
    pcVar1 = *(code **)(in_RCX + 0x38);
    if (pcVar1 == (code *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x40);
        iVar2 = *(int32_t *)(in_RCX + 0xb8);
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250ce7;
        iVar2 = (*pcVar1)(iVar2 == 0, in_RCX);
        uVar3 = (uint32_t)(iVar2 != 0);
    } else {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + iVar4) = 0x180250cd3;
        uVar3 = (*pcVar1)(in_RCX);
    }
code_r0x000180250cf0:
    if (((int32_t)uVar3 < 1) && (*(int32_t *)(in_RCX + 0xb8) == 0)) {
        *(int32_t *)(in_RCX + 0xb8) = 1;
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_18024c7b0
// Address: 0x18024c7b0
// Size: 2797 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

uint64_t fcn.18024c7b0(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    char *pcVar13;
    int64_t in_RCX;
    uint64_t uVar14;
    int32_t iVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    int64_t aiStackX_8 [4];
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_48 = 0x18024c7c7;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = *(int64_t *)(in_RCX + 0xf8);
    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
    *(int64_t *)((int64_t)&var_8h + iVar7) = iVar12;
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c7e5;
    iVar2 = fcn.180222010(uVar9);
    uVar14 = 0;
    uVar16 = 3;
    *(undefined4 *)((int64_t)&var_20h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_68h + iVar7) = 3;
    *(undefined4 *)((int64_t)&arg_60h + iVar7) = 0;
    uVar8 = uVar14;
    if ((iVar2 != 1) || (uVar8 = 0, *(int32_t *)(in_RCX + 0x9c) != 1)) {
code_r0x00018024cb27:
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cb2c;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cb44;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cb56;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar7 + -8));
        *(undefined4 *)(in_RCX + 0xb8) = 1;
code_r0x00018024cb60:
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cb68;
        fcn.180221d50(uVar8);
        return 0xffffffff;
    }
    uVar18 = *(int64_t *)(in_RCX + 0x10) != 0;
    if ((iVar12 == 0) || (((*(uint32_t *)(iVar12 + 0x28) & 3) != 0 || ((*(uint32_t *)(iVar12 + 0x28) & 0xc) == 0)))) {
        if ((*(int64_t *)(in_RCX + 0x10) == 0) ||
           (uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14), (uVar4 >> 0xf & 1) != 0)) {
            uVar18 = uVar18 | 2;
        } else if ((uVar4 >> 0x14 & 1) == 0) {
            *(undefined4 *)((int64_t)&arg_78h + iVar7) = 1;
        }
        *(undefined4 *)((int64_t)&var_20h + iVar7) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c87b;
    uVar8 = fcn.180221f20();
    *(uint64_t *)((int64_t)&var_18h + iVar7) = uVar8;
    if (uVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c88d;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c8a5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c8b7;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar7 + -8));
        *(undefined4 *)(in_RCX + 0xb8) = 0x11;
        goto code_r0x00018024cb60;
    }
    if (iVar12 != 0) {
        uVar9 = *(undefined8 *)(iVar12 + 8);
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c8d4;
        iVar2 = fcn.180222010(uVar9);
        if ((0 < iVar2) && (iVar12 = *(int64_t *)(iVar12 + 0x10), iVar12 != 0)) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c8ec;
            iVar2 = func_0x000180237cb0(uVar8, iVar12, 0);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c8f5;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c90d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c91f;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar7 + -8));
                *(undefined4 *)(in_RCX + 0xb8) = 0x11;
                goto code_r0x00018024cb60;
            }
        }
    }
    uVar9 = *(undefined8 *)(in_RCX + 0x10);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c93d;
    iVar2 = func_0x000180237cb0(uVar8, uVar9, 0);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c946;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c95e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c970;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar7 + -8));
        *(undefined4 *)(in_RCX + 0xb8) = 0x11;
        goto code_r0x00018024cb60;
    }
    if (0x3fffffff < *(int32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x20)) {
        *(undefined4 *)(*(int64_t *)(in_RCX + 0x28) + 0x20) = 0x3fffffff;
    }
    iVar2 = *(int32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x20) + 1;
    *(int32_t *)((int64_t)&arg_70h + iVar7) = iVar2;
    if (uVar18 != 0) {
        do {
            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&var_10h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c9c1;
            iVar3 = fcn.180222010(uVar9);
            *(int32_t *)(in_RCX + 0xb4) = iVar3 + -1;
            if ((uVar18 & 2) == 0) {
code_r0x00018024cc58:
                uVar10 = 0;
                if ((uVar18 & 1) == 0) goto code_r0x00018024cec2;
                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cc6e;
                iVar2 = fcn.180222010(uVar9);
                if (iVar2 != *(int32_t *)(in_RCX + 0x9c)) {
code_r0x00018024cb22:
                    uVar8 = *(uint64_t *)((int64_t)&var_18h + iVar7);
                    goto code_r0x00018024cb27;
                }
                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cc8b;
                uVar9 = fcn.180222340(uVar9, iVar2 + -1);
                *(undefined8 *)((int64_t)aiStackX_8 + iVar7 + -8) = uVar9;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cc9a;
                iVar3 = fcn.18024c670(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 0x18), 
                                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                                      *(int64_t *)(&stack0x00000038 + iVar7));
                if ((0 < iVar3) || (*(int32_t *)((int64_t)&arg_70h + iVar7) < iVar2)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar7) = 0;
code_r0x00018024ce9f:
                    uVar16 = (uint64_t)*(uint32_t *)((int64_t)&arg_68h + iVar7);
                    uVar17 = uVar18 & 0xfe;
                    uVar18 = uVar17 | 2;
                    if (*(int32_t *)((int64_t)&var_20h + iVar7) == 0) {
                        uVar18 = uVar17;
                    }
                    goto code_r0x00018024cebb;
                }
                uVar8 = *(uint64_t *)((int64_t)&var_18h + iVar7);
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ccc2;
                iVar2 = fcn.180222010(uVar8);
                uVar14 = uVar10;
                uVar16 = uVar10;
                if (0 < iVar2) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ccdb;
                        uVar10 = fcn.180222340(uVar8, uVar16);
                        if ((*(uint8_t *)(*(int64_t *)((int64_t)aiStackX_8 + iVar7 + -8) + 0xd8) & 0x20) == 0) {
code_r0x00018024ccfd:
                            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cd0c;
                            iVar2 = fcn.180222010(uVar9);
                            iVar3 = 0;
                            if (0 < iVar2) {
                                do {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cd1e;
                                    uVar11 = fcn.180222340(uVar9, iVar3);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cd29;
                                    iVar5 = func_0x000180238200(uVar11, uVar10);
                                    if (iVar5 == 0) {
                                        uVar8 = *(uint64_t *)((int64_t)&var_18h + iVar7);
                                        goto code_r0x00018024cdcd;
                                    }
                                    iVar3 = iVar3 + 1;
                                } while (iVar3 < iVar2);
                            }
                            uVar8 = *(uint64_t *)((int64_t)&var_18h + iVar7);
                        } else {
                            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ccf8;
                            iVar2 = fcn.180222010(uVar9);
                            if (iVar2 != 1) goto code_r0x00018024ccfd;
                        }
                        pcVar1 = *(code **)(in_RCX + 0x50);
                        uVar9 = *(undefined8 *)((int64_t)aiStackX_8 + iVar7 + -8);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cd50;
                        iVar2 = (*pcVar1)(in_RCX, uVar9, uVar10);
                        if (iVar2 != 0) {
                            uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14);
                            if (((uVar4 & 2) == 0) && ((uVar4 >> 0x15 & 1) != 0)) break;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cd76;
                            fcn.1801e8e30(uVar10);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cd81;
                            iVar2 = fcn.18024c3a0(*(int64_t *)((int64_t)&var_20h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar7), 
                                                  *(int64_t *)(&stack0x00000040 + iVar7));
                            if (iVar2 < 0) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cd8d;
                                fcn.180201ea0(uVar10);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cd98;
                                iVar2 = fcn.18024c3a0(*(int64_t *)((int64_t)&var_20h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar7), 
                                                      *(int64_t *)(&stack0x00000040 + iVar7));
                                if (0 < iVar2) break;
                            }
                            if (uVar14 != 0) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cda9;
                                fcn.180201ea0(uVar14);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cdb4;
                                fcn.180201ea0(uVar10);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cdbf;
                                iVar2 = fcn.1802aa1b0(*(int64_t *)((int64_t)&var_20h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + -8), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 0x10), 
                                                      *(int64_t *)(&stack0x00000028 + iVar7), 
                                                      *(int64_t *)(&stack0x00000030 + iVar7));
                                if (iVar2 < 1) goto code_r0x00018024cdcd;
                            }
                            uVar14 = uVar10;
                        }
code_r0x00018024cdcd:
                        uVar10 = uVar14;
                        uVar4 = (int32_t)uVar16 + 1;
                        uVar16 = (uint64_t)uVar4;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cdd8;
                        iVar2 = fcn.180222010(uVar8);
                        uVar14 = uVar10;
                    } while ((int32_t)uVar4 < iVar2);
                }
                *(uint64_t *)((int64_t)&var_10h + iVar7) = uVar10;
                if (uVar10 == 0) goto code_r0x00018024ce9f;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ce01;
                func_0x0001802218c0(uVar8, uVar10);
                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ce18;
                iVar2 = func_0x000180237a90(uVar9, *(undefined8 *)((int64_t)&var_10h + iVar7), 1);
                if (iVar2 == 0) goto code_r0x00018024cb27;
                iVar2 = *(int32_t *)(in_RCX + 0x9c);
                *(int32_t *)(in_RCX + 0x9c) = iVar2 + 1;
                if (((*(int64_t *)(in_RCX + 0xf8) == 0) || ((*(uint8_t *)(*(int64_t *)(in_RCX + 0xf8) + 0x28) & 5) == 0)
                    ) || (iVar2 == 0)) {
code_r0x00018024ce83:
                    uVar14 = (uint64_t)*(uint32_t *)((int64_t)&arg_60h + iVar7);
                    uVar16 = 3;
                    *(undefined4 *)((int64_t)&arg_68h + iVar7) = 3;
                } else {
                    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ce53;
                    iVar12 = fcn.180222340(uVar9, iVar2);
                    if (iVar12 == 0) goto code_r0x00018024ce83;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ce66;
                    uVar4 = func_0x00018024f970(in_RCX, iVar12, iVar2);
                    *(uint32_t *)((int64_t)&arg_68h + iVar7) = uVar4;
                    uVar16 = (uint64_t)uVar4;
                    if (-1 < (int32_t)uVar4) {
                        if ((int32_t)uVar4 < 1) goto code_r0x00018024ce83;
                        *(int32_t *)(in_RCX + 0x9c) = iVar2 + -1;
                        iVar2 = 1;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cf6f;
                        fcn.180221d50(uVar8);
                        goto code_r0x00018024cf6f;
                    }
                    uVar14 = (uint64_t)*(uint32_t *)((int64_t)&arg_60h + iVar7);
                }
            } else {
                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                iVar5 = (int32_t)uVar14;
                if ((uVar18 & 4) == 0) {
                    iVar5 = iVar3;
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024c9ee;
                uVar9 = fcn.180222340(uVar9, iVar5 + -1);
                if (iVar2 < iVar3) {
code_r0x00018024cbf3:
                    if ((uVar18 & 1) != 0) {
                        uVar4 = *(uint32_t *)((int64_t)&arg_60h + iVar7);
code_r0x00018024cc55:
                        uVar14 = (uint64_t)uVar4;
                        goto code_r0x00018024cc58;
                    }
                    if ((uVar18 & 4) != 0) {
                        uVar4 = *(int32_t *)((int64_t)&arg_60h + iVar7) - 1;
                        uVar14 = (uint64_t)uVar4;
                        *(uint32_t *)((int64_t)&arg_60h + iVar7) = uVar4;
                        if ((int32_t)uVar4 < 1) goto code_r0x00018024cc19;
                        goto code_r0x00018024cec2;
                    }
code_r0x00018024cc19:
                    if (((*(int32_t *)((int64_t)&arg_78h + iVar7) != 0) && ((uVar18 & 4) == 0)) &&
                       (1 < *(int32_t *)(in_RCX + 0x9c))) {
                        uVar4 = *(int32_t *)(in_RCX + 0x9c) - 1;
                        uVar18 = uVar18 | 4;
                        *(uint32_t *)((int64_t)&arg_60h + iVar7) = uVar4;
                        goto code_r0x00018024cc55;
                    }
code_r0x00018024d09a:
                    uVar8 = *(uint64_t *)((int64_t)&var_18h + iVar7);
                    break;
                }
                uVar11 = *(undefined8 *)(in_RCX + 0xa0);
                pcVar1 = *(code **)(in_RCX + 0x48);
                *(undefined8 *)(in_RCX + 0xa0) = 0;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ca1d;
                iVar2 = (*pcVar1)((int64_t)&var_10h + iVar7, in_RCX, uVar9);
                *(undefined8 *)(in_RCX + 0xa0) = uVar11;
                if (iVar2 < 0) {
                    uVar9 = *(undefined8 *)((int64_t)&var_18h + iVar7);
                    *(undefined4 *)(in_RCX + 0xb8) = 0x46;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cf50;
                    fcn.180221d50(uVar9);
                    return 0xffffffff;
                }
                if (iVar2 < 1) goto code_r0x00018024cbf3;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ca3c;
                iVar2 = fcn.18024c670(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 0x18), 
                                      *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                                      *(int64_t *)(&stack0x00000038 + iVar7));
                if (iVar2 < 0) {
code_r0x00018024cedf:
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cee9;
                    fcn.18021fe80(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8)
                                 );
                    goto code_r0x00018024cb22;
                }
                if ((uVar18 & 4) == 0) {
                    if (iVar2 == 0) goto code_r0x00018024caf3;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cb8b;
                    iVar5 = func_0x000180238200(uVar9, *(undefined8 *)((int64_t)&var_10h + iVar7));
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cb99;
                        fcn.18021fe80(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
                        goto code_r0x00018024cbf3;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cba3;
                    fcn.18021fe80(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8)
                                 );
                    uVar9 = *(undefined8 *)((int64_t)&var_10h + iVar7);
                    iVar3 = iVar3 + -1;
                    uVar11 = *(undefined8 *)(in_RCX + 0xa0);
                    *(int32_t *)(in_RCX + 0x9c) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cbbe;
                    fcn.1802221b0(uVar11, iVar3, uVar9);
                } else {
                    if (((iVar3 <= iVar5) || (iVar5 < 1)) || (iVar2 != 0)) goto code_r0x00018024cedf;
                    uVar18 = uVar18 & 0xfb;
                    do {
                        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ca7c;
                        func_0x000180222020(uVar9);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024ca84;
                        fcn.18021fe80(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
                        iVar3 = iVar3 + -1;
                    } while (iVar5 < iVar3);
                    iVar12 = *(int64_t *)((int64_t)&var_8h + iVar7);
                    *(int32_t *)(in_RCX + 0x9c) = iVar3;
                    if (iVar12 != 0) {
                        uVar9 = *(undefined8 *)(iVar12 + 8);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024caa3;
                        iVar2 = fcn.180222010(uVar9);
                        if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x9c) <= *(int32_t *)(iVar12 + 0x2c))) {
                            *(undefined4 *)(iVar12 + 0x2c) = 0xffffffff;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cac2;
                            fcn.18021fe80(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
                            *(undefined8 *)(iVar12 + 0x20) = 0;
                        }
                        uVar9 = *(undefined8 *)(iVar12 + 8);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cad3;
                        iVar2 = fcn.180222010(uVar9);
                        if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x9c) <= *(int32_t *)(iVar12 + 0x30))) {
                            *(undefined4 *)(iVar12 + 0x30) = 0xffffffff;
                        }
                    }
code_r0x00018024caf3:
                    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cb04;
                    iVar2 = fcn.180222110(uVar9, *(undefined8 *)((int64_t)&var_10h + iVar7));
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cef3;
                        fcn.18021fe80(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cef8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cf10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cf22;
                        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar7 + -8));
                        uVar8 = *(uint64_t *)((int64_t)&var_18h + iVar7);
                        *(undefined4 *)(in_RCX + 0xb8) = 0x11;
                        goto code_r0x00018024cb60;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cb18;
                    iVar2 = fcn.18024c670(*(int64_t *)((int64_t)&var_20h + iVar7), 
                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)&var_10h + iVar7), 
                                          *(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 0x18), 
                                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7)
                                          , *(int64_t *)(&stack0x00000038 + iVar7));
                    if (iVar2 < 0) goto code_r0x00018024cb22;
                }
                if (iVar3 < *(int32_t *)(in_RCX + 0x9c)) goto code_r0x00018024cb22;
                uVar18 = uVar18 & 0xfe;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cbd8;
                uVar4 = func_0x00018024f170(in_RCX, iVar3);
                *(uint32_t *)((int64_t)&arg_68h + iVar7) = uVar4;
                uVar16 = (uint64_t)uVar4;
                if (uVar4 != 3) goto code_r0x00018024d09a;
                if (iVar2 != 0) goto code_r0x00018024cbf3;
code_r0x00018024cebb:
                uVar14 = (uint64_t)*(uint32_t *)((int64_t)&arg_60h + iVar7);
code_r0x00018024cec2:
                uVar8 = *(uint64_t *)((int64_t)&var_18h + iVar7);
            }
            if (uVar18 == 0) break;
            iVar2 = *(int32_t *)((int64_t)&arg_70h + iVar7);
        } while( true );
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d0a7;
    fcn.180221d50(uVar8);
    iVar2 = (int32_t)uVar16;
    if (iVar2 < 0) {
        return uVar16;
    }
code_r0x00018024cf6f:
    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cf7b;
    iVar5 = fcn.180222010(uVar9);
    iVar3 = *(int32_t *)((int64_t)&arg_70h + iVar7);
    if ((iVar5 <= iVar3) && (iVar2 == 3)) {
        if ((*(int64_t *)((int64_t)&var_8h + iVar7) != 0) &&
           ((*(uint8_t *)(*(int64_t *)((int64_t)&var_8h + iVar7) + 0x28) & 4) != 0)) {
            iVar2 = *(int32_t *)(in_RCX + 0x9c);
            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
            iVar12 = *(int64_t *)(in_RCX + 0xf8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cfc8;
            uVar11 = fcn.180222340(uVar9, iVar2 + -1);
            uVar9 = *(undefined8 *)(iVar12 + 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cfd4;
            iVar3 = fcn.180222010(uVar9);
            iVar15 = 0;
            if (0 < iVar3) {
                do {
                    uVar9 = *(undefined8 *)(iVar12 + 8);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024cfeb;
                    pcVar13 = (char *)fcn.180222340(uVar9, iVar15);
                    if (((*pcVar13 == '\x02') && (pcVar13[1] == '\x01')) && (pcVar13[2] == '\0')) {
                        uVar9 = *(undefined8 *)(pcVar13 + 0x18);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d00b;
                        iVar6 = func_0x0001802405a0(uVar11, uVar9);
                        if (0 < iVar6) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d0c1;
                            fcn.18021fe80(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
                            *(undefined8 *)(iVar12 + 0x20) = 0;
                            *(undefined4 *)(in_RCX + 0x100) = 1;
                            *(int32_t *)(iVar12 + 0x2c) = iVar2 + -1;
                            *(char **)(iVar12 + 0x18) = pcVar13;
                            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d0eb;
                            iVar2 = fcn.180222010(uVar9);
                            if (iVar2 <= *(int32_t *)(in_RCX + 0x9c)) {
                                return 1;
                            }
                            do {
                                uVar9 = *(undefined8 *)(in_RCX + 0xa0);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d10c;
                                func_0x000180222020(uVar9);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d114;
                                fcn.18021fe80(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8));
                                iVar2 = iVar2 + -1;
                            } while (*(int32_t *)(in_RCX + 0x9c) < iVar2);
                            return 1;
                        }
                    }
                    iVar15 = iVar15 + 1;
                } while (iVar15 < iVar3);
            }
            iVar3 = *(int32_t *)((int64_t)&arg_70h + iVar7);
            iVar2 = 3;
        }
        if (iVar5 == *(int32_t *)(in_RCX + 0x9c)) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d039;
            iVar2 = func_0x00018024f170(in_RCX, iVar5);
        }
    }
    if (iVar2 == 1) {
        return 1;
    }
    if (iVar2 == 2) {
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 0xb8);
    if (iVar2 != 0) {
        if (iVar2 == 9) {
            return 0;
        }
        if (iVar2 == 10) {
            return 0;
        }
        if (iVar2 == 0xd) {
            return 0;
        }
        if (iVar2 == 0xe) {
            return 0;
        }
        iVar5 = iVar5 + -1;
        if (iVar5 < 0) {
            iVar5 = *(int32_t *)(in_RCX + 0xb4);
        } else {
            *(int32_t *)(in_RCX + 0xb4) = iVar5;
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d13a;
        uVar9 = fcn.180222340(uVar9, iVar5);
        *(undefined8 *)(in_RCX + 0xc0) = uVar9;
        if (iVar2 != 0) {
            *(int32_t *)(in_RCX + 0xb8) = iVar2;
        }
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d156;
        uVar8 = (*pcVar1)(0, in_RCX);
        return uVar8;
    }
    if (iVar3 < iVar5) {
        iVar2 = iVar5 + -1;
        if (iVar2 < 0) {
            iVar2 = *(int32_t *)(in_RCX + 0xb4);
        } else {
            *(int32_t *)(in_RCX + 0xb4) = iVar2;
        }
        uVar9 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d180;
        uVar9 = fcn.180222340(uVar9, iVar2);
        *(undefined8 *)(in_RCX + 0xc0) = uVar9;
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x16;
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d19c;
        iVar2 = (*pcVar1)(0, in_RCX);
        if (iVar2 == 0) {
            return 0;
        }
    }
    iVar12 = *(int64_t *)((int64_t)&var_8h + iVar7);
    if (iVar12 != 0) {
        uVar9 = *(undefined8 *)(iVar12 + 8);
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d1b7;
        iVar2 = fcn.180222010(uVar9);
        if ((0 < iVar2) && (((*(uint8_t *)(iVar12 + 0x28) & 3) == 0 || (-1 < *(int32_t *)(iVar12 + 0x30))))) {
            iVar2 = iVar5 + -1;
            if (iVar2 < 0) {
                iVar2 = *(int32_t *)(in_RCX + 0xb4);
            } else {
                *(int32_t *)(in_RCX + 0xb4) = iVar2;
            }
            uVar9 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d1e8;
            uVar9 = fcn.180222340(uVar9, iVar2);
            *(undefined8 *)(in_RCX + 0xc0) = uVar9;
            pcVar1 = *(code **)(in_RCX + 0x40);
            *(undefined4 *)(in_RCX + 0xb8) = 0x41;
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d204;
            iVar2 = (*pcVar1)(0, in_RCX);
            if (iVar2 == 0) {
                return 0;
            }
        }
    }
    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
    iVar2 = iVar5 + -1;
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d21d;
    fcn.180222340(uVar9, iVar2);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d227;
    iVar3 = fcn.18024c670(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 0x18), *(int64_t *)(&stack0x00000028 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7));
    if (iVar3 < 1) {
        iVar3 = 0x14;
        if (*(int32_t *)(in_RCX + 0x9c) < iVar5) {
            iVar3 = 2;
        }
        if (iVar2 < 0) {
            iVar2 = *(int32_t *)(in_RCX + 0xb4);
            goto code_r0x00018024d24c;
        }
    } else {
        iVar3 = (iVar5 != 1) + 0x12;
        if (iVar2 < 0) {
            iVar2 = *(int32_t *)(in_RCX + 0xb4);
            goto code_r0x00018024d24c;
        }
    }
    *(int32_t *)(in_RCX + 0xb4) = iVar2;
code_r0x00018024d24c:
    uVar9 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d25a;
    uVar9 = fcn.180222340(uVar9, iVar2);
    *(undefined8 *)(in_RCX + 0xc0) = uVar9;
    pcVar1 = *(code **)(in_RCX + 0x40);
    *(int32_t *)(in_RCX + 0xb8) = iVar3;
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18024d272;
    uVar8 = (*pcVar1)(0, in_RCX);
    return uVar8;
}

// ============================================================
// Function: FUN_18024d2a0
// Address: 0x18024d2a0
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18024d2a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024d2b5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (((*(uint8_t *)(*(int64_t *)(in_RCX + 0x28) + 0x14) & 0x10) == 0) &&
       ((*(uint32_t *)(in_RDX + 0x7c) & 0x200) != 0)) {
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x24;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024d2e9;
        uVar4 = (*pcVar1)(0, in_RCX);
        if ((int32_t)uVar4 == 0) {
            return uVar4;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024d30d;
    iVar2 = fcn.18028ebb0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
    if (iVar2 != 0) {
        if (*(int32_t *)(*(int64_t *)((int64_t)&arg_28h + iVar3) + 0x30) == 8) {
            return 2;
        }
        pcVar1 = *(code **)(in_RCX + 0x40);
        *(undefined4 *)(in_RCX + 0xb8) = 0x17;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024d346;
        iVar2 = (*pcVar1)(0, in_RCX);
        return (uint64_t)(iVar2 != 0);
    }
    return 1;
}

// ============================================================
// Function: FUN_18024d380
// Address: 0x18024d380
// Size: 426 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18024d380(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int32_t iVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18024d3a2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar2 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d3b4;
    iVar4 = fcn.180222010(uVar2);
    if ((0 < *(int32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x24)) && (iVar9 = 0, 0 < iVar4)) {
        do {
            uVar2 = *(undefined8 *)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d3ee;
            iVar7 = fcn.180222340(uVar2, iVar9);
            if (0 < iVar9) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d3fd;
                iVar8 = fcn.180238400(iVar7);
                uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x28) + 0x24);
                if (0 < (int32_t)uVar1) {
                    if (iVar8 != 0) {
                        if (5 < (int32_t)uVar1) {
                            uVar1 = 5;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d41c;
                        iVar5 = fcn.18022fb60(iVar8);
                        if (*(int32_t *)((uint64_t)uVar1 * 4 + 0x1804e4894) <= iVar5) goto code_r0x00018024d465;
                    }
                    *(int32_t *)(in_RCX + 0xb4) = iVar9;
                    iVar8 = iVar7;
                    if (iVar7 == 0) {
                        uVar2 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d441;
                        iVar8 = fcn.180222340(uVar2, iVar9);
                    }
                    *(int64_t *)(in_RCX + 0xc0) = iVar8;
                    pcVar3 = *(code **)(in_RCX + 0x40);
                    *(undefined4 *)(in_RCX + 0xb8) = 0x43;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d45d;
                    iVar5 = (*pcVar3)(0, in_RCX);
                    if (iVar5 == 0) {
                        return 0;
                    }
                }
            }
code_r0x00018024d465:
            if (iVar9 < iVar4 + -1) {
                iVar8 = *(int64_t *)(in_RCX + 0x28);
                *(undefined4 *)((int64_t)&arg_38h + iVar6) = 0xffffffff;
                uVar1 = *(uint32_t *)(iVar8 + 0x24);
                if (0 < (int32_t)uVar1) {
                    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
                    if (5 < (int32_t)uVar1) {
                        uVar1 = 5;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d4a2;
                    iVar5 = func_0x000180237500(iVar7, 0, 0, (int64_t)&arg_38h + iVar6);
                    if ((iVar5 == 0) ||
                       (*(int32_t *)((int64_t)&arg_38h + iVar6) < *(int32_t *)((uint64_t)uVar1 * 4 + 0x1804e4894))) {
                        if (iVar9 < 0) {
                            iVar5 = *(int32_t *)(in_RCX + 0xb4);
                        } else {
                            *(int32_t *)(in_RCX + 0xb4) = iVar9;
                            iVar5 = iVar9;
                        }
                        if (iVar7 == 0) {
                            uVar2 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d4d6;
                            iVar7 = fcn.180222340(uVar2, iVar5);
                        }
                        pcVar3 = *(code **)(in_RCX + 0x40);
                        *(int64_t *)(in_RCX + 0xc0) = iVar7;
                        *(undefined4 *)(in_RCX + 0xb8) = 0x44;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024d4f5;
                        iVar5 = (*pcVar3)(0, in_RCX);
                        if (iVar5 == 0) {
                            return 0;
                        }
                    }
                }
            }
            iVar9 = iVar9 + 1;
        } while (iVar9 < iVar4);
    }
    return 1;
}

// ============================================================
// Function: FUN_18024d530
// Address: 0x18024d530
// Size: 99 bytes
// ============================================================
int32_t fcn.18024d530(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined4 uVar1;
    int32_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int32_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18024d543;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined4 *)(in_RCX + 0xb4);
    uVar8 = *(undefined8 *)(in_RCX + 0xa0);
    var_18h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d561;
    iVar6 = fcn.180222340(uVar8, uVar1);
    *(int64_t *)(in_RCX + 0xc0) = iVar6;
    *(undefined8 *)(in_RCX + 200) = 0;
    *(undefined8 *)(in_RCX + 0xd8) = 0;
    if (((*(uint32_t *)(iVar6 + 0xd8) >> 0xd & 1) != 0) || ((*(uint32_t *)(iVar6 + 0xd8) >> 10 & 1) != 0)) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_R14;
    iVar9 = 0;
    do {
        pcVar3 = *(code **)(in_RCX + 0x60);
        if (pcVar3 == (code *)0x0) {
            var_58h = 0;
            var_8h._0_4_ = 0;
            var_20h = 0;
            var_50h = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d5e1;
            uVar8 = fcn.1801e3990(iVar6);
            var_10h._0_4_ = *(undefined4 *)(in_RCX + 0xdc);
            *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x18);
            *(int64_t **)((int64_t)&var_8h + iVar5) = &var_10h;
            *(int64_t **)(&stack0x00000000 + iVar5) = &var_8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d61c;
            iVar4 = func_0x000180250230(in_RCX, &var_20h, &var_50h, &var_58h);
            if (iVar4 == 0) {
                pcVar3 = *(code **)(in_RCX + 0x88);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d62f;
                iVar7 = (*pcVar3)(in_RCX, uVar8);
                if ((iVar7 != 0) || (var_20h == 0)) {
                    *(int64_t *)((int64_t)&var_10h + iVar5) = iVar7;
                    *(int64_t **)((int64_t)&var_8h + iVar5) = &var_10h;
                    *(int64_t **)(&stack0x00000000 + iVar5) = &var_8h;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d66b;
                    func_0x000180250230(in_RCX, &var_20h, &var_50h, &var_58h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d67a;
                    fcn.180222050(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar5));
                    goto code_r0x00018024d67a;
                }
            } else {
code_r0x00018024d67a:
                iVar7 = 0;
                if (var_20h == 0) goto code_r0x00018024d6b1;
            }
            *(int64_t *)(in_RCX + 200) = var_58h;
            *(undefined4 *)(in_RCX + 0xd8) = (undefined4)var_8h;
            *(undefined4 *)(in_RCX + 0xdc) = (undefined4)var_10h;
            iVar4 = 1;
            var_18h = var_20h;
            iVar7 = var_50h;
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d5c5;
            iVar7 = (*pcVar3)(in_RCX, &var_18h, iVar6);
code_r0x00018024d6b1:
            iVar4 = (int32_t)iVar7;
            iVar7 = 0;
        }
        if (iVar4 == 0) {
code_r0x00018024d763:
            pcVar3 = *(code **)(in_RCX + 0x40);
            *(undefined4 *)(in_RCX + 0xb8) = 3;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d778;
            iVar4 = (*pcVar3)(0, in_RCX);
            break;
        }
        pcVar3 = *(code **)(in_RCX + 0x68);
        *(int64_t *)(in_RCX + 0xd0) = var_18h;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d6da;
        iVar4 = (*pcVar3)(in_RCX);
        if (iVar4 == 0) break;
        if (iVar7 == 0) {
code_r0x00018024d715:
            pcVar3 = *(code **)(in_RCX + 0x70);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d725;
            iVar4 = (*pcVar3)(in_RCX, var_18h, iVar6);
            if (iVar4 == 0) break;
        } else {
            pcVar3 = *(code **)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d6f5;
            iVar4 = (*pcVar3)(in_RCX, iVar7);
            if (iVar4 == 0) break;
            pcVar3 = *(code **)(in_RCX + 0x70);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d70a;
            iVar4 = (*pcVar3)(in_RCX, iVar7, iVar6);
            if (iVar4 == 0) break;
            if (iVar4 != 2) goto code_r0x00018024d715;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d734;
        func_0x00018028eb90(var_18h);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d73c;
        func_0x00018028eb90(iVar7);
        iVar2 = *(int32_t *)(in_RCX + 0xdc);
        iVar7 = 0;
        var_18h = 0;
        if (iVar9 == iVar2) goto code_r0x00018024d763;
        iVar9 = iVar2;
    } while (iVar2 != 0x807f);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d783;
    func_0x00018028eb90(var_18h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d78b;
    func_0x00018028eb90(iVar7);
    *(undefined8 *)(in_RCX + 0xd0) = 0;
    return iVar4;
}

// ============================================================
// Function: FUN_18024d593
// Address: 0x18024d593
// Size: 543 bytes
// ============================================================
int32_t fcn.18024d530(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined4 uVar1;
    int32_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int32_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18024d543;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined4 *)(in_RCX + 0xb4);
    uVar8 = *(undefined8 *)(in_RCX + 0xa0);
    var_18h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d561;
    iVar6 = fcn.180222340(uVar8, uVar1);
    *(int64_t *)(in_RCX + 0xc0) = iVar6;
    *(undefined8 *)(in_RCX + 200) = 0;
    *(undefined8 *)(in_RCX + 0xd8) = 0;
    if (((*(uint32_t *)(iVar6 + 0xd8) >> 0xd & 1) != 0) || ((*(uint32_t *)(iVar6 + 0xd8) >> 10 & 1) != 0)) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_R14;
    iVar9 = 0;
    do {
        pcVar3 = *(code **)(in_RCX + 0x60);
        if (pcVar3 == (code *)0x0) {
            var_58h = 0;
            var_8h._0_4_ = 0;
            var_20h = 0;
            var_50h = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d5e1;
            uVar8 = fcn.1801e3990(iVar6);
            var_10h._0_4_ = *(undefined4 *)(in_RCX + 0xdc);
            *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x18);
            *(int64_t **)((int64_t)&var_8h + iVar5) = &var_10h;
            *(int64_t **)(&stack0x00000000 + iVar5) = &var_8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d61c;
            iVar4 = func_0x000180250230(in_RCX, &var_20h, &var_50h, &var_58h);
            if (iVar4 == 0) {
                pcVar3 = *(code **)(in_RCX + 0x88);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d62f;
                iVar7 = (*pcVar3)(in_RCX, uVar8);
                if ((iVar7 != 0) || (var_20h == 0)) {
                    *(int64_t *)((int64_t)&var_10h + iVar5) = iVar7;
                    *(int64_t **)((int64_t)&var_8h + iVar5) = &var_10h;
                    *(int64_t **)(&stack0x00000000 + iVar5) = &var_8h;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d66b;
                    func_0x000180250230(in_RCX, &var_20h, &var_50h, &var_58h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d67a;
                    fcn.180222050(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar5));
                    goto code_r0x00018024d67a;
                }
            } else {
code_r0x00018024d67a:
                iVar7 = 0;
                if (var_20h == 0) goto code_r0x00018024d6b1;
            }
            *(int64_t *)(in_RCX + 200) = var_58h;
            *(undefined4 *)(in_RCX + 0xd8) = (undefined4)var_8h;
            *(undefined4 *)(in_RCX + 0xdc) = (undefined4)var_10h;
            iVar4 = 1;
            var_18h = var_20h;
            iVar7 = var_50h;
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d5c5;
            iVar7 = (*pcVar3)(in_RCX, &var_18h, iVar6);
code_r0x00018024d6b1:
            iVar4 = (int32_t)iVar7;
            iVar7 = 0;
        }
        if (iVar4 == 0) {
code_r0x00018024d763:
            pcVar3 = *(code **)(in_RCX + 0x40);
            *(undefined4 *)(in_RCX + 0xb8) = 3;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d778;
            iVar4 = (*pcVar3)(0, in_RCX);
            break;
        }
        pcVar3 = *(code **)(in_RCX + 0x68);
        *(int64_t *)(in_RCX + 0xd0) = var_18h;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d6da;
        iVar4 = (*pcVar3)(in_RCX);
        if (iVar4 == 0) break;
        if (iVar7 == 0) {
code_r0x00018024d715:
            pcVar3 = *(code **)(in_RCX + 0x70);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d725;
            iVar4 = (*pcVar3)(in_RCX, var_18h, iVar6);
            if (iVar4 == 0) break;
        } else {
            pcVar3 = *(code **)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d6f5;
            iVar4 = (*pcVar3)(in_RCX, iVar7);
            if (iVar4 == 0) break;
            pcVar3 = *(code **)(in_RCX + 0x70);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d70a;
            iVar4 = (*pcVar3)(in_RCX, iVar7, iVar6);
            if (iVar4 == 0) break;
            if (iVar4 != 2) goto code_r0x00018024d715;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d734;
        func_0x00018028eb90(var_18h);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d73c;
        func_0x00018028eb90(iVar7);
        iVar2 = *(int32_t *)(in_RCX + 0xdc);
        iVar7 = 0;
        var_18h = 0;
        if (iVar9 == iVar2) goto code_r0x00018024d763;
        iVar9 = iVar2;
    } while (iVar2 != 0x807f);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d783;
    func_0x00018028eb90(var_18h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d78b;
    func_0x00018028eb90(iVar7);
    *(undefined8 *)(in_RCX + 0xd0) = 0;
    return iVar4;
}

// ============================================================
// Function: FUN_18024d7b2
// Address: 0x18024d7b2
// Size: 15 bytes
// ============================================================
int32_t fcn.18024d530(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined4 uVar1;
    int32_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int32_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18024d543;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined4 *)(in_RCX + 0xb4);
    uVar8 = *(undefined8 *)(in_RCX + 0xa0);
    var_18h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d561;
    iVar6 = fcn.180222340(uVar8, uVar1);
    *(int64_t *)(in_RCX + 0xc0) = iVar6;
    *(undefined8 *)(in_RCX + 200) = 0;
    *(undefined8 *)(in_RCX + 0xd8) = 0;
    if (((*(uint32_t *)(iVar6 + 0xd8) >> 0xd & 1) != 0) || ((*(uint32_t *)(iVar6 + 0xd8) >> 10 & 1) != 0)) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_R14;
    iVar9 = 0;
    do {
        pcVar3 = *(code **)(in_RCX + 0x60);
        if (pcVar3 == (code *)0x0) {
            var_58h = 0;
            var_8h._0_4_ = 0;
            var_20h = 0;
            var_50h = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d5e1;
            uVar8 = fcn.1801e3990(iVar6);
            var_10h._0_4_ = *(undefined4 *)(in_RCX + 0xdc);
            *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x18);
            *(int64_t **)((int64_t)&var_8h + iVar5) = &var_10h;
            *(int64_t **)(&stack0x00000000 + iVar5) = &var_8h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d61c;
            iVar4 = func_0x000180250230(in_RCX, &var_20h, &var_50h, &var_58h);
            if (iVar4 == 0) {
                pcVar3 = *(code **)(in_RCX + 0x88);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d62f;
                iVar7 = (*pcVar3)(in_RCX, uVar8);
                if ((iVar7 != 0) || (var_20h == 0)) {
                    *(int64_t *)((int64_t)&var_10h + iVar5) = iVar7;
                    *(int64_t **)((int64_t)&var_8h + iVar5) = &var_10h;
                    *(int64_t **)(&stack0x00000000 + iVar5) = &var_8h;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d66b;
                    func_0x000180250230(in_RCX, &var_20h, &var_50h, &var_58h);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d67a;
                    fcn.180222050(*(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar5));
                    goto code_r0x00018024d67a;
                }
            } else {
code_r0x00018024d67a:
                iVar7 = 0;
                if (var_20h == 0) goto code_r0x00018024d6b1;
            }
            *(int64_t *)(in_RCX + 200) = var_58h;
            *(undefined4 *)(in_RCX + 0xd8) = (undefined4)var_8h;
            *(undefined4 *)(in_RCX + 0xdc) = (undefined4)var_10h;
            iVar4 = 1;
            var_18h = var_20h;
            iVar7 = var_50h;
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d5c5;
            iVar7 = (*pcVar3)(in_RCX, &var_18h, iVar6);
code_r0x00018024d6b1:
            iVar4 = (int32_t)iVar7;
            iVar7 = 0;
        }
        if (iVar4 == 0) {
code_r0x00018024d763:
            pcVar3 = *(code **)(in_RCX + 0x40);
            *(undefined4 *)(in_RCX + 0xb8) = 3;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d778;
            iVar4 = (*pcVar3)(0, in_RCX);
            break;
        }
        pcVar3 = *(code **)(in_RCX + 0x68);
        *(int64_t *)(in_RCX + 0xd0) = var_18h;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d6da;
        iVar4 = (*pcVar3)(in_RCX);
        if (iVar4 == 0) break;
        if (iVar7 == 0) {
code_r0x00018024d715:
            pcVar3 = *(code **)(in_RCX + 0x70);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d725;
            iVar4 = (*pcVar3)(in_RCX, var_18h, iVar6);
            if (iVar4 == 0) break;
        } else {
            pcVar3 = *(code **)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d6f5;
            iVar4 = (*pcVar3)(in_RCX, iVar7);
            if (iVar4 == 0) break;
            pcVar3 = *(code **)(in_RCX + 0x70);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d70a;
            iVar4 = (*pcVar3)(in_RCX, iVar7, iVar6);
            if (iVar4 == 0) break;
            if (iVar4 != 2) goto code_r0x00018024d715;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d734;
        func_0x00018028eb90(var_18h);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d73c;
        func_0x00018028eb90(iVar7);
        iVar2 = *(int32_t *)(in_RCX + 0xdc);
        iVar7 = 0;
        var_18h = 0;
        if (iVar9 == iVar2) goto code_r0x00018024d763;
        iVar9 = iVar2;
    } while (iVar2 != 0x807f);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d783;
    func_0x00018028eb90(var_18h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024d78b;
    func_0x00018028eb90(iVar7);
    *(undefined8 *)(in_RCX + 0xd0) = 0;
    return iVar4;
}

// ============================================================
// Function: FUN_18024d7d0
// Address: 0x18024d7d0
// Size: 106 bytes
// ============================================================
bool fcn.18024d7d0(int64_t param_1, undefined8 param_2)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024d7dc;
    iVar3 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18024d7ea;
    iVar4 = fcn.180238400(param_2);
    uVar1 = *(uint32_t *)(*(int64_t *)(param_1 + 0x28) + 0x24);
    if ((int32_t)uVar1 < 1) {
        return true;
    }
    if (iVar4 == 0) {
        return false;
    }
    if (5 < (int32_t)uVar1) {
        uVar1 = 5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18024d821;
    iVar2 = fcn.18022fb60(iVar4);
    return *(int32_t *)((uint64_t)uVar1 * 4 + 0x1804e4894) <= iVar2;
}

// ============================================================
// Function: FUN_18024d840
// Address: 0x18024d840
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18024d840(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    undefined8 *in_RCX;
    uint32_t uVar10;
    uint64_t uVar12;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    int64_t var_8h;
    uint64_t uVar11;
    
    uStack_38 = 0x18024d853;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar12 = 0;
    uVar7 = in_RCX[4];
    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d868;
    iVar1 = fcn.180222010(uVar7);
    if ((-1 < iVar1) && (*(int32_t *)((int64_t)in_RCX + 0xb4) < iVar1)) {
        uVar7 = in_RCX[4];
        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d887;
        iVar5 = fcn.180222340(uVar7);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d89b;
            iVar6 = func_0x00018023f020(iVar5);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d8af;
                iVar1 = func_0x00018023eea0(iVar6);
                if (0 < iVar1) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d8c3;
                    iVar2 = func_0x00018023f0d0(iVar5);
                    if (iVar2 == 0) {
                        uVar7 = *in_RCX;
                        uVar8 = in_RCX[0x14];
                        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d8ee;
                        iVar2 = func_0x0001802caa80(iVar6, uVar8, uVar7, 0x200);
                        if (iVar2 < 1) {
                            uVar9 = 0;
                            iVar1 = 0x61;
                        } else {
                            *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R14;
                            uVar11 = uVar12;
                            do {
                                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d90e;
                                uVar7 = func_0x00018023eff0(iVar6, uVar11);
                                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d916;
                                uVar7 = func_0x00018001ed90(uVar7);
                                *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar7;
                                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d933;
                                func_0x000180265cd0(0, (int64_t)&arg_70h + iVar4, 0, 0);
                                uVar9 = uVar12;
                                if (*(int64_t *)((int64_t)&arg_70h + iVar4) != 0) {
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d945;
                                    uVar3 = fcn.18022cd20(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                                          *(int64_t *)((int64_t)&iStackX_8 + iVar4), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar4), 
                                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                                          *(int64_t *)(&stack0x00000038 + iVar4));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d94c;
                                    uVar8 = fcn.18022ccf0(uVar3);
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d954;
                                    uVar9 = func_0x00018022e160(uVar8);
                                }
                                uVar8 = in_RCX[0x18];
                                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d96f;
                                uVar9 = func_0x0001802aea40(uVar9, uVar8);
                                if (uVar9 == 0) {
code_r0x00018024da20:
                                    iVar1 = 0x60;
                                    goto code_r0x00018024da2a;
                                }
                                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d986;
                                iVar2 = func_0x0001802aec30(uVar9, uVar7);
                                if (iVar2 == 0) {
                                    *(int64_t *)(&stack0x00000000 + iVar4) = (int64_t)&arg_78h + iVar4;
                                    *(int64_t *)((int64_t)&var_8h + iVar4) = (int64_t)&iStackX_10 + iVar4;
                                    *(int64_t *)((int64_t)&var_10h + iVar4) = (int64_t)&var_18h + iVar4;
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d9e6;
                                    iVar1 = func_0x00018023eed0(iVar6, uVar9, (int64_t)&arg_60h + iVar4, 
                                                                (int64_t)&arg_68h + iVar4);
                                    if (iVar1 < 1) goto code_r0x00018024da20;
                                    iVar1 = *(int32_t *)((int64_t)&arg_60h + iVar4);
                                    if (*(int32_t *)((int64_t)&arg_60h + iVar4) == 0) {
                                        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024da13;
                                        iVar2 = func_0x00018023ecb0(*(undefined8 *)((int64_t)&iStackX_10 + iVar4), 
                                                                    *(undefined8 *)((int64_t)&arg_78h + iVar4), 300, 
                                                                    0xffffffff);
                                        iVar1 = 99;
                                        if (iVar2 != 0) {
                                            iVar1 = 0;
                                        }
                                    }
                                    goto code_r0x00018024da2a;
                                }
                                *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d992;
                                func_0x00018023f1c0(uVar9);
                                uVar10 = (int32_t)uVar11 + 1;
                                uVar11 = (uint64_t)uVar10;
                            } while ((int32_t)uVar10 < iVar1);
                            uVar9 = uVar12;
                            iVar1 = 100;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024d8cf;
                        func_0x00018023f190();
                        uVar9 = uVar12;
                        iVar1 = 0x60;
                    }
code_r0x00018024da2a:
                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024da32;
                    func_0x00018023f1c0(uVar9);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar4) = 0x18024da3a;
                    func_0x00018023f190(iVar6);
                    return iVar1;
                }
            }
        }
    }
    return 100;
}

