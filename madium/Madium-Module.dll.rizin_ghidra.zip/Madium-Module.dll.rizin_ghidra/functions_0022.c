// Chunk 22 - 50 functions

// ============================================================
// Function: FUN_18003e860
// Address: 0x18003e860
// Size: 31 bytes
// ============================================================
void fcn.18003e860(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.18003e860(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RDI);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x28));
        fcn.180459c3c(arg3, 0x48);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18003e87f
// Address: 0x18003e87f
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18003e860(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.18003e860(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RDI);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x28));
        fcn.180459c3c(arg3, 0x48);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18003e8c9
// Address: 0x18003e8c9
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18003e860(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.18003e860(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RDI);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x28));
        fcn.180459c3c(arg3, 0x48);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18003e8e0
// Address: 0x18003e8e0
// Size: 147 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003e8e0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    *(undefined8 *)(arg1 + 0x10) = 0x180622970;
    if (*(int64_t **)(arg1 + 0x280) != (int64_t *)0x0) {
        (**(code **)(**(int64_t **)(arg1 + 0x280) + 0x10))();
        *(undefined8 *)(arg1 + 0x280) = 0;
    }
    iVar1 = *(int64_t *)(arg1 + 0x48);
    if (iVar1 != *(int64_t *)(arg1 + 0x50)) {
        *(int64_t *)(arg1 + 0x50) = iVar1;
    }
    if (iVar1 != 0) {
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x58) - iVar1)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18003e95c;
        fcn.180459c3c(iVar3);
        *(undefined8 *)(arg1 + 0x48) = 0;
        *(undefined8 *)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18003e9b0
// Address: 0x18003e9b0
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003e9b0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (0x1af286bca1af286 < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar5 = arg2 * 0x98;
    if (uVar5 == 0) {
        uVar3 = 0;
    } else if (uVar5 < 0x1000) {
        uVar3 = func_0x000180459890(uVar5);
    } else {
        if (uVar5 + 0x27 <= uVar5) {
            func_0x000180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        iVar2 = func_0x000180459890();
        iVar4 = iVar2;
        if (iVar2 == 0) {
            iVar4 = 5;
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)();
        }
        uVar3 = iVar2 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar3 - 8) = iVar4;
    }
    *(uint64_t *)arg1 = uVar3;
    *(uint64_t *)(arg1 + 8) = uVar3;
    *(uint64_t *)(arg1 + 0x10) = uVar3 + uVar5;
    return;
}

// ============================================================
// Function: FUN_18003e9c8
// Address: 0x18003e9c8
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003e9b0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (0x1af286bca1af286 < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar5 = arg2 * 0x98;
    if (uVar5 == 0) {
        uVar3 = 0;
    } else if (uVar5 < 0x1000) {
        uVar3 = func_0x000180459890(uVar5);
    } else {
        if (uVar5 + 0x27 <= uVar5) {
            func_0x000180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        iVar2 = func_0x000180459890();
        iVar4 = iVar2;
        if (iVar2 == 0) {
            iVar4 = 5;
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)();
        }
        uVar3 = iVar2 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar3 - 8) = iVar4;
    }
    *(uint64_t *)arg1 = uVar3;
    *(uint64_t *)(arg1 + 8) = uVar3;
    *(uint64_t *)(arg1 + 0x10) = uVar3 + uVar5;
    return;
}

// ============================================================
// Function: FUN_18003ea32
// Address: 0x18003ea32
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003e9b0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (0x1af286bca1af286 < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar5 = arg2 * 0x98;
    if (uVar5 == 0) {
        uVar3 = 0;
    } else if (uVar5 < 0x1000) {
        uVar3 = func_0x000180459890(uVar5);
    } else {
        if (uVar5 + 0x27 <= uVar5) {
            func_0x000180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        iVar2 = func_0x000180459890();
        iVar4 = iVar2;
        if (iVar2 == 0) {
            iVar4 = 5;
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)();
        }
        uVar3 = iVar2 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar3 - 8) = iVar4;
    }
    *(uint64_t *)arg1 = uVar3;
    *(uint64_t *)(arg1 + 8) = uVar3;
    *(uint64_t *)(arg1 + 0x10) = uVar3 + uVar5;
    return;
}

// ============================================================
// Function: FUN_18003ea38
// Address: 0x18003ea38
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003e9b0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (0x1af286bca1af286 < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar5 = arg2 * 0x98;
    if (uVar5 == 0) {
        uVar3 = 0;
    } else if (uVar5 < 0x1000) {
        uVar3 = func_0x000180459890(uVar5);
    } else {
        if (uVar5 + 0x27 <= uVar5) {
            func_0x000180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        iVar2 = func_0x000180459890();
        iVar4 = iVar2;
        if (iVar2 == 0) {
            iVar4 = 5;
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)();
        }
        uVar3 = iVar2 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar3 - 8) = iVar4;
    }
    *(uint64_t *)arg1 = uVar3;
    *(uint64_t *)(arg1 + 8) = uVar3;
    *(uint64_t *)(arg1 + 0x10) = uVar3 + uVar5;
    return;
}

// ============================================================
// Function: FUN_18003ea40
// Address: 0x18003ea40
// Size: 43 bytes
// ============================================================
int64_t fcn.18003ea40(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180622900;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x38);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003ea70
// Address: 0x18003ea70
// Size: 43 bytes
// ============================================================
int64_t fcn.18003ea70(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180622940;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x98);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003eaa0
// Address: 0x18003eaa0
// Size: 43 bytes
// ============================================================
int64_t fcn.18003eaa0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180622920;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x60);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003ead0
// Address: 0x18003ead0
// Size: 43 bytes
// ============================================================
int64_t fcn.18003ead0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180622998;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x68);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003eb00
// Address: 0x18003eb00
// Size: 43 bytes
// ============================================================
int64_t fcn.18003eb00(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x180622978;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x70);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003eb30
// Address: 0x18003eb30
// Size: 43 bytes
// ============================================================
int64_t fcn.18003eb30(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1806228e0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x298);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003eb60
// Address: 0x18003eb60
// Size: 813 bytes
// ============================================================
void fcn.18003eb60(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    code *pcVar5;
    undefined8 uVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined *puVar11;
    undefined auStack_358 [8];
    undefined auStack_350 [24];
    int64_t var_338h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_300h;
    int64_t var_2f8h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_188h;
    int64_t var_48h;
    
    puVar11 = auStack_358;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_358;
    uVar4 = *(undefined8 *)(arg1 + 0x18);
    _var_2f8h = ZEXT816(0);
    var_2e8h = 0;
    var_2e0h = 0;
    func_0x000180004830(&var_2f8h, *(int64_t *)arg1 + 0x50, *(undefined8 *)(arg1 + 0x10));
    uVar6 = func_0x000180459890(0x80);
    var_328h = 0;
    var_320h = 0;
    var_328h = func_0x000180459890(0x60);
    *(int64_t *)var_328h = var_328h;
    *(int64_t *)(var_328h + 8) = var_328h;
    *(int64_t *)(var_328h + 0x10) = var_328h;
    *(undefined2 *)(var_328h + 0x18) = 0x101;
    var_318h._0_1_ = 1;
    _var_310h = ZEXT816(0);
    var_300h = 0;
    var_338h._0_4_ = 0;
    iVar7 = func_0x000180083a90(uVar6, &var_2f8h, &var_318h, &var_328h);
    if (0xf < (uint64_t)var_2e0h) {
        iVar10 = var_2f8h;
        puVar11 = auStack_358;
        if ((0xfff < var_2e0h + 1U) &&
           (iVar10 = *(int64_t *)(var_2f8h + -8), puVar11 = auStack_358, 0x1f < (var_2f8h - iVar10) - 8U)) {
            iVar10 = 5;
            pcVar5 = (code *)swi(0x29);
            (*pcVar5)(5);
            puVar11 = auStack_350;
        }
        *(undefined8 *)(puVar11 + -8) = 0x18003ec6a;
        fcn.180459c3c(iVar10);
    }
    *(undefined8 *)(puVar11 + -8) = 0x18003ec7f;
    func_0x000180084280(iVar7, &var_188h, 1);
    *(undefined8 *)(puVar11 + -8) = 0x18003ec84;
    puVar8 = (undefined8 *)func_0x0001800137d0();
    uVar6 = *puVar8;
    if (*(int64_t *)(arg1 + 8) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg1 + 8) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    var_2d8h = *(int64_t *)arg1;
    var_2d0h = *(int64_t *)(arg1 + 8);
    *(undefined8 *)(puVar11 + -8) = 0x18003ecbb;
    func_0x00018003c320(&var_2c8h, &var_188h);
    *(undefined8 *)(puVar11 + -8) = 0x18003ecc5;
    piVar9 = (int64_t *)func_0x000180459890(0x148);
    *piVar9 = 0;
    piVar9[1] = 0;
    if (var_2d0h != 0) {
        LOCK();
        *(int32_t *)(var_2d0h + 8) = *(int32_t *)(var_2d0h + 8) + 1;
        UNLOCK();
    }
    *piVar9 = var_2d8h;
    piVar9[1] = var_2d0h;
    *(undefined8 *)(puVar11 + -8) = 0x18003ecf8;
    func_0x00018003c320(piVar9 + 2, &var_2c8h);
    *(undefined8 *)(puVar11 + -8) = 0x18003ed02;
    puVar8 = (undefined8 *)func_0x000180459890(0x38);
    *(undefined4 *)(puVar8 + 1) = 1;
    *(undefined4 *)((int64_t)puVar8 + 0xc) = 1;
    *puVar8 = 0x180622900;
    *(undefined4 *)(puVar8 + 3) = 2;
    puVar8[2] = 0x1806229d8;
    puVar8[4] = piVar9;
    puVar8[5] = 0x18003e560;
    puVar8[6] = uVar4;
    *(undefined8 **)(puVar11 + 0x30) = puVar8 + 2;
    *(undefined8 **)(puVar11 + 0x38) = puVar8;
    *(undefined8 *)(puVar11 + -8) = 0x18003ed59;
    func_0x00018000a9d0(uVar6, puVar11 + 0x30);
    piVar9 = *(int64_t **)(puVar11 + 0x38);
    if (piVar9 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar9 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar5 = *(code **)*piVar9;
            *(undefined8 *)(puVar11 + -8) = 0x18003ed7c;
            (*pcVar5)(piVar9);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                pcVar5 = *(code **)(*piVar9 + 8);
                *(undefined8 *)(puVar11 + -8) = 0x18003ed91;
                (*pcVar5)(piVar9);
            }
        }
    }
    *(undefined8 *)(puVar11 + -8) = 0x18003ed9a;
    func_0x00018003c510(&var_2c8h);
    iVar10 = var_2d0h;
    if (var_2d0h != 0) {
        LOCK();
        piVar1 = (int32_t *)(var_2d0h + 8);
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar5 = **(code ***)var_2d0h;
            *(undefined8 *)(puVar11 + -8) = 0x18003edb7;
            (*pcVar5)(var_2d0h);
            LOCK();
            piVar1 = (int32_t *)(iVar10 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                pcVar5 = *(code **)(*(int64_t *)iVar10 + 8);
                *(undefined8 *)(puVar11 + -8) = 0x18003edcc;
                (*pcVar5)(iVar10);
            }
        }
    }
    *(undefined8 *)(puVar11 + -8) = 0x18003edd8;
    func_0x00018003c510(&var_188h);
    if (iVar7 != 0) {
        uVar4 = *(undefined8 *)(*(int64_t *)(iVar7 + 0x70) + 8);
        *(undefined8 *)(puVar11 + -8) = 0x18003edf2;
        func_0x000180015170(iVar7 + 0x70, iVar7 + 0x70, uVar4);
        uVar4 = *(undefined8 *)(iVar7 + 0x70);
        *(undefined8 *)(puVar11 + -8) = 0x18003ee00;
        fcn.180459c3c(uVar4, 0x60);
        *(undefined8 *)(puVar11 + -8) = 0x18003ee09;
        func_0x00018003e790(iVar7 + 0x58);
        *(undefined8 *)(puVar11 + -8) = 0x18003ee12;
        fcn.180004e40(iVar7 + 0x30);
        *(undefined8 *)(puVar11 + -8) = 0x18003ee1b;
        fcn.180004e40(iVar7 + 8);
        *(undefined8 *)(puVar11 + -8) = 0x18003ee28;
        fcn.180459c3c(iVar7, 0x80);
    }
    *(undefined8 *)(puVar11 + -8) = 0x18003ee2d;
    func_0x00018045476c();
    piVar9 = *(int64_t **)(arg1 + 8);
    if (piVar9 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar9 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar5 = *(code **)*piVar9;
            *(undefined8 *)(puVar11 + -8) = 0x18003ee4a;
            (*pcVar5)(piVar9);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                pcVar5 = *(code **)(*piVar9 + 8);
                *(undefined8 *)(puVar11 + -8) = 0x18003ee5d;
                (*pcVar5)(piVar9);
            }
        }
    }
    *(undefined8 *)(puVar11 + -8) = 0x18003ee6a;
    fcn.180459c3c(arg1, 0x20);
    *(undefined8 *)(puVar11 + -8) = 0x18003ee7b;
    func_0x000180459870(var_48h ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_18003ee90
// Address: 0x18003ee90
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18003ee90(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    for (arg1 = *(int64_t *)arg1; arg1 != iVar1; arg1 = arg1 + 0x98) {
        fcn.180004e40(arg1 + 0x68);
        fcn.180004e40(arg1 + 0x40);
        fcn.180004e40(arg1 + 0x20);
        fcn.180004e40(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_18003eee0
// Address: 0x18003eee0
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003eee0(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_18003eeee
// Address: 0x18003eeee
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003eee0(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_18003eefc
// Address: 0x18003eefc
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003eee0(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_18003ef32
// Address: 0x18003ef32
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003eee0(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_18003ef44
// Address: 0x18003ef44
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18003eee0(int64_t arg1, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 != 0) {
        piVar4 = *(int64_t **)(arg1 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(arg1, 0x20);
    }
    return;
}

// ============================================================
// Function: FUN_18003ef50
// Address: 0x18003ef50
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18003ef50(int64_t arg1)
{
    int64_t var_8h;
    
    *(undefined *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined4 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)arg1 = 0x180622970;
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x48) = 0;
    *(undefined4 *)(arg1 + 0xc) = 1;
    *(undefined8 *)(arg1 + 0x10) = 0x3f800000;
    fcn.1804986e0(arg1 + 0x50, 0, 0x200);
    *(undefined8 *)(arg1 + 0x250) = 0;
    *(undefined8 *)(arg1 + 0x280) = 0x3ff0000000000000;
    *(undefined8 *)(arg1 + 600) = 0;
    *(undefined8 *)(arg1 + 0x260) = 0;
    *(undefined8 *)(arg1 + 0x268) = 0;
    *(undefined8 *)(arg1 + 0x270) = 0;
    *(undefined *)(arg1 + 0x278) = 0;
    *(undefined4 *)(arg1 + 0x27c) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18003f000
// Address: 0x18003f000
// Size: 33 bytes
// ============================================================
int64_t fcn.18003f000(int64_t arg1)
{
    uint64_t in_RDX;
    
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x60);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003f030
// Address: 0x18003f030
// Size: 33 bytes
// ============================================================
int64_t fcn.18003f030(int64_t arg1)
{
    uint64_t in_RDX;
    
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x50);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003f060
// Address: 0x18003f060
// Size: 33 bytes
// ============================================================
int64_t fcn.18003f060(int64_t arg1)
{
    uint64_t in_RDX;
    
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x58);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003f090
// Address: 0x18003f090
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18003f090(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 0x38);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x88);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18003f0d0
// Address: 0x18003f0d0
// Size: 604 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18003f0d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    uint32_t uVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t var_8h;
    int64_t var_1ch;
    
    ppiVar13 = *(int64_t ***)arg1;
    if (*(char *)(arg3 + 0x19) == '\0') {
        iVar3 = *(int32_t *)(arg3 + 0x20);
        iVar4 = *(int32_t *)arg4;
        if ((int64_t *)arg3 == *ppiVar13) {
            if (iVar4 < iVar3) {
                *(int64_t *)arg2 = arg3;
                *(undefined4 *)(arg2 + 8) = 1;
                *(undefined *)(arg2 + 0x10) = 0;
                return arg2;
            }
            goto code_r0x00018003f253;
        }
        if (iVar4 < iVar3) {
            piVar7 = *(int64_t **)arg3;
            if (*(char *)((int64_t)piVar7 + 0x19) == '\0') {
                cVar1 = *(char *)(piVar7[2] + 0x19);
                while (cVar1 == '\0') {
                    piVar7 = (int64_t *)piVar7[2];
                    cVar1 = *(char *)(piVar7[2] + 0x19);
                }
            } else {
                cVar1 = *(char *)((int64_t)*(int64_t **)(arg3 + 8) + 0x19);
                piVar6 = *(int64_t **)(arg3 + 8);
                piVar5 = (int64_t *)arg3;
                while ((piVar7 = piVar6, cVar1 == '\0' && (piVar5 == (int64_t *)*piVar7))) {
                    cVar1 = *(char *)((int64_t)(int64_t *)piVar7[1] + 0x19);
                    piVar6 = (int64_t *)piVar7[1];
                    piVar5 = piVar7;
                }
                if (*(char *)((int64_t)piVar5 + 0x19) != '\0') {
                    piVar7 = piVar5;
                }
            }
            if (*(int32_t *)(piVar7 + 4) < iVar4) {
                cVar1 = *(char *)(piVar7[2] + 0x19);
                *(undefined *)(arg2 + 0x10) = 0;
                if (cVar1 == '\0') {
                    *(int64_t *)arg2 = arg3;
                    *(undefined4 *)(arg2 + 8) = 1;
                    return arg2;
                }
                *(int64_t **)arg2 = piVar7;
                *(undefined4 *)(arg2 + 8) = 0;
                return arg2;
            }
            goto code_r0x00018003f253;
        }
        if (iVar4 <= iVar3) {
            *(int64_t *)arg2 = arg3;
            *(undefined *)(arg2 + 0x10) = 1;
            goto code_r0x00018003f317;
        }
        ppiVar12 = *(int64_t ***)(arg3 + 0x10);
        cVar1 = *(char *)((int64_t)ppiVar12 + 0x19);
        if (cVar1 == '\0') {
            cVar2 = *(char *)((int64_t)*ppiVar12 + 0x19);
            ppiVar11 = (int64_t **)*ppiVar12;
            while (cVar2 == '\0') {
                cVar2 = *(char *)((int64_t)*ppiVar11 + 0x19);
                ppiVar12 = ppiVar11;
                ppiVar11 = (int64_t **)*ppiVar11;
            }
        } else {
            ppiVar11 = *(int64_t ***)(arg3 + 8);
            ppiVar8 = (int64_t **)arg3;
            ppiVar12 = ppiVar11;
            if (*(char *)((int64_t)ppiVar11 + 0x19) != '\0') goto code_r0x00018003f2d8;
            do {
                ppiVar12 = ppiVar11;
                if (ppiVar8 != (int64_t **)ppiVar11[2]) break;
                ppiVar12 = (int64_t **)ppiVar11[1];
                ppiVar8 = ppiVar11;
                ppiVar11 = ppiVar12;
            } while (*(char *)((int64_t)ppiVar12 + 0x19) == '\0');
        }
        if ((*(char *)((int64_t)ppiVar12 + 0x19) != '\0') || (iVar4 < *(int32_t *)(ppiVar12 + 4))) {
code_r0x00018003f2d8:
            *(undefined *)(arg2 + 0x10) = 0;
            if (cVar1 == '\0') {
                *(int64_t ***)arg2 = ppiVar12;
                *(undefined4 *)(arg2 + 8) = 1;
                return arg2;
            }
            *(int64_t *)arg2 = arg3;
            *(undefined4 *)(arg2 + 8) = 0;
            return arg2;
        }
    } else if ((*(char *)((int64_t)ppiVar13[1] + 0x19) != '\0') || (*(int32_t *)(ppiVar13[2] + 4) < *(int32_t *)arg4)) {
        *(int64_t **)arg2 = ppiVar13[2];
        *(undefined *)(arg2 + 0x10) = 0;
code_r0x00018003f317:
        *(undefined4 *)(arg2 + 8) = 0;
        return arg2;
    }
code_r0x00018003f253:
    ppiVar12 = (int64_t **)ppiVar13[1];
    if (*(char *)((int64_t)ppiVar12 + 0x19) == '\0') {
        ppiVar11 = ppiVar12;
        ppiVar8 = ppiVar13;
        do {
            ppiVar12 = ppiVar11;
            ppiVar9 = ppiVar12;
            ppiVar13 = ppiVar12;
            if (*(int32_t *)arg4 > *(int32_t *)(ppiVar12 + 4)) {
                ppiVar9 = ppiVar12 + 2;
                ppiVar13 = ppiVar8;
            }
            uVar10 = (uint32_t)(*(int32_t *)arg4 <= *(int32_t *)(ppiVar12 + 4));
            ppiVar11 = (int64_t **)*ppiVar9;
            ppiVar8 = ppiVar13;
        } while (*(char *)((int64_t)*ppiVar9 + 0x19) == '\0');
    } else {
        uVar10 = 0;
    }
    if ((*(char *)((int64_t)ppiVar13 + 0x19) == '\0') && (*(int32_t *)(ppiVar13 + 4) <= *(int32_t *)arg4)) {
        *(int64_t ***)arg2 = ppiVar13;
        *(undefined4 *)(arg2 + 8) = 2;
        *(undefined *)(arg2 + 0x10) = 1;
        return arg2;
    }
    *(undefined4 *)(arg2 + 0xc) = (undefined4)var_1ch;
    *(int64_t ***)arg2 = ppiVar12;
    *(uint32_t *)(arg2 + 8) = uVar10;
    *(undefined *)(arg2 + 0x10) = 0;
    return arg2;
}

// ============================================================
// Function: FUN_18003f360
// Address: 0x18003f360
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18003f360(void)
{
    code *pcVar1;
    int64_t var_28h;
    int64_t var_18h;
    
    _var_28h = ZEXT816(0);
    var_18h = 0;
    fcn.18003f390(&var_28h);
    fcn.18045bae0(var_28h);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18003f3b0
// Address: 0x18003f3b0
// Size: 60 bytes
// ============================================================
int64_t fcn.18003f3b0(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1806230c8;
    return arg1;
}

// ============================================================
// Function: FUN_18003f3f0
// Address: 0x18003f3f0
// Size: 31 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

undefined8 fcn.18003f3f0(undefined8 param_1)
{
    fcn.180086cc0(param_1, 0xffffd8f0, 0x1805aae80);
    return 1;
}

// ============================================================
// Function: FUN_18003f410
// Address: 0x18003f410
// Size: 309 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.18003f410(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float fVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t var_20h;
    undefined var_48h;
    int64_t var_47h;
    int64_t var_28h;
    float fStack_20;
    float var_1ch;
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_48h;
    iVar9 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar8 = *(int64_t *)(iVar9 + 0x58);
    fStack_20 = (float)iVar8;
    var_18h._0_4_ = 0.0;
    var_18h._4_4_ = 2;
    var_28h._4_4_ = (float)((uint64_t)iVar8 >> 0x20);
    var_1ch = var_28h._4_4_;
    var_28h = iVar8;
    iVar8 = func_0x0001800a00a0(*(undefined8 *)(*(int64_t *)(iVar9 + 0x20) + 0x4c0), &fStack_20);
    iVar7 = func_0x000180099200(iVar8 + 0x10, &fStack_20);
    iVar13 = *(int64_t *)0x180782430;
    while ((iVar14 = iVar8, iVar7 == 0 && (iVar14 = iVar13, ((int64_t)*(int32_t *)(iVar8 + 0x1c) & 0xfffffff0U) != 0)))
    {
        iVar8 = iVar8 + ((int64_t)*(int32_t *)(iVar8 + 0x1c) >> 4) * 0x20;
        iVar7 = func_0x000180099200(iVar8 + 0x10, &fStack_20);
    }
    if (iVar14 == iVar13) {
        iVar9 = func_0x0001800a1260(iVar9, *(undefined8 *)(iVar9 + 0x58));
        if (var_18h._4_4_ == 0) {
            func_0x000180093000(arg1, 0x18063ea50);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if (var_18h._4_4_ == 3) {
            if (NAN((double)CONCAT44(var_1ch, fStack_20))) {
                func_0x000180093000(arg1, 0x18063eab0);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
        } else if ((var_18h._4_4_ == 5) && (((NAN(fStack_20) || (NAN(var_1ch))) || (NAN((float)var_18h))))) {
            func_0x000180093000(arg1, 0x18063ea90);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar8 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x4c0);
        piVar10 = (int64_t *)func_0x0001800a0a80(arg1, iVar8, &fStack_20);
        fVar6 = (float)var_18h;
        *piVar10 = iVar9;
        *(float *)(piVar10 + 1) = (float)var_18h;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = 7;
        if (((*(uint8_t *)(iVar8 + 1) & 4) != 0) && ((*(uint8_t *)(iVar9 + 1) & 3) != 0)) {
            iVar13 = *(int64_t *)(arg1 + 0x20);
            if (*(char *)(iVar13 + 0x59) == '\x02') {
                func_0x000180094420(iVar13, iVar9);
            } else {
                *(uint8_t *)(iVar8 + 1) = *(uint8_t *)(iVar8 + 1) & 0xfb;
                *(undefined8 *)(iVar8 + 0x18) = *(undefined8 *)(iVar13 + 0x18);
                *(int64_t *)(iVar13 + 0x18) = iVar8;
            }
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) goto code_r0x00018003f74e;
        piVar10 = *(int64_t **)(arg1 + 0x40);
        *piVar10 = iVar9;
        *(float *)(piVar10 + 1) = fVar6;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = 7;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    } else {
        func_0x0001800854a0(arg1, iVar14);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar7 = func_0x000180085510(arg1, 1), iVar7 != 0)) {
        puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, 2);
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        uVar3 = puVar12[1];
        uVar4 = puVar12[2];
        uVar5 = puVar12[3];
        *puVar1 = *puVar12;
        puVar1[1] = uVar3;
        puVar1[2] = uVar4;
        puVar1[3] = uVar5;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffe, 0x1806203dc);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 != 0)) {
            puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
            puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, 4);
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            uVar3 = puVar12[1];
            uVar4 = puVar12[2];
            uVar5 = puVar12[3];
            *puVar1 = *puVar12;
            puVar1[1] = uVar3;
            puVar1[2] = uVar4;
            puVar1[3] = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087370(arg1, 0xfffffffe, 0x1806203e0);
            func_0x000180459870(var_10h ^ (uint64_t)&var_48h);
            return;
        }
    }
code_r0x00018003f74e:
    func_0x000180099450(arg1, 0x18063d8d0);
    func_0x000180087960(arg1);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18003f545
// Address: 0x18003f545
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.18003f410(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float fVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t var_20h;
    undefined var_48h;
    int64_t var_47h;
    int64_t var_28h;
    float fStack_20;
    float var_1ch;
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_48h;
    iVar9 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar8 = *(int64_t *)(iVar9 + 0x58);
    fStack_20 = (float)iVar8;
    var_18h._0_4_ = 0.0;
    var_18h._4_4_ = 2;
    var_28h._4_4_ = (float)((uint64_t)iVar8 >> 0x20);
    var_1ch = var_28h._4_4_;
    var_28h = iVar8;
    iVar8 = func_0x0001800a00a0(*(undefined8 *)(*(int64_t *)(iVar9 + 0x20) + 0x4c0), &fStack_20);
    iVar7 = func_0x000180099200(iVar8 + 0x10, &fStack_20);
    iVar13 = *(int64_t *)0x180782430;
    while ((iVar14 = iVar8, iVar7 == 0 && (iVar14 = iVar13, ((int64_t)*(int32_t *)(iVar8 + 0x1c) & 0xfffffff0U) != 0)))
    {
        iVar8 = iVar8 + ((int64_t)*(int32_t *)(iVar8 + 0x1c) >> 4) * 0x20;
        iVar7 = func_0x000180099200(iVar8 + 0x10, &fStack_20);
    }
    if (iVar14 == iVar13) {
        iVar9 = func_0x0001800a1260(iVar9, *(undefined8 *)(iVar9 + 0x58));
        if (var_18h._4_4_ == 0) {
            func_0x000180093000(arg1, 0x18063ea50);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if (var_18h._4_4_ == 3) {
            if (NAN((double)CONCAT44(var_1ch, fStack_20))) {
                func_0x000180093000(arg1, 0x18063eab0);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
        } else if ((var_18h._4_4_ == 5) && (((NAN(fStack_20) || (NAN(var_1ch))) || (NAN((float)var_18h))))) {
            func_0x000180093000(arg1, 0x18063ea90);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar8 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x4c0);
        piVar10 = (int64_t *)func_0x0001800a0a80(arg1, iVar8, &fStack_20);
        fVar6 = (float)var_18h;
        *piVar10 = iVar9;
        *(float *)(piVar10 + 1) = (float)var_18h;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = 7;
        if (((*(uint8_t *)(iVar8 + 1) & 4) != 0) && ((*(uint8_t *)(iVar9 + 1) & 3) != 0)) {
            iVar13 = *(int64_t *)(arg1 + 0x20);
            if (*(char *)(iVar13 + 0x59) == '\x02') {
                func_0x000180094420(iVar13, iVar9);
            } else {
                *(uint8_t *)(iVar8 + 1) = *(uint8_t *)(iVar8 + 1) & 0xfb;
                *(undefined8 *)(iVar8 + 0x18) = *(undefined8 *)(iVar13 + 0x18);
                *(int64_t *)(iVar13 + 0x18) = iVar8;
            }
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) goto code_r0x00018003f74e;
        piVar10 = *(int64_t **)(arg1 + 0x40);
        *piVar10 = iVar9;
        *(float *)(piVar10 + 1) = fVar6;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = 7;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    } else {
        func_0x0001800854a0(arg1, iVar14);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar7 = func_0x000180085510(arg1, 1), iVar7 != 0)) {
        puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, 2);
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        uVar3 = puVar12[1];
        uVar4 = puVar12[2];
        uVar5 = puVar12[3];
        *puVar1 = *puVar12;
        puVar1[1] = uVar3;
        puVar1[2] = uVar4;
        puVar1[3] = uVar5;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffe, 0x1806203dc);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 != 0)) {
            puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
            puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, 4);
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            uVar3 = puVar12[1];
            uVar4 = puVar12[2];
            uVar5 = puVar12[3];
            *puVar1 = *puVar12;
            puVar1[1] = uVar3;
            puVar1[2] = uVar4;
            puVar1[3] = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087370(arg1, 0xfffffffe, 0x1806203e0);
            func_0x000180459870(var_10h ^ (uint64_t)&var_48h);
            return;
        }
    }
code_r0x00018003f74e:
    func_0x000180099450(arg1, 0x18063d8d0);
    func_0x000180087960(arg1);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18003f5ae
// Address: 0x18003f5ae
// Size: 440 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

void fcn.18003f410(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    float fVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t var_20h;
    undefined var_48h;
    int64_t var_47h;
    int64_t var_28h;
    float fStack_20;
    float var_1ch;
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_48h;
    iVar9 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    iVar8 = *(int64_t *)(iVar9 + 0x58);
    fStack_20 = (float)iVar8;
    var_18h._0_4_ = 0.0;
    var_18h._4_4_ = 2;
    var_28h._4_4_ = (float)((uint64_t)iVar8 >> 0x20);
    var_1ch = var_28h._4_4_;
    var_28h = iVar8;
    iVar8 = func_0x0001800a00a0(*(undefined8 *)(*(int64_t *)(iVar9 + 0x20) + 0x4c0), &fStack_20);
    iVar7 = func_0x000180099200(iVar8 + 0x10, &fStack_20);
    iVar13 = *(int64_t *)0x180782430;
    while ((iVar14 = iVar8, iVar7 == 0 && (iVar14 = iVar13, ((int64_t)*(int32_t *)(iVar8 + 0x1c) & 0xfffffff0U) != 0)))
    {
        iVar8 = iVar8 + ((int64_t)*(int32_t *)(iVar8 + 0x1c) >> 4) * 0x20;
        iVar7 = func_0x000180099200(iVar8 + 0x10, &fStack_20);
    }
    if (iVar14 == iVar13) {
        iVar9 = func_0x0001800a1260(iVar9, *(undefined8 *)(iVar9 + 0x58));
        if (var_18h._4_4_ == 0) {
            func_0x000180093000(arg1, 0x18063ea50);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if (var_18h._4_4_ == 3) {
            if (NAN((double)CONCAT44(var_1ch, fStack_20))) {
                func_0x000180093000(arg1, 0x18063eab0);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
        } else if ((var_18h._4_4_ == 5) && (((NAN(fStack_20) || (NAN(var_1ch))) || (NAN((float)var_18h))))) {
            func_0x000180093000(arg1, 0x18063ea90);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar8 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x4c0);
        piVar10 = (int64_t *)func_0x0001800a0a80(arg1, iVar8, &fStack_20);
        fVar6 = (float)var_18h;
        *piVar10 = iVar9;
        *(float *)(piVar10 + 1) = (float)var_18h;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = 7;
        if (((*(uint8_t *)(iVar8 + 1) & 4) != 0) && ((*(uint8_t *)(iVar9 + 1) & 3) != 0)) {
            iVar13 = *(int64_t *)(arg1 + 0x20);
            if (*(char *)(iVar13 + 0x59) == '\x02') {
                func_0x000180094420(iVar13, iVar9);
            } else {
                *(uint8_t *)(iVar8 + 1) = *(uint8_t *)(iVar8 + 1) & 0xfb;
                *(undefined8 *)(iVar8 + 0x18) = *(undefined8 *)(iVar13 + 0x18);
                *(int64_t *)(iVar13 + 0x18) = iVar8;
            }
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 == 0)) goto code_r0x00018003f74e;
        piVar10 = *(int64_t **)(arg1 + 0x40);
        *piVar10 = iVar9;
        *(float *)(piVar10 + 1) = fVar6;
        *(undefined4 *)((int64_t)piVar10 + 0xc) = 7;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    } else {
        func_0x0001800854a0(arg1, iVar14);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar7 = func_0x000180085510(arg1, 1), iVar7 != 0)) {
        puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, 2);
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        uVar3 = puVar12[1];
        uVar4 = puVar12[2];
        uVar5 = puVar12[3];
        *puVar1 = *puVar12;
        puVar1[1] = uVar3;
        puVar1[2] = uVar4;
        puVar1[3] = uVar5;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffe, 0x1806203dc);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar7 = func_0x000180085510(arg1, 1), iVar7 != 0)) {
            puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
            puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, 4);
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            uVar3 = puVar12[1];
            uVar4 = puVar12[2];
            uVar5 = puVar12[3];
            *puVar1 = *puVar12;
            puVar1[1] = uVar3;
            puVar1[2] = uVar4;
            puVar1[3] = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087370(arg1, 0xfffffffe, 0x1806203e0);
            func_0x000180459870(var_10h ^ (uint64_t)&var_48h);
            return;
        }
    }
code_r0x00018003f74e:
    func_0x000180099450(arg1, 0x18063d8d0);
    func_0x000180087960(arg1);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18003f770
// Address: 0x18003f770
// Size: 179 bytes
// ============================================================
undefined8 fcn.18003f770(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar5 = *(int64_t **)0x180782430;
    }
    iVar6 = arg1;
    if ((piVar5 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar5 + 0xc) == 10)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
            piVar3 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar3 + 0xc) == 10) {
            iVar6 = *piVar3;
        } else {
            iVar6 = 0;
        }
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    *puVar1 = *(undefined8 *)(iVar6 + 0x58);
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 7;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar4 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar2 = iVar4 * 2;
        if (iVar4 < 1) {
            iVar2 = iVar4 + 1;
        }
        func_0x000180093240(arg1, iVar2, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18003f830
// Address: 0x18003f830
// Size: 177 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8 fcn.18003f830(int64_t arg1)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t *piVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar3 = *(int32_t **)(arg1 + 0x28);
    piVar1 = *(int32_t **)(arg1 + 0x40);
    piVar5 = piVar3;
    if (piVar1 <= piVar3) {
        piVar5 = *(int32_t **)0x180782430;
    }
    var_18h = arg1;
    if ((piVar5 != *(int32_t **)0x180782430) && (0 < piVar5[3])) {
        piVar5 = piVar3;
        if (piVar1 <= piVar3) {
            piVar5 = *(int32_t **)0x180782430;
        }
        if ((piVar5 == *(int32_t **)0x180782430) || (piVar5[3] != 1)) {
            func_0x000180088470(arg1, 1, 1);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
        if (piVar1 <= piVar3) {
            piVar3 = *(int32_t **)0x180782430;
        }
        if ((piVar3[3] != 0) && ((piVar3[3] != 1 || (*piVar3 != 0)))) {
            var_10h._0_1_ = 1;
            goto code_r0x00018003f898;
        }
    }
    var_10h._0_1_ = 0;
code_r0x00018003f898:
    var_10h._4_4_ = 0;
    func_0x000180086fd0(arg1, 0, 0);
    func_0x0001800989f0(arg1, &var_18h, 0x18003f8f0);
    return 1;
}

// ============================================================
// Function: FUN_18003f8f0
// Address: 0x18003f8f0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18003f8f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t in_RAX;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg3 == 0) {
        return in_RAX & 0xffffffffffffff00;
    }
    iVar2 = *(int64_t *)arg1;
    if (((~*(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 0x58) & 3 ^ *(uint8_t *)(arg3 + 1)) & 0xb) != 0) {
        uVar1 = *(uint8_t *)(arg3 + 2);
        uVar4 = (uint64_t)(uVar1 - 8);
        if (((uint8_t)(uVar1 - 8) < 2) || ((*(char *)(arg1 + 8) != '\0' && (uVar1 == 7)))) {
            uVar4 = func_0x000180085510(iVar2, 1);
            if ((int32_t)uVar4 != 0) {
                if ((5 < uVar1) && ((*(uint8_t *)(iVar2 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
                }
                **(int64_t **)(iVar2 + 0x40) = arg3;
                *(uint32_t *)(*(int64_t *)(iVar2 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(arg3 + 2);
                if (*(int64_t *)(iVar2 + 0x30) - *(int64_t *)(iVar2 + 0x40) < 0x11) {
                    iVar5 = *(int32_t *)(iVar2 + 0x60) - ((int32_t)iVar2 + 0x60);
                    iVar3 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar3 = iVar5 + 1;
                    }
                    func_0x000180093240(iVar2, iVar3, 0);
                }
                *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + 0x10;
                *(int32_t *)(arg1 + 0xc) = *(int32_t *)(arg1 + 0xc) + 1;
                uVar4 = func_0x000180087560(iVar2, 0xfffffffe, *(undefined4 *)(arg1 + 0xc));
            }
        }
        return uVar4 & 0xffffffffffffff00;
    }
    return 0;
}

// ============================================================
// Function: FUN_18003f909
// Address: 0x18003f909
// Size: 247 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18003f8f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t in_RAX;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg3 == 0) {
        return in_RAX & 0xffffffffffffff00;
    }
    iVar2 = *(int64_t *)arg1;
    if (((~*(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 0x58) & 3 ^ *(uint8_t *)(arg3 + 1)) & 0xb) != 0) {
        uVar1 = *(uint8_t *)(arg3 + 2);
        uVar4 = (uint64_t)(uVar1 - 8);
        if (((uint8_t)(uVar1 - 8) < 2) || ((*(char *)(arg1 + 8) != '\0' && (uVar1 == 7)))) {
            uVar4 = func_0x000180085510(iVar2, 1);
            if ((int32_t)uVar4 != 0) {
                if ((5 < uVar1) && ((*(uint8_t *)(iVar2 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
                }
                **(int64_t **)(iVar2 + 0x40) = arg3;
                *(uint32_t *)(*(int64_t *)(iVar2 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(arg3 + 2);
                if (*(int64_t *)(iVar2 + 0x30) - *(int64_t *)(iVar2 + 0x40) < 0x11) {
                    iVar5 = *(int32_t *)(iVar2 + 0x60) - ((int32_t)iVar2 + 0x60);
                    iVar3 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar3 = iVar5 + 1;
                    }
                    func_0x000180093240(iVar2, iVar3, 0);
                }
                *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + 0x10;
                *(int32_t *)(arg1 + 0xc) = *(int32_t *)(arg1 + 0xc) + 1;
                uVar4 = func_0x000180087560(iVar2, 0xfffffffe, *(undefined4 *)(arg1 + 0xc));
            }
        }
        return uVar4 & 0xffffffffffffff00;
    }
    return 0;
}

// ============================================================
// Function: FUN_18003fa00
// Address: 0x18003fa00
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18003f8f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t in_RAX;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg3 == 0) {
        return in_RAX & 0xffffffffffffff00;
    }
    iVar2 = *(int64_t *)arg1;
    if (((~*(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 0x58) & 3 ^ *(uint8_t *)(arg3 + 1)) & 0xb) != 0) {
        uVar1 = *(uint8_t *)(arg3 + 2);
        uVar4 = (uint64_t)(uVar1 - 8);
        if (((uint8_t)(uVar1 - 8) < 2) || ((*(char *)(arg1 + 8) != '\0' && (uVar1 == 7)))) {
            uVar4 = func_0x000180085510(iVar2, 1);
            if ((int32_t)uVar4 != 0) {
                if ((5 < uVar1) && ((*(uint8_t *)(iVar2 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
                }
                **(int64_t **)(iVar2 + 0x40) = arg3;
                *(uint32_t *)(*(int64_t *)(iVar2 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(arg3 + 2);
                if (*(int64_t *)(iVar2 + 0x30) - *(int64_t *)(iVar2 + 0x40) < 0x11) {
                    iVar5 = *(int32_t *)(iVar2 + 0x60) - ((int32_t)iVar2 + 0x60);
                    iVar3 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar3 = iVar5 + 1;
                    }
                    func_0x000180093240(iVar2, iVar3, 0);
                }
                *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + 0x10;
                *(int32_t *)(arg1 + 0xc) = *(int32_t *)(arg1 + 0xc) + 1;
                uVar4 = func_0x000180087560(iVar2, 0xfffffffe, *(undefined4 *)(arg1 + 0xc));
            }
        }
        return uVar4 & 0xffffffffffffff00;
    }
    return 0;
}

// ============================================================
// Function: FUN_18003fa12
// Address: 0x18003fa12
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18003f8f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t in_RAX;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg3 == 0) {
        return in_RAX & 0xffffffffffffff00;
    }
    iVar2 = *(int64_t *)arg1;
    if (((~*(uint8_t *)(*(int64_t *)(iVar2 + 0x20) + 0x58) & 3 ^ *(uint8_t *)(arg3 + 1)) & 0xb) != 0) {
        uVar1 = *(uint8_t *)(arg3 + 2);
        uVar4 = (uint64_t)(uVar1 - 8);
        if (((uint8_t)(uVar1 - 8) < 2) || ((*(char *)(arg1 + 8) != '\0' && (uVar1 == 7)))) {
            uVar4 = func_0x000180085510(iVar2, 1);
            if ((int32_t)uVar4 != 0) {
                if ((5 < uVar1) && ((*(uint8_t *)(iVar2 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
                }
                **(int64_t **)(iVar2 + 0x40) = arg3;
                *(uint32_t *)(*(int64_t *)(iVar2 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(arg3 + 2);
                if (*(int64_t *)(iVar2 + 0x30) - *(int64_t *)(iVar2 + 0x40) < 0x11) {
                    iVar5 = *(int32_t *)(iVar2 + 0x60) - ((int32_t)iVar2 + 0x60);
                    iVar3 = iVar5 * 2;
                    if (iVar5 < 1) {
                        iVar3 = iVar5 + 1;
                    }
                    func_0x000180093240(iVar2, iVar3, 0);
                }
                *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + 0x10;
                *(int32_t *)(arg1 + 0xc) = *(int32_t *)(arg1 + 0xc) + 1;
                uVar4 = func_0x000180087560(iVar2, 0xfffffffe, *(undefined4 *)(arg1 + 0xc));
            }
        }
        return uVar4 & 0xffffffffffffff00;
    }
    return 0;
}

// ============================================================
// Function: FUN_18003fa20
// Address: 0x18003fa20
// Size: 93 bytes
// ============================================================
undefined2 fcn.18003fa20(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    double dVar1;
    double dVar2;
    int16_t iVar3;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar1 = *(double *)arg3;
    dVar2 = *(double *)arg2;
    iVar3 = func_0x00018046ea10(SUB84(dVar2, 0));
    if (((iVar3 != 2) || (iVar3 = func_0x00018046ea10(SUB84(dVar1, 0)), iVar3 != 2)) && (dVar2 != dVar1)) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18003fa80
// Address: 0x18003fa80
// Size: 4217 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1bfh
// WARNING: [rz-ghidra] Detected overlap for variable var_1d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_1d3h
// WARNING: [rz-ghidra] Detected overlap for variable var_133h
// WARNING: [rz-ghidra] Detected overlap for variable var_1d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_131h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18003fa80(int64_t arg1)
{
    uint64_t uVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    double *pdVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined uVar11;
    char cVar12;
    int32_t iVar13;
    undefined8 *puVar14;
    undefined8 uVar15;
    undefined8 uVar16;
    int64_t iVar17;
    int32_t iVar18;
    undefined8 *puVar19;
    int32_t iVar20;
    uint64_t uVar21;
    int64_t *piVar22;
    uint64_t uVar23;
    undefined *puVar24;
    undefined *puVar25;
    int32_t iVar26;
    int64_t *piVar27;
    uint64_t uVar28;
    int64_t iVar29;
    int64_t *piVar30;
    int64_t *piVar31;
    int64_t iVar32;
    bool bVar33;
    undefined8 uStack_200;
    undefined auStack_1f8 [8];
    undefined auStack_1f0 [24];
    int64_t var_1d8h;
    int64_t var_1cch;
    char var_1c0h;
    undefined var_1bfh;
    int64_t var_1bch;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    undefined4 var_138h;
    int64_t var_134h;
    int64_t var_128h;
    undefined8 uStack_120;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar24 = auStack_1f8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1f8;
    puVar19 = *(undefined8 **)(arg1 + 0x28);
    puVar14 = puVar19;
    if (*(undefined8 **)(arg1 + 0x40) <= puVar19) {
        puVar14 = *(undefined8 **)0x180782430;
    }
    if ((puVar14 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar14 + 0xc) != 6)) {
        func_0x000180088470(arg1, 1, 6);
code_r0x000180040aba:
        func_0x000180010010();
code_r0x000180040ac0:
        func_0x000180004720();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    puVar14 = puVar19 + 2;
    if (*(undefined8 **)(arg1 + 0x40) <= puVar19 + 2) {
        puVar14 = *(undefined8 **)0x180782430;
    }
    if ((puVar14 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar14 + 0xc) != 7)) {
        func_0x000180088470(arg1, 2, 7);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar15 = func_0x0001800860c0(arg1, 1, 0);
    _var_70h = ZEXT816(0);
    var_60h = 0;
    var_58h = 0;
    uVar16 = func_0x000180498cd0(uVar15);
    func_0x000180004830(&var_70h, uVar15, uVar16);
    piVar27 = (int64_t *)var_70h;
    if ((uint64_t)var_58h < 0x10) {
        piVar27 = &var_70h;
    }
    piVar22 = (int64_t *)(var_60h + (int64_t)piVar27);
    piVar30 = (int64_t *)var_70h;
    piVar31 = piVar27;
    if (piVar27 != piVar22) {
        do {
            uVar11 = func_0x000180460320(*(undefined *)piVar27);
            *(undefined *)piVar31 = uVar11;
            piVar31 = (int64_t *)((int64_t)piVar31 + 1);
            piVar27 = (int64_t *)((int64_t)piVar27 + 1);
        } while (piVar27 != piVar22);
        piVar30 = (int64_t *)var_70h;
    }
    iVar32 = var_58h;
    iVar17 = var_60h;
    piVar27 = &var_70h;
    if (0xf < (uint64_t)var_58h) {
        piVar27 = piVar30;
    }
    if ((var_60h != 5) || (iVar13 = func_0x000180497f30(piVar27, 0x180622fb4, 5), iVar13 != 0)) {
        piVar27 = &var_70h;
        if (0xf < (uint64_t)iVar32) {
            piVar27 = piVar30;
        }
        puVar25 = auStack_1f8;
        if ((iVar17 != 8) || (iVar13 = func_0x000180497f30(piVar27, 0x180622fe0, 8), puVar25 = auStack_1f8, iVar13 != 0)
           ) goto code_r0x000180040ae4;
    }
    piVar27 = &var_70h;
    if (0xf < (uint64_t)iVar32) {
        piVar27 = piVar30;
    }
    if (iVar17 == 8) {
        iVar13 = func_0x000180497f30(piVar27, 0x180622fe0, 8);
        var_1c0h = iVar13 == 0;
    } else {
        var_1c0h = false;
    }
    puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(undefined8 **)(arg1 + 0x40) <= puVar19) {
        puVar19 = *(undefined8 **)0x180782430;
    }
    if ((puVar19 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar19 + 0xc) < 1)) {
        var_1cch._0_4_ = 0;
    } else {
        var_1cch._0_4_ = func_0x0001800887e0(arg1, 3);
    }
    var_1bfh = (int32_t)var_1cch != 0;
    var_1bch._0_4_ = 0;
    *(undefined (*) [16])0x1200 = ZEXT816(0);
    _var_1a8h = ZEXT816(0);
    var_168h._0_1_ = '\0';
    var_140h._0_1_ = '\0';
    var_134h._0_1_ = 0;
    var_134h._4_1_ = 1;
    _var_118h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_d8h = ZEXT816(0);
    _var_b8h = ZEXT816(0);
    unique0x10001f95 = arg1;
    _var_198h = *(undefined (*) [16])0x1200;
    _var_128h = *(undefined (*) [16])0x1200;
    _var_108h = *(undefined (*) [16])0x1200;
    _var_e8h = *(undefined (*) [16])0x1200;
    _var_c8h = *(undefined (*) [16])0x1200;
    _var_a8h = *(undefined (*) [16])0x1200;
    if ((bool)var_1c0h == false) {
        fcn.180086cc0(arg1, 2, 0x180623068);
        iVar17 = *(int64_t *)(arg1 + 0x40);
        if (((undefined8 *)(iVar17 - 0x10U) != *(undefined8 **)0x180782430) && (*(int32_t *)(iVar17 + -4) == 7)) {
            puVar19 = (undefined8 *)(iVar17 - 0x10U);
            if ((undefined8 *)(iVar17 - 0x10U) == *(undefined8 **)0x180782430) {
                puVar19 = (undefined8 *)0x0;
            }
            var_e8h = *puVar19;
            var_1bch._0_4_ = (int32_t)var_1bch + 1;
        }
        func_0x0001800858c0(arg1, 0xfffffffe);
        fcn.180086cc0(arg1, 2, 0x18062305c);
        puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if ((puVar19 != *(undefined8 **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
            if (puVar19 == *(undefined8 **)0x180782430) {
                puVar19 = (undefined8 *)0x0;
            }
            func_0x0001800416d0(&var_1a0h, puVar19);
            uVar23 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180086510(arg1);
            iVar13 = func_0x000180087970(arg1, uVar23 & 0xffffffff);
            while (iVar13 != 0) {
                puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
                if (puVar19 == *(undefined8 **)0x180782430) {
                    puVar19 = (undefined8 *)0x0;
                }
                func_0x0001800416d0(&var_e0h, puVar19);
                func_0x0001800858c0(arg1, 0xfffffffe);
                iVar13 = func_0x000180087970(arg1, uVar23 & 0xffffffff);
            }
            if (var_e0h != var_d8h) {
                var_1bch._0_4_ = (int32_t)var_1bch + 1;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        fcn.180086cc0(arg1, 2, 0x180623088);
        puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if ((puVar19 != *(undefined8 **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
            if (puVar19 == *(undefined8 **)0x180782430) {
                puVar19 = (undefined8 *)0x0;
            }
            func_0x0001800416d0(&var_1a0h, puVar19);
            uVar23 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180086510(arg1);
            iVar13 = func_0x000180087970(arg1, uVar23 & 0xffffffff);
            while (iVar13 != 0) {
                puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
                if (puVar19 == *(undefined8 **)0x180782430) {
                    puVar19 = (undefined8 *)0x0;
                }
                func_0x0001800416d0(&var_c8h, puVar19);
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar13 = func_0x000180087970(arg1, uVar23 & 0xffffffff);
            }
            if (var_c8h != var_c0h) {
                var_1bch._0_4_ = (int32_t)var_1bch + 1;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        fcn.180086cc0(arg1, 2, 0x180623078);
        puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        puVar25 = auStack_1f8;
        if ((puVar19 != *(undefined8 **)0x180782430) &&
           (puVar25 = auStack_1f8, *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
            if (puVar19 == *(undefined8 **)0x180782430) {
                puVar19 = (undefined8 *)0x0;
            }
            func_0x0001800416d0(&var_1a0h, puVar19);
            var_98h = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180086510(arg1);
            while (iVar13 = func_0x000180087970(arg1), puVar24 = auStack_1f8, iVar13 != 0) {
                puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
                if (puVar19 == *(undefined8 **)0x180782430) {
                    puVar19 = (undefined8 *)0x0;
                }
                var_1d8h = *(int64_t *)(arg1 + 0x40) - 0x20;
                if ((undefined8 *)var_1d8h == *(undefined8 **)0x180782430) {
                    var_1d8h = (int64_t)(undefined8 *)0x0;
                }
                iVar17 = var_a8h;
                if (var_a8h == var_a0h) {
                    iVar32 = var_a8h - var_b0h >> 5;
                    if (iVar32 == 0x7ffffffffffffff) {
                        func_0x000180010010();
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                    uVar23 = var_a0h - var_b0h >> 5;
                    if (0x7ffffffffffffff - (uVar23 >> 1) < uVar23) goto code_r0x000180040ac0;
                    uVar1 = iVar32 + 1;
                    uVar23 = (uVar23 >> 1) + uVar23;
                    uVar28 = uVar1;
                    if (uVar1 <= uVar23) {
                        uVar28 = uVar23;
                    }
                    if (0x7ffffffffffffff < uVar28) goto code_r0x000180040ac0;
                    uVar28 = uVar28 * 0x20;
                    if (uVar28 == 0) {
                        uVar23 = 0;
                    } else if (uVar28 < 0x1000) {
                        uVar23 = func_0x000180459890(uVar28);
                    } else {
                        if (uVar28 + 0x27 <= uVar28) goto code_r0x000180040ac0;
                        iVar29 = func_0x000180459890();
                        if (iVar29 == 0) goto code_r0x000180040683;
                        uVar23 = iVar29 + 0x27U & 0xffffffffffffffe0;
                        *(int64_t *)(uVar23 - 8) = iVar29;
                    }
                    iVar32 = iVar32 * 0x20;
                    uVar6 = *(undefined4 *)(var_1d8h + 4);
                    uVar7 = *(undefined4 *)(var_1d8h + 8);
                    uVar8 = *(undefined4 *)(var_1d8h + 0xc);
                    puVar3 = (undefined4 *)(iVar32 + uVar23);
                    *puVar3 = *(undefined4 *)var_1d8h;
                    puVar3[1] = uVar6;
                    puVar3[2] = uVar7;
                    puVar3[3] = uVar8;
                    iVar13 = *(int32_t *)((int64_t)puVar19 + 4);
                    iVar20 = *(int32_t *)(puVar19 + 1);
                    iVar26 = *(int32_t *)((int64_t)puVar19 + 0xc);
                    piVar2 = (int32_t *)(iVar32 + 0x10 + uVar23);
                    *piVar2 = *(int32_t *)puVar19;
                    piVar2[1] = iVar13;
                    piVar2[2] = iVar20;
                    piVar2[3] = iVar26;
                    if (iVar17 == var_a8h) {
                        iVar29 = var_a8h - var_b0h;
                        uVar21 = uVar23;
                        iVar17 = var_b0h;
                    } else {
                        func_0x000180498030(uVar23, var_b0h, iVar17 - var_b0h);
                        iVar29 = var_a8h - iVar17;
                        uVar21 = iVar32 + 0x20 + uVar23;
                    }
                    func_0x000180498030(uVar21, iVar17, iVar29);
                    if (var_b0h != 0) {
                        uVar21 = var_a0h - var_b0h & 0xffffffffffffffe0;
                        iVar17 = var_b0h;
                        if (0xfff < uVar21) {
                            if (0x1f < (var_b0h - *(int64_t *)(var_b0h + -8)) - 8U) goto code_r0x000180040683;
                            uVar21 = uVar21 + 0x27;
                            iVar17 = *(int64_t *)(var_b0h + -8);
                        }
                        fcn.180459c3c(iVar17, uVar21);
                    }
                    var_b0h = uVar23;
                    var_a0h = uVar23 + uVar28;
                    var_a8h = uVar1 * 0x20 + uVar23;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                } else {
                    iVar13 = *(int32_t *)(var_1d8h + 4);
                    iVar20 = *(int32_t *)(var_1d8h + 8);
                    iVar26 = *(int32_t *)(var_1d8h + 0xc);
                    *(int32_t *)var_a8h = *(int32_t *)var_1d8h;
                    *(int32_t *)(var_a8h + 4) = iVar13;
                    *(int32_t *)(var_a8h + 8) = iVar20;
                    *(int32_t *)(var_a8h + 0xc) = iVar26;
                    iVar13 = *(int32_t *)((int64_t)puVar19 + 4);
                    iVar20 = *(int32_t *)(puVar19 + 1);
                    iVar26 = *(int32_t *)((int64_t)puVar19 + 0xc);
                    *(int32_t *)(var_a8h + 0x10) = *(int32_t *)puVar19;
                    *(int32_t *)(var_a8h + 0x14) = iVar13;
                    *(int32_t *)(var_a8h + 0x18) = iVar20;
                    *(int32_t *)(var_a8h + 0x1c) = iVar26;
                    var_a8h = var_a8h + 0x20;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                }
            }
            goto code_r0x00018004068a;
        }
    } else {
        fcn.180086cc0(arg1, 2, 0x180622ff4);
        if (((undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(undefined8 **)0x180782430) &&
           ((iVar13 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4), iVar13 == 6 || (iVar13 == 3)))) {
            var_1d8h = 0;
            uVar15 = func_0x0001800860c0(arg1, 0xffffffff, &var_1d8h);
            _var_90h = ZEXT816(0);
            var_80h = 0;
            var_78h = 0;
            func_0x000180004830(&var_90h, uVar15, var_1d8h);
            if ((char)var_168h == '\0') {
                _var_188h = _var_90h;
                var_178h = var_80h;
                var_170h = var_78h;
                var_80h = 0;
                var_78h = 0xf;
                auVar9[15] = 0;
                auVar9._0_15_ = stack0xffffffffffffff71;
                _var_90h = auVar9 << 8;
                var_168h._0_1_ = '\x01';
            } else {
                func_0x000180012c10(&var_188h, &var_90h);
            }
            fcn.180004e40(&var_90h);
            var_1bch._0_4_ = (int32_t)var_1bch + 1;
        }
        func_0x0001800858c0(arg1, 0xfffffffe);
        fcn.180086cc0(arg1, 2, 0x180622fec);
        if (((undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(undefined8 **)0x180782430) &&
           ((iVar13 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4), iVar13 == 6 || (iVar13 == 3)))) {
            var_1d8h = 0;
            uVar15 = func_0x0001800860c0(arg1, 0xffffffff, &var_1d8h);
            _var_90h = ZEXT816(0);
            var_80h = 0;
            var_78h = 0;
            func_0x000180004830(&var_90h, uVar15, var_1d8h);
            if ((char)var_140h == '\0') {
                _var_160h = _var_90h;
                var_150h = var_80h;
                var_148h = var_78h;
                var_80h = 0;
                var_78h = 0xf;
                auVar10[15] = 0;
                auVar10._0_15_ = stack0xffffffffffffff71;
                _var_90h = auVar10 << 8;
                var_140h._0_1_ = '\x01';
            } else {
                func_0x000180012c10(&var_160h, &var_90h);
            }
            fcn.180004e40(&var_90h);
            var_1bch._0_4_ = (int32_t)var_1bch + 1;
        }
        func_0x0001800858c0(arg1, 0xfffffffe);
        fcn.180086cc0(arg1, 2, 0x180623010);
        iVar13 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar13 != 0) {
            var_138h = func_0x000180085f50(arg1, 0xffffffff, 0);
            var_134h._0_1_ = 1;
            var_134h._1_2_ = var_1d8h._5_2_;
            var_134h._3_1_ = var_1d8h._7_1_;
            var_1bch._0_4_ = (int32_t)var_1bch + 1;
        }
        func_0x0001800858c0(arg1, 0xfffffffe);
        fcn.180086cc0(arg1, 2, 0x180623000);
        puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if ((puVar19 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 1)) {
            func_0x0001800858c0(arg1, 0xfffffffe);
            fcn.180086cc0(arg1, 2, 0x180623030);
            puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
            if ((puVar19 != *(undefined8 **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 1))
            goto code_r0x00018003ff9d;
        } else {
code_r0x00018003ff9d:
            var_134h._4_1_ = *(int32_t *)puVar19 != 0;
        }
        func_0x0001800858c0(arg1, 0xfffffffe);
        fcn.180086cc0(arg1, 2, 0x180623020);
        puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if ((puVar19 != *(undefined8 **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
            if (puVar19 == *(undefined8 **)0x180782430) {
                puVar19 = (undefined8 *)0x0;
            }
            var_128h = *puVar19;
            var_1bch._0_4_ = (int32_t)var_1bch + 1;
        }
        func_0x0001800858c0(arg1, 0xfffffffe);
        fcn.180086cc0(arg1, 2, 0x180623050);
        puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        if ((puVar19 != *(undefined8 **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
            if (puVar19 == *(undefined8 **)0x180782430) {
                puVar19 = (undefined8 *)0x0;
            }
            func_0x0001800416d0(&var_1a0h, puVar19);
            uVar23 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180086510(arg1);
            iVar13 = func_0x000180087970(arg1, uVar23 & 0xffffffff);
            while (iVar13 != 0) {
                puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
                if (puVar19 == *(undefined8 **)0x180782430) {
                    puVar19 = (undefined8 *)0x0;
                }
                func_0x0001800416d0(&var_118h, puVar19);
                func_0x0001800858c0(arg1, 0xfffffffe);
                iVar13 = func_0x000180087970(arg1, uVar23 & 0xffffffff);
            }
            if (var_118h != var_110h) {
                var_1bch._0_4_ = (int32_t)var_1bch + 1;
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        fcn.180086cc0(arg1, 2, 0x180623040);
        puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
        puVar25 = auStack_1f8;
        if ((puVar19 != *(undefined8 **)0x180782430) &&
           (puVar25 = auStack_1f8, *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
            if (puVar19 == *(undefined8 **)0x180782430) {
                puVar19 = (undefined8 *)0x0;
            }
            func_0x0001800416d0(&var_1a0h, puVar19);
            var_1d8h = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
            func_0x000180086510(arg1);
            while( true ) {
                iVar13 = func_0x000180087970(arg1);
                iVar17 = var_f8h;
                if (iVar13 == 0) break;
                puVar19 = (undefined8 *)(*(int64_t *)(arg1 + 0x40) - 0x10);
                if (puVar19 == *(undefined8 **)0x180782430) {
                    puVar19 = (undefined8 *)0x0;
                }
                if (var_f8h == var_f0h) {
                    iVar32 = var_f8h - var_100h >> 4;
                    if (iVar32 == 0xfffffffffffffff) goto code_r0x000180040aba;
                    uVar23 = var_f0h - var_100h >> 4;
                    if (0xfffffffffffffff - (uVar23 >> 1) < uVar23) goto code_r0x000180040ac0;
                    uVar1 = iVar32 + 1;
                    uVar23 = (uVar23 >> 1) + uVar23;
                    uVar28 = uVar1;
                    if (uVar1 <= uVar23) {
                        uVar28 = uVar23;
                    }
                    if (0xfffffffffffffff < uVar28) goto code_r0x000180040ac0;
                    uVar28 = uVar28 * 0x10;
                    if (uVar28 == 0) {
                        uVar23 = 0;
                    } else if (uVar28 < 0x1000) {
                        uVar23 = func_0x000180459890(uVar28);
                    } else {
                        if (uVar28 + 0x27 <= uVar28) goto code_r0x000180040ac0;
                        iVar29 = func_0x000180459890();
                        if (iVar29 == 0) goto code_r0x000180040683;
                        uVar23 = iVar29 + 0x27U & 0xffffffffffffffe0;
                        *(int64_t *)(uVar23 - 8) = iVar29;
                    }
                    iVar13 = *(int32_t *)((int64_t)puVar19 + 4);
                    iVar20 = *(int32_t *)(puVar19 + 1);
                    iVar26 = *(int32_t *)((int64_t)puVar19 + 0xc);
                    piVar2 = (int32_t *)(iVar32 * 0x10 + uVar23);
                    *piVar2 = *(int32_t *)puVar19;
                    piVar2[1] = iVar13;
                    piVar2[2] = iVar20;
                    piVar2[3] = iVar26;
                    if (iVar17 == var_f8h) {
                        iVar29 = var_f8h - var_100h;
                        uVar21 = uVar23;
                        iVar17 = var_100h;
                    } else {
                        func_0x000180498030(uVar23, var_100h, iVar17 - var_100h);
                        iVar29 = var_f8h - iVar17;
                        uVar21 = iVar32 * 0x10 + 0x10 + uVar23;
                    }
                    func_0x000180498030(uVar21, iVar17, iVar29);
                    if (var_100h != 0) {
                        uVar21 = var_f0h - var_100h & 0xfffffffffffffff0;
                        iVar17 = var_100h;
                        if (0xfff < uVar21) {
                            if (0x1f < (var_100h - *(int64_t *)(var_100h + -8)) - 8U) goto code_r0x000180040683;
                            uVar21 = uVar21 + 0x27;
                            iVar17 = *(int64_t *)(var_100h + -8);
                        }
                        fcn.180459c3c(iVar17, uVar21);
                    }
                    var_100h = uVar23;
                    var_f0h = uVar28 + uVar23;
                    var_f8h = uVar1 * 0x10 + uVar23;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                } else {
                    iVar13 = *(int32_t *)((int64_t)puVar19 + 4);
                    iVar20 = *(int32_t *)(puVar19 + 1);
                    iVar26 = *(int32_t *)((int64_t)puVar19 + 0xc);
                    *(int32_t *)var_f8h = *(int32_t *)puVar19;
                    *(int32_t *)(var_f8h + 4) = iVar13;
                    *(int32_t *)(var_f8h + 8) = iVar20;
                    *(int32_t *)(var_f8h + 0xc) = iVar26;
                    var_f8h = var_f8h + 0x10;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                }
            }
            bVar33 = var_100h == var_f8h;
            goto code_r0x000180040692;
        }
    }
code_r0x000180040698:
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    iVar17 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1e0);
joined_r0x0001800406ab:
    iVar32 = iVar17;
    if (iVar32 != 0) {
        iVar17 = *(int64_t *)(iVar32 + 8);
        iVar13 = *(int32_t *)(iVar32 + 0x24);
        iVar29 = (int64_t)*(int32_t *)(iVar32 + 0x30) + iVar32 + 0x40;
        iVar20 = *(int32_t *)(iVar32 + 0x20);
        iVar26 = *(int32_t *)(iVar32 + 0x34);
        do {
            do {
                iVar29 = iVar29 + iVar13;
                if (iVar29 == (int64_t)((int32_t)(((int64_t)iVar20 - 0x40U) / (uint64_t)(int64_t)iVar13) * iVar13) +
                              iVar32 + 0x40) goto joined_r0x0001800406ab;
            } while (*(char *)(iVar29 + 2) == '\0');
            *(undefined8 *)(puVar25 + -8) = 0x18004070b;
            cVar12 = func_0x000180040b00(puVar25 + 0x28, puVar25 + 0x30, iVar32, iVar29);
        } while ((cVar12 == '\0') || (iVar26 = iVar26 + -1, iVar26 != 0));
        goto joined_r0x0001800406ab;
    }
    if (*(int32_t *)(puVar25 + 0x2c) == 0) {
        *(undefined8 *)(puVar25 + -8) = 0x1800408b6;
        func_0x000180086fd0(arg1, *(int64_t *)(puVar25 + 0x48) - *(int64_t *)(puVar25 + 0x40) >> 3, 0);
        piVar31 = *(int64_t **)(puVar25 + 0x48);
        iVar13 = 1;
        for (piVar27 = *(int64_t **)(puVar25 + 0x40); piVar27 != piVar31; piVar27 = piVar27 + 1) {
            iVar17 = *piVar27;
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                iVar20 = *(int32_t *)(arg1 + 0x60);
                iVar18 = (int32_t)(int32_t *)(arg1 + 0x60);
                iVar26 = iVar20 - iVar18;
                if (iVar20 - iVar18 < 2) {
                    iVar26 = iVar26 + 2;
                } else {
                    iVar26 = iVar26 * 2;
                }
                *(undefined8 *)(puVar25 + -8) = 0x180040904;
                func_0x000180093240(arg1, iVar26, 0);
            }
            if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
                *(undefined8 *)(puVar25 + -8) = 0x18004092b;
                iVar20 = func_0x000180085510(arg1, 1);
                if (iVar20 == 0) goto code_r0x000180040acc;
            }
            pdVar4 = *(double **)(arg1 + 0x40);
            *pdVar4 = (double)iVar13;
            *(undefined4 *)((int64_t)pdVar4 + 0xc) = 3;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            **(int64_t **)(arg1 + 0x40) = iVar17;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(iVar17 + 2);
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar20 = *(int32_t *)(arg1 + 0x60);
                iVar18 = (int32_t)(int32_t *)(arg1 + 0x60);
                iVar26 = iVar20 - iVar18;
                if (iVar20 - iVar18 < 1) {
                    iVar26 = iVar26 + 1;
                } else {
                    iVar26 = iVar26 * 2;
                }
                *(undefined8 *)(puVar25 + -8) = 0x180040995;
                func_0x000180093240(arg1, iVar26, 0);
            }
            iVar17 = *(int64_t *)(arg1 + 0x40);
            *(int64_t *)(arg1 + 0x40) = iVar17 + 0x10;
            *(undefined8 *)(puVar25 + -8) = 0x1800409b1;
            func_0x0001800a8680(arg1, iVar17 + -0x20);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
            iVar13 = iVar13 + 1;
        }
        *(undefined8 *)(puVar25 + -8) = 0x1800409cc;
        func_0x000180041a30(&var_b0h);
        *(undefined8 *)(puVar25 + -8) = 0x1800409d5;
        func_0x00018002a260(&var_c8h);
        *(undefined8 *)(puVar25 + -8) = 0x1800409de;
        func_0x00018002a260(&var_e0h);
        *(undefined8 *)(puVar25 + -8) = 0x1800409e7;
        func_0x00018002a260(&var_100h);
        *(undefined8 *)(puVar25 + -8) = 0x1800409f0;
        func_0x00018002a260(&var_118h);
        if ((char)var_140h != '\0') {
            *(undefined8 *)(puVar25 + -8) = 0x1800409ff;
            fcn.180004e40(&var_160h);
        }
        if ((char)var_168h != '\0') {
            *(undefined8 *)(puVar25 + -8) = 0x180040a0f;
            fcn.180004e40(puVar25 + 0x70);
        }
        *(undefined8 *)(puVar25 + -8) = 0x180040a19;
        func_0x00018002a260(puVar25 + 0x58);
        *(undefined8 *)(puVar25 + -8) = 0x180040a23;
        func_0x00018000ace0(puVar25 + 0x40);
        if ((uint64_t)var_58h < 0x10) goto code_r0x000180040a6a;
        iVar17 = var_70h;
        if (0xfff < var_58h + 1U) {
            iVar17 = *(int64_t *)(var_70h + -8);
            iVar32 = var_70h - iVar17;
            goto joined_r0x000180040a53;
        }
    } else {
        piVar27 = *(int64_t **)(puVar25 + 0x40);
        if (piVar27 == *(int64_t **)(puVar25 + 0x48)) {
            if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
                *(undefined8 *)(puVar25 + -8) = 0x180040762;
                iVar13 = func_0x000180085510(arg1, 1);
                if (iVar13 == 0) {
code_r0x000180040acc:
                    *(undefined8 *)(puVar25 + -8) = 0x180040adb;
                    func_0x000180099450(arg1, 0x18063d8d0);
                    *(undefined8 *)(puVar25 + -8) = 0x180040ae3;
                    func_0x000180087960(arg1);
code_r0x000180040ae4:
                    *(undefined8 *)(puVar25 + -8) = 0x180040af8;
                    func_0x000180088380(arg1, 1, 0x180622fc0);
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
            }
            *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        } else {
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar13 = *(int32_t *)(arg1 + 0x60);
                iVar26 = (int32_t)(int32_t *)(arg1 + 0x60);
                iVar20 = iVar13 - iVar26;
                if (iVar13 - iVar26 < 1) {
                    iVar20 = iVar20 + 1;
                } else {
                    iVar20 = iVar20 * 2;
                }
                *(undefined8 *)(puVar25 + -8) = 0x1800407a7;
                func_0x000180093240(arg1, iVar20, 0);
                piVar27 = *(int64_t **)(puVar25 + 0x40);
            }
            iVar17 = *piVar27;
            **(int64_t **)(arg1 + 0x40) = iVar17;
            *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(iVar17 + 2);
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                iVar13 = *(int32_t *)(arg1 + 0x60);
                iVar26 = (int32_t)(int32_t *)(arg1 + 0x60);
                iVar20 = iVar13 - iVar26;
                if (iVar13 - iVar26 < 1) {
                    iVar20 = iVar20 + 1;
                } else {
                    iVar20 = iVar20 * 2;
                }
                *(undefined8 *)(puVar25 + -8) = 0x1800407f1;
                func_0x000180093240(arg1, iVar20, 0);
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        *(undefined8 *)(puVar25 + -8) = 0x1800407ff;
        func_0x000180041a30(&var_b0h);
        *(undefined8 *)(puVar25 + -8) = 0x180040808;
        func_0x00018002a260(&var_c8h);
        *(undefined8 *)(puVar25 + -8) = 0x180040811;
        func_0x00018002a260(&var_e0h);
        *(undefined8 *)(puVar25 + -8) = 0x18004081a;
        func_0x00018002a260(&var_100h);
        *(undefined8 *)(puVar25 + -8) = 0x180040823;
        func_0x00018002a260(&var_118h);
        if ((char)var_140h != '\0') {
            *(undefined8 *)(puVar25 + -8) = 0x180040832;
            fcn.180004e40(&var_160h);
        }
        if ((char)var_168h != '\0') {
            *(undefined8 *)(puVar25 + -8) = 0x180040842;
            fcn.180004e40(puVar25 + 0x70);
        }
        *(undefined8 *)(puVar25 + -8) = 0x18004084c;
        func_0x00018002a260(puVar25 + 0x58);
        *(undefined8 *)(puVar25 + -8) = 0x180040856;
        func_0x00018000ace0(puVar25 + 0x40);
        if ((uint64_t)var_58h < 0x10) goto code_r0x000180040a6a;
        iVar17 = var_70h;
        if (0xfff < var_58h + 1U) {
            iVar17 = *(int64_t *)(var_70h + -8);
            iVar32 = var_70h - iVar17;
joined_r0x000180040a53:
            if (0x1f < iVar32 - 8U) {
                pcVar5 = (code *)swi(0x29);
                iVar17 = (*pcVar5)(5);
                puVar25 = puVar25 + 8;
            }
        }
    }
    *(undefined8 *)(puVar25 + -8) = 0x180040a6a;
    fcn.180459c3c(iVar17);
code_r0x000180040a6a:
    *(undefined8 *)(puVar25 + -8) = 0x180040a7e;
    func_0x000180459870(var_50h ^ (uint64_t)puVar25);
    return;
code_r0x000180040683:
    pcVar5 = (code *)swi(0x29);
    (*pcVar5)(5);
    puVar24 = auStack_1f0;
code_r0x00018004068a:
    bVar33 = var_b0h == var_a8h;
code_r0x000180040692:
    puVar25 = puVar24;
    if (!bVar33) {
        *(int32_t *)(puVar24 + 0x3c) = *(int32_t *)(puVar24 + 0x3c) + 1;
    }
    goto code_r0x000180040698;
}

// ============================================================
// Function: FUN_180040b00
// Address: 0x180040b00
// Size: 2463 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h

void fcn.180040b00(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    code *pcVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    char cVar4;
    char cVar5;
    int32_t iVar6;
    undefined8 uVar7;
    double *pdVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    uint64_t uVar16;
    double *pdVar17;
    int64_t iVar18;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    double *pdVar22;
    double *pdVar23;
    double *pdVar24;
    int32_t iVar25;
    int64_t iVar26;
    bool bVar27;
    int64_t var_8h;
    undefined8 uStack_100;
    undefined auStack_f8 [8];
    undefined auStack_f0 [24];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar19 = auStack_f8;
    puVar20 = auStack_f8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    puVar21 = auStack_f8;
    var_d0h = arg2;
    var_c8h = arg4;
    var_a8h = arg4;
    if (arg4 == 0) goto code_r0x000180041454;
    iVar15 = *(int64_t *)arg2;
    uVar10 = ~(uint32_t)*(uint8_t *)(*(int64_t *)(iVar15 + 0x20) + 0x58) & 3 ^ (uint32_t)*(uint8_t *)(arg4 + 1);
    pdVar8 = (double *)(uint64_t)uVar10;
    puVar21 = auStack_f8;
    if (((uVar10 & 0xb) == 0) ||
       ((*(char *)(arg2 + 9) != '\0' && (puVar21 = auStack_f8, *(int64_t *)(arg2 + 0x10) != *(int64_t *)(arg2 + 0x18))))
       ) goto code_r0x000180041454;
    iVar25 = 0;
    var_d8h._0_4_ = 0;
    if (*(char *)(arg2 + 8) == '\0') {
        puVar21 = auStack_f8;
        if (*(char *)(arg4 + 2) == '\a') {
            if (*(int64_t *)(arg2 + 0xe0) != 0) {
                puVar21 = auStack_f8;
                if (*(int64_t *)(arg4 + 0x10) != *(int64_t *)(arg2 + 0xe0)) goto code_r0x000180041454;
                iVar25 = 1;
                var_d8h._0_4_ = 1;
            }
            iVar18 = *(int64_t *)(arg2 + 0xe8);
            iVar12 = *(int64_t *)(arg2 + 0xf0);
            if (iVar18 != iVar12) {
                iVar26 = iVar12 - iVar18;
                iVar25 = 0;
                do {
                    iVar9 = func_0x0001800a0ea0(arg4, iVar18);
                    if ((iVar9 != 0) && (0 < *(int32_t *)(iVar9 + 0xc))) {
                        iVar25 = iVar25 + 1;
                    }
                    iVar18 = iVar18 + 0x10;
                } while (iVar18 != iVar12);
                puVar21 = auStack_f8;
                if (iVar25 != (int32_t)(iVar26 >> 4)) goto code_r0x000180041454;
                iVar25 = (int32_t)var_d8h + 1;
                var_d8h._0_4_ = iVar25;
            }
            iVar26 = var_c8h;
            iVar18 = *(int64_t *)(var_d0h + 0x100);
            iVar12 = *(int64_t *)(var_d0h + 0x108);
            if (iVar18 != iVar12) {
                iVar25 = 0;
                **(int64_t **)(iVar15 + 0x40) = var_c8h;
                *(undefined4 *)(*(int64_t *)(iVar15 + 0x40) + 0xc) = 7;
                if (*(int64_t *)(iVar15 + 0x30) - *(int64_t *)(iVar15 + 0x40) < 0x11) {
                    iVar6 = *(int32_t *)(iVar15 + 0x60);
                    iVar11 = (int32_t)(int32_t *)(iVar15 + 0x60);
                    iVar13 = iVar6 - iVar11;
                    if (iVar6 - iVar11 < 1) {
                        iVar13 = iVar13 + 1;
                    } else {
                        iVar13 = iVar13 * 2;
                    }
                    func_0x000180093240(iVar15, iVar13, 0);
                }
                *(int64_t *)(iVar15 + 0x40) = *(int64_t *)(iVar15 + 0x40) + 0x10;
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                pdVar8 = *(double **)(var_d0h + 0x108);
                for (pdVar22 = *(double **)(var_d0h + 0x100); pdVar22 != pdVar8; pdVar22 = pdVar22 + 2) {
                    func_0x000180086510(iVar15);
                    iVar26 = iVar15;
                    iVar6 = func_0x000180087970(iVar15, uVar16 & 0xffffffff);
                    while (iVar6 != 0) {
                        iVar9 = *(int64_t *)(iVar15 + 0x40);
                        pdVar17 = (double *)(iVar9 + -0x10);
                        if (pdVar17 == *(double **)0x180782430) {
                            pdVar17 = (double *)0x0;
                        }
                        if ((*(int32_t *)((int64_t)pdVar17 + 0xc) == 3) && (*(int32_t *)((int64_t)pdVar22 + 0xc) == 3))
                        {
                            if (*pdVar17 == *pdVar22) {
code_r0x000180041265:
                                iVar25 = iVar25 + 1;
                            }
                        } else {
                            cVar5 = fcn.18003fa20(iVar26, (int64_t)pdVar17, (int64_t)pdVar22);
                            if (cVar5 != '\0') goto code_r0x000180041265;
                        }
                        *(int64_t *)(iVar15 + 0x40) = iVar9 + -0x10;
                        iVar26 = iVar15;
                        iVar6 = func_0x000180087970(iVar15, uVar16 & 0xffffffff);
                    }
                    iVar26 = var_c8h;
                }
                *(int64_t *)(iVar15 + 0x40) = *(int64_t *)(iVar15 + 0x40) + -0x10;
                puVar21 = auStack_f8;
                if (iVar25 != (int32_t)(iVar12 - iVar18 >> 4)) goto code_r0x000180041454;
                iVar25 = (int32_t)var_d8h + 1;
                var_d8h._0_4_ = iVar25;
            }
            iVar18 = var_d0h;
            if (*(int64_t *)(var_d0h + 0x118) != *(int64_t *)(var_d0h + 0x120)) {
                var_c8h = *(int64_t *)(var_d0h + 0x120) - *(int64_t *)(var_d0h + 0x118) >> 5;
                iVar25 = 0;
                **(int64_t **)(iVar15 + 0x40) = iVar26;
                *(undefined4 *)(*(int64_t *)(iVar15 + 0x40) + 0xc) = 7;
                if (*(int64_t *)(iVar15 + 0x30) - *(int64_t *)(iVar15 + 0x40) < 0x11) {
                    iVar6 = *(int32_t *)(iVar15 + 0x60);
                    iVar11 = (int32_t)(int32_t *)(iVar15 + 0x60);
                    iVar13 = iVar6 - iVar11;
                    if (iVar6 - iVar11 < 1) {
                        iVar13 = iVar13 + 1;
                    } else {
                        iVar13 = iVar13 * 2;
                    }
                    func_0x000180093240(iVar15, iVar13, 0);
                }
                *(int64_t *)(iVar15 + 0x40) = *(int64_t *)(iVar15 + 0x40) + 0x10;
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_b8h = uVar16;
                func_0x000180086510(iVar15);
                iVar12 = iVar15;
                iVar6 = func_0x000180087970(iVar15, uVar16 & 0xffffffff);
                while (iVar6 != 0) {
                    pdVar8 = (double *)(*(int64_t *)(iVar15 + 0x40) + -0x20);
                    if (pdVar8 == *(double **)0x180782430) {
                        pdVar8 = (double *)0x0;
                    }
                    pdVar22 = (double *)(*(int64_t *)(iVar15 + 0x40) + -0x10);
                    if (pdVar22 == *(double **)0x180782430) {
                        pdVar22 = (double *)0x0;
                    }
                    pdVar17 = *(double **)(iVar18 + 0x118);
                    pdVar24 = *(double **)(iVar18 + 0x120);
                    if (pdVar17 != pdVar24) {
                        iVar6 = *(int32_t *)((int64_t)pdVar8 + 0xc);
                        do {
                            if ((iVar6 == 3) && (*(int32_t *)((int64_t)pdVar17 + 0xc) == 3)) {
                                if (*pdVar8 == *pdVar17) {
code_r0x0001800413d0:
                                    if ((*(int32_t *)((int64_t)pdVar22 + 0xc) == 3) &&
                                       (*(int32_t *)((int64_t)pdVar17 + 0x1c) == 3)) {
                                        if (*pdVar22 == pdVar17[2]) {
code_r0x000180041410:
                                            iVar25 = iVar25 + 1;
                                            break;
                                        }
                                    } else {
                                        cVar5 = fcn.18003fa20(iVar12, (int64_t)pdVar22, (int64_t)(pdVar17 + 2));
                                        if (cVar5 != '\0') goto code_r0x000180041410;
                                    }
                                }
                            } else {
                                cVar5 = fcn.18003fa20(iVar12, (int64_t)pdVar8, (int64_t)pdVar17);
                                if (cVar5 != '\0') goto code_r0x0001800413d0;
                            }
                            pdVar17 = pdVar17 + 4;
                        } while (pdVar17 != pdVar24);
                    }
                    *(int64_t *)(iVar15 + 0x40) = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    iVar12 = iVar15;
                    iVar6 = func_0x000180087970(iVar15, var_b8h & 0xffffffff);
                    iVar18 = var_d0h;
                }
                *(int64_t *)(iVar15 + 0x40) = *(int64_t *)(iVar15 + 0x40) + -0x10;
                puVar21 = auStack_f8;
                if (iVar25 != (int32_t)var_c8h) goto code_r0x000180041454;
                iVar25 = (int32_t)var_d8h + 1;
            }
            puVar21 = auStack_f8;
            if (iVar25 == *(int32_t *)(iVar18 + 0xc)) {
                func_0x000180041870(iVar18 + 0x10, &var_a8h);
                puVar21 = auStack_f8;
            }
        }
        goto code_r0x000180041454;
    }
    puVar21 = auStack_f8;
    if (*(char *)(arg4 + 2) != '\b') goto code_r0x000180041454;
    cVar5 = *(char *)(arg4 + 3);
    var_d8h._4_1_ = cVar5;
    if (*(char *)(arg2 + 0x98) != '\0') {
        func_0x000180013530();
        if (*(char *)(arg4 + 3) == '\0') {
            bVar27 = *(int64_t *)(*(int64_t *)(arg4 + 0x20) + 0x78) == 1;
        } else {
            bVar27 = *(char *)(arg4 + 3) == '\x02';
        }
        puVar21 = auStack_f8;
        if (bVar27) goto code_r0x000180041454;
    }
    if (*(char *)(arg2 + 0x60) != '\0') {
        if (cVar5 == '\0') {
            piVar14 = (int64_t *)(*(int64_t *)(arg4 + 0x20) + 0x20);
            iVar15 = (int64_t)piVar14 - *piVar14;
            puVar21 = auStack_f8;
            if (iVar15 == 0) goto code_r0x000180041454;
            iVar15 = iVar15 + 0x18;
        } else {
            iVar15 = (int64_t)(int64_t *)(arg4 + 0x30) - *(int64_t *)(arg4 + 0x30);
        }
        puVar21 = auStack_f8;
        if (iVar15 == 0) goto code_r0x000180041454;
        pdVar8 = (double *)(arg2 + 0x40);
        if (*(char *)(arg2 + 0x60) == '\0') {
            fcn.18003f360();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        cVar4 = func_0x00018000a630();
        puVar21 = auStack_f8;
        if (cVar4 == '\0') goto code_r0x000180041454;
        var_d8h._0_4_ = 1;
    }
    if (*(char *)(arg2 + 0x94) != '\0') {
        puVar21 = auStack_f8;
        if ((cVar5 != '\0') ||
           (pdVar8 = *(double **)(arg4 + 0x20), puVar21 = auStack_f8,
           *(int32_t *)((int64_t)pdVar8 + 0x8c) != *(int32_t *)(arg2 + 0x90))) goto code_r0x000180041454;
        var_d8h._0_4_ = (int32_t)var_d8h + 1;
    }
    if (*(int64_t *)(arg2 + 0xa0) != 0) {
        puVar21 = auStack_f8;
        if (*(int64_t *)(arg4 + 0x10) != *(int64_t *)(arg2 + 0xa0)) goto code_r0x000180041454;
        var_d8h._0_4_ = (int32_t)var_d8h + 1;
    }
    if (*(int64_t *)(arg2 + 0xa8) != 0) {
        puVar21 = auStack_f8;
        if ((cVar5 != '\0') || (puVar21 = auStack_f8, *(int64_t *)(arg4 + 0x20) != *(int64_t *)(arg2 + 0xa8)))
        goto code_r0x000180041454;
        var_d8h._0_4_ = (int32_t)var_d8h + 1;
    }
    puVar21 = auStack_f8;
    if ((*(char *)(arg2 + 0x88) != '\0') && (puVar21 = auStack_f8, cVar5 == '\0')) {
        func_0x000180027960(&var_a0h, *(undefined8 *)(arg4 + 0x20));
        _var_88h = ZEXT816(0);
        var_78h = 0;
        var_70h = 0;
        func_0x000180004830(&var_88h, var_a0h, var_98h - var_a0h);
        func_0x00018007ff90();
        uVar7 = func_0x00018020e890();
        var_b8h = (int64_t)&var_88h;
        if (0xf < (uint64_t)var_70h) {
            var_b8h = var_88h;
        }
        var_b0h = var_78h;
        func_0x000180081030(var_78h, &var_68h, &var_b8h, uVar7);
        pdVar8 = (double *)&var_68h;
        cVar4 = func_0x000180017d40(pdVar8, arg2 + 0x68);
        if (cVar4 == '\0') {
            if (0xf < (uint64_t)var_50h) {
                uVar16 = var_50h + 1;
                if (0xfff < uVar16) {
                    if (0x1f < (var_68h - *(int64_t *)(var_68h + -8)) - 8U) goto code_r0x000180040e34;
                    uVar16 = var_50h + 0x28;
                    var_68h = *(int64_t *)(var_68h + -8);
                }
                fcn.180459c3c(var_68h, uVar16);
            }
            if (0xf < (uint64_t)var_70h) {
                uVar16 = var_70h + 1;
                iVar15 = var_88h;
                if (0xfff < uVar16) {
                    if (0x1f < (var_88h - *(int64_t *)(var_88h + -8)) - 8U) goto code_r0x000180040e75;
                    uVar16 = var_70h + 0x28;
                    iVar15 = *(int64_t *)(var_88h + -8);
                }
                fcn.180459c3c(iVar15, uVar16);
            }
            var_78h = 0;
            var_70h = 0xf;
            auVar2[15] = 0;
            auVar2._0_15_ = stack0xffffffffffffff79;
            _var_88h = auVar2 << 8;
            puVar21 = auStack_f8;
            if (var_a0h == 0) goto code_r0x000180041454;
            if ((uint64_t)(var_90h - var_a0h) < 0x1000) {
                fcn.180459c3c(var_a0h);
                puVar21 = auStack_f8;
                goto code_r0x000180041454;
            }
            if ((var_a0h - *(int64_t *)(var_a0h + -8)) - 8U < 0x20) {
                fcn.180459c3c(*(int64_t *)(var_a0h + -8), (var_90h - var_a0h) + 0x27);
                puVar21 = auStack_f8;
                goto code_r0x000180041454;
            }
code_r0x000180040ed0:
            var_70h = 0xf;
            var_78h = 0;
            pcVar1 = (code *)swi(0x29);
            pdVar8 = (double *)(*pcVar1)(5);
            puVar20 = puVar20 + 8;
        } else {
            puVar19 = auStack_f8;
            if (0xf < (uint64_t)var_50h) {
                pdVar8 = (double *)var_68h;
                puVar21 = auStack_f8;
                if ((0xfff < var_50h + 1U) &&
                   (pdVar8 = *(double **)(var_68h + -8), puVar21 = auStack_f8, 0x1f < (var_68h - (int64_t)pdVar8) - 8U))
                {
code_r0x000180040e34:
                    pcVar1 = (code *)swi(0x29);
                    pdVar8 = (double *)(*pcVar1)(5);
                    puVar21 = auStack_f0;
                }
                *(undefined8 *)(puVar21 + -8) = 0x180040e43;
                fcn.180459c3c();
                puVar19 = puVar21;
            }
            puVar20 = puVar19;
            if (0xf < (uint64_t)var_70h) {
                pdVar8 = (double *)var_88h;
                if ((0xfff < var_70h + 1U) &&
                   (pdVar8 = *(double **)(var_88h + -8), 0x1f < (var_88h - (int64_t)pdVar8) - 8U)) {
code_r0x000180040e75:
                    pcVar1 = (code *)swi(0x29);
                    pdVar8 = (double *)(*pcVar1)(5);
                    puVar19 = puVar19 + 8;
                }
                *(undefined8 *)(puVar19 + -8) = 0x180040e84;
                fcn.180459c3c();
                puVar20 = puVar19;
            }
            var_d8h._0_4_ = (int32_t)var_d8h + 1;
            var_78h = 0;
            var_70h = 0xf;
            auVar3[15] = 0;
            auVar3._0_15_ = stack0xffffffffffffff79;
            _var_88h = auVar3 << 8;
            puVar21 = puVar20;
            if (var_a0h == 0) goto code_r0x000180040ee2;
            pdVar8 = (double *)var_a0h;
            if ((0xfff < (uint64_t)(var_90h - var_a0h)) &&
               (pdVar8 = *(double **)(var_a0h + -8), 0x1f < (var_a0h - (int64_t)pdVar8) - 8U))
            goto code_r0x000180040ed0;
        }
        *(undefined8 *)(puVar20 + -8) = 0x180040edf;
        fcn.180459c3c();
        puVar21 = puVar20;
    }
code_r0x000180040ee2:
    pdVar22 = *(double **)(arg2 + 0xb0);
    pdVar17 = *(double **)(arg2 + 0xb8);
    if ((pdVar22 != pdVar17) && (cVar5 == '\0')) {
        var_b8h = (int64_t)pdVar17 - (int64_t)pdVar22 >> 4;
        iVar25 = 0;
        iVar15 = *(int64_t *)(arg4 + 0x20);
        uVar16 = 0;
        if (0 < *(int32_t *)(iVar15 + 0xa8)) {
            do {
                pdVar23 = (double *)(uVar16 * 0x10 + *(int64_t *)(iVar15 + 0x38));
                iVar6 = *(int32_t *)((int64_t)pdVar23 + 0xc);
                pdVar24 = pdVar22;
                do {
                    if ((iVar6 == 3) && (*(int32_t *)((int64_t)pdVar24 + 0xc) == 3)) {
                        if (*pdVar23 == *pdVar24) {
code_r0x000180040f73:
                            iVar25 = iVar25 + 1;
                            break;
                        }
                    } else {
                        *(undefined8 *)(puVar21 + -8) = 0x18004109a;
                        cVar5 = fcn.18003fa20(pdVar8, (int64_t)pdVar23, (int64_t)pdVar24);
                        if (cVar5 != '\0') goto code_r0x000180040f73;
                    }
                    pdVar24 = pdVar24 + 2;
                } while (pdVar24 != pdVar17);
                uVar10 = (int32_t)uVar16 + 1;
                uVar16 = (uint64_t)uVar10;
                iVar15 = *(int64_t *)(var_c8h + 0x20);
                arg4 = var_c8h;
                cVar5 = var_d8h._4_1_;
            } while ((int32_t)uVar10 < *(int32_t *)(iVar15 + 0xa8));
        }
        if (iVar25 != (int32_t)var_b8h) goto code_r0x000180041454;
        var_d8h._0_4_ = (int32_t)var_d8h + 1;
        arg2 = var_d0h;
    }
    pdVar22 = *(double **)(arg2 + 200);
    pdVar17 = *(double **)(arg2 + 0xd0);
    iVar25 = (int32_t)var_d8h;
    if ((pdVar22 != pdVar17) && (cVar5 == '\0')) {
        var_b8h = (int64_t)pdVar17 - (int64_t)pdVar22 >> 4;
        iVar25 = 0;
        uVar16 = 0;
        if (*(char *)(arg4 + 4) != '\0') {
            do {
                pdVar24 = (double *)(arg4 + 0x28 + uVar16 * 0x10);
                if (*(int32_t *)((int64_t)pdVar24 + 0xc) == 0x10) {
                    pdVar8 = (double *)((int64_t)*pdVar24 + 0x10);
                    pdVar24 = *(double **)((int64_t)*pdVar24 + 8);
                    if (pdVar24 == pdVar8) {
                        pdVar24 = pdVar8;
                    }
                }
                iVar6 = *(int32_t *)((int64_t)pdVar24 + 0xc);
                pdVar23 = pdVar22;
                do {
                    if ((iVar6 == 3) && (*(int32_t *)((int64_t)pdVar23 + 0xc) == 3)) {
                        if (*pdVar24 == *pdVar23) {
code_r0x000180041048:
                            iVar25 = iVar25 + 1;
                            break;
                        }
                    } else {
                        *(undefined8 *)(puVar21 + -8) = 0x1800410bf;
                        cVar5 = fcn.18003fa20(pdVar8, (int64_t)pdVar24, (int64_t)pdVar23);
                        if (cVar5 != '\0') goto code_r0x000180041048;
                    }
                    pdVar23 = pdVar23 + 2;
                } while (pdVar23 != pdVar17);
                uVar10 = (int32_t)uVar16 + 1;
                uVar16 = (uint64_t)uVar10;
                arg4 = var_c8h;
            } while ((int32_t)uVar10 < (int32_t)(uint32_t)*(uint8_t *)(var_c8h + 4));
        }
        if (iVar25 != (int32_t)var_b8h) goto code_r0x000180041454;
        iVar25 = (int32_t)var_d8h + 1;
        arg2 = var_d0h;
    }
    if (iVar25 == *(int32_t *)(arg2 + 0xc)) {
        *(undefined8 *)(puVar21 + -8) = 0x180041085;
        func_0x000180041870(arg2 + 0x10, &var_a8h);
    }
code_r0x000180041454:
    *(undefined8 *)(puVar21 + -8) = 0x180041460;
    func_0x000180459870(var_48h ^ (uint64_t)puVar21);
    return;
}

// ============================================================
// Function: FUN_1800414b0
// Address: 0x1800414b0
// Size: 131 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800414b0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    func_0x000180041a30(arg1 + 0x118);
    func_0x00018002a260(arg1 + 0x100);
    func_0x00018002a260(arg1 + 0xe8);
    func_0x00018002a260(arg1 + 200);
    func_0x00018002a260(arg1 + 0xb0);
    if (*(char *)(arg1 + 0x88) != '\0') {
        fcn.180004e40();
    }
    if (*(char *)(arg1 + 0x60) != '\0') {
        fcn.180004e40(arg1 + 0x40);
    }
    func_0x00018002a260(arg1 + 0x28);
    uVar4 = *(uint64_t *)(arg1 + 0x10);
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x20) - uVar4) >> 3) * 8;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18000ad35;
        fcn.180459c3c(uVar4, uVar3);
        *(uint64_t *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180041540
// Address: 0x180041540
// Size: 394 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018004158f: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800415ca: Changing call to branch
// WARNING: Possible PIC construction at 0x000180041605: Changing call to branch
// WARNING: Possible PIC construction at 0x000180041640: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004167b: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180041645)
// WARNING: Removing unreachable block (ram,0x00018004160a)
// WARNING: Removing unreachable block (ram,0x0001800415cf)
// WARNING: Removing unreachable block (ram,0x000180041594)
// WARNING: Removing unreachable block (ram,0x000180041680)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180041540(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_98 [32];
    undefined8 uStack_78;
    undefined4 uStack_6c;
    uint64_t uStack_68;
    int64_t iStack_58;
    undefined8 uStack_50;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    func_0x000180018f70();
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.18003f3f0, 0x180623098, 0);
    uStack_50 = 0;
    uStack_68 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    iVar4 = (int32_t)(iVar1 - iVar2 >> 4);
    iStack_58 = arg2;
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar5 = func_0x000180085370();
        } else {
            uVar5 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar5 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
    }
    piVar6 = (int64_t *)(arg2 + 0x40);
    uVar3 = func_0x000180498cd0(0x180623098);
    uStack_78 = func_0x00018009a8e0(arg2, 0x180623098, uVar3);
    uStack_6c = 6;
    func_0x0001800a8680(arg2, uVar5, &uStack_78, *piVar6 + -0x10);
    *piVar6 = *piVar6 + -0x10;
    func_0x000180459870(uStack_68 ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_1800416d0
// Address: 0x1800416d0
// Size: 403 bytes
// ============================================================
undefined4 * fcn.1800416d0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    undefined *puVar11;
    undefined4 *unaff_RSI;
    uint64_t uVar12;
    int64_t iVar13;
    undefined4 *puVar14;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    puVar8 = *(undefined4 **)(arg1 + 8);
    if (puVar8 != *(undefined4 **)(arg1 + 0x10)) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar8 = *(undefined4 *)arg2;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = *(undefined4 **)(arg1 + 8);
        *(undefined4 **)(arg1 + 8) = puVar8 + 4;
        return puVar8;
    }
    puVar14 = (undefined4 *)((int64_t)puVar8 - *(int64_t *)arg1 >> 4);
    if (puVar14 == (undefined4 *)0xfffffffffffffff) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        puVar8 = (undefined4 *)(*pcVar3)();
        return puVar8;
    }
    uVar9 = (int64_t)*(undefined4 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 4;
    if (0xfffffffffffffff - (uVar9 >> 1) < uVar9) {
code_r0x00018004185d:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        puVar8 = (undefined4 *)(*pcVar3)();
        return puVar8;
    }
    uVar1 = (int64_t)puVar14 + 1;
    uVar9 = uVar9 + (uVar9 >> 1);
    uVar12 = uVar1;
    if (uVar1 <= uVar9) {
        uVar12 = uVar9;
    }
    if (0xfffffffffffffff < uVar12) goto code_r0x00018004185d;
    uVar9 = uVar12 * 0x10;
    if (uVar9 == 0) {
        unaff_RSI = (undefined4 *)0x0;
code_r0x0001800417ab:
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        puVar14 = unaff_RSI + (int64_t)puVar14 * 4;
        *puVar14 = *(undefined4 *)arg2;
        puVar14[1] = uVar4;
        puVar14[2] = uVar5;
        puVar14[3] = uVar6;
        puVar2 = *(undefined4 **)arg1;
        if (puVar8 == *(undefined4 **)(arg1 + 8)) {
            iVar13 = (int64_t)*(undefined4 **)(arg1 + 8) - (int64_t)puVar2;
            puVar10 = unaff_RSI;
            puVar8 = puVar2;
        } else {
            func_0x000180498030(unaff_RSI, puVar2, (int64_t)puVar8 - (int64_t)puVar2);
            puVar10 = puVar14 + 4;
            iVar13 = *(int64_t *)(arg1 + 8) - (int64_t)puVar8;
        }
        func_0x000180498030(puVar10, puVar8, iVar13);
        iVar13 = *(int64_t *)arg1;
        if (iVar13 == 0) goto code_r0x00018004182f;
        iVar7 = iVar13;
        puVar11 = auStack_58;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar13 & 0xfffffffffffffff0U)) &&
           (iVar7 = *(int64_t *)(iVar13 + -8), puVar11 = auStack_58, 0x1f < (iVar13 - iVar7) - 8U))
        goto code_r0x000180041820;
    } else {
        if (uVar9 < 0x1000) {
            unaff_RSI = (undefined4 *)func_0x000180459890(uVar9);
            goto code_r0x0001800417ab;
        }
        if (uVar9 + 0x27 <= uVar9) goto code_r0x00018004185d;
        iVar13 = func_0x000180459890();
        if (iVar13 != 0) {
            unaff_RSI = (undefined4 *)(iVar13 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RSI + -2) = iVar13;
            goto code_r0x0001800417ab;
        }
code_r0x000180041820:
        pcVar3 = (code *)swi(0x29);
        iVar7 = (*pcVar3)(5);
        puVar11 = auStack_50;
    }
    *(undefined8 *)(puVar11 + -8) = 0x18004182f;
    fcn.180459c3c(iVar7);
code_r0x00018004182f:
    *(undefined4 **)arg1 = unaff_RSI;
    *(undefined4 **)(arg1 + 8) = unaff_RSI + uVar1 * 4;
    *(undefined4 **)(arg1 + 0x10) = unaff_RSI + uVar12 * 4;
    return puVar14;
}

// ============================================================
// Function: FUN_180041870
// Address: 0x180041870
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.180041870(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined8 **)(arg1 + 8);
    if (puVar5 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar5 = *(undefined8 *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        return;
    }
    iVar7 = (int64_t)puVar5 - *(int64_t *)arg1 >> 3;
    if (iVar7 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (0x1fffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x000180041a1c:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar7 + 1;
    uVar4 = uVar4 + (uVar4 >> 1);
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0x1fffffffffffffff < uVar8) goto code_r0x000180041a1c;
    uVar8 = uVar8 * 8;
    if (uVar8 == 0) {
        unaff_RDI = 0;
code_r0x00018004195b:
        *(undefined8 *)(unaff_RDI + iVar7 * 8) = *(undefined8 *)arg2;
        puVar2 = *(undefined8 **)arg1;
        if (puVar5 == *(undefined8 **)(arg1 + 8)) {
            iVar9 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
            uVar4 = unaff_RDI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RDI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar5;
            uVar4 = unaff_RDI + (iVar7 + 1) * 8;
        }
        fcn.180498030(uVar4, puVar5, iVar9);
        iVar7 = *(int64_t *)arg1;
        if (iVar7 == 0) goto code_r0x0001800419e5;
        iVar9 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 3) * 8)) &&
           (iVar9 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar9) - 8U))
        goto code_r0x0001800419d3;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar8);
            goto code_r0x00018004195b;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x000180041a1c;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RDI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar9;
            goto code_r0x00018004195b;
        }
code_r0x0001800419d3:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar6 = auStack_30;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800419e5;
    fcn.180459c3c(iVar9);
code_r0x0001800419e5:
    *(uint64_t *)arg1 = unaff_RDI;
    *(uint64_t *)(arg1 + 8) = unaff_RDI + uVar1 * 8;
    *(uint64_t *)(arg1 + 0x10) = uVar8 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_1800418af
// Address: 0x1800418af
// Size: 359 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.180041870(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined8 **)(arg1 + 8);
    if (puVar5 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar5 = *(undefined8 *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        return;
    }
    iVar7 = (int64_t)puVar5 - *(int64_t *)arg1 >> 3;
    if (iVar7 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (0x1fffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x000180041a1c:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar7 + 1;
    uVar4 = uVar4 + (uVar4 >> 1);
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0x1fffffffffffffff < uVar8) goto code_r0x000180041a1c;
    uVar8 = uVar8 * 8;
    if (uVar8 == 0) {
        unaff_RDI = 0;
code_r0x00018004195b:
        *(undefined8 *)(unaff_RDI + iVar7 * 8) = *(undefined8 *)arg2;
        puVar2 = *(undefined8 **)arg1;
        if (puVar5 == *(undefined8 **)(arg1 + 8)) {
            iVar9 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
            uVar4 = unaff_RDI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RDI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar5;
            uVar4 = unaff_RDI + (iVar7 + 1) * 8;
        }
        fcn.180498030(uVar4, puVar5, iVar9);
        iVar7 = *(int64_t *)arg1;
        if (iVar7 == 0) goto code_r0x0001800419e5;
        iVar9 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 3) * 8)) &&
           (iVar9 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar9) - 8U))
        goto code_r0x0001800419d3;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar8);
            goto code_r0x00018004195b;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x000180041a1c;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RDI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar9;
            goto code_r0x00018004195b;
        }
code_r0x0001800419d3:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar6 = auStack_30;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800419e5;
    fcn.180459c3c(iVar9);
code_r0x0001800419e5:
    *(uint64_t *)arg1 = unaff_RDI;
    *(uint64_t *)(arg1 + 8) = unaff_RDI + uVar1 * 8;
    *(uint64_t *)(arg1 + 0x10) = uVar8 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180041a16
// Address: 0x180041a16
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.180041870(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined8 **)(arg1 + 8);
    if (puVar5 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar5 = *(undefined8 *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        return;
    }
    iVar7 = (int64_t)puVar5 - *(int64_t *)arg1 >> 3;
    if (iVar7 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (0x1fffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x000180041a1c:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar7 + 1;
    uVar4 = uVar4 + (uVar4 >> 1);
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0x1fffffffffffffff < uVar8) goto code_r0x000180041a1c;
    uVar8 = uVar8 * 8;
    if (uVar8 == 0) {
        unaff_RDI = 0;
code_r0x00018004195b:
        *(undefined8 *)(unaff_RDI + iVar7 * 8) = *(undefined8 *)arg2;
        puVar2 = *(undefined8 **)arg1;
        if (puVar5 == *(undefined8 **)(arg1 + 8)) {
            iVar9 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
            uVar4 = unaff_RDI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RDI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar5;
            uVar4 = unaff_RDI + (iVar7 + 1) * 8;
        }
        fcn.180498030(uVar4, puVar5, iVar9);
        iVar7 = *(int64_t *)arg1;
        if (iVar7 == 0) goto code_r0x0001800419e5;
        iVar9 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 3) * 8)) &&
           (iVar9 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar9) - 8U))
        goto code_r0x0001800419d3;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar8);
            goto code_r0x00018004195b;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x000180041a1c;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RDI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar9;
            goto code_r0x00018004195b;
        }
code_r0x0001800419d3:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar6 = auStack_30;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800419e5;
    fcn.180459c3c(iVar9);
code_r0x0001800419e5:
    *(uint64_t *)arg1 = unaff_RDI;
    *(uint64_t *)(arg1 + 8) = unaff_RDI + uVar1 * 8;
    *(uint64_t *)(arg1 + 0x10) = uVar8 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180041a1c
// Address: 0x180041a1c
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.180041870(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined8 **)(arg1 + 8);
    if (puVar5 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar5 = *(undefined8 *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
        return;
    }
    iVar7 = (int64_t)puVar5 - *(int64_t *)arg1 >> 3;
    if (iVar7 == 0x1fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar4 = (int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3;
    if (0x1fffffffffffffff - (uVar4 >> 1) < uVar4) {
code_r0x000180041a1c:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = iVar7 + 1;
    uVar4 = uVar4 + (uVar4 >> 1);
    uVar8 = uVar1;
    if (uVar1 <= uVar4) {
        uVar8 = uVar4;
    }
    if (0x1fffffffffffffff < uVar8) goto code_r0x000180041a1c;
    uVar8 = uVar8 * 8;
    if (uVar8 == 0) {
        unaff_RDI = 0;
code_r0x00018004195b:
        *(undefined8 *)(unaff_RDI + iVar7 * 8) = *(undefined8 *)arg2;
        puVar2 = *(undefined8 **)arg1;
        if (puVar5 == *(undefined8 **)(arg1 + 8)) {
            iVar9 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar2;
            uVar4 = unaff_RDI;
            puVar5 = puVar2;
        } else {
            fcn.180498030(unaff_RDI, puVar2, (int64_t)puVar5 - (int64_t)puVar2);
            iVar9 = *(int64_t *)(arg1 + 8) - (int64_t)puVar5;
            uVar4 = unaff_RDI + (iVar7 + 1) * 8;
        }
        fcn.180498030(uVar4, puVar5, iVar9);
        iVar7 = *(int64_t *)arg1;
        if (iVar7 == 0) goto code_r0x0001800419e5;
        iVar9 = iVar7;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar7 >> 3) * 8)) &&
           (iVar9 = *(int64_t *)(iVar7 + -8), puVar6 = auStack_38, 0x1f < (iVar7 - iVar9) - 8U))
        goto code_r0x0001800419d3;
    } else {
        if (uVar8 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar8);
            goto code_r0x00018004195b;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x000180041a1c;
        iVar9 = fcn.180459890();
        if (iVar9 != 0) {
            unaff_RDI = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar9;
            goto code_r0x00018004195b;
        }
code_r0x0001800419d3:
        iVar9 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar6 = auStack_30;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800419e5;
    fcn.180459c3c(iVar9);
code_r0x0001800419e5:
    *(uint64_t *)arg1 = unaff_RDI;
    *(uint64_t *)(arg1 + 8) = unaff_RDI + uVar1 * 8;
    *(uint64_t *)(arg1 + 0x10) = uVar8 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180041a30
// Address: 0x180041a30
// Size: 94 bytes
// ============================================================
void fcn.180041a30(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar1 & 0xffffffffffffffe0U)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180041a7b;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

