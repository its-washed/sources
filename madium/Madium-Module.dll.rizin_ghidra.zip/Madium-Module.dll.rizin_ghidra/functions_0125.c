// Chunk 125 - 50 functions

// ============================================================
// Function: FUN_1801ac1c0
// Address: 0x1801ac1c0
// Size: 203 bytes
// ============================================================
undefined8 fcn.1801ac1c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 uVar10;
    undefined8 unaff_R14;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ac1ce;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    uVar7 = *(undefined8 *)(in_RCX + 0x1580);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac1ed;
    func_0x000180224990(uVar7, 0x1804aeee0, 0xb8a);
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    uVar8 = 0;
    iVar5 = *(int64_t *)(in_RCX + 0x118);
    *(undefined8 *)(in_RCX + 0x1580) = 0;
    *(undefined8 *)(in_RCX + 0x1588) = 0;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac23b;
        uVar7 = func_0x000180224e40(iVar5, 4, 0x1804aeee0, 0xb92);
        *(undefined8 *)(in_RCX + 0x408) = uVar7;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac222;
        func_0x0001804986e0(iVar1, 0, iVar5 * 4);
    }
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac253;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac26b;
        func_0x0001802295a0(0x1804aeee0, 0xb94, 0x1804af1a0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac281;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if ((*(int64_t *)(in_RCX + 1000) != 0) || (*(int64_t *)(in_RCX + 0x3e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac34a;
        iVar2 = func_0x0001801ac470(in_RCX);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac42a;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac442;
            func_0x0001802295a0(0x1804aeee0, 0xbb2, 0x1804af1a0);
            uVar7 = 0x50;
            uVar10 = 0xc0103;
        } else {
            uVar4 = uVar8;
            if (*(int64_t *)(in_RCX + 0x118) != 0) {
                do {
                    *(undefined4 *)(iVar1 + uVar4 * 4) = 0;
                    uVar4 = uVar4 + 1;
                } while (uVar4 < *(uint64_t *)(in_RCX + 0x118));
            }
            if (*(int64_t *)(in_RCX + 0x1588) != 0) {
                do {
                    iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x1580) + uVar8 * 8);
                    if ((((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                          (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) ||
                        (*(int32_t *)(iVar5 + 0x1c) != 6)) &&
                       (iVar5 = (int64_t)*(int32_t *)(iVar5 + 0x20), *(int32_t *)(iVar1 + iVar5 * 4) == 0)) {
                        uVar7 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac3c8;
                        iVar2 = func_0x00018019e480(uVar7, iVar5);
                        if (iVar2 == 0) {
                            *(undefined4 *)(iVar1 + iVar5 * 4) = 0x102;
                        }
                    }
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(in_RCX + 0x1588));
            }
            if (*(int64_t *)(in_RCX + 0x1580) != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac400;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac418;
            func_0x0001802295a0(0x1804aeee0, 0xbba, 0x1804af1a0);
            uVar7 = 0x28;
            uVar10 = 0x178;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac458;
        func_0x00018019b5e0(in_RCX, uVar7, uVar10, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac2bc;
    uVar4 = func_0x0001801a9eb0(in_RCX, 1, (int64_t)&arg_28h + iVar3);
    if (*(int64_t *)(in_RCX + 0x118) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R14;
    iVar1 = *(int64_t *)((int64_t)&arg_28h + iVar3);
    uVar9 = uVar8;
    do {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac2ea;
        iVar5 = func_0x0001801ab3e0(in_RCX, uVar9 & 0xffffffff);
        if ((iVar5 != 0) && (uVar4 != 0)) {
            uVar6 = uVar8;
            do {
                if (*(int16_t *)(iVar5 + 0x10) == *(int16_t *)(iVar1 + uVar6 * 2)) {
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x408) + uVar9 * 4) = 2;
                    break;
                }
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar4);
        }
        uVar9 = uVar9 + 1;
        if (*(uint64_t *)(in_RCX + 0x118) <= uVar9) {
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801ac28b
// Address: 0x1801ac28b
// Size: 183 bytes
// ============================================================
undefined8 fcn.1801ac1c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 uVar10;
    undefined8 unaff_R14;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ac1ce;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    uVar7 = *(undefined8 *)(in_RCX + 0x1580);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac1ed;
    func_0x000180224990(uVar7, 0x1804aeee0, 0xb8a);
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    uVar8 = 0;
    iVar5 = *(int64_t *)(in_RCX + 0x118);
    *(undefined8 *)(in_RCX + 0x1580) = 0;
    *(undefined8 *)(in_RCX + 0x1588) = 0;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac23b;
        uVar7 = func_0x000180224e40(iVar5, 4, 0x1804aeee0, 0xb92);
        *(undefined8 *)(in_RCX + 0x408) = uVar7;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac222;
        func_0x0001804986e0(iVar1, 0, iVar5 * 4);
    }
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac253;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac26b;
        func_0x0001802295a0(0x1804aeee0, 0xb94, 0x1804af1a0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac281;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if ((*(int64_t *)(in_RCX + 1000) != 0) || (*(int64_t *)(in_RCX + 0x3e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac34a;
        iVar2 = func_0x0001801ac470(in_RCX);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac42a;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac442;
            func_0x0001802295a0(0x1804aeee0, 0xbb2, 0x1804af1a0);
            uVar7 = 0x50;
            uVar10 = 0xc0103;
        } else {
            uVar4 = uVar8;
            if (*(int64_t *)(in_RCX + 0x118) != 0) {
                do {
                    *(undefined4 *)(iVar1 + uVar4 * 4) = 0;
                    uVar4 = uVar4 + 1;
                } while (uVar4 < *(uint64_t *)(in_RCX + 0x118));
            }
            if (*(int64_t *)(in_RCX + 0x1588) != 0) {
                do {
                    iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x1580) + uVar8 * 8);
                    if ((((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                          (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) ||
                        (*(int32_t *)(iVar5 + 0x1c) != 6)) &&
                       (iVar5 = (int64_t)*(int32_t *)(iVar5 + 0x20), *(int32_t *)(iVar1 + iVar5 * 4) == 0)) {
                        uVar7 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac3c8;
                        iVar2 = func_0x00018019e480(uVar7, iVar5);
                        if (iVar2 == 0) {
                            *(undefined4 *)(iVar1 + iVar5 * 4) = 0x102;
                        }
                    }
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(in_RCX + 0x1588));
            }
            if (*(int64_t *)(in_RCX + 0x1580) != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac400;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac418;
            func_0x0001802295a0(0x1804aeee0, 0xbba, 0x1804af1a0);
            uVar7 = 0x28;
            uVar10 = 0x178;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac458;
        func_0x00018019b5e0(in_RCX, uVar7, uVar10, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac2bc;
    uVar4 = func_0x0001801a9eb0(in_RCX, 1, (int64_t)&arg_28h + iVar3);
    if (*(int64_t *)(in_RCX + 0x118) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R14;
    iVar1 = *(int64_t *)((int64_t)&arg_28h + iVar3);
    uVar9 = uVar8;
    do {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac2ea;
        iVar5 = func_0x0001801ab3e0(in_RCX, uVar9 & 0xffffffff);
        if ((iVar5 != 0) && (uVar4 != 0)) {
            uVar6 = uVar8;
            do {
                if (*(int16_t *)(iVar5 + 0x10) == *(int16_t *)(iVar1 + uVar6 * 2)) {
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x408) + uVar9 * 4) = 2;
                    break;
                }
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar4);
        }
        uVar9 = uVar9 + 1;
        if (*(uint64_t *)(in_RCX + 0x118) <= uVar9) {
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801ac342
// Address: 0x1801ac342
// Size: 185 bytes
// ============================================================
undefined8 fcn.1801ac1c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 uVar10;
    undefined8 unaff_R14;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ac1ce;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    uVar7 = *(undefined8 *)(in_RCX + 0x1580);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac1ed;
    func_0x000180224990(uVar7, 0x1804aeee0, 0xb8a);
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    uVar8 = 0;
    iVar5 = *(int64_t *)(in_RCX + 0x118);
    *(undefined8 *)(in_RCX + 0x1580) = 0;
    *(undefined8 *)(in_RCX + 0x1588) = 0;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac23b;
        uVar7 = func_0x000180224e40(iVar5, 4, 0x1804aeee0, 0xb92);
        *(undefined8 *)(in_RCX + 0x408) = uVar7;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac222;
        func_0x0001804986e0(iVar1, 0, iVar5 * 4);
    }
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac253;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac26b;
        func_0x0001802295a0(0x1804aeee0, 0xb94, 0x1804af1a0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac281;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if ((*(int64_t *)(in_RCX + 1000) != 0) || (*(int64_t *)(in_RCX + 0x3e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac34a;
        iVar2 = func_0x0001801ac470(in_RCX);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac42a;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac442;
            func_0x0001802295a0(0x1804aeee0, 0xbb2, 0x1804af1a0);
            uVar7 = 0x50;
            uVar10 = 0xc0103;
        } else {
            uVar4 = uVar8;
            if (*(int64_t *)(in_RCX + 0x118) != 0) {
                do {
                    *(undefined4 *)(iVar1 + uVar4 * 4) = 0;
                    uVar4 = uVar4 + 1;
                } while (uVar4 < *(uint64_t *)(in_RCX + 0x118));
            }
            if (*(int64_t *)(in_RCX + 0x1588) != 0) {
                do {
                    iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x1580) + uVar8 * 8);
                    if ((((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                          (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) ||
                        (*(int32_t *)(iVar5 + 0x1c) != 6)) &&
                       (iVar5 = (int64_t)*(int32_t *)(iVar5 + 0x20), *(int32_t *)(iVar1 + iVar5 * 4) == 0)) {
                        uVar7 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac3c8;
                        iVar2 = func_0x00018019e480(uVar7, iVar5);
                        if (iVar2 == 0) {
                            *(undefined4 *)(iVar1 + iVar5 * 4) = 0x102;
                        }
                    }
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(in_RCX + 0x1588));
            }
            if (*(int64_t *)(in_RCX + 0x1580) != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac400;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac418;
            func_0x0001802295a0(0x1804aeee0, 0xbba, 0x1804af1a0);
            uVar7 = 0x28;
            uVar10 = 0x178;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac458;
        func_0x00018019b5e0(in_RCX, uVar7, uVar10, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac2bc;
    uVar4 = func_0x0001801a9eb0(in_RCX, 1, (int64_t)&arg_28h + iVar3);
    if (*(int64_t *)(in_RCX + 0x118) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R14;
    iVar1 = *(int64_t *)((int64_t)&arg_28h + iVar3);
    uVar9 = uVar8;
    do {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac2ea;
        iVar5 = func_0x0001801ab3e0(in_RCX, uVar9 & 0xffffffff);
        if ((iVar5 != 0) && (uVar4 != 0)) {
            uVar6 = uVar8;
            do {
                if (*(int16_t *)(iVar5 + 0x10) == *(int16_t *)(iVar1 + uVar6 * 2)) {
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x408) + uVar9 * 4) = 2;
                    break;
                }
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar4);
        }
        uVar9 = uVar9 + 1;
        if (*(uint64_t *)(in_RCX + 0x118) <= uVar9) {
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801ac3fb
// Address: 0x1801ac3fb
// Size: 108 bytes
// ============================================================
undefined8 fcn.1801ac1c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 uVar10;
    undefined8 unaff_R14;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ac1ce;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    uVar7 = *(undefined8 *)(in_RCX + 0x1580);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac1ed;
    func_0x000180224990(uVar7, 0x1804aeee0, 0xb8a);
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    uVar8 = 0;
    iVar5 = *(int64_t *)(in_RCX + 0x118);
    *(undefined8 *)(in_RCX + 0x1580) = 0;
    *(undefined8 *)(in_RCX + 0x1588) = 0;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac23b;
        uVar7 = func_0x000180224e40(iVar5, 4, 0x1804aeee0, 0xb92);
        *(undefined8 *)(in_RCX + 0x408) = uVar7;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac222;
        func_0x0001804986e0(iVar1, 0, iVar5 * 4);
    }
    iVar1 = *(int64_t *)(in_RCX + 0x408);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac253;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac26b;
        func_0x0001802295a0(0x1804aeee0, 0xb94, 0x1804af1a0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac281;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if ((*(int64_t *)(in_RCX + 1000) != 0) || (*(int64_t *)(in_RCX + 0x3e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac34a;
        iVar2 = func_0x0001801ac470(in_RCX);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac42a;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac442;
            func_0x0001802295a0(0x1804aeee0, 0xbb2, 0x1804af1a0);
            uVar7 = 0x50;
            uVar10 = 0xc0103;
        } else {
            uVar4 = uVar8;
            if (*(int64_t *)(in_RCX + 0x118) != 0) {
                do {
                    *(undefined4 *)(iVar1 + uVar4 * 4) = 0;
                    uVar4 = uVar4 + 1;
                } while (uVar4 < *(uint64_t *)(in_RCX + 0x118));
            }
            if (*(int64_t *)(in_RCX + 0x1588) != 0) {
                do {
                    iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x1580) + uVar8 * 8);
                    if ((((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                          (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) ||
                        (*(int32_t *)(iVar5 + 0x1c) != 6)) &&
                       (iVar5 = (int64_t)*(int32_t *)(iVar5 + 0x20), *(int32_t *)(iVar1 + iVar5 * 4) == 0)) {
                        uVar7 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac3c8;
                        iVar2 = func_0x00018019e480(uVar7, iVar5);
                        if (iVar2 == 0) {
                            *(undefined4 *)(iVar1 + iVar5 * 4) = 0x102;
                        }
                    }
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(in_RCX + 0x1588));
            }
            if (*(int64_t *)(in_RCX + 0x1580) != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac400;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac418;
            func_0x0001802295a0(0x1804aeee0, 0xbba, 0x1804af1a0);
            uVar7 = 0x28;
            uVar10 = 0x178;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac458;
        func_0x00018019b5e0(in_RCX, uVar7, uVar10, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac2bc;
    uVar4 = func_0x0001801a9eb0(in_RCX, 1, (int64_t)&arg_28h + iVar3);
    if (*(int64_t *)(in_RCX + 0x118) == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R14;
    iVar1 = *(int64_t *)((int64_t)&arg_28h + iVar3);
    uVar9 = uVar8;
    do {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ac2ea;
        iVar5 = func_0x0001801ab3e0(in_RCX, uVar9 & 0xffffffff);
        if ((iVar5 != 0) && (uVar4 != 0)) {
            uVar6 = uVar8;
            do {
                if (*(int16_t *)(iVar5 + 0x10) == *(int16_t *)(iVar1 + uVar6 * 2)) {
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x408) + uVar9 * 4) = 2;
                    break;
                }
                uVar6 = uVar6 + 1;
            } while (uVar6 < uVar4);
        }
        uVar9 = uVar9 + 1;
        if (*(uint64_t *)(in_RCX + 0x118) <= uVar9) {
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801ac470
// Address: 0x1801ac470
// Size: 454 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ac470(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int64_t iVar6;
    uint32_t uVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ac48e;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    iVar6 = *(int64_t *)(in_RCX + 0x878);
    uVar8 = *(undefined8 *)(in_RCX + 0x1580);
    uVar7 = *(uint32_t *)(iVar6 + 0x1c) & 0x30000;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801ac4bd;
    func_0x000180224990(uVar8, 0x1804aeee0, 0xdb8);
    iVar4 = 0;
    *(undefined8 *)(in_RCX + 0x1580) = 0;
    *(undefined8 *)(in_RCX + 0x1588) = 0;
    if (((*(int32_t *)(in_RCX + 0x78) == 0) && (iVar5 = *(int64_t *)(iVar6 + 0x50), iVar5 != 0)) && (uVar7 == 0)) {
        uVar8 = *(undefined8 *)(iVar6 + 0x58);
    } else {
        iVar5 = *(int64_t *)(iVar6 + 0x40);
        if ((iVar5 == 0) || (uVar7 != 0)) {
            iVar6 = *(int64_t *)(in_RCX + 0x878);
            uVar1 = *(uint32_t *)(iVar6 + 0x1c) & 0x30000;
            if (uVar1 == 0x10000) {
                uVar8 = 1;
            } else {
                if (uVar1 == 0x20000) {
                    iVar5 = 0x1804adff6;
                    uVar8 = 1;
                    goto code_r0x0001801ac579;
                }
                if (uVar1 != 0x30000) {
                    if ((*(int32_t *)(in_RCX + 0x78) == 0) && (iVar5 = *(int64_t *)(iVar6 + 0x50), iVar5 != 0)) {
                        uVar8 = *(undefined8 *)(iVar6 + 0x58);
                    } else {
                        iVar5 = *(int64_t *)(iVar6 + 0x40);
                        if (iVar5 == 0) {
                            iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x658);
                            uVar8 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x648);
                        } else {
                            uVar8 = *(undefined8 *)(iVar6 + 0x48);
                        }
                    }
                    goto code_r0x0001801ac579;
                }
                uVar8 = 2;
            }
            iVar5 = 0x1804adff4;
        } else {
            uVar8 = *(undefined8 *)(iVar6 + 0x48);
        }
    }
code_r0x0001801ac579:
    if (((*(uint32_t *)(in_RCX + 0x9a8) >> 0x16 & 1) == 0) && (uVar7 == 0)) {
        iVar6 = iVar5;
        iVar5 = *(int64_t *)(in_RCX + 0x3e0);
        uVar9 = uVar8;
        uVar8 = *(undefined8 *)(in_RCX + 0x3f0);
    } else {
        iVar6 = *(int64_t *)(in_RCX + 0x3e0);
        uVar9 = *(undefined8 *)(in_RCX + 0x3f0);
    }
    *(undefined8 *)((int64_t)&var_10h + iVar2) = uVar9;
    *(int64_t *)((int64_t)&var_8h + iVar2) = iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801ac5c8;
    iVar3 = func_0x0001801a9f60(in_RCX, 0, iVar5, uVar8);
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801ac5e7;
        iVar4 = func_0x000180224ed0(iVar3, 8, 0x1804aeee0, 0xdd1);
        if (iVar4 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar2) = uVar9;
        *(int64_t *)((int64_t)&var_8h + iVar2) = iVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801ac60a;
        iVar3 = func_0x0001801a9f60(in_RCX, iVar4, iVar5, uVar8);
    }
    *(int64_t *)(in_RCX + 0x1588) = iVar3;
    *(int64_t *)(in_RCX + 0x1580) = iVar4;
    return 1;
}

// ============================================================
// Function: FUN_1801ac640
// Address: 0x1801ac640
// Size: 317 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ac640(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined2 *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int32_t *in_RDX;
    uint64_t uVar7;
    uint64_t in_R8;
    int32_t in_R9D;
    uint64_t uVar8;
    undefined2 *puVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ac65e;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    if ((in_R8 & 1) == 0) {
        uVar10 = in_R8 >> 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ac697;
        puVar5 = (undefined2 *)func_0x000180224ed0(uVar10, 2, 0x1804aeee0);
        if (puVar5 != (undefined2 *)0x0) {
            uVar8 = 0;
            puVar9 = puVar5;
            if (in_R8 != 0) {
                do {
                    iVar2 = *in_RDX;
                    uVar7 = 0;
                    piVar1 = in_RDX + 1;
                    in_RDX = in_RDX + 2;
                    iVar6 = 0x1804ae0e0;
                    do {
                        if ((*(int32_t *)(iVar6 + 0x14) == iVar2) && (*(int32_t *)(iVar6 + 0x1c) == *piVar1)) {
                            *puVar9 = *(undefined2 *)(iVar6 + 0x10);
                            puVar9 = puVar9 + 1;
                            break;
                        }
                        uVar7 = uVar7 + 1;
                        iVar6 = iVar6 + 0x48;
                    } while (uVar7 < 0x1f);
                    if (uVar7 == 0x1f) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ac744;
                        func_0x000180224990(puVar5, 0x1804aeee0, 0xf47);
                        return 0;
                    }
                    uVar8 = uVar8 + 2;
                } while (uVar8 < in_R8);
            }
            if (in_R9D == 0) {
                uVar3 = *(undefined8 *)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ac76e;
                func_0x000180224990(uVar3, 0x1804aeee0, 0xf3f);
                *(undefined2 **)(in_RCX + 0x40) = puVar5;
                *(uint64_t *)(in_RCX + 0x48) = uVar10;
                return 1;
            }
            uVar3 = *(undefined8 *)(in_RCX + 0x50);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ac720;
            func_0x000180224990(uVar3, 0x1804aeee0, 0xf3b);
            *(undefined2 **)(in_RCX + 0x50) = puVar5;
            *(uint64_t *)(in_RCX + 0x58) = uVar10;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ac780
// Address: 0x1801ac780
// Size: 120 bytes
// ============================================================
void fcn.1801ac780(int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_1b0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ac790;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_a0h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
    iVar4 = *(int64_t *)((int64_t)&arg_98h + iVar3);
    if (in_RCX != 0) {
        iVar4 = in_RCX;
    }
    *(int64_t *)((int64_t)&arg_98h + iVar3) = iVar4;
    *(int64_t *)(&stack0x00000000 + iVar3) = (int64_t)&var_10h + iVar3;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac7f0;
    iVar2 = func_0x00018024a850(in_R8, 0x3a, 1, 0x1801a8120);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_b0h + iVar3) = unaff_RDI;
        iVar4 = *(int64_t *)((int64_t)&var_10h + iVar3);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac80f;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac827;
            func_0x0001802295a0(0x1804aeee0, 0xf00, 0x1804af1f0);
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac840;
            func_0x0001802296d0(0x14, 0x80106, 0x1804af208, in_R8);
        } else if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac86d;
            iVar5 = func_0x000180224ed0(iVar4, 2, 0x1804aeee0, 0xf0e);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac886;
                func_0x000180498030(iVar5, (int64_t)&var_18h + iVar3, iVar4 * 2);
                if (in_R9D == 0) {
                    uVar1 = *(undefined8 *)(in_RDX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8ba;
                    func_0x000180224990(uVar1, 0x1804aeee0, 0xf17);
                    *(int64_t *)(in_RDX + 0x40) = iVar5;
                    *(int64_t *)(in_RDX + 0x48) = iVar4;
                } else {
                    uVar1 = *(undefined8 *)(in_RDX + 0x50);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8a1;
                    func_0x000180224990(uVar1, 0x1804aeee0, 0xf13);
                    *(int64_t *)(in_RDX + 0x50) = iVar5;
                    *(int64_t *)(in_RDX + 0x58) = iVar4;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8e1;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_a0h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801ac7f8
// Address: 0x1801ac7f8
// Size: 217 bytes
// ============================================================
void fcn.1801ac780(int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_1b0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ac790;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_a0h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
    iVar4 = *(int64_t *)((int64_t)&arg_98h + iVar3);
    if (in_RCX != 0) {
        iVar4 = in_RCX;
    }
    *(int64_t *)((int64_t)&arg_98h + iVar3) = iVar4;
    *(int64_t *)(&stack0x00000000 + iVar3) = (int64_t)&var_10h + iVar3;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac7f0;
    iVar2 = func_0x00018024a850(in_R8, 0x3a, 1, 0x1801a8120);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_b0h + iVar3) = unaff_RDI;
        iVar4 = *(int64_t *)((int64_t)&var_10h + iVar3);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac80f;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac827;
            func_0x0001802295a0(0x1804aeee0, 0xf00, 0x1804af1f0);
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac840;
            func_0x0001802296d0(0x14, 0x80106, 0x1804af208, in_R8);
        } else if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac86d;
            iVar5 = func_0x000180224ed0(iVar4, 2, 0x1804aeee0, 0xf0e);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac886;
                func_0x000180498030(iVar5, (int64_t)&var_18h + iVar3, iVar4 * 2);
                if (in_R9D == 0) {
                    uVar1 = *(undefined8 *)(in_RDX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8ba;
                    func_0x000180224990(uVar1, 0x1804aeee0, 0xf17);
                    *(int64_t *)(in_RDX + 0x40) = iVar5;
                    *(int64_t *)(in_RDX + 0x48) = iVar4;
                } else {
                    uVar1 = *(undefined8 *)(in_RDX + 0x50);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8a1;
                    func_0x000180224990(uVar1, 0x1804aeee0, 0xf13);
                    *(int64_t *)(in_RDX + 0x50) = iVar5;
                    *(int64_t *)(in_RDX + 0x58) = iVar4;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8e1;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_a0h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801ac8d1
// Address: 0x1801ac8d1
// Size: 29 bytes
// ============================================================
void fcn.1801ac780(int64_t arg_98h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_1b0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ac790;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_a0h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
    iVar4 = *(int64_t *)((int64_t)&arg_98h + iVar3);
    if (in_RCX != 0) {
        iVar4 = in_RCX;
    }
    *(int64_t *)((int64_t)&arg_98h + iVar3) = iVar4;
    *(int64_t *)(&stack0x00000000 + iVar3) = (int64_t)&var_10h + iVar3;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac7f0;
    iVar2 = func_0x00018024a850(in_R8, 0x3a, 1, 0x1801a8120);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_b0h + iVar3) = unaff_RDI;
        iVar4 = *(int64_t *)((int64_t)&var_10h + iVar3);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac80f;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac827;
            func_0x0001802295a0(0x1804aeee0, 0xf00, 0x1804af1f0);
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac840;
            func_0x0001802296d0(0x14, 0x80106, 0x1804af208, in_R8);
        } else if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac86d;
            iVar5 = func_0x000180224ed0(iVar4, 2, 0x1804aeee0, 0xf0e);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac886;
                func_0x000180498030(iVar5, (int64_t)&var_18h + iVar3, iVar4 * 2);
                if (in_R9D == 0) {
                    uVar1 = *(undefined8 *)(in_RDX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8ba;
                    func_0x000180224990(uVar1, 0x1804aeee0, 0xf17);
                    *(int64_t *)(in_RDX + 0x40) = iVar5;
                    *(int64_t *)(in_RDX + 0x48) = iVar4;
                } else {
                    uVar1 = *(undefined8 *)(in_RDX + 0x50);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8a1;
                    func_0x000180224990(uVar1, 0x1804aeee0, 0xf13);
                    *(int64_t *)(in_RDX + 0x50) = iVar5;
                    *(int64_t *)(in_RDX + 0x58) = iVar4;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x1801ac8e1;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_a0h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801ac8f0
// Address: 0x1801ac8f0
// Size: 761 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_668h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_660h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel

uint64_t fcn.1801ac8f0(int64_t placeholder_0, int64_t arg2, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h,
                      int64_t arg_48h)
{
    uint16_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int32_t *piVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    bool bVar18;
    int64_t var_10h;
    undefined8 uStack_48;
    
    uStack_48 = 0x1801ac90a;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    iVar8 = *(int64_t *)(placeholder_0 + 8);
    uVar9 = 0;
    *(int64_t *)((int64_t)&arg_48h + iVar5) = iVar8;
    if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
        return 0;
    }
    uVar7 = arg2 & 0xffffffff;
    if ((int32_t)arg2 == -2) {
        if ((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x1c) & 0x30000) != 0) {
            iVar4 = *(int32_t *)(*(int64_t *)(placeholder_0 + 0x300) + 0x18);
            if (iVar4 == 0x300c02b) {
                return 0x17;
            }
            if (iVar4 != 0x300c02c) {
                return 0;
            }
            return 0x18;
        }
        *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
        uVar7 = uVar9;
    }
    iVar4 = (int32_t)uVar7;
    if ((*(uint32_t *)(placeholder_0 + 0x9a8) >> 0x16 & 1) == 0) {
        iVar11 = *(int64_t *)(placeholder_0 + 0xaa0);
        iVar14 = *(int64_t *)(placeholder_0 + 0xa98);
        uVar10 = *(uint32_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x1c) & 0x30000;
        *(int64_t *)((int64_t)&arg_30h + iVar5) = iVar11;
        *(int64_t *)((int64_t)&arg_40h + iVar5) = iVar14;
        if (uVar10 == 0x10000) {
            uVar13 = 1;
        } else {
            if (uVar10 == 0x20000) {
                iVar12 = 0x1804adff2;
                uVar13 = 1;
                goto code_r0x0001801acaa1;
            }
            if (uVar10 != 0x30000) {
                iVar12 = *(int64_t *)(placeholder_0 + 0xa90);
                if (iVar12 == 0) {
                    iVar12 = *(int64_t *)(iVar8 + 0x298);
                    uVar13 = *(uint64_t *)(iVar8 + 0x290);
                } else {
                    uVar13 = *(uint64_t *)(placeholder_0 + 0xa88);
                }
                goto code_r0x0001801acaa1;
            }
            uVar13 = 2;
        }
        iVar12 = 0x1804adff0;
        goto code_r0x0001801acaa1;
    }
    uVar10 = *(uint32_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x1c) & 0x30000;
    if (uVar10 == 0x10000) {
        iVar14 = 1;
code_r0x0001801ac9f8:
        iVar11 = 0x1804adff0;
code_r0x0001801ac9ff:
        *(int64_t *)((int64_t)&arg_30h + iVar5) = iVar11;
    } else {
        if (uVar10 == 0x20000) {
            iVar11 = 0x1804adff2;
            iVar14 = 1;
            goto code_r0x0001801ac9ff;
        }
        if (uVar10 == 0x30000) {
            iVar14 = 2;
            goto code_r0x0001801ac9f8;
        }
        iVar11 = *(int64_t *)(placeholder_0 + 0xa90);
        *(int64_t *)((int64_t)&arg_30h + iVar5) = iVar11;
        if (iVar11 == 0) {
            iVar11 = *(int64_t *)(iVar8 + 0x298);
            iVar14 = *(int64_t *)(iVar8 + 0x290);
            goto code_r0x0001801ac9ff;
        }
        iVar14 = *(int64_t *)(placeholder_0 + 0xa88);
    }
    iVar12 = *(int64_t *)(placeholder_0 + 0xaa0);
    uVar13 = *(uint64_t *)(placeholder_0 + 0xa98);
    *(int64_t *)((int64_t)&arg_40h + iVar5) = iVar14;
code_r0x0001801acaa1:
    uVar16 = uVar9;
    uVar17 = uVar9;
    if (iVar14 != 0) {
        do {
            uVar1 = *(uint16_t *)(iVar11 + uVar16 * 2);
            uVar6 = uVar9;
            if (uVar13 != 0) {
code_r0x0001801acac1:
                if (*(uint16_t *)(iVar12 + uVar6 * 2) != uVar1) goto code_r0x0001801acac7;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801acae5;
                iVar4 = func_0x0001801ada30(placeholder_0, uVar1, 0x20005);
                if (iVar4 == 0) {
                    uVar10 = *(uint32_t *)((int64_t)&arg_38h + iVar5);
                } else {
                    if (*(uint64_t *)(iVar8 + 0x668) == 0) {
                        return 0;
                    }
                    iVar14 = *(int64_t *)(iVar8 + 0x660);
                    uVar7 = uVar9;
                    while (*(uint16_t *)(iVar14 + 0x1c) != uVar1) {
                        uVar7 = uVar7 + 1;
                        iVar14 = iVar14 + 0x38;
                        if (*(uint64_t *)(iVar8 + 0x668) <= uVar7) {
                            return 0;
                        }
                    }
                    if (iVar14 == 0) {
                        return 0;
                    }
                    bVar18 = (*(uint32_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) >> 3 & 1) ==
                             0;
                    iVar8 = 0x28;
                    if (bVar18) {
                        iVar8 = 0x20;
                    }
                    iVar4 = *(int32_t *)(iVar8 + iVar14);
                    if (bVar18) {
                        piVar15 = (int32_t *)(iVar14 + 0x24);
                    } else {
                        piVar15 = (int32_t *)(iVar14 + 0x2c);
                    }
                    iVar2 = *piVar15;
                    if (iVar2 == -1) {
code_r0x0001801acba3:
                        uVar10 = *(uint32_t *)((int64_t)&arg_38h + iVar5);
                    } else {
                        if (iVar4 != 0) {
                            uVar3 = *(undefined4 *)(placeholder_0 + 0x48);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801acb72;
                            iVar4 = func_0x0001801afd90(placeholder_0, uVar3, iVar4);
                            if (iVar4 < 0) goto code_r0x0001801acba3;
                        }
                        if (iVar2 != 0) {
                            uVar3 = *(undefined4 *)(placeholder_0 + 0x48);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1801acb89;
                            iVar4 = func_0x0001801afd90(placeholder_0, uVar3, iVar2);
                            if (0 < iVar4) goto code_r0x0001801acba3;
                        }
                        uVar10 = *(uint32_t *)((int64_t)&arg_38h + iVar5);
                        if (uVar10 == (uint32_t)uVar17) {
                            return (uint64_t)uVar1;
                        }
                        uVar17 = (uint64_t)((uint32_t)uVar17 + 1);
                    }
                    iVar8 = *(int64_t *)((int64_t)&arg_48h + iVar5);
                }
                uVar7 = (uint64_t)uVar10;
                iVar11 = *(int64_t *)((int64_t)&arg_30h + iVar5);
            }
code_r0x0001801acbb5:
            iVar4 = (int32_t)uVar7;
            uVar16 = uVar16 + 1;
        } while (uVar16 < *(uint64_t *)((int64_t)&arg_40h + iVar5));
    }
    if (iVar4 == -1) {
        uVar9 = uVar17 & 0xffff;
    }
    return uVar9;
code_r0x0001801acac7:
    uVar6 = uVar6 + 1;
    if (uVar13 <= uVar6) goto code_r0x0001801acbb5;
    goto code_r0x0001801acac1;
}

// ============================================================
// Function: FUN_1801acbf0
// Address: 0x1801acbf0
// Size: 171 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801acbf0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x878) + 0x40);
    if (iVar6 == 0) {
        iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x658);
        uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 8) + 0x648);
    } else {
        uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 0x878) + 0x48);
    }
    uVar4 = 0;
    if (uVar5 != 0) {
        uVar1 = *(uint64_t *)(*(int64_t *)(arg1 + 8) + 0x640);
        do {
            uVar3 = 0;
            if (uVar1 != 0) {
                iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x650);
                do {
                    if (*(int16_t *)(iVar2 + 0x10) == *(int16_t *)(iVar6 + uVar4 * 2)) {
                        if ((((*(int32_t *)(iVar2 + 0x2c) != 0) && (*(int32_t *)(iVar2 + 0x1c) == 0x198)) &&
                            (*(int32_t *)(iVar2 + 0x28) != 0)) && ((int32_t)arg2 == *(int32_t *)(iVar2 + 0x28))) {
                            return 1;
                        }
                        break;
                    }
                    iVar2 = iVar2 + 0x48;
                    uVar3 = uVar3 + 1;
                } while (uVar3 < uVar1);
            }
            uVar4 = uVar4 + 1;
        } while (uVar4 < uVar5);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801acca0
// Address: 0x1801acca0
// Size: 1252 bytes
// ============================================================
undefined8 fcn.1801acca0(int64_t placeholder_0, int64_t arg2, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint64_t uVar14;
    int16_t *piVar15;
    uint64_t uVar16;
    int32_t iVar17;
    bool bVar18;
    int64_t var_10h;
    undefined8 uStack_48;
    
    iVar17 = (int32_t)arg2;
    uStack_48 = 0x1801accba;
    iVar9 = func_0x00018045a350();
    iVar9 = -iVar9;
    uVar16 = 0;
    *(undefined8 *)(placeholder_0 + 0x3d8) = 0;
    *(undefined8 *)(placeholder_0 + 0x3d0) = 0;
    uVar14 = 0xffffffff;
    iVar6 = -1;
    uVar1 = *(uint32_t *)(*(int64_t *)(*(int32_t **)(placeholder_0 + 0x18) + 0x36) + 0x50);
    if ((((uVar1 & 8) == 0) && (iVar5 = **(int32_t **)(placeholder_0 + 0x18), 0x303 < iVar5)) && (iVar5 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acd0d;
        uVar10 = func_0x0001801a7690(placeholder_0, 0, 0);
        if (uVar10 == 0) {
            if (iVar17 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acd27;
            func_0x000180229480();
            uVar13 = 0x1231;
            goto code_r0x0001801acd2c;
        }
    } else {
        if ((*(uint8_t *)(*(int64_t *)(placeholder_0 + 0x300) + 0x20) & 0xab) == 0) {
            return 1;
        }
        if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
            iVar3 = **(int64_t **)(placeholder_0 + 0x878);
            iVar12 = (*(int64_t **)(placeholder_0 + 0x878))[4];
            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acda7;
            iVar5 = func_0x000180197870(placeholder_0, (iVar3 - iVar12) / 0x28);
            if (iVar5 == 0) {
                return 1;
            }
        }
        if ((uVar1 & 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad148;
            uVar10 = func_0x0001801ab3e0(placeholder_0, 0xffffffff);
            if (uVar10 == 0) {
                if (iVar17 == 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad162;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad17a;
                func_0x0001802295a0(0x1804aeee0, 0x12a5, 0x1804af238);
                uVar13 = 0x50;
                goto code_r0x0001801acd44;
            }
        } else if (*(int64_t *)(placeholder_0 + 0x3e0) == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad08b;
            uVar10 = func_0x0001801ab3e0(placeholder_0, 0xffffffff);
            if (uVar10 == 0) {
                if (iVar17 == 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad09d;
                func_0x000180229480();
                uVar13 = 0x128d;
code_r0x0001801acd2c:
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acd3f;
                func_0x0001802295a0(0x1804aeee0, uVar13, 0x1804af238);
                uVar13 = 0x28;
code_r0x0001801acd44:
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acd55;
                func_0x00018019b5e0(placeholder_0, uVar13, 0x76, 0);
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad0b9;
            uVar14 = func_0x0001801a9eb0(placeholder_0, 1, (int64_t)&arg_30h + iVar9);
            if (uVar14 != 0) {
                piVar15 = *(int16_t **)((int64_t)&arg_30h + iVar9);
                do {
                    if (*(int16_t *)(uVar10 + 0x10) == *piVar15) {
                        uVar2 = *(undefined4 *)(uVar10 + 0x20);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad0de;
                        iVar6 = func_0x0001801a80a0(placeholder_0, uVar10, uVar2);
                        if (iVar6 != 0) goto code_r0x0001801ad041;
                    }
                    uVar16 = uVar16 + 1;
                    piVar15 = piVar15 + 1;
                } while (uVar16 < uVar14);
            }
            if (uVar16 == uVar14) {
                if (iVar17 == 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad109;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad121;
                func_0x0001802295a0(0x1804aeee0, 0x129c, 0x1804af238);
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad137;
                func_0x00018019b5e0(placeholder_0, 0x28, 0x172, 0);
                return 0;
            }
        } else {
            iVar3 = *(int64_t *)(placeholder_0 + 0x878);
            uVar13 = *(undefined8 *)(placeholder_0 + 8);
            iVar5 = -1;
            *(undefined4 *)((int64_t)&arg_30h + iVar9) = 0xffffffff;
            *(undefined8 *)((int64_t)&arg_40h + iVar9) = uVar13;
            if ((*(uint32_t *)(iVar3 + 0x1c) & 0x30000) != 0) {
                uVar4 = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x80);
                *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acdf8;
                iVar5 = func_0x0001801a86f0(uVar4);
                *(int32_t *)((int64_t)&arg_30h + iVar9) = iVar5;
            }
            uVar10 = uVar16;
            if (*(int64_t *)(placeholder_0 + 0x1588) != 0) {
                iVar17 = *(int32_t *)((int64_t)&arg_30h + iVar9);
                do {
                    uVar10 = *(uint64_t *)(*(int64_t *)(placeholder_0 + 0x1580) + uVar16 * 8);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ace36;
                    iVar6 = func_0x0001801adb40(placeholder_0, uVar10);
                    if (iVar6 != 0) {
                        uVar1 = *(uint32_t *)(uVar10 + 0x20);
                        uVar14 = (uint64_t)(int32_t)uVar1;
                        if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
                            if ((uint32_t)
                                ((**(int64_t **)(placeholder_0 + 0x878) - (*(int64_t **)(placeholder_0 + 0x878))[4]) /
                                0x28) != uVar1) goto code_r0x0001801acfb0;
                        } else {
                            uVar13 = *(undefined8 *)(placeholder_0 + 8);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ace5b;
                            piVar11 = (int32_t *)func_0x0001801a1fe0(uVar14, uVar13);
                            if (((piVar11 == (int32_t *)0x0) ||
                                ((piVar11[1] & *(uint32_t *)(*(int64_t *)(placeholder_0 + 0x300) + 0x20)) == 0)) ||
                               ((*piVar11 == 0x390 &&
                                ((*(uint8_t *)(*(int64_t *)(placeholder_0 + 0x300) + 0x1c) & 1) != 0)))) {
                                uVar14 = 0xffffffff;
                                goto code_r0x0001801acfb0;
                            }
                            if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
                                if (*(char *)(placeholder_0 + 0xb50) == '\x02') goto code_r0x0001801acec4;
code_r0x0001801ace94:
                                bVar18 = (*(uint8_t *)(*(int64_t *)(placeholder_0 + 0x408) + uVar14 * 4) & 1) == 0;
                            } else {
                                if (*(char *)(placeholder_0 + 0xb52) != '\x02') goto code_r0x0001801ace94;
code_r0x0001801acec4:
                                iVar3 = *(int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20);
                                if ((*(int64_t *)(iVar3 + 8 + uVar14 * 0x28) == 0) ||
                                   (*(int64_t *)(iVar3 + uVar14 * 0x28) != 0)) goto code_r0x0001801ace94;
                                bVar18 = (*(uint32_t *)(*(int64_t *)(placeholder_0 + 0x408) + uVar14 * 4) & 0x1000) == 0
                                ;
                            }
                            uVar14 = 0xffffffff;
                            if (!bVar18) {
                                uVar14 = (uint64_t)uVar1;
                            }
                            if ((int32_t)uVar14 == -1) goto code_r0x0001801acfb0;
                            uVar13 = *(undefined8 *)((int64_t)&arg_40h + iVar9);
                        }
                        iVar6 = (int32_t)uVar14;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acf3b;
                        iVar7 = func_0x0001801a80a0(placeholder_0, uVar10, uVar14 & 0xffffffff);
                        if (iVar7 != 0) {
                            if (*(int32_t *)(uVar10 + 0x1c) == 0x390) {
                                iVar3 = *(int64_t *)
                                         (*(int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x20) + 8 +
                                         (int64_t)iVar6 * 0x28);
                                if ((iVar3 != 0) && (*(int32_t *)(uVar10 + 0x14) != 0)) {
                                    uVar2 = *(undefined4 *)(uVar10 + 0x18);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acf75;
                                    iVar12 = func_0x0001801a08e0(uVar13, uVar2);
                                    if (iVar12 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acf85;
                                        iVar7 = func_0x00018020f800(iVar12);
                                        if (0 < iVar7) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acf91;
                                            iVar7 = func_0x00018020f800(iVar12);
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acfa0;
                                            iVar8 = func_0x00018022fbd0(iVar3);
                                            if (iVar7 * 2 + 2 <= iVar8) goto code_r0x0001801acfa4;
                                        }
                                    }
                                }
                            } else {
code_r0x0001801acfa4:
                                if ((iVar5 == -1) || (*(int32_t *)(uVar10 + 0x28) == iVar17)) break;
                            }
                        }
                    }
code_r0x0001801acfb0:
                    iVar6 = (int32_t)uVar14;
                    uVar13 = *(undefined8 *)((int64_t)&arg_40h + iVar9);
                    uVar16 = uVar16 + 1;
                } while (uVar16 < *(uint64_t *)(placeholder_0 + 0x1588));
                iVar17 = *(int32_t *)((int64_t)&arg_38h + iVar9);
            }
            if (uVar16 == *(uint64_t *)(placeholder_0 + 0x1588)) {
                if ((*(uint8_t *)(*(int64_t *)(placeholder_0 + 0x300) + 0x20) & 0xa0) != 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801acffd;
                    uVar10 = func_0x0001801ab3e0(placeholder_0, 0xffffffff);
                    if (uVar10 == 0) {
                        if (iVar17 == 0) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad00f;
                        func_0x000180229480();
                        uVar13 = 0x1273;
                        goto code_r0x0001801acd2c;
                    }
                    iVar6 = *(int32_t *)(uVar10 + 0x20);
                    uVar16 = 0;
                }
                if (uVar16 == *(uint64_t *)(placeholder_0 + 0x1588)) {
                    if (iVar17 == 0) {
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar9) = 0x1801ad032;
                    func_0x000180229480();
                    uVar13 = 0x127f;
                    goto code_r0x0001801acd2c;
                }
            }
            if (iVar6 != -1) goto code_r0x0001801ad044;
        }
    }
code_r0x0001801ad041:
    iVar6 = *(int32_t *)(uVar10 + 0x20);
code_r0x0001801ad044:
    iVar9 = (*(int64_t **)(placeholder_0 + 0x878))[4] + (int64_t)iVar6 * 0x28;
    *(int64_t *)(placeholder_0 + 0x3d8) = iVar9;
    **(int64_t **)(placeholder_0 + 0x878) = iVar9;
    *(uint64_t *)(placeholder_0 + 0x3d0) = uVar10;
    return 1;
}

// ============================================================
// Function: FUN_1801ad190
// Address: 0x1801ad190
// Size: 2008 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801ad190(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int64_t *piVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    undefined8 uVar13;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar14;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t iVar15;
    int64_t var_8h;
    int64_t iStackX_10;
    int32_t aiStackX_18 [2];
    undefined8 uStackX_20;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    int64_t var_f0h;
    undefined4 uStack_e8;
    undefined4 uStack_e4;
    int64_t var_e0h;
    undefined4 uStack_d8;
    undefined4 uStack_d4;
    int64_t var_d0h;
    int64_t var_c8h;
    undefined auStack_98 [64];
    int64_t var_58h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t iVar16;
    
    uStack_48 = 0x1801ad1ac;
    iVar7 = func_0x00018045a350();
    piVar8 = (int64_t *)arg_30h;
    iVar7 = -iVar7;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar7);
    iVar16 = 0;
    iVar15 = 0;
    uVar12 = *(undefined8 *)(in_RCX + 8);
    puVar1 = *(undefined8 **)(in_RCX + 0xb88);
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = in_R9;
    *(int64_t *)((int64_t)&var_10h + iVar7) = in_RDX;
    *(int64_t *)((int64_t)&iStackX_10 + iVar7) = in_RCX;
    *(int64_t **)((int64_t)&arg_30h + iVar7) = piVar8;
    *(undefined4 *)(&stack0xfffffffffffffffc + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = uVar12;
    if (in_R8 == 0) {
        iVar14 = 3;
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad215;
        func_0x000180211410(0);
    } else {
        iVar14 = 4;
        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
             (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)) ||
           (*(int64_t *)(in_RCX + 0xae0) == 0)) {
            if (in_R8 < 0x20) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad263;
                func_0x000180211410(0);
            } else {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad27f;
                piVar8 = (int64_t *)func_0x000180224d60(0x10, 0x1804aeee0, 0x12dc);
                iVar9 = 0;
                if (piVar8 != (int64_t *)0x0) {
                    if ((puVar1[0x4c] == 0) && (puVar1[0x4b] != 0)) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad2ab;
                        iVar14 = func_0x0001801bc900(piVar8);
                        if (iVar14 != 0) {
code_r0x0001801ad3b3:
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad3bb;
                            iVar9 = func_0x000180211490();
                            if (iVar9 == 0) {
                                iVar14 = 0;
                                goto code_r0x0001801ad880;
                            }
                            pcVar2 = (code *)puVar1[0x4c];
                            if (pcVar2 == (code *)0x0) {
                                if (puVar1[0x4b] != 0) {
                                    pcVar2 = (code *)puVar1[0x4b];
                                    uVar12 = *(undefined8 *)(*(int64_t *)((int64_t)&iStackX_10 + iVar7) + 0x40);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad599;
                                    uVar13 = func_0x0001801bc820(piVar8);
                                    *(undefined4 *)((int64_t)&var_18h + iVar7) = 0;
                                    *(undefined8 *)((int64_t)&var_20h + iVar7) = uVar13;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad5b7;
                                    iVar14 = (*pcVar2)(uVar12, *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                       *(int64_t *)((int64_t)&var_10h + iVar7) + 0x10, iVar9);
                                    goto code_r0x0001801ad5e1;
                                }
                                piVar3 = *(int64_t **)((int64_t)&var_10h + iVar7);
                                if ((*piVar3 != puVar1[0x48]) || (piVar3[1] != puVar1[0x49])) goto code_r0x0001801ad5f1;
                                uVar12 = (*(undefined8 **)((int64_t)&arg_28h + iVar7))[0x8c];
                                uVar13 = **(undefined8 **)((int64_t)&arg_28h + iVar7);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad428;
                                iVar10 = func_0x0001802119f0(uVar13, 0x1804af1b8, uVar12);
                                *(int64_t *)((int64_t)&uStackX_20 + iVar7 + -0x20) = iVar10;
                                if (iVar10 != 0) {
                                    uVar12 = puVar1[0x4a];
                                    *(undefined8 *)((int64_t)&uStackX_20 + iVar7) = uVar12;
                                    if (*piVar8 == 0) {
code_r0x0001801ad4bc:
                                        if (piVar8[1] != 0) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad4de;
                                            iVar14 = func_0x0001801bc8a0(piVar8, uVar12, 0x20, 0x1804ad37c);
                                            if (0 < iVar14) goto code_r0x0001801ad4e2;
                                        }
                                        uVar12 = *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + -0x20);
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad562;
                                        func_0x000180211a40(uVar12);
                                        iVar14 = 1;
                                        goto code_r0x0001801ad880;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad461;
                                    puVar11 = (undefined4 *)func_0x000180229e30(&var_c8h, 0x1804af254, 0x1804ad37c, 0);
                                    var_118h._0_4_ = *puVar11;
                                    var_118h._4_4_ = puVar11[1];
                                    uStack_110 = puVar11[2];
                                    uStack_10c = puVar11[3];
                                    var_108h._0_4_ = puVar11[4];
                                    var_108h._4_4_ = puVar11[5];
                                    uStack_100 = puVar11[6];
                                    uStack_fc = puVar11[7];
                                    var_f8h = *(int64_t *)(puVar11 + 8);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad483;
                                    puVar11 = (undefined4 *)func_0x000180229ba0(&var_c8h);
                                    iVar10 = *piVar8;
                                    var_f0h._0_4_ = *puVar11;
                                    var_f0h._4_4_ = puVar11[1];
                                    uStack_e8 = puVar11[2];
                                    uStack_e4 = puVar11[3];
                                    var_e0h._0_4_ = puVar11[4];
                                    var_e0h._4_4_ = puVar11[5];
                                    uStack_d8 = puVar11[6];
                                    uStack_d4 = puVar11[7];
                                    var_d0h = *(int64_t *)(puVar11 + 8);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad4b3;
                                    iVar14 = func_0x000180257420(iVar10, *(undefined8 *)((int64_t)&uStackX_20 + iVar7), 
                                                                 0x20, &var_118h);
                                    if (iVar14 == 0) {
                                        uVar12 = *(undefined8 *)((int64_t)&uStackX_20 + iVar7);
                                        goto code_r0x0001801ad4bc;
                                    }
code_r0x0001801ad4e2:
                                    iVar10 = puVar1[0x4a];
                                    uVar12 = *(undefined8 *)((int64_t)&uStackX_20 + iVar7 + -0x20);
                                    *(int64_t **)((int64_t)&var_20h + iVar7) = piVar3 + 2;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad509;
                                    iVar14 = func_0x000180212170(iVar9, uVar12, 0, iVar10 + 0x20);
                                    if (iVar14 < 1) goto code_r0x0001801ad56f;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad515;
                                    func_0x000180211a40(uVar12);
                                    piVar4 = *(int32_t **)(*(int64_t *)((int64_t)&iStackX_10 + iVar7) + 0x18);
                                    if ((((*(uint8_t *)(*(int64_t *)(piVar4 + 0x36) + 0x50) & 8) == 0) &&
                                        (iVar14 = *piVar4, 0x303 < iVar14)) && (iVar14 != 0x10000)) {
                                        *(undefined4 *)(&stack0xfffffffffffffffc + iVar7) = 1;
                                    }
                                    goto code_r0x0001801ad60f;
                                }
                                uVar12 = 0;
code_r0x0001801ad56f:
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad577;
                                func_0x000180211a40(uVar12);
                                goto code_r0x0001801ad577;
                            }
                            iVar10 = *piVar8;
                            *(undefined4 *)((int64_t)&var_18h + iVar7) = 0;
                            *(int64_t *)((int64_t)&var_20h + iVar7) = iVar10;
                            uVar12 = *(undefined8 *)(*(int64_t *)((int64_t)&iStackX_10 + iVar7) + 0x40);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad5e1;
                            iVar14 = (*pcVar2)(uVar12, *(int64_t *)((int64_t)&var_10h + iVar7), 
                                               *(int64_t *)((int64_t)&var_10h + iVar7) + 0x10, iVar9);
code_r0x0001801ad5e1:
                            if (iVar14 < 0) {
                                iVar14 = 1;
code_r0x0001801ad880:
                                in_RDX = *(int64_t *)((int64_t)&var_10h + iVar7);
                                iVar15 = iVar16;
                            } else {
                                if (iVar14 == 0) {
code_r0x0001801ad5f1:
                                    iVar14 = 4;
                                    goto code_r0x0001801ad880;
                                }
                                *(uint32_t *)(&stack0xfffffffffffffffc + iVar7) = (uint32_t)(iVar14 == 2);
code_r0x0001801ad60f:
                                if (*piVar8 == 0) {
                                    if (piVar8[1] != 0) {
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad630;
                                        iVar10 = func_0x0001801bc930(piVar8);
                                        goto code_r0x0001801ad630;
                                    }
code_r0x0001801ad879:
                                    iVar14 = 1;
                                    goto code_r0x0001801ad880;
                                }
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad61c;
                                iVar10 = func_0x0001802570c0();
code_r0x0001801ad630:
                                if (iVar10 == 0) goto code_r0x0001801ad879;
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad644;
                                iVar14 = func_0x00018020e980(iVar9);
                                if (iVar14 < 0) {
                                    iVar14 = 1;
                                    goto code_r0x0001801ad880;
                                }
                                if (in_R8 <= (uint64_t)((iVar14 + 0x10) + iVar10)) {
                                    iVar14 = 4;
                                    goto code_r0x0001801ad880;
                                }
                                iVar5 = *piVar8;
                                in_R8 = in_R8 - iVar10;
                                if (iVar5 == 0) {
                                    if (piVar8[1] == 0) goto code_r0x0001801ad577;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad6a3;
                                    iVar6 = func_0x0001801bc950(piVar8, *(undefined8 *)((int64_t)&var_10h + iVar7), 
                                                                in_R8);
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad687;
                                    iVar6 = func_0x0001802574c0(iVar5, *(undefined8 *)((int64_t)&var_10h + iVar7), in_R8
                                                               );
                                }
                                if (iVar6 < 1) {
code_r0x0001801ad577:
                                    iVar14 = 1;
                                    goto code_r0x0001801ad880;
                                }
                                iVar5 = *piVar8;
                                if (iVar5 == 0) {
                                    if (piVar8[1] == 0) goto code_r0x0001801ad577;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad6e0;
                                    iVar6 = func_0x0001801bc830(piVar8, auStack_98, 0);
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad6c5;
                                    iVar6 = func_0x000180257200(iVar5, auStack_98, 0, 0x40);
                                }
                                if (iVar6 < 1) goto code_r0x0001801ad577;
                                in_RDX = *(int64_t *)((int64_t)&var_10h + iVar7);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad6fd;
                                iVar6 = func_0x0001802262e0(auStack_98, in_R8 + in_RDX, iVar10);
                                if (iVar6 == 0) {
                                    *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8) = in_RDX + 0x10 + (int64_t)iVar14;
                                    in_R8 = in_R8 - (int64_t)(iVar14 + 0x10);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad737;
                                    iVar10 = func_0x0001802248d0(in_R8, 0x1804aeee0, 0xc8f);
                                    if (iVar10 != 0) {
                                        uVar12 = *(undefined8 *)((int64_t)&iStackX_10 + iVar7 + -8);
                                        *(int32_t *)((int64_t)&var_20h + iVar7) = (int32_t)in_R8;
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad75d;
                                        iVar14 = func_0x0001802121a0(iVar9, iVar10, &stack0xfffffffffffffff8 + iVar7, 
                                                                     uVar12);
                                        if (0 < iVar14) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad77a;
                                            iVar14 = func_0x000180211de0(iVar9, *(int32_t *)
                                                                                 (&stack0xfffffffffffffff8 + iVar7) +
                                                                                iVar10, (int64_t)aiStackX_18 + iVar7);
                                            if (iVar14 < 1) {
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad793;
                                                func_0x000180224990(iVar10, 0x1804aeee0, 0xc97);
                                                iVar14 = 4;
                                                iVar15 = iVar16;
                                            } else {
                                                puVar1 = *(undefined8 **)((int64_t)&arg_28h + iVar7);
                                                iVar14 = *(int32_t *)(&stack0xfffffffffffffff8 + iVar7) +
                                                         *(int32_t *)((int64_t)aiStackX_18 + iVar7);
                                                *(int32_t *)(&stack0xfffffffffffffff8 + iVar7) = iVar14;
                                                *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8) = iVar10;
                                                uVar12 = *puVar1;
                                                *(undefined8 *)((int64_t)&var_20h + iVar7) = puVar1[0x8c];
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad7d3;
                                                iVar15 = func_0x0001801d3e50(0, (int64_t)&iStackX_10 + iVar7 + -8, 
                                                                             iVar14, uVar12);
                                                *(int32_t *)(&stack0xfffffffffffffff8 + iVar7) =
                                                     *(int32_t *)(&stack0xfffffffffffffff8 + iVar7) +
                                                     ((int32_t)iVar10 - *(int32_t *)((int64_t)&iStackX_10 + iVar7 + -8))
                                                ;
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad7f5;
                                                func_0x000180224990(iVar10, 0x1804aeee0, 0xca0);
                                                iVar16 = arg_28h;
                                                if (iVar15 == 0) {
                                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad84f;
                                                    func_0x0001802203d0();
                                                    iVar14 = 4;
                                                } else if (*(int32_t *)(&stack0xfffffffffffffff8 + iVar7) == 0) {
                                                    if (arg_28h != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad835;
                                                        func_0x000180498030(iVar15 + 600, 
                                                                            *(undefined8 *)((int64_t)&arg_38h + iVar7), 
                                                                            arg_28h);
                                                        *(int64_t *)(iVar15 + 0x250) = iVar16;
                                                    }
                                                    iVar14 = *(int32_t *)(&stack0xfffffffffffffffc + iVar7) + 5;
                                                } else {
                                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad809;
                                                    func_0x00018019c980(iVar15);
                                                    iVar15 = 0;
                                                    iVar14 = 4;
                                                }
                                            }
                                            goto code_r0x0001801ad885;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad86d;
                                    func_0x000180224990(iVar10, 0x1804aeee0, 0xc92);
                                    iVar14 = 1;
                                } else {
                                    iVar14 = 4;
                                    iVar15 = iVar16;
                                }
                            }
code_r0x0001801ad885:
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad88d;
                            func_0x000180211410(iVar9);
                            iVar16 = *piVar8;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad896;
                            func_0x000180257070(iVar16);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad89e;
                            func_0x0001801bc880(piVar8);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad8b3;
                            func_0x000180224990(piVar8, 0x1804aeee0, 0x12fc);
                            in_RCX = *(int64_t *)((int64_t)&iStackX_10 + iVar7);
                            piVar8 = *(int64_t **)((int64_t)&arg_30h + iVar7);
                            iVar16 = iVar15;
                            goto code_r0x0001801ad2ec;
                        }
                    } else {
                        uVar12 = puVar1[0x8c];
                        uVar13 = *puVar1;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad38a;
                        iVar9 = func_0x000180256ae0(uVar13, 0x1804af24c, uVar12);
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad39e;
                            iVar10 = func_0x0001802570e0(iVar9);
                            *piVar8 = iVar10;
                            if (iVar10 != 0) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad3b3;
                                func_0x000180256b30(iVar9);
                                goto code_r0x0001801ad3b3;
                            }
                        }
                    }
                    iVar15 = *piVar8;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad2bc;
                    func_0x000180257070(iVar15);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad2c4;
                    func_0x000180256b30(iVar9);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad2d9;
                    func_0x000180224990(piVar8, 0x1804aeee0, 0x12f1);
                }
                iVar14 = 0;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad2e2;
                func_0x000180211410(0);
                piVar8 = *(int64_t **)((int64_t)&arg_30h + iVar7);
            }
        } else {
            iVar14 = 4;
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad24d;
            func_0x000180211410(0);
        }
    }
code_r0x0001801ad2ec:
    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xb88) + 0x420);
    if ((pcVar2 == (code *)0x0) || (3 < iVar14 - 3U)) goto code_r0x0001801ad900;
    if (0x10 < in_R8) {
        in_R8 = 0x10;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar7) = *(undefined8 *)(*(int64_t *)(in_RCX + 0xb88) + 0x428);
    *(int32_t *)((int64_t)&var_20h + iVar7) = iVar14;
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad33b;
    iVar6 = (*pcVar2)(in_RCX, iVar16, in_RDX, in_R8);
    if (iVar6 == 0) {
code_r0x0001801ad368:
        iVar14 = 1;
    } else {
        if (iVar6 == 1) {
            iVar14 = 2;
        } else {
            if (iVar6 != 2) {
                if ((iVar6 == 3) || (iVar6 == 4)) {
                    if (iVar14 - 5U < 2) {
                        iVar14 = (iVar6 != 3) + 5;
                    } else {
                        iVar14 = 1;
                    }
                    goto code_r0x0001801ad900;
                }
                goto code_r0x0001801ad368;
            }
            if (1 < iVar14 - 3U) {
                iVar14 = 4;
            }
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad8f8;
        func_0x00018019c980(iVar16);
        iVar16 = 0;
    }
code_r0x0001801ad900:
    if (((*(int64_t *)(in_RCX + 0xae0) == 0) ||
        ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0 &&
          (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)))) &&
       (((iVar14 == 3 || (iVar14 == 4)) || (iVar14 == 6)))) {
        *(undefined4 *)(in_RCX + 0xa60) = 1;
    }
    *piVar8 = iVar16;
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x1801ad954;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801ad970
// Address: 0x1801ad970
// Size: 187 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801ad970(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ad985;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *in_R8 = 0;
    *(undefined4 *)(in_RCX + 0xa60) = 0;
    if ((0x300 < *(int32_t *)(in_RCX + 0x48)) && ((*(uint32_t *)(in_RCX + 0x9a8) >> 0xe & 1) == 0)) {
        *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ad9ca;
        iVar1 = fcn.1801a2690(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000060 + iVar2));
        if ((iVar1 != 0) && (*(int32_t *)(*(int64_t *)(in_RDX + 0x288) + 0x100) != 0)) {
            uVar3 = *(undefined8 *)(in_RDX + 0x28);
            *(undefined8 **)((int64_t)&var_20h + iVar2) = in_R8;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = uVar3;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ada06;
            uVar3 = fcn.1801ad190(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                  *(int64_t *)(&stack0x00000028 + iVar2));
            return uVar3;
        }
    }
    return 2;
}

// ============================================================
// Function: FUN_1801ada30
// Address: 0x1801ada30
// Size: 192 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel

undefined8 fcn.1801ada30(int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int16_t in_DX;
    int64_t iVar6;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ada3c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar4 = 0;
    uVar1 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x668);
    if (uVar1 != 0) {
        iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x660);
        uVar3 = uVar4;
        do {
            if (*(int16_t *)(iVar6 + 0x1c) == in_DX) {
                if (iVar6 == 0) {
                    return 0;
                }
                *(char *)((int64_t)&arg_38h + iVar2 + 1) = (char)in_DX;
                *(char *)((int64_t)&arg_38h + iVar2) = (char)((uint16_t)in_DX >> 8);
                if (*(int16_t *)(iVar6 + 0x1c) == 0) goto code_r0x0001801adacf;
                goto code_r0x0001801adab0;
            }
            uVar3 = uVar3 + 1;
            iVar6 = iVar6 + 0x38;
        } while (uVar3 < uVar1);
    }
    return 0;
    while (uVar4 = uVar4 + 1, uVar4 < 0x2d) {
code_r0x0001801adab0:
        if (*(int16_t *)(uVar4 * 8 + 0x1804ade84) == *(int16_t *)(iVar6 + 0x1c)) break;
    }
code_r0x0001801adacf:
    *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8) = (int64_t)&arg_38h + iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801adaea;
    uVar5 = fcn.1801a2690(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2));
    return uVar5;
}

// ============================================================
// Function: FUN_1801adb40
// Address: 0x1801adb40
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801adb40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t iVar6;
    int64_t in_RDX;
    int64_t iVar7;
    int64_t iVar8;
    bool bVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801adb5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RDX + 0x2c) != 0) {
        iVar6 = 0x9b4;
        iVar3 = **(int32_t **)(in_RCX + 0x18);
        iVar5 = 0x9b8;
        if ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) {
            bVar9 = iVar3 == 0x10000;
            iVar8 = 0x38;
            iVar7 = 0x34;
        } else {
            bVar9 = iVar3 == 0x1ffff;
            iVar8 = 0x40;
            iVar7 = 0x3c;
        }
        if (!bVar9) {
            iVar6 = 0x48;
        }
        iVar3 = *(int32_t *)(in_RDX + iVar8);
        if (!bVar9) {
            iVar5 = 0x48;
        }
        iVar1 = *(int32_t *)(iVar6 + in_RCX);
        if ((*(int32_t *)(in_RDX + iVar7) != -1) && (iVar3 != -1)) {
            if ((*(int32_t *)(in_RDX + iVar7) != 0) && (*(int32_t *)(iVar5 + in_RCX) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801adbe2;
                iVar2 = func_0x0001801afd90(in_RCX);
                if (0 < iVar2) {
                    return false;
                }
            }
            if ((iVar3 != 0) && (iVar1 != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801adbfb;
                iVar3 = func_0x0001801afd90(in_RCX, iVar3, iVar1);
                if (iVar3 < 0) {
                    return false;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801adc0f;
            iVar3 = func_0x0001801aa060(in_RCX, 0x5000b, in_RDX);
            return iVar3 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801adc40
// Address: 0x1801adc40
// Size: 63 bytes
// ============================================================
undefined8 fcn.1801adc40(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801adc4a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((*(uint32_t *)(param_1 + 0x9a8) >> 0xe & 1) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801adc7a;
    uVar2 = fcn.1801a2690(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000068 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_1801adc80
// Address: 0x1801adc80
// Size: 186 bytes
// ============================================================
uint32_t fcn.1801adc80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    uint64_t uVar2;
    uint32_t *puVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int16_t in_DX;
    uint64_t uVar11;
    uint64_t uVar12;
    uint32_t uVar13;
    undefined8 unaff_RBP;
    uint32_t uVar14;
    uint64_t uVar15;
    uint64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    bool bVar16;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801adc92;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar15 = 0;
    uVar14 = 0;
    uVar2 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x668);
    uVar12 = uVar15;
    if (uVar2 != 0) {
        uVar11 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x660);
        uVar9 = uVar15;
        do {
            uVar12 = uVar11;
            if (*(int16_t *)(uVar11 + 0x1c) == in_DX) break;
            uVar9 = uVar9 + 1;
            uVar11 = uVar11 + 0x38;
            uVar12 = uVar15;
        } while (uVar9 < uVar2);
    }
    puVar3 = *(uint32_t **)((int64_t)&arg_50h + iVar8);
    if (puVar3 != (uint32_t *)0x0) {
        *puVar3 = 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_R14;
    if (uVar12 == 0) {
        return 0;
    }
    bVar16 = (*(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) >> 3 & 1) == 0;
    iVar10 = 0x2c;
    if (bVar16) {
        iVar10 = 0x24;
    }
    iVar7 = *(int32_t *)(iVar10 + uVar12);
    iVar10 = 0x28;
    if (bVar16) {
        iVar10 = 0x20;
    }
    iVar1 = *(int32_t *)(iVar10 + uVar12);
    if (iVar1 < 0) {
        return 0;
    }
    if (iVar7 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    if (iVar7 == 0) {
        uVar13 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801add56;
        iVar5 = func_0x0001801afd90(in_RCX, in_R8 & 0xffffffff, iVar7);
        uVar13 = (uint32_t)(iVar5 < 1);
    }
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801add71;
        uVar6 = func_0x0001801afd90(in_RCX, in_R9 & 0xffffffff, iVar1);
        uVar13 = uVar13 & ~uVar6 >> 0x1f;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) && (uVar13 != 0)) &&
        (puVar3 != (uint32_t *)0x0)) && ((int32_t)in_R9 == 0x304)) {
        if ((iVar7 == 0) || (uVar6 = uVar14, 0x303 < iVar7)) {
            uVar6 = 1;
        }
        *puVar3 = uVar6;
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar8) != 0) {
        uVar4 = *(undefined8 *)(uVar12 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801addc7;
        iVar7 = func_0x000180498f10(uVar4, 0x1804af0ec);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801addda;
            iVar7 = func_0x000180498f10(uVar4, 0x1804af0f0);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801added;
                iVar7 = func_0x000180498f10(uVar4, 0x1804af0f8);
                if (iVar7 != 0) goto code_r0x0001801addf6;
            }
        }
    }
    uVar14 = 1;
code_r0x0001801addf6:
    return uVar14 & uVar13;
}

// ============================================================
// Function: FUN_1801add3a
// Address: 0x1801add3a
// Size: 199 bytes
// ============================================================
uint32_t fcn.1801adc80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    uint64_t uVar2;
    uint32_t *puVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int16_t in_DX;
    uint64_t uVar11;
    uint64_t uVar12;
    uint32_t uVar13;
    undefined8 unaff_RBP;
    uint32_t uVar14;
    uint64_t uVar15;
    uint64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    bool bVar16;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801adc92;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar15 = 0;
    uVar14 = 0;
    uVar2 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x668);
    uVar12 = uVar15;
    if (uVar2 != 0) {
        uVar11 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x660);
        uVar9 = uVar15;
        do {
            uVar12 = uVar11;
            if (*(int16_t *)(uVar11 + 0x1c) == in_DX) break;
            uVar9 = uVar9 + 1;
            uVar11 = uVar11 + 0x38;
            uVar12 = uVar15;
        } while (uVar9 < uVar2);
    }
    puVar3 = *(uint32_t **)((int64_t)&arg_50h + iVar8);
    if (puVar3 != (uint32_t *)0x0) {
        *puVar3 = 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_R14;
    if (uVar12 == 0) {
        return 0;
    }
    bVar16 = (*(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) >> 3 & 1) == 0;
    iVar10 = 0x2c;
    if (bVar16) {
        iVar10 = 0x24;
    }
    iVar7 = *(int32_t *)(iVar10 + uVar12);
    iVar10 = 0x28;
    if (bVar16) {
        iVar10 = 0x20;
    }
    iVar1 = *(int32_t *)(iVar10 + uVar12);
    if (iVar1 < 0) {
        return 0;
    }
    if (iVar7 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    if (iVar7 == 0) {
        uVar13 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801add56;
        iVar5 = func_0x0001801afd90(in_RCX, in_R8 & 0xffffffff, iVar7);
        uVar13 = (uint32_t)(iVar5 < 1);
    }
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801add71;
        uVar6 = func_0x0001801afd90(in_RCX, in_R9 & 0xffffffff, iVar1);
        uVar13 = uVar13 & ~uVar6 >> 0x1f;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) && (uVar13 != 0)) &&
        (puVar3 != (uint32_t *)0x0)) && ((int32_t)in_R9 == 0x304)) {
        if ((iVar7 == 0) || (uVar6 = uVar14, 0x303 < iVar7)) {
            uVar6 = 1;
        }
        *puVar3 = uVar6;
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar8) != 0) {
        uVar4 = *(undefined8 *)(uVar12 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801addc7;
        iVar7 = func_0x000180498f10(uVar4, 0x1804af0ec);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801addda;
            iVar7 = func_0x000180498f10(uVar4, 0x1804af0f0);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801added;
                iVar7 = func_0x000180498f10(uVar4, 0x1804af0f8);
                if (iVar7 != 0) goto code_r0x0001801addf6;
            }
        }
    }
    uVar14 = 1;
code_r0x0001801addf6:
    return uVar14 & uVar13;
}

// ============================================================
// Function: FUN_1801ade01
// Address: 0x1801ade01
// Size: 24 bytes
// ============================================================
uint32_t fcn.1801adc80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    uint64_t uVar2;
    uint32_t *puVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int16_t in_DX;
    uint64_t uVar11;
    uint64_t uVar12;
    uint32_t uVar13;
    undefined8 unaff_RBP;
    uint32_t uVar14;
    uint64_t uVar15;
    uint64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    bool bVar16;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801adc92;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar15 = 0;
    uVar14 = 0;
    uVar2 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x668);
    uVar12 = uVar15;
    if (uVar2 != 0) {
        uVar11 = *(uint64_t *)(*(int64_t *)(in_RCX + 8) + 0x660);
        uVar9 = uVar15;
        do {
            uVar12 = uVar11;
            if (*(int16_t *)(uVar11 + 0x1c) == in_DX) break;
            uVar9 = uVar9 + 1;
            uVar11 = uVar11 + 0x38;
            uVar12 = uVar15;
        } while (uVar9 < uVar2);
    }
    puVar3 = *(uint32_t **)((int64_t)&arg_50h + iVar8);
    if (puVar3 != (uint32_t *)0x0) {
        *puVar3 = 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_R14;
    if (uVar12 == 0) {
        return 0;
    }
    bVar16 = (*(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) >> 3 & 1) == 0;
    iVar10 = 0x2c;
    if (bVar16) {
        iVar10 = 0x24;
    }
    iVar7 = *(int32_t *)(iVar10 + uVar12);
    iVar10 = 0x28;
    if (bVar16) {
        iVar10 = 0x20;
    }
    iVar1 = *(int32_t *)(iVar10 + uVar12);
    if (iVar1 < 0) {
        return 0;
    }
    if (iVar7 < 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RBP;
    if (iVar7 == 0) {
        uVar13 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801add56;
        iVar5 = func_0x0001801afd90(in_RCX, in_R8 & 0xffffffff, iVar7);
        uVar13 = (uint32_t)(iVar5 < 1);
    }
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801add71;
        uVar6 = func_0x0001801afd90(in_RCX, in_R9 & 0xffffffff, iVar1);
        uVar13 = uVar13 & ~uVar6 >> 0x1f;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) && (uVar13 != 0)) &&
        (puVar3 != (uint32_t *)0x0)) && ((int32_t)in_R9 == 0x304)) {
        if ((iVar7 == 0) || (uVar6 = uVar14, 0x303 < iVar7)) {
            uVar6 = 1;
        }
        *puVar3 = uVar6;
    }
    if (*(int32_t *)((int64_t)&arg_48h + iVar8) != 0) {
        uVar4 = *(undefined8 *)(uVar12 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801addc7;
        iVar7 = func_0x000180498f10(uVar4, 0x1804af0ec);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801addda;
            iVar7 = func_0x000180498f10(uVar4, 0x1804af0f0);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801added;
                iVar7 = func_0x000180498f10(uVar4, 0x1804af0f8);
                if (iVar7 != 0) goto code_r0x0001801addf6;
            }
        }
    }
    uVar14 = 1;
code_r0x0001801addf6:
    return uVar14 & uVar13;
}

// ============================================================
// Function: FUN_1801ade20
// Address: 0x1801ade20
// Size: 57 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

undefined4 fcn.1801ade20(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R15;
    int64_t var_1h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ade2f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = (int64_t)in_EDX;
    if (((in_R8 == 0) || (in_RCX == 0)) || (in_EDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf66;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf7e;
        func_0x0001802295a0(0x1804aeee0, 0x605, 0x1804af118);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf90;
        func_0x0001802296d0(0x14, 0x19e, 0);
        return 0;
    }
    iVar4 = *(int64_t *)(in_R8 + 0x20);
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R15;
    if (*(int64_t *)(in_R8 + 0x28) == iVar4) {
        uVar1 = *(undefined8 *)(in_R8 + 0x30);
        *(undefined4 *)((int64_t)&var_1h + iVar3 + 7) = 0x60e;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ade90;
        iVar4 = func_0x000180224f60(uVar1, iVar4 + 0x20, 8, 0x1804aeee0);
        if (iVar4 == 0) {
            return 0;
        }
        *(int64_t *)(in_R8 + 0x20) = *(int64_t *)(in_R8 + 0x20) + 0x20;
        *(int64_t *)(in_R8 + 0x30) = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adec1;
    iVar4 = func_0x0001802248d0(iVar5 + 1, 0x1804aeee0, 0x617);
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adef1;
    func_0x000180498030(iVar4, in_RCX, iVar5);
    *(undefined *)(iVar5 + iVar4) = 0;
    *(int64_t *)((int64_t)&var_1h + iVar3 + 7) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf15;
    uVar2 = func_0x00018024a850(iVar4, 0x3a, 1, 0x1801a7aa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf2d;
    func_0x000180224990(iVar4, 0x1804aeee0, 0x621);
    if (*(int64_t *)(*(int64_t *)(in_R8 + 0x30) + *(int64_t *)(in_R8 + 0x28) * 8) == 0) {
        return uVar2;
    }
    if (*(int64_t *)(in_R8 + 0x50) != 0) {
        iVar3 = *(int64_t *)(in_R8 + 0x28) + 1;
        *(int64_t *)(in_R8 + 0x28) = iVar3;
        *(undefined8 *)(*(int64_t *)(in_R8 + 0x30) + iVar3 * 8) = 0;
        *(undefined8 *)(in_R8 + 0x50) = 1;
        return uVar2;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801ade59
// Address: 0x1801ade59
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

undefined4 fcn.1801ade20(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R15;
    int64_t var_1h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ade2f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = (int64_t)in_EDX;
    if (((in_R8 == 0) || (in_RCX == 0)) || (in_EDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf66;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf7e;
        func_0x0001802295a0(0x1804aeee0, 0x605, 0x1804af118);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf90;
        func_0x0001802296d0(0x14, 0x19e, 0);
        return 0;
    }
    iVar4 = *(int64_t *)(in_R8 + 0x20);
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R15;
    if (*(int64_t *)(in_R8 + 0x28) == iVar4) {
        uVar1 = *(undefined8 *)(in_R8 + 0x30);
        *(undefined4 *)((int64_t)&var_1h + iVar3 + 7) = 0x60e;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ade90;
        iVar4 = func_0x000180224f60(uVar1, iVar4 + 0x20, 8, 0x1804aeee0);
        if (iVar4 == 0) {
            return 0;
        }
        *(int64_t *)(in_R8 + 0x20) = *(int64_t *)(in_R8 + 0x20) + 0x20;
        *(int64_t *)(in_R8 + 0x30) = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adec1;
    iVar4 = func_0x0001802248d0(iVar5 + 1, 0x1804aeee0, 0x617);
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adef1;
    func_0x000180498030(iVar4, in_RCX, iVar5);
    *(undefined *)(iVar5 + iVar4) = 0;
    *(int64_t *)((int64_t)&var_1h + iVar3 + 7) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf15;
    uVar2 = func_0x00018024a850(iVar4, 0x3a, 1, 0x1801a7aa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf2d;
    func_0x000180224990(iVar4, 0x1804aeee0, 0x621);
    if (*(int64_t *)(*(int64_t *)(in_R8 + 0x30) + *(int64_t *)(in_R8 + 0x28) * 8) == 0) {
        return uVar2;
    }
    if (*(int64_t *)(in_R8 + 0x50) != 0) {
        iVar3 = *(int64_t *)(in_R8 + 0x28) + 1;
        *(int64_t *)(in_R8 + 0x28) = iVar3;
        *(undefined8 *)(*(int64_t *)(in_R8 + 0x30) + iVar3 * 8) = 0;
        *(undefined8 *)(in_R8 + 0x50) = 1;
        return uVar2;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801adee3
// Address: 0x1801adee3
// Size: 126 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

undefined4 fcn.1801ade20(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R15;
    int64_t var_1h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ade2f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = (int64_t)in_EDX;
    if (((in_R8 == 0) || (in_RCX == 0)) || (in_EDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf66;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf7e;
        func_0x0001802295a0(0x1804aeee0, 0x605, 0x1804af118);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf90;
        func_0x0001802296d0(0x14, 0x19e, 0);
        return 0;
    }
    iVar4 = *(int64_t *)(in_R8 + 0x20);
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R15;
    if (*(int64_t *)(in_R8 + 0x28) == iVar4) {
        uVar1 = *(undefined8 *)(in_R8 + 0x30);
        *(undefined4 *)((int64_t)&var_1h + iVar3 + 7) = 0x60e;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ade90;
        iVar4 = func_0x000180224f60(uVar1, iVar4 + 0x20, 8, 0x1804aeee0);
        if (iVar4 == 0) {
            return 0;
        }
        *(int64_t *)(in_R8 + 0x20) = *(int64_t *)(in_R8 + 0x20) + 0x20;
        *(int64_t *)(in_R8 + 0x30) = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adec1;
    iVar4 = func_0x0001802248d0(iVar5 + 1, 0x1804aeee0, 0x617);
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adef1;
    func_0x000180498030(iVar4, in_RCX, iVar5);
    *(undefined *)(iVar5 + iVar4) = 0;
    *(int64_t *)((int64_t)&var_1h + iVar3 + 7) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf15;
    uVar2 = func_0x00018024a850(iVar4, 0x3a, 1, 0x1801a7aa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf2d;
    func_0x000180224990(iVar4, 0x1804aeee0, 0x621);
    if (*(int64_t *)(*(int64_t *)(in_R8 + 0x30) + *(int64_t *)(in_R8 + 0x28) * 8) == 0) {
        return uVar2;
    }
    if (*(int64_t *)(in_R8 + 0x50) != 0) {
        iVar3 = *(int64_t *)(in_R8 + 0x28) + 1;
        *(int64_t *)(in_R8 + 0x28) = iVar3;
        *(undefined8 *)(*(int64_t *)(in_R8 + 0x30) + iVar3 * 8) = 0;
        *(undefined8 *)(in_R8 + 0x50) = 1;
        return uVar2;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801adf61
// Address: 0x1801adf61
// Size: 58 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

undefined4 fcn.1801ade20(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R15;
    int64_t var_1h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ade2f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = (int64_t)in_EDX;
    if (((in_R8 == 0) || (in_RCX == 0)) || (in_EDX < 1)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf66;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf7e;
        func_0x0001802295a0(0x1804aeee0, 0x605, 0x1804af118);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf90;
        func_0x0001802296d0(0x14, 0x19e, 0);
        return 0;
    }
    iVar4 = *(int64_t *)(in_R8 + 0x20);
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R15;
    if (*(int64_t *)(in_R8 + 0x28) == iVar4) {
        uVar1 = *(undefined8 *)(in_R8 + 0x30);
        *(undefined4 *)((int64_t)&var_1h + iVar3 + 7) = 0x60e;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ade90;
        iVar4 = func_0x000180224f60(uVar1, iVar4 + 0x20, 8, 0x1804aeee0);
        if (iVar4 == 0) {
            return 0;
        }
        *(int64_t *)(in_R8 + 0x20) = *(int64_t *)(in_R8 + 0x20) + 0x20;
        *(int64_t *)(in_R8 + 0x30) = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adec1;
    iVar4 = func_0x0001802248d0(iVar5 + 1, 0x1804aeee0, 0x617);
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adef1;
    func_0x000180498030(iVar4, in_RCX, iVar5);
    *(undefined *)(iVar5 + iVar4) = 0;
    *(int64_t *)((int64_t)&var_1h + iVar3 + 7) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf15;
    uVar2 = func_0x00018024a850(iVar4, 0x3a, 1, 0x1801a7aa0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801adf2d;
    func_0x000180224990(iVar4, 0x1804aeee0, 0x621);
    if (*(int64_t *)(*(int64_t *)(in_R8 + 0x30) + *(int64_t *)(in_R8 + 0x28) * 8) == 0) {
        return uVar2;
    }
    if (*(int64_t *)(in_R8 + 0x50) != 0) {
        iVar3 = *(int64_t *)(in_R8 + 0x28) + 1;
        *(int64_t *)(in_R8 + 0x28) = iVar3;
        *(undefined8 *)(*(int64_t *)(in_R8 + 0x30) + iVar3 * 8) = 0;
        *(undefined8 *)(in_R8 + 0x50) = 1;
        return uVar2;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801adfa0
// Address: 0x1801adfa0
// Size: 28 bytes
// ============================================================
uint64_t fcn.1801adfa0(int64_t arg_30h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t *in_RCX;
    int64_t iVar5;
    int64_t *in_RDX;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar6 = *in_RDX;
    iVar5 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802378f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (iVar6 == 0) {
        return (uint64_t)(iVar5 != 0);
    }
    if (iVar5 != 0) {
        if ((*(int64_t *)(iVar5 + 0x18) == 0) || (*(int32_t *)(iVar5 + 8) != 0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18023793a;
            iVar1 = fcn.180234b40(*(int64_t *)(&stack0x00000070 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000a0 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000a8 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000b0 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000b8 + iVar3 + iVar2));
            if (iVar1 < 0) {
                return 0xfffffffe;
            }
        }
        if ((*(int64_t *)(iVar6 + 0x18) == 0) || (*(int32_t *)(iVar6 + 8) != 0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180237955;
            iVar1 = fcn.180234b40(*(int64_t *)(&stack0x00000070 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000a0 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000a8 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000b0 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x000000b8 + iVar3 + iVar2));
            if (iVar1 < 0) {
                return 0xfffffffe;
            }
        }
        iVar1 = *(int32_t *)(iVar5 + 0x20);
        iVar4 = iVar1 - *(int32_t *)(iVar6 + 0x20);
        if (iVar4 == 0) {
            if (iVar1 == 0) {
                return (int64_t)iVar1;
            }
            iVar5 = *(int64_t *)(iVar5 + 0x18);
            if ((iVar5 == 0) || (iVar6 = *(int64_t *)(iVar6 + 0x18), iVar6 == 0)) {
                return 0xfffffffe;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18023798d;
            iVar4 = fcn.180497f30(iVar5, iVar6, (int64_t)iVar1);
        }
        if (-1 < iVar4) {
            return (uint64_t)(0 < iVar4);
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801adfc0
// Address: 0x1801adfc0
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801adfc0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined4 *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801adfd5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_EDX == 0x303) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801adff5;
        iVar1 = fcn.1801afde0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            *in_R8 = 1;
            return;
        }
    }
    if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) && (in_EDX < 0x303)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ae038;
        iVar1 = fcn.1801afde0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar1 != 0) {
            *in_R8 = 2;
            return;
        }
    }
    *in_R8 = 0;
    return;
}

// ============================================================
// Function: FUN_1801ae070
// Address: 0x1801ae070
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel

undefined8 fcn.1801ae070(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int16_t in_DX;
    uint64_t uVar4;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ae08e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (((in_R8 != 0) && (in_R9 != 0)) && (uVar4 = 0, in_R9 != 0)) {
        iVar1 = *(int32_t *)((int64_t)&arg_48h + iVar3);
        do {
            if (in_DX == *(int16_t *)(in_R8 + uVar4 * 2)) {
                if (iVar1 == 0) {
code_r0x0001801ae0f6:
                    if (*(uint64_t **)((int64_t)&arg_50h + iVar3) != (uint64_t *)0x0) {
                        **(uint64_t **)((int64_t)&arg_50h + iVar3) = uVar4;
                    }
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae0cf;
                iVar2 = fcn.1801ada30(*(int64_t *)((int64_t)&var_18h + iVar3));
                if (iVar2 != 0) goto code_r0x0001801ae0f6;
            }
            uVar4 = uVar4 + 1;
        } while (uVar4 < in_R9);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ae110
// Address: 0x1801ae110
// Size: 412 bytes
// ============================================================
bool fcn.1801ae110(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ae120;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae139;
    iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae142;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae15a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae170;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if ((in_RDX != 0) && ((*(uint32_t *)(in_RCX + 0x9a8) >> 9 & 1) == 0)) {
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae1ac;
        iVar1 = fcn.180222010(in_RDX);
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae1ba;
                iVar4 = fcn.180222340(in_RDX, iVar5);
                if (iVar4 == 0) {
code_r0x0001801ae257:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae25c;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae274;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae28a;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
                    return false;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae1d0;
                iVar1 = fcn.180234b40(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000068 + iVar3), 
                                      *(int64_t *)(&stack0x00000070 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                                      *(int64_t *)(&stack0x00000080 + iVar3));
                if (iVar1 < 0) goto code_r0x0001801ae257;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae1f1;
                iVar2 = fcn.180244b60(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                if (iVar2 == 0) goto code_r0x0001801ae257;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae202;
                iVar2 = fcn.180234b40(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000068 + iVar3), 
                                      *(int64_t *)(&stack0x00000070 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                                      *(int64_t *)(&stack0x00000080 + iVar3));
                if (iVar2 != iVar1) goto code_r0x0001801ae257;
                iVar5 = iVar5 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae210;
                iVar1 = fcn.180222010(in_RDX);
            } while (iVar5 < iVar1);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae21c;
    iVar1 = fcn.180244000(in_R8);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae225;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae23d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ae253;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
    }
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_1801ae2b0
// Address: 0x1801ae2b0
// Size: 220 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1801ae2b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ae2ce;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae2f3;
    puVar5 = (undefined4 *)
             fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    if (puVar5 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae300;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae318;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae32e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        in_R9 = 0;
    } else {
        uVar1 = *(undefined4 *)(in_RCX + 0x188);
        uVar2 = *(undefined4 *)(in_RCX + 0x18c);
        uVar3 = *(undefined4 *)(in_RCX + 400);
        *puVar5 = *(undefined4 *)(in_RCX + 0x184);
        puVar5[1] = uVar1;
        puVar5[2] = uVar2;
        puVar5[3] = uVar3;
        uVar1 = *(undefined4 *)(in_RCX + 0x198);
        uVar2 = *(undefined4 *)(in_RCX + 0x19c);
        uVar3 = *(undefined4 *)(in_RCX + 0x1a0);
        puVar5[4] = *(undefined4 *)(in_RCX + 0x194);
        puVar5[5] = uVar1;
        puVar5[6] = uVar2;
        puVar5[7] = uVar3;
        uVar1 = *(undefined4 *)(in_RCX + 0x168);
        uVar2 = *(undefined4 *)(in_RCX + 0x16c);
        uVar3 = *(undefined4 *)(in_RCX + 0x170);
        puVar5[8] = *(undefined4 *)(in_RCX + 0x164);
        puVar5[9] = uVar1;
        puVar5[10] = uVar2;
        puVar5[0xb] = uVar3;
        uVar1 = *(undefined4 *)(in_RCX + 0x178);
        uVar2 = *(undefined4 *)(in_RCX + 0x17c);
        uVar3 = *(undefined4 *)(in_RCX + 0x180);
        puVar5[0xc] = *(undefined4 *)(in_RCX + 0x174);
        puVar5[0xd] = uVar1;
        puVar5[0xe] = uVar2;
        puVar5[0xf] = uVar3;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae36c;
        func_0x000180498030(puVar5 + 0x10, in_R8, in_R9);
        in_R9 = in_R9 + 0x40;
        *in_RDX = puVar5;
    }
    return in_R9;
}

// ============================================================
// Function: FUN_1801ae390
// Address: 0x1801ae390
// Size: 276 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_bh

void fcn.1801ae390(int64_t arg_58h, int64_t arg_a8h, int64_t arg_b0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ae39e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_58h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    *(undefined8 *)((int64_t)&var_10h + iVar4) = in_R8;
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 0;
    if (in_RDX == 0) {
        in_RDX = (int64_t)&var_18h + iVar4;
        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae3d8;
        iVar3 = func_0x0001801da790();
        if (iVar3 == 0) goto code_r0x0001801ae48c;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae3f8;
        iVar3 = func_0x000180197770(in_RCX, (int64_t)&var_18h + iVar4, 0x40, (int64_t)&var_10h + iVar4);
        if (iVar3 == 0) goto code_r0x0001801ae48c;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae408;
    iVar3 = func_0x0001801db380(in_RCX);
    if (iVar3 != 0) {
        *(undefined *)((int64_t)&var_8h + iVar4 + 3) = *(undefined *)((int64_t)&var_10h + iVar4);
        *(undefined *)((int64_t)&var_8h + iVar4) = 0xfe;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae42d;
        iVar3 = func_0x0001801dac70(in_RCX, (int64_t)&var_8h + iVar4, 4);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae441;
            iVar3 = func_0x0001801dac70(in_RCX, in_RDX, *(undefined8 *)((int64_t)&var_10h + iVar4));
            if ((iVar3 != 0) && (in_R9 != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae45d;
                iVar3 = func_0x0001801dac70(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_a8h + iVar4));
                if (iVar3 != 0) {
                    iVar1 = *(int64_t *)(in_RCX + 0x2f0);
                    uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae47f;
                    func_0x0001801dac70(in_RCX, uVar2, iVar1 + 4);
                }
            }
        }
    }
code_r0x0001801ae48c:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ae499;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801ae4b0
// Address: 0x1801ae4b0
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801ae4b0(int64_t arg_28h)
{
    int32_t iVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t *in_RCX;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ae4c0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX[0x1e] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ae4d1;
        iVar4 = fcn.1801a1020();
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ae4e1;
            iVar1 = fcn.180222010(iVar4);
            if (iVar1 != 0) {
                return iVar4;
            }
        }
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = 0x1801a0fcc;
    iVar4 = fcn.18045a350();
    if (in_RCX != (int32_t *)0x0) {
        piVar2 = in_RCX;
        if (*in_RCX == 0) {
code_r0x0001801a0ff0:
            if (*(int64_t *)(piVar2 + 0x266) != 0) {
                return *(int64_t *)(piVar2 + 0x266);
            }
            return *(int64_t *)(*(int64_t *)(in_RCX + 2) + 0x128);
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)auStackX_10 + (iVar3 - iVar4)) = 0x1801a0feb;
            piVar2 = (int32_t *)fcn.1801bda50();
            if (piVar2 != (int32_t *)0x0) goto code_r0x0001801a0ff0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ae510
// Address: 0x1801ae510
// Size: 369 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801ae510(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 uVar3;
    undefined8 *in_R8;
    int64_t *in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ae52b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar1 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar1)) && (iVar1 != 0x10000)) {
        *in_RDX = 0x2020202020202020;
        in_RDX[1] = 0x2020202020202020;
        in_RDX[2] = 0x2020202020202020;
        in_RDX[3] = 0x2020202020202020;
        in_RDX[4] = 0x2020202020202020;
        in_RDX[5] = 0x2020202020202020;
        in_RDX[6] = 0x2020202020202020;
        in_RDX[7] = 0x2020202020202020;
        if ((*(int32_t *)(in_RCX + 0xac) == 0x2b) || (*(int32_t *)(in_RCX + 0xac) == 0x2c)) {
            uVar3 = 0x1804af280;
        } else {
            uVar3 = 0x1804af2a8;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ae5ab;
        func_0x0001804990c0(in_RDX + 8, uVar3);
        if ((*(int32_t *)(in_RCX + 0xac) == 0x2b) || (*(int32_t *)(in_RCX + 0xac) == 0x21)) {
            uVar3 = *(undefined8 *)(in_RCX + 0x8c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ae5ff;
            func_0x000180498030((int64_t)in_RDX + 0x62, in_RCX + 0x880, uVar3);
            iVar2 = *(int64_t *)(in_RCX + 0x8c0) + 0x62;
            *in_R8 = in_RDX;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ae5d2;
            iVar1 = func_0x000180197770(in_RCX, (int64_t)in_RDX + 0x62, 0x40, (int64_t)&arg_28h + iVar2);
            if (iVar1 == 0) {
                return 0;
            }
            iVar2 = *(int64_t *)((int64_t)&arg_28h + iVar2) + 0x62;
            *in_R8 = in_RDX;
        }
    } else {
        uVar3 = *(undefined8 *)(in_RCX + 0x1a8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ae626;
        iVar1 = func_0x000180219d10(uVar3, 3, 0, in_R8);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ae62f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ae647;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ae65d;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar2));
            return 0;
        }
        iVar2 = (int64_t)iVar1;
    }
    *in_R9 = iVar2;
    return 1;
}

// ============================================================
// Function: FUN_1801ae690
// Address: 0x1801ae690
// Size: 407 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ae690(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ae6aa;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((*(int64_t *)(in_RCX + 8) != 0) && (*(int64_t *)(in_RCX + 0xb88) != 0)) {
        if ((*(int64_t *)(*(int64_t *)(in_RCX + 8) + 0x230) != 0) ||
           ((((*(int64_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x230) != 0 || (*(int64_t *)(in_RCX + 0x970) != 0)) ||
             (*(int64_t *)(in_RCX + 0x978) != 0)) || (*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x60) != 0)))) {
            return 1;
        }
        uVar7 = *(uint64_t *)(in_RCX + 0x118);
        uVar8 = 0;
        if (uVar7 != 0) {
            do {
                if ((((uVar8 != 2) && (uVar8 != 4)) &&
                    ((uVar8 != 5 && ((uVar8 != 6 && (iVar3 = (int32_t)uVar8, -1 < iVar3)))))) &&
                   (iVar3 < (int32_t)uVar7)) {
                    iVar5 = 0x15a0;
                    iVar9 = 0x15a8;
                    if (*(int32_t *)(in_RCX + 0x78) == 0) {
                        iVar5 = 0x1590;
                        iVar9 = 0x1598;
                    }
                    iVar5 = *(int64_t *)(iVar5 + in_RCX);
                    if (iVar5 == 0) {
                        iVar9 = *(int64_t *)(in_RCX + 0x878);
                        iVar5 = (int64_t)iVar3 * 0x28;
code_r0x0001801ae78d:
                        iVar6 = *(int64_t *)(iVar9 + 0x20);
                        if (*(int64_t *)(iVar5 + iVar6) == 0) goto code_r0x0001801ae7c4;
                    } else {
                        uVar1 = *(undefined8 *)(iVar9 + in_RCX);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ae7e8;
                        iVar6 = func_0x000180498a80(iVar5, 2, uVar1);
                        iVar9 = *(int64_t *)(in_RCX + 0x878);
                        iVar5 = (int64_t)iVar3 * 0x28;
                        if (iVar6 == 0) goto code_r0x0001801ae78d;
                        iVar6 = *(int64_t *)(iVar9 + 0x20);
                    }
                    if (*(int64_t *)(iVar5 + 8 + iVar6) != 0) {
                        if (uVar8 != 3) {
                            return 1;
                        }
                        uVar1 = *(undefined8 *)(*(int64_t *)(iVar9 + 0x20) + 0x80);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ae7b6;
                        uVar2 = func_0x0001801a86f0(uVar1);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ae7c0;
                        iVar3 = fcn.1801acbf0(in_RCX, (uint64_t)uVar2);
                        if (iVar3 != 0) {
                            return 1;
                        }
                    }
                }
code_r0x0001801ae7c4:
                uVar8 = uVar8 + 1;
                if (*(uint64_t *)(in_RCX + 0x118) <= uVar8) {
                    return 0;
                }
                uVar7 = *(uint64_t *)(in_RCX + 0x118) & 0xffffffff;
            } while( true );
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ae830
// Address: 0x1801ae830
// Size: 581 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801ae830(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined uVar1;
    undefined uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    undefined8 *in_RDX;
    uint64_t uVar12;
    undefined *puVar13;
    undefined *puVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801ae84c;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae861;
    iVar9 = func_0x000180221ee0(fcn.1801adfa0);
    iVar10 = 0;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae870;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18)
                     );
code_r0x0001801ae875:
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae888;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18)
                      , *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
    } else {
        puVar13 = (undefined *)*in_RDX;
        uVar3 = in_RDX[1];
        uVar11 = in_RDX[1];
        *(undefined **)(&stack0xfffffffffffffff8 + iVar8) = puVar13;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar8 + -0x18) = uVar3;
        if (1 < uVar11) {
            uVar11 = uVar11 - 2;
            puVar14 = puVar13 + 2;
            uVar12 = (uint64_t)CONCAT11(*puVar13, puVar13[1]);
            if (uVar12 <= uVar11) {
                *(undefined **)(&stack0xfffffffffffffff8 + iVar8) = puVar14 + uVar12;
                *(uint64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18) = uVar11 - uVar12;
                uVar4 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar8);
                uVar5 = *(undefined4 *)((int64_t)aiStackX_18 + iVar8 + -0x18);
                uVar6 = *(undefined4 *)((int64_t)aiStackX_18 + iVar8 + -0x14);
                *(undefined4 *)in_RDX = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar8);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                do {
                    if (uVar12 == 0) {
                        uVar3 = *(undefined8 *)(in_RCX + 0x358);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae971;
                        func_0x000180222050(uVar3, 0x1802348f0);
                        *(int64_t *)(in_RCX + 0x358) = iVar9;
                        return 1;
                    }
                    if (uVar12 < 2) {
code_r0x0001801ae9db:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae9e0;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae9f8;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18), 
                                      *(int64_t *)((int64_t)&var_8h + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -8), 
                                      *(int64_t *)(&stack0x00000028 + iVar8));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801aea0e;
                        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar8));
                        iVar10 = 0;
                        goto code_r0x0001801aea45;
                    }
                    uVar1 = *puVar14;
                    uVar2 = puVar14[1];
                    puVar13 = puVar14 + 2;
                    uVar11 = (uint64_t)(uint32_t)CONCAT11(uVar1, uVar2);
                    if (uVar12 - 2 < uVar11) goto code_r0x0001801ae9db;
                    *(undefined **)((int64_t)&arg_48h + iVar8) = puVar13;
                    puVar14 = puVar13 + uVar11;
                    uVar12 = (uVar12 - 2) - uVar11;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae937;
                    iVar10 = func_0x000180234b20(0, (int64_t)&arg_48h + iVar8, (uint32_t)CONCAT11(uVar1, uVar2));
                    if (iVar10 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae9bb;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae9d3;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18), 
                                      *(int64_t *)((int64_t)&var_8h + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -8), 
                                      *(int64_t *)(&stack0x00000028 + iVar8));
                        goto code_r0x0001801aea3a;
                    }
                    if (*(undefined **)((int64_t)&arg_48h + iVar8) != puVar13 + uVar11) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae996;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae9ae;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18), 
                                      *(int64_t *)((int64_t)&var_8h + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -8), 
                                      *(int64_t *)(&stack0x00000028 + iVar8));
                        goto code_r0x0001801aea3a;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae955;
                    iVar7 = func_0x000180222110(iVar9, iVar10);
                } while (iVar7 != 0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801ae987;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18));
                goto code_r0x0001801ae875;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801aea17;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18)
                     );
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801aea2f;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -0x18)
                      , *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + -8), 
                      *(int64_t *)(&stack0x00000028 + iVar8));
    }
code_r0x0001801aea3a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801aea45;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar8));
code_r0x0001801aea45:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801aea54;
    func_0x000180222050(iVar9, 0x1802348f0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801aea5c;
    func_0x0001802348f0(iVar10);
    return 0;
}

// ============================================================
// Function: FUN_1801aea80
// Address: 0x1801aea80
// Size: 550 bytes
// ============================================================
undefined8 fcn.1801aea80(int64_t arg_48h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801aea8e;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    pcVar2 = *(code **)(in_RCX + 0xd0);
    uVar3 = *(undefined8 *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_58h + iVar9) = 0;
    if ((((pcVar2 != (code *)0x0) && ((*(uint8_t *)(in_RCX + 0xe8) & 1) == 0)) && ((char)in_RDX == '\x16')) &&
       (uVar4 = *(uint64_t *)(in_RCX + 0x108), 3 < uVar4)) {
        iVar10 = *(int64_t *)(in_RCX + 0xf8);
        *(undefined8 *)((int64_t)&var_8h + iVar9) = *(undefined8 *)(in_RCX + 0xe0);
        uVar5 = *(undefined8 *)(iVar10 + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801aeb00;
        iVar8 = (*pcVar2)(uVar5, uVar4, (int64_t)&arg_60h + iVar9, (int64_t)&arg_48h + iVar9);
        if (iVar8 == 0) {
            return 0xffffffff;
        }
        if (*(uint64_t *)((int64_t)&arg_48h + iVar9) < 4) {
            return 0xffffffff;
        }
        uVar5 = *(undefined8 *)(in_RCX + 0xf8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801aeb23;
        iVar10 = func_0x000180226380(uVar5);
        if (iVar10 == 0) {
            return 0xffffffff;
        }
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801aeb46;
        func_0x000180498030(uVar5, *(undefined8 *)((int64_t)&arg_60h + iVar9), 
                            *(undefined8 *)((int64_t)&arg_48h + iVar9));
        *(undefined8 *)(in_RCX + 0x108) = *(undefined8 *)((int64_t)&arg_48h + iVar9);
        pcVar2 = *(code **)(in_RCX + 0xd8);
        *(int64_t *)(in_RCX + 0x100) = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + 4;
        uVar5 = *(undefined8 *)(in_RCX + 0xe0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801aeb78;
        (*pcVar2)(uVar5);
        *(uint32_t *)(in_RCX + 0xe8) = *(uint32_t *)(in_RCX + 0xe8) | 1;
    }
    uVar5 = *(undefined8 *)(in_RCX + 0x108);
    iVar10 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
    iVar6 = *(int64_t *)(in_RCX + 0x110);
    *(int64_t *)((int64_t)&var_8h + iVar9) = (int64_t)&arg_58h + iVar9;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801aebae;
    iVar8 = func_0x0001801a4290(in_RCX, in_RDX & 0xff, iVar10 + iVar6, uVar5);
    if (iVar8 < 1) {
        return 0xffffffff;
    }
    if (((char)in_RDX == '\x16') &&
       ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
         (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) ||
        ((iVar8 == 0x10000 || ((*(int32_t *)(in_RCX + 0xac) != 0x25 && (1 < *(int32_t *)(in_RCX + 0xac) - 0x2eU))))))))
    {
        iVar10 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        iVar6 = *(int64_t *)(in_RCX + 0x110);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801aec0f;
        iVar8 = func_0x0001801dac70(in_RCX, iVar10 + iVar6, *(undefined8 *)((int64_t)&arg_58h + iVar9));
        if (iVar8 == 0) {
            return 0xffffffff;
        }
    }
    iVar10 = *(int64_t *)(in_RCX + 0x108);
    iVar6 = *(int64_t *)((int64_t)&arg_58h + iVar9);
    if (iVar6 != iVar10) {
        *(int64_t *)(in_RCX + 0x110) = *(int64_t *)(in_RCX + 0x110) + iVar6;
        *(int64_t *)(in_RCX + 0x108) = iVar10 - iVar6;
        return 0;
    }
    *(uint32_t *)(in_RCX + 0xe8) = *(uint32_t *)(in_RCX + 0xe8) & 0xfffffffe;
    pcVar2 = *(code **)(in_RCX + 0x4f8);
    if (pcVar2 != (code *)0x0) {
        iVar6 = *(int64_t *)(in_RCX + 0x110);
        iVar7 = *(int64_t *)(in_RCX + 0xf8);
        *(undefined8 *)((int64_t)&var_18h + iVar9) = *(undefined8 *)(in_RCX + 0x500);
        *(undefined8 *)((int64_t)&var_10h + iVar9) = uVar3;
        *(int64_t *)((int64_t)&var_8h + iVar9) = iVar10 + iVar6;
        uVar3 = *(undefined8 *)(iVar7 + 8);
        uVar1 = *(undefined4 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801aec71;
        (*pcVar2)(1, uVar1, in_RDX & 0xff, uVar3);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801aecb0
// Address: 0x1801aecb0
// Size: 199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801aecb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RDX;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801aecca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aece6;
    iVar1 = fcn.180244a90(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    if (iVar1 == 0) {
        if (in_R9D != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aecf3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aed49;
        iVar1 = fcn.1801aede0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
        if (iVar1 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aed55;
        iVar1 = fcn.180244000(in_RDX);
        if (iVar1 != 0) {
            return 1;
        }
        if (in_R9D != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aed62;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aed0b;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801aed21;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801aed80
// Address: 0x1801aed80
// Size: 89 bytes
// ============================================================
bool fcn.1801aed80(int64_t param_1)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801aed8c;
    iVar2 = fcn.18045a350();
    pcVar1 = *(code **)(*(int64_t *)(*(int64_t *)(param_1 + 0x18) + 0xd8) + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801aedc2;
    iVar2 = (*pcVar1)();
    *(int64_t *)(param_1 + 0x2e8) = iVar2;
    return iVar2 != 0;
}

// ============================================================
// Function: FUN_1801aede0
// Address: 0x1801aede0
// Size: 635 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801aede0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801aee04;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    if ((in_R8 == (int64_t *)0x0) || (iVar2 = *in_R8, iVar2 == 0)) {
code_r0x0001801af037:
        uVar7 = 1;
    } else {
        iVar6 = in_R8[2];
        if (iVar6 == 0) {
            iVar6 = puVar1[0x22];
        }
        if ((((*(uint8_t *)(in_RCX + 0x9b0) & 8) == 0) && (iVar6 == 0)) &&
           ((iVar10 = *(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x70), iVar10 != 0 ||
            (iVar10 = puVar1[5], iVar10 != 0)))) {
            uVar7 = puVar1[0x8c];
            uVar8 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aee7b;
            iVar6 = func_0x00018024c080(uVar8, uVar7);
            if (iVar6 == 0) {
                if (in_R9D == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aee90;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
code_r0x0001801aee95:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aeea8;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
code_r0x0001801aefc2:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aefd2;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar5));
                    return 0;
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aeec4;
                iVar3 = func_0x00018024bbe0(iVar6, iVar10, iVar2, 0);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aeed0;
                    func_0x00018024b910();
                    if (in_R9D == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aeedd;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                        goto code_r0x0001801aee95;
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aeee9;
                    func_0x00018024c740(iVar6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aeeee;
                    func_0x0001802203d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aeef6;
                    uVar7 = func_0x00018024b960(iVar6);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef0a;
                    iVar3 = func_0x0001801a8ed0(in_RCX, uVar7, 0, 0);
                    if (iVar3 == 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef34;
                        iVar3 = fcn.180222010(uVar7);
                        iVar9 = 0;
                        if (0 < iVar3) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef4a;
                                uVar8 = fcn.180222340(uVar7, iVar9);
                                *(int32_t *)((int64_t)&var_8h + iVar5) = in_R9D;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef5f;
                                iVar4 = func_0x0001801af060(in_RCX, in_RDX, uVar8, iVar9);
                                if (iVar4 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef7f;
                                    func_0x00018024b910(iVar6);
                                    goto code_r0x0001801aef7f;
                                }
                                iVar9 = iVar9 + 1;
                            } while (iVar9 < iVar3);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef72;
                        func_0x00018024b910(iVar6);
                        goto code_r0x0001801af037;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef19;
                    func_0x00018024b910(iVar6);
                    if (in_R9D == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef22;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                        goto code_r0x0001801aefac;
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aef97;
            iVar3 = func_0x0001801a8ed0(in_RCX, iVar6, iVar2, 0);
            if (iVar3 == 1) {
                *(int32_t *)((int64_t)&var_8h + iVar5) = in_R9D;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aefeb;
                iVar3 = func_0x0001801af060(in_RCX, in_RDX, iVar2, 0);
                if (iVar3 != 0) {
                    iVar9 = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aeff9;
                    iVar3 = fcn.180222010(iVar6);
                    if (0 < iVar3) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af00a;
                            uVar7 = fcn.180222340(iVar6, iVar9);
                            iVar9 = iVar9 + 1;
                            *(int32_t *)((int64_t)&var_8h + iVar5) = in_R9D;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af023;
                            iVar3 = func_0x0001801af060(in_RCX, in_RDX, uVar7);
                            if (iVar3 == 0) goto code_r0x0001801aef7f;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af033;
                            iVar3 = fcn.180222010(iVar6);
                        } while (iVar9 < iVar3);
                    }
                    goto code_r0x0001801af037;
                }
            } else if (in_R9D == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aefa7;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
code_r0x0001801aefac:
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801aefbf;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5));
                goto code_r0x0001801aefc2;
            }
        }
code_r0x0001801aef7f:
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801af060
// Address: 0x1801af060
// Size: 341 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801af060(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801af084;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)((int64_t)&arg_68h + iVar5);
    uVar1 = 0x9000;
    if (iVar4 == 0) {
        uVar1 = 0x1000;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af0b5;
    iVar2 = func_0x0001802200d0(in_R8, 0);
    if (iVar2 < 0) {
        if (iVar4 != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af0c9;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af0e1;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)(&stack0x00000038 + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af102;
        iVar3 = fcn.180244b60(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af113;
            iVar3 = func_0x0001802200d0(in_R8, (int64_t)&var_18h + iVar5);
            if (iVar3 == iVar2) {
                if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                     (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) || (iVar4 != 0)) {
                    *(int64_t *)((int64_t)&var_8h + iVar5) = (int64_t)in_R9D;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af152;
                    iVar4 = func_0x0001801c9910(in_RCX, in_RDX, uVar1, in_R8);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                return 1;
            }
        }
        if (iVar4 != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af166;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af17e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)(&stack0x00000038 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801af194;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801af1c0
// Address: 0x1801af1c0
// Size: 63 bytes
// ============================================================
undefined8 fcn.1801af1c0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801af1ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((*(uint32_t *)(param_1 + 0x9a8) >> 0x11 & 1) != 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801af1fa;
    uVar2 = fcn.1801a2690(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000068 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_1801af200
// Address: 0x1801af200
// Size: 40 bytes
// ============================================================
bool fcn.1801af200(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801af20c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int32_t *)(in_RCX + 0x48) == **(int32_t **)(in_RCX + 0x10)) {
        return true;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af232;
    piVar4 = (int32_t *)fcn.18019a2d0();
    if (**(int32_t **)(in_RCX + 0x10) == *piVar4) {
        piVar4 = (int32_t *)0x1804af420;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af24a;
        piVar4 = (int32_t *)fcn.18019a2b0();
        if (**(int32_t **)(in_RCX + 0x10) != *piVar4) {
            return false;
        }
        piVar4 = (int32_t *)0x1804af4b0;
    }
    do {
        pcVar1 = *(code **)(piVar4 + 4);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af26b;
            (*pcVar1)();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af276;
            iVar2 = fcn.1801afb30(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            if (iVar2 == 0) {
                return *(int32_t *)(in_RCX + 0x48) == *piVar4;
            }
        }
        piVar4 = piVar4 + 6;
    } while (*piVar4 != 0);
    return false;
}

// ============================================================
// Function: FUN_1801af228
// Address: 0x1801af228
// Size: 104 bytes
// ============================================================
bool fcn.1801af200(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801af20c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int32_t *)(in_RCX + 0x48) == **(int32_t **)(in_RCX + 0x10)) {
        return true;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af232;
    piVar4 = (int32_t *)fcn.18019a2d0();
    if (**(int32_t **)(in_RCX + 0x10) == *piVar4) {
        piVar4 = (int32_t *)0x1804af420;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af24a;
        piVar4 = (int32_t *)fcn.18019a2b0();
        if (**(int32_t **)(in_RCX + 0x10) != *piVar4) {
            return false;
        }
        piVar4 = (int32_t *)0x1804af4b0;
    }
    do {
        pcVar1 = *(code **)(piVar4 + 4);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af26b;
            (*pcVar1)();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af276;
            iVar2 = fcn.1801afb30(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            if (iVar2 == 0) {
                return *(int32_t *)(in_RCX + 0x48) == *piVar4;
            }
        }
        piVar4 = piVar4 + 6;
    } while (*piVar4 != 0);
    return false;
}

// ============================================================
// Function: FUN_1801af290
// Address: 0x1801af290
// Size: 21 bytes
// ============================================================
bool fcn.1801af200(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801af20c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int32_t *)(in_RCX + 0x48) == **(int32_t **)(in_RCX + 0x10)) {
        return true;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af232;
    piVar4 = (int32_t *)fcn.18019a2d0();
    if (**(int32_t **)(in_RCX + 0x10) == *piVar4) {
        piVar4 = (int32_t *)0x1804af420;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af24a;
        piVar4 = (int32_t *)fcn.18019a2b0();
        if (**(int32_t **)(in_RCX + 0x10) != *piVar4) {
            return false;
        }
        piVar4 = (int32_t *)0x1804af4b0;
    }
    do {
        pcVar1 = *(code **)(piVar4 + 4);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af26b;
            (*pcVar1)();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801af276;
            iVar2 = fcn.1801afb30(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
            if (iVar2 == 0) {
                return *(int32_t *)(in_RCX + 0x48) == *piVar4;
            }
        }
        piVar4 = piVar4 + 6;
    } while (*piVar4 != 0);
    return false;
}

// ============================================================
// Function: FUN_1801af2b0
// Address: 0x1801af2b0
// Size: 155 bytes
// ============================================================
undefined8 fcn.1801af2b0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_98h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined4 in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t *piVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801af2bd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined4 *)(in_RCX + 0x48);
    *(undefined4 *)(in_RCX + 0x48) = in_EDX;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af2e8;
    uVar6 = fcn.1801c9d00(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5));
    if ((int32_t)uVar6 == 0) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        return uVar6;
    }
    if ((*(int32_t *)(in_RCX + 0x8c8) != 0) && (*(int32_t *)(in_RCX + 0x48) != 0x304)) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af310;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af328;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af33e;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        return 0;
    }
    piVar7 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RDI;
    iVar3 = *piVar7;
    if (iVar3 == 0x10000) {
        piVar7 = (int32_t *)0x1804af420;
    } else {
        if (iVar3 != 0x1ffff) {
            if (*(int32_t *)(in_RCX + 0x48) == iVar3) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3a5;
                iVar3 = fcn.1801a5230(in_RCX);
                if (iVar3 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3b2;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
code_r0x0001801af3b7:
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3ca;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
            } else {
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af37a;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af392;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
            }
            goto code_r0x0001801af57b;
        }
        piVar7 = (int32_t *)0x1804af4b0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af401;
    iVar3 = fcn.1801af910(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5), 
                          *(int64_t *)(&stack0x000000c8 + iVar5));
    if (iVar3 != 0) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af40f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af427;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        goto code_r0x0001801af57b;
    }
    iVar3 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af441;
    iVar4 = fcn.1801afd90(in_RCX, iVar3, *(undefined4 *)((int64_t)&arg_40h + iVar5));
    if (iVar4 < 0) {
code_r0x0001801af550:
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af558;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af458;
        iVar4 = fcn.1801afd90(in_RCX, iVar3, *(undefined4 *)((int64_t)&arg_48h + iVar5));
        if (0 < iVar4) goto code_r0x0001801af550;
        iVar4 = *(int32_t *)((int64_t)&arg_58h + iVar5);
        if ((*(uint8_t *)(in_RCX + 0x9b0) & 0x80) == 0) {
            iVar4 = *(int32_t *)((int64_t)&arg_48h + iVar5);
        }
        if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) && (iVar3 < iVar4)) {
            if (*(int64_t *)(in_RCX + 0x17c) == 0x4452474e574f44) {
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af49d;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            } else {
                if ((iVar4 != 0x304) || (*(int64_t *)(in_RCX + 0x17c) != 0x14452474e574f44)) goto code_r0x0001801af4ec;
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af4e5;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af4b5;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5));
            goto code_r0x0001801af57b;
        }
code_r0x0001801af4ec:
        iVar4 = *piVar7;
        while (iVar4 != 0) {
            pcVar2 = *(code **)(piVar7 + 2);
            if ((pcVar2 != (code *)0x0) && (iVar3 == *piVar7)) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af518;
                uVar6 = (*pcVar2)();
                *(undefined8 *)(in_RCX + 0x18) = uVar6;
                uVar1 = *(undefined4 *)(in_RCX + 0x48);
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af527;
                iVar3 = fcn.1801a5230(in_RCX, uVar1);
                if (iVar3 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af530;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                goto code_r0x0001801af3b7;
            }
            piVar7 = piVar7 + 6;
            iVar4 = *piVar7;
        }
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af50f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af570;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                  *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                  *(int64_t *)((int64_t)&arg_40h + iVar5));
code_r0x0001801af57b:
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af586;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801af34b
// Address: 0x1801af34b
// Size: 517 bytes
// ============================================================
undefined8 fcn.1801af2b0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_98h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined4 in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t *piVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801af2bd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined4 *)(in_RCX + 0x48);
    *(undefined4 *)(in_RCX + 0x48) = in_EDX;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af2e8;
    uVar6 = fcn.1801c9d00(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5));
    if ((int32_t)uVar6 == 0) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        return uVar6;
    }
    if ((*(int32_t *)(in_RCX + 0x8c8) != 0) && (*(int32_t *)(in_RCX + 0x48) != 0x304)) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af310;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af328;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af33e;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        return 0;
    }
    piVar7 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RDI;
    iVar3 = *piVar7;
    if (iVar3 == 0x10000) {
        piVar7 = (int32_t *)0x1804af420;
    } else {
        if (iVar3 != 0x1ffff) {
            if (*(int32_t *)(in_RCX + 0x48) == iVar3) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3a5;
                iVar3 = fcn.1801a5230(in_RCX);
                if (iVar3 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3b2;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
code_r0x0001801af3b7:
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3ca;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
            } else {
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af37a;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af392;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
            }
            goto code_r0x0001801af57b;
        }
        piVar7 = (int32_t *)0x1804af4b0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af401;
    iVar3 = fcn.1801af910(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5), 
                          *(int64_t *)(&stack0x000000c8 + iVar5));
    if (iVar3 != 0) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af40f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af427;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        goto code_r0x0001801af57b;
    }
    iVar3 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af441;
    iVar4 = fcn.1801afd90(in_RCX, iVar3, *(undefined4 *)((int64_t)&arg_40h + iVar5));
    if (iVar4 < 0) {
code_r0x0001801af550:
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af558;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af458;
        iVar4 = fcn.1801afd90(in_RCX, iVar3, *(undefined4 *)((int64_t)&arg_48h + iVar5));
        if (0 < iVar4) goto code_r0x0001801af550;
        iVar4 = *(int32_t *)((int64_t)&arg_58h + iVar5);
        if ((*(uint8_t *)(in_RCX + 0x9b0) & 0x80) == 0) {
            iVar4 = *(int32_t *)((int64_t)&arg_48h + iVar5);
        }
        if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) && (iVar3 < iVar4)) {
            if (*(int64_t *)(in_RCX + 0x17c) == 0x4452474e574f44) {
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af49d;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            } else {
                if ((iVar4 != 0x304) || (*(int64_t *)(in_RCX + 0x17c) != 0x14452474e574f44)) goto code_r0x0001801af4ec;
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af4e5;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af4b5;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5));
            goto code_r0x0001801af57b;
        }
code_r0x0001801af4ec:
        iVar4 = *piVar7;
        while (iVar4 != 0) {
            pcVar2 = *(code **)(piVar7 + 2);
            if ((pcVar2 != (code *)0x0) && (iVar3 == *piVar7)) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af518;
                uVar6 = (*pcVar2)();
                *(undefined8 *)(in_RCX + 0x18) = uVar6;
                uVar1 = *(undefined4 *)(in_RCX + 0x48);
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af527;
                iVar3 = fcn.1801a5230(in_RCX, uVar1);
                if (iVar3 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af530;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                goto code_r0x0001801af3b7;
            }
            piVar7 = piVar7 + 6;
            iVar4 = *piVar7;
        }
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af50f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af570;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                  *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                  *(int64_t *)((int64_t)&arg_40h + iVar5));
code_r0x0001801af57b:
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af586;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801af550
// Address: 0x1801af550
// Size: 73 bytes
// ============================================================
undefined8 fcn.1801af2b0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_98h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined4 in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int32_t *piVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801af2bd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(undefined4 *)(in_RCX + 0x48);
    *(undefined4 *)(in_RCX + 0x48) = in_EDX;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af2e8;
    uVar6 = fcn.1801c9d00(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5));
    if ((int32_t)uVar6 == 0) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        return uVar6;
    }
    if ((*(int32_t *)(in_RCX + 0x8c8) != 0) && (*(int32_t *)(in_RCX + 0x48) != 0x304)) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af310;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af328;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af33e;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
        return 0;
    }
    piVar7 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RDI;
    iVar3 = *piVar7;
    if (iVar3 == 0x10000) {
        piVar7 = (int32_t *)0x1804af420;
    } else {
        if (iVar3 != 0x1ffff) {
            if (*(int32_t *)(in_RCX + 0x48) == iVar3) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3a5;
                iVar3 = fcn.1801a5230(in_RCX);
                if (iVar3 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3b2;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
code_r0x0001801af3b7:
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af3ca;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
            } else {
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af37a;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af392;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                              *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar5));
            }
            goto code_r0x0001801af57b;
        }
        piVar7 = (int32_t *)0x1804af4b0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af401;
    iVar3 = fcn.1801af910(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar5), 
                          *(int64_t *)(&stack0x000000c8 + iVar5));
    if (iVar3 != 0) {
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af40f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af427;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                      *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                      *(int64_t *)((int64_t)&arg_40h + iVar5));
        goto code_r0x0001801af57b;
    }
    iVar3 = *(int32_t *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af441;
    iVar4 = fcn.1801afd90(in_RCX, iVar3, *(undefined4 *)((int64_t)&arg_40h + iVar5));
    if (iVar4 < 0) {
code_r0x0001801af550:
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af558;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af458;
        iVar4 = fcn.1801afd90(in_RCX, iVar3, *(undefined4 *)((int64_t)&arg_48h + iVar5));
        if (0 < iVar4) goto code_r0x0001801af550;
        iVar4 = *(int32_t *)((int64_t)&arg_58h + iVar5);
        if ((*(uint8_t *)(in_RCX + 0x9b0) & 0x80) == 0) {
            iVar4 = *(int32_t *)((int64_t)&arg_48h + iVar5);
        }
        if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) && (iVar3 < iVar4)) {
            if (*(int64_t *)(in_RCX + 0x17c) == 0x4452474e574f44) {
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af49d;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            } else {
                if ((iVar4 != 0x304) || (*(int64_t *)(in_RCX + 0x17c) != 0x14452474e574f44)) goto code_r0x0001801af4ec;
                *(undefined4 *)(in_RCX + 0x48) = uVar1;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af4e5;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af4b5;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                          *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                          *(int64_t *)((int64_t)&arg_40h + iVar5));
            goto code_r0x0001801af57b;
        }
code_r0x0001801af4ec:
        iVar4 = *piVar7;
        while (iVar4 != 0) {
            pcVar2 = *(code **)(piVar7 + 2);
            if ((pcVar2 != (code *)0x0) && (iVar3 == *piVar7)) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af518;
                uVar6 = (*pcVar2)();
                *(undefined8 *)(in_RCX + 0x18) = uVar6;
                uVar1 = *(undefined4 *)(in_RCX + 0x48);
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af527;
                iVar3 = fcn.1801a5230(in_RCX, uVar1);
                if (iVar3 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af530;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
                goto code_r0x0001801af3b7;
            }
            piVar7 = piVar7 + 6;
            iVar4 = *piVar7;
        }
        *(undefined4 *)(in_RCX + 0x48) = uVar1;
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af50f;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5));
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af570;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&var_18h + iVar5), 
                  *(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                  *(int64_t *)((int64_t)&arg_40h + iVar5));
code_r0x0001801af57b:
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x1801af586;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000030 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801af5a0
// Address: 0x1801af5a0
// Size: 166 bytes
// ============================================================
undefined4
fcn.1801af5a0(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    int32_t *piVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    undefined4 uVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    uint32_t uVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar22;
    uint8_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801af5b5;
    var_18h = arg3;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    iVar8 = *(int32_t *)(placeholder_1 + 4);
    piVar3 = *(int32_t **)(placeholder_0 + 0x18);
    uVar21 = 0;
    iVar10 = *piVar3;
    *(int32_t *)(placeholder_0 + 0x9cc) = iVar8;
    if (iVar10 == 0x10000) {
code_r0x0001801af638:
        piVar20 = (int32_t *)0x1804af420;
    } else {
        if (iVar10 != 0x1ffff) {
            if ((((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) != 0) || (*piVar3 < 0x304)) ||
               (*piVar3 == 0x10000)) {
                uVar11 = *(undefined4 *)(placeholder_0 + 0x48);
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af60b;
                iVar8 = fcn.1801afd90(placeholder_0, iVar8, uVar11);
                if (iVar8 < 0) {
                    return 0x10a;
                }
                *(undefined4 *)arg3 = 0;
                return 0;
            }
            goto code_r0x0001801af638;
        }
        piVar20 = (int32_t *)0x1804af4b0;
    }
    iVar4 = *(int64_t *)(placeholder_1 + 0x288);
    *(undefined8 *)((int64_t)&arg_50h + iVar12) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar12) = unaff_R13;
    *(undefined8 *)((int64_t)&var_8h + iVar12) = unaff_R14;
    if (*(int32_t *)(iVar4 + 0x308) == 0) {
        if (*(int32_t *)(placeholder_0 + 0x8c8) != 0) {
            return 0x102;
        }
    } else if ((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) == 0) {
        *(undefined4 *)(iVar4 + 0x30c) = 1;
        puVar23 = *(uint8_t **)(iVar4 + 0x2f8);
        uVar13 = *(undefined8 *)(iVar4 + 0x300);
        iVar18 = *(int64_t *)(iVar4 + 0x300);
        *(undefined8 *)((int64_t)&arg_48h + iVar12) = 0;
        *(uint8_t **)(&stack0xfffffffffffffff8 + iVar12) = puVar23;
        *(undefined8 *)(&stack0x00000000 + iVar12) = uVar13;
        if (iVar18 != 0) {
            uVar17 = iVar18 - 1;
            uVar22 = (uint64_t)*puVar23;
            puVar23 = puVar23 + 1;
            if (uVar22 <= uVar17) {
                iVar18 = uVar17 - uVar22;
                *(uint8_t **)(&stack0xfffffffffffffff8 + iVar12) = puVar23 + uVar22;
                *(int64_t *)(&stack0x00000000 + iVar12) = iVar18;
                if (iVar18 == 0) {
                    uVar11 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar12);
                    uVar6 = *(undefined4 *)(&stack0x00000000 + iVar12);
                    uVar7 = *(undefined4 *)(&stack0x00000004 + iVar12);
                    *(undefined4 *)(iVar4 + 0x2f8) = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar12);
                    *(undefined4 *)(iVar4 + 0x2fc) = uVar11;
                    *(undefined4 *)(iVar4 + 0x300) = uVar6;
                    *(undefined4 *)(iVar4 + 0x304) = uVar7;
                    if (iVar8 < 0x301) {
                        return 0x124;
                    }
                    while (1 < uVar22) {
                        uVar2 = *puVar23;
                        uVar22 = uVar22 - 2;
                        puVar1 = puVar23 + 1;
                        puVar23 = puVar23 + 2;
                        uVar19 = (uint32_t)CONCAT11(uVar2, *puVar1);
                        if (uVar19 != uVar21) {
                            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0)
                            {
                                iVar8 = 1;
                                if (uVar19 < uVar21) {
                                    iVar8 = -1;
                                }
                            } else {
                                uVar14 = uVar19;
                                if (uVar19 == 0x100) {
                                    uVar14 = 0xff00;
                                }
                                uVar9 = uVar21;
                                if (uVar21 == 0x100) {
                                    uVar9 = 0xff00;
                                }
                                iVar8 = 1;
                                if (uVar9 < uVar14) {
                                    iVar8 = -1;
                                }
                            }
                            if (0 < iVar8) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7a7;
                                iVar8 = fcn.1801afde0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                                                      *(int64_t *)(&stack0x00000000 + iVar12), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar12));
                                if (iVar8 != 0) {
                                    uVar21 = uVar19;
                                }
                            }
                        }
                    }
                    if (uVar22 == 0) {
                        if (uVar21 == 0) {
                            return 0x102;
                        }
                        if (*(int32_t *)(placeholder_0 + 0x8c8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7e5;
                            fcn.1801adfc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                                          *(int64_t *)(&stack0x00000000 + iVar12));
                            uVar13 = *(undefined8 *)((int64_t)&arg_48h + iVar12);
                            *(uint32_t *)(placeholder_0 + 0x48) = uVar21;
                            *(undefined8 *)(placeholder_0 + 0x18) = uVar13;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7fb;
                            iVar8 = fcn.1801a5230(placeholder_0, uVar21);
                            if (iVar8 == 0) {
                                return 0xc0103;
                            }
                        } else if (uVar21 != 0x304) {
                            return 0x102;
                        }
                        return 0;
                    }
                }
            }
        }
        return 0x9f;
    }
    if (iVar8 != 0x304) {
        if ((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) == 0) {
            iVar15 = 1;
            if (iVar8 < 0x304) {
                iVar15 = -1;
            }
        } else {
            iVar10 = iVar8;
            if (iVar8 == 0x100) {
                iVar10 = 0xff00;
            }
            iVar15 = 1;
            if (0x304 < iVar10) {
                iVar15 = -1;
            }
        }
        if (iVar15 < 0) goto code_r0x0001801af838;
    }
    iVar8 = 0x303;
code_r0x0001801af838:
    iVar10 = *piVar20;
    do {
        if (iVar10 == 0) {
            uVar11 = 0x18c;
            if (uVar21 != 0) {
                uVar11 = 0x102;
            }
            return uVar11;
        }
        pcVar5 = *(code **)(piVar20 + 4);
        if (pcVar5 != (code *)0x0) {
            iVar10 = *piVar20;
            if (iVar8 != iVar10) {
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    iVar16 = 1;
                    if (iVar8 < iVar10) {
                        iVar16 = -1;
                    }
                } else {
                    if (iVar10 == 0x100) {
                        iVar10 = 0xff00;
                    }
                    iVar15 = iVar8;
                    if (iVar8 == 0x100) {
                        iVar15 = 0xff00;
                    }
                    iVar16 = 1;
                    if (iVar10 < iVar15) {
                        iVar16 = -1;
                    }
                }
                if (iVar16 < 0) goto code_r0x0001801af8a8;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af890;
            uVar13 = (*pcVar5)();
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af89e;
            iVar10 = fcn.1801afb30(*(int64_t *)((int64_t)&var_8h + iVar12), *(int64_t *)((int64_t)&var_10h + iVar12));
            if (iVar10 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af8e7;
                fcn.1801adfc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), *(int64_t *)(&stack0x00000000 + iVar12));
                *(int32_t *)(placeholder_0 + 0x48) = *piVar20;
                *(undefined8 *)(placeholder_0 + 0x18) = uVar13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af8f8;
                iVar8 = fcn.1801a5230(placeholder_0);
                if (iVar8 == 0) {
                    return 0xc0103;
                }
                return 0;
            }
            uVar21 = 1;
        }
code_r0x0001801af8a8:
        piVar20 = piVar20 + 6;
        iVar10 = *piVar20;
    } while( true );
}

// ============================================================
// Function: FUN_1801af646
// Address: 0x1801af646
// Size: 660 bytes
// ============================================================
undefined4
fcn.1801af5a0(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    int32_t *piVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    undefined4 uVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    uint32_t uVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar22;
    uint8_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801af5b5;
    var_18h = arg3;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    iVar8 = *(int32_t *)(placeholder_1 + 4);
    piVar3 = *(int32_t **)(placeholder_0 + 0x18);
    uVar21 = 0;
    iVar10 = *piVar3;
    *(int32_t *)(placeholder_0 + 0x9cc) = iVar8;
    if (iVar10 == 0x10000) {
code_r0x0001801af638:
        piVar20 = (int32_t *)0x1804af420;
    } else {
        if (iVar10 != 0x1ffff) {
            if ((((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) != 0) || (*piVar3 < 0x304)) ||
               (*piVar3 == 0x10000)) {
                uVar11 = *(undefined4 *)(placeholder_0 + 0x48);
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af60b;
                iVar8 = fcn.1801afd90(placeholder_0, iVar8, uVar11);
                if (iVar8 < 0) {
                    return 0x10a;
                }
                *(undefined4 *)arg3 = 0;
                return 0;
            }
            goto code_r0x0001801af638;
        }
        piVar20 = (int32_t *)0x1804af4b0;
    }
    iVar4 = *(int64_t *)(placeholder_1 + 0x288);
    *(undefined8 *)((int64_t)&arg_50h + iVar12) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar12) = unaff_R13;
    *(undefined8 *)((int64_t)&var_8h + iVar12) = unaff_R14;
    if (*(int32_t *)(iVar4 + 0x308) == 0) {
        if (*(int32_t *)(placeholder_0 + 0x8c8) != 0) {
            return 0x102;
        }
    } else if ((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) == 0) {
        *(undefined4 *)(iVar4 + 0x30c) = 1;
        puVar23 = *(uint8_t **)(iVar4 + 0x2f8);
        uVar13 = *(undefined8 *)(iVar4 + 0x300);
        iVar18 = *(int64_t *)(iVar4 + 0x300);
        *(undefined8 *)((int64_t)&arg_48h + iVar12) = 0;
        *(uint8_t **)(&stack0xfffffffffffffff8 + iVar12) = puVar23;
        *(undefined8 *)(&stack0x00000000 + iVar12) = uVar13;
        if (iVar18 != 0) {
            uVar17 = iVar18 - 1;
            uVar22 = (uint64_t)*puVar23;
            puVar23 = puVar23 + 1;
            if (uVar22 <= uVar17) {
                iVar18 = uVar17 - uVar22;
                *(uint8_t **)(&stack0xfffffffffffffff8 + iVar12) = puVar23 + uVar22;
                *(int64_t *)(&stack0x00000000 + iVar12) = iVar18;
                if (iVar18 == 0) {
                    uVar11 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar12);
                    uVar6 = *(undefined4 *)(&stack0x00000000 + iVar12);
                    uVar7 = *(undefined4 *)(&stack0x00000004 + iVar12);
                    *(undefined4 *)(iVar4 + 0x2f8) = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar12);
                    *(undefined4 *)(iVar4 + 0x2fc) = uVar11;
                    *(undefined4 *)(iVar4 + 0x300) = uVar6;
                    *(undefined4 *)(iVar4 + 0x304) = uVar7;
                    if (iVar8 < 0x301) {
                        return 0x124;
                    }
                    while (1 < uVar22) {
                        uVar2 = *puVar23;
                        uVar22 = uVar22 - 2;
                        puVar1 = puVar23 + 1;
                        puVar23 = puVar23 + 2;
                        uVar19 = (uint32_t)CONCAT11(uVar2, *puVar1);
                        if (uVar19 != uVar21) {
                            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0)
                            {
                                iVar8 = 1;
                                if (uVar19 < uVar21) {
                                    iVar8 = -1;
                                }
                            } else {
                                uVar14 = uVar19;
                                if (uVar19 == 0x100) {
                                    uVar14 = 0xff00;
                                }
                                uVar9 = uVar21;
                                if (uVar21 == 0x100) {
                                    uVar9 = 0xff00;
                                }
                                iVar8 = 1;
                                if (uVar9 < uVar14) {
                                    iVar8 = -1;
                                }
                            }
                            if (0 < iVar8) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7a7;
                                iVar8 = fcn.1801afde0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                                                      *(int64_t *)(&stack0x00000000 + iVar12), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar12));
                                if (iVar8 != 0) {
                                    uVar21 = uVar19;
                                }
                            }
                        }
                    }
                    if (uVar22 == 0) {
                        if (uVar21 == 0) {
                            return 0x102;
                        }
                        if (*(int32_t *)(placeholder_0 + 0x8c8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7e5;
                            fcn.1801adfc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                                          *(int64_t *)(&stack0x00000000 + iVar12));
                            uVar13 = *(undefined8 *)((int64_t)&arg_48h + iVar12);
                            *(uint32_t *)(placeholder_0 + 0x48) = uVar21;
                            *(undefined8 *)(placeholder_0 + 0x18) = uVar13;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7fb;
                            iVar8 = fcn.1801a5230(placeholder_0, uVar21);
                            if (iVar8 == 0) {
                                return 0xc0103;
                            }
                        } else if (uVar21 != 0x304) {
                            return 0x102;
                        }
                        return 0;
                    }
                }
            }
        }
        return 0x9f;
    }
    if (iVar8 != 0x304) {
        if ((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) == 0) {
            iVar15 = 1;
            if (iVar8 < 0x304) {
                iVar15 = -1;
            }
        } else {
            iVar10 = iVar8;
            if (iVar8 == 0x100) {
                iVar10 = 0xff00;
            }
            iVar15 = 1;
            if (0x304 < iVar10) {
                iVar15 = -1;
            }
        }
        if (iVar15 < 0) goto code_r0x0001801af838;
    }
    iVar8 = 0x303;
code_r0x0001801af838:
    iVar10 = *piVar20;
    do {
        if (iVar10 == 0) {
            uVar11 = 0x18c;
            if (uVar21 != 0) {
                uVar11 = 0x102;
            }
            return uVar11;
        }
        pcVar5 = *(code **)(piVar20 + 4);
        if (pcVar5 != (code *)0x0) {
            iVar10 = *piVar20;
            if (iVar8 != iVar10) {
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    iVar16 = 1;
                    if (iVar8 < iVar10) {
                        iVar16 = -1;
                    }
                } else {
                    if (iVar10 == 0x100) {
                        iVar10 = 0xff00;
                    }
                    iVar15 = iVar8;
                    if (iVar8 == 0x100) {
                        iVar15 = 0xff00;
                    }
                    iVar16 = 1;
                    if (iVar10 < iVar15) {
                        iVar16 = -1;
                    }
                }
                if (iVar16 < 0) goto code_r0x0001801af8a8;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af890;
            uVar13 = (*pcVar5)();
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af89e;
            iVar10 = fcn.1801afb30(*(int64_t *)((int64_t)&var_8h + iVar12), *(int64_t *)((int64_t)&var_10h + iVar12));
            if (iVar10 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af8e7;
                fcn.1801adfc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), *(int64_t *)(&stack0x00000000 + iVar12));
                *(int32_t *)(placeholder_0 + 0x48) = *piVar20;
                *(undefined8 *)(placeholder_0 + 0x18) = uVar13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af8f8;
                iVar8 = fcn.1801a5230(placeholder_0);
                if (iVar8 == 0) {
                    return 0xc0103;
                }
                return 0;
            }
            uVar21 = 1;
        }
code_r0x0001801af8a8:
        piVar20 = piVar20 + 6;
        iVar10 = *piVar20;
    } while( true );
}

// ============================================================
// Function: FUN_1801af8da
// Address: 0x1801af8da
// Size: 44 bytes
// ============================================================
undefined4
fcn.1801af5a0(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    int32_t *piVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    undefined4 uVar11;
    int64_t iVar12;
    undefined8 uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    uint32_t uVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar22;
    uint8_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801af5b5;
    var_18h = arg3;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    iVar8 = *(int32_t *)(placeholder_1 + 4);
    piVar3 = *(int32_t **)(placeholder_0 + 0x18);
    uVar21 = 0;
    iVar10 = *piVar3;
    *(int32_t *)(placeholder_0 + 0x9cc) = iVar8;
    if (iVar10 == 0x10000) {
code_r0x0001801af638:
        piVar20 = (int32_t *)0x1804af420;
    } else {
        if (iVar10 != 0x1ffff) {
            if ((((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) != 0) || (*piVar3 < 0x304)) ||
               (*piVar3 == 0x10000)) {
                uVar11 = *(undefined4 *)(placeholder_0 + 0x48);
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af60b;
                iVar8 = fcn.1801afd90(placeholder_0, iVar8, uVar11);
                if (iVar8 < 0) {
                    return 0x10a;
                }
                *(undefined4 *)arg3 = 0;
                return 0;
            }
            goto code_r0x0001801af638;
        }
        piVar20 = (int32_t *)0x1804af4b0;
    }
    iVar4 = *(int64_t *)(placeholder_1 + 0x288);
    *(undefined8 *)((int64_t)&arg_50h + iVar12) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar12) = unaff_R13;
    *(undefined8 *)((int64_t)&var_8h + iVar12) = unaff_R14;
    if (*(int32_t *)(iVar4 + 0x308) == 0) {
        if (*(int32_t *)(placeholder_0 + 0x8c8) != 0) {
            return 0x102;
        }
    } else if ((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) == 0) {
        *(undefined4 *)(iVar4 + 0x30c) = 1;
        puVar23 = *(uint8_t **)(iVar4 + 0x2f8);
        uVar13 = *(undefined8 *)(iVar4 + 0x300);
        iVar18 = *(int64_t *)(iVar4 + 0x300);
        *(undefined8 *)((int64_t)&arg_48h + iVar12) = 0;
        *(uint8_t **)(&stack0xfffffffffffffff8 + iVar12) = puVar23;
        *(undefined8 *)(&stack0x00000000 + iVar12) = uVar13;
        if (iVar18 != 0) {
            uVar17 = iVar18 - 1;
            uVar22 = (uint64_t)*puVar23;
            puVar23 = puVar23 + 1;
            if (uVar22 <= uVar17) {
                iVar18 = uVar17 - uVar22;
                *(uint8_t **)(&stack0xfffffffffffffff8 + iVar12) = puVar23 + uVar22;
                *(int64_t *)(&stack0x00000000 + iVar12) = iVar18;
                if (iVar18 == 0) {
                    uVar11 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar12);
                    uVar6 = *(undefined4 *)(&stack0x00000000 + iVar12);
                    uVar7 = *(undefined4 *)(&stack0x00000004 + iVar12);
                    *(undefined4 *)(iVar4 + 0x2f8) = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar12);
                    *(undefined4 *)(iVar4 + 0x2fc) = uVar11;
                    *(undefined4 *)(iVar4 + 0x300) = uVar6;
                    *(undefined4 *)(iVar4 + 0x304) = uVar7;
                    if (iVar8 < 0x301) {
                        return 0x124;
                    }
                    while (1 < uVar22) {
                        uVar2 = *puVar23;
                        uVar22 = uVar22 - 2;
                        puVar1 = puVar23 + 1;
                        puVar23 = puVar23 + 2;
                        uVar19 = (uint32_t)CONCAT11(uVar2, *puVar1);
                        if (uVar19 != uVar21) {
                            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0)
                            {
                                iVar8 = 1;
                                if (uVar19 < uVar21) {
                                    iVar8 = -1;
                                }
                            } else {
                                uVar14 = uVar19;
                                if (uVar19 == 0x100) {
                                    uVar14 = 0xff00;
                                }
                                uVar9 = uVar21;
                                if (uVar21 == 0x100) {
                                    uVar9 = 0xff00;
                                }
                                iVar8 = 1;
                                if (uVar9 < uVar14) {
                                    iVar8 = -1;
                                }
                            }
                            if (0 < iVar8) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7a7;
                                iVar8 = fcn.1801afde0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                                                      *(int64_t *)(&stack0x00000000 + iVar12), 
                                                      *(int64_t *)((int64_t)&var_8h + iVar12));
                                if (iVar8 != 0) {
                                    uVar21 = uVar19;
                                }
                            }
                        }
                    }
                    if (uVar22 == 0) {
                        if (uVar21 == 0) {
                            return 0x102;
                        }
                        if (*(int32_t *)(placeholder_0 + 0x8c8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7e5;
                            fcn.1801adfc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                                          *(int64_t *)(&stack0x00000000 + iVar12));
                            uVar13 = *(undefined8 *)((int64_t)&arg_48h + iVar12);
                            *(uint32_t *)(placeholder_0 + 0x48) = uVar21;
                            *(undefined8 *)(placeholder_0 + 0x18) = uVar13;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af7fb;
                            iVar8 = fcn.1801a5230(placeholder_0, uVar21);
                            if (iVar8 == 0) {
                                return 0xc0103;
                            }
                        } else if (uVar21 != 0x304) {
                            return 0x102;
                        }
                        return 0;
                    }
                }
            }
        }
        return 0x9f;
    }
    if (iVar8 != 0x304) {
        if ((*(uint8_t *)(*(int64_t *)(piVar3 + 0x36) + 0x50) & 8) == 0) {
            iVar15 = 1;
            if (iVar8 < 0x304) {
                iVar15 = -1;
            }
        } else {
            iVar10 = iVar8;
            if (iVar8 == 0x100) {
                iVar10 = 0xff00;
            }
            iVar15 = 1;
            if (0x304 < iVar10) {
                iVar15 = -1;
            }
        }
        if (iVar15 < 0) goto code_r0x0001801af838;
    }
    iVar8 = 0x303;
code_r0x0001801af838:
    iVar10 = *piVar20;
    do {
        if (iVar10 == 0) {
            uVar11 = 0x18c;
            if (uVar21 != 0) {
                uVar11 = 0x102;
            }
            return uVar11;
        }
        pcVar5 = *(code **)(piVar20 + 4);
        if (pcVar5 != (code *)0x0) {
            iVar10 = *piVar20;
            if (iVar8 != iVar10) {
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    iVar16 = 1;
                    if (iVar8 < iVar10) {
                        iVar16 = -1;
                    }
                } else {
                    if (iVar10 == 0x100) {
                        iVar10 = 0xff00;
                    }
                    iVar15 = iVar8;
                    if (iVar8 == 0x100) {
                        iVar15 = 0xff00;
                    }
                    iVar16 = 1;
                    if (iVar10 < iVar15) {
                        iVar16 = -1;
                    }
                }
                if (iVar16 < 0) goto code_r0x0001801af8a8;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af890;
            uVar13 = (*pcVar5)();
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af89e;
            iVar10 = fcn.1801afb30(*(int64_t *)((int64_t)&var_8h + iVar12), *(int64_t *)((int64_t)&var_10h + iVar12));
            if (iVar10 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af8e7;
                fcn.1801adfc0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), *(int64_t *)(&stack0x00000000 + iVar12));
                *(int32_t *)(placeholder_0 + 0x48) = *piVar20;
                *(undefined8 *)(placeholder_0 + 0x18) = uVar13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1801af8f8;
                iVar8 = fcn.1801a5230(placeholder_0);
                if (iVar8 == 0) {
                    return 0xc0103;
                }
                return 0;
            }
            uVar21 = 1;
        }
code_r0x0001801af8a8:
        piVar20 = piVar20 + 6;
        iVar10 = *piVar20;
    } while( true );
}

// ============================================================
// Function: FUN_1801af910
// Address: 0x1801af910
// Size: 100 bytes
// ============================================================
uint32_t fcn.1801af910(int64_t placeholder_0, int64_t arg2, int64_t arg3, uint32_t *placeholder_3, int64_t arg_28h,
                      int64_t arg_30h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_e0h)
{
    int32_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    bool bVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint32_t uVar9;
    undefined8 unaff_R12;
    uint32_t *puVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801af929;
    var_10h = arg2;
    var_18h = arg3;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (**(int32_t **)(placeholder_0 + 0x18) == 0x10000) {
        puVar10 = (uint32_t *)0x1804af420;
    } else {
        if (**(int32_t **)(placeholder_0 + 0x18) != 0x1ffff) {
            iVar6 = *(int32_t *)(placeholder_0 + 0x48);
            *(int32_t *)arg3 = iVar6;
            *(int32_t *)arg2 = iVar6;
            return -(uint32_t)(placeholder_3 != (uint32_t *)0x0) & 0xc0103;
        }
        puVar10 = (uint32_t *)0x1804af4b0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    bVar4 = true;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R12;
    uVar9 = 0;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R15;
    *(undefined4 *)((int64_t)&arg_58h + iVar7) = 0;
    *(int32_t *)arg2 = 0;
    if (placeholder_3 != (uint32_t *)0x0) {
        *placeholder_3 = 0;
    }
    if (*puVar10 != 0) {
        *(undefined8 *)((int64_t)&arg_70h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        uVar11 = uVar9;
        do {
            pcVar2 = *(code **)(puVar10 + 2);
            uVar12 = uVar9;
            if (pcVar2 == (code *)0x0) {
code_r0x0001801af9be:
                bVar4 = true;
code_r0x0001801af9c3:
                iVar6 = *(int32_t *)((int64_t)&arg_58h + iVar7);
                uVar11 = uVar12;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801afa11;
                piVar8 = (int32_t *)(*pcVar2)();
                uVar12 = uVar11;
                if ((bVar4) && (uVar11 == 0)) {
                    uVar12 = *puVar10;
                }
                iVar6 = *(int32_t *)(placeholder_0 + 0x9b4);
                iVar1 = *piVar8;
                if ((iVar6 != 0) && (iVar1 != iVar6)) {
                    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                        iVar5 = 1;
                        if (iVar1 < iVar6) {
                            iVar5 = -1;
                        }
                    } else {
                        if (iVar6 == 0x100) {
                            iVar6 = 0xff00;
                        }
                        iVar3 = iVar1;
                        if (iVar1 == 0x100) {
                            iVar3 = 0xff00;
                        }
                        iVar5 = 1;
                        if (iVar6 < iVar3) {
                            iVar5 = -1;
                        }
                    }
                    if (iVar5 < 0) goto code_r0x0001801af9be;
                }
                *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801afa9b;
                iVar6 = fcn.1801a2690(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                      *(int64_t *)(&stack0x00000050 + iVar7));
                if (iVar6 == 0) goto code_r0x0001801af9be;
                if (*(int32_t *)(placeholder_0 + 0x9b8) != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801afab9;
                    iVar6 = fcn.1801afd90(placeholder_0, iVar1);
                    if (0 < iVar6) goto code_r0x0001801af9be;
                }
                if (((*(uint64_t *)(placeholder_0 + 0x9a8) & *(uint64_t *)(piVar8 + 2)) != 0) ||
                   (((*(uint8_t *)(piVar8 + 1) & 2) != 0 &&
                    ((*(uint32_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x1c) & 0x30000) != 0))))
                goto code_r0x0001801af9be;
                if (!bVar4) {
                    **(int32_t **)((int64_t)&arg_60h + iVar7) = *piVar8;
                    goto code_r0x0001801af9c3;
                }
                if ((placeholder_3 != (uint32_t *)0x0) && (uVar12 != 0)) {
                    *placeholder_3 = uVar12;
                }
                iVar6 = *piVar8;
                *(int32_t *)((int64_t)&arg_58h + iVar7) = iVar6;
                **(int32_t **)((int64_t)&arg_60h + iVar7) = iVar6;
                uVar11 = uVar12;
                bVar4 = false;
            }
            puVar10 = puVar10 + 6;
        } while (*puVar10 != 0);
        arg3 = *(int64_t *)((int64_t)&arg_68h + iVar7);
    }
    *(int32_t *)arg3 = iVar6;
    if (iVar6 == 0) {
        uVar9 = 0xbf;
    }
    return uVar9;
}

