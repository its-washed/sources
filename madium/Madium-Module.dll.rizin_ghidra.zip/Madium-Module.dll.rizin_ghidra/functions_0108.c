// Chunk 108 - 50 functions

// ============================================================
// Function: FUN_1801767f0
// Address: 0x1801767f0
// Size: 141 bytes
// ============================================================
void fcn.1801767f0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    func_0x000180176880();
    piVar1 = *(int64_t **)(arg1 + 0x98);
    if (piVar1 == (int64_t *)0x0) {
        if (*(int64_t *)(arg1 + 0x48) == 0) {
            piVar1 = (int64_t *)0x0;
        } else {
            piVar1 = (int64_t *)(arg1 + 0x38);
            if (0xf < *(uint64_t *)(arg1 + 0x50)) {
                piVar1 = (int64_t *)*piVar1;
            }
            *(int64_t **)(arg1 + 0x98) = piVar1;
            *(int64_t *)(arg1 + 0xa0) = *(int64_t *)(arg1 + 0x48);
        }
    }
    if (*(int64_t *)(arg1 + 0xa0) == 0) {
        func_0x000180177750(arg1);
    }
    if ((piVar1 != (int64_t *)0x0) && (*(int64_t *)(arg1 + 0xa0) != 0)) {
        func_0x00018000d970(arg2, piVar1);
    }
    return;
}

// ============================================================
// Function: FUN_180176880
// Address: 0x180176880
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180176880(int64_t arg1, int64_t arg_78h)
{
    char cVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined8 *puVar14;
    undefined8 *puVar15;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_20;
    int64_t var_18h;
    
    puVar12 = auStack_58;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    puVar13 = auStack_58;
    if (*(int64_t *)(arg1 + 0x48) != 0) goto code_r0x000180176b21;
    func_0x000180177b70();
    iVar4 = *(int32_t *)(arg1 + 0xa8);
    if (iVar4 == 0xca) {
        uVar6 = func_0x0001801881a0(&var_38h, arg1 + 0xb0, 2);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        if (uStack_20 + 1 < 0x1000) goto code_r0x000180176b17;
        iVar5 = *(int64_t *)(var_38h + -8);
        iVar7 = var_38h - iVar5;
joined_r0x000180176b05:
        puVar12 = auStack_58;
        if (0x1f < iVar7 - 8U) {
code_r0x000180176b0d:
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar12 = auStack_50;
        }
    } else if (iVar4 == 0xcc) {
        uVar6 = func_0x000180188970(&var_38h, arg1 + 0xd0);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    } else {
        puVar13 = auStack_58;
        if (iVar4 != 0x12d) goto code_r0x000180176b21;
        var_28h = 0xc;
        uStack_20 = 0xf;
        var_30h._0_4_ = 0x65707954;
        var_38h = 0x2d746e65746e6f43;
        var_30h._4_4_ = 0;
        puVar14 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
        cVar1 = *(char *)((int64_t)puVar14 + 0x19);
        puVar15 = *(undefined8 **)(arg1 + 0x10);
        while (cVar1 == '\0') {
            piVar9 = puVar14 + 4;
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            if (0xf < (uint64_t)puVar14[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            iVar4 = func_0x00018047b6d0(piVar9, piVar8);
            if (iVar4 < 0) {
                puVar11 = (undefined8 *)puVar14[2];
                puVar14 = puVar15;
            } else {
                puVar11 = (undefined8 *)*puVar14;
            }
            puVar15 = puVar14;
            puVar14 = puVar11;
            cVar1 = *(char *)((int64_t)puVar11 + 0x19);
        }
        if (*(char *)((int64_t)puVar15 + 0x19) == '\0') {
            piVar9 = puVar15 + 4;
            if (0xf < (uint64_t)puVar15[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            iVar4 = func_0x00018047b6d0(piVar8, piVar9);
            if (iVar4 < 0) goto code_r0x000180176987;
        } else {
code_r0x000180176987:
            puVar15 = *(undefined8 **)(arg1 + 0x10);
        }
        if (0xf < uStack_20) {
            uVar10 = uStack_20 + 1;
            iVar5 = var_38h;
            if (uVar10 < 0x1000) {
code_r0x0001801769c3:
                func_0x000180459c3c(iVar5, uVar10);
                goto code_r0x0001801769c8;
            }
            if ((var_38h - *(int64_t *)(var_38h + -8)) - 8U < 0x20) {
                uVar10 = uStack_20 + 0x28;
                iVar5 = *(int64_t *)(var_38h + -8);
                goto code_r0x0001801769c3;
            }
            goto code_r0x000180176b0d;
        }
code_r0x0001801769c8:
        var_28h = 0;
        uStack_20 = 0xf;
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffffc9;
        _var_38h = auVar3 << 8;
        puVar13 = auStack_58;
        if (puVar15 == *(undefined8 **)(arg1 + 0x10)) goto code_r0x000180176b21;
        piVar9 = puVar15 + 8;
        if (0xf < (uint64_t)puVar15[0xb]) {
            piVar9 = (int64_t *)*piVar9;
        }
        iVar5 = func_0x00018045bb90(piVar9, 0x1804a6298);
        puVar13 = auStack_58;
        if (iVar5 == 0) goto code_r0x000180176b21;
        uVar6 = func_0x000180188250(&var_38h, arg1 + 0xc0, iVar5 + 9);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    }
code_r0x000180176b17:
    *(undefined8 *)(puVar12 + -8) = 0x180176b1c;
    func_0x000180459c3c(iVar5);
    puVar13 = puVar12;
code_r0x000180176b21:
    *(undefined8 *)(puVar13 + -8) = 0x180176b2d;
    func_0x000180459870(var_18h ^ (uint64_t)puVar13);
    return;
}

// ============================================================
// Function: FUN_1801768a9
// Address: 0x1801768a9
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180176880(int64_t arg1, int64_t arg_78h)
{
    char cVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined8 *puVar14;
    undefined8 *puVar15;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_20;
    int64_t var_18h;
    
    puVar12 = auStack_58;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    puVar13 = auStack_58;
    if (*(int64_t *)(arg1 + 0x48) != 0) goto code_r0x000180176b21;
    func_0x000180177b70();
    iVar4 = *(int32_t *)(arg1 + 0xa8);
    if (iVar4 == 0xca) {
        uVar6 = func_0x0001801881a0(&var_38h, arg1 + 0xb0, 2);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        if (uStack_20 + 1 < 0x1000) goto code_r0x000180176b17;
        iVar5 = *(int64_t *)(var_38h + -8);
        iVar7 = var_38h - iVar5;
joined_r0x000180176b05:
        puVar12 = auStack_58;
        if (0x1f < iVar7 - 8U) {
code_r0x000180176b0d:
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar12 = auStack_50;
        }
    } else if (iVar4 == 0xcc) {
        uVar6 = func_0x000180188970(&var_38h, arg1 + 0xd0);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    } else {
        puVar13 = auStack_58;
        if (iVar4 != 0x12d) goto code_r0x000180176b21;
        var_28h = 0xc;
        uStack_20 = 0xf;
        var_30h._0_4_ = 0x65707954;
        var_38h = 0x2d746e65746e6f43;
        var_30h._4_4_ = 0;
        puVar14 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
        cVar1 = *(char *)((int64_t)puVar14 + 0x19);
        puVar15 = *(undefined8 **)(arg1 + 0x10);
        while (cVar1 == '\0') {
            piVar9 = puVar14 + 4;
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            if (0xf < (uint64_t)puVar14[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            iVar4 = func_0x00018047b6d0(piVar9, piVar8);
            if (iVar4 < 0) {
                puVar11 = (undefined8 *)puVar14[2];
                puVar14 = puVar15;
            } else {
                puVar11 = (undefined8 *)*puVar14;
            }
            puVar15 = puVar14;
            puVar14 = puVar11;
            cVar1 = *(char *)((int64_t)puVar11 + 0x19);
        }
        if (*(char *)((int64_t)puVar15 + 0x19) == '\0') {
            piVar9 = puVar15 + 4;
            if (0xf < (uint64_t)puVar15[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            iVar4 = func_0x00018047b6d0(piVar8, piVar9);
            if (iVar4 < 0) goto code_r0x000180176987;
        } else {
code_r0x000180176987:
            puVar15 = *(undefined8 **)(arg1 + 0x10);
        }
        if (0xf < uStack_20) {
            uVar10 = uStack_20 + 1;
            iVar5 = var_38h;
            if (uVar10 < 0x1000) {
code_r0x0001801769c3:
                func_0x000180459c3c(iVar5, uVar10);
                goto code_r0x0001801769c8;
            }
            if ((var_38h - *(int64_t *)(var_38h + -8)) - 8U < 0x20) {
                uVar10 = uStack_20 + 0x28;
                iVar5 = *(int64_t *)(var_38h + -8);
                goto code_r0x0001801769c3;
            }
            goto code_r0x000180176b0d;
        }
code_r0x0001801769c8:
        var_28h = 0;
        uStack_20 = 0xf;
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffffc9;
        _var_38h = auVar3 << 8;
        puVar13 = auStack_58;
        if (puVar15 == *(undefined8 **)(arg1 + 0x10)) goto code_r0x000180176b21;
        piVar9 = puVar15 + 8;
        if (0xf < (uint64_t)puVar15[0xb]) {
            piVar9 = (int64_t *)*piVar9;
        }
        iVar5 = func_0x00018045bb90(piVar9, 0x1804a6298);
        puVar13 = auStack_58;
        if (iVar5 == 0) goto code_r0x000180176b21;
        uVar6 = func_0x000180188250(&var_38h, arg1 + 0xc0, iVar5 + 9);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    }
code_r0x000180176b17:
    *(undefined8 *)(puVar12 + -8) = 0x180176b1c;
    func_0x000180459c3c(iVar5);
    puVar13 = puVar12;
code_r0x000180176b21:
    *(undefined8 *)(puVar13 + -8) = 0x180176b2d;
    func_0x000180459870(var_18h ^ (uint64_t)puVar13);
    return;
}

// ============================================================
// Function: FUN_18017690c
// Address: 0x18017690c
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180176880(int64_t arg1, int64_t arg_78h)
{
    char cVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined8 *puVar14;
    undefined8 *puVar15;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_20;
    int64_t var_18h;
    
    puVar12 = auStack_58;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    puVar13 = auStack_58;
    if (*(int64_t *)(arg1 + 0x48) != 0) goto code_r0x000180176b21;
    func_0x000180177b70();
    iVar4 = *(int32_t *)(arg1 + 0xa8);
    if (iVar4 == 0xca) {
        uVar6 = func_0x0001801881a0(&var_38h, arg1 + 0xb0, 2);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        if (uStack_20 + 1 < 0x1000) goto code_r0x000180176b17;
        iVar5 = *(int64_t *)(var_38h + -8);
        iVar7 = var_38h - iVar5;
joined_r0x000180176b05:
        puVar12 = auStack_58;
        if (0x1f < iVar7 - 8U) {
code_r0x000180176b0d:
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar12 = auStack_50;
        }
    } else if (iVar4 == 0xcc) {
        uVar6 = func_0x000180188970(&var_38h, arg1 + 0xd0);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    } else {
        puVar13 = auStack_58;
        if (iVar4 != 0x12d) goto code_r0x000180176b21;
        var_28h = 0xc;
        uStack_20 = 0xf;
        var_30h._0_4_ = 0x65707954;
        var_38h = 0x2d746e65746e6f43;
        var_30h._4_4_ = 0;
        puVar14 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
        cVar1 = *(char *)((int64_t)puVar14 + 0x19);
        puVar15 = *(undefined8 **)(arg1 + 0x10);
        while (cVar1 == '\0') {
            piVar9 = puVar14 + 4;
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            if (0xf < (uint64_t)puVar14[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            iVar4 = func_0x00018047b6d0(piVar9, piVar8);
            if (iVar4 < 0) {
                puVar11 = (undefined8 *)puVar14[2];
                puVar14 = puVar15;
            } else {
                puVar11 = (undefined8 *)*puVar14;
            }
            puVar15 = puVar14;
            puVar14 = puVar11;
            cVar1 = *(char *)((int64_t)puVar11 + 0x19);
        }
        if (*(char *)((int64_t)puVar15 + 0x19) == '\0') {
            piVar9 = puVar15 + 4;
            if (0xf < (uint64_t)puVar15[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            iVar4 = func_0x00018047b6d0(piVar8, piVar9);
            if (iVar4 < 0) goto code_r0x000180176987;
        } else {
code_r0x000180176987:
            puVar15 = *(undefined8 **)(arg1 + 0x10);
        }
        if (0xf < uStack_20) {
            uVar10 = uStack_20 + 1;
            iVar5 = var_38h;
            if (uVar10 < 0x1000) {
code_r0x0001801769c3:
                func_0x000180459c3c(iVar5, uVar10);
                goto code_r0x0001801769c8;
            }
            if ((var_38h - *(int64_t *)(var_38h + -8)) - 8U < 0x20) {
                uVar10 = uStack_20 + 0x28;
                iVar5 = *(int64_t *)(var_38h + -8);
                goto code_r0x0001801769c3;
            }
            goto code_r0x000180176b0d;
        }
code_r0x0001801769c8:
        var_28h = 0;
        uStack_20 = 0xf;
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffffc9;
        _var_38h = auVar3 << 8;
        puVar13 = auStack_58;
        if (puVar15 == *(undefined8 **)(arg1 + 0x10)) goto code_r0x000180176b21;
        piVar9 = puVar15 + 8;
        if (0xf < (uint64_t)puVar15[0xb]) {
            piVar9 = (int64_t *)*piVar9;
        }
        iVar5 = func_0x00018045bb90(piVar9, 0x1804a6298);
        puVar13 = auStack_58;
        if (iVar5 == 0) goto code_r0x000180176b21;
        uVar6 = func_0x000180188250(&var_38h, arg1 + 0xc0, iVar5 + 9);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    }
code_r0x000180176b17:
    *(undefined8 *)(puVar12 + -8) = 0x180176b1c;
    func_0x000180459c3c(iVar5);
    puVar13 = puVar12;
code_r0x000180176b21:
    *(undefined8 *)(puVar13 + -8) = 0x180176b2d;
    func_0x000180459870(var_18h ^ (uint64_t)puVar13);
    return;
}

// ============================================================
// Function: FUN_180176962
// Address: 0x180176962
// Size: 447 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180176880(int64_t arg1, int64_t arg_78h)
{
    char cVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined8 *puVar14;
    undefined8 *puVar15;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_20;
    int64_t var_18h;
    
    puVar12 = auStack_58;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    puVar13 = auStack_58;
    if (*(int64_t *)(arg1 + 0x48) != 0) goto code_r0x000180176b21;
    func_0x000180177b70();
    iVar4 = *(int32_t *)(arg1 + 0xa8);
    if (iVar4 == 0xca) {
        uVar6 = func_0x0001801881a0(&var_38h, arg1 + 0xb0, 2);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        if (uStack_20 + 1 < 0x1000) goto code_r0x000180176b17;
        iVar5 = *(int64_t *)(var_38h + -8);
        iVar7 = var_38h - iVar5;
joined_r0x000180176b05:
        puVar12 = auStack_58;
        if (0x1f < iVar7 - 8U) {
code_r0x000180176b0d:
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar12 = auStack_50;
        }
    } else if (iVar4 == 0xcc) {
        uVar6 = func_0x000180188970(&var_38h, arg1 + 0xd0);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    } else {
        puVar13 = auStack_58;
        if (iVar4 != 0x12d) goto code_r0x000180176b21;
        var_28h = 0xc;
        uStack_20 = 0xf;
        var_30h._0_4_ = 0x65707954;
        var_38h = 0x2d746e65746e6f43;
        var_30h._4_4_ = 0;
        puVar14 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
        cVar1 = *(char *)((int64_t)puVar14 + 0x19);
        puVar15 = *(undefined8 **)(arg1 + 0x10);
        while (cVar1 == '\0') {
            piVar9 = puVar14 + 4;
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            if (0xf < (uint64_t)puVar14[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            iVar4 = func_0x00018047b6d0(piVar9, piVar8);
            if (iVar4 < 0) {
                puVar11 = (undefined8 *)puVar14[2];
                puVar14 = puVar15;
            } else {
                puVar11 = (undefined8 *)*puVar14;
            }
            puVar15 = puVar14;
            puVar14 = puVar11;
            cVar1 = *(char *)((int64_t)puVar11 + 0x19);
        }
        if (*(char *)((int64_t)puVar15 + 0x19) == '\0') {
            piVar9 = puVar15 + 4;
            if (0xf < (uint64_t)puVar15[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            iVar4 = func_0x00018047b6d0(piVar8, piVar9);
            if (iVar4 < 0) goto code_r0x000180176987;
        } else {
code_r0x000180176987:
            puVar15 = *(undefined8 **)(arg1 + 0x10);
        }
        if (0xf < uStack_20) {
            uVar10 = uStack_20 + 1;
            iVar5 = var_38h;
            if (uVar10 < 0x1000) {
code_r0x0001801769c3:
                func_0x000180459c3c(iVar5, uVar10);
                goto code_r0x0001801769c8;
            }
            if ((var_38h - *(int64_t *)(var_38h + -8)) - 8U < 0x20) {
                uVar10 = uStack_20 + 0x28;
                iVar5 = *(int64_t *)(var_38h + -8);
                goto code_r0x0001801769c3;
            }
            goto code_r0x000180176b0d;
        }
code_r0x0001801769c8:
        var_28h = 0;
        uStack_20 = 0xf;
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffffc9;
        _var_38h = auVar3 << 8;
        puVar13 = auStack_58;
        if (puVar15 == *(undefined8 **)(arg1 + 0x10)) goto code_r0x000180176b21;
        piVar9 = puVar15 + 8;
        if (0xf < (uint64_t)puVar15[0xb]) {
            piVar9 = (int64_t *)*piVar9;
        }
        iVar5 = func_0x00018045bb90(piVar9, 0x1804a6298);
        puVar13 = auStack_58;
        if (iVar5 == 0) goto code_r0x000180176b21;
        uVar6 = func_0x000180188250(&var_38h, arg1 + 0xc0, iVar5 + 9);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    }
code_r0x000180176b17:
    *(undefined8 *)(puVar12 + -8) = 0x180176b1c;
    func_0x000180459c3c(iVar5);
    puVar13 = puVar12;
code_r0x000180176b21:
    *(undefined8 *)(puVar13 + -8) = 0x180176b2d;
    func_0x000180459870(var_18h ^ (uint64_t)puVar13);
    return;
}

// ============================================================
// Function: FUN_180176b21
// Address: 0x180176b21
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180176880(int64_t arg1, int64_t arg_78h)
{
    char cVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined8 *puVar14;
    undefined8 *puVar15;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_20;
    int64_t var_18h;
    
    puVar12 = auStack_58;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    puVar13 = auStack_58;
    if (*(int64_t *)(arg1 + 0x48) != 0) goto code_r0x000180176b21;
    func_0x000180177b70();
    iVar4 = *(int32_t *)(arg1 + 0xa8);
    if (iVar4 == 0xca) {
        uVar6 = func_0x0001801881a0(&var_38h, arg1 + 0xb0, 2);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        if (uStack_20 + 1 < 0x1000) goto code_r0x000180176b17;
        iVar5 = *(int64_t *)(var_38h + -8);
        iVar7 = var_38h - iVar5;
joined_r0x000180176b05:
        puVar12 = auStack_58;
        if (0x1f < iVar7 - 8U) {
code_r0x000180176b0d:
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar12 = auStack_50;
        }
    } else if (iVar4 == 0xcc) {
        uVar6 = func_0x000180188970(&var_38h, arg1 + 0xd0);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    } else {
        puVar13 = auStack_58;
        if (iVar4 != 0x12d) goto code_r0x000180176b21;
        var_28h = 0xc;
        uStack_20 = 0xf;
        var_30h._0_4_ = 0x65707954;
        var_38h = 0x2d746e65746e6f43;
        var_30h._4_4_ = 0;
        puVar14 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
        cVar1 = *(char *)((int64_t)puVar14 + 0x19);
        puVar15 = *(undefined8 **)(arg1 + 0x10);
        while (cVar1 == '\0') {
            piVar9 = puVar14 + 4;
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            if (0xf < (uint64_t)puVar14[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            iVar4 = func_0x00018047b6d0(piVar9, piVar8);
            if (iVar4 < 0) {
                puVar11 = (undefined8 *)puVar14[2];
                puVar14 = puVar15;
            } else {
                puVar11 = (undefined8 *)*puVar14;
            }
            puVar15 = puVar14;
            puVar14 = puVar11;
            cVar1 = *(char *)((int64_t)puVar11 + 0x19);
        }
        if (*(char *)((int64_t)puVar15 + 0x19) == '\0') {
            piVar9 = puVar15 + 4;
            if (0xf < (uint64_t)puVar15[7]) {
                piVar9 = (int64_t *)*piVar9;
            }
            piVar8 = &var_38h;
            if (0xf < uStack_20) {
                piVar8 = (int64_t *)var_38h;
            }
            iVar4 = func_0x00018047b6d0(piVar8, piVar9);
            if (iVar4 < 0) goto code_r0x000180176987;
        } else {
code_r0x000180176987:
            puVar15 = *(undefined8 **)(arg1 + 0x10);
        }
        if (0xf < uStack_20) {
            uVar10 = uStack_20 + 1;
            iVar5 = var_38h;
            if (uVar10 < 0x1000) {
code_r0x0001801769c3:
                func_0x000180459c3c(iVar5, uVar10);
                goto code_r0x0001801769c8;
            }
            if ((var_38h - *(int64_t *)(var_38h + -8)) - 8U < 0x20) {
                uVar10 = uStack_20 + 0x28;
                iVar5 = *(int64_t *)(var_38h + -8);
                goto code_r0x0001801769c3;
            }
            goto code_r0x000180176b0d;
        }
code_r0x0001801769c8:
        var_28h = 0;
        uStack_20 = 0xf;
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffffc9;
        _var_38h = auVar3 << 8;
        puVar13 = auStack_58;
        if (puVar15 == *(undefined8 **)(arg1 + 0x10)) goto code_r0x000180176b21;
        piVar9 = puVar15 + 8;
        if (0xf < (uint64_t)puVar15[0xb]) {
            piVar9 = (int64_t *)*piVar9;
        }
        iVar5 = func_0x00018045bb90(piVar9, 0x1804a6298);
        puVar13 = auStack_58;
        if (iVar5 == 0) goto code_r0x000180176b21;
        uVar6 = func_0x000180188250(&var_38h, arg1 + 0xc0, iVar5 + 9);
        func_0x000180012c10(arg1 + 0x38, uVar6);
        puVar13 = auStack_58;
        if (uStack_20 < 0x10) goto code_r0x000180176b21;
        iVar5 = var_38h;
        puVar12 = auStack_58;
        if (0xfff < uStack_20 + 1) {
            iVar5 = *(int64_t *)(var_38h + -8);
            iVar7 = var_38h - iVar5;
            goto joined_r0x000180176b05;
        }
    }
code_r0x000180176b17:
    *(undefined8 *)(puVar12 + -8) = 0x180176b1c;
    func_0x000180459c3c(iVar5);
    puVar13 = puVar12;
code_r0x000180176b21:
    *(undefined8 *)(puVar13 + -8) = 0x180176b2d;
    func_0x000180459870(var_18h ^ (uint64_t)puVar13);
    return;
}

// ============================================================
// Function: FUN_180176b40
// Address: 0x180176b40
// Size: 1408 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_11fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_107h

void fcn.180176b40(int64_t arg1, int64_t arg2)
{
    undefined2 *puVar1;
    char cVar2;
    code *pcVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined auVar6 [16];
    int32_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    undefined8 *puVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    undefined8 *puVar16;
    int64_t ******ppppppiVar17;
    int64_t iVar18;
    undefined8 *puVar19;
    uint64_t uVar20;
    uint64_t uVar21;
    undefined *puVar22;
    int64_t *piVar23;
    int64_t ******ppppppiVar24;
    int64_t **unaff_R15;
    int64_t var_18h;
    undefined8 uStack_170;
    undefined auStack_168 [8];
    undefined auStack_160 [16];
    int64_t var_150h;
    int64_t *piStack_148;
    int64_t var_138h;
    undefined auStack_130 [8];
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    undefined auStack_110 [5];
    undefined auStack_10b [3];
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t ******ppppppiStack_f0;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    uint64_t uStack_d0;
    int64_t **ppiStack_c0;
    int64_t **ppiStack_b8;
    int64_t *piStack_b0;
    int64_t iStack_a8;
    int64_t **ppiStack_a0;
    undefined *apuStack_98 [4];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    uint64_t uStack_50;
    int64_t var_48h;
    int64_t var_40h;
    
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)apuStack_98;
    ppiStack_a0 = (int64_t **)0x180176b74;
    var_68h = arg1;
    func_0x000180177b70();
    ppiStack_a0 = (int64_t **)0x180176b7c;
    func_0x000180177750(arg1);
    ppiVar15 = (int64_t **)**(int64_t ***)(arg1 + 0x10);
    cVar2 = *(char *)((int64_t)ppiVar15 + 0x19);
    while (cVar2 == '\0') {
        pcVar8 = (char *)arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            pcVar8 = *(char **)arg2;
        }
        if (*pcVar8 != ':') {
            if (ppiVar15[7] < (int64_t *)0x10) {
                ppiVar14 = ppiVar15 + 4;
            } else {
                ppiVar14 = (int64_t **)ppiVar15[4];
            }
            ppiStack_a0 = (int64_t **)0x180176bc3;
            func_0x00018000d970(arg2, ppiVar14, ppiVar15[6]);
            iVar18 = *(int64_t *)(arg2 + 0x10);
            if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 2) {
                var_78h = 2;
                ppiStack_a0 = (int64_t **)0x180176c1f;
                func_0x00018000ee80(arg2, 2, 0, 0x1805aadb4);
            } else {
                *(int64_t *)(arg2 + 0x10) = iVar18 + 2;
                iVar9 = arg2;
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    iVar9 = *(int64_t *)arg2;
                }
                *(undefined2 *)(iVar18 + iVar9) = 0x203a;
                *(undefined *)(iVar18 + 2 + iVar9) = 0;
            }
            unaff_R15 = ppiVar15 + 8;
            ppiVar14 = unaff_R15;
            if ((int64_t *)0xf < ppiVar15[0xb]) {
                ppiVar14 = (int64_t **)*unaff_R15;
            }
            ppiVar10 = ppiVar15 + 10;
            if (*ppiVar10 == (int64_t *)0x0) {
code_r0x000180176c68:
                ppiVar14 = unaff_R15;
                if ((int64_t *)0xf < ppiVar15[0xb]) {
                    ppiVar14 = (int64_t **)*unaff_R15;
                }
                if (*ppiVar10 != (int64_t *)0x0) {
                    iVar18 = (int64_t)ppiVar14 + (int64_t)*ppiVar10;
                    ppiStack_a0 = (int64_t **)0x180176c9f;
                    iVar9 = func_0x0001804581c0(ppiVar14, iVar18, 0x1805ab2a0, 1);
                    if ((iVar9 != iVar18) && (iVar9 - (int64_t)ppiVar14 != -1)) goto code_r0x000180176cb5;
                }
                if ((int64_t *)0xf < ppiVar15[0xb]) {
                    unaff_R15 = (int64_t **)*unaff_R15;
                }
                ppiStack_a0 = (int64_t **)0x180176e6b;
                func_0x00018000d970(arg2, unaff_R15, *ppiVar10);
            } else {
                iVar18 = (int64_t)*ppiVar10 + (int64_t)ppiVar14;
                ppiStack_a0 = (int64_t **)0x180176c5a;
                iVar9 = func_0x0001804581c0(ppiVar14, iVar18, 0x1804a6320, 1);
                if ((iVar9 == iVar18) || (iVar9 - (int64_t)ppiVar14 == -1)) goto code_r0x000180176c68;
code_r0x000180176cb5:
                uStack_50 = 0;
                var_48h = 0xf;
                stack0xffffffffffffffa1 = SUB1615(ZEXT816(0), 1);
                auVar4[15] = 0;
                auVar4._0_15_ = stack0xffffffffffffffa1;
                _var_60h = auVar4 << 8;
                piVar23 = (int64_t *)0x0;
                if (ppiVar15[10] != (int64_t *)0x0) {
                    do {
                        uVar20 = uStack_50;
                        piVar11 = ppiVar15[0xb];
                        ppiVar10 = unaff_R15;
                        if ((int64_t *)0xf < piVar11) {
                            ppiVar10 = (int64_t **)*unaff_R15;
                        }
                        if (*(char *)((int64_t)ppiVar10 + (int64_t)piVar23) == '\r') {
                            if (var_48h - uStack_50 < 2) {
                                uVar12 = 0x18062037c;
code_r0x000180176d86:
                                var_78h = 2;
                                ppiStack_a0 = (int64_t **)0x180176d9c;
                                func_0x00018000ee80(&var_60h, 2, 0, uVar12);
                            } else {
                                piVar11 = &var_60h;
                                if (0xf < (uint64_t)var_48h) {
                                    piVar11 = (int64_t *)var_60h;
                                }
                                puVar1 = (undefined2 *)((int64_t)piVar11 + uStack_50);
                                uStack_50 = uStack_50 + 2;
                                *puVar1 = 0x725c;
                                *(undefined *)((int64_t)piVar11 + uVar20 + 2) = 0;
                            }
                        } else {
                            ppiVar10 = ppiVar15 + 8;
                            if ((int64_t *)0xf < piVar11) {
                                ppiVar10 = (int64_t **)*ppiVar10;
                            }
                            if (*(char *)((int64_t)ppiVar10 + (int64_t)piVar23) == '\n') {
                                if (var_48h - uStack_50 < 2) {
                                    uVar12 = 0x180620378;
                                    goto code_r0x000180176d86;
                                }
                                piVar11 = &var_60h;
                                if (0xf < (uint64_t)var_48h) {
                                    piVar11 = (int64_t *)var_60h;
                                }
                                puVar1 = (undefined2 *)((int64_t)piVar11 + uStack_50);
                                uStack_50 = uStack_50 + 2;
                                *puVar1 = 0x6e5c;
                                *(undefined *)((int64_t)piVar11 + uVar20 + 2) = 0;
                            } else {
                                ppiVar10 = ppiVar15 + 8;
                                if ((int64_t *)0xf < piVar11) {
                                    ppiVar10 = (int64_t **)*ppiVar10;
                                }
                                if (uStack_50 < (uint64_t)var_48h) {
                                    piVar11 = &var_60h;
                                    if (0xf < (uint64_t)var_48h) {
                                        piVar11 = (int64_t *)var_60h;
                                    }
                                    puVar22 = (undefined *)((int64_t)piVar11 + uStack_50);
                                    uStack_50 = uStack_50 + 1;
                                    *puVar22 = *(undefined *)((int64_t)ppiVar10 + (int64_t)piVar23);
                                    *(undefined *)((int64_t)piVar11 + uVar20 + 1) = 0;
                                } else {
                                    ppiStack_a0 = (int64_t **)0x180176dea;
                                    func_0x00018000f010(&var_60h, 1, 0, 
                                                        *(undefined *)((int64_t)ppiVar10 + (int64_t)piVar23));
                                }
                            }
                        }
                        piVar23 = (int64_t *)((int64_t)piVar23 + 1);
                    } while (piVar23 < ppiVar15[10]);
                }
                piVar11 = &var_60h;
                if (0xf < (uint64_t)var_48h) {
                    piVar11 = (int64_t *)var_60h;
                }
                ppiStack_a0 = (int64_t **)0x180176e14;
                func_0x00018000d970(arg2, piVar11);
                if (0xf < (uint64_t)var_48h) {
                    uVar20 = var_48h + 1;
                    iVar18 = var_60h;
                    if (0xfff < uVar20) {
                        iVar18 = *(int64_t *)(var_60h + -8);
                        if (0x1f < (var_60h - iVar18) - 8U) goto code_r0x0001801770b9;
                        uVar20 = var_48h + 0x28;
                    }
                    ppiStack_a0 = (int64_t **)0x180176e50;
                    func_0x000180459c3c(iVar18, uVar20);
                }
            }
            iVar18 = *(int64_t *)(arg2 + 0x10);
            if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 2) {
                var_78h = 2;
                ppiStack_a0 = (int64_t **)0x180176ec7;
                func_0x00018000ee80(arg2, 2, 0, 0x180644f68);
            } else {
                *(int64_t *)(arg2 + 0x10) = iVar18 + 2;
                iVar9 = arg2;
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    iVar9 = *(int64_t *)arg2;
                }
                *(undefined2 *)(iVar18 + iVar9) = 0xa0d;
                *(undefined *)(iVar18 + 2 + iVar9) = 0;
            }
        }
        ppiVar14 = (int64_t **)ppiVar15[2];
        if (*(char *)((int64_t)ppiVar14 + 0x19) == '\0') {
            cVar2 = *(char *)((int64_t)*ppiVar14 + 0x19);
            ppiVar15 = ppiVar14;
            ppiVar14 = (int64_t **)*ppiVar14;
            while (cVar2 == '\0') {
                cVar2 = *(char *)((int64_t)*ppiVar14 + 0x19);
                ppiVar15 = ppiVar14;
                ppiVar14 = (int64_t **)*ppiVar14;
            }
        } else {
            cVar2 = *(char *)((int64_t)ppiVar15[1] + 0x19);
            ppiVar10 = (int64_t **)ppiVar15[1];
            ppiVar14 = ppiVar15;
            while ((ppiVar15 = ppiVar10, cVar2 == '\0' && (ppiVar14 == (int64_t **)ppiVar15[2]))) {
                cVar2 = *(char *)((int64_t)ppiVar15[1] + 0x19);
                ppiVar10 = (int64_t **)ppiVar15[1];
                ppiVar14 = ppiVar15;
            }
        }
        arg1 = var_68h;
        cVar2 = *(char *)((int64_t)ppiVar15 + 0x19);
    }
    piVar23 = (int64_t *)0x1804a6330;
    if (*(int32_t *)(arg1 + 8) != 1) {
        piVar23 = (int64_t *)0x1804a6324;
    }
    ppiVar15 = *(int64_t ***)(arg1 + 0x20);
    ppiVar14 = *(int64_t ***)(arg1 + 0x28);
    do {
        if (ppiVar15 == ppiVar14) {
            ppiStack_a0 = (int64_t **)0x1801770a1;
            func_0x000180459870(var_40h ^ (uint64_t)apuStack_98);
            return;
        }
        ppiStack_a0 = (int64_t **)0x180176f5d;
        uVar12 = func_0x000180498cd0(piVar23);
        ppiStack_a0 = (int64_t **)0x180176f6b;
        func_0x00018000d970(arg2, piVar23, uVar12);
        iVar18 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 2) {
            var_78h = 2;
            ppiStack_a0 = (int64_t **)0x180176fc5;
            func_0x00018000ee80(arg2, 2, 0, 0x1805aadb4);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar18 + 2;
            iVar9 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar9 = *(int64_t *)arg2;
            }
            *(undefined2 *)(iVar18 + iVar9) = 0x203a;
            *(undefined *)(iVar18 + 2 + iVar9) = 0;
        }
        ppiStack_a0 = (int64_t **)0x180176fd1;
        puVar13 = (undefined8 *)func_0x000180179d20(ppiVar15, &var_60h);
        puVar19 = puVar13;
        if (0xf < (uint64_t)puVar13[3]) {
            puVar19 = (undefined8 *)*puVar13;
        }
        ppiStack_a0 = (int64_t **)0x180176fed;
        func_0x00018000d970(arg2, puVar19, puVar13[2]);
        if (0xf < (uint64_t)var_48h) {
            uVar20 = var_48h + 1;
            iVar18 = var_60h;
            if (0xfff < uVar20) {
                iVar18 = *(int64_t *)(var_60h + -8);
                if (0x1f < (var_60h - iVar18) - 8U) break;
                uVar20 = var_48h + 0x28;
            }
            ppiStack_a0 = (int64_t **)0x180177029;
            func_0x000180459c3c(iVar18, uVar20);
        }
        iVar18 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 2) {
            var_78h = 2;
            ppiStack_a0 = (int64_t **)0x180177085;
            func_0x00018000ee80(arg2, 2, 0, 0x180644f68);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar18 + 2;
            iVar9 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar9 = *(int64_t *)arg2;
            }
            *(undefined2 *)(iVar18 + iVar9) = 0xa0d;
            *(undefined *)(iVar18 + 2 + iVar9) = 0;
        }
        ppiVar15 = ppiVar15 + 0x18;
    } while( true );
code_r0x0001801770b9:
    iVar18 = 5;
    pcVar3 = (code *)swi(0x29);
    (*pcVar3)();
    uStack_d0 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    var_120h = 0;
    var_118h = 0xf;
    stack0xfffffffffffffed1 = SUB1615(ZEXT816(0), 1);
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xfffffffffffffed1;
    _auStack_130 = auVar5 << 8;
    ppiStack_c0 = unaff_R15;
    ppiStack_b8 = ppiVar14;
    piStack_b0 = piVar23;
    iStack_a8 = arg2;
    ppiStack_a0 = ppiVar15;
    apuStack_98[0] = &stack0xffffffffffffffc8;
    if (*(int64_t *)(iVar18 + 0xf8) == 0) {
code_r0x00018017714a:
        piVar23 = (int64_t *)(iVar18 + 0x108);
        if ((int64_t *)auStack_130 != piVar23) {
            if (0xf < *(uint64_t *)(iVar18 + 0x120)) {
                piVar23 = (int64_t *)*piVar23;
            }
            func_0x00018000f180(auStack_130, piVar23, *(undefined8 *)(iVar18 + 0x118));
        }
        if ((uint64_t)(var_118h - var_120h) < 3) {
            piStack_148 = (int64_t *)0x3;
            func_0x00018000ee80(auStack_130, 3, 0, 0x1804a63dc);
        } else {
            puVar22 = auStack_130;
            if (0xf < (uint64_t)var_118h) {
                puVar22 = (undefined *)auStack_130;
            }
            puVar22 = puVar22 + var_120h;
            var_120h = var_120h + 3;
            func_0x000180498030(puVar22, 0x1804a63dc, 3);
            puVar22[3] = 0;
        }
        if (*(int64_t *)(iVar18 + 0xf8) != 0) {
            ppiVar15 = (int64_t **)(iVar18 + 0xe8);
            ppiVar14 = ppiVar15;
            if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
                ppiVar14 = (int64_t **)*ppiVar15;
            }
            if (*(char *)ppiVar14 == '/') goto code_r0x000180177273;
            if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
                ppiVar15 = (int64_t **)*ppiVar15;
            }
            piVar23 = *(int64_t **)(iVar18 + 0xf8);
            if ((int64_t *)(var_118h - var_120h) < piVar23) {
                piStack_148 = piVar23;
                func_0x00018000ee80(auStack_130, piVar23, 0);
            } else {
                puVar22 = auStack_130;
                if (0xf < (uint64_t)var_118h) {
                    puVar22 = (undefined *)auStack_130;
                }
                puVar22 = puVar22 + var_120h;
                var_120h = (int64_t)piVar23 + var_120h;
                func_0x000180498030(puVar22, ppiVar15, piVar23);
                *(undefined *)((int64_t)piVar23 + (int64_t)puVar22) = 0;
            }
code_r0x000180177518:
            if (*(int64_t *)(iVar18 + 0xf8) == 0) {
code_r0x000180177595:
                if (1 < *(uint64_t *)(iVar18 + 0x160)) {
                    ppiVar15 = (int64_t **)(iVar18 + 0x150);
                    ppiVar14 = ppiVar15;
                    if (0xf < *(uint64_t *)(iVar18 + 0x168)) {
                        ppiVar14 = (int64_t **)*ppiVar15;
                    }
                    if (*(char *)ppiVar14 == '/') {
                        ppiVar14 = ppiVar15;
                        if (0xf < *(uint64_t *)(iVar18 + 0x168)) {
                            ppiVar14 = (int64_t **)*ppiVar15;
                        }
                        goto code_r0x00018017754f;
                    }
                }
                if (*(int64_t *)(iVar18 + 0xf8) == 0) {
                    if ((uint64_t)var_120h < (uint64_t)var_118h) {
                        puVar22 = auStack_130;
                        if (0xf < (uint64_t)var_118h) {
                            puVar22 = (undefined *)auStack_130;
                        }
                        puVar1 = (undefined2 *)(puVar22 + var_120h);
                        var_120h = var_120h + 1;
                        *puVar1 = 0x2f;
                    } else {
                        func_0x00018000f010(auStack_130, 1, 0, 0x2f);
                    }
                }
            } else {
                ppiVar15 = (int64_t **)(iVar18 + 0xe8);
                ppiVar14 = ppiVar15;
                if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
                    ppiVar14 = (int64_t **)*ppiVar15;
                }
                if (*(char *)ppiVar14 != '/') goto code_r0x000180177595;
                ppiVar14 = ppiVar15;
                if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
                    ppiVar14 = (int64_t **)*ppiVar15;
                }
code_r0x00018017754f:
                piVar23 = ppiVar15[2];
                if ((int64_t *)(var_118h - var_120h) < piVar23) {
                    piStack_148 = piVar23;
                    func_0x00018000ee80(auStack_130, piVar23, 0);
                } else {
                    puVar22 = auStack_130;
                    if (0xf < (uint64_t)var_118h) {
                        puVar22 = (undefined *)auStack_130;
                    }
                    puVar22 = puVar22 + var_120h;
                    var_120h = var_120h + (int64_t)piVar23;
                    func_0x000180498030(puVar22, ppiVar14, piVar23);
                    puVar22[(int64_t)piVar23] = 0;
                }
            }
            if ((undefined *)(iVar18 + 0xe8) != auStack_130) {
                puVar22 = auStack_130;
                if (0xf < (uint64_t)var_118h) {
                    puVar22 = (undefined *)auStack_130;
                }
                func_0x00018000f180((undefined *)(iVar18 + 0xe8), puVar22, var_120h);
            }
            goto code_r0x00018017764a;
        }
code_r0x000180177273:
        iVar7 = *(int32_t *)(iVar18 + 0x148);
        if (((iVar7 == 0) || (iVar7 == 0x50)) || (iVar7 == 0x1bb)) {
            var_100h = 4;
            var_f8h = 0xf;
            _auStack_10b = SUB1611(ZEXT816(0), 5);
            auStack_110 = (undefined  [5])0x74736f48;
            puVar19 = (undefined8 *)(*(undefined8 **)(iVar18 + 0x10))[1];
            cVar2 = *(char *)((int64_t)puVar19 + 0x19);
            puVar13 = *(undefined8 **)(iVar18 + 0x10);
            while (cVar2 == '\0') {
                puVar22 = auStack_110;
                if (0xf < (uint64_t)var_f8h) {
                    puVar22 = _auStack_110;
                }
                piVar23 = puVar19 + 4;
                if (0xf < (uint64_t)puVar19[7]) {
                    piVar23 = (int64_t *)*piVar23;
                }
                iVar7 = func_0x00018047b6d0(piVar23, puVar22);
                if (iVar7 < 0) {
                    puVar16 = (undefined8 *)puVar19[2];
                    puVar19 = puVar13;
                } else {
                    puVar16 = (undefined8 *)*puVar19;
                }
                puVar13 = puVar19;
                puVar19 = puVar16;
                cVar2 = *(char *)((int64_t)puVar16 + 0x19);
            }
            if (*(char *)((int64_t)puVar13 + 0x19) == '\0') {
                piVar23 = puVar13 + 4;
                if (0xf < (uint64_t)puVar13[7]) {
                    piVar23 = (int64_t *)*piVar23;
                }
                puVar22 = auStack_110;
                if (0xf < (uint64_t)var_f8h) {
                    puVar22 = _auStack_110;
                }
                iVar7 = func_0x00018047b6d0(puVar22, piVar23);
                if (iVar7 < 0) goto code_r0x000180177402;
            } else {
code_r0x000180177402:
                puVar13 = *(undefined8 **)(iVar18 + 0x10);
            }
            if (0xf < (uint64_t)var_f8h) {
                uVar20 = var_f8h + 1;
                iVar9 = (int64_t)_auStack_110;
                if (0xfff < uVar20) {
                    if (0x1f < ((int64_t)_auStack_110 - *(int64_t *)((int64_t)_auStack_110 + -8)) - 8U)
                    goto code_r0x0001801776dd;
                    uVar20 = var_f8h + 0x28;
                    iVar9 = *(int64_t *)((int64_t)_auStack_110 + -8);
                }
                func_0x000180459c3c(iVar9, uVar20);
            }
            var_100h = 0;
            var_f8h = 0xf;
            auVar6[15] = 0;
            auVar6._0_15_ = stack0xfffffffffffffef1;
            _auStack_110 = auVar6 << 8;
            puVar19 = (undefined8 *)(iVar18 + 0x128);
            if (puVar13 != *(undefined8 **)(iVar18 + 0x10)) {
                puVar19 = puVar13 + 8;
            }
            func_0x00018000b4d0(&ppppppiStack_f0, puVar19);
            uVar20 = var_d8h;
            ppppppiVar17 = ppppppiStack_f0;
            ppppppiVar24 = (int64_t ******)&ppppppiStack_f0;
            if (0xf < (uint64_t)var_d8h) {
                ppppppiVar24 = ppppppiStack_f0;
            }
            if ((uint64_t)(var_118h - var_120h) < (uint64_t)var_e0h) {
                piStack_148 = (int64_t *)var_e0h;
                func_0x00018000ee80(auStack_130, var_e0h, 0);
                ppppppiVar17 = ppppppiStack_f0;
                uVar20 = var_d8h;
            } else {
                puVar22 = auStack_130;
                if (0xf < (uint64_t)var_118h) {
                    puVar22 = (undefined *)auStack_130;
                }
                puVar22 = puVar22 + var_120h;
                var_120h = var_120h + var_e0h;
                func_0x000180498030(puVar22, ppppppiVar24, var_e0h);
                puVar22[var_e0h] = 0;
            }
            if (0xf < uVar20) {
                uVar21 = uVar20 + 1;
                if (0xfff < uVar21) {
                    if (0x1f < (uint64_t)((int64_t)ppppppiVar17 + (-8 - (int64_t)ppppppiVar17[-1])))
                    goto code_r0x0001801776dd;
                    uVar21 = uVar20 + 0x28;
                    ppppppiVar17 = (int64_t ******)ppppppiVar17[-1];
                }
code_r0x000180177513:
                func_0x000180459c3c(ppppppiVar17, uVar21);
            }
            goto code_r0x000180177518;
        }
        piVar23 = (int64_t *)(iVar18 + 0x128);
        if (0xf < *(uint64_t *)(iVar18 + 0x140)) {
            piVar23 = (int64_t *)*piVar23;
        }
        puVar13 = (undefined8 *)func_0x0001801858c0(&ppppppiStack_f0, 0x18063e190, piVar23);
        puVar19 = puVar13;
        if (0xf < (uint64_t)puVar13[3]) {
            puVar19 = (undefined8 *)*puVar13;
        }
        piVar23 = (int64_t *)puVar13[2];
        if ((int64_t *)(var_118h - var_120h) < piVar23) {
            piStack_148 = piVar23;
            func_0x00018000ee80(auStack_130, piVar23, 0);
        } else {
            puVar22 = auStack_130;
            if (0xf < (uint64_t)var_118h) {
                puVar22 = (undefined *)auStack_130;
            }
            puVar22 = puVar22 + var_120h;
            var_120h = (int64_t)piVar23 + var_120h;
            func_0x000180498030(puVar22, puVar19, piVar23);
            *(undefined *)((int64_t)piVar23 + (int64_t)puVar22) = 0;
        }
        if ((uint64_t)var_d8h < 0x10) goto code_r0x000180177518;
        uVar21 = var_d8h + 1;
        ppppppiVar17 = ppppppiStack_f0;
        if (uVar21 < 0x1000) goto code_r0x000180177513;
        if ((uint64_t)((int64_t)ppppppiStack_f0 + (-8 - (int64_t)ppppppiStack_f0[-1])) < 0x20) {
            uVar21 = var_d8h + 0x28;
            ppppppiVar17 = (int64_t ******)ppppppiStack_f0[-1];
            goto code_r0x000180177513;
        }
code_r0x0001801776dd:
        pcVar3 = (code *)swi(0x29);
        ppppppiVar17 = (int64_t ******)(*pcVar3)(5);
        puVar22 = auStack_160;
    } else {
        ppiVar15 = (int64_t **)(iVar18 + 0xe8);
        ppiVar14 = ppiVar15;
        if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
            ppiVar14 = (int64_t **)*ppiVar15;
        }
        apuStack_98[0] = &stack0xffffffffffffffc8;
        if (*(char *)ppiVar14 == '/') goto code_r0x00018017714a;
        if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
            ppiVar15 = (int64_t **)*ppiVar15;
        }
        apuStack_98[0] = &stack0xffffffffffffffc8;
        iVar9 = func_0x00018045bb90(ppiVar15, 0x1804a63dc);
        if (iVar9 == 0) goto code_r0x00018017714a;
code_r0x00018017764a:
        puVar13 = (undefined8 *)(iVar18 + 0xe8);
        puVar19 = puVar13;
        if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
            puVar19 = (undefined8 *)*puVar13;
        }
        iVar9 = func_0x00018045b928(puVar19, 0x3f);
        puVar22 = auStack_168;
        if ((iVar9 != 0) || (puVar22 = auStack_168, *(int64_t *)(iVar18 + 0x178) == 0)) goto code_r0x0001801776ed;
        func_0x00018000b460(puVar13, 0x3f);
        puVar16 = (undefined8 *)func_0x000180188970(&ppppppiStack_f0, iVar18 + 0x170);
        puVar19 = puVar16;
        if (0xf < (uint64_t)puVar16[3]) {
            puVar19 = (undefined8 *)*puVar16;
        }
        func_0x00018000d970(puVar13, puVar19, puVar16[2]);
        puVar22 = auStack_168;
        if ((uint64_t)var_d8h < 0x10) goto code_r0x0001801776ed;
        ppppppiVar17 = ppppppiStack_f0;
        puVar22 = auStack_168;
        if ((0xfff < var_d8h + 1U) &&
           (ppppppiVar17 = (int64_t ******)ppppppiStack_f0[-1], puVar22 = auStack_168,
           0x1f < (uint64_t)((int64_t)ppppppiStack_f0 + (-8 - (int64_t)ppppppiVar17)))) goto code_r0x0001801776dd;
    }
    *(undefined8 *)(puVar22 + -8) = 0x1801776ec;
    func_0x000180459c3c(ppppppiVar17);
code_r0x0001801776ed:
    if (0xf < (uint64_t)var_118h) {
        iVar18 = (int64_t)auStack_130;
        if ((0xfff < var_118h + 1U) &&
           (iVar18 = *(int64_t *)((int64_t)auStack_130 + -8), 0x1f < ((int64_t)auStack_130 - iVar18) - 8U)) {
            pcVar3 = (code *)swi(0x29);
            iVar18 = (*pcVar3)(5);
            puVar22 = puVar22 + 8;
        }
        *(undefined8 *)(puVar22 + -8) = 0x18017772d;
        func_0x000180459c3c(iVar18);
    }
    *(undefined8 *)(puVar22 + -8) = 0x180177739;
    func_0x000180459870(uStack_d0 ^ (uint64_t)puVar22);
    return;
}

// ============================================================
// Function: FUN_1801770c0
// Address: 0x1801770c0
// Size: 1673 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_127h
// WARNING: [rz-ghidra] Detected overlap for variable var_11fh
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_107h

void fcn.180176b40(int64_t arg1, int64_t arg2)
{
    undefined2 *puVar1;
    char cVar2;
    code *pcVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined auVar6 [16];
    int32_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    undefined8 *puVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    undefined8 *puVar16;
    int64_t ******ppppppiVar17;
    int64_t iVar18;
    undefined8 *puVar19;
    uint64_t uVar20;
    uint64_t uVar21;
    undefined *puVar22;
    int64_t *piVar23;
    int64_t ******ppppppiVar24;
    int64_t **unaff_R15;
    int64_t var_18h;
    undefined8 uStack_170;
    undefined auStack_168 [8];
    undefined auStack_160 [16];
    int64_t var_150h;
    int64_t *piStack_148;
    int64_t var_138h;
    undefined auStack_130 [8];
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    undefined auStack_110 [5];
    undefined auStack_10b [3];
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t ******ppppppiStack_f0;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    uint64_t uStack_d0;
    int64_t **ppiStack_c0;
    int64_t **ppiStack_b8;
    int64_t *piStack_b0;
    int64_t iStack_a8;
    int64_t **ppiStack_a0;
    undefined *apuStack_98 [4];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    uint64_t uStack_50;
    int64_t var_48h;
    int64_t var_40h;
    
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)apuStack_98;
    ppiStack_a0 = (int64_t **)0x180176b74;
    var_68h = arg1;
    func_0x000180177b70();
    ppiStack_a0 = (int64_t **)0x180176b7c;
    func_0x000180177750(arg1);
    ppiVar15 = (int64_t **)**(int64_t ***)(arg1 + 0x10);
    cVar2 = *(char *)((int64_t)ppiVar15 + 0x19);
    while (cVar2 == '\0') {
        pcVar8 = (char *)arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            pcVar8 = *(char **)arg2;
        }
        if (*pcVar8 != ':') {
            if (ppiVar15[7] < (int64_t *)0x10) {
                ppiVar14 = ppiVar15 + 4;
            } else {
                ppiVar14 = (int64_t **)ppiVar15[4];
            }
            ppiStack_a0 = (int64_t **)0x180176bc3;
            func_0x00018000d970(arg2, ppiVar14, ppiVar15[6]);
            iVar18 = *(int64_t *)(arg2 + 0x10);
            if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 2) {
                var_78h = 2;
                ppiStack_a0 = (int64_t **)0x180176c1f;
                func_0x00018000ee80(arg2, 2, 0, 0x1805aadb4);
            } else {
                *(int64_t *)(arg2 + 0x10) = iVar18 + 2;
                iVar9 = arg2;
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    iVar9 = *(int64_t *)arg2;
                }
                *(undefined2 *)(iVar18 + iVar9) = 0x203a;
                *(undefined *)(iVar18 + 2 + iVar9) = 0;
            }
            unaff_R15 = ppiVar15 + 8;
            ppiVar14 = unaff_R15;
            if ((int64_t *)0xf < ppiVar15[0xb]) {
                ppiVar14 = (int64_t **)*unaff_R15;
            }
            ppiVar10 = ppiVar15 + 10;
            if (*ppiVar10 == (int64_t *)0x0) {
code_r0x000180176c68:
                ppiVar14 = unaff_R15;
                if ((int64_t *)0xf < ppiVar15[0xb]) {
                    ppiVar14 = (int64_t **)*unaff_R15;
                }
                if (*ppiVar10 != (int64_t *)0x0) {
                    iVar18 = (int64_t)ppiVar14 + (int64_t)*ppiVar10;
                    ppiStack_a0 = (int64_t **)0x180176c9f;
                    iVar9 = func_0x0001804581c0(ppiVar14, iVar18, 0x1805ab2a0, 1);
                    if ((iVar9 != iVar18) && (iVar9 - (int64_t)ppiVar14 != -1)) goto code_r0x000180176cb5;
                }
                if ((int64_t *)0xf < ppiVar15[0xb]) {
                    unaff_R15 = (int64_t **)*unaff_R15;
                }
                ppiStack_a0 = (int64_t **)0x180176e6b;
                func_0x00018000d970(arg2, unaff_R15, *ppiVar10);
            } else {
                iVar18 = (int64_t)*ppiVar10 + (int64_t)ppiVar14;
                ppiStack_a0 = (int64_t **)0x180176c5a;
                iVar9 = func_0x0001804581c0(ppiVar14, iVar18, 0x1804a6320, 1);
                if ((iVar9 == iVar18) || (iVar9 - (int64_t)ppiVar14 == -1)) goto code_r0x000180176c68;
code_r0x000180176cb5:
                uStack_50 = 0;
                var_48h = 0xf;
                stack0xffffffffffffffa1 = SUB1615(ZEXT816(0), 1);
                auVar4[15] = 0;
                auVar4._0_15_ = stack0xffffffffffffffa1;
                _var_60h = auVar4 << 8;
                piVar23 = (int64_t *)0x0;
                if (ppiVar15[10] != (int64_t *)0x0) {
                    do {
                        uVar20 = uStack_50;
                        piVar11 = ppiVar15[0xb];
                        ppiVar10 = unaff_R15;
                        if ((int64_t *)0xf < piVar11) {
                            ppiVar10 = (int64_t **)*unaff_R15;
                        }
                        if (*(char *)((int64_t)ppiVar10 + (int64_t)piVar23) == '\r') {
                            if (var_48h - uStack_50 < 2) {
                                uVar12 = 0x18062037c;
code_r0x000180176d86:
                                var_78h = 2;
                                ppiStack_a0 = (int64_t **)0x180176d9c;
                                func_0x00018000ee80(&var_60h, 2, 0, uVar12);
                            } else {
                                piVar11 = &var_60h;
                                if (0xf < (uint64_t)var_48h) {
                                    piVar11 = (int64_t *)var_60h;
                                }
                                puVar1 = (undefined2 *)((int64_t)piVar11 + uStack_50);
                                uStack_50 = uStack_50 + 2;
                                *puVar1 = 0x725c;
                                *(undefined *)((int64_t)piVar11 + uVar20 + 2) = 0;
                            }
                        } else {
                            ppiVar10 = ppiVar15 + 8;
                            if ((int64_t *)0xf < piVar11) {
                                ppiVar10 = (int64_t **)*ppiVar10;
                            }
                            if (*(char *)((int64_t)ppiVar10 + (int64_t)piVar23) == '\n') {
                                if (var_48h - uStack_50 < 2) {
                                    uVar12 = 0x180620378;
                                    goto code_r0x000180176d86;
                                }
                                piVar11 = &var_60h;
                                if (0xf < (uint64_t)var_48h) {
                                    piVar11 = (int64_t *)var_60h;
                                }
                                puVar1 = (undefined2 *)((int64_t)piVar11 + uStack_50);
                                uStack_50 = uStack_50 + 2;
                                *puVar1 = 0x6e5c;
                                *(undefined *)((int64_t)piVar11 + uVar20 + 2) = 0;
                            } else {
                                ppiVar10 = ppiVar15 + 8;
                                if ((int64_t *)0xf < piVar11) {
                                    ppiVar10 = (int64_t **)*ppiVar10;
                                }
                                if (uStack_50 < (uint64_t)var_48h) {
                                    piVar11 = &var_60h;
                                    if (0xf < (uint64_t)var_48h) {
                                        piVar11 = (int64_t *)var_60h;
                                    }
                                    puVar22 = (undefined *)((int64_t)piVar11 + uStack_50);
                                    uStack_50 = uStack_50 + 1;
                                    *puVar22 = *(undefined *)((int64_t)ppiVar10 + (int64_t)piVar23);
                                    *(undefined *)((int64_t)piVar11 + uVar20 + 1) = 0;
                                } else {
                                    ppiStack_a0 = (int64_t **)0x180176dea;
                                    func_0x00018000f010(&var_60h, 1, 0, 
                                                        *(undefined *)((int64_t)ppiVar10 + (int64_t)piVar23));
                                }
                            }
                        }
                        piVar23 = (int64_t *)((int64_t)piVar23 + 1);
                    } while (piVar23 < ppiVar15[10]);
                }
                piVar11 = &var_60h;
                if (0xf < (uint64_t)var_48h) {
                    piVar11 = (int64_t *)var_60h;
                }
                ppiStack_a0 = (int64_t **)0x180176e14;
                func_0x00018000d970(arg2, piVar11);
                if (0xf < (uint64_t)var_48h) {
                    uVar20 = var_48h + 1;
                    iVar18 = var_60h;
                    if (0xfff < uVar20) {
                        iVar18 = *(int64_t *)(var_60h + -8);
                        if (0x1f < (var_60h - iVar18) - 8U) goto code_r0x0001801770b9;
                        uVar20 = var_48h + 0x28;
                    }
                    ppiStack_a0 = (int64_t **)0x180176e50;
                    func_0x000180459c3c(iVar18, uVar20);
                }
            }
            iVar18 = *(int64_t *)(arg2 + 0x10);
            if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 2) {
                var_78h = 2;
                ppiStack_a0 = (int64_t **)0x180176ec7;
                func_0x00018000ee80(arg2, 2, 0, 0x180644f68);
            } else {
                *(int64_t *)(arg2 + 0x10) = iVar18 + 2;
                iVar9 = arg2;
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    iVar9 = *(int64_t *)arg2;
                }
                *(undefined2 *)(iVar18 + iVar9) = 0xa0d;
                *(undefined *)(iVar18 + 2 + iVar9) = 0;
            }
        }
        ppiVar14 = (int64_t **)ppiVar15[2];
        if (*(char *)((int64_t)ppiVar14 + 0x19) == '\0') {
            cVar2 = *(char *)((int64_t)*ppiVar14 + 0x19);
            ppiVar15 = ppiVar14;
            ppiVar14 = (int64_t **)*ppiVar14;
            while (cVar2 == '\0') {
                cVar2 = *(char *)((int64_t)*ppiVar14 + 0x19);
                ppiVar15 = ppiVar14;
                ppiVar14 = (int64_t **)*ppiVar14;
            }
        } else {
            cVar2 = *(char *)((int64_t)ppiVar15[1] + 0x19);
            ppiVar10 = (int64_t **)ppiVar15[1];
            ppiVar14 = ppiVar15;
            while ((ppiVar15 = ppiVar10, cVar2 == '\0' && (ppiVar14 == (int64_t **)ppiVar15[2]))) {
                cVar2 = *(char *)((int64_t)ppiVar15[1] + 0x19);
                ppiVar10 = (int64_t **)ppiVar15[1];
                ppiVar14 = ppiVar15;
            }
        }
        arg1 = var_68h;
        cVar2 = *(char *)((int64_t)ppiVar15 + 0x19);
    }
    piVar23 = (int64_t *)0x1804a6330;
    if (*(int32_t *)(arg1 + 8) != 1) {
        piVar23 = (int64_t *)0x1804a6324;
    }
    ppiVar15 = *(int64_t ***)(arg1 + 0x20);
    ppiVar14 = *(int64_t ***)(arg1 + 0x28);
    do {
        if (ppiVar15 == ppiVar14) {
            ppiStack_a0 = (int64_t **)0x1801770a1;
            func_0x000180459870(var_40h ^ (uint64_t)apuStack_98);
            return;
        }
        ppiStack_a0 = (int64_t **)0x180176f5d;
        uVar12 = func_0x000180498cd0(piVar23);
        ppiStack_a0 = (int64_t **)0x180176f6b;
        func_0x00018000d970(arg2, piVar23, uVar12);
        iVar18 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 2) {
            var_78h = 2;
            ppiStack_a0 = (int64_t **)0x180176fc5;
            func_0x00018000ee80(arg2, 2, 0, 0x1805aadb4);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar18 + 2;
            iVar9 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar9 = *(int64_t *)arg2;
            }
            *(undefined2 *)(iVar18 + iVar9) = 0x203a;
            *(undefined *)(iVar18 + 2 + iVar9) = 0;
        }
        ppiStack_a0 = (int64_t **)0x180176fd1;
        puVar13 = (undefined8 *)func_0x000180179d20(ppiVar15, &var_60h);
        puVar19 = puVar13;
        if (0xf < (uint64_t)puVar13[3]) {
            puVar19 = (undefined8 *)*puVar13;
        }
        ppiStack_a0 = (int64_t **)0x180176fed;
        func_0x00018000d970(arg2, puVar19, puVar13[2]);
        if (0xf < (uint64_t)var_48h) {
            uVar20 = var_48h + 1;
            iVar18 = var_60h;
            if (0xfff < uVar20) {
                iVar18 = *(int64_t *)(var_60h + -8);
                if (0x1f < (var_60h - iVar18) - 8U) break;
                uVar20 = var_48h + 0x28;
            }
            ppiStack_a0 = (int64_t **)0x180177029;
            func_0x000180459c3c(iVar18, uVar20);
        }
        iVar18 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar18 < 2) {
            var_78h = 2;
            ppiStack_a0 = (int64_t **)0x180177085;
            func_0x00018000ee80(arg2, 2, 0, 0x180644f68);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar18 + 2;
            iVar9 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar9 = *(int64_t *)arg2;
            }
            *(undefined2 *)(iVar18 + iVar9) = 0xa0d;
            *(undefined *)(iVar18 + 2 + iVar9) = 0;
        }
        ppiVar15 = ppiVar15 + 0x18;
    } while( true );
code_r0x0001801770b9:
    iVar18 = 5;
    pcVar3 = (code *)swi(0x29);
    (*pcVar3)();
    uStack_d0 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    var_120h = 0;
    var_118h = 0xf;
    stack0xfffffffffffffed1 = SUB1615(ZEXT816(0), 1);
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xfffffffffffffed1;
    _auStack_130 = auVar5 << 8;
    ppiStack_c0 = unaff_R15;
    ppiStack_b8 = ppiVar14;
    piStack_b0 = piVar23;
    iStack_a8 = arg2;
    ppiStack_a0 = ppiVar15;
    apuStack_98[0] = &stack0xffffffffffffffc8;
    if (*(int64_t *)(iVar18 + 0xf8) == 0) {
code_r0x00018017714a:
        piVar23 = (int64_t *)(iVar18 + 0x108);
        if ((int64_t *)auStack_130 != piVar23) {
            if (0xf < *(uint64_t *)(iVar18 + 0x120)) {
                piVar23 = (int64_t *)*piVar23;
            }
            func_0x00018000f180(auStack_130, piVar23, *(undefined8 *)(iVar18 + 0x118));
        }
        if ((uint64_t)(var_118h - var_120h) < 3) {
            piStack_148 = (int64_t *)0x3;
            func_0x00018000ee80(auStack_130, 3, 0, 0x1804a63dc);
        } else {
            puVar22 = auStack_130;
            if (0xf < (uint64_t)var_118h) {
                puVar22 = (undefined *)auStack_130;
            }
            puVar22 = puVar22 + var_120h;
            var_120h = var_120h + 3;
            func_0x000180498030(puVar22, 0x1804a63dc, 3);
            puVar22[3] = 0;
        }
        if (*(int64_t *)(iVar18 + 0xf8) != 0) {
            ppiVar15 = (int64_t **)(iVar18 + 0xe8);
            ppiVar14 = ppiVar15;
            if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
                ppiVar14 = (int64_t **)*ppiVar15;
            }
            if (*(char *)ppiVar14 == '/') goto code_r0x000180177273;
            if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
                ppiVar15 = (int64_t **)*ppiVar15;
            }
            piVar23 = *(int64_t **)(iVar18 + 0xf8);
            if ((int64_t *)(var_118h - var_120h) < piVar23) {
                piStack_148 = piVar23;
                func_0x00018000ee80(auStack_130, piVar23, 0);
            } else {
                puVar22 = auStack_130;
                if (0xf < (uint64_t)var_118h) {
                    puVar22 = (undefined *)auStack_130;
                }
                puVar22 = puVar22 + var_120h;
                var_120h = (int64_t)piVar23 + var_120h;
                func_0x000180498030(puVar22, ppiVar15, piVar23);
                *(undefined *)((int64_t)piVar23 + (int64_t)puVar22) = 0;
            }
code_r0x000180177518:
            if (*(int64_t *)(iVar18 + 0xf8) == 0) {
code_r0x000180177595:
                if (1 < *(uint64_t *)(iVar18 + 0x160)) {
                    ppiVar15 = (int64_t **)(iVar18 + 0x150);
                    ppiVar14 = ppiVar15;
                    if (0xf < *(uint64_t *)(iVar18 + 0x168)) {
                        ppiVar14 = (int64_t **)*ppiVar15;
                    }
                    if (*(char *)ppiVar14 == '/') {
                        ppiVar14 = ppiVar15;
                        if (0xf < *(uint64_t *)(iVar18 + 0x168)) {
                            ppiVar14 = (int64_t **)*ppiVar15;
                        }
                        goto code_r0x00018017754f;
                    }
                }
                if (*(int64_t *)(iVar18 + 0xf8) == 0) {
                    if ((uint64_t)var_120h < (uint64_t)var_118h) {
                        puVar22 = auStack_130;
                        if (0xf < (uint64_t)var_118h) {
                            puVar22 = (undefined *)auStack_130;
                        }
                        puVar1 = (undefined2 *)(puVar22 + var_120h);
                        var_120h = var_120h + 1;
                        *puVar1 = 0x2f;
                    } else {
                        func_0x00018000f010(auStack_130, 1, 0, 0x2f);
                    }
                }
            } else {
                ppiVar15 = (int64_t **)(iVar18 + 0xe8);
                ppiVar14 = ppiVar15;
                if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
                    ppiVar14 = (int64_t **)*ppiVar15;
                }
                if (*(char *)ppiVar14 != '/') goto code_r0x000180177595;
                ppiVar14 = ppiVar15;
                if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
                    ppiVar14 = (int64_t **)*ppiVar15;
                }
code_r0x00018017754f:
                piVar23 = ppiVar15[2];
                if ((int64_t *)(var_118h - var_120h) < piVar23) {
                    piStack_148 = piVar23;
                    func_0x00018000ee80(auStack_130, piVar23, 0);
                } else {
                    puVar22 = auStack_130;
                    if (0xf < (uint64_t)var_118h) {
                        puVar22 = (undefined *)auStack_130;
                    }
                    puVar22 = puVar22 + var_120h;
                    var_120h = var_120h + (int64_t)piVar23;
                    func_0x000180498030(puVar22, ppiVar14, piVar23);
                    puVar22[(int64_t)piVar23] = 0;
                }
            }
            if ((undefined *)(iVar18 + 0xe8) != auStack_130) {
                puVar22 = auStack_130;
                if (0xf < (uint64_t)var_118h) {
                    puVar22 = (undefined *)auStack_130;
                }
                func_0x00018000f180((undefined *)(iVar18 + 0xe8), puVar22, var_120h);
            }
            goto code_r0x00018017764a;
        }
code_r0x000180177273:
        iVar7 = *(int32_t *)(iVar18 + 0x148);
        if (((iVar7 == 0) || (iVar7 == 0x50)) || (iVar7 == 0x1bb)) {
            var_100h = 4;
            var_f8h = 0xf;
            _auStack_10b = SUB1611(ZEXT816(0), 5);
            auStack_110 = (undefined  [5])0x74736f48;
            puVar19 = (undefined8 *)(*(undefined8 **)(iVar18 + 0x10))[1];
            cVar2 = *(char *)((int64_t)puVar19 + 0x19);
            puVar13 = *(undefined8 **)(iVar18 + 0x10);
            while (cVar2 == '\0') {
                puVar22 = auStack_110;
                if (0xf < (uint64_t)var_f8h) {
                    puVar22 = _auStack_110;
                }
                piVar23 = puVar19 + 4;
                if (0xf < (uint64_t)puVar19[7]) {
                    piVar23 = (int64_t *)*piVar23;
                }
                iVar7 = func_0x00018047b6d0(piVar23, puVar22);
                if (iVar7 < 0) {
                    puVar16 = (undefined8 *)puVar19[2];
                    puVar19 = puVar13;
                } else {
                    puVar16 = (undefined8 *)*puVar19;
                }
                puVar13 = puVar19;
                puVar19 = puVar16;
                cVar2 = *(char *)((int64_t)puVar16 + 0x19);
            }
            if (*(char *)((int64_t)puVar13 + 0x19) == '\0') {
                piVar23 = puVar13 + 4;
                if (0xf < (uint64_t)puVar13[7]) {
                    piVar23 = (int64_t *)*piVar23;
                }
                puVar22 = auStack_110;
                if (0xf < (uint64_t)var_f8h) {
                    puVar22 = _auStack_110;
                }
                iVar7 = func_0x00018047b6d0(puVar22, piVar23);
                if (iVar7 < 0) goto code_r0x000180177402;
            } else {
code_r0x000180177402:
                puVar13 = *(undefined8 **)(iVar18 + 0x10);
            }
            if (0xf < (uint64_t)var_f8h) {
                uVar20 = var_f8h + 1;
                iVar9 = (int64_t)_auStack_110;
                if (0xfff < uVar20) {
                    if (0x1f < ((int64_t)_auStack_110 - *(int64_t *)((int64_t)_auStack_110 + -8)) - 8U)
                    goto code_r0x0001801776dd;
                    uVar20 = var_f8h + 0x28;
                    iVar9 = *(int64_t *)((int64_t)_auStack_110 + -8);
                }
                func_0x000180459c3c(iVar9, uVar20);
            }
            var_100h = 0;
            var_f8h = 0xf;
            auVar6[15] = 0;
            auVar6._0_15_ = stack0xfffffffffffffef1;
            _auStack_110 = auVar6 << 8;
            puVar19 = (undefined8 *)(iVar18 + 0x128);
            if (puVar13 != *(undefined8 **)(iVar18 + 0x10)) {
                puVar19 = puVar13 + 8;
            }
            func_0x00018000b4d0(&ppppppiStack_f0, puVar19);
            uVar20 = var_d8h;
            ppppppiVar17 = ppppppiStack_f0;
            ppppppiVar24 = (int64_t ******)&ppppppiStack_f0;
            if (0xf < (uint64_t)var_d8h) {
                ppppppiVar24 = ppppppiStack_f0;
            }
            if ((uint64_t)(var_118h - var_120h) < (uint64_t)var_e0h) {
                piStack_148 = (int64_t *)var_e0h;
                func_0x00018000ee80(auStack_130, var_e0h, 0);
                ppppppiVar17 = ppppppiStack_f0;
                uVar20 = var_d8h;
            } else {
                puVar22 = auStack_130;
                if (0xf < (uint64_t)var_118h) {
                    puVar22 = (undefined *)auStack_130;
                }
                puVar22 = puVar22 + var_120h;
                var_120h = var_120h + var_e0h;
                func_0x000180498030(puVar22, ppppppiVar24, var_e0h);
                puVar22[var_e0h] = 0;
            }
            if (0xf < uVar20) {
                uVar21 = uVar20 + 1;
                if (0xfff < uVar21) {
                    if (0x1f < (uint64_t)((int64_t)ppppppiVar17 + (-8 - (int64_t)ppppppiVar17[-1])))
                    goto code_r0x0001801776dd;
                    uVar21 = uVar20 + 0x28;
                    ppppppiVar17 = (int64_t ******)ppppppiVar17[-1];
                }
code_r0x000180177513:
                func_0x000180459c3c(ppppppiVar17, uVar21);
            }
            goto code_r0x000180177518;
        }
        piVar23 = (int64_t *)(iVar18 + 0x128);
        if (0xf < *(uint64_t *)(iVar18 + 0x140)) {
            piVar23 = (int64_t *)*piVar23;
        }
        puVar13 = (undefined8 *)func_0x0001801858c0(&ppppppiStack_f0, 0x18063e190, piVar23);
        puVar19 = puVar13;
        if (0xf < (uint64_t)puVar13[3]) {
            puVar19 = (undefined8 *)*puVar13;
        }
        piVar23 = (int64_t *)puVar13[2];
        if ((int64_t *)(var_118h - var_120h) < piVar23) {
            piStack_148 = piVar23;
            func_0x00018000ee80(auStack_130, piVar23, 0);
        } else {
            puVar22 = auStack_130;
            if (0xf < (uint64_t)var_118h) {
                puVar22 = (undefined *)auStack_130;
            }
            puVar22 = puVar22 + var_120h;
            var_120h = (int64_t)piVar23 + var_120h;
            func_0x000180498030(puVar22, puVar19, piVar23);
            *(undefined *)((int64_t)piVar23 + (int64_t)puVar22) = 0;
        }
        if ((uint64_t)var_d8h < 0x10) goto code_r0x000180177518;
        uVar21 = var_d8h + 1;
        ppppppiVar17 = ppppppiStack_f0;
        if (uVar21 < 0x1000) goto code_r0x000180177513;
        if ((uint64_t)((int64_t)ppppppiStack_f0 + (-8 - (int64_t)ppppppiStack_f0[-1])) < 0x20) {
            uVar21 = var_d8h + 0x28;
            ppppppiVar17 = (int64_t ******)ppppppiStack_f0[-1];
            goto code_r0x000180177513;
        }
code_r0x0001801776dd:
        pcVar3 = (code *)swi(0x29);
        ppppppiVar17 = (int64_t ******)(*pcVar3)(5);
        puVar22 = auStack_160;
    } else {
        ppiVar15 = (int64_t **)(iVar18 + 0xe8);
        ppiVar14 = ppiVar15;
        if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
            ppiVar14 = (int64_t **)*ppiVar15;
        }
        apuStack_98[0] = &stack0xffffffffffffffc8;
        if (*(char *)ppiVar14 == '/') goto code_r0x00018017714a;
        if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
            ppiVar15 = (int64_t **)*ppiVar15;
        }
        apuStack_98[0] = &stack0xffffffffffffffc8;
        iVar9 = func_0x00018045bb90(ppiVar15, 0x1804a63dc);
        if (iVar9 == 0) goto code_r0x00018017714a;
code_r0x00018017764a:
        puVar13 = (undefined8 *)(iVar18 + 0xe8);
        puVar19 = puVar13;
        if (0xf < *(uint64_t *)(iVar18 + 0x100)) {
            puVar19 = (undefined8 *)*puVar13;
        }
        iVar9 = func_0x00018045b928(puVar19, 0x3f);
        puVar22 = auStack_168;
        if ((iVar9 != 0) || (puVar22 = auStack_168, *(int64_t *)(iVar18 + 0x178) == 0)) goto code_r0x0001801776ed;
        func_0x00018000b460(puVar13, 0x3f);
        puVar16 = (undefined8 *)func_0x000180188970(&ppppppiStack_f0, iVar18 + 0x170);
        puVar19 = puVar16;
        if (0xf < (uint64_t)puVar16[3]) {
            puVar19 = (undefined8 *)*puVar16;
        }
        func_0x00018000d970(puVar13, puVar19, puVar16[2]);
        puVar22 = auStack_168;
        if ((uint64_t)var_d8h < 0x10) goto code_r0x0001801776ed;
        ppppppiVar17 = ppppppiStack_f0;
        puVar22 = auStack_168;
        if ((0xfff < var_d8h + 1U) &&
           (ppppppiVar17 = (int64_t ******)ppppppiStack_f0[-1], puVar22 = auStack_168,
           0x1f < (uint64_t)((int64_t)ppppppiStack_f0 + (-8 - (int64_t)ppppppiVar17)))) goto code_r0x0001801776dd;
    }
    *(undefined8 *)(puVar22 + -8) = 0x1801776ec;
    func_0x000180459c3c(ppppppiVar17);
code_r0x0001801776ed:
    if (0xf < (uint64_t)var_118h) {
        iVar18 = (int64_t)auStack_130;
        if ((0xfff < var_118h + 1U) &&
           (iVar18 = *(int64_t *)((int64_t)auStack_130 + -8), 0x1f < ((int64_t)auStack_130 - iVar18) - 8U)) {
            pcVar3 = (code *)swi(0x29);
            iVar18 = (*pcVar3)(5);
            puVar22 = puVar22 + 8;
        }
        *(undefined8 *)(puVar22 + -8) = 0x18017772d;
        func_0x000180459c3c(iVar18);
    }
    *(undefined8 *)(puVar22 + -8) = 0x180177739;
    func_0x000180459870(uStack_d0 ^ (uint64_t)puVar22);
    return;
}

// ============================================================
// Function: FUN_180177750
// Address: 0x180177750
// Size: 1049 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180177750(int64_t arg1)
{
    code *pcVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined8 *puVar15;
    undefined8 *puVar16;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStackY_1b0;
    undefined auStackY_1a8 [8];
    undefined auStackY_1a0 [24];
    int64_t var_188h;
    int32_t iStackY_17c;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_120h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f0h;
    int64_t var_88h;
    undefined var_80h [6];
    int64_t var_7ah;
    int64_t var_70h;
    int64_t var_68h;
    undefined4 var_60h;
    undefined2 var_5ch;
    int64_t var_5ah;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar9 = var_88h;
    puVar13 = auStackY_1a8;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_1a8;
    var_188h._0_4_ = 0;
    stack0xffffffffffffff88 = 0xe;
    var_70h = 0xf;
    var_80h._0_4_ = 0x676e654c;
    var_88h = 0x2d746e65746e6f43;
    var_7ah._0_2_ = (undefined2)((uint64_t)iVar9 >> 0x30);
    var_80h._4_2_ = 0x6874;
    puVar15 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
    cVar5 = *(char *)((int64_t)puVar15 + 0x19);
    puVar16 = *(undefined8 **)(arg1 + 0x10);
    while (cVar5 == '\0') {
        piVar8 = &var_88h;
        if (0xf < (uint64_t)var_70h) {
            piVar8 = (int64_t *)var_88h;
        }
        piVar10 = puVar15 + 4;
        if (0xf < (uint64_t)puVar15[7]) {
            piVar10 = (int64_t *)*piVar10;
        }
        iVar6 = func_0x00018047b6d0(piVar10, piVar8);
        if (iVar6 < 0) {
            puVar12 = (undefined8 *)puVar15[2];
            puVar15 = puVar16;
        } else {
            puVar12 = (undefined8 *)*puVar15;
        }
        puVar16 = puVar15;
        puVar15 = puVar12;
        cVar5 = *(char *)((int64_t)puVar12 + 0x19);
    }
    if (*(char *)((int64_t)puVar16 + 0x19) == '\0') {
        piVar8 = puVar16 + 4;
        if (0xf < (uint64_t)puVar16[7]) {
            piVar8 = (int64_t *)*piVar8;
        }
        piVar10 = &var_88h;
        if (0xf < (uint64_t)var_70h) {
            piVar10 = (int64_t *)var_88h;
        }
        iVar6 = func_0x00018047b6d0(piVar10, piVar8);
        if (iVar6 < 0) goto code_r0x000180177832;
    } else {
code_r0x000180177832:
        puVar16 = *(undefined8 **)(arg1 + 0x10);
    }
    if ((uint64_t)var_70h < 0x10) {
code_r0x000180177873:
        stack0xffffffffffffff88 = 0;
        var_70h = 0xf;
        auVar2[15] = 0;
        auVar2._0_15_ = stack0xffffffffffffff79;
        _var_88h = auVar2 << 8;
        if (puVar16 != *(undefined8 **)(arg1 + 0x10)) {
            piVar8 = puVar16 + 8;
            if (0xf < (uint64_t)puVar16[0xb]) {
                piVar8 = (int64_t *)*piVar8;
            }
            uVar7 = func_0x00018046eb8c(piVar8);
            *(undefined8 *)(arg1 + 0xa0) = uVar7;
        }
        if (*(int64_t *)(arg1 + 0xa0) == 0) {
            fcn.180176880(arg1, var_138h);
            *(undefined8 *)(arg1 + 0xa0) = *(undefined8 *)(arg1 + 0x48);
        }
        puVar14 = auStackY_1a8;
        if ((((puVar16 != *(undefined8 **)(arg1 + 0x10)) ||
             (cVar5 = func_0x000180178600(arg1), puVar14 = auStackY_1a8, cVar5 != '\0')) ||
            (puVar14 = auStackY_1a8, *(int32_t *)(arg1 + 0xa8) == 0x6a)) ||
           ((*(int64_t *)(arg1 + 0xa0) == 0 &&
            (((puVar14 = auStackY_1a8, *(int32_t *)(arg1 + 8) != 1 ||
              (iVar6 = *(int32_t *)(arg1 + 0xe0), puVar14 = auStackY_1a8, iVar6 - 100U < 100)) ||
             ((puVar14 = auStackY_1a8, iVar6 == 0xcc || (puVar14 = auStackY_1a8, iVar6 == 0x130))))))))
        goto code_r0x000180177b42;
        stack0xffffffffffffffa8 = 0xe;
        var_50h = 0xf;
        var_68h = 0x2d746e65746e6f43;
        var_60h = 0x676e654c;
        var_5ch = 0x6874;
        var_5ah._0_2_ = 0;
        func_0x00018000c2d0(&var_178h, 1);
        func_0x0001800107d0(&var_178h, *(undefined8 *)(arg1 + 0xa0));
        var_38h = 0;
        var_30h = 0xf;
        stack0xffffffffffffffb9 = SUB1615(ZEXT816(0), 1);
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffffb9;
        _var_48h = auVar3 << 8;
        var_188h._0_4_ = 4;
        auVar2 = ZEXT816(0);
        stack0xffffffffffffff88 = 0;
        if ((((uint8_t)(uint32_t)var_100h & 0x22) == 2) || (uVar11 = *(uint64_t *)var_130h, uVar11 == 0)) {
            if (((uint32_t)var_100h & 4) == 0) {
                if (*(int64_t *)var_138h == 0) {
                    _var_80h = 0;
                    var_88h = 0;
                } else {
                    var_88h = *(int64_t *)var_158h;
                    _var_80h = (*(int32_t *)var_120h - var_88h) + *(int64_t *)var_138h;
                }
                goto code_r0x000180177a1a;
            }
        } else {
            var_88h = *(int64_t *)var_150h;
            if (uVar11 < (uint64_t)var_108h) {
                uVar11 = var_108h;
            }
            _var_80h = uVar11 - var_88h;
code_r0x000180177a1a:
            if (var_88h != 0) {
                iVar9 = var_88h;
                iVar4 = _var_80h;
                _var_88h = auVar2;
                func_0x00018000f180(&var_48h, iVar9, iVar4);
                auVar2 = _var_88h;
            }
        }
        _var_88h = auVar2;
        var_188h._0_4_ = 3;
        *(undefined8 *)((int64_t)&var_178h + (int64_t)*(int32_t *)(var_178h + 4)) = 0x1804a6448;
        *(int32_t *)((int64_t)&iStackY_17c + (int64_t)*(int32_t *)(var_178h + 4)) = *(int32_t *)(var_178h + 4) + -0x88;
        func_0x00018000c970(&var_170h);
        *(undefined8 *)((int64_t)&var_178h + (int64_t)*(int32_t *)(var_178h + 4)) = 0x1804a54f0;
        *(int32_t *)((int64_t)&iStackY_17c + (int64_t)*(int32_t *)(var_178h + 4)) = *(int32_t *)(var_178h + 4) + -0x10;
        var_f0h = 0x1804a54d0;
        func_0x000180455c14(&var_f0h);
        piVar8 = (int64_t *)func_0x000180014c60(arg1 + 0x10, &var_88h, &var_68h);
        func_0x000180012c10(*piVar8 + 0x40, &var_48h);
        if (0xf < (uint64_t)var_30h) {
            iVar9 = var_48h;
            puVar13 = auStackY_1a8;
            if ((0xfff < var_30h + 1U) &&
               (iVar9 = *(int64_t *)(var_48h + -8), puVar13 = auStackY_1a8, 0x1f < (var_48h - iVar9) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar9 = (*pcVar1)(5);
                puVar13 = auStackY_1a0;
            }
            *(undefined8 *)(puVar13 + -8) = 0x180177b01;
            func_0x000180459c3c(iVar9);
        }
        puVar14 = puVar13;
        if ((uint64_t)var_50h < 0x10) goto code_r0x000180177b42;
        iVar9 = var_68h;
        if ((0xfff < var_50h + 1U) &&
           (iVar9 = *(int64_t *)(var_68h + -8), 0x1f < (var_68h - *(int64_t *)(var_68h + -8)) - 8U))
        goto code_r0x000180177b33;
    } else {
        uVar11 = var_70h + 1;
        iVar9 = var_88h;
        if (uVar11 < 0x1000) {
code_r0x00018017786e:
            func_0x000180459c3c(iVar9, uVar11);
            goto code_r0x000180177873;
        }
        puVar14 = auStackY_1a8;
        if ((var_88h - *(int64_t *)(var_88h + -8)) - 8U < 0x20) {
            uVar11 = var_70h + 0x28;
            iVar9 = *(int64_t *)(var_88h + -8);
            goto code_r0x00018017786e;
        }
code_r0x000180177b33:
        pcVar1 = (code *)swi(0x29);
        iVar9 = (*pcVar1)(5);
        puVar14 = puVar14 + 8;
    }
    *(undefined8 *)(puVar14 + -8) = 0x180177b42;
    func_0x000180459c3c(iVar9);
code_r0x000180177b42:
    *(undefined8 *)(puVar14 + -8) = 0x180177b51;
    func_0x000180459870(var_28h ^ (uint64_t)puVar14);
    return;
}

// ============================================================
// Function: FUN_180177b70
// Address: 0x180177b70
// Size: 1112 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h

void fcn.180177b70(int64_t arg1)
{
    int32_t *piVar1;
    char cVar2;
    code *pcVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined8 *puVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    undefined *puVar16;
    undefined *puVar17;
    undefined8 *puVar18;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    undefined4 var_70h;
    int64_t var_6ch;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar16 = auStack_c8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    var_88h = 0xc;
    var_80h = 0xf;
    var_90h._0_4_ = 0x65707954;
    var_98h = 0x2d746e65746e6f43;
    var_90h._4_4_ = 0;
    puVar18 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
    cVar2 = *(char *)((int64_t)puVar18 + 0x19);
    puVar12 = *(undefined8 **)(arg1 + 0x10);
    while (cVar2 == '\0') {
        piVar8 = &var_98h;
        if (0xf < (uint64_t)var_80h) {
            piVar8 = (int64_t *)var_98h;
        }
        piVar13 = puVar18 + 4;
        if (0xf < (uint64_t)puVar18[7]) {
            piVar13 = (int64_t *)*piVar13;
        }
        iVar6 = func_0x00018047b6d0(piVar13, piVar8);
        if (iVar6 < 0) {
            puVar15 = (undefined8 *)puVar18[2];
            puVar18 = puVar12;
        } else {
            puVar15 = (undefined8 *)*puVar18;
        }
        puVar12 = puVar18;
        puVar18 = puVar15;
        cVar2 = *(char *)((int64_t)puVar15 + 0x19);
    }
    if (*(char *)((int64_t)puVar12 + 0x19) == '\0') {
        piVar8 = puVar12 + 4;
        if (0xf < (uint64_t)puVar12[7]) {
            piVar8 = (int64_t *)*piVar8;
        }
        piVar13 = &var_98h;
        if (0xf < (uint64_t)var_80h) {
            piVar13 = (int64_t *)var_98h;
        }
        iVar6 = func_0x00018047b6d0(piVar13, piVar8);
        if (iVar6 < 0) goto code_r0x000180177c5e;
    } else {
code_r0x000180177c5e:
        puVar12 = *(undefined8 **)(arg1 + 0x10);
    }
    puVar18 = (undefined8 *)0x65707954;
    if ((uint64_t)var_80h < 0x10) {
code_r0x000180177cad:
        var_88h = 0;
        var_80h = 0xf;
        auVar4[15] = 0;
        auVar4._0_15_ = stack0xffffffffffffff69;
        _var_98h = auVar4 << 8;
        if (puVar12 == *(undefined8 **)(arg1 + 0x10)) {
            piVar1 = (int32_t *)(arg1 + 0xa8);
            if (*piVar1 == 0) {
                iVar11 = func_0x00018017c490(arg1 + 0xb0);
                if (iVar11 == 0) {
                    if (*(int64_t *)(arg1 + 200) == 0) {
                        if (*(int64_t *)(arg1 + 0xd8) == 0) {
                            iVar6 = 0;
                            if (*(int64_t *)(arg1 + 0x48) == 0) goto code_r0x000180177d51;
                            iVar6 = 0x65;
                        } else {
                            iVar6 = 0xcc;
                        }
                        goto code_r0x000180177d41;
                    }
                    *piVar1 = 0x12d;
                    iVar6 = 0x12d;
                } else {
                    iVar6 = 0xca;
code_r0x000180177d41:
                    *piVar1 = iVar6;
                }
code_r0x000180177d51:
                if (iVar6 == 0) goto code_r0x000180177dfd;
            }
            stack0xffffffffffffff98 = 0xc;
            var_60h = 0xf;
            var_78h = 0x2d746e65746e6f43;
            var_70h = 0x65707954;
            var_6ch._0_4_ = 0;
            piVar8 = (int64_t *)func_0x000180014c60(arg1 + 0x10, &var_98h, &var_78h);
            puVar18 = (undefined8 *)*piVar8;
            uVar9 = func_0x0001801867d0(*piVar1);
            uVar10 = func_0x000180498cd0(uVar9);
            func_0x00018000f180(puVar18 + 8, uVar9, uVar10);
            if (0xf < (uint64_t)var_60h) {
                uVar14 = var_60h + 1;
                iVar11 = var_78h;
                if (0xfff < uVar14) {
                    if (0x1f < (var_78h - *(int64_t *)(var_78h + -8)) - 8U) goto code_r0x000180177ed7;
                    uVar14 = var_60h + 0x28;
                    iVar11 = *(int64_t *)(var_78h + -8);
                }
                func_0x000180459c3c(iVar11, uVar14);
            }
        } else {
            piVar8 = puVar12 + 8;
            if (0xf < (uint64_t)puVar12[0xb]) {
                piVar8 = (int64_t *)*piVar8;
            }
            uVar7 = func_0x000180185c10(piVar8);
            *(undefined4 *)(arg1 + 0xa8) = uVar7;
        }
code_r0x000180177dfd:
        puVar17 = auStack_c8;
        if (*(int32_t *)(arg1 + 0xa8) != 0x12d) goto code_r0x000180177fa4;
        var_88h = 0xc;
        var_80h = 0xf;
        var_90h._0_4_ = 0x65707954;
        var_98h = 0x2d746e65746e6f43;
        var_90h._4_4_ = 0;
        puVar12 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
        cVar2 = *(char *)((int64_t)puVar12 + 0x19);
        puVar18 = *(undefined8 **)(arg1 + 0x10);
        while (cVar2 == '\0') {
            piVar8 = &var_98h;
            if (0xf < (uint64_t)var_80h) {
                piVar8 = (int64_t *)var_98h;
            }
            piVar13 = puVar12 + 4;
            if (0xf < (uint64_t)puVar12[7]) {
                piVar13 = (int64_t *)*piVar13;
            }
            iVar6 = func_0x00018047b6d0(piVar13, piVar8);
            if (iVar6 < 0) {
                puVar15 = (undefined8 *)puVar12[2];
                puVar12 = puVar18;
            } else {
                puVar15 = (undefined8 *)*puVar12;
            }
            puVar18 = puVar12;
            puVar12 = puVar15;
            cVar2 = *(char *)((int64_t)puVar15 + 0x19);
        }
        if (*(char *)((int64_t)puVar18 + 0x19) == '\0') {
            piVar8 = puVar18 + 4;
            if (0xf < (uint64_t)puVar18[7]) {
                piVar8 = (int64_t *)*piVar8;
            }
            piVar13 = &var_98h;
            if (0xf < (uint64_t)var_80h) {
                piVar13 = (int64_t *)var_98h;
            }
            iVar6 = func_0x00018047b6d0(piVar13, piVar8);
            if (iVar6 < 0) goto code_r0x000180177ea2;
        } else {
code_r0x000180177ea2:
            puVar18 = *(undefined8 **)(arg1 + 0x10);
        }
        if (0xf < (uint64_t)var_80h) {
            iVar11 = var_98h;
            puVar16 = auStack_c8;
            if ((0xfff < var_80h + 1U) &&
               (iVar11 = *(int64_t *)(var_98h + -8), puVar16 = auStack_c8,
               0x1f < (var_98h - *(int64_t *)(var_98h + -8)) - 8U)) goto code_r0x000180177ed7;
            goto code_r0x000180177ee1;
        }
    } else {
        uVar14 = var_80h + 1;
        iVar11 = var_98h;
        if (uVar14 < 0x1000) {
code_r0x000180177c9a:
            func_0x000180459c3c(iVar11, uVar14);
            goto code_r0x000180177cad;
        }
        if ((var_98h - *(int64_t *)(var_98h + -8)) - 8U < 0x20) {
            uVar14 = var_80h + 0x28;
            iVar11 = *(int64_t *)(var_98h + -8);
            goto code_r0x000180177c9a;
        }
code_r0x000180177ed7:
        pcVar3 = (code *)swi(0x29);
        iVar11 = (*pcVar3)(5);
        puVar16 = auStack_c0;
code_r0x000180177ee1:
        *(undefined8 *)(puVar16 + -8) = 0x180177ee6;
        func_0x000180459c3c(iVar11);
    }
    var_88h = 0;
    var_80h = 0xf;
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xffffffffffffff69;
    _var_98h = auVar5 << 8;
    puVar17 = puVar16;
    if (puVar18 != *(undefined8 **)(arg1 + 0x10)) {
        puVar15 = puVar18 + 8;
        puVar12 = puVar15;
        if (0xf < (uint64_t)puVar18[0xb]) {
            puVar12 = (undefined8 *)*puVar15;
        }
        *(undefined8 *)(puVar16 + -8) = 0x180177f21;
        iVar11 = func_0x00018045bb90(puVar12, 0x1804a6298);
        if (iVar11 == 0) {
            iVar11 = puVar18[10];
            if ((uint64_t)(puVar18[0xb] - iVar11) < 0xb) {
                *(undefined8 *)(puVar16 + 0x20) = 0xb;
                *(undefined8 *)(puVar16 + -8) = 0x180177f8f;
                func_0x00018000ee80(puVar15, 0xb, 0, 0x1804a62d0);
            } else {
                puVar18[10] = iVar11 + 0xb;
                puVar12 = puVar15;
                if (0xf < (uint64_t)puVar18[0xb]) {
                    puVar12 = (undefined8 *)*puVar15;
                }
                *(undefined8 *)(puVar16 + -8) = 0x180177f69;
                func_0x000180498030(iVar11 + (int64_t)puVar12, 0x1804a62d0, 0xb);
                *(undefined *)(iVar11 + (int64_t)puVar12 + 0xb) = 0;
            }
            *(undefined8 *)(puVar16 + -8) = 0x180177fa4;
            func_0x00018000d970(puVar15, 0x1804a62a8, 0x25);
        }
    }
code_r0x000180177fa4:
    *(undefined8 *)(puVar17 + -8) = 0x180177fb0;
    func_0x000180459870(var_58h ^ (uint64_t)puVar17);
    return;
}

// ============================================================
// Function: FUN_180177fd0
// Address: 0x180177fd0
// Size: 663 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

void fcn.180177fd0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined8 *puVar16;
    undefined8 *puVar17;
    undefined8 uStack_d0;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar13 = auStack_c8;
    puVar14 = auStack_c8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    var_78h = 4;
    var_70h = 0xf;
    stack0xffffffffffffff7d = SUB1611(ZEXT816(0), 5);
    var_88h._0_5_ = 0x74736f48;
    piVar7 = (int64_t *)(arg1 + 0x10);
    puVar2 = (undefined8 *)*piVar7;
    cVar1 = *(char *)((int64_t)(undefined8 *)puVar2[1] + 0x19);
    puVar17 = puVar2;
    puVar16 = (undefined8 *)puVar2[1];
    while (cVar1 == '\0') {
        piVar10 = &var_88h;
        if (0xf < (uint64_t)var_70h) {
            piVar10 = (int64_t *)var_88h;
        }
        piVar9 = puVar16 + 4;
        if (0xf < (uint64_t)puVar16[7]) {
            piVar9 = (int64_t *)*piVar9;
        }
        iVar5 = func_0x00018047b6d0(piVar9, piVar10);
        if (iVar5 < 0) {
            puVar12 = (undefined8 *)puVar16[2];
            puVar16 = puVar17;
        } else {
            puVar12 = (undefined8 *)*puVar16;
        }
        puVar17 = puVar16;
        puVar16 = puVar12;
        cVar1 = *(char *)((int64_t)puVar12 + 0x19);
    }
    if (*(char *)((int64_t)puVar17 + 0x19) == '\0') {
        piVar10 = puVar17 + 4;
        if (0xf < (uint64_t)puVar17[7]) {
            piVar10 = (int64_t *)*piVar10;
        }
        piVar9 = &var_88h;
        if (0xf < (uint64_t)var_70h) {
            piVar9 = (int64_t *)var_88h;
        }
        iVar5 = func_0x00018047b6d0(piVar9, piVar10);
        if (iVar5 < 0) goto code_r0x0001801780ae;
    } else {
code_r0x0001801780ae:
        puVar17 = (undefined8 *)*piVar7;
    }
    if ((uint64_t)var_70h < 0x10) {
code_r0x0001801780f4:
        puVar15 = auStack_c8;
        if (puVar17 != puVar2) goto code_r0x000180178249;
        iVar5 = (int32_t)arg3;
        if (((iVar5 == 0) || (iVar5 == 0x50)) || (iVar5 == 0x1bb)) {
            var_98h = 4;
            var_90h = 0xf;
            stack0xffffffffffffff5d = SUB1611(ZEXT816(0), 5);
            var_a8h._0_5_ = 0x74736f48;
            piVar7 = (int64_t *)func_0x000180014c60(piVar7, &var_88h, &var_a8h);
            iVar8 = *piVar7;
            uVar6 = func_0x000180498cd0(arg2);
            func_0x00018000f180(iVar8 + 0x40, arg2, uVar6);
        } else {
            var_98h = 4;
            var_90h = 0xf;
            stack0xffffffffffffff5d = SUB1611(ZEXT816(0), 5);
            var_a8h._0_5_ = 0x74736f48;
            uVar6 = func_0x000180185af0(&var_68h, arg2, arg3 & 0xffffffff);
            piVar7 = (int64_t *)func_0x000180014c60(piVar7, &var_88h, &var_a8h);
            func_0x000180012c10(*piVar7 + 0x40, uVar6);
            if (0xf < (uint64_t)var_50h) {
                iVar4 = CONCAT71(var_68h._1_7_, (undefined)var_68h);
                iVar8 = iVar4;
                puVar13 = auStack_c8;
                if ((0xfff < var_50h + 1U) &&
                   (iVar8 = *(int64_t *)(iVar4 + -8), puVar13 = auStack_c8, 0x1f < (iVar4 - iVar8) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar8 = (*pcVar3)(5);
                    puVar13 = auStack_c0;
                }
                *(undefined8 *)(puVar13 + -8) = 0x1801781aa;
                func_0x000180459c3c(iVar8);
            }
            var_58h = 0;
            var_50h = 0xf;
            var_68h._0_1_ = 0;
            puVar14 = puVar13;
        }
        puVar15 = puVar14;
        if ((uint64_t)var_90h < 0x10) goto code_r0x000180178249;
        iVar8 = var_a8h;
        if ((0xfff < var_90h + 1U) &&
           (iVar8 = *(int64_t *)(var_a8h + -8), 0x1f < (var_a8h - *(int64_t *)(var_a8h + -8)) - 8U))
        goto code_r0x00018017823a;
    } else {
        uVar11 = var_70h + 1;
        iVar8 = var_88h;
        if (uVar11 < 0x1000) {
code_r0x0001801780e9:
            func_0x000180459c3c(iVar8, uVar11);
            goto code_r0x0001801780f4;
        }
        puVar15 = auStack_c8;
        if ((var_88h - *(int64_t *)(var_88h + -8)) - 8U < 0x20) {
            uVar11 = var_70h + 0x28;
            iVar8 = *(int64_t *)(var_88h + -8);
            goto code_r0x0001801780e9;
        }
code_r0x00018017823a:
        pcVar3 = (code *)swi(0x29);
        iVar8 = (*pcVar3)(5);
        puVar15 = puVar15 + 8;
    }
    *(undefined8 *)(puVar15 + -8) = 0x180178249;
    func_0x000180459c3c(iVar8);
code_r0x000180178249:
    *(undefined8 *)(puVar15 + -8) = 0x180178255;
    func_0x000180459870(var_48h ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_180178270
// Address: 0x180178270
// Size: 362 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180178270(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h)
{
    char cVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined8 *puVar8;
    undefined *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_88 [8];
    undefined auStack_80 [32];
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar9 = auStack_88;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    var_48h = 0;
    _var_58h = ZEXT816(0);
    var_40h = 0;
    var_60h = arg2;
    uVar4 = func_0x000180498cd0(arg3);
    func_0x000180004830(&var_58h, arg3, uVar4);
    puVar10 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
    cVar1 = *(char *)((int64_t)puVar10 + 0x19);
    puVar11 = *(undefined8 **)(arg1 + 0x10);
    while (cVar1 == '\0') {
        piVar6 = puVar10 + 4;
        piVar7 = &var_58h;
        if (0xf < (uint64_t)var_40h) {
            piVar7 = (int64_t *)var_58h;
        }
        if (0xf < (uint64_t)puVar10[7]) {
            piVar6 = (int64_t *)*piVar6;
        }
        iVar3 = func_0x00018047b6d0(piVar6, piVar7);
        if (iVar3 < 0) {
            puVar8 = (undefined8 *)puVar10[2];
            puVar10 = puVar11;
        } else {
            puVar8 = (undefined8 *)*puVar10;
        }
        puVar11 = puVar10;
        puVar10 = puVar8;
        cVar1 = *(char *)((int64_t)puVar8 + 0x19);
    }
    if (*(char *)((int64_t)puVar11 + 0x19) == '\0') {
        piVar6 = puVar11 + 4;
        if (0xf < (uint64_t)puVar11[7]) {
            piVar6 = (int64_t *)*piVar6;
        }
        piVar7 = &var_58h;
        if (0xf < (uint64_t)var_40h) {
            piVar7 = (int64_t *)var_58h;
        }
        iVar3 = func_0x00018047b6d0(piVar7, piVar6);
        if (-1 < iVar3) goto code_r0x00018017834c;
    }
    puVar11 = *(undefined8 **)(arg1 + 0x10);
code_r0x00018017834c:
    if (0xf < (uint64_t)var_40h) {
        iVar5 = var_58h;
        puVar9 = auStack_88;
        if ((0xfff < var_40h + 1U) &&
           (iVar5 = *(int64_t *)(var_58h + -8), puVar9 = auStack_88, 0x1f < (var_58h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar9 = auStack_80;
        }
        *(undefined8 *)(puVar9 + -8) = 0x18017838e;
        func_0x000180459c3c(iVar5);
    }
    *(undefined8 *)(puVar9 + 0x40) = 0;
    *(undefined8 *)(puVar9 + 0x48) = 0xf;
    puVar9[0x30] = 0;
    if (puVar11 != *(undefined8 **)(arg1 + 0x10)) {
        arg4 = (int64_t)(puVar11 + 8);
    }
    *(undefined8 *)(puVar9 + -8) = 0x1801783b6;
    func_0x00018000b4d0(arg2, arg4);
    *(undefined8 *)(puVar9 + -8) = 0x1801783c6;
    func_0x000180459870(*(uint64_t *)(puVar9 + 0x50) ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_1801783e0
// Address: 0x1801783e0
// Size: 538 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2eh
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h

void fcn.1801783e0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    puVar5 = auStack_68;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    var_28h = 10;
    var_20h = 0xf;
    var_30h._0_2_ = 0x746e;
    var_38h = 0x6567412d72657355;
    var_30h._2_6_ = 0;
    piVar2 = (int64_t *)func_0x000180014c60(arg1 + 0x10, &var_48h, &var_38h);
    func_0x00018000f180(*piVar2 + 0x40, 0x1804a6350, 0x6e);
    if ((uint64_t)var_20h < 0x10) {
code_r0x0001801784a7:
        var_28h = 6;
        var_20h = 0xf;
        stack0xffffffffffffffcf = SUB169(ZEXT816(0), 7);
        var_38h._0_7_ = 0x747065636341;
        piVar2 = (int64_t *)func_0x000180014c60(arg1 + 0x10, &var_48h, &var_38h);
        func_0x00018000f180(*piVar2 + 0x40, 0x1804a63c8, 3);
        if ((uint64_t)var_20h < 0x10) goto code_r0x00018017854b;
        iVar3 = var_38h;
        puVar5 = auStack_68;
        if ((0xfff < var_20h + 1U) &&
           (iVar3 = *(int64_t *)(var_38h + -8), puVar5 = auStack_68, 0x1f < (var_38h - *(int64_t *)(var_38h + -8)) - 8U)
           ) goto code_r0x00018017853c;
    } else {
        uVar4 = var_20h + 1;
        iVar3 = var_38h;
        if (uVar4 < 0x1000) {
code_r0x0001801784a2:
            func_0x000180459c3c(iVar3, uVar4);
            goto code_r0x0001801784a7;
        }
        if ((var_38h - *(int64_t *)(var_38h + -8)) - 8U < 0x20) {
            uVar4 = var_20h + 0x28;
            iVar3 = *(int64_t *)(var_38h + -8);
            goto code_r0x0001801784a2;
        }
code_r0x00018017853c:
        pcVar1 = (code *)swi(0x29);
        iVar3 = (*pcVar1)(5);
        puVar5 = auStack_60;
    }
    *(undefined8 *)(puVar5 + -8) = 0x18017854b;
    func_0x000180459c3c(iVar3);
code_r0x00018017854b:
    *(undefined4 *)(arg1 + 0xe0) = 1;
    *(undefined8 *)(puVar5 + -8) = 0x18017856e;
    func_0x00018000f180(arg1 + 0x108, 0x180623910, 4);
    *(undefined8 *)(puVar5 + -8) = 0x180178587;
    func_0x00018000f180(arg1 + 0x128, 0x1804a63d0, 9);
    *(undefined4 *)(arg1 + 0x148) = 0x50;
    *(undefined8 *)(puVar5 + -8) = 0x1801785aa;
    func_0x00018000f180(arg1 + 0x150, 0x1806238f0, 1);
    *(undefined4 *)(arg1 + 0x1a8) = 0xa003c;
    *(undefined4 *)(arg1 + 0x1ac) = 1;
    *(undefined4 *)(arg1 + 0x1b0) = 1000;
    *(uint32_t *)(arg1 + 0x1b4) = *(uint32_t *)(arg1 + 0x1b4) & 0xfffffff9 | 1;
    *(undefined8 *)(puVar5 + -8) = 0x1801785e7;
    func_0x000180459870(*(uint64_t *)(puVar5 + 0x50) ^ (uint64_t)puVar5);
    return;
}

// ============================================================
// Function: FUN_180178600
// Address: 0x180178600
// Size: 412 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180178600(int64_t arg1)
{
    char cVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined8 *puVar8;
    undefined *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    puVar9 = auStack_58;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    var_28h = 0;
    var_20h = 0;
    _var_38h = ZEXT816(0);
    puVar4 = (undefined4 *)func_0x000180459890(0x20);
    var_38h = (int64_t)puVar4;
    var_28h = 0x11;
    var_20h = 0x1f;
    *puVar4 = 0x6e617254;
    puVar4[1] = 0x72656673;
    puVar4[2] = 0x636e452d;
    puVar4[3] = 0x6e69646f;
    *(undefined *)(puVar4 + 4) = 0x67;
    *(undefined *)((int64_t)puVar4 + 0x11) = 0;
    puVar10 = (undefined8 *)(*(undefined8 **)(arg1 + 0x10))[1];
    cVar1 = *(char *)((int64_t)puVar10 + 0x19);
    puVar11 = *(undefined8 **)(arg1 + 0x10);
    while (cVar1 == '\0') {
        piVar7 = puVar10 + 4;
        piVar6 = &var_38h;
        if (0xf < (uint64_t)var_20h) {
            piVar6 = (int64_t *)var_38h;
        }
        if (0xf < (uint64_t)puVar10[7]) {
            piVar7 = (int64_t *)*piVar7;
        }
        iVar3 = func_0x00018047b6d0(piVar7, piVar6);
        if (iVar3 < 0) {
            puVar8 = (undefined8 *)puVar10[2];
            puVar10 = puVar11;
        } else {
            puVar8 = (undefined8 *)*puVar10;
        }
        puVar11 = puVar10;
        puVar10 = puVar8;
        cVar1 = *(char *)((int64_t)puVar8 + 0x19);
    }
    if (*(char *)((int64_t)puVar11 + 0x19) == '\0') {
        piVar7 = puVar11 + 4;
        if (0xf < (uint64_t)puVar11[7]) {
            piVar7 = (int64_t *)*piVar7;
        }
        piVar6 = &var_38h;
        if (0xf < (uint64_t)var_20h) {
            piVar6 = (int64_t *)var_38h;
        }
        iVar3 = func_0x00018047b6d0(piVar6, piVar7);
        if (-1 < iVar3) goto code_r0x0001801786fc;
    }
    puVar11 = *(undefined8 **)(arg1 + 0x10);
code_r0x0001801786fc:
    if (0xf < (uint64_t)var_20h) {
        iVar5 = var_38h;
        puVar9 = auStack_58;
        if ((0xfff < var_20h + 1U) &&
           (iVar5 = *(int64_t *)(var_38h + -8), puVar9 = auStack_58, 0x1f < (var_38h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar9 = auStack_50;
        }
        *(undefined8 *)(puVar9 + -8) = 0x18017873e;
        func_0x000180459c3c(iVar5);
    }
    *(undefined8 *)(puVar9 + 0x30) = 0;
    *(undefined8 *)(puVar9 + 0x38) = 0xf;
    puVar9[0x20] = 0;
    if (puVar11 != *(undefined8 **)(arg1 + 0x10)) {
        piVar7 = puVar11 + 8;
        if (0xf < (uint64_t)puVar11[0xb]) {
            piVar7 = (int64_t *)*piVar7;
        }
        *(undefined8 *)(puVar9 + -8) = 0x180178775;
        func_0x00018047b6d0(piVar7, 0x1804a62f0);
    }
    *(undefined8 *)(puVar9 + -8) = 0x18017878c;
    func_0x000180459870(*(uint64_t *)(puVar9 + 0x40) ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_1801787a0
// Address: 0x1801787a0
// Size: 936 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h

void fcn.1801787a0(int64_t arg1)
{
    code *pcVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t **ppiVar10;
    undefined *puVar11;
    uint64_t unaff_RDI;
    uint64_t uVar12;
    uint64_t unaff_R15;
    bool bVar13;
    undefined8 uStack_110;
    undefined auStack_108 [8];
    undefined auStack_100 [32];
    int64_t var_e0h;
    undefined4 uStack_d8;
    undefined4 uStack_d4;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    undefined4 uStack_b4;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    uint16_t var_74h;
    int64_t var_72h;
    int64_t var_6ah;
    int64_t var_60h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_108;
    func_0x0001801770c0();
    ppiVar10 = (int64_t **)(arg1 + 0xe8);
    ppiVar5 = ppiVar10;
    if (0xf < *(uint64_t *)(arg1 + 0x100)) {
        ppiVar5 = (int64_t **)*ppiVar10;
    }
    func_0x000180181000(&var_80h, ppiVar5);
    uVar7 = (uint64_t)(uint16_t)var_80h;
    _var_a0h = ZEXT816(0);
    var_90h = 0;
    var_88h = 0;
    if (*(uint64_t *)(arg1 + 0xf8) < uVar7) goto code_r0x000180178b42;
    uVar3 = *(uint64_t *)(arg1 + 0xf8) - uVar7;
    uVar12 = (uint64_t)var_80h._2_2_;
    if (uVar3 < var_80h._2_2_) {
        uVar12 = uVar3;
    }
    ppiVar5 = ppiVar10;
    if (0xf < *(uint64_t *)(arg1 + 0x100)) {
        ppiVar5 = (int64_t **)*ppiVar10;
    }
    func_0x000180004830(&var_a0h, (int64_t)ppiVar5 + uVar7, uVar12);
    piVar9 = (int64_t *)(arg1 + 0x128);
    func_0x00018000b4d0(&var_e0h, piVar9);
    if ((uint16_t)var_72h == 0) {
code_r0x0001801788f3:
        if ((uint16_t)var_60h == 0) {
            iVar6 = 0;
            piVar8 = &var_a0h;
            if (0xf < (uint64_t)var_88h) {
                piVar8 = (int64_t *)var_a0h;
            }
            do {
                iVar4 = iVar6;
                bVar13 = *(char *)((int64_t)piVar8 + iVar4) == *(char *)(iVar4 + 0x1804a60d0);
                if (!bVar13) goto code_r0x000180178939;
                iVar6 = iVar4 + 1;
            } while (iVar4 + 1 != 6);
            bVar13 = *(char *)((int64_t)piVar8 + iVar4) == *(char *)(iVar4 + 0x1804a60d0);
code_r0x000180178939:
            uVar2 = 0x1bb;
            if (!bVar13) {
                uVar2 = 0x50;
            }
        } else {
            uVar2 = (uint32_t)(uint16_t)var_60h;
        }
        unaff_RDI = var_a0h;
        unaff_R15 = var_88h;
        if ((*(uint8_t *)(arg1 + 0x1b4) & 2) == 0) {
            if ((int64_t *)(arg1 + 0x108) != &var_a0h) {
                piVar8 = &var_a0h;
                if (0xf < (uint64_t)var_88h) {
                    piVar8 = (int64_t *)var_a0h;
                }
                func_0x00018000f180((int64_t *)(arg1 + 0x108), piVar8, var_90h);
                unaff_RDI = var_a0h;
            }
            unaff_R15 = var_88h;
            if (piVar9 != &var_e0h) {
                piVar8 = &var_e0h;
                if (0xf < (uint64_t)var_c8h) {
                    piVar8 = (int64_t *)CONCAT44(var_e0h._4_4_, (undefined4)var_e0h);
                }
                func_0x00018000f180(piVar9, piVar8, var_d0h);
            }
            *(uint32_t *)(arg1 + 0x148) = uVar2;
        }
        piVar9 = &var_e0h;
        if (0xf < (uint64_t)var_c8h) {
            piVar9 = (int64_t *)CONCAT44(var_e0h._4_4_, (undefined4)var_e0h);
        }
        fcn.180177fd0(arg1, (int64_t)piVar9, (uint64_t)uVar2);
        puVar11 = auStack_108;
        if ((int16_t)var_6ah == 0) goto code_r0x000180178a6c;
        uVar7 = (uint64_t)var_72h._6_2_;
        _var_c0h = ZEXT816(0);
        var_b0h = 0;
        var_a8h = 0;
        if (*(uint64_t *)(arg1 + 0xf8) < uVar7) goto code_r0x000180178b3c;
        iVar4 = *(uint64_t *)(arg1 + 0xf8) - uVar7;
        iVar6 = -1;
        if (iVar4 != -1) {
            iVar6 = iVar4;
        }
        ppiVar5 = ppiVar10;
        if (0xf < *(uint64_t *)(arg1 + 0x100)) {
            ppiVar5 = (int64_t **)*ppiVar10;
        }
        func_0x000180004830(&var_c0h, (int64_t)ppiVar5 + uVar7, iVar6);
        func_0x000180012c10(arg1 + 0x150, &var_c0h);
        puVar11 = auStack_108;
        if ((uint64_t)var_a8h < 0x10) goto code_r0x000180178a6c;
        iVar6 = var_c0h;
        puVar11 = auStack_108;
        if ((0xfff < var_a8h + 1U) &&
           (iVar6 = *(int64_t *)(var_c0h + -8), puVar11 = auStack_108,
           0x1f < (var_c0h - *(int64_t *)(var_c0h + -8)) - 8U)) goto code_r0x000180178a5d;
    } else {
        uVar7 = (uint64_t)var_74h;
        _var_c0h = ZEXT816(0);
        var_b0h = 0;
        var_a8h = 0;
        if (*(uint64_t *)(arg1 + 0xf8) < uVar7) {
code_r0x000180178b3c:
            _var_c0h = ZEXT816(0);
            var_a8h = 0;
            var_b0h = 0;
            func_0x00018000f930();
code_r0x000180178b42:
            func_0x00018000f930();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar3 = *(uint64_t *)(arg1 + 0xf8) - uVar7;
        uVar12 = (uint64_t)(uint16_t)var_72h;
        if (uVar3 < (uint16_t)var_72h) {
            uVar12 = uVar3;
        }
        ppiVar5 = ppiVar10;
        if (0xf < *(uint64_t *)(arg1 + 0x100)) {
            ppiVar5 = (int64_t **)*ppiVar10;
        }
        func_0x000180004830(&var_c0h, (int64_t)ppiVar5 + uVar7, uVar12);
        if ((uint64_t)var_c8h < 0x10) {
code_r0x0001801788e2:
            var_e0h._0_4_ = (undefined4)var_c0h;
            var_e0h._4_4_ = var_c0h._4_4_;
            uStack_d8 = uStack_b8;
            uStack_d4 = uStack_b4;
            var_d0h = var_b0h;
            var_c8h = var_a8h;
            goto code_r0x0001801788f3;
        }
        iVar6 = CONCAT44(var_e0h._4_4_, (undefined4)var_e0h);
        uVar7 = var_c8h + 1;
        if (uVar7 < 0x1000) {
code_r0x0001801788dd:
            func_0x000180459c3c(iVar6, uVar7);
            goto code_r0x0001801788e2;
        }
        if ((iVar6 - *(int64_t *)(iVar6 + -8)) - 8U < 0x20) {
            uVar7 = var_c8h + 0x28;
            iVar6 = *(int64_t *)(iVar6 + -8);
            goto code_r0x0001801788dd;
        }
code_r0x000180178a5d:
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar11 = auStack_100;
    }
    *(undefined8 *)(puVar11 + -8) = 0x180178a6c;
    func_0x000180459c3c(iVar6);
code_r0x000180178a6c:
    if (var_6ah._4_2_ != 0) {
        if (0xf < *(uint64_t *)(arg1 + 0x100)) {
            ppiVar10 = (int64_t **)*ppiVar10;
        }
        *(undefined8 *)(puVar11 + -8) = 0x180178a90;
        func_0x000180188bc0((uint64_t)var_6ah._2_2_ + (int64_t)ppiVar10, arg1 + 0x170);
    }
    if (0xf < (uint64_t)var_c8h) {
        iVar6 = *(int64_t *)(puVar11 + 0x28);
        iVar4 = iVar6;
        if ((0xfff < var_c8h + 1U) && (iVar4 = *(int64_t *)(iVar6 + -8), 0x1f < (iVar6 - iVar4) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar4 = (*pcVar1)(5);
            puVar11 = puVar11 + 8;
        }
        *(undefined8 *)(puVar11 + -8) = 0x180178ad2;
        func_0x000180459c3c(iVar4);
    }
    var_d0h = 0;
    var_c8h = 0xf;
    puVar11[0x28] = 0;
    if (0xf < unaff_R15) {
        uVar7 = unaff_RDI;
        if (0xfff < unaff_R15 + 1) {
            uVar7 = *(uint64_t *)(unaff_RDI - 8);
            uVar12 = (unaff_RDI - uVar7) - 8;
            if (0x1f < uVar12) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar11 = puVar11 + 8;
                uVar7 = uVar12;
            }
        }
        *(undefined8 *)(puVar11 + -8) = 0x180178b1c;
        func_0x000180459c3c(uVar7);
    }
    *(undefined8 *)(puVar11 + -8) = 0x180178b28;
    func_0x000180459870(var_58h ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_180178b50
// Address: 0x180178b50
// Size: 456 bytes
// ============================================================
void fcn.180178b50(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    undefined *puVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    undefined *puVar6;
    
    *(undefined4 *)(arg1 + 0xc) = 0x10001;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    *(undefined4 *)(arg1 + 0xa8) = 0;
    iVar1 = *(int64_t *)(arg1 + 0x10);
    func_0x000180015170(arg1 + 0x10, arg1 + 0x10, *(undefined8 *)(iVar1 + 8));
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined8 *)(arg1 + 0x18) = 0;
    iVar1 = *(int64_t *)(arg1 + 0x28);
    iVar5 = *(int64_t *)(arg1 + 0x20);
    if (iVar5 != iVar1) {
        do {
            func_0x000180175e80(iVar5);
            iVar5 = iVar5 + 0xc0;
        } while (iVar5 != iVar1);
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x20);
    }
    puVar4 = (undefined8 *)(arg1 + 0x38);
    *(undefined8 *)(arg1 + 0x48) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x50)) {
        puVar4 = (undefined8 *)*puVar4;
    }
    *(undefined *)puVar4 = 0;
    // switch table (8 cases) at 0x180178cf8
    switch(*(undefined *)(arg1 + 0xb0)) {
    case 1:
        func_0x000180178f10(*(undefined8 *)(arg1 + 0xb8));
        break;
    case 2:
        puVar4 = *(undefined8 **)(arg1 + 0xb8);
        puVar3 = (undefined *)puVar4[1];
        puVar6 = (undefined *)*puVar4;
        if (puVar6 != puVar3) {
            do {
                func_0x000180178f50(puVar6 + 8, *puVar6);
                puVar6 = puVar6 + 0x10;
            } while (puVar6 != puVar3);
            puVar4[1] = *puVar4;
        }
        break;
    case 3:
        puVar4 = *(undefined8 **)(arg1 + 0xb8);
        puVar4[2] = 0;
        if (0xf < (uint64_t)puVar4[3]) {
            puVar4 = (undefined8 *)*puVar4;
        }
        *(undefined *)puVar4 = 0;
        break;
    case 4:
        *(undefined *)(arg1 + 0xb8) = 0;
        break;
    case 5:
    case 6:
    case 7:
        *(undefined8 *)(arg1 + 0xb8) = 0;
        break;
    case 8:
        piVar2 = *(int64_t **)(arg1 + 0xb8);
        if (*piVar2 != piVar2[1]) {
            piVar2[1] = *piVar2;
        }
    }
    iVar1 = *(int64_t *)(arg1 + 0xc0);
    func_0x000180174530(arg1 + 0xc0, arg1 + 0xc0, *(undefined8 *)(iVar1 + 8));
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined8 *)(arg1 + 200) = 0;
    iVar1 = *(int64_t *)(arg1 + 0xd0);
    func_0x000180015170(arg1 + 0xd0, arg1 + 0xd0, *(undefined8 *)(iVar1 + 8));
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined8 *)(arg1 + 0xd8) = 0;
    return;
}

// ============================================================
// Function: FUN_180178d20
// Address: 0x180178d20
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2eh
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h

void fcn.180178d20(int64_t arg1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t unaff_RBX;
    int64_t var_8h;
    
    fcn.180178b50(arg1);
    fcn.1801783e0(arg1, unaff_RBX);
    puVar2 = (undefined8 *)(arg1 + 0xe8);
    *(undefined8 *)(arg1 + 0xf8) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x100)) {
        puVar2 = (undefined8 *)*puVar2;
    }
    *(undefined *)puVar2 = 0;
    iVar1 = *(int64_t *)(arg1 + 0x170);
    fcn.180015170(unaff_RBX);
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined8 *)(arg1 + 0x178) = 0;
    return;
}

// ============================================================
// Function: FUN_180178da0
// Address: 0x180178da0
// Size: 30 bytes
// ============================================================
void fcn.180178da0(int64_t arg1)
{
    fcn.180178b50(arg1);
    *(undefined4 *)(arg1 + 0xe0) = 200;
    return;
}

// ============================================================
// Function: FUN_180178dc0
// Address: 0x180178dc0
// Size: 169 bytes
// ============================================================
void fcn.180178dc0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined *puVar5;
    undefined auStack_58 [8];
    undefined auStack_50 [32];
    
    puVar5 = *(undefined **)arg1;
    if (puVar5 != (undefined *)0x0) {
        puVar1 = *(undefined **)(arg1 + 8);
        for (; puVar5 != puVar1; puVar5 = puVar5 + 0x10) {
            func_0x000180178f50(puVar5 + 8, *puVar5);
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar5 = auStack_58;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar2 & 0xfffffffffffffff0U)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar5 = auStack_58, 0x1f < (iVar2 - iVar4) - 8U)) {
            pcVar3 = (code *)swi(0x29);
            iVar4 = (*pcVar3)(5);
            puVar5 = auStack_50;
        }
        *(undefined8 *)(puVar5 + -8) = 0x180178e43;
        fcn.180459c3c(iVar4);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x10 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x10 + arg2;
    return;
}

// ============================================================
// Function: FUN_180178e70
// Address: 0x180178e70
// Size: 147 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180178e70(int64_t arg1)
{
    undefined *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = *(undefined **)arg1;
    if (puVar5 != (undefined *)0x0) {
        puVar1 = *(undefined **)(arg1 + 8);
        for (; puVar5 != puVar1; puVar5 = puVar5 + 0x10) {
            func_0x000180178f50(puVar5 + 8, *puVar5);
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar5 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar2 & 0xfffffffffffffff0U)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar5 = auStack_28, 0x1f < (iVar2 - iVar4) - 8U)) {
            pcVar3 = (code *)swi(0x29);
            iVar4 = (*pcVar3)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x180178ee6;
        fcn.180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180178f10
// Address: 0x180178f10
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180178f10(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)arg1;
    fcn.1801745c0(arg1, arg1, *(undefined8 *)(iVar1 + 8));
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined8 *)(arg1 + 8) = 0;
    return;
}

// ============================================================
// Function: FUN_180178f50
// Address: 0x180178f50
// Size: 1175 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_67h
// WARNING: [rz-ghidra] Detected overlap for variable var_63h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

void fcn.180178f50(int64_t arg1)
{
    char cVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int64_t **ppiVar4;
    undefined8 uVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t **ppiVar10;
    int64_t iVar11;
    char in_DL;
    uint64_t uVar12;
    undefined8 uVar13;
    int64_t **ppiVar14;
    undefined4 *puVar15;
    int64_t *piVar16;
    undefined *puVar17;
    undefined *puVar18;
    undefined4 *puVar19;
    int64_t *piVar20;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t **var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar17 = auStack_88;
    puVar18 = auStack_88;
    if ((in_DL == '\x01') || (in_DL == '\x02')) {
        if (*(int64_t *)arg1 == 0) {
            return;
        }
        _var_58h = ZEXT816(0);
        var_48h = 0;
        iVar2 = (*(int64_t **)arg1)[1];
        if (in_DL == '\x02') {
            func_0x00018017c390(&var_58h, iVar2 - **(int64_t **)arg1 >> 4);
            puVar15 = (undefined4 *)**(undefined8 **)arg1;
            puVar3 = (undefined4 *)(*(undefined8 **)arg1)[1];
            if (puVar15 == puVar3) {
code_r0x0001801790bb:
                puVar19 = (undefined4 *)var_50h;
            } else {
                puVar19 = (undefined4 *)var_50h;
                do {
                    if (puVar19 == (undefined4 *)var_48h) {
                        func_0x000180174370(&var_58h, puVar19, puVar15);
                        puVar19 = (undefined4 *)var_50h;
                    } else {
                        uVar7 = puVar15[1];
                        uVar8 = puVar15[2];
                        uVar9 = puVar15[3];
                        *puVar19 = *puVar15;
                        puVar19[1] = uVar7;
                        puVar19[2] = uVar8;
                        puVar19[3] = uVar9;
                        *(undefined *)puVar15 = 0;
                        *(undefined8 *)(puVar15 + 2) = 0;
                        puVar19 = (undefined4 *)(var_50h + 0x10);
                        var_50h = (int64_t)puVar19;
                    }
                    puVar15 = puVar15 + 4;
                } while (puVar15 != puVar3);
            }
        } else {
            func_0x00018017c390(&var_58h, iVar2);
            ppiVar14 = (int64_t **)***(int64_t ***)arg1;
            if (*(char *)((int64_t)ppiVar14 + 0x19) != '\0') goto code_r0x0001801790bb;
            puVar19 = (undefined4 *)var_50h;
            do {
                if (puVar19 == (undefined4 *)var_48h) {
                    func_0x000180174370(&var_58h, puVar19);
                    puVar19 = (undefined4 *)var_50h;
                } else {
                    uVar7 = *(undefined4 *)((int64_t)ppiVar14 + 0x44);
                    uVar8 = *(undefined4 *)(ppiVar14 + 9);
                    uVar9 = *(undefined4 *)((int64_t)ppiVar14 + 0x4c);
                    *puVar19 = *(undefined4 *)(ppiVar14 + 8);
                    puVar19[1] = uVar7;
                    puVar19[2] = uVar8;
                    puVar19[3] = uVar9;
                    *(undefined *)(ppiVar14 + 8) = 0;
                    ppiVar14[9] = (int64_t *)0x0;
                    puVar19 = (undefined4 *)(var_50h + 0x10);
                    var_50h = (int64_t)puVar19;
                }
                ppiVar4 = (int64_t **)ppiVar14[2];
                if (*(char *)((int64_t)ppiVar4 + 0x19) == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar4 + 0x19);
                    ppiVar14 = ppiVar4;
                    ppiVar4 = (int64_t **)*ppiVar4;
                    while (cVar1 == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar4 + 0x19);
                        ppiVar14 = ppiVar4;
                        ppiVar4 = (int64_t **)*ppiVar4;
                    }
                } else {
                    cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                    ppiVar10 = (int64_t **)ppiVar14[1];
                    ppiVar4 = ppiVar14;
                    while ((ppiVar14 = ppiVar10, cVar1 == '\0' && (ppiVar4 == (int64_t **)ppiVar14[2]))) {
                        cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                        ppiVar10 = (int64_t **)ppiVar14[1];
                        ppiVar4 = ppiVar14;
                    }
                }
            } while (*(char *)((int64_t)ppiVar14 + 0x19) == '\0');
        }
        puVar15 = (undefined4 *)var_58h;
        if ((undefined4 *)var_58h != puVar19) {
            do {
                var_68h._0_1_ = *(char *)(puVar19 + -4);
                var_68h._1_4_ = *(undefined4 *)((int64_t)puVar19 + -0xf);
                var_68h._5_2_ = *(undefined2 *)((int64_t)puVar19 + -0xb);
                var_68h._7_1_ = *(undefined *)((int64_t)puVar19 + -9);
                var_60h = *(int64_t ***)(puVar19 + -2);
                *(undefined *)(puVar19 + -4) = 0;
                *(undefined8 *)(puVar19 + -2) = 0;
                fcn.180178f50(var_50h + -8);
                puVar19 = (undefined4 *)(var_50h + -0x10);
                var_50h = (int64_t)puVar19;
                if ((char)var_68h == '\x02') {
                    piVar16 = var_60h[1];
                    ppiVar14 = var_60h;
                    for (piVar20 = *var_60h; var_60h = ppiVar14, piVar20 != piVar16; piVar20 = piVar20 + 2) {
                        if (puVar19 == (undefined4 *)var_48h) {
                            func_0x000180174370(&var_58h, puVar19, piVar20);
                            puVar19 = (undefined4 *)var_50h;
                        } else {
                            uVar7 = *(undefined4 *)((int64_t)piVar20 + 4);
                            uVar8 = *(undefined4 *)(piVar20 + 1);
                            uVar9 = *(undefined4 *)((int64_t)piVar20 + 0xc);
                            *puVar19 = *(undefined4 *)piVar20;
                            puVar19[1] = uVar7;
                            puVar19[2] = uVar8;
                            puVar19[3] = uVar9;
                            *(undefined *)piVar20 = 0;
                            piVar20[1] = 0;
                            puVar19 = (undefined4 *)(var_50h + 0x10);
                            var_50h = (int64_t)puVar19;
                        }
                        ppiVar14 = var_60h;
                    }
                    piVar16 = *ppiVar14;
                    piVar20 = ppiVar14[1];
                    if (piVar16 != piVar20) {
                        do {
                            fcn.180178f50((int64_t)(piVar16 + 1));
                            piVar16 = piVar16 + 2;
                        } while (piVar16 != piVar20);
                        ppiVar14[1] = *ppiVar14;
                    }
                } else if ((char)var_68h == '\x01') {
                    ppiVar14 = (int64_t **)**var_60h;
                    cVar1 = *(char *)((int64_t)ppiVar14 + 0x19);
                    ppiVar4 = var_60h;
                    while (var_60h = ppiVar4, cVar1 == '\0') {
                        if (puVar19 == (undefined4 *)var_48h) {
                            func_0x000180174370(&var_58h);
                            puVar19 = (undefined4 *)var_50h;
                        } else {
                            uVar7 = *(undefined4 *)((int64_t)ppiVar14 + 0x44);
                            uVar8 = *(undefined4 *)(ppiVar14 + 9);
                            uVar9 = *(undefined4 *)((int64_t)ppiVar14 + 0x4c);
                            *puVar19 = *(undefined4 *)(ppiVar14 + 8);
                            puVar19[1] = uVar7;
                            puVar19[2] = uVar8;
                            puVar19[3] = uVar9;
                            *(undefined *)(ppiVar14 + 8) = 0;
                            ppiVar14[9] = (int64_t *)0x0;
                            puVar19 = (undefined4 *)(var_50h + 0x10);
                            var_50h = (int64_t)puVar19;
                        }
                        ppiVar4 = (int64_t **)ppiVar14[2];
                        if (*(char *)((int64_t)ppiVar4 + 0x19) == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar4 + 0x19);
                            ppiVar14 = ppiVar4;
                            ppiVar4 = (int64_t **)*ppiVar4;
                            while (cVar1 == '\0') {
                                cVar1 = *(char *)((int64_t)*ppiVar4 + 0x19);
                                ppiVar14 = ppiVar4;
                                ppiVar4 = (int64_t **)*ppiVar4;
                            }
                        } else {
                            cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                            ppiVar10 = (int64_t **)ppiVar14[1];
                            ppiVar4 = ppiVar14;
                            while ((ppiVar14 = ppiVar10, cVar1 == '\0' && (ppiVar4 == (int64_t **)ppiVar14[2]))) {
                                cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                                ppiVar10 = (int64_t **)ppiVar14[1];
                                ppiVar4 = ppiVar14;
                            }
                        }
                        ppiVar4 = var_60h;
                        cVar1 = *(char *)((int64_t)ppiVar14 + 0x19);
                    }
                    piVar16 = *ppiVar4;
                    fcn.1801745c0(ppiVar4, ppiVar4, piVar16[1]);
                    piVar16[1] = (int64_t)piVar16;
                    *piVar16 = (int64_t)piVar16;
                    piVar16[2] = (int64_t)piVar16;
                    ppiVar4[1] = (int64_t *)0x0;
                }
                fcn.180178f50((int64_t)&var_60h);
                puVar15 = (undefined4 *)var_58h;
                puVar19 = (undefined4 *)var_50h;
            } while (var_58h != var_50h);
        }
        if (puVar15 == (undefined4 *)0x0) goto code_r0x000180179319;
        if (puVar15 != puVar19) {
            do {
                fcn.180178f50((int64_t)(puVar15 + 2));
                puVar15 = puVar15 + 4;
            } while (puVar15 != puVar19);
            puVar15 = (undefined4 *)var_58h;
        }
        uVar12 = var_48h - (int64_t)puVar15 & 0xfffffffffffffff0;
        if (uVar12 < 0x1000) {
            fcn.180459c3c(puVar15);
            goto code_r0x000180179319;
        }
        piVar16 = (int64_t *)((int64_t)puVar15 + (-8 - *(int64_t *)(puVar15 + -2)));
        if (piVar16 < (int64_t *)0x20) {
            fcn.180459c3c(*(int64_t *)(puVar15 + -2), uVar12 + 0x27);
            goto code_r0x000180179319;
        }
code_r0x00018017936a:
        pcVar6 = (code *)swi(0x29);
        iVar11 = (*pcVar6)(5);
        puVar17 = auStack_80;
code_r0x000180179374:
        *(undefined8 *)(puVar17 + -8) = 0x180179379;
        fcn.180459c3c(iVar11);
        *piVar16 = 0;
        piVar16[1] = 0;
        piVar16[2] = 0;
    } else {
        if (((in_DL == '\x03') || (in_DL == '\b')) && (*(int64_t *)arg1 == 0)) {
            return;
        }
code_r0x000180179319:
        if (in_DL == '\x01') {
            piVar16 = *(int64_t **)arg1;
            fcn.1801745c0(piVar16, piVar16, *(undefined8 *)(*piVar16 + 8));
            fcn.180459c3c(*piVar16, 0x50);
            uVar13 = 0x10;
            goto code_r0x0001801793d0;
        }
        if (in_DL == '\x02') {
            fcn.180178e70(*(int64_t *)arg1);
            uVar13 = 0x18;
            puVar18 = auStack_88;
            goto code_r0x0001801793d0;
        }
        if (in_DL == '\x03') {
            fcn.180004e40(*(undefined8 *)arg1);
            uVar13 = 0x20;
            puVar18 = auStack_88;
            goto code_r0x0001801793d0;
        }
        if (in_DL != '\b') {
            return;
        }
        piVar16 = *(int64_t **)arg1;
        iVar2 = *piVar16;
        if (iVar2 != 0) {
            iVar11 = iVar2;
            puVar17 = auStack_88;
            if ((0xfff < (uint64_t)(piVar16[2] - iVar2)) &&
               (iVar11 = *(int64_t *)(iVar2 + -8), puVar17 = auStack_88, 0x1f < (iVar2 - iVar11) - 8U))
            goto code_r0x00018017936a;
            goto code_r0x000180179374;
        }
    }
    uVar13 = 0x28;
    puVar18 = puVar17;
code_r0x0001801793d0:
    uVar5 = *(undefined8 *)arg1;
    *(undefined8 *)(puVar18 + -8) = 0x1801793d8;
    fcn.180459c3c(uVar5, uVar13);
    return;
}

// ============================================================
// Function: FUN_1801793f0
// Address: 0x1801793f0
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801793f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    char cVar1;
    int64_t *piVar2;
    code **ppcVar3;
    int64_t **ppiVar4;
    int16_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    undefined8 *puVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t iVar12;
    undefined *puVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    uint64_t uVar17;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    // switch table (10 cases) at 0x180179cf4
    switch(*(undefined *)arg2) {
    case 0:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        break;
    case 1:
        piVar7 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar7;
        if (*(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == 0) {
            (*ppcVar3[1])(piVar7, 0x1804a6508, 2);
            return;
        }
        if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar7, 0x7b);
            uVar15 = 0;
            ppiVar11 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
            if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
                do {
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                    func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
                    fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    ppiVar10 = (int64_t **)ppiVar11[2];
                    uVar15 = uVar15 + 1;
                    if (*(char *)((int64_t)ppiVar10 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                        ppiVar11 = ppiVar10;
                        ppiVar10 = (int64_t **)*ppiVar10;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                            ppiVar11 = ppiVar10;
                            ppiVar10 = (int64_t **)*ppiVar10;
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                        ppiVar8 = (int64_t **)ppiVar11[1];
                        ppiVar10 = ppiVar11;
                        while ((ppiVar11 = ppiVar8, cVar1 == '\0' && (ppiVar10 == (int64_t **)ppiVar11[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                            ppiVar8 = (int64_t **)ppiVar11[1];
                            ppiVar10 = ppiVar11;
                        }
                    }
                } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
            }
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
            func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
            fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
            return;
        }
        (*ppcVar3[1])(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
        if (*(uint64_t *)(arg1 + 0x270) < (uint64_t)uVar14) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 
                                CONCAT71((unkuint7)(unkuint3)(uVar14 >> 8), 0x20));
        }
        uVar15 = 0;
        ppiVar10 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
        if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
            do {
                ppiVar8 = ppiVar11;
                if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                }
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
                uVar16 = 0;
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
                fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                              (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                              CONCAT44(var_40h._4_4_, uVar14));
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                ppiVar8 = (int64_t **)ppiVar10[2];
                uVar15 = uVar15 + 1;
                if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                    while (cVar1 == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar10 = ppiVar8;
                        ppiVar8 = (int64_t **)*ppiVar8;
                    }
                } else {
                    cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar4 = (int64_t **)ppiVar10[1];
                    ppiVar8 = ppiVar10;
                    while ((ppiVar10 = ppiVar4, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar10[2]))) {
                        cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                        ppiVar4 = (int64_t **)ppiVar10[1];
                        ppiVar8 = ppiVar10;
                    }
                }
            } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
        }
        ppiVar8 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar8 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
        uVar16 = 0;
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
        fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                      (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                      CONCAT44(var_40h._4_4_, uVar14));
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
        goto code_r0x000180179b21;
    case 2:
        piVar7 = *(int64_t **)(arg2 + 8);
        piVar2 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar2;
        if (*piVar7 == piVar7[1]) {
            (*ppcVar3[1])(piVar2, 0x180645cc0, 2);
        } else if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar2, CONCAT71((unkint7)((uint64_t)piVar7 >> 8), 0x5b));
            piVar7 = *(int64_t **)(arg2 + 8);
            iVar12 = *piVar7;
            if (iVar12 != piVar7[1] + -0x10) {
                do {
                    fcn.1801793f0(arg1, iVar12, 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    piVar7 = *(int64_t **)(arg2 + 8);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != piVar7[1] + -0x10);
            }
            fcn.1801793f0(arg1, piVar7[1] + -0x10, 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        } else {
            (*ppcVar3[1])(piVar2, 0x1804a6518, 2);
            ppiVar11 = (int64_t **)(arg1 + 0x260);
            uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
            uVar15 = (uint64_t)uVar14;
            if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
                func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
            }
            iVar12 = **(int64_t **)(arg2 + 8);
            if (iVar12 != (*(int64_t **)(arg2 + 8))[1] + -0x10) {
                do {
                    ppiVar10 = ppiVar11;
                    if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                        ppiVar10 = (int64_t **)*ppiVar11;
                    }
                    uVar17 = uVar15;
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
                    fcn.1801793f0(arg1, iVar12, CONCAT71((unkint7)(uVar17 >> 8), 1), (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, uVar14));
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10);
            }
            ppiVar10 = ppiVar11;
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar10 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
            fcn.1801793f0(arg1, *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10, CONCAT71((unkint7)(uVar15 >> 8), 1), 
                          (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                          CONCAT44(var_40h._4_4_, uVar14));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar11 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar11, arg_30h & 0xffffffff);
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        }
        break;
    case 3:
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, *(undefined8 *)(arg2 + 8), (uint8_t)placeholder_3);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        break;
    case 4:
        piVar7 = *(int64_t **)arg1;
        if (*(char *)(arg2 + 8) == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab28c, 5);
        } else {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab294, 4);
        }
        break;
    case 5:
        func_0x000180174ef0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 6:
        func_0x0001801750c0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 7:
        uVar18 = (undefined4)*(undefined8 *)(arg2 + 8);
        iVar5 = func_0x00018046ea10(uVar18);
        if (iVar5 < 1) {
            iVar12 = arg1 + 0x10;
            iVar6 = func_0x0001801751f0(iVar12, arg1 + 0x50, uVar18);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, iVar12, iVar6 - iVar12);
        } else {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        }
        break;
    case 8:
        piVar7 = *(int64_t **)arg1;
        if ((char)placeholder_2 == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1804a6540, 10);
            puVar9 = *(undefined8 **)(arg2 + 8);
            puVar13 = (undefined *)*puVar9;
            if (puVar13 != (undefined *)puVar9[1]) {
                if (puVar13 != (undefined *)puVar9[1] + -1) {
                    do {
                        func_0x000180174db0(arg1, *puVar13);
                        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                        puVar9 = *(undefined8 **)(arg2 + 8);
                        puVar13 = puVar13 + 1;
                    } while (puVar13 != (undefined *)(puVar9[1] + -1));
                }
                func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6550, 0xc);
            if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) != '\0') {
                func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
                return;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6560, 5);
            return;
        }
        (**(code **)(*piVar7 + 8))(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar15 = (uint64_t)(uint32_t)((int32_t)arg_28h + (int32_t)arg_30h);
        if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
        }
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6520, 10);
        puVar9 = *(undefined8 **)(arg2 + 8);
        puVar13 = (undefined *)*puVar9;
        if (puVar13 != (undefined *)puVar9[1]) {
            if (puVar13 != (undefined *)puVar9[1] + -1) {
                do {
                    func_0x000180174db0(arg1, *puVar13);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180641928, 2);
                    puVar9 = *(undefined8 **)(arg2 + 8);
                    puVar13 = puVar13 + 1;
                } while (puVar13 != (undefined *)(puVar9[1] + -1));
            }
            func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a652c, 3);
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6530, 0xb);
        if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) == '\0') {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        } else {
            func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
        }
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
code_r0x000180179b21:
        (**(code **)(*piVar7 + 8))(piVar7, ppiVar11, (int32_t)arg_30h);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
        break;
    case 9:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6568, 0xb);
    }
    return;
}

// ============================================================
// Function: FUN_180179411
// Address: 0x180179411
// Size: 2100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801793f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    char cVar1;
    int64_t *piVar2;
    code **ppcVar3;
    int64_t **ppiVar4;
    int16_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    undefined8 *puVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t iVar12;
    undefined *puVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    uint64_t uVar17;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    // switch table (10 cases) at 0x180179cf4
    switch(*(undefined *)arg2) {
    case 0:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        break;
    case 1:
        piVar7 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar7;
        if (*(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == 0) {
            (*ppcVar3[1])(piVar7, 0x1804a6508, 2);
            return;
        }
        if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar7, 0x7b);
            uVar15 = 0;
            ppiVar11 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
            if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
                do {
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                    func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
                    fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    ppiVar10 = (int64_t **)ppiVar11[2];
                    uVar15 = uVar15 + 1;
                    if (*(char *)((int64_t)ppiVar10 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                        ppiVar11 = ppiVar10;
                        ppiVar10 = (int64_t **)*ppiVar10;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                            ppiVar11 = ppiVar10;
                            ppiVar10 = (int64_t **)*ppiVar10;
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                        ppiVar8 = (int64_t **)ppiVar11[1];
                        ppiVar10 = ppiVar11;
                        while ((ppiVar11 = ppiVar8, cVar1 == '\0' && (ppiVar10 == (int64_t **)ppiVar11[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                            ppiVar8 = (int64_t **)ppiVar11[1];
                            ppiVar10 = ppiVar11;
                        }
                    }
                } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
            }
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
            func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
            fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
            return;
        }
        (*ppcVar3[1])(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
        if (*(uint64_t *)(arg1 + 0x270) < (uint64_t)uVar14) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 
                                CONCAT71((unkuint7)(unkuint3)(uVar14 >> 8), 0x20));
        }
        uVar15 = 0;
        ppiVar10 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
        if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
            do {
                ppiVar8 = ppiVar11;
                if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                }
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
                uVar16 = 0;
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
                fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                              (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                              CONCAT44(var_40h._4_4_, uVar14));
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                ppiVar8 = (int64_t **)ppiVar10[2];
                uVar15 = uVar15 + 1;
                if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                    while (cVar1 == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar10 = ppiVar8;
                        ppiVar8 = (int64_t **)*ppiVar8;
                    }
                } else {
                    cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar4 = (int64_t **)ppiVar10[1];
                    ppiVar8 = ppiVar10;
                    while ((ppiVar10 = ppiVar4, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar10[2]))) {
                        cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                        ppiVar4 = (int64_t **)ppiVar10[1];
                        ppiVar8 = ppiVar10;
                    }
                }
            } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
        }
        ppiVar8 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar8 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
        uVar16 = 0;
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
        fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                      (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                      CONCAT44(var_40h._4_4_, uVar14));
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
        goto code_r0x000180179b21;
    case 2:
        piVar7 = *(int64_t **)(arg2 + 8);
        piVar2 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar2;
        if (*piVar7 == piVar7[1]) {
            (*ppcVar3[1])(piVar2, 0x180645cc0, 2);
        } else if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar2, CONCAT71((unkint7)((uint64_t)piVar7 >> 8), 0x5b));
            piVar7 = *(int64_t **)(arg2 + 8);
            iVar12 = *piVar7;
            if (iVar12 != piVar7[1] + -0x10) {
                do {
                    fcn.1801793f0(arg1, iVar12, 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    piVar7 = *(int64_t **)(arg2 + 8);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != piVar7[1] + -0x10);
            }
            fcn.1801793f0(arg1, piVar7[1] + -0x10, 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        } else {
            (*ppcVar3[1])(piVar2, 0x1804a6518, 2);
            ppiVar11 = (int64_t **)(arg1 + 0x260);
            uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
            uVar15 = (uint64_t)uVar14;
            if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
                func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
            }
            iVar12 = **(int64_t **)(arg2 + 8);
            if (iVar12 != (*(int64_t **)(arg2 + 8))[1] + -0x10) {
                do {
                    ppiVar10 = ppiVar11;
                    if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                        ppiVar10 = (int64_t **)*ppiVar11;
                    }
                    uVar17 = uVar15;
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
                    fcn.1801793f0(arg1, iVar12, CONCAT71((unkint7)(uVar17 >> 8), 1), (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, uVar14));
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10);
            }
            ppiVar10 = ppiVar11;
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar10 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
            fcn.1801793f0(arg1, *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10, CONCAT71((unkint7)(uVar15 >> 8), 1), 
                          (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                          CONCAT44(var_40h._4_4_, uVar14));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar11 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar11, arg_30h & 0xffffffff);
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        }
        break;
    case 3:
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, *(undefined8 *)(arg2 + 8), (uint8_t)placeholder_3);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        break;
    case 4:
        piVar7 = *(int64_t **)arg1;
        if (*(char *)(arg2 + 8) == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab28c, 5);
        } else {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab294, 4);
        }
        break;
    case 5:
        func_0x000180174ef0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 6:
        func_0x0001801750c0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 7:
        uVar18 = (undefined4)*(undefined8 *)(arg2 + 8);
        iVar5 = func_0x00018046ea10(uVar18);
        if (iVar5 < 1) {
            iVar12 = arg1 + 0x10;
            iVar6 = func_0x0001801751f0(iVar12, arg1 + 0x50, uVar18);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, iVar12, iVar6 - iVar12);
        } else {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        }
        break;
    case 8:
        piVar7 = *(int64_t **)arg1;
        if ((char)placeholder_2 == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1804a6540, 10);
            puVar9 = *(undefined8 **)(arg2 + 8);
            puVar13 = (undefined *)*puVar9;
            if (puVar13 != (undefined *)puVar9[1]) {
                if (puVar13 != (undefined *)puVar9[1] + -1) {
                    do {
                        func_0x000180174db0(arg1, *puVar13);
                        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                        puVar9 = *(undefined8 **)(arg2 + 8);
                        puVar13 = puVar13 + 1;
                    } while (puVar13 != (undefined *)(puVar9[1] + -1));
                }
                func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6550, 0xc);
            if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) != '\0') {
                func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
                return;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6560, 5);
            return;
        }
        (**(code **)(*piVar7 + 8))(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar15 = (uint64_t)(uint32_t)((int32_t)arg_28h + (int32_t)arg_30h);
        if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
        }
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6520, 10);
        puVar9 = *(undefined8 **)(arg2 + 8);
        puVar13 = (undefined *)*puVar9;
        if (puVar13 != (undefined *)puVar9[1]) {
            if (puVar13 != (undefined *)puVar9[1] + -1) {
                do {
                    func_0x000180174db0(arg1, *puVar13);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180641928, 2);
                    puVar9 = *(undefined8 **)(arg2 + 8);
                    puVar13 = puVar13 + 1;
                } while (puVar13 != (undefined *)(puVar9[1] + -1));
            }
            func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a652c, 3);
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6530, 0xb);
        if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) == '\0') {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        } else {
            func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
        }
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
code_r0x000180179b21:
        (**(code **)(*piVar7 + 8))(piVar7, ppiVar11, (int32_t)arg_30h);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
        break;
    case 9:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6568, 0xb);
    }
    return;
}

// ============================================================
// Function: FUN_180179c45
// Address: 0x180179c45
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801793f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    char cVar1;
    int64_t *piVar2;
    code **ppcVar3;
    int64_t **ppiVar4;
    int16_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    undefined8 *puVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t iVar12;
    undefined *puVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    uint64_t uVar17;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    // switch table (10 cases) at 0x180179cf4
    switch(*(undefined *)arg2) {
    case 0:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        break;
    case 1:
        piVar7 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar7;
        if (*(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == 0) {
            (*ppcVar3[1])(piVar7, 0x1804a6508, 2);
            return;
        }
        if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar7, 0x7b);
            uVar15 = 0;
            ppiVar11 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
            if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
                do {
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                    func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
                    fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    ppiVar10 = (int64_t **)ppiVar11[2];
                    uVar15 = uVar15 + 1;
                    if (*(char *)((int64_t)ppiVar10 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                        ppiVar11 = ppiVar10;
                        ppiVar10 = (int64_t **)*ppiVar10;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                            ppiVar11 = ppiVar10;
                            ppiVar10 = (int64_t **)*ppiVar10;
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                        ppiVar8 = (int64_t **)ppiVar11[1];
                        ppiVar10 = ppiVar11;
                        while ((ppiVar11 = ppiVar8, cVar1 == '\0' && (ppiVar10 == (int64_t **)ppiVar11[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                            ppiVar8 = (int64_t **)ppiVar11[1];
                            ppiVar10 = ppiVar11;
                        }
                    }
                } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
            }
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
            func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
            fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
            return;
        }
        (*ppcVar3[1])(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
        if (*(uint64_t *)(arg1 + 0x270) < (uint64_t)uVar14) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 
                                CONCAT71((unkuint7)(unkuint3)(uVar14 >> 8), 0x20));
        }
        uVar15 = 0;
        ppiVar10 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
        if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
            do {
                ppiVar8 = ppiVar11;
                if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                }
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
                uVar16 = 0;
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
                fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                              (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                              CONCAT44(var_40h._4_4_, uVar14));
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                ppiVar8 = (int64_t **)ppiVar10[2];
                uVar15 = uVar15 + 1;
                if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                    while (cVar1 == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar10 = ppiVar8;
                        ppiVar8 = (int64_t **)*ppiVar8;
                    }
                } else {
                    cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar4 = (int64_t **)ppiVar10[1];
                    ppiVar8 = ppiVar10;
                    while ((ppiVar10 = ppiVar4, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar10[2]))) {
                        cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                        ppiVar4 = (int64_t **)ppiVar10[1];
                        ppiVar8 = ppiVar10;
                    }
                }
            } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
        }
        ppiVar8 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar8 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
        uVar16 = 0;
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
        fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                      (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                      CONCAT44(var_40h._4_4_, uVar14));
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
        goto code_r0x000180179b21;
    case 2:
        piVar7 = *(int64_t **)(arg2 + 8);
        piVar2 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar2;
        if (*piVar7 == piVar7[1]) {
            (*ppcVar3[1])(piVar2, 0x180645cc0, 2);
        } else if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar2, CONCAT71((unkint7)((uint64_t)piVar7 >> 8), 0x5b));
            piVar7 = *(int64_t **)(arg2 + 8);
            iVar12 = *piVar7;
            if (iVar12 != piVar7[1] + -0x10) {
                do {
                    fcn.1801793f0(arg1, iVar12, 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    piVar7 = *(int64_t **)(arg2 + 8);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != piVar7[1] + -0x10);
            }
            fcn.1801793f0(arg1, piVar7[1] + -0x10, 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        } else {
            (*ppcVar3[1])(piVar2, 0x1804a6518, 2);
            ppiVar11 = (int64_t **)(arg1 + 0x260);
            uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
            uVar15 = (uint64_t)uVar14;
            if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
                func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
            }
            iVar12 = **(int64_t **)(arg2 + 8);
            if (iVar12 != (*(int64_t **)(arg2 + 8))[1] + -0x10) {
                do {
                    ppiVar10 = ppiVar11;
                    if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                        ppiVar10 = (int64_t **)*ppiVar11;
                    }
                    uVar17 = uVar15;
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
                    fcn.1801793f0(arg1, iVar12, CONCAT71((unkint7)(uVar17 >> 8), 1), (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, uVar14));
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10);
            }
            ppiVar10 = ppiVar11;
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar10 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
            fcn.1801793f0(arg1, *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10, CONCAT71((unkint7)(uVar15 >> 8), 1), 
                          (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                          CONCAT44(var_40h._4_4_, uVar14));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar11 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar11, arg_30h & 0xffffffff);
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        }
        break;
    case 3:
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, *(undefined8 *)(arg2 + 8), (uint8_t)placeholder_3);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        break;
    case 4:
        piVar7 = *(int64_t **)arg1;
        if (*(char *)(arg2 + 8) == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab28c, 5);
        } else {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab294, 4);
        }
        break;
    case 5:
        func_0x000180174ef0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 6:
        func_0x0001801750c0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 7:
        uVar18 = (undefined4)*(undefined8 *)(arg2 + 8);
        iVar5 = func_0x00018046ea10(uVar18);
        if (iVar5 < 1) {
            iVar12 = arg1 + 0x10;
            iVar6 = func_0x0001801751f0(iVar12, arg1 + 0x50, uVar18);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, iVar12, iVar6 - iVar12);
        } else {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        }
        break;
    case 8:
        piVar7 = *(int64_t **)arg1;
        if ((char)placeholder_2 == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1804a6540, 10);
            puVar9 = *(undefined8 **)(arg2 + 8);
            puVar13 = (undefined *)*puVar9;
            if (puVar13 != (undefined *)puVar9[1]) {
                if (puVar13 != (undefined *)puVar9[1] + -1) {
                    do {
                        func_0x000180174db0(arg1, *puVar13);
                        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                        puVar9 = *(undefined8 **)(arg2 + 8);
                        puVar13 = puVar13 + 1;
                    } while (puVar13 != (undefined *)(puVar9[1] + -1));
                }
                func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6550, 0xc);
            if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) != '\0') {
                func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
                return;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6560, 5);
            return;
        }
        (**(code **)(*piVar7 + 8))(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar15 = (uint64_t)(uint32_t)((int32_t)arg_28h + (int32_t)arg_30h);
        if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
        }
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6520, 10);
        puVar9 = *(undefined8 **)(arg2 + 8);
        puVar13 = (undefined *)*puVar9;
        if (puVar13 != (undefined *)puVar9[1]) {
            if (puVar13 != (undefined *)puVar9[1] + -1) {
                do {
                    func_0x000180174db0(arg1, *puVar13);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180641928, 2);
                    puVar9 = *(undefined8 **)(arg2 + 8);
                    puVar13 = puVar13 + 1;
                } while (puVar13 != (undefined *)(puVar9[1] + -1));
            }
            func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a652c, 3);
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6530, 0xb);
        if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) == '\0') {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        } else {
            func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
        }
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
code_r0x000180179b21:
        (**(code **)(*piVar7 + 8))(piVar7, ppiVar11, (int32_t)arg_30h);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
        break;
    case 9:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6568, 0xb);
    }
    return;
}

// ============================================================
// Function: FUN_180179c77
// Address: 0x180179c77
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801793f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    char cVar1;
    int64_t *piVar2;
    code **ppcVar3;
    int64_t **ppiVar4;
    int16_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    undefined8 *puVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t iVar12;
    undefined *puVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    uint64_t uVar17;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    // switch table (10 cases) at 0x180179cf4
    switch(*(undefined *)arg2) {
    case 0:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        break;
    case 1:
        piVar7 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar7;
        if (*(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == 0) {
            (*ppcVar3[1])(piVar7, 0x1804a6508, 2);
            return;
        }
        if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar7, 0x7b);
            uVar15 = 0;
            ppiVar11 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
            if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
                do {
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                    func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
                    fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    ppiVar10 = (int64_t **)ppiVar11[2];
                    uVar15 = uVar15 + 1;
                    if (*(char *)((int64_t)ppiVar10 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                        ppiVar11 = ppiVar10;
                        ppiVar10 = (int64_t **)*ppiVar10;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                            ppiVar11 = ppiVar10;
                            ppiVar10 = (int64_t **)*ppiVar10;
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                        ppiVar8 = (int64_t **)ppiVar11[1];
                        ppiVar10 = ppiVar11;
                        while ((ppiVar11 = ppiVar8, cVar1 == '\0' && (ppiVar10 == (int64_t **)ppiVar11[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                            ppiVar8 = (int64_t **)ppiVar11[1];
                            ppiVar10 = ppiVar11;
                        }
                    }
                } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
            }
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
            func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
            fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
            return;
        }
        (*ppcVar3[1])(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
        if (*(uint64_t *)(arg1 + 0x270) < (uint64_t)uVar14) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 
                                CONCAT71((unkuint7)(unkuint3)(uVar14 >> 8), 0x20));
        }
        uVar15 = 0;
        ppiVar10 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
        if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
            do {
                ppiVar8 = ppiVar11;
                if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                }
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
                uVar16 = 0;
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
                fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                              (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                              CONCAT44(var_40h._4_4_, uVar14));
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                ppiVar8 = (int64_t **)ppiVar10[2];
                uVar15 = uVar15 + 1;
                if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                    while (cVar1 == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar10 = ppiVar8;
                        ppiVar8 = (int64_t **)*ppiVar8;
                    }
                } else {
                    cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar4 = (int64_t **)ppiVar10[1];
                    ppiVar8 = ppiVar10;
                    while ((ppiVar10 = ppiVar4, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar10[2]))) {
                        cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                        ppiVar4 = (int64_t **)ppiVar10[1];
                        ppiVar8 = ppiVar10;
                    }
                }
            } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
        }
        ppiVar8 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar8 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
        uVar16 = 0;
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
        fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                      (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                      CONCAT44(var_40h._4_4_, uVar14));
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
        goto code_r0x000180179b21;
    case 2:
        piVar7 = *(int64_t **)(arg2 + 8);
        piVar2 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar2;
        if (*piVar7 == piVar7[1]) {
            (*ppcVar3[1])(piVar2, 0x180645cc0, 2);
        } else if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar2, CONCAT71((unkint7)((uint64_t)piVar7 >> 8), 0x5b));
            piVar7 = *(int64_t **)(arg2 + 8);
            iVar12 = *piVar7;
            if (iVar12 != piVar7[1] + -0x10) {
                do {
                    fcn.1801793f0(arg1, iVar12, 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    piVar7 = *(int64_t **)(arg2 + 8);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != piVar7[1] + -0x10);
            }
            fcn.1801793f0(arg1, piVar7[1] + -0x10, 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        } else {
            (*ppcVar3[1])(piVar2, 0x1804a6518, 2);
            ppiVar11 = (int64_t **)(arg1 + 0x260);
            uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
            uVar15 = (uint64_t)uVar14;
            if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
                func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
            }
            iVar12 = **(int64_t **)(arg2 + 8);
            if (iVar12 != (*(int64_t **)(arg2 + 8))[1] + -0x10) {
                do {
                    ppiVar10 = ppiVar11;
                    if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                        ppiVar10 = (int64_t **)*ppiVar11;
                    }
                    uVar17 = uVar15;
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
                    fcn.1801793f0(arg1, iVar12, CONCAT71((unkint7)(uVar17 >> 8), 1), (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, uVar14));
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10);
            }
            ppiVar10 = ppiVar11;
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar10 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
            fcn.1801793f0(arg1, *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10, CONCAT71((unkint7)(uVar15 >> 8), 1), 
                          (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                          CONCAT44(var_40h._4_4_, uVar14));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar11 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar11, arg_30h & 0xffffffff);
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        }
        break;
    case 3:
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, *(undefined8 *)(arg2 + 8), (uint8_t)placeholder_3);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        break;
    case 4:
        piVar7 = *(int64_t **)arg1;
        if (*(char *)(arg2 + 8) == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab28c, 5);
        } else {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab294, 4);
        }
        break;
    case 5:
        func_0x000180174ef0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 6:
        func_0x0001801750c0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 7:
        uVar18 = (undefined4)*(undefined8 *)(arg2 + 8);
        iVar5 = func_0x00018046ea10(uVar18);
        if (iVar5 < 1) {
            iVar12 = arg1 + 0x10;
            iVar6 = func_0x0001801751f0(iVar12, arg1 + 0x50, uVar18);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, iVar12, iVar6 - iVar12);
        } else {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        }
        break;
    case 8:
        piVar7 = *(int64_t **)arg1;
        if ((char)placeholder_2 == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1804a6540, 10);
            puVar9 = *(undefined8 **)(arg2 + 8);
            puVar13 = (undefined *)*puVar9;
            if (puVar13 != (undefined *)puVar9[1]) {
                if (puVar13 != (undefined *)puVar9[1] + -1) {
                    do {
                        func_0x000180174db0(arg1, *puVar13);
                        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                        puVar9 = *(undefined8 **)(arg2 + 8);
                        puVar13 = puVar13 + 1;
                    } while (puVar13 != (undefined *)(puVar9[1] + -1));
                }
                func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6550, 0xc);
            if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) != '\0') {
                func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
                return;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6560, 5);
            return;
        }
        (**(code **)(*piVar7 + 8))(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar15 = (uint64_t)(uint32_t)((int32_t)arg_28h + (int32_t)arg_30h);
        if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
        }
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6520, 10);
        puVar9 = *(undefined8 **)(arg2 + 8);
        puVar13 = (undefined *)*puVar9;
        if (puVar13 != (undefined *)puVar9[1]) {
            if (puVar13 != (undefined *)puVar9[1] + -1) {
                do {
                    func_0x000180174db0(arg1, *puVar13);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180641928, 2);
                    puVar9 = *(undefined8 **)(arg2 + 8);
                    puVar13 = puVar13 + 1;
                } while (puVar13 != (undefined *)(puVar9[1] + -1));
            }
            func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a652c, 3);
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6530, 0xb);
        if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) == '\0') {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        } else {
            func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
        }
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
code_r0x000180179b21:
        (**(code **)(*piVar7 + 8))(piVar7, ppiVar11, (int32_t)arg_30h);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
        break;
    case 9:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6568, 0xb);
    }
    return;
}

// ============================================================
// Function: FUN_180179c93
// Address: 0x180179c93
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801793f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    char cVar1;
    int64_t *piVar2;
    code **ppcVar3;
    int64_t **ppiVar4;
    int16_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    undefined8 *puVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t iVar12;
    undefined *puVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    uint64_t uVar17;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    // switch table (10 cases) at 0x180179cf4
    switch(*(undefined *)arg2) {
    case 0:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        break;
    case 1:
        piVar7 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar7;
        if (*(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == 0) {
            (*ppcVar3[1])(piVar7, 0x1804a6508, 2);
            return;
        }
        if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar7, 0x7b);
            uVar15 = 0;
            ppiVar11 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
            if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
                do {
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                    func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
                    fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    ppiVar10 = (int64_t **)ppiVar11[2];
                    uVar15 = uVar15 + 1;
                    if (*(char *)((int64_t)ppiVar10 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                        ppiVar11 = ppiVar10;
                        ppiVar10 = (int64_t **)*ppiVar10;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                            ppiVar11 = ppiVar10;
                            ppiVar10 = (int64_t **)*ppiVar10;
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                        ppiVar8 = (int64_t **)ppiVar11[1];
                        ppiVar10 = ppiVar11;
                        while ((ppiVar11 = ppiVar8, cVar1 == '\0' && (ppiVar10 == (int64_t **)ppiVar11[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                            ppiVar8 = (int64_t **)ppiVar11[1];
                            ppiVar10 = ppiVar11;
                        }
                    }
                } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
            }
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
            func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
            fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
            return;
        }
        (*ppcVar3[1])(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
        if (*(uint64_t *)(arg1 + 0x270) < (uint64_t)uVar14) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 
                                CONCAT71((unkuint7)(unkuint3)(uVar14 >> 8), 0x20));
        }
        uVar15 = 0;
        ppiVar10 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
        if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
            do {
                ppiVar8 = ppiVar11;
                if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                }
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
                uVar16 = 0;
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
                fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                              (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                              CONCAT44(var_40h._4_4_, uVar14));
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                ppiVar8 = (int64_t **)ppiVar10[2];
                uVar15 = uVar15 + 1;
                if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                    while (cVar1 == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar10 = ppiVar8;
                        ppiVar8 = (int64_t **)*ppiVar8;
                    }
                } else {
                    cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar4 = (int64_t **)ppiVar10[1];
                    ppiVar8 = ppiVar10;
                    while ((ppiVar10 = ppiVar4, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar10[2]))) {
                        cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                        ppiVar4 = (int64_t **)ppiVar10[1];
                        ppiVar8 = ppiVar10;
                    }
                }
            } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
        }
        ppiVar8 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar8 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
        uVar16 = 0;
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
        fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                      (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                      CONCAT44(var_40h._4_4_, uVar14));
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
        goto code_r0x000180179b21;
    case 2:
        piVar7 = *(int64_t **)(arg2 + 8);
        piVar2 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar2;
        if (*piVar7 == piVar7[1]) {
            (*ppcVar3[1])(piVar2, 0x180645cc0, 2);
        } else if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar2, CONCAT71((unkint7)((uint64_t)piVar7 >> 8), 0x5b));
            piVar7 = *(int64_t **)(arg2 + 8);
            iVar12 = *piVar7;
            if (iVar12 != piVar7[1] + -0x10) {
                do {
                    fcn.1801793f0(arg1, iVar12, 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    piVar7 = *(int64_t **)(arg2 + 8);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != piVar7[1] + -0x10);
            }
            fcn.1801793f0(arg1, piVar7[1] + -0x10, 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        } else {
            (*ppcVar3[1])(piVar2, 0x1804a6518, 2);
            ppiVar11 = (int64_t **)(arg1 + 0x260);
            uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
            uVar15 = (uint64_t)uVar14;
            if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
                func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
            }
            iVar12 = **(int64_t **)(arg2 + 8);
            if (iVar12 != (*(int64_t **)(arg2 + 8))[1] + -0x10) {
                do {
                    ppiVar10 = ppiVar11;
                    if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                        ppiVar10 = (int64_t **)*ppiVar11;
                    }
                    uVar17 = uVar15;
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
                    fcn.1801793f0(arg1, iVar12, CONCAT71((unkint7)(uVar17 >> 8), 1), (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, uVar14));
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10);
            }
            ppiVar10 = ppiVar11;
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar10 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
            fcn.1801793f0(arg1, *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10, CONCAT71((unkint7)(uVar15 >> 8), 1), 
                          (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                          CONCAT44(var_40h._4_4_, uVar14));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar11 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar11, arg_30h & 0xffffffff);
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        }
        break;
    case 3:
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, *(undefined8 *)(arg2 + 8), (uint8_t)placeholder_3);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        break;
    case 4:
        piVar7 = *(int64_t **)arg1;
        if (*(char *)(arg2 + 8) == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab28c, 5);
        } else {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab294, 4);
        }
        break;
    case 5:
        func_0x000180174ef0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 6:
        func_0x0001801750c0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 7:
        uVar18 = (undefined4)*(undefined8 *)(arg2 + 8);
        iVar5 = func_0x00018046ea10(uVar18);
        if (iVar5 < 1) {
            iVar12 = arg1 + 0x10;
            iVar6 = func_0x0001801751f0(iVar12, arg1 + 0x50, uVar18);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, iVar12, iVar6 - iVar12);
        } else {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        }
        break;
    case 8:
        piVar7 = *(int64_t **)arg1;
        if ((char)placeholder_2 == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1804a6540, 10);
            puVar9 = *(undefined8 **)(arg2 + 8);
            puVar13 = (undefined *)*puVar9;
            if (puVar13 != (undefined *)puVar9[1]) {
                if (puVar13 != (undefined *)puVar9[1] + -1) {
                    do {
                        func_0x000180174db0(arg1, *puVar13);
                        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                        puVar9 = *(undefined8 **)(arg2 + 8);
                        puVar13 = puVar13 + 1;
                    } while (puVar13 != (undefined *)(puVar9[1] + -1));
                }
                func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6550, 0xc);
            if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) != '\0') {
                func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
                return;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6560, 5);
            return;
        }
        (**(code **)(*piVar7 + 8))(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar15 = (uint64_t)(uint32_t)((int32_t)arg_28h + (int32_t)arg_30h);
        if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
        }
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6520, 10);
        puVar9 = *(undefined8 **)(arg2 + 8);
        puVar13 = (undefined *)*puVar9;
        if (puVar13 != (undefined *)puVar9[1]) {
            if (puVar13 != (undefined *)puVar9[1] + -1) {
                do {
                    func_0x000180174db0(arg1, *puVar13);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180641928, 2);
                    puVar9 = *(undefined8 **)(arg2 + 8);
                    puVar13 = puVar13 + 1;
                } while (puVar13 != (undefined *)(puVar9[1] + -1));
            }
            func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a652c, 3);
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6530, 0xb);
        if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) == '\0') {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        } else {
            func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
        }
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
code_r0x000180179b21:
        (**(code **)(*piVar7 + 8))(piVar7, ppiVar11, (int32_t)arg_30h);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
        break;
    case 9:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6568, 0xb);
    }
    return;
}

// ============================================================
// Function: FUN_180179c9c
// Address: 0x180179c9c
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801793f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    char cVar1;
    int64_t *piVar2;
    code **ppcVar3;
    int64_t **ppiVar4;
    int16_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    undefined8 *puVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t iVar12;
    undefined *puVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    uint64_t uVar17;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    // switch table (10 cases) at 0x180179cf4
    switch(*(undefined *)arg2) {
    case 0:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        break;
    case 1:
        piVar7 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar7;
        if (*(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == 0) {
            (*ppcVar3[1])(piVar7, 0x1804a6508, 2);
            return;
        }
        if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar7, 0x7b);
            uVar15 = 0;
            ppiVar11 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
            if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
                do {
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                    func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
                    fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    ppiVar10 = (int64_t **)ppiVar11[2];
                    uVar15 = uVar15 + 1;
                    if (*(char *)((int64_t)ppiVar10 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                        ppiVar11 = ppiVar10;
                        ppiVar10 = (int64_t **)*ppiVar10;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                            ppiVar11 = ppiVar10;
                            ppiVar10 = (int64_t **)*ppiVar10;
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                        ppiVar8 = (int64_t **)ppiVar11[1];
                        ppiVar10 = ppiVar11;
                        while ((ppiVar11 = ppiVar8, cVar1 == '\0' && (ppiVar10 == (int64_t **)ppiVar11[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                            ppiVar8 = (int64_t **)ppiVar11[1];
                            ppiVar10 = ppiVar11;
                        }
                    }
                } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
            }
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
            func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
            fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
            return;
        }
        (*ppcVar3[1])(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
        if (*(uint64_t *)(arg1 + 0x270) < (uint64_t)uVar14) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 
                                CONCAT71((unkuint7)(unkuint3)(uVar14 >> 8), 0x20));
        }
        uVar15 = 0;
        ppiVar10 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
        if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
            do {
                ppiVar8 = ppiVar11;
                if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                }
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
                uVar16 = 0;
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
                fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                              (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                              CONCAT44(var_40h._4_4_, uVar14));
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                ppiVar8 = (int64_t **)ppiVar10[2];
                uVar15 = uVar15 + 1;
                if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                    while (cVar1 == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar10 = ppiVar8;
                        ppiVar8 = (int64_t **)*ppiVar8;
                    }
                } else {
                    cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar4 = (int64_t **)ppiVar10[1];
                    ppiVar8 = ppiVar10;
                    while ((ppiVar10 = ppiVar4, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar10[2]))) {
                        cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                        ppiVar4 = (int64_t **)ppiVar10[1];
                        ppiVar8 = ppiVar10;
                    }
                }
            } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
        }
        ppiVar8 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar8 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
        uVar16 = 0;
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
        fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                      (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                      CONCAT44(var_40h._4_4_, uVar14));
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
        goto code_r0x000180179b21;
    case 2:
        piVar7 = *(int64_t **)(arg2 + 8);
        piVar2 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar2;
        if (*piVar7 == piVar7[1]) {
            (*ppcVar3[1])(piVar2, 0x180645cc0, 2);
        } else if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar2, CONCAT71((unkint7)((uint64_t)piVar7 >> 8), 0x5b));
            piVar7 = *(int64_t **)(arg2 + 8);
            iVar12 = *piVar7;
            if (iVar12 != piVar7[1] + -0x10) {
                do {
                    fcn.1801793f0(arg1, iVar12, 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    piVar7 = *(int64_t **)(arg2 + 8);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != piVar7[1] + -0x10);
            }
            fcn.1801793f0(arg1, piVar7[1] + -0x10, 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        } else {
            (*ppcVar3[1])(piVar2, 0x1804a6518, 2);
            ppiVar11 = (int64_t **)(arg1 + 0x260);
            uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
            uVar15 = (uint64_t)uVar14;
            if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
                func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
            }
            iVar12 = **(int64_t **)(arg2 + 8);
            if (iVar12 != (*(int64_t **)(arg2 + 8))[1] + -0x10) {
                do {
                    ppiVar10 = ppiVar11;
                    if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                        ppiVar10 = (int64_t **)*ppiVar11;
                    }
                    uVar17 = uVar15;
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
                    fcn.1801793f0(arg1, iVar12, CONCAT71((unkint7)(uVar17 >> 8), 1), (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, uVar14));
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10);
            }
            ppiVar10 = ppiVar11;
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar10 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
            fcn.1801793f0(arg1, *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10, CONCAT71((unkint7)(uVar15 >> 8), 1), 
                          (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                          CONCAT44(var_40h._4_4_, uVar14));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar11 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar11, arg_30h & 0xffffffff);
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        }
        break;
    case 3:
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, *(undefined8 *)(arg2 + 8), (uint8_t)placeholder_3);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        break;
    case 4:
        piVar7 = *(int64_t **)arg1;
        if (*(char *)(arg2 + 8) == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab28c, 5);
        } else {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab294, 4);
        }
        break;
    case 5:
        func_0x000180174ef0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 6:
        func_0x0001801750c0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 7:
        uVar18 = (undefined4)*(undefined8 *)(arg2 + 8);
        iVar5 = func_0x00018046ea10(uVar18);
        if (iVar5 < 1) {
            iVar12 = arg1 + 0x10;
            iVar6 = func_0x0001801751f0(iVar12, arg1 + 0x50, uVar18);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, iVar12, iVar6 - iVar12);
        } else {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        }
        break;
    case 8:
        piVar7 = *(int64_t **)arg1;
        if ((char)placeholder_2 == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1804a6540, 10);
            puVar9 = *(undefined8 **)(arg2 + 8);
            puVar13 = (undefined *)*puVar9;
            if (puVar13 != (undefined *)puVar9[1]) {
                if (puVar13 != (undefined *)puVar9[1] + -1) {
                    do {
                        func_0x000180174db0(arg1, *puVar13);
                        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                        puVar9 = *(undefined8 **)(arg2 + 8);
                        puVar13 = puVar13 + 1;
                    } while (puVar13 != (undefined *)(puVar9[1] + -1));
                }
                func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6550, 0xc);
            if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) != '\0') {
                func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
                return;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6560, 5);
            return;
        }
        (**(code **)(*piVar7 + 8))(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar15 = (uint64_t)(uint32_t)((int32_t)arg_28h + (int32_t)arg_30h);
        if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
        }
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6520, 10);
        puVar9 = *(undefined8 **)(arg2 + 8);
        puVar13 = (undefined *)*puVar9;
        if (puVar13 != (undefined *)puVar9[1]) {
            if (puVar13 != (undefined *)puVar9[1] + -1) {
                do {
                    func_0x000180174db0(arg1, *puVar13);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180641928, 2);
                    puVar9 = *(undefined8 **)(arg2 + 8);
                    puVar13 = puVar13 + 1;
                } while (puVar13 != (undefined *)(puVar9[1] + -1));
            }
            func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a652c, 3);
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6530, 0xb);
        if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) == '\0') {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        } else {
            func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
        }
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
code_r0x000180179b21:
        (**(code **)(*piVar7 + 8))(piVar7, ppiVar11, (int32_t)arg_30h);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
        break;
    case 9:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6568, 0xb);
    }
    return;
}

// ============================================================
// Function: FUN_180179cc4
// Address: 0x180179cc4
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1801793f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h)
{
    char cVar1;
    int64_t *piVar2;
    code **ppcVar3;
    int64_t **ppiVar4;
    int16_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    undefined8 *puVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t iVar12;
    undefined *puVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    undefined8 uVar16;
    uint64_t uVar17;
    undefined4 uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    // switch table (10 cases) at 0x180179cf4
    switch(*(undefined *)arg2) {
    case 0:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        break;
    case 1:
        piVar7 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar7;
        if (*(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == 0) {
            (*ppcVar3[1])(piVar7, 0x1804a6508, 2);
            return;
        }
        if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar7, 0x7b);
            uVar15 = 0;
            ppiVar11 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
            if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
                do {
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                    func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
                    fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    ppiVar10 = (int64_t **)ppiVar11[2];
                    uVar15 = uVar15 + 1;
                    if (*(char *)((int64_t)ppiVar10 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                        ppiVar11 = ppiVar10;
                        ppiVar10 = (int64_t **)*ppiVar10;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar10 + 0x19);
                            ppiVar11 = ppiVar10;
                            ppiVar10 = (int64_t **)*ppiVar10;
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                        ppiVar8 = (int64_t **)ppiVar11[1];
                        ppiVar10 = ppiVar11;
                        while ((ppiVar11 = ppiVar8, cVar1 == '\0' && (ppiVar10 == (int64_t **)ppiVar11[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                            ppiVar8 = (int64_t **)ppiVar11[1];
                            ppiVar10 = ppiVar11;
                        }
                    }
                } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
            }
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
            func_0x00018017a620(arg1, ppiVar11 + 4, (uint8_t)placeholder_3);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180620390);
            fcn.1801793f0(arg1, (int64_t)(ppiVar11 + 8), 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
            return;
        }
        (*ppcVar3[1])(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
        if (*(uint64_t *)(arg1 + 0x270) < (uint64_t)uVar14) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 
                                CONCAT71((unkuint7)(unkuint3)(uVar14 >> 8), 0x20));
        }
        uVar15 = 0;
        ppiVar10 = *(int64_t ***)**(undefined8 **)(arg2 + 8);
        if ((*(undefined8 **)(arg2 + 8))[1] != 1) {
            do {
                ppiVar8 = ppiVar11;
                if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                }
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
                func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
                uVar16 = 0;
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
                fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                              (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                              CONCAT44(var_40h._4_4_, uVar14));
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                ppiVar8 = (int64_t **)ppiVar10[2];
                uVar15 = uVar15 + 1;
                if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                    while (cVar1 == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar10 = ppiVar8;
                        ppiVar8 = (int64_t **)*ppiVar8;
                    }
                } else {
                    cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar4 = (int64_t **)ppiVar10[1];
                    ppiVar8 = ppiVar10;
                    while ((ppiVar10 = ppiVar4, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar10[2]))) {
                        cVar1 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                        ppiVar4 = (int64_t **)ppiVar10[1];
                        ppiVar8 = ppiVar10;
                    }
                }
            } while (uVar15 < *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) - 1U);
        }
        ppiVar8 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar8 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar8, uVar14);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, ppiVar10 + 4, (uint8_t)placeholder_3);
        uVar16 = 0;
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6510, 3);
        fcn.1801793f0(arg1, (int64_t)(ppiVar10 + 8), CONCAT71((unkint7)((uint64_t)uVar16 >> 8), 1), 
                      (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                      CONCAT44(var_40h._4_4_, uVar14));
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
        goto code_r0x000180179b21;
    case 2:
        piVar7 = *(int64_t **)(arg2 + 8);
        piVar2 = *(int64_t **)arg1;
        ppcVar3 = (code **)*piVar2;
        if (*piVar7 == piVar7[1]) {
            (*ppcVar3[1])(piVar2, 0x180645cc0, 2);
        } else if ((char)placeholder_2 == '\0') {
            (**ppcVar3)(piVar2, CONCAT71((unkint7)((uint64_t)piVar7 >> 8), 0x5b));
            piVar7 = *(int64_t **)(arg2 + 8);
            iVar12 = *piVar7;
            if (iVar12 != piVar7[1] + -0x10) {
                do {
                    fcn.1801793f0(arg1, iVar12, 0, (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
                    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                    piVar7 = *(int64_t **)(arg2 + 8);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != piVar7[1] + -0x10);
            }
            fcn.1801793f0(arg1, piVar7[1] + -0x10, 0, (uint64_t)(uint8_t)placeholder_3, 
                          CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, (int32_t)arg_30h));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        } else {
            (*ppcVar3[1])(piVar2, 0x1804a6518, 2);
            ppiVar11 = (int64_t **)(arg1 + 0x260);
            uVar14 = (int32_t)arg_30h + (int32_t)arg_28h;
            uVar15 = (uint64_t)uVar14;
            if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
                func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
            }
            iVar12 = **(int64_t **)(arg2 + 8);
            if (iVar12 != (*(int64_t **)(arg2 + 8))[1] + -0x10) {
                do {
                    ppiVar10 = ppiVar11;
                    if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                        ppiVar10 = (int64_t **)*ppiVar11;
                    }
                    uVar17 = uVar15;
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
                    fcn.1801793f0(arg1, iVar12, CONCAT71((unkint7)(uVar17 >> 8), 1), (uint64_t)(uint8_t)placeholder_3, 
                                  CONCAT44(var_48h._4_4_, (int32_t)arg_28h), CONCAT44(var_40h._4_4_, uVar14));
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6514, 2);
                    iVar12 = iVar12 + 0x10;
                } while (iVar12 != *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10);
            }
            ppiVar10 = ppiVar11;
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar10 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
            fcn.1801793f0(arg1, *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) + -0x10, CONCAT71((unkint7)(uVar15 >> 8), 1), 
                          (uint64_t)(uint8_t)placeholder_3, CONCAT44(var_48h._4_4_, (int32_t)arg_28h), 
                          CONCAT44(var_40h._4_4_, uVar14));
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
            if (0xf < *(uint64_t *)(arg1 + 0x278)) {
                ppiVar11 = (int64_t **)*ppiVar11;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar11, arg_30h & 0xffffffff);
            (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x5d);
        }
        break;
    case 3:
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        func_0x00018017a620(arg1, *(undefined8 *)(arg2 + 8), (uint8_t)placeholder_3);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x22);
        break;
    case 4:
        piVar7 = *(int64_t **)arg1;
        if (*(char *)(arg2 + 8) == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab28c, 5);
        } else {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1805ab294, 4);
        }
        break;
    case 5:
        func_0x000180174ef0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 6:
        func_0x0001801750c0(arg1, *(undefined8 *)(arg2 + 8));
        break;
    case 7:
        uVar18 = (undefined4)*(undefined8 *)(arg2 + 8);
        iVar5 = func_0x00018046ea10(uVar18);
        if (iVar5 < 1) {
            iVar12 = arg1 + 0x10;
            iVar6 = func_0x0001801751f0(iVar12, arg1 + 0x50, uVar18);
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, iVar12, iVar6 - iVar12);
        } else {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        }
        break;
    case 8:
        piVar7 = *(int64_t **)arg1;
        if ((char)placeholder_2 == '\0') {
            (**(code **)(*piVar7 + 8))(piVar7, 0x1804a6540, 10);
            puVar9 = *(undefined8 **)(arg2 + 8);
            puVar13 = (undefined *)*puVar9;
            if (puVar13 != (undefined *)puVar9[1]) {
                if (puVar13 != (undefined *)puVar9[1] + -1) {
                    do {
                        func_0x000180174db0(arg1, *puVar13);
                        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x2c);
                        puVar9 = *(undefined8 **)(arg2 + 8);
                        puVar13 = puVar13 + 1;
                    } while (puVar13 != (undefined *)(puVar9[1] + -1));
                }
                func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6550, 0xc);
            if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) != '\0') {
                func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
                (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
                return;
            }
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6560, 5);
            return;
        }
        (**(code **)(*piVar7 + 8))(piVar7, 0x1804a650c, 2);
        ppiVar11 = (int64_t **)(arg1 + 0x260);
        uVar15 = (uint64_t)(uint32_t)((int32_t)arg_28h + (int32_t)arg_30h);
        if (*(uint64_t *)(arg1 + 0x270) < uVar15) {
            func_0x00018000b3b0(ppiVar11, *(uint64_t *)(arg1 + 0x270) * 2, 0x20);
        }
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6520, 10);
        puVar9 = *(undefined8 **)(arg2 + 8);
        puVar13 = (undefined *)*puVar9;
        if (puVar13 != (undefined *)puVar9[1]) {
            if (puVar13 != (undefined *)puVar9[1] + -1) {
                do {
                    func_0x000180174db0(arg1, *puVar13);
                    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x180641928, 2);
                    puVar9 = *(undefined8 **)(arg2 + 8);
                    puVar13 = puVar13 + 1;
                } while (puVar13 != (undefined *)(puVar9[1] + -1));
            }
            func_0x000180174db0(arg1, *(undefined *)(puVar9[1] + -1));
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a652c, 3);
        ppiVar10 = ppiVar11;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar10 = (int64_t **)*ppiVar11;
        }
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, ppiVar10, uVar15);
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6530, 0xb);
        if (*(char *)(*(int64_t *)(arg2 + 8) + 0x20) == '\0') {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x18063e188, 4);
        } else {
            func_0x0001801750c0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 8) + 0x18));
        }
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 10);
        piVar7 = *(int64_t **)arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x278)) {
            ppiVar11 = (int64_t **)*ppiVar11;
        }
code_r0x000180179b21:
        (**(code **)(*piVar7 + 8))(piVar7, ppiVar11, (int32_t)arg_30h);
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x7d);
        break;
    case 9:
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, 0x1804a6568, 0xb);
    }
    return;
}

// ============================================================
// Function: FUN_180179d20
// Address: 0x180179d20
// Size: 2291 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180179d20(int64_t arg1, int64_t arg2)
{
    char cVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t **ppiVar9;
    int64_t *piVar10;
    int64_t **ppiVar11;
    undefined8 uVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    int64_t var_18h;
    undefined auStack_1a8 [8];
    undefined auStack_1a0 [24];
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int32_t iStack_14c;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar13 = auStack_1a8;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1a8;
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    var_178h._0_4_ = 1;
    var_158h = arg2;
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        if (arg2 != arg1) {
            iVar6 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar6 = *(int64_t *)arg1;
            }
            func_0x00018000f180(arg2, iVar6);
        }
        uVar15 = *(uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
            var_188h = 1;
            func_0x00018000ee80(arg2, 1, 0, 0x1805aae98);
        } else {
            *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
            iVar6 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar6 = *(int64_t *)arg2;
            }
            *(undefined *)(uVar15 + iVar6) = 0x3d;
            *(undefined *)(uVar15 + 1 + iVar6) = 0;
        }
        if (*(uint64_t *)(arg1 + 0x38) < 0x10) {
            iVar6 = arg1 + 0x20;
        } else {
            iVar6 = *(int64_t *)(arg1 + 0x20);
        }
        func_0x00018000d970(arg2, iVar6, *(undefined8 *)(arg1 + 0x30));
    }
    ppiVar11 = (int64_t **)**(int64_t ***)(arg1 + 0xb0);
    cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
    while (cVar1 == '\0') {
        iVar6 = arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar6 = *(int64_t *)arg1;
        }
        ppiVar9 = ppiVar11 + 4;
        if ((int64_t *)0xf < ppiVar11[7]) {
            ppiVar9 = (int64_t **)ppiVar11[4];
        }
        if ((ppiVar11[6] != *(int64_t **)(arg1 + 0x10)) ||
           ((ppiVar11[6] != (int64_t *)0x0 && (iVar5 = func_0x000180497f30(ppiVar9, iVar6), iVar5 != 0)))) {
            iVar6 = *(int64_t *)(arg2 + 0x10);
            if (iVar6 != 0) {
                if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 2) {
                    var_188h = 2;
                    func_0x00018000ee80(arg2, 2, 0, 0x1804a5638);
                } else {
                    *(int64_t *)(arg2 + 0x10) = iVar6 + 2;
                    iVar8 = arg2;
                    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                        iVar8 = *(int64_t *)arg2;
                    }
                    *(undefined2 *)(iVar6 + iVar8) = 0x203b;
                    *(undefined *)(iVar6 + 2 + iVar8) = 0;
                }
            }
            if (ppiVar11[7] < (int64_t *)0x10) {
                ppiVar9 = ppiVar11 + 4;
            } else {
                ppiVar9 = (int64_t **)ppiVar11[4];
            }
            func_0x00018000d970(arg2, ppiVar9, ppiVar11[6]);
            uVar15 = *(uint64_t *)(arg2 + 0x10);
            if (*(uint64_t *)(arg2 + 0x18) == uVar15) {
                var_188h = 1;
                func_0x00018000ee80(arg2, 1, 0, 0x1805aae98);
            } else {
                *(uint64_t *)(arg2 + 0x10) = uVar15 + 1;
                if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                    *(undefined *)(uVar15 + arg2) = 0x3d;
                    *(undefined *)(uVar15 + 1 + arg2) = 0;
                } else {
                    iVar6 = *(int64_t *)arg2;
                    *(undefined *)(uVar15 + iVar6) = 0x3d;
                    *(undefined *)(uVar15 + 1 + iVar6) = 0;
                }
            }
            if (ppiVar11[0xb] < (int64_t *)0x10) {
                ppiVar9 = ppiVar11 + 8;
            } else {
                ppiVar9 = (int64_t **)ppiVar11[8];
            }
            func_0x00018000d970(arg2, ppiVar9, ppiVar11[10]);
        }
        ppiVar9 = (int64_t **)ppiVar11[2];
        if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
            ppiVar11 = ppiVar9;
            ppiVar9 = (int64_t **)*ppiVar9;
            while (cVar1 == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                ppiVar11 = ppiVar9;
                ppiVar9 = (int64_t **)*ppiVar9;
            }
        } else {
            cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
            ppiVar4 = (int64_t **)ppiVar11[1];
            ppiVar9 = ppiVar11;
            while ((ppiVar11 = ppiVar4, cVar1 == '\0' && (ppiVar9 == (int64_t **)ppiVar11[2]))) {
                cVar1 = *(char *)((int64_t)ppiVar11[1] + 0x19);
                ppiVar4 = (int64_t **)ppiVar11[1];
                ppiVar9 = ppiVar11;
            }
        }
        cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
    }
    if (*(int64_t *)(arg1 + 0x50) != 0) {
        iVar6 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 9) {
            var_188h = 9;
            func_0x00018000ee80(arg2, 9, 0, 0x1804a6220);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar6 + 9;
            iVar8 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar8 = *(int64_t *)arg2;
            }
            func_0x000180498030(iVar6 + iVar8, 0x1804a6220, 9);
            *(undefined *)(iVar6 + iVar8 + 9) = 0;
        }
        if (*(uint64_t *)(arg1 + 0x58) < 0x10) {
            iVar6 = arg1 + 0x40;
        } else {
            iVar6 = *(int64_t *)(arg1 + 0x40);
        }
        func_0x00018000d970(arg2, iVar6, *(undefined8 *)(arg1 + 0x50));
    }
    if (*(int64_t *)(arg1 + 0x70) != 0) {
        iVar6 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 7) {
            var_188h = 7;
            func_0x00018000ee80(arg2, 7, 0, 0x1804a6230);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar6 + 7;
            iVar8 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar8 = *(int64_t *)arg2;
            }
            func_0x000180498030(iVar6 + iVar8, 0x1804a6230, 7);
            *(undefined *)(iVar6 + iVar8 + 7) = 0;
        }
        if (*(uint64_t *)(arg1 + 0x78) < 0x10) {
            iVar6 = arg1 + 0x60;
        } else {
            iVar6 = *(int64_t *)(arg1 + 0x60);
        }
        func_0x00018000d970(arg2, iVar6, *(undefined8 *)(arg1 + 0x70));
    }
    if (*(int32_t *)(arg1 + 0xa0) < 1) {
        puVar14 = auStack_1a8;
        if (*(int64_t *)(arg1 + 0x90) != 0) {
            iVar6 = *(int64_t *)(arg2 + 0x10);
            if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 10) {
                var_188h = 10;
                func_0x00018000ee80(arg2, 10, 0, 0x1804a6248);
            } else {
                *(int64_t *)(arg2 + 0x10) = iVar6 + 10;
                iVar8 = arg2;
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    iVar8 = *(int64_t *)arg2;
                }
                func_0x000180498030(iVar6 + iVar8, 0x1804a6248, 10);
                *(undefined *)(iVar6 + iVar8 + 10) = 0;
            }
            if (*(uint64_t *)(arg1 + 0x98) < 0x10) {
                iVar6 = arg1 + 0x80;
            } else {
                iVar6 = *(int64_t *)(arg1 + 0x80);
            }
            func_0x00018000d970(arg2, iVar6, *(undefined8 *)(arg1 + 0x90));
            puVar14 = auStack_1a8;
        }
        goto code_r0x00018017a3a6;
    }
    iVar6 = *(int64_t *)(arg2 + 0x10);
    if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 10) {
        var_188h = 10;
        func_0x00018000ee80(arg2, 10, 0, 0x1804a6238);
    } else {
        *(int64_t *)(arg2 + 0x10) = iVar6 + 10;
        iVar8 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar8 = *(int64_t *)arg2;
        }
        func_0x000180498030(iVar6 + iVar8, 0x1804a6238, 10);
        *(undefined *)(iVar6 + iVar8 + 10) = 0;
    }
    func_0x00018000c2d0(&var_148h, 1);
    func_0x000180014900(&var_148h, *(undefined4 *)(arg1 + 0xa0));
    var_48h = 0;
    var_40h = 0xf;
    stack0xffffffffffffffa9 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffffa9;
    _var_58h = auVar3 << 8;
    var_178h._0_4_ = 9;
    auVar3 = ZEXT816(0);
    if ((((uint8_t)(uint32_t)var_d0h & 0x22) == 2) || (uVar15 = *(uint64_t *)var_100h, uVar15 == 0)) {
        if (((uint32_t)var_d0h & 4) == 0) {
            if (*(int64_t *)var_108h == 0) {
                var_168h = 0;
                var_170h = 0;
            } else {
                var_170h = *(int64_t *)var_128h;
                var_168h = (*(int32_t *)var_f0h - var_170h) + *(int64_t *)var_108h;
            }
            goto code_r0x00018017a20b;
        }
    } else {
        var_170h = *(int64_t *)var_120h;
        if (uVar15 < (uint64_t)var_d8h) {
            uVar15 = var_d8h;
        }
        var_168h = uVar15 - var_170h;
code_r0x00018017a20b:
        if (var_170h != 0) {
            iVar6 = var_168h;
            iVar8 = var_170h;
            _var_170h = auVar3;
            func_0x00018000f180(&var_58h, iVar8, iVar6);
            auVar3 = _var_170h;
        }
    }
    _var_170h = auVar3;
    iVar8 = var_40h;
    iVar6 = var_48h;
    var_178h._0_4_ = 7;
    *(undefined8 *)((int64_t)&var_148h + (int64_t)*(int32_t *)(var_148h + 4)) = 0x1804a6448;
    *(int32_t *)((int64_t)&iStack_14c + (int64_t)*(int32_t *)(var_148h + 4)) = *(int32_t *)(var_148h + 4) + -0x88;
    func_0x00018000c970(&var_140h);
    *(undefined8 *)((int64_t)&var_148h + (int64_t)*(int32_t *)(var_148h + 4)) = 0x1804a54f0;
    *(int32_t *)((int64_t)&iStack_14c + (int64_t)*(int32_t *)(var_148h + 4)) = *(int32_t *)(var_148h + 4) + -0x10;
    var_c0h = 0x1804a54d0;
    func_0x000180455c14(&var_c0h);
    piVar10 = &var_58h;
    if (0xf < (uint64_t)iVar8) {
        piVar10 = (int64_t *)var_58h;
    }
    func_0x00018000d970(arg2, piVar10, iVar6);
    var_178h._0_4_ = 5;
    puVar14 = auStack_1a8;
    if (0xf < (uint64_t)var_40h) {
        iVar6 = var_58h;
        if (0xfff < var_40h + 1U) {
            if ((var_58h - *(int64_t *)(var_58h + -8)) - 8U < 0x20) {
                fcn.180459c3c(*(int64_t *)(var_58h + -8), var_40h + 0x28);
                puVar14 = auStack_1a8;
                goto code_r0x00018017a3a6;
            }
            pcVar2 = (code *)swi(0x29);
            iVar6 = (*pcVar2)(5);
            puVar13 = auStack_1a0;
        }
        *(undefined8 *)(puVar13 + -8) = 0x18017a301;
        fcn.180459c3c(iVar6);
        puVar14 = puVar13;
    }
code_r0x00018017a3a6:
    if (*(int32_t *)(arg1 + 0xa8) != 0) {
        iVar6 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 0xb) {
            *(undefined8 *)(puVar14 + 0x20) = 0xb;
            *(undefined8 *)(puVar14 + -8) = 0x18017a41d;
            func_0x00018000ee80(arg2, 0xb, 0, 0x1804a6258);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar6 + 0xb;
            iVar8 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar8 = *(int64_t *)arg2;
            }
            *(undefined8 *)(puVar14 + -8) = 0x18017a3f7;
            func_0x000180498030(iVar6 + iVar8, 0x1804a6258, 0xb);
            *(undefined *)(iVar6 + iVar8 + 0xb) = 0;
        }
        if (*(int32_t *)(arg1 + 0xa8) == 1) {
            uVar12 = 0x1804a6134;
        } else {
            uVar12 = 0x180644c8c;
            if (*(int32_t *)(arg1 + 0xa8) == 2) {
                uVar12 = 0x1804a613c;
            }
        }
        *(undefined8 *)(puVar14 + -8) = 0x18017a44f;
        uVar7 = func_0x000180498cd0(uVar12);
        *(undefined8 *)(puVar14 + -8) = 0x18017a45d;
        func_0x00018000d970(arg2, uVar12, uVar7);
    }
    if (*(int32_t *)(arg1 + 0xac) != 0) {
        iVar6 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 0xb) {
            *(undefined8 *)(puVar14 + 0x20) = 0xb;
            *(undefined8 *)(puVar14 + -8) = 0x18017a4d4;
            func_0x00018000ee80(arg2, 0xb, 0, 0x1804a6268);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar6 + 0xb;
            iVar8 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar8 = *(int64_t *)arg2;
            }
            *(undefined8 *)(puVar14 + -8) = 0x18017a4ae;
            func_0x000180498030(iVar6 + iVar8, 0x1804a6268, 0xb);
            *(undefined *)(iVar6 + iVar8 + 0xb) = 0;
        }
        if (*(int32_t *)(arg1 + 0xac) == 1) {
            uVar12 = 0x1804a6140;
        } else {
            uVar12 = 0x1804a614c;
            if (*(int32_t *)(arg1 + 0xac) == 2) {
                uVar12 = 0x1804a6144;
            }
        }
        *(undefined8 *)(puVar14 + -8) = 0x18017a506;
        uVar7 = func_0x000180498cd0(uVar12);
        *(undefined8 *)(puVar14 + -8) = 0x18017a514;
        func_0x00018000d970(arg2, uVar12, uVar7);
    }
    if (*(char *)(arg1 + 0xa4) != '\0') {
        iVar6 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 8) {
            *(undefined8 *)(puVar14 + 0x20) = 8;
            *(undefined8 *)(puVar14 + -8) = 0x18017a579;
            func_0x00018000ee80(arg2, 8, 0, 0x1804a6278);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar6 + 8;
            iVar8 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar8 = *(int64_t *)arg2;
            }
            *(undefined8 *)(iVar6 + iVar8) = 0x657275636553203b;
            *(undefined *)(iVar6 + 8 + iVar8) = 0;
        }
    }
    if (*(char *)(arg1 + 0xa5) != '\0') {
        iVar6 = *(int64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x18) - iVar6 < 10) {
            *(undefined8 *)(puVar14 + 0x20) = 10;
            *(undefined8 *)(puVar14 + -8) = 0x18017a5ec;
            func_0x00018000ee80(arg2, 10, 0, 0x1804a6288);
        } else {
            *(int64_t *)(arg2 + 0x10) = iVar6 + 10;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            *(undefined8 *)(puVar14 + -8) = 0x18017a5c6;
            func_0x000180498030(iVar6 + arg2, 0x1804a6288, 10);
            *(undefined *)(iVar6 + arg2 + 10) = 0;
        }
    }
    *(undefined8 *)(puVar14 + -8) = 0x18017a5fb;
    func_0x000180459870(var_38h ^ (uint64_t)puVar14);
    return;
}

// ============================================================
// Function: FUN_18017a620
// Address: 0x18017a620
// Size: 1257 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18017a620(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint32_t uVar12;
    char in_R8B;
    int64_t iVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t var_18h;
    undefined auStack_108 [32];
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_a0h;
    int64_t var_80h;
    int64_t var_60h;
    int64_t var_40h;
    
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_108;
    uVar12 = 0;
    uVar15 = 0;
    iVar10 = 0;
    iVar13 = 0;
    iVar14 = 0;
    uVar11 = 0;
    if (*(int64_t *)(arg2 + 0x10) == 0) goto code_r0x00018017a936;
    do {
        uVar4 = *(uint64_t *)(arg2 + 0x18);
        iVar6 = arg2;
        if (0xf < uVar4) {
            iVar6 = *(int64_t *)arg2;
        }
        uVar1 = *(uint8_t *)(iVar6 + uVar11);
        uVar2 = *(uint8_t *)((uint64_t)uVar1 + 0x1804a68a0);
        if ((char)uVar15 == '\0') {
            uVar12 = 0xffU >> (uVar2 & 0x1f) & (uint32_t)uVar1;
        } else {
            uVar12 = uVar1 & 0x3f | uVar12 << 6;
        }
        uVar2 = *(uint8_t *)(uVar15 * 0x10 + (uint64_t)uVar2 + 0x1804a69a0);
        uVar15 = (uint64_t)uVar2;
        if (uVar2 == 0) {
    // switch table (8 cases) at 0x18017aa94
            switch(uVar12) {
            case 8:
                *(undefined *)(arg1 + 0x5a + iVar10) = 0x5c;
                *(undefined *)(iVar10 + 0x5b + arg1) = 0x62;
                iVar10 = iVar10 + 2;
                break;
            case 9:
                *(undefined *)(arg1 + 0x5a + iVar10) = 0x5c;
                *(undefined *)(iVar10 + 0x5b + arg1) = 0x74;
                iVar10 = iVar10 + 2;
                break;
            case 10:
                *(undefined *)(arg1 + 0x5a + iVar10) = 0x5c;
                *(undefined *)(iVar10 + 0x5b + arg1) = 0x6e;
                iVar10 = iVar10 + 2;
                break;
            default:
                if ((uVar12 < 0x20) || ((in_R8B != '\0' && (0x7e < uVar12)))) {
                    if (uVar12 < 0x10000) {
                        func_0x000180065f60(arg1 + iVar10 + 0x5a, 7, 0x1804a6818);
                        iVar10 = iVar10 + 6;
                    } else {
                        var_e8h = CONCAT44(var_e8h._4_4_, (uint32_t)(uint16_t)(((uint16_t)uVar12 & 0x3ff) + 0xdc00));
                        func_0x000180065f60(arg1 + iVar10 + 0x5a, 0xd, 0x1804a6820);
                        iVar10 = iVar10 + 0xc;
                    }
                } else if (uVar4 < 0x10) {
                    *(undefined *)(arg1 + 0x5a + iVar10) = *(undefined *)(arg2 + uVar11);
                    iVar10 = iVar10 + 1;
                } else {
                    *(undefined *)(arg1 + 0x5a + iVar10) = *(undefined *)(*(int64_t *)arg2 + uVar11);
                    iVar10 = iVar10 + 1;
                }
                break;
            case 0xc:
                *(undefined *)(arg1 + 0x5a + iVar10) = 0x5c;
                *(undefined *)(iVar10 + 0x5b + arg1) = 0x66;
                iVar10 = iVar10 + 2;
                break;
            case 0xd:
                *(undefined *)(arg1 + 0x5a + iVar10) = 0x5c;
                *(undefined *)(iVar10 + 0x5b + arg1) = 0x72;
                iVar10 = iVar10 + 2;
                break;
            case 0x22:
                *(undefined *)(arg1 + 0x5a + iVar10) = 0x5c;
                *(undefined *)(iVar10 + 0x5b + arg1) = 0x22;
                iVar10 = iVar10 + 2;
                break;
            case 0x5c:
                *(undefined *)(arg1 + 0x5a + iVar10) = 0x5c;
                *(undefined *)(iVar10 + 0x5b + arg1) = 0x5c;
                iVar10 = iVar10 + 2;
            }
            if (0x200U - iVar10 < 0xd) {
                (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x5a, iVar10);
                iVar10 = 0;
            }
            iVar14 = 0;
            iVar13 = iVar10;
        } else if (uVar2 == 1) {
            iVar3 = *(int32_t *)(arg1 + 0x280);
            if (iVar3 == 0) {
                iVar10 = func_0x00018017b1e0(&var_60h, (uint64_t)uVar1);
                uVar8 = func_0x00018017c500(&var_a0h, uVar11);
                var_e8h = iVar10;
                uVar8 = func_0x0001801746a0(&var_80h, 0x1804a6838, uVar8, 0x1804a6830);
                func_0x000180174b20(&var_d8h, 0x13c, uVar8, 0);
                func_0x00018045bae0(&var_d8h, 0x180698790);
                goto code_r0x00018017aa3e;
            }
            if ((iVar3 == 1) || (iVar3 == 2)) {
                if (iVar14 != 0) {
                    uVar11 = uVar11 - 1;
                }
                if (iVar3 == 1) {
                    iVar14 = iVar13 + 2;
                    if (in_R8B == '\0') {
                        *(undefined2 *)(arg1 + 0x5a + iVar13) = 0xbfef;
                        *(undefined *)(iVar13 + 0x5c + arg1) = 0xbd;
                    } else {
                        *(undefined2 *)(arg1 + 0x5a + iVar13) = 0x755c;
                        *(undefined2 *)(iVar13 + 0x5c + arg1) = 0x6666;
                        *(undefined *)(iVar13 + 0x5e + arg1) = 0x66;
                        iVar14 = iVar13 + 5;
                        *(undefined *)(iVar13 + 0x5f + arg1) = 100;
                    }
                    iVar10 = iVar14 + 1;
                    if (0x1ffU - iVar14 < 0xd) {
                        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x5a, iVar10);
                        iVar10 = 0;
                    }
                    iVar14 = 0;
                    uVar15 = 0;
                    iVar13 = iVar10;
                } else {
                    iVar14 = 0;
                    uVar15 = 0;
                    iVar10 = iVar13;
                }
            }
        } else {
            if (in_R8B == '\0') {
                iVar6 = arg2;
                if (0xf < uVar4) {
                    iVar6 = *(int64_t *)arg2;
                }
                *(undefined *)(arg1 + 0x5a + iVar10) = *(undefined *)(iVar6 + uVar11);
                iVar10 = iVar10 + 1;
            }
            iVar14 = iVar14 + 1;
        }
        uVar11 = uVar11 + 1;
    } while (uVar11 < *(uint64_t *)(arg2 + 0x10));
    if ((char)uVar15 == '\0') {
        if (iVar10 == 0) goto code_r0x00018017a936;
        piVar9 = *(int64_t **)arg1;
        iVar14 = *piVar9;
        iVar13 = iVar10;
    } else {
        iVar3 = *(int32_t *)(arg1 + 0x280);
        if (iVar3 == 0) {
code_r0x00018017aa3e:
            puVar7 = (undefined *)func_0x0001800148e0(arg2);
            uVar8 = func_0x00018017b1e0(&var_80h, *puVar7);
            uVar8 = func_0x000180174790(&var_a0h, 0x1804a6858, uVar8);
            func_0x000180174b20(&var_d8h, 0x13c, uVar8, 0);
            func_0x00018045bae0(&var_d8h, 0x180698790);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (iVar3 == 1) {
            (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x5a, iVar13);
            piVar9 = *(int64_t **)arg1;
            if (in_R8B == '\0') {
                (**(code **)(*piVar9 + 8))(piVar9, 0x1804a6888, 3);
            } else {
                (**(code **)(*piVar9 + 8))(piVar9, 0x1804a6880, 6);
            }
            goto code_r0x00018017a936;
        }
        if (iVar3 != 2) goto code_r0x00018017a936;
        piVar9 = *(int64_t **)arg1;
        iVar14 = *piVar9;
    }
    (**(code **)(iVar14 + 8))(piVar9, arg1 + 0x5a, iVar13);
code_r0x00018017a936:
    func_0x000180459870(var_40h ^ (uint64_t)auStack_108);
    return;
}

// ============================================================
// Function: FUN_18017ab10
// Address: 0x18017ab10
// Size: 450 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

char * fcn.18017ab10(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    char cVar2;
    undefined uVar3;
    char *pcVar4;
    int64_t iVar5;
    undefined *puVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = (int32_t)arg2;
    placeholder_2._0_4_ = iVar1 + (int32_t)placeholder_2;
    if ((iVar1 <= (int32_t)placeholder_2) && ((int32_t)placeholder_2 <= (int32_t)arg_28h)) {
        iVar5 = (int64_t)(int32_t)placeholder_2;
        fcn.1804986e0(arg1 + iVar1, 0x30, iVar5 - iVar1);
        *(undefined2 *)(iVar5 + arg1) = 0x302e;
        return (char *)(arg1 + 2 + iVar5);
    }
    if (((int32_t)placeholder_2 < 1) || ((int32_t)arg_28h < (int32_t)placeholder_2)) {
        if (((int32_t)arg4 < (int32_t)placeholder_2) && ((int32_t)placeholder_2 < 1)) {
            iVar5 = (int64_t)-(int32_t)placeholder_2;
            fcn.180498030(arg1 + 2 + iVar5, arg1, (int64_t)iVar1);
            *(undefined2 *)arg1 = 0x2e30;
            fcn.1804986e0(arg1 + 2, 0x30, iVar5);
            pcVar4 = (char *)((int64_t)iVar1 + 2 + iVar5 + arg1);
        } else {
            puVar6 = (undefined *)(arg1 + 1);
            if (iVar1 != 1) {
                fcn.180498030(arg1 + 2, puVar6, (int64_t)iVar1 + -1);
                *puVar6 = 0x2e;
                puVar6 = (undefined *)((int64_t)iVar1 + 1 + arg1);
            }
            *puVar6 = 0x65;
            uVar3 = 0x2d;
            uVar7 = 1 - (int32_t)placeholder_2;
            if (-1 < (int32_t)((int32_t)placeholder_2 - 1U)) {
                uVar3 = 0x2b;
                uVar7 = (int32_t)placeholder_2 - 1U;
            }
            uVar8 = (uint64_t)uVar7;
            puVar6[1] = uVar3;
            if (uVar7 < 10) {
                puVar6[2] = 0x30;
                pcVar4 = puVar6 + 3;
            } else if (uVar7 < 100) {
                pcVar4 = puVar6 + 3;
                cVar2 = (char)(uVar8 / 10);
                puVar6[2] = cVar2 + '0';
                uVar8 = (uint64_t)(uint8_t)((char)uVar7 + cVar2 * -10);
            } else {
                pcVar4 = puVar6 + 4;
                puVar6[2] = (char)(uVar8 / 100) + '0';
                uVar7 = uVar7 + (int32_t)(uVar8 / 100) * -100;
                uVar8 = (uint64_t)uVar7 / 10;
                *pcVar4 = (char)uVar7 + (char)uVar8 * -10 + '0';
                uVar8 = uVar8 & 0xff;
            }
            pcVar4 = pcVar4 + 1;
            puVar6[3] = (char)uVar8 + '0';
        }
    } else {
        puVar6 = (undefined *)((int32_t)placeholder_2 + arg1);
        fcn.180498030(puVar6 + 1, puVar6, (int64_t)iVar1 - (int64_t)(int32_t)placeholder_2);
        *puVar6 = 0x2e;
        pcVar4 = (char *)((int64_t)iVar1 + 1 + arg1);
    }
    return pcVar4;
}

// ============================================================
// Function: FUN_18017ace0
// Address: 0x18017ace0
// Size: 614 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_70h

void fcn.18017ace0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int32_t var_50h;
    int64_t var_4ch;
    
    uVar12 = *(uint64_t *)arg_28h & 0xffffffff;
    var_60h._0_4_ = *(int32_t *)(arg_30h + 8);
    iVar10 = -0x3d - (int32_t)var_60h;
    uVar1 = *(uint64_t *)arg_30h;
    iVar3 = iVar10 * 0x13441;
    uVar7 = *(uint64_t *)arg_28h >> 0x20;
    iVar3 = ((int32_t)(iVar3 + (iVar3 >> 0x1f & 0x3ffffU)) >> 0x12) + (0 < iVar10) + 0x133;
    iVar4 = (int64_t)((int32_t)(iVar3 + (iVar3 >> 0x1f & 7U)) >> 3);
    uVar2 = *(uint64_t *)(iVar4 * 0x10 + 0x1804a5ba0);
    iVar3 = *(int32_t *)(iVar4 * 0x10 + 0x1804a5ba8);
    uVar13 = uVar2 & 0xffffffff;
    uVar8 = uVar2 >> 0x20;
    uVar5 = uVar13 * uVar7;
    *(int32_t *)arg3 = -*(int32_t *)(iVar4 * 0x10 + 0x1804a5bac);
    uVar11 = (uVar1 & 0xffffffff) * uVar8;
    uVar6 = uVar8 * uVar12;
    uVar9 = (uVar1 >> 0x20) * uVar13;
    var_68h = (((uVar1 & 0xffffffff) * uVar13 >> 0x20) + (uVar9 & 0xffffffff) + 0x80000000 + (uVar11 & 0xffffffff) >>
              0x20) + (uVar1 >> 0x20) * uVar8 + -1 + (uVar9 >> 0x20) + (uVar11 >> 0x20);
    var_60h._0_4_ = iVar3 + 0x40 + (int32_t)var_60h;
    var_50h = iVar3 + 0x40 + *(int32_t *)(arg_28h + 8);
    var_58h = (((uVar2 & 0xffffffff) * uVar12 >> 0x20) + (uVar5 & 0xffffffff) + 0x80000000 + (uVar6 & 0xffffffff) >>
              0x20) + uVar8 * uVar7 + (uVar5 >> 0x20) + (uVar6 >> 0x20);
    fcn.18017af50((int64_t)&var_58h, (int64_t)&var_68h);
    return;
}

// ============================================================
// Function: FUN_18017af50
// Address: 0x18017af50
// Size: 642 bytes
// ============================================================
void fcn.18017af50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint8_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    
    iVar7 = 1;
    uVar10 = 1000000000;
    uVar3 = *(uint64_t *)arg_30h;
    uVar13 = uVar3 - *(int64_t *)arg4;
    uVar4 = -(char)*(undefined4 *)(arg_30h + 8);
    uVar11 = uVar3 - *(int64_t *)arg_28h;
    uVar6 = 1LL << (uVar4 & 0x3f);
    uVar9 = uVar3 >> (uVar4 & 0x3f);
    uVar3 = uVar6 - 1 & uVar3;
    uVar8 = (uint32_t)uVar9;
    if (uVar8 < 1000000000) {
        uVar10 = 100000000;
        if (uVar8 < 100000000) {
            uVar10 = 10000000;
            if (uVar8 < 10000000) {
                uVar10 = 1000000;
                if (uVar8 < 1000000) {
                    uVar10 = 100000;
                    if (uVar8 < 100000) {
                        uVar10 = 10000;
                        if (uVar8 < 10000) {
                            uVar10 = 1000;
                            if (uVar8 < 1000) {
                                if (uVar8 < 100) {
                                    if (uVar8 < 10) {
                                        uVar10 = 1;
                                        iVar12 = 1;
                                    } else {
                                        uVar10 = 10;
                                        iVar12 = 2;
                                    }
                                } else {
                                    uVar10 = 100;
                                    iVar12 = 3;
                                }
                            } else {
                                iVar12 = 4;
                            }
                        } else {
                            iVar12 = 5;
                        }
                    } else {
                        iVar12 = 6;
                    }
                } else {
                    iVar12 = 7;
                }
            } else {
                iVar12 = 8;
            }
        } else {
            iVar12 = 9;
        }
    } else {
        iVar12 = 10;
    }
    do {
        uVar5 = uVar9 & 0xffffffff;
        iVar12 = iVar12 + -1;
        uVar9 = uVar5 % (uint64_t)uVar10;
        *(char *)(*(int32_t *)arg2 + arg1) = (char)(uVar5 / uVar10) + '0';
        iVar2 = *(int32_t *)arg2;
        uVar5 = (uVar9 << (uVar4 & 0x3f)) + uVar3;
        *(int32_t *)arg2 = iVar2 + 1;
        if (uVar5 <= uVar13) {
            *(int32_t *)arg3 = *(int32_t *)arg3 + iVar12;
            iVar7 = *(int32_t *)arg2;
            uVar3 = (uint64_t)uVar10 << (uVar4 & 0x3f);
            if (uVar11 <= uVar5) {
                return;
            }
            while( true ) {
                if (uVar13 - uVar5 < uVar3) {
                    return;
                }
                uVar9 = uVar5 + uVar3;
                if ((uVar11 <= uVar9) && (uVar11 - uVar5 <= (uVar5 - uVar11) + uVar3)) break;
                pcVar1 = (char *)((int64_t)iVar7 + -1 + arg1);
                *pcVar1 = *pcVar1 + -1;
                uVar5 = uVar9;
                if (uVar11 <= uVar9) {
                    return;
                }
            }
            return;
        }
        uVar10 = uVar10 / 10;
    } while (0 < iVar12);
    uVar3 = uVar3 * 10;
    uVar9 = uVar3 & uVar6 - 1;
    *(char *)((int64_t)iVar2 + 1 + arg1) = (char)(uVar3 >> (uVar4 & 0x3f)) + '0';
    uVar13 = uVar13 * 10;
    *(int32_t *)arg2 = *(int32_t *)arg2 + 1;
    uVar11 = uVar11 * 10;
    iVar12 = *(int32_t *)arg2;
    if (uVar13 < uVar9) {
        do {
            uVar3 = uVar9 * 10;
            uVar9 = uVar3 & uVar6 - 1;
            iVar7 = iVar7 + 1;
            uVar13 = uVar13 * 10;
            uVar11 = uVar11 * 10;
            *(char *)(iVar12 + arg1) = (char)(uVar3 >> (uVar4 & 0x3f)) + '0';
            *(int32_t *)arg2 = *(int32_t *)arg2 + 1;
            iVar12 = *(int32_t *)arg2;
        } while (uVar13 < uVar9);
    }
    *(int32_t *)arg3 = *(int32_t *)arg3 - iVar7;
    iVar7 = *(int32_t *)arg2;
    if (uVar9 < uVar11) {
        while ((uVar6 <= uVar13 - uVar9 &&
               ((uVar3 = uVar6 + uVar9, uVar3 < uVar11 || ((uVar6 - uVar11) + uVar9 < uVar11 - uVar9))))) {
            pcVar1 = (char *)((int64_t)iVar7 + -1 + arg1);
            *pcVar1 = *pcVar1 + -1;
            uVar9 = uVar3;
            if (uVar11 <= uVar3) {
                return;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017b1e0
// Address: 0x18017b1e0
// Size: 124 bytes
// ============================================================
int64_t fcn.18017b1e0(int64_t arg1, int64_t arg2)
{
    undefined *puVar1;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 2;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined2 *)arg1 = 0x4646;
    *(undefined *)(arg1 + 2) = 0;
    puVar1 = (undefined *)arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        puVar1 = *(undefined **)arg1;
    }
    *puVar1 = *(undefined *)(((arg2 & 0xffU) >> 4) + 0x1804a6a38);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        *(undefined *)(*(int64_t *)arg1 + 1) = *(undefined *)((uint64_t)((uint32_t)arg2 & 0xf) + 0x1804a6a38);
        return arg1;
    }
    *(undefined *)(arg1 + 1) = *(undefined *)((uint64_t)((uint32_t)arg2 & 0xf) + 0x1804a6a38);
    return arg1;
}

// ============================================================
// Function: FUN_18017b260
// Address: 0x18017b260
// Size: 598 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18017b260(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined *puVar5;
    uint32_t uVar6;
    int64_t *piVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_98 [8];
    undefined auStack_90 [11];
    int64_t var_85h;
    int64_t var_78h;
    undefined var_68h [4];
    undefined4 var_64h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined auStack_25 [2];
    int64_t var_23h;
    int64_t *piVar8;
    
    *(uint64_t *)0x0 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    var_64h = 0;
    piVar7 = &var_23h;
    if ((int32_t)arg3 < 0) {
        uVar6 = -(int32_t)arg3;
        do {
            piVar8 = piVar7;
            piVar7 = (int64_t *)((int64_t)piVar8 + -1);
            *(char *)piVar7 = (char)uVar6 + (char)((uint64_t)uVar6 / 10) * -10 + '0';
            uVar6 = (uint32_t)((uint64_t)uVar6 / 10);
        } while (uVar6 != 0);
        piVar7 = (int64_t *)((int64_t)piVar8 + -2);
        *(undefined *)piVar7 = 0x2d;
    } else {
        do {
            piVar7 = (int64_t *)((int64_t)piVar7 + -1);
            uVar1 = (arg3 & 0xffffffffU) / 10;
            *(char *)piVar7 = (char)arg3 + (char)uVar1 * -10 + '0';
            arg3 = uVar1;
        } while ((int32_t)uVar1 != 0);
    }
    var_60h = arg1;
    func_0x000180014b30(&var_58h, piVar7, &var_23h, var_68h);
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    var_64h = 0xe;
    piVar7 = (int64_t *)(arg2 + 0x10);
    func_0x00018000b240(arg1, var_48h + 0x13 + *piVar7);
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar4 < 0x10) {
        var_78h = 0x10;
        func_0x00018000ee80(arg1, 0x10, 0, 0x1804a5b58);
    } else {
        *(int64_t *)(arg1 + 0x10) = iVar4 + 0x10;
        iVar3 = arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar3 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar4 + iVar3, 0x1804a5b58, 0x10);
        *(undefined *)(iVar4 + iVar3 + 0x10) = 0;
    }
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    func_0x00018000d970(arg1, arg2, *piVar7);
    puVar5 = auStack_98;
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (uVar1 < *(uint64_t *)(arg1 + 0x18)) {
        *(uint64_t *)(arg1 + 0x10) = uVar1 + 1;
        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
            *(undefined2 *)(uVar1 + arg1) = 0x2e;
        } else {
            *(undefined2 *)(uVar1 + *(int64_t *)arg1) = 0x2e;
        }
    } else {
        func_0x00018000f010(arg1, 1, 0, 0x2e);
    }
    piVar7 = &var_58h;
    if (0xf < (uint64_t)var_40h) {
        piVar7 = (int64_t *)var_58h;
    }
    func_0x00018000d970(arg1, piVar7, var_48h);
    func_0x00018000d970(arg1, 0x1805ab2b4, 2);
    if (0xf < (uint64_t)var_40h) {
        iVar4 = var_58h;
        puVar5 = auStack_98;
        if ((0xfff < var_40h + 1U) &&
           (iVar4 = *(int64_t *)(var_58h + -8), puVar5 = auStack_98, 0x1f < (var_58h - iVar4) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar4 = (*pcVar2)(5);
            puVar5 = auStack_90;
        }
        *(undefined8 *)(puVar5 + -8) = 0x18017b48e;
        fcn.180459c3c(iVar4);
    }
    *(undefined8 *)(puVar5 + -8) = 0x18017b49e;
    func_0x000180459870(*(uint64_t *)(puVar5 + 0x78) ^ (uint64_t)puVar5);
    return;
}

// ============================================================
// Function: FUN_18017b4c0
// Address: 0x18017b4c0
// Size: 3786 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_268h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_1fch

void fcn.18017b4c0(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    int64_t iVar9;
    int32_t iVar10;
    undefined4 uVar11;
    undefined *puVar12;
    int64_t **ppiVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    int64_t *piVar16;
    int64_t iVar17;
    undefined (*pauVar18) [16];
    undefined8 *puVar19;
    undefined8 uVar20;
    int64_t iVar21;
    undefined8 *puVar22;
    int64_t *piVar23;
    uint64_t uVar24;
    undefined8 *puVar25;
    undefined *puVar26;
    undefined *puVar27;
    uint64_t uVar28;
    int64_t **ppiVar29;
    int64_t var_18h;
    undefined8 uStackY_2a0;
    undefined auStackY_298 [8];
    undefined auStackY_290 [24];
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_208h;
    int64_t var_200h;
    int32_t iStack_1ec;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    undefined4 var_154h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar27 = auStackY_298;
    puVar26 = auStackY_298;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_298;
    var_1e8h = 0x1804a5628;
    var_1d8h = 0x1804a5630;
    var_148h = 0;
    var_140h = 0;
    var_138h._0_4_ = 0;
    var_130h = 0;
    _var_128h = ZEXT816(0);
    _var_118h = ZEXT816(0);
    _var_108h = ZEXT816(0);
    var_f8h._0_1_ = 0;
    var_258h._0_4_ = 4;
    var_250h = CONCAT44((int32_t)((uint64_t)var_250h >> 0x20), 4);
    var_150h = 0x1804a5600;
    var_154h = 0x80;
    var_1e0h = 0;
    var_238h = arg1;
    func_0x00018000fe50(&var_150h, &var_1d0h, 0);
    *(undefined8 *)((int64_t)&var_1d8h + (int64_t)*(int32_t *)(var_1d8h + 4)) = 0x1804a54f0;
    *(int32_t *)((int64_t)&var_1e0h + (int64_t)*(int32_t *)(var_1d8h + 4) + 4) = *(int32_t *)(var_1d8h + 4) + -0x10;
    *(undefined8 *)((int64_t)&var_1e8h + (int64_t)*(int32_t *)(var_1e8h + 4)) = 0x1804a5610;
    *(int32_t *)((int64_t)&iStack_1ec + (int64_t)*(int32_t *)(var_1e8h + 4)) = *(int32_t *)(var_1e8h + 4) + -0x20;
    *(undefined8 *)((int64_t)&var_1e8h + (int64_t)*(int32_t *)(var_1e8h + 4)) = 0x1804a5620;
    *(int32_t *)((int64_t)&iStack_1ec + (int64_t)*(int32_t *)(var_1e8h + 4)) = *(int32_t *)(var_1e8h + 4) + -0x98;
    func_0x00018000dfd0(&var_1d0h, 3);
    iVar21 = arg2;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar21 = *(int64_t *)arg2;
    }
    func_0x000180017f30(&var_1d8h, iVar21, *(undefined8 *)(arg2 + 0x10));
    var_98h = 0;
    var_90h = 0xf;
    stack0xffffffffffffff59 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffff59;
    _var_a8h = auVar3 << 8;
    var_b8h = 0;
    var_b0h = 0xf;
    stack0xffffffffffffff39 = SUB1615(ZEXT816(0), 1);
    auVar4[15] = 0;
    auVar4._0_15_ = stack0xffffffffffffff39;
    _var_c8h = auVar4 << 8;
    var_d8h = 0;
    var_d0h = 0xf;
    stack0xffffffffffffff19 = SUB1615(ZEXT816(0), 1);
    auVar5[15] = 0;
    auVar5._0_15_ = stack0xffffffffffffff19;
    _var_e8h = auVar5 << 8;
    *(undefined4 *)(arg1 + 0xa0) = 0;
    *(undefined2 *)(arg1 + 0xa4) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    puVar12 = (undefined *)arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        puVar12 = *(undefined **)arg1;
    }
    *puVar12 = 0;
    puVar19 = (undefined8 *)(arg1 + 0x20);
    *(undefined8 *)(arg1 + 0x30) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x38)) {
        puVar19 = (undefined8 *)*puVar19;
    }
    *(undefined *)puVar19 = 0;
    ppiVar29 = (int64_t **)(arg1 + 0x40);
    *(undefined8 *)(arg1 + 0x50) = 0;
    ppiVar13 = ppiVar29;
    if (0xf < *(uint64_t *)(arg1 + 0x58)) {
        ppiVar13 = (int64_t **)*ppiVar29;
    }
    *(undefined *)ppiVar13 = 0;
    ppiVar13 = (int64_t **)(arg1 + 0x60);
    *(undefined8 *)(arg1 + 0x70) = 0;
    ppiVar14 = ppiVar13;
    if (0xf < *(uint64_t *)(arg1 + 0x78)) {
        ppiVar14 = (int64_t **)*ppiVar13;
    }
    *(undefined *)ppiVar14 = 0;
    ppiVar14 = (int64_t **)(arg1 + 0x80);
    *(undefined8 *)(arg1 + 0x90) = 0;
    ppiVar15 = ppiVar14;
    if (0xf < *(uint64_t *)(arg1 + 0x98)) {
        ppiVar15 = (int64_t **)*ppiVar14;
    }
    *(undefined *)ppiVar15 = 0;
    piVar23 = (int64_t *)(arg1 + 0xb0);
    iVar21 = *piVar23;
    var_250h = (int64_t)piVar23;
    var_248h = (int64_t)ppiVar29;
    var_230h = (int64_t)ppiVar14;
    var_228h = (int64_t)ppiVar13;
    fcn.180015170(var_268h);
    *(int64_t *)(iVar21 + 8) = iVar21;
    *(int64_t *)iVar21 = iVar21;
    *(int64_t *)(iVar21 + 0x10) = iVar21;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    piVar16 = (int64_t *)func_0x00018007d3a0(&var_1e8h, &var_a8h, 0x3b);
    uVar1 = *(uint8_t *)((int64_t)*(int32_t *)(*piVar16 + 4) + 0x10 + (int64_t)piVar16);
    do {
        if ((uVar1 & 6) != 0) {
            uVar28 = 0;
            if (0xf < (uint64_t)var_d0h) {
                iVar21 = var_e8h;
                puVar27 = auStackY_298;
                if ((0xfff < var_d0h + 1U) &&
                   (iVar21 = *(int64_t *)(var_e8h + -8), puVar27 = auStackY_298, 0x1f < (var_e8h - iVar21) - 8U)) {
code_r0x00018017c262:
                    pcVar2 = (code *)swi(0x29);
                    iVar21 = (*pcVar2)(5);
                    puVar27 = puVar26 + 8;
                }
                *(undefined8 *)(puVar27 + -8) = 0x18017c271;
                fcn.180459c3c(iVar21);
            }
            var_d0h = 0xf;
            auVar6[15] = 0;
            auVar6._0_15_ = stack0xffffffffffffff19;
            _var_e8h = auVar6 << 8;
            var_d8h = uVar28;
            if (0xf < (uint64_t)var_b0h) {
                iVar21 = var_c8h;
                if ((0xfff < var_b0h + 1U) && (iVar21 = *(int64_t *)(var_c8h + -8), 0x1f < (var_c8h - iVar21) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar21 = (*pcVar2)(5);
                    puVar27 = puVar27 + 8;
                }
                *(undefined8 *)(puVar27 + -8) = 0x18017c2d0;
                fcn.180459c3c(iVar21);
            }
            var_b0h = 0xf;
            auVar7[15] = 0;
            auVar7._0_15_ = stack0xffffffffffffff39;
            _var_c8h = auVar7 << 8;
            var_b8h = uVar28;
            if (0xf < (uint64_t)var_90h) {
                iVar21 = var_a8h;
                if ((0xfff < var_90h + 1U) && (iVar21 = *(int64_t *)(var_a8h + -8), 0x1f < (var_a8h - iVar21) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar21 = (*pcVar2)(5);
                    puVar27 = puVar27 + 8;
                }
                *(undefined8 *)(puVar27 + -8) = 0x18017c32f;
                fcn.180459c3c(iVar21);
            }
            var_90h = 0xf;
            auVar8[15] = 0;
            auVar8._0_15_ = stack0xffffffffffffff59;
            _var_a8h = auVar8 << 8;
            *(undefined8 *)(puVar27 + -8) = 0x18017c351;
            var_98h = uVar28;
            func_0x00018016b9c0(&var_1e8h);
            *(undefined8 *)(puVar27 + -8) = 0x18017c363;
            func_0x000180459870(var_48h ^ (uint64_t)puVar27);
            return;
        }
        piVar16 = &var_a8h;
        if (0xf < (uint64_t)var_90h) {
            piVar16 = (int64_t *)var_a8h;
        }
        if (var_98h == 0) {
            uVar28 = 0xffffffffffffffff;
        } else {
            iVar21 = var_98h + (int64_t)piVar16;
            iVar17 = func_0x0001804580f0(piVar16, iVar21, 0x3d);
            uVar28 = 0xffffffffffffffff;
            if (iVar17 != iVar21) {
                uVar28 = iVar17 - (int64_t)piVar16;
            }
        }
        if (uVar28 == 0xffffffffffffffff) {
            pauVar18 = (undefined (*) [16])func_0x000180185b50(&var_88h, &var_a8h, 0x1804a6100);
            if ((undefined (*) [16])&var_c8h == pauVar18) {
code_r0x00018017c14f:
                uVar28 = 0;
                if (0xf < (uint64_t)var_70h) {
                    uVar24 = var_70h + 1;
                    iVar17 = CONCAT71(var_88h._1_7_, (undefined)var_88h);
                    iVar21 = iVar17;
                    if (0xfff < uVar24) {
                        iVar21 = *(int64_t *)(iVar17 + -8);
                        puVar12 = auStackY_298;
                        if (0x1f < (iVar17 - iVar21) - 8U) goto code_r0x00018017c25b;
                        uVar24 = var_70h + 0x28;
                    }
                    fcn.180459c3c(iVar21, uVar24);
                }
                piVar16 = &var_c8h;
                if (0xf < (uint64_t)var_b0h) {
                    piVar16 = (int64_t *)var_c8h;
                }
                iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6154);
                if (iVar10 == 0) {
                    *(undefined *)(arg1 + 0xa4) = 1;
                } else {
                    iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6160);
                    if (iVar10 == 0) {
                        *(undefined *)(arg1 + 0xa5) = 1;
                    } else {
                        piVar16 = &var_c8h;
                        if (0xf < (uint64_t)var_b0h) {
                            piVar16 = (int64_t *)var_c8h;
                        }
                        iVar21 = func_0x00018045b9a8(0x1804a6190, 0x5c);
                        uVar20 = func_0x0001801723e0();
                        var_268h = 0x1804a6170;
                        var_270h._0_4_ = 0x5f;
                        var_278h = iVar21 + 1;
                        func_0x000180172b00(uVar20, 2, 0x1804a61f8, piVar16);
                    }
                }
                goto code_r0x00018017c018;
            }
            if ((uint64_t)var_b0h < 0x10) {
code_r0x00018017c10c:
                _var_c8h = *pauVar18;
                var_b8h = *(int64_t *)pauVar18[1];
                var_b0h = *(int64_t *)(pauVar18[1] + 8);
                *(undefined8 *)pauVar18[1] = 0;
                *(undefined8 *)(pauVar18[1] + 8) = 0xf;
                (*pauVar18)[0] = 0;
                goto code_r0x00018017c14f;
            }
            uVar24 = var_b0h + 1;
            iVar21 = var_c8h;
            if (uVar24 < 0x1000) {
code_r0x00018017c107:
                fcn.180459c3c(iVar21, uVar24);
                goto code_r0x00018017c10c;
            }
            iVar21 = *(int64_t *)(var_c8h + -8);
            puVar12 = auStackY_298;
            if ((var_c8h - iVar21) - 8U < 0x20) {
                uVar24 = var_b0h + 0x28;
                goto code_r0x00018017c107;
            }
code_r0x00018017c25b:
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar26 = puVar12 + 8;
            goto code_r0x00018017c262;
        }
        _var_68h = ZEXT816(0);
        var_58h = 0;
        var_50h = 0;
        uVar24 = uVar28;
        if ((uint64_t)var_98h < uVar28) {
            uVar24 = var_98h;
        }
        piVar16 = &var_a8h;
        if (0xf < (uint64_t)var_90h) {
            piVar16 = (int64_t *)var_a8h;
        }
        func_0x000180004830(&var_68h, piVar16, uVar24);
        var_258h._0_4_ = (uint32_t)var_258h | 1;
        pauVar18 = (undefined (*) [16])func_0x000180185b50(&var_88h, &var_68h, 0x1804a6100);
        if ((undefined (*) [16])&var_c8h != pauVar18) {
            if ((uint64_t)var_b0h < 0x10) {
code_r0x00018017b8a5:
                _var_c8h = *pauVar18;
                var_b8h = *(int64_t *)pauVar18[1];
                var_b0h = *(int64_t *)(pauVar18[1] + 8);
                *(undefined8 *)pauVar18[1] = 0;
                *(undefined8 *)(pauVar18[1] + 8) = 0xf;
                (*pauVar18)[0] = 0;
                goto code_r0x00018017b8e2;
            }
            uVar24 = var_b0h + 1;
            iVar21 = var_c8h;
            if (uVar24 < 0x1000) {
code_r0x00018017b8a0:
                fcn.180459c3c(iVar21, uVar24);
                goto code_r0x00018017b8a5;
            }
            iVar21 = *(int64_t *)(var_c8h + -8);
            if ((var_c8h - iVar21) - 8U < 0x20) {
                uVar24 = var_b0h + 0x28;
                goto code_r0x00018017b8a0;
            }
code_r0x00018017c24d:
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar12 = auStackY_290;
code_r0x00018017c254:
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar12 = puVar12 + 8;
            goto code_r0x00018017c25b;
        }
code_r0x00018017b8e2:
        if (0xf < (uint64_t)var_70h) {
            uVar24 = var_70h + 1;
            iVar17 = CONCAT71(var_88h._1_7_, (undefined)var_88h);
            iVar21 = iVar17;
            if (0xfff < uVar24) {
                iVar21 = *(int64_t *)(iVar17 + -8);
                if (0x1f < (iVar17 - iVar21) - 8U) goto code_r0x00018017c24d;
                uVar24 = var_70h + 0x28;
            }
            fcn.180459c3c(iVar21, uVar24);
        }
        var_78h = 0;
        var_70h = 0xf;
        var_88h._0_1_ = 0;
        if (0xf < (uint64_t)var_50h) {
            uVar24 = var_50h + 1;
            iVar21 = var_68h;
            if (0xfff < uVar24) {
                iVar21 = *(int64_t *)(var_68h + -8);
                puVar12 = auStackY_298;
                if (0x1f < (var_68h - iVar21) - 8U) goto code_r0x00018017c25b;
                uVar24 = var_50h + 0x28;
            }
            fcn.180459c3c(iVar21, uVar24);
        }
        uVar24 = uVar28 + 1;
        _var_68h = ZEXT816(0);
        uVar28 = 0;
        var_58h = 0;
        var_50h = 0;
        if ((uint64_t)var_98h < uVar24) {
            func_0x00018000f930();
            goto code_r0x00018017c384;
        }
        iVar21 = -1;
        if (var_98h - uVar24 != -1) {
            iVar21 = var_98h - uVar24;
        }
        piVar16 = &var_a8h;
        if (0xf < (uint64_t)var_90h) {
            piVar16 = (int64_t *)var_a8h;
        }
        func_0x000180004830(&var_68h, (int64_t)piVar16 + uVar24, iVar21);
        var_258h._0_4_ = (uint32_t)var_258h | 2;
        pauVar18 = (undefined (*) [16])func_0x000180185b50(&var_88h, &var_68h, 0x1804a6100);
        if ((undefined (*) [16])&var_e8h != pauVar18) {
            if (0xf < (uint64_t)var_d0h) {
                uVar24 = var_d0h + 1;
                iVar21 = var_e8h;
                if (0xfff < uVar24) {
                    iVar21 = *(int64_t *)(var_e8h + -8);
                    puVar12 = auStackY_298;
                    if (0x1f < (var_e8h - iVar21) - 8U) goto code_r0x00018017c254;
                    uVar24 = var_d0h + 0x28;
                }
                fcn.180459c3c(iVar21, uVar24);
            }
            _var_e8h = *pauVar18;
            var_d8h = *(int64_t *)pauVar18[1];
            var_d0h = *(int64_t *)(pauVar18[1] + 8);
            *(undefined8 *)pauVar18[1] = 0;
            *(undefined8 *)(pauVar18[1] + 8) = 0xf;
            (*pauVar18)[0] = 0;
        }
        if (0xf < (uint64_t)var_70h) {
            uVar24 = var_70h + 1;
            iVar17 = CONCAT71(var_88h._1_7_, (undefined)var_88h);
            iVar21 = iVar17;
            if (0xfff < uVar24) {
                iVar21 = *(int64_t *)(iVar17 + -8);
                puVar12 = auStackY_298;
                if (0x1f < (iVar17 - iVar21) - 8U) goto code_r0x00018017c254;
                uVar24 = var_70h + 0x28;
            }
            fcn.180459c3c(iVar21, uVar24);
        }
        var_78h = 0;
        var_70h = 0xf;
        var_88h._0_1_ = 0;
        if (0xf < (uint64_t)var_50h) {
            uVar24 = var_50h + 1;
            iVar21 = var_68h;
            if (0xfff < uVar24) {
                iVar21 = *(int64_t *)(var_68h + -8);
                puVar12 = auStackY_298;
                if (0x1f < (var_68h - iVar21) - 8U) goto code_r0x00018017c25b;
                uVar24 = var_50h + 0x28;
            }
            fcn.180459c3c(iVar21, uVar24);
        }
        piVar16 = &var_c8h;
        if (0xf < (uint64_t)var_b0h) {
            piVar16 = (int64_t *)var_c8h;
        }
        iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6108);
        if (iVar10 == 0) {
            if (ppiVar29 != (int64_t **)&var_e8h) {
                piVar16 = &var_e8h;
                if (0xf < (uint64_t)var_d0h) {
                    piVar16 = (int64_t *)var_e8h;
                }
                func_0x00018000f180(ppiVar29, piVar16, var_d8h);
            }
        } else {
            iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6110);
            if (iVar10 == 0) {
                if (ppiVar13 != (int64_t **)&var_e8h) {
                    piVar16 = &var_e8h;
                    if (0xf < (uint64_t)var_d0h) {
                        piVar16 = (int64_t *)var_e8h;
                    }
                    func_0x00018000f180(ppiVar13, piVar16, var_d8h);
                }
            } else {
                iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6118);
                if (iVar10 == 0) {
                    if (ppiVar14 != (int64_t **)&var_e8h) {
                        piVar16 = &var_e8h;
                        if (0xf < (uint64_t)var_d0h) {
                            piVar16 = (int64_t *)var_e8h;
                        }
                        func_0x00018000f180(ppiVar14, piVar16, var_d8h);
                    }
                } else {
                    iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6120);
                    if (iVar10 == 0) {
                        piVar16 = &var_e8h;
                        if (0xf < (uint64_t)var_d0h) {
                            piVar16 = (int64_t *)var_e8h;
                        }
                        uVar11 = func_0x00018046eadc(piVar16);
                        *(undefined4 *)(arg1 + 0xa0) = uVar11;
                    } else {
                        iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6128);
                        uVar11 = 0;
                        if (iVar10 == 0) {
                            piVar16 = &var_e8h;
                            if (0xf < (uint64_t)var_d0h) {
                                piVar16 = (int64_t *)var_e8h;
                            }
                            iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6134);
                            if (iVar10 == 0) {
                                *(undefined4 *)(arg1 + 0xa8) = 1;
                            } else {
                                piVar16 = &var_e8h;
                                if (0xf < (uint64_t)var_d0h) {
                                    piVar16 = (int64_t *)var_e8h;
                                }
                                iVar10 = func_0x00018047b6d0(piVar16, 0x1804a613c);
                                if (iVar10 == 0) {
                                    *(undefined4 *)(arg1 + 0xa8) = 2;
                                } else {
                                    piVar16 = &var_e8h;
                                    if (0xf < (uint64_t)var_d0h) {
                                        piVar16 = (int64_t *)var_e8h;
                                    }
                                    iVar10 = func_0x00018047b6d0(piVar16, 0x180644c8c);
                                    if (iVar10 == 0) {
                                        uVar11 = 3;
                                    }
                                    *(undefined4 *)(arg1 + 0xa8) = uVar11;
                                }
                            }
                        } else {
                            iVar10 = func_0x00018047b6d0(piVar16, 0x180634328);
                            if (iVar10 == 0) {
                                piVar16 = &var_e8h;
                                if (0xf < (uint64_t)var_d0h) {
                                    piVar16 = (int64_t *)var_e8h;
                                }
                                iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6140);
                                if (iVar10 == 0) {
                                    *(undefined4 *)(arg1 + 0xac) = 1;
                                } else {
                                    piVar16 = &var_e8h;
                                    if (0xf < (uint64_t)var_d0h) {
                                        piVar16 = (int64_t *)var_e8h;
                                    }
                                    iVar10 = func_0x00018047b6d0(piVar16, 0x1804a6144);
                                    if (iVar10 == 0) {
                                        *(undefined4 *)(arg1 + 0xac) = 2;
                                    } else {
                                        piVar16 = &var_e8h;
                                        if (0xf < (uint64_t)var_d0h) {
                                            piVar16 = (int64_t *)var_e8h;
                                        }
                                        iVar10 = func_0x00018047b6d0(piVar16, 0x1804a614c);
                                        if (iVar10 == 0) {
                                            uVar11 = 3;
                                        }
                                        *(undefined4 *)(arg1 + 0xac) = uVar11;
                                    }
                                }
                            } else {
                                if (*(int64_t *)(arg1 + 0x10) == 0) {
                                    if ((int64_t *)arg1 != &var_c8h) {
                                        piVar16 = &var_c8h;
                                        if (0xf < (uint64_t)var_b0h) {
                                            piVar16 = (int64_t *)var_c8h;
                                        }
                                        func_0x00018000f180(arg1, piVar16, var_b8h);
                                    }
                                    if ((int64_t *)(arg1 + 0x20) != &var_e8h) {
                                        piVar16 = &var_e8h;
                                        if (0xf < (uint64_t)var_d0h) {
                                            piVar16 = (int64_t *)var_e8h;
                                        }
                                        func_0x00018000f180((int64_t *)(arg1 + 0x20), piVar16, var_d8h);
                                    }
                                }
                                iVar9 = var_b0h;
                                iVar17 = var_b8h;
                                puVar19 = (undefined8 *)*piVar23;
                                puVar25 = (undefined8 *)puVar19[1];
                                iVar21 = var_c8h;
                                if (*(char *)((int64_t)puVar25 + 0x19) == '\0') {
                                    do {
                                        piVar23 = &var_c8h;
                                        if (0xf < (uint64_t)iVar9) {
                                            piVar23 = (int64_t *)iVar21;
                                        }
                                        if ((uint64_t)puVar25[7] < 0x10) {
                                            puVar22 = puVar25 + 4;
                                        } else {
                                            puVar22 = (undefined8 *)puVar25[4];
                                        }
                                        uVar28 = puVar25[6];
                                        uVar24 = uVar28;
                                        if ((uint64_t)iVar17 < uVar28) {
                                            uVar24 = iVar17;
                                        }
                                        var_240h = (int64_t)puVar25;
                                        iVar10 = func_0x000180497f30(puVar22, piVar23, uVar24);
                                        if (iVar10 == 0) {
                                            if (uVar28 < (uint64_t)iVar17) goto code_r0x00018017bed9;
code_r0x00018017bebe:
                                            uVar11 = 1;
                                            puVar22 = (undefined8 *)*puVar25;
                                            puVar19 = puVar25;
                                        } else {
                                            if (-1 < iVar10) goto code_r0x00018017bebe;
code_r0x00018017bed9:
                                            uVar11 = 0;
                                            puVar22 = (undefined8 *)puVar25[2];
                                        }
                                        puVar25 = puVar22;
                                    } while (*(char *)((int64_t)puVar22 + 0x19) == '\0');
                                } else {
                                    uVar11 = 0;
                                    var_240h = (int64_t)puVar25;
                                }
                                if (*(char *)((int64_t)puVar19 + 0x19) == '\0') {
                                    if ((uint64_t)puVar19[7] < 0x10) {
                                        puVar25 = puVar19 + 4;
                                    } else {
                                        puVar25 = (undefined8 *)puVar19[4];
                                    }
                                    piVar23 = &var_c8h;
                                    if (0xf < (uint64_t)iVar9) {
                                        piVar23 = (int64_t *)iVar21;
                                    }
                                    uVar28 = puVar19[6];
                                    uVar24 = iVar17;
                                    if (uVar28 < (uint64_t)iVar17) {
                                        uVar24 = uVar28;
                                    }
                                    iVar10 = func_0x000180497f30(piVar23, puVar25, uVar24);
                                    piVar23 = (int64_t *)var_250h;
                                    if (iVar10 == 0) {
                                        if ((uint64_t)iVar17 < uVar28) goto code_r0x00018017bf34;
                                    } else if (iVar10 < 0) goto code_r0x00018017bf34;
                                } else {
code_r0x00018017bf34:
                                    piVar23 = (int64_t *)var_250h;
                                    if (*(int64_t *)(var_250h + 8) == 0x2aaaaaaaaaaaaaa) {
code_r0x00018017c384:
                                        func_0x000180013c00();
                                        pcVar2 = (code *)swi(3);
                                        (*pcVar2)();
                                        return;
                                    }
                                    uVar20 = *(undefined8 *)var_250h;
                                    var_220h = var_250h;
                                    var_218h = 0;
                                    puVar19 = (undefined8 *)func_0x000180459890(0x60);
                                    var_218h = (int64_t)puVar19;
                                    func_0x00018000b4d0(puVar19 + 4, &var_c8h);
                                    *(undefined (*) [16])(puVar19 + 8) = ZEXT816(0);
                                    puVar19[10] = 0;
                                    puVar19[0xb] = 0xf;
                                    *(undefined *)(puVar19 + 8) = 0;
                                    *puVar19 = uVar20;
                                    puVar19[1] = uVar20;
                                    puVar19[2] = uVar20;
                                    *(undefined2 *)(puVar19 + 3) = 0;
                                    var_218h = 0;
                                    var_208h = var_240h;
                                    var_200h._0_4_ = uVar11;
                                    puVar19 = (undefined8 *)func_0x0001800156d0(piVar23, &var_208h, puVar19);
                                }
                                arg1 = var_238h;
                                ppiVar29 = (int64_t **)var_248h;
                                ppiVar14 = (int64_t **)var_230h;
                                ppiVar13 = (int64_t **)var_228h;
                                if (puVar19 + 8 != &var_e8h) {
                                    piVar16 = &var_e8h;
                                    if (0xf < (uint64_t)var_d0h) {
                                        piVar16 = (int64_t *)var_e8h;
                                    }
                                    func_0x00018000f180(puVar19 + 8, piVar16, var_d8h);
                                    arg1 = var_238h;
                                    ppiVar29 = (int64_t **)var_248h;
                                    ppiVar14 = (int64_t **)var_230h;
                                    ppiVar13 = (int64_t **)var_228h;
                                }
                            }
                        }
                    }
                }
            }
        }
code_r0x00018017c018:
        piVar16 = (int64_t *)func_0x00018007d3a0(&var_1e8h, &var_a8h, 0x3b);
        uVar1 = *(uint8_t *)((int64_t)*(int32_t *)(*piVar16 + 4) + 0x10 + (int64_t)piVar16);
    } while( true );
}

// ============================================================
// Function: FUN_18017c390
// Address: 0x18017c390
// Size: 242 bytes
// ============================================================
void fcn.18017c390(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    undefined4 *arg2_00;
    uint64_t uVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    
    puVar14 = auStack_48;
    puVar13 = auStack_48;
    iVar1 = *(int64_t *)arg1;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1 >> 4) < (uint64_t)arg2) {
        if (0xfffffffffffffff < (uint64_t)arg2) {
            func_0x000180010010();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 8);
        uVar10 = arg2 * 0x10;
        arg2_00 = (undefined4 *)0x0;
        if (uVar10 != 0) {
            if (uVar10 < 0x1000) {
                arg2_00 = (undefined4 *)func_0x000180459890();
                puVar14 = auStack_48;
            } else {
                if (uVar10 + 0x27 <= uVar10) {
                    func_0x000180004720();
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar9 = func_0x000180459890(uVar10 + 0x27);
                iVar11 = iVar9;
                if (iVar9 == 0) {
                    iVar11 = 5;
                    pcVar4 = (code *)swi(0x29);
                    iVar9 = (*pcVar4)();
                    puVar13 = auStack_40;
                }
                arg2_00 = (undefined4 *)(iVar9 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(arg2_00 + -2) = iVar11;
                puVar14 = puVar13;
            }
        }
        puVar3 = *(undefined4 **)(arg1 + 8);
        puVar8 = arg2_00;
        for (puVar12 = *(undefined4 **)arg1; puVar12 != puVar3; puVar12 = puVar12 + 4) {
            uVar5 = puVar12[1];
            uVar6 = puVar12[2];
            uVar7 = puVar12[3];
            *puVar8 = *puVar12;
            puVar8[1] = uVar5;
            puVar8[2] = uVar6;
            puVar8[3] = uVar7;
            *(undefined *)puVar12 = 0;
            *(undefined8 *)(puVar12 + 2) = 0;
            puVar8 = puVar8 + 4;
        }
        *(undefined8 *)(puVar14 + -8) = 0x18017c46b;
        fcn.180178dc0(arg1, (int64_t)arg2_00, iVar2 - iVar1 >> 4, arg2);
    }
    return;
}

// ============================================================
// Function: FUN_18017c500
// Address: 0x18017c500
// Size: 133 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_13h

void fcn.18017c500(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    char *pcVar2;
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_30h;
    char acStack_14 [4];
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    pcVar2 = acStack_14 + 1;
    do {
        pcVar2 = pcVar2 + -1;
        uVar1 = (uint64_t)arg2 / 10;
        *pcVar2 = (char)arg2 + (char)uVar1 * -10 + '0';
        arg2 = uVar1;
    } while (uVar1 != 0);
    var_30h = arg1;
    fcn.180014b30(arg1, pcVar2, acStack_14 + 1, &var_38h);
    fcn.180459870(var_10h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_18017c590
// Address: 0x18017c590
// Size: 20 bytes
// ============================================================
void fcn.18017c590(int64_t arg1)
{
    (**(code **)(*(int64_t *)(arg1 + 0x20) + 8))();
    return;
}

// ============================================================
// Function: FUN_18017c5b0
// Address: 0x18017c5b0
// Size: 352 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

int64_t fcn.18017c5b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t *piVar9;
    undefined8 *puVar10;
    uint32_t uVar11;
    int64_t var_68h;
    int64_t var_60h;
    
    puVar6 = *(undefined8 **)arg1;
    puVar10 = (undefined8 *)puVar6[1];
    uVar11 = 0;
    cVar1 = *(char *)((int64_t)puVar10 + 0x19);
    puVar4 = puVar10;
    while (puVar3 = puVar10, cVar1 == '\0') {
        iVar8 = arg3;
        if (0xf < *(uint64_t *)(arg3 + 0x18)) {
            iVar8 = *(int64_t *)arg3;
        }
        piVar9 = puVar3 + 4;
        if (0xf < (uint64_t)puVar3[7]) {
            piVar9 = (int64_t *)*piVar9;
        }
        iVar5 = func_0x00018047b6d0(piVar9, iVar8);
        if (-1 < iVar5) {
            puVar10 = (undefined8 *)*puVar3;
            puVar6 = puVar3;
        } else {
            puVar10 = (undefined8 *)puVar3[2];
        }
        uVar11 = (uint32_t)(-1 < iVar5);
        cVar1 = *(char *)((int64_t)puVar10 + 0x19);
        puVar4 = puVar3;
    }
    if (*(char *)((int64_t)puVar6 + 0x19) == '\0') {
        piVar9 = puVar6 + 4;
        if (0xf < (uint64_t)puVar6[7]) {
            piVar9 = (int64_t *)*piVar9;
        }
        iVar8 = arg3;
        if (0xf < *(uint64_t *)(arg3 + 0x18)) {
            iVar8 = *(int64_t *)arg3;
        }
        iVar5 = func_0x00018047b6d0(iVar8, piVar9);
        if (-1 < iVar5) {
            *(undefined8 **)arg2 = puVar6;
            *(undefined *)(arg2 + 8) = 0;
            return arg2;
        }
    }
    if (*(int64_t *)(arg1 + 8) != 0x2aaaaaaaaaaaaaa) {
        uVar7 = *(undefined8 *)arg1;
        var_60h = 0;
        var_68h = arg1;
        puVar6 = (undefined8 *)fcn.180459890(0x60);
        var_60h = (int64_t)puVar6;
        func_0x00018000b4d0(puVar6 + 4, arg3);
        *(undefined (*) [16])(puVar6 + 8) = ZEXT816(0);
        puVar6[10] = 0;
        puVar6[0xb] = 0xf;
        *(undefined *)(puVar6 + 8) = 0;
        *puVar6 = uVar7;
        puVar6[1] = uVar7;
        puVar6[2] = uVar7;
        *(undefined2 *)(puVar6 + 3) = 0;
        var_60h = CONCAT44(var_60h._4_4_, uVar11);
        var_68h = (int64_t)puVar4;
        uVar7 = func_0x0001800156d0(arg1, &var_68h, puVar6);
        *(undefined8 *)arg2 = uVar7;
        *(undefined *)(arg2 + 8) = 1;
        return arg2;
    }
    func_0x000180013c00();
    pcVar2 = (code *)swi(3);
    iVar8 = (*pcVar2)();
    return iVar8;
}

// ============================================================
// Function: FUN_18017c710
// Address: 0x18017c710
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18017c710(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined4 uVar2;
    undefined (*pauVar3) [16];
    undefined8 uVar4;
    int64_t iVar5;
    undefined (*pauVar6) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    
    pauVar6 = (undefined (*) [16])0x0;
    pauVar3 = (undefined (*) [16])fcn.180459890(0x200);
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        *(undefined4 *)(*pauVar3 + 8) = 1;
        *(undefined4 *)(*pauVar3 + 0xc) = 1;
        *(undefined8 *)*pauVar3 = 0x1804a7208;
        arg2 = *(int64_t *)arg2;
        *(undefined8 *)pauVar3[1] = 0x1804a6a98;
        *(undefined4 *)pauVar3[3] = 0;
        *(undefined8 *)pauVar3[7] = 0;
        *(undefined8 *)pauVar3[0xb] = 0;
        *(undefined8 *)pauVar3[0xf] = 0;
        *(undefined8 *)(pauVar3[0xf] + 8) = 0;
        *(undefined8 *)pauVar3[0x10] = 0;
        *(int64_t *)(pauVar3[1] + 8) = arg2;
        *(undefined4 *)pauVar3[2] = 0xffffffff;
        *(undefined4 *)(pauVar3[2] + 4) = 0;
        *(undefined8 *)(pauVar3[2] + 8) = 0;
        LOCK();
        *(undefined4 *)pauVar3[3] = 4;
        UNLOCK();
        if (arg2 != 0) {
            uVar2 = func_0x000180173970(arg2);
            *(undefined4 *)pauVar3[2] = uVar2;
            uVar2 = func_0x000180173bc0(arg2);
            *(undefined4 *)(pauVar3[2] + 4) = uVar2;
            uVar4 = func_0x0001801736d0(arg2);
            *(undefined8 *)(pauVar3[2] + 8) = uVar4;
            func_0x000180174090(arg2, pauVar3 + 1);
            cVar1 = func_0x000180173be0(arg2);
            if (cVar1 != '\0') {
                LOCK();
                *(undefined4 *)pauVar3[3] = 0;
                UNLOCK();
            }
            iVar5 = func_0x000180173a00(arg2);
            if (iVar5 == 0) {
                func_0x000180174310(*(undefined8 *)(pauVar3[1] + 8), 0x18017fb00);
            }
            iVar5 = func_0x000180173a10(arg2);
            if (iVar5 == 0) {
                func_0x000180174320(*(undefined8 *)(pauVar3[1] + 8), 0x18017fb80);
            }
            iVar5 = func_0x0001801739f0(arg2);
            if (iVar5 == 0) {
                func_0x0001801742f0(*(undefined8 *)(pauVar3[1] + 8), 0x18017fa80);
            }
        }
        *(undefined8 *)pauVar3[0x14] = 0;
        *(undefined8 *)pauVar3[1] = 0x1804a6ab8;
        *(undefined8 *)pauVar3[0x18] = 0;
        *(undefined8 *)pauVar3[0x19] = 0x1804a6a88;
        *(undefined4 *)(pauVar3[0x18] + 8) = 0;
        *(undefined4 *)(pauVar3[0x18] + 0xc) = 8;
        *(undefined8 *)(pauVar3[0x19] + 8) = 0;
        *(undefined8 *)pauVar3[0x1a] = 0;
        pauVar3[0x1a][8] = 0;
        *(undefined (*) [16])(pauVar3[0x1c] + 8) = ZEXT816(0);
        *(undefined (*) [16])(pauVar3[0x1d] + 8) = ZEXT816(0);
        *(undefined (*) [16])(pauVar3[0x1e] + 8) = ZEXT816(0);
        *(undefined8 *)(pauVar3[0x1b] + 8) = 0;
        *(undefined8 *)pauVar3[0x1c] = 0;
        *(undefined4 *)(pauVar3[0x1f] + 8) = 0xffffffff;
        *(undefined4 *)pauVar3[0x1b] = 2;
        *(undefined4 *)(pauVar3[0x1f] + 0xc) = 0;
        pauVar6 = pauVar3;
    }
    *(undefined (**) [16])arg1 = pauVar6 + 1;
    *(undefined (**) [16])(arg1 + 8) = pauVar6;
    return arg1;
}

// ============================================================
// Function: FUN_18017c744
// Address: 0x18017c744
// Size: 420 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18017c710(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined4 uVar2;
    undefined (*pauVar3) [16];
    undefined8 uVar4;
    int64_t iVar5;
    undefined (*pauVar6) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    
    pauVar6 = (undefined (*) [16])0x0;
    pauVar3 = (undefined (*) [16])fcn.180459890(0x200);
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        *(undefined4 *)(*pauVar3 + 8) = 1;
        *(undefined4 *)(*pauVar3 + 0xc) = 1;
        *(undefined8 *)*pauVar3 = 0x1804a7208;
        arg2 = *(int64_t *)arg2;
        *(undefined8 *)pauVar3[1] = 0x1804a6a98;
        *(undefined4 *)pauVar3[3] = 0;
        *(undefined8 *)pauVar3[7] = 0;
        *(undefined8 *)pauVar3[0xb] = 0;
        *(undefined8 *)pauVar3[0xf] = 0;
        *(undefined8 *)(pauVar3[0xf] + 8) = 0;
        *(undefined8 *)pauVar3[0x10] = 0;
        *(int64_t *)(pauVar3[1] + 8) = arg2;
        *(undefined4 *)pauVar3[2] = 0xffffffff;
        *(undefined4 *)(pauVar3[2] + 4) = 0;
        *(undefined8 *)(pauVar3[2] + 8) = 0;
        LOCK();
        *(undefined4 *)pauVar3[3] = 4;
        UNLOCK();
        if (arg2 != 0) {
            uVar2 = func_0x000180173970(arg2);
            *(undefined4 *)pauVar3[2] = uVar2;
            uVar2 = func_0x000180173bc0(arg2);
            *(undefined4 *)(pauVar3[2] + 4) = uVar2;
            uVar4 = func_0x0001801736d0(arg2);
            *(undefined8 *)(pauVar3[2] + 8) = uVar4;
            func_0x000180174090(arg2, pauVar3 + 1);
            cVar1 = func_0x000180173be0(arg2);
            if (cVar1 != '\0') {
                LOCK();
                *(undefined4 *)pauVar3[3] = 0;
                UNLOCK();
            }
            iVar5 = func_0x000180173a00(arg2);
            if (iVar5 == 0) {
                func_0x000180174310(*(undefined8 *)(pauVar3[1] + 8), 0x18017fb00);
            }
            iVar5 = func_0x000180173a10(arg2);
            if (iVar5 == 0) {
                func_0x000180174320(*(undefined8 *)(pauVar3[1] + 8), 0x18017fb80);
            }
            iVar5 = func_0x0001801739f0(arg2);
            if (iVar5 == 0) {
                func_0x0001801742f0(*(undefined8 *)(pauVar3[1] + 8), 0x18017fa80);
            }
        }
        *(undefined8 *)pauVar3[0x14] = 0;
        *(undefined8 *)pauVar3[1] = 0x1804a6ab8;
        *(undefined8 *)pauVar3[0x18] = 0;
        *(undefined8 *)pauVar3[0x19] = 0x1804a6a88;
        *(undefined4 *)(pauVar3[0x18] + 8) = 0;
        *(undefined4 *)(pauVar3[0x18] + 0xc) = 8;
        *(undefined8 *)(pauVar3[0x19] + 8) = 0;
        *(undefined8 *)pauVar3[0x1a] = 0;
        pauVar3[0x1a][8] = 0;
        *(undefined (*) [16])(pauVar3[0x1c] + 8) = ZEXT816(0);
        *(undefined (*) [16])(pauVar3[0x1d] + 8) = ZEXT816(0);
        *(undefined (*) [16])(pauVar3[0x1e] + 8) = ZEXT816(0);
        *(undefined8 *)(pauVar3[0x1b] + 8) = 0;
        *(undefined8 *)pauVar3[0x1c] = 0;
        *(undefined4 *)(pauVar3[0x1f] + 8) = 0xffffffff;
        *(undefined4 *)pauVar3[0x1b] = 2;
        *(undefined4 *)(pauVar3[0x1f] + 0xc) = 0;
        pauVar6 = pauVar3;
    }
    *(undefined (**) [16])arg1 = pauVar6 + 1;
    *(undefined (**) [16])(arg1 + 8) = pauVar6;
    return arg1;
}

// ============================================================
// Function: FUN_18017c8e8
// Address: 0x18017c8e8
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18017c710(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined4 uVar2;
    undefined (*pauVar3) [16];
    undefined8 uVar4;
    int64_t iVar5;
    undefined (*pauVar6) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    
    pauVar6 = (undefined (*) [16])0x0;
    pauVar3 = (undefined (*) [16])fcn.180459890(0x200);
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        *(undefined4 *)(*pauVar3 + 8) = 1;
        *(undefined4 *)(*pauVar3 + 0xc) = 1;
        *(undefined8 *)*pauVar3 = 0x1804a7208;
        arg2 = *(int64_t *)arg2;
        *(undefined8 *)pauVar3[1] = 0x1804a6a98;
        *(undefined4 *)pauVar3[3] = 0;
        *(undefined8 *)pauVar3[7] = 0;
        *(undefined8 *)pauVar3[0xb] = 0;
        *(undefined8 *)pauVar3[0xf] = 0;
        *(undefined8 *)(pauVar3[0xf] + 8) = 0;
        *(undefined8 *)pauVar3[0x10] = 0;
        *(int64_t *)(pauVar3[1] + 8) = arg2;
        *(undefined4 *)pauVar3[2] = 0xffffffff;
        *(undefined4 *)(pauVar3[2] + 4) = 0;
        *(undefined8 *)(pauVar3[2] + 8) = 0;
        LOCK();
        *(undefined4 *)pauVar3[3] = 4;
        UNLOCK();
        if (arg2 != 0) {
            uVar2 = func_0x000180173970(arg2);
            *(undefined4 *)pauVar3[2] = uVar2;
            uVar2 = func_0x000180173bc0(arg2);
            *(undefined4 *)(pauVar3[2] + 4) = uVar2;
            uVar4 = func_0x0001801736d0(arg2);
            *(undefined8 *)(pauVar3[2] + 8) = uVar4;
            func_0x000180174090(arg2, pauVar3 + 1);
            cVar1 = func_0x000180173be0(arg2);
            if (cVar1 != '\0') {
                LOCK();
                *(undefined4 *)pauVar3[3] = 0;
                UNLOCK();
            }
            iVar5 = func_0x000180173a00(arg2);
            if (iVar5 == 0) {
                func_0x000180174310(*(undefined8 *)(pauVar3[1] + 8), 0x18017fb00);
            }
            iVar5 = func_0x000180173a10(arg2);
            if (iVar5 == 0) {
                func_0x000180174320(*(undefined8 *)(pauVar3[1] + 8), 0x18017fb80);
            }
            iVar5 = func_0x0001801739f0(arg2);
            if (iVar5 == 0) {
                func_0x0001801742f0(*(undefined8 *)(pauVar3[1] + 8), 0x18017fa80);
            }
        }
        *(undefined8 *)pauVar3[0x14] = 0;
        *(undefined8 *)pauVar3[1] = 0x1804a6ab8;
        *(undefined8 *)pauVar3[0x18] = 0;
        *(undefined8 *)pauVar3[0x19] = 0x1804a6a88;
        *(undefined4 *)(pauVar3[0x18] + 8) = 0;
        *(undefined4 *)(pauVar3[0x18] + 0xc) = 8;
        *(undefined8 *)(pauVar3[0x19] + 8) = 0;
        *(undefined8 *)pauVar3[0x1a] = 0;
        pauVar3[0x1a][8] = 0;
        *(undefined (*) [16])(pauVar3[0x1c] + 8) = ZEXT816(0);
        *(undefined (*) [16])(pauVar3[0x1d] + 8) = ZEXT816(0);
        *(undefined (*) [16])(pauVar3[0x1e] + 8) = ZEXT816(0);
        *(undefined8 *)(pauVar3[0x1b] + 8) = 0;
        *(undefined8 *)pauVar3[0x1c] = 0;
        *(undefined4 *)(pauVar3[0x1f] + 8) = 0xffffffff;
        *(undefined4 *)pauVar3[0x1b] = 2;
        *(undefined4 *)(pauVar3[0x1f] + 0xc) = 0;
        pauVar6 = pauVar3;
    }
    *(undefined (**) [16])arg1 = pauVar6 + 1;
    *(undefined (**) [16])(arg1 + 8) = pauVar6;
    return arg1;
}

// ============================================================
// Function: FUN_18017c910
// Address: 0x18017c910
// Size: 479 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18017c910(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    bool bVar5;
    bool bVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    *(undefined8 *)arg1 = 0x1804a6ac8;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined (*) [16])(arg1 + 0x18) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0xf;
    *(undefined *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0x130) = 0;
    *(undefined8 *)(arg1 + 0x138) = 0;
    *(undefined8 *)(arg1 + 0x140) = 0;
    if (*(int64_t *)arg2 == 0) {
        piVar7 = (int64_t *)func_0x000180063840(&var_38h);
        bVar6 = false;
        bVar5 = true;
        iVar8 = *piVar7;
    } else {
        if (*(int64_t *)(arg2 + 8) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar8 = *(int64_t *)arg2;
        var_40h = *(int64_t *)(arg2 + 8);
        piVar7 = &var_48h;
        bVar6 = true;
        bVar5 = false;
        var_48h = iVar8;
    }
    iVar4 = piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    *(int64_t *)(arg1 + 0x138) = iVar8;
    piVar7 = *(int64_t **)(arg1 + 0x140);
    *(int64_t *)(arg1 + 0x140) = iVar4;
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar7 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    if (bVar5) {
        if (var_30h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_30h + 8);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (***(code ***)var_30h)(var_30h);
                LOCK();
                piVar1 = (int32_t *)(var_30h + 0xc);
                iVar3 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*(int64_t *)var_30h + 8))(var_30h);
                }
            }
        }
    }
    iVar8 = var_40h;
    if ((bVar6) && (var_40h != 0)) {
        LOCK();
        piVar1 = (int32_t *)(var_40h + 8);
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (***(code ***)var_40h)(var_40h);
            LOCK();
            piVar1 = (int32_t *)(iVar8 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*(int64_t *)iVar8 + 8))(iVar8);
            }
        }
    }
    *(undefined4 *)(arg1 + 0x38) = 0;
    *(undefined4 *)(arg1 + 0x58) = 10000;
    *(undefined *)(arg1 + 0x5c) = 0;
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0;
    *(undefined8 *)(arg1 + 0x70) = 0;
    piVar7 = *(int64_t **)(arg2 + 8);
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar7 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017caf0
// Address: 0x18017caf0
// Size: 469 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_50h

int64_t fcn.18017caf0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_2c;
    
    if (*(int64_t *)(arg2 + 8) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar4 = *(int64_t *)arg2;
    piVar5 = *(int64_t **)(arg2 + 8);
    _var_38h = *(undefined (*) [12])arg2;
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar5 + 1) = *(int32_t *)(piVar5 + 1) + 1;
        UNLOCK();
    }
    var_50h._4_4_ = (undefined4)((uint64_t)piVar5 >> 0x20);
    uStack_2c = var_50h._4_4_;
    func_0x0001800618a0(arg1 + 0x148, &var_38h);
    if (*(int64_t *)(arg1 + 0x158) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x158) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    _var_48h = *(undefined (*) [16])(arg1 + 0x150);
    fcn.18017c910(arg1, (int64_t)&var_48h, (int64_t)piVar5);
    *(undefined8 *)arg1 = 0x1804a6ad8;
    *(bool *)(arg1 + 0x170) = iVar4 == 0;
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    *(undefined8 *)arg1 = 0x1804a6ae8;
    *(undefined (*) [16])(arg1 + 0x178) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x188) = 0;
    *(undefined8 *)(arg1 + 400) = 0xf;
    *(undefined *)(arg1 + 0x178) = 0;
    *(undefined8 *)(arg1 + 0x1d0) = 0;
    *(undefined8 *)(arg1 + 0x210) = 0;
    *(undefined8 *)(arg1 + 0x250) = 0;
    *(undefined8 *)(arg1 + 0x260) = 0;
    *(undefined8 *)(arg1 + 0x268) = 0;
    *(undefined8 *)(arg1 + 0x270) = 0;
    *(undefined8 *)(arg1 + 0x278) = 0;
    *(undefined8 *)(arg1 + 0x280) = 0;
    *(undefined8 *)(arg1 + 0x288) = 0;
    *(undefined8 *)(arg1 + 0x290) = 0;
    *(undefined8 *)(arg1 + 0x298) = 0;
    *(undefined4 *)(arg1 + 600) = 4;
    *(undefined8 *)(arg1 + 0x2a0) = 3000;
    piVar5 = *(int64_t **)(arg2 + 8);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017ccd0
// Address: 0x18017ccd0
// Size: 295 bytes
// ============================================================
void fcn.18017ccd0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    
    *(undefined8 *)arg1 = 0x1804a6ac8;
    if (*(int64_t *)(arg1 + 0x60) != 0) {
        func_0x000180180fe0();
        *(undefined8 *)(arg1 + 0x60) = 0;
    }
    if (*(int64_t *)(arg1 + 0x68) != 0) {
        func_0x000180180fe0();
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    if (*(int64_t *)(arg1 + 0x70) != 0) {
        func_0x000180180fe0();
        *(undefined8 *)(arg1 + 0x70) = 0;
    }
    piVar4 = *(int64_t **)(arg1 + 0x140);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x130);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0xf8));
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    piVar4 = *(int64_t **)(arg1 + 0xf0);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0xb8));
        *(undefined8 *)(arg1 + 0xf0) = 0;
    }
    piVar4 = *(int64_t **)(arg1 + 0xb0);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x78));
        *(undefined8 *)(arg1 + 0xb0) = 0;
    }
    fcn.180004e40(arg1 + 0x18);
    piVar4 = *(int64_t **)(arg1 + 0x10);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017ce20
// Address: 0x18017ce20
// Size: 45 bytes
// ============================================================
void fcn.18017ce20(int64_t arg1)
{
    int64_t *piVar1;
    
    piVar1 = *(int64_t **)(arg1 + 0x50);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 0x18));
        *(undefined8 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017ce50
// Address: 0x18017ce50
// Size: 277 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18017ce50(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0x1804a6a98;
    if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(arg1 + 0x20) < 3)) {
        iVar5 = func_0x000180173bc0(*(undefined8 *)(arg1 + 8));
        if (*(int32_t *)(arg1 + 0x14) == iVar5) {
            cVar4 = func_0x000180173be0(*(undefined8 *)(arg1 + 8));
            if (cVar4 != '\0') {
                func_0x00018017f680(arg1, 0);
                if (*(int64_t *)(arg1 + 8) != 0) {
                    iVar5 = *(int32_t *)(arg1 + 0x14);
                    iVar6 = func_0x000180173bc0();
                    if (iVar5 == iVar6) {
                        func_0x000180174090(*(undefined8 *)(arg1 + 8), 0);
                    }
                }
            }
        }
    }
    piVar3 = *(int64_t **)(arg1 + 0xf0);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar5 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar5 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    piVar3 = *(int64_t **)(arg1 + 0xe0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)(arg1 + 0xa8));
        *(undefined8 *)(arg1 + 0xe0) = 0;
    }
    piVar3 = *(int64_t **)(arg1 + 0xa0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)(arg1 + 0x68));
        *(undefined8 *)(arg1 + 0xa0) = 0;
    }
    piVar3 = *(int64_t **)(arg1 + 0x60);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)(arg1 + 0x28));
        *(undefined8 *)(arg1 + 0x60) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017cf70
// Address: 0x18017cf70
// Size: 65 bytes
// ============================================================
void fcn.18017cf70(int64_t arg1)
{
    *(undefined8 *)arg1 = 0x1804a6a88;
    if (*(char *)(arg1 + 0x18) != '\0') {
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180180fe0();
            *(undefined8 *)(arg1 + 8) = 0;
        }
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined *)(arg1 + 0x18) = 0;
    }
    return;
}

