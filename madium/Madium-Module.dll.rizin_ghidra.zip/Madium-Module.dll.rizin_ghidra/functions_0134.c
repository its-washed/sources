// Chunk 134 - 50 functions

// ============================================================
// Function: FUN_1801c98f6
// Address: 0x1801c98f6
// Size: 21 bytes
// ============================================================
void fcn.1801c98f6(int64_t arg_70h)
{
    return;
}

// ============================================================
// Function: FUN_1801c9910
// Address: 0x1801c9910
// Size: 600 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801c9910(int64_t arg4, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 uVar6;
    uint8_t *puVar7;
    uint64_t in_R8;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_40 = 0x1801c992f;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    *(undefined4 *)((int64_t)&arg_58h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9960;
    iVar3 = func_0x000180244a90(in_RDX, 2);
    if (iVar3 == 0) {
code_r0x0001801c9b16:
        if ((in_R8 & 0x8000) != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9b20;
        func_0x000180229480();
        uVar6 = 0x368;
    } else {
        if ((in_R8 & 0x180) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c997d;
            iVar3 = func_0x000180244980(in_RDX, 2);
            if (iVar3 == 0) goto code_r0x0001801c9b16;
        }
        if ((in_R8 & 0x80) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c99a9;
            iVar3 = func_0x0001801af910(in_RCX, &stack0xfffffffffffffff8 + iVar4, (int64_t)&arg_58h + iVar4, 0);
            if (iVar3 != 0) {
                if ((in_R8 & 0x8000) != 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c99bd;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c99d5;
                func_0x0001802295a0(0x1804b3878, 0x370, 0x1804b38a8);
                goto code_r0x0001801c9b3e;
            }
            iVar8 = *(int64_t *)(in_RCX + 0x878);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c99ed;
            func_0x00018019ac20(iVar8 + 0x80);
        }
        *(undefined4 *)((int64_t)&var_10h + iVar4) = *(undefined4 *)((int64_t)&arg_58h + iVar4);
        *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&arg_68h + iVar4);
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9a15;
        iVar3 = func_0x00018019a860(in_RCX, in_R8 & 0xffffffff, in_RDX, arg4);
        if (iVar3 == 0) {
            return 0;
        }
        iVar8 = 0x1804b3200;
        puVar7 = (uint8_t *)(in_RCX + 0x9e8);
        *(int64_t *)(&stack0x00000000 + iVar4) = -0x9e8 - in_RCX;
        do {
            uVar1 = *(uint32_t *)(iVar8 + 4);
            if (((uint32_t)in_R8 & uVar1) != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9a59;
                iVar3 = func_0x0001801c9310(in_RCX, uVar1, in_R8 & 0xffffffff);
                if ((iVar3 != 0) &&
                   ((((uVar1 & 0x20) == 0 || ((in_R8 & 0x80) == 0)) ||
                    (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0 &&
                     (0x303 < *(int32_t *)((int64_t)&arg_58h + iVar4))))))) {
                    iVar5 = 0x20;
                    if (*(int32_t *)(in_RCX + 0x78) == 0) {
                        iVar5 = 0x28;
                    }
                    pcVar2 = *(code **)(iVar5 + iVar8);
                    if (pcVar2 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&arg_68h + iVar4);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9ac1;
                        iVar3 = (*pcVar2)(in_RCX, in_RDX, in_R8 & 0xffffffff, *(undefined8 *)((int64_t)&arg_60h + iVar4)
                                         );
                        if (iVar3 == 0) {
                            return 0;
                        }
                        if ((iVar3 == 1) && ((in_R8 & 0x6080) != 0)) {
                            *puVar7 = *puVar7 | 2;
                        }
                    }
                }
            }
            puVar7 = puVar7 + 1;
            iVar8 = iVar8 + 0x38;
        } while (puVar7 + *(int64_t *)(&stack0x00000000 + iVar4) < (uint8_t *)0x1d);
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9afa;
        iVar3 = func_0x000180244000(in_RDX);
        if (iVar3 != 0) {
            return 1;
        }
        if ((in_R8 & 0x8000) != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9b08;
        func_0x000180229480();
        uVar6 = 0x39d;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9b38;
    func_0x0001802295a0(0x1804b3878, uVar6, 0x1804b38a8);
    iVar3 = 0xc0103;
code_r0x0001801c9b3e:
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1801c9b4e;
    func_0x00018019b5e0(in_RCX, 0x50, iVar3, 0);
    return 0;
}

// ============================================================
// Function: FUN_1801c9b70
// Address: 0x1801c9b70
// Size: 397 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801c9b70(int64_t placeholder_0, uint64_t placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_48h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t *puVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_10h;
    
    uStack_40 = 0x1801c9b94;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    uVar12 = 0;
    uVar13 = 0;
    iVar3 = *(int64_t *)(*(int64_t *)(placeholder_0 + 0x878) + 0x88);
    if (iVar3 != -0x1d) {
        uVar4 = *(undefined8 *)((int64_t)&arg_68h + iVar8);
        do {
            uVar10 = (uint64_t)(int32_t)uVar13;
            puVar1 = (undefined8 *)(arg3 + uVar10 * 0x28);
            if ((*(int32_t *)(arg3 + 0x10 + uVar10 * 0x28) != 0) && (*(int32_t *)((int64_t)puVar1 + 0x14) == 0)) {
                *(undefined4 *)((int64_t)puVar1 + 0x14) = 1;
                if (uVar10 < 0x1d) {
                    uVar2 = *(undefined4 *)(uVar10 * 0x38 + 0x1804b3204);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c9c0f;
                    iVar7 = func_0x0001801c9310(placeholder_0, uVar2, placeholder_1 & 0xffffffff);
                    if (iVar7 != 0) {
                        iVar9 = 0x1804b3210;
                        if (*(int32_t *)(placeholder_0 + 0x78) == 0) {
                            iVar9 = 0x1804b3218;
                        }
                        pcVar5 = *(code **)(iVar9 + uVar10 * 0x38);
                        if (pcVar5 == (code *)0x0) goto code_r0x0001801c9c4d;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = uVar4;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c9c4b;
                        iVar7 = (*pcVar5)(placeholder_0, puVar1, placeholder_1 & 0xffffffff, 
                                          *(undefined8 *)((int64_t)&arg_60h + iVar8));
                        goto code_r0x0001801c9c79;
                    }
                } else {
code_r0x0001801c9c4d:
                    uVar6 = *puVar1;
                    uVar2 = *(undefined4 *)(puVar1 + 3);
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = uVar4;
                    *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_60h + iVar8);
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = puVar1[1];
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c9c79;
                    iVar7 = func_0x00018019ac50(placeholder_0, placeholder_1 & 0xffffffff, uVar2, uVar6);
code_r0x0001801c9c79:
                    if (iVar7 == 0) {
                        return 0;
                    }
                }
                arg3 = *(int64_t *)((int64_t)&arg_58h + iVar8);
            }
            uVar13 = uVar13 + 1;
        } while (uVar13 < iVar3 + 0x1dU);
    }
    if (*(int32_t *)((int64_t)&arg_70h + iVar8) != 0) {
        puVar11 = (uint32_t *)0x1804b3204;
        puVar14 = (undefined4 *)(arg3 + 0x10);
        do {
            pcVar5 = *(code **)(puVar11 + 0xb);
            if ((pcVar5 != (code *)0x0) && ((*puVar11 & (uint32_t)placeholder_1) != 0)) {
                uVar2 = *puVar14;
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1801c9cc7;
                iVar7 = (*pcVar5)(placeholder_0, placeholder_1 & 0xffffffff, uVar2);
                if (iVar7 == 0) {
                    return 0;
                }
            }
            uVar12 = uVar12 + 1;
            puVar14 = puVar14 + 10;
            puVar11 = puVar11 + 0xe;
        } while (uVar12 < 0x1d);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c9d00
// Address: 0x1801c9d00
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801c9d00(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    uint64_t uVar8;
    int32_t in_EDX;
    uint64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c9d1a;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    uVar8 = (uint64_t)in_EDX;
    puVar1 = (undefined8 *)(in_R9 + uVar8 * 0x28);
    if ((*(int32_t *)(in_R9 + 0x10 + uVar8 * 0x28) == 0) || (*(int32_t *)((int64_t)puVar1 + 0x14) != 0)) {
code_r0x0001801c9dd7:
        uVar7 = 1;
    } else {
        *(undefined4 *)((int64_t)puVar1 + 0x14) = 1;
        if (uVar8 < 0x1d) {
            uVar2 = *(undefined4 *)(uVar8 * 0x38 + 0x1804b3204);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c9d67;
            iVar4 = func_0x0001801c9310(in_RCX, uVar2);
            if (iVar4 == 0) goto code_r0x0001801c9dd7;
            iVar6 = 0x1804b3210;
            if (*(int32_t *)(in_RCX + 0x78) == 0) {
                iVar6 = 0x1804b3218;
            }
            pcVar3 = *(code **)(iVar6 + uVar8 * 0x38);
            if (pcVar3 != (code *)0x0) {
                *(undefined8 *)((int64_t)&var_18h + iVar5) = *(undefined8 *)((int64_t)&arg_70h + iVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c9da5;
                uVar7 = (*pcVar3)(in_RCX, puVar1, in_R8 & 0xffffffff, *(undefined8 *)((int64_t)&arg_68h + iVar5));
                return uVar7;
            }
        }
        uVar7 = *puVar1;
        uVar2 = *(undefined4 *)(puVar1 + 3);
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = *(undefined8 *)((int64_t)&arg_70h + iVar5);
        *(undefined8 *)((int64_t)&var_20h + iVar5) = *(undefined8 *)((int64_t)&arg_68h + iVar5);
        *(undefined8 *)((int64_t)&var_18h + iVar5) = puVar1[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c9dd5;
        uVar7 = func_0x00018019ac50(in_RCX, in_R8 & 0xffffffff, uVar2, uVar7);
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801c9e00
// Address: 0x1801c9e00
// Size: 213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801c9e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_a0h, int64_t arg_e0h, int64_t arg_120h, int64_t arg_160h
                  , int64_t arg_178h, int64_t arg_180h, int64_t arg_1e0h, int64_t arg_1e8h, int64_t arg_1f0h,
                  int64_t arg_1f8h, int64_t arg_200h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    bool bVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 in_RDX;
    int64_t iVar11;
    undefined8 unaff_RBX;
    int64_t iVar12;
    undefined8 in_R8;
    uint64_t uVar13;
    undefined8 in_R9;
    int64_t iVar14;
    undefined8 unaff_R15;
    undefined8 uVar15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_38 = 0x1801c9e14;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_160h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    iVar8 = *(int64_t *)((int64_t)&arg_1f0h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = *(undefined8 *)((int64_t)&arg_1e8h + iVar7);
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = *(undefined8 *)((int64_t)&arg_1e0h + iVar7);
    iVar11 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9e72;
    iVar5 = func_0x00018020f800();
    iVar14 = (int64_t)iVar5;
    bVar4 = false;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = *(undefined8 *)(in_RCX + 8);
    *(undefined4 *)((int64_t)&arg_28h + iVar7) = 0xffffffff;
    if (iVar5 < 1) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9e92;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9eaa;
        func_0x0001802295a0(0x1804b3878, 0x606, 0x1804b39b0);
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9ec0;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        iVar12 = iVar11;
        goto code_r0x0001801ca46a;
    }
    iVar5 = *(int32_t *)((int64_t)&arg_200h + iVar7);
    *(undefined8 *)((int64_t)&arg_180h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_178h + iVar7) = unaff_R15;
    if ((((iVar5 != 0) && (*(int32_t *)(in_RCX + 0xf0) == 2)) &&
        (*(int32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x338) == 0)) && (bVar4 = false, *(int32_t *)(iVar8 + 0x338) != 0))
    {
        bVar4 = true;
    }
    uVar15 = 0x1804b3868;
    if (iVar5 == 0) {
        uVar15 = 0x1804b3858;
    }
    if (((*(int32_t *)(in_RCX + 0x78) != 0) || (iVar5 == 0)) || (iVar11 = iVar8 + 0x10, bVar4)) {
        iVar11 = in_RCX + 0x574;
    }
    uVar2 = *(undefined8 *)(iVar8 + 8);
    *(int64_t *)((int64_t)&var_8h + iVar7) = iVar11;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = uVar2;
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f57;
    iVar5 = func_0x0001801b3d70(in_RCX, in_RDX, 0, iVar8 + 0x50);
    if (iVar5 == 0) {
        iVar11 = 0;
        goto code_r0x0001801ca46a;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f64;
    iVar12 = func_0x000180215470();
    if (iVar12 == 0) {
code_r0x0001801ca41d:
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca422;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca43a;
        func_0x0001802295a0(0x1804b3878, 0x634, 0x1804b39b0);
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca450;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f7e;
        iVar5 = func_0x000180214880(iVar12, in_RDX, 0);
        if (iVar5 < 1) goto code_r0x0001801ca41d;
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f99;
        iVar5 = func_0x0001802146d0(iVar12, (int64_t)&arg_60h + iVar7, 0);
        if (iVar5 < 1) goto code_r0x0001801ca41d;
        *(undefined4 *)((int64_t)&var_18h + iVar7) = 1;
        *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8) = iVar14;
        *(int64_t *)((int64_t)aiStackX_8 + iVar7) = (int64_t)&arg_a0h + iVar7;
        *(int64_t *)(&stack0x00000000 + iVar7) = iVar14;
        *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_60h + iVar7;
        *(undefined8 *)((int64_t)&var_10h + iVar7) = 10;
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9fe7;
        iVar5 = func_0x0001801b40a0(in_RCX, in_RDX, iVar11, uVar15);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_10h + iVar7) = iVar14;
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca00f;
            iVar5 = func_0x0001801b3740(in_RCX, in_RDX, (int64_t)&arg_a0h + iVar7, (int64_t)&arg_e0h + iVar7);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca025;
                iVar5 = func_0x000180214880(iVar12, in_RDX, 0);
                if (iVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca02e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca046;
                    func_0x0001802295a0(0x1804b3878, 0x646, 0x1804b39b0);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca05c;
                    func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                    iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                    goto code_r0x0001801ca46a;
                }
                if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
                    uVar15 = *(undefined8 *)(in_RCX + 0x1a8);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca08c;
                    iVar5 = func_0x000180219d10(uVar15, 3, 0, (int64_t)&arg_38h + iVar7);
                    uVar13 = (uint64_t)iVar5;
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca098;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca0b0;
                        func_0x0001802295a0(0x1804b3878, 0x657, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca0c6;
                        func_0x00018019b5e0(in_RCX, 0x50, 0x14c, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
                    iVar8 = *(int64_t *)((int64_t)&arg_38h + iVar7);
                    if (*(int32_t *)(in_RCX + 0x78) != 0) {
                        if (((uVar13 < 0x8000000000000000) && (uVar13 != 0)) && (2 < uVar13 - 1)) {
                            uVar10 = (uint64_t)
                                     CONCAT21(CONCAT11(*(undefined *)(iVar8 + 1), *(undefined *)(iVar8 + 2)), 
                                              *(undefined *)(iVar8 + 3));
                            if (((uVar10 <= uVar13 - 4) && (iVar11 = (uVar13 - 4) - uVar10, iVar11 != 0)) &&
                               (iVar1 = uVar10 + iVar8, 2 < iVar11 - 1U)) {
                                uVar10 = (uint64_t)
                                         CONCAT21(CONCAT11(*(undefined *)(iVar1 + 5), *(undefined *)(iVar1 + 6)), 
                                                  *(undefined *)(iVar1 + 7));
                                if (uVar10 <= iVar11 - 4U) {
                                    uVar13 = uVar13 - ((iVar11 - 4U) - uVar10);
                                    goto code_r0x0001801ca17a;
                                }
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1cb;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1e3;
                        func_0x0001802295a0(0x1804b3878, 0x668, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1f9;
                        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
code_r0x0001801ca17a:
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca185;
                    iVar5 = func_0x0001802149b0(iVar12, iVar8, uVar13);
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca18e;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1a6;
                        func_0x0001802295a0(0x1804b3878, 0x66f, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1bc;
                        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca213;
                iVar5 = func_0x0001802149b0(iVar12, in_R8, *(undefined8 *)((int64_t)&arg_40h + iVar7));
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca22e;
                    iVar5 = func_0x0001802146d0(iVar12, (int64_t)&arg_60h + iVar7, 0);
                    if (0 < iVar5) {
                        puVar3 = *(undefined8 **)((int64_t)&arg_48h + iVar7);
                        *(int64_t *)((int64_t)&var_10h + iVar7) = iVar14;
                        uVar15 = puVar3[0x8c];
                        uVar2 = *puVar3;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca25e;
                        iVar8 = func_0x00018022fea0(uVar2, 0x1804af24c, uVar15, (int64_t)&arg_e0h + iVar7);
                        *(int64_t *)((int64_t)&var_20h + iVar7) = iVar8;
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca26d;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca285;
                            func_0x0001802295a0(0x1804b3878, 0x67e, 0x1804b39b0);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca29b;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                            iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        } else {
                            iVar5 = *(int32_t *)((int64_t)&arg_1f8h + iVar7);
                            iVar8 = (int64_t)&arg_120h + iVar7;
                            *(int64_t *)((int64_t)&arg_30h + iVar7) = iVar14;
                            uVar15 = puVar3[0x8c];
                            if (iVar5 != 0) {
                                iVar8 = *(int64_t *)((int64_t)&arg_50h + iVar7);
                            }
                            uVar2 = *puVar3;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca2d8;
                            uVar9 = func_0x00018020f750(in_RDX);
                            iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                            *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                            *(int64_t *)((int64_t)&var_8h + iVar7) = iVar11;
                            *(undefined8 *)((int64_t)&var_10h + iVar7) = uVar15;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca300;
                            iVar6 = func_0x00018025c2e0(iVar12, 0, uVar9, uVar2);
                            if (0 < iVar6) {
                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca31b;
                                iVar6 = func_0x00018025c340(iVar12, (int64_t)&arg_60h + iVar7, iVar14);
                                if (0 < iVar6) {
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca333;
                                    iVar6 = func_0x00018025be60(iVar12, iVar8, (int64_t)&arg_30h + iVar7);
                                    if ((0 < iVar6) && (*(int64_t *)((int64_t)&arg_30h + iVar7) == iVar14)) {
                                        if (iVar5 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca363;
                                            iVar5 = func_0x0001802262e0(*(undefined8 *)((int64_t)&arg_58h + iVar7), 
                                                                        iVar8, iVar14);
                                            *(uint32_t *)((int64_t)&arg_28h + iVar7) = (uint32_t)(iVar5 == 0);
                                            if (iVar5 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca37b;
                                                func_0x000180229480();
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca393;
                                                func_0x0001802295a0(0x1804b3878, 0x695, 0x1804b39b0);
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3a9;
                                                func_0x00018019b5e0(in_RCX, 0x33, 0xfd, 0);
                                            }
                                        } else {
                                            *(undefined4 *)((int64_t)&arg_28h + iVar7) = 1;
                                        }
                                        goto code_r0x0001801ca46a;
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3b3;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3cb;
                            func_0x0001802295a0(0x1804b3878, 0x68b, 0x1804b39b0);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3e1;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        }
                        goto code_r0x0001801ca46a;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3e8;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca400;
                func_0x0001802295a0(0x1804b3878, 0x676, 0x1804b39b0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca416;
                func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                goto code_r0x0001801ca46a;
            }
        }
    }
    iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
code_r0x0001801ca46a:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca47c;
    func_0x000180244fc0((int64_t)&arg_a0h + iVar7, 0x40);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca48e;
    func_0x000180244fc0((int64_t)&arg_e0h + iVar7, 0x40);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca496;
    func_0x00018022ecc0(iVar11);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca49e;
    func_0x000180215310(iVar12);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca4b2;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_160h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801c9ed5
// Address: 0x1801c9ed5
// Size: 1429 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801c9e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_a0h, int64_t arg_e0h, int64_t arg_120h, int64_t arg_160h
                  , int64_t arg_178h, int64_t arg_180h, int64_t arg_1e0h, int64_t arg_1e8h, int64_t arg_1f0h,
                  int64_t arg_1f8h, int64_t arg_200h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    bool bVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 in_RDX;
    int64_t iVar11;
    undefined8 unaff_RBX;
    int64_t iVar12;
    undefined8 in_R8;
    uint64_t uVar13;
    undefined8 in_R9;
    int64_t iVar14;
    undefined8 unaff_R15;
    undefined8 uVar15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_38 = 0x1801c9e14;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_160h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    iVar8 = *(int64_t *)((int64_t)&arg_1f0h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = *(undefined8 *)((int64_t)&arg_1e8h + iVar7);
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = *(undefined8 *)((int64_t)&arg_1e0h + iVar7);
    iVar11 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9e72;
    iVar5 = func_0x00018020f800();
    iVar14 = (int64_t)iVar5;
    bVar4 = false;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = *(undefined8 *)(in_RCX + 8);
    *(undefined4 *)((int64_t)&arg_28h + iVar7) = 0xffffffff;
    if (iVar5 < 1) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9e92;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9eaa;
        func_0x0001802295a0(0x1804b3878, 0x606, 0x1804b39b0);
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9ec0;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        iVar12 = iVar11;
        goto code_r0x0001801ca46a;
    }
    iVar5 = *(int32_t *)((int64_t)&arg_200h + iVar7);
    *(undefined8 *)((int64_t)&arg_180h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_178h + iVar7) = unaff_R15;
    if ((((iVar5 != 0) && (*(int32_t *)(in_RCX + 0xf0) == 2)) &&
        (*(int32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x338) == 0)) && (bVar4 = false, *(int32_t *)(iVar8 + 0x338) != 0))
    {
        bVar4 = true;
    }
    uVar15 = 0x1804b3868;
    if (iVar5 == 0) {
        uVar15 = 0x1804b3858;
    }
    if (((*(int32_t *)(in_RCX + 0x78) != 0) || (iVar5 == 0)) || (iVar11 = iVar8 + 0x10, bVar4)) {
        iVar11 = in_RCX + 0x574;
    }
    uVar2 = *(undefined8 *)(iVar8 + 8);
    *(int64_t *)((int64_t)&var_8h + iVar7) = iVar11;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = uVar2;
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f57;
    iVar5 = func_0x0001801b3d70(in_RCX, in_RDX, 0, iVar8 + 0x50);
    if (iVar5 == 0) {
        iVar11 = 0;
        goto code_r0x0001801ca46a;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f64;
    iVar12 = func_0x000180215470();
    if (iVar12 == 0) {
code_r0x0001801ca41d:
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca422;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca43a;
        func_0x0001802295a0(0x1804b3878, 0x634, 0x1804b39b0);
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca450;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f7e;
        iVar5 = func_0x000180214880(iVar12, in_RDX, 0);
        if (iVar5 < 1) goto code_r0x0001801ca41d;
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f99;
        iVar5 = func_0x0001802146d0(iVar12, (int64_t)&arg_60h + iVar7, 0);
        if (iVar5 < 1) goto code_r0x0001801ca41d;
        *(undefined4 *)((int64_t)&var_18h + iVar7) = 1;
        *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8) = iVar14;
        *(int64_t *)((int64_t)aiStackX_8 + iVar7) = (int64_t)&arg_a0h + iVar7;
        *(int64_t *)(&stack0x00000000 + iVar7) = iVar14;
        *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_60h + iVar7;
        *(undefined8 *)((int64_t)&var_10h + iVar7) = 10;
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9fe7;
        iVar5 = func_0x0001801b40a0(in_RCX, in_RDX, iVar11, uVar15);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_10h + iVar7) = iVar14;
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca00f;
            iVar5 = func_0x0001801b3740(in_RCX, in_RDX, (int64_t)&arg_a0h + iVar7, (int64_t)&arg_e0h + iVar7);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca025;
                iVar5 = func_0x000180214880(iVar12, in_RDX, 0);
                if (iVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca02e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca046;
                    func_0x0001802295a0(0x1804b3878, 0x646, 0x1804b39b0);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca05c;
                    func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                    iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                    goto code_r0x0001801ca46a;
                }
                if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
                    uVar15 = *(undefined8 *)(in_RCX + 0x1a8);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca08c;
                    iVar5 = func_0x000180219d10(uVar15, 3, 0, (int64_t)&arg_38h + iVar7);
                    uVar13 = (uint64_t)iVar5;
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca098;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca0b0;
                        func_0x0001802295a0(0x1804b3878, 0x657, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca0c6;
                        func_0x00018019b5e0(in_RCX, 0x50, 0x14c, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
                    iVar8 = *(int64_t *)((int64_t)&arg_38h + iVar7);
                    if (*(int32_t *)(in_RCX + 0x78) != 0) {
                        if (((uVar13 < 0x8000000000000000) && (uVar13 != 0)) && (2 < uVar13 - 1)) {
                            uVar10 = (uint64_t)
                                     CONCAT21(CONCAT11(*(undefined *)(iVar8 + 1), *(undefined *)(iVar8 + 2)), 
                                              *(undefined *)(iVar8 + 3));
                            if (((uVar10 <= uVar13 - 4) && (iVar11 = (uVar13 - 4) - uVar10, iVar11 != 0)) &&
                               (iVar1 = uVar10 + iVar8, 2 < iVar11 - 1U)) {
                                uVar10 = (uint64_t)
                                         CONCAT21(CONCAT11(*(undefined *)(iVar1 + 5), *(undefined *)(iVar1 + 6)), 
                                                  *(undefined *)(iVar1 + 7));
                                if (uVar10 <= iVar11 - 4U) {
                                    uVar13 = uVar13 - ((iVar11 - 4U) - uVar10);
                                    goto code_r0x0001801ca17a;
                                }
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1cb;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1e3;
                        func_0x0001802295a0(0x1804b3878, 0x668, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1f9;
                        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
code_r0x0001801ca17a:
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca185;
                    iVar5 = func_0x0001802149b0(iVar12, iVar8, uVar13);
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca18e;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1a6;
                        func_0x0001802295a0(0x1804b3878, 0x66f, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1bc;
                        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca213;
                iVar5 = func_0x0001802149b0(iVar12, in_R8, *(undefined8 *)((int64_t)&arg_40h + iVar7));
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca22e;
                    iVar5 = func_0x0001802146d0(iVar12, (int64_t)&arg_60h + iVar7, 0);
                    if (0 < iVar5) {
                        puVar3 = *(undefined8 **)((int64_t)&arg_48h + iVar7);
                        *(int64_t *)((int64_t)&var_10h + iVar7) = iVar14;
                        uVar15 = puVar3[0x8c];
                        uVar2 = *puVar3;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca25e;
                        iVar8 = func_0x00018022fea0(uVar2, 0x1804af24c, uVar15, (int64_t)&arg_e0h + iVar7);
                        *(int64_t *)((int64_t)&var_20h + iVar7) = iVar8;
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca26d;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca285;
                            func_0x0001802295a0(0x1804b3878, 0x67e, 0x1804b39b0);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca29b;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                            iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        } else {
                            iVar5 = *(int32_t *)((int64_t)&arg_1f8h + iVar7);
                            iVar8 = (int64_t)&arg_120h + iVar7;
                            *(int64_t *)((int64_t)&arg_30h + iVar7) = iVar14;
                            uVar15 = puVar3[0x8c];
                            if (iVar5 != 0) {
                                iVar8 = *(int64_t *)((int64_t)&arg_50h + iVar7);
                            }
                            uVar2 = *puVar3;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca2d8;
                            uVar9 = func_0x00018020f750(in_RDX);
                            iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                            *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                            *(int64_t *)((int64_t)&var_8h + iVar7) = iVar11;
                            *(undefined8 *)((int64_t)&var_10h + iVar7) = uVar15;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca300;
                            iVar6 = func_0x00018025c2e0(iVar12, 0, uVar9, uVar2);
                            if (0 < iVar6) {
                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca31b;
                                iVar6 = func_0x00018025c340(iVar12, (int64_t)&arg_60h + iVar7, iVar14);
                                if (0 < iVar6) {
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca333;
                                    iVar6 = func_0x00018025be60(iVar12, iVar8, (int64_t)&arg_30h + iVar7);
                                    if ((0 < iVar6) && (*(int64_t *)((int64_t)&arg_30h + iVar7) == iVar14)) {
                                        if (iVar5 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca363;
                                            iVar5 = func_0x0001802262e0(*(undefined8 *)((int64_t)&arg_58h + iVar7), 
                                                                        iVar8, iVar14);
                                            *(uint32_t *)((int64_t)&arg_28h + iVar7) = (uint32_t)(iVar5 == 0);
                                            if (iVar5 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca37b;
                                                func_0x000180229480();
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca393;
                                                func_0x0001802295a0(0x1804b3878, 0x695, 0x1804b39b0);
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3a9;
                                                func_0x00018019b5e0(in_RCX, 0x33, 0xfd, 0);
                                            }
                                        } else {
                                            *(undefined4 *)((int64_t)&arg_28h + iVar7) = 1;
                                        }
                                        goto code_r0x0001801ca46a;
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3b3;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3cb;
                            func_0x0001802295a0(0x1804b3878, 0x68b, 0x1804b39b0);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3e1;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        }
                        goto code_r0x0001801ca46a;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3e8;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca400;
                func_0x0001802295a0(0x1804b3878, 0x676, 0x1804b39b0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca416;
                func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                goto code_r0x0001801ca46a;
            }
        }
    }
    iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
code_r0x0001801ca46a:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca47c;
    func_0x000180244fc0((int64_t)&arg_a0h + iVar7, 0x40);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca48e;
    func_0x000180244fc0((int64_t)&arg_e0h + iVar7, 0x40);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca496;
    func_0x00018022ecc0(iVar11);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca49e;
    func_0x000180215310(iVar12);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca4b2;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_160h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801ca46a
// Address: 0x1801ca46a
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801c9e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_a0h, int64_t arg_e0h, int64_t arg_120h, int64_t arg_160h
                  , int64_t arg_178h, int64_t arg_180h, int64_t arg_1e0h, int64_t arg_1e8h, int64_t arg_1f0h,
                  int64_t arg_1f8h, int64_t arg_200h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    bool bVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint64_t uVar10;
    undefined8 in_RDX;
    int64_t iVar11;
    undefined8 unaff_RBX;
    int64_t iVar12;
    undefined8 in_R8;
    uint64_t uVar13;
    undefined8 in_R9;
    int64_t iVar14;
    undefined8 unaff_R15;
    undefined8 uVar15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_38 = 0x1801c9e14;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_160h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7);
    iVar8 = *(int64_t *)((int64_t)&arg_1f0h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = *(undefined8 *)((int64_t)&arg_1e8h + iVar7);
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = *(undefined8 *)((int64_t)&arg_1e0h + iVar7);
    iVar11 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9e72;
    iVar5 = func_0x00018020f800();
    iVar14 = (int64_t)iVar5;
    bVar4 = false;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = *(undefined8 *)(in_RCX + 8);
    *(undefined4 *)((int64_t)&arg_28h + iVar7) = 0xffffffff;
    if (iVar5 < 1) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9e92;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9eaa;
        func_0x0001802295a0(0x1804b3878, 0x606, 0x1804b39b0);
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9ec0;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        iVar12 = iVar11;
        goto code_r0x0001801ca46a;
    }
    iVar5 = *(int32_t *)((int64_t)&arg_200h + iVar7);
    *(undefined8 *)((int64_t)&arg_180h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_178h + iVar7) = unaff_R15;
    if ((((iVar5 != 0) && (*(int32_t *)(in_RCX + 0xf0) == 2)) &&
        (*(int32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x338) == 0)) && (bVar4 = false, *(int32_t *)(iVar8 + 0x338) != 0))
    {
        bVar4 = true;
    }
    uVar15 = 0x1804b3868;
    if (iVar5 == 0) {
        uVar15 = 0x1804b3858;
    }
    if (((*(int32_t *)(in_RCX + 0x78) != 0) || (iVar5 == 0)) || (iVar11 = iVar8 + 0x10, bVar4)) {
        iVar11 = in_RCX + 0x574;
    }
    uVar2 = *(undefined8 *)(iVar8 + 8);
    *(int64_t *)((int64_t)&var_8h + iVar7) = iVar11;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = uVar2;
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f57;
    iVar5 = func_0x0001801b3d70(in_RCX, in_RDX, 0, iVar8 + 0x50);
    if (iVar5 == 0) {
        iVar11 = 0;
        goto code_r0x0001801ca46a;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f64;
    iVar12 = func_0x000180215470();
    if (iVar12 == 0) {
code_r0x0001801ca41d:
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca422;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca43a;
        func_0x0001802295a0(0x1804b3878, 0x634, 0x1804b39b0);
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca450;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
    } else {
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f7e;
        iVar5 = func_0x000180214880(iVar12, in_RDX, 0);
        if (iVar5 < 1) goto code_r0x0001801ca41d;
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9f99;
        iVar5 = func_0x0001802146d0(iVar12, (int64_t)&arg_60h + iVar7, 0);
        if (iVar5 < 1) goto code_r0x0001801ca41d;
        *(undefined4 *)((int64_t)&var_18h + iVar7) = 1;
        *(int64_t *)((int64_t)aiStackX_8 + iVar7 + 8) = iVar14;
        *(int64_t *)((int64_t)aiStackX_8 + iVar7) = (int64_t)&arg_a0h + iVar7;
        *(int64_t *)(&stack0x00000000 + iVar7) = iVar14;
        *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_60h + iVar7;
        *(undefined8 *)((int64_t)&var_10h + iVar7) = 10;
        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801c9fe7;
        iVar5 = func_0x0001801b40a0(in_RCX, in_RDX, iVar11, uVar15);
        if (iVar5 != 0) {
            *(int64_t *)((int64_t)&var_10h + iVar7) = iVar14;
            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca00f;
            iVar5 = func_0x0001801b3740(in_RCX, in_RDX, (int64_t)&arg_a0h + iVar7, (int64_t)&arg_e0h + iVar7);
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca025;
                iVar5 = func_0x000180214880(iVar12, in_RDX, 0);
                if (iVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca02e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca046;
                    func_0x0001802295a0(0x1804b3878, 0x646, 0x1804b39b0);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca05c;
                    func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                    iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                    goto code_r0x0001801ca46a;
                }
                if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
                    uVar15 = *(undefined8 *)(in_RCX + 0x1a8);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca08c;
                    iVar5 = func_0x000180219d10(uVar15, 3, 0, (int64_t)&arg_38h + iVar7);
                    uVar13 = (uint64_t)iVar5;
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca098;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca0b0;
                        func_0x0001802295a0(0x1804b3878, 0x657, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca0c6;
                        func_0x00018019b5e0(in_RCX, 0x50, 0x14c, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
                    iVar8 = *(int64_t *)((int64_t)&arg_38h + iVar7);
                    if (*(int32_t *)(in_RCX + 0x78) != 0) {
                        if (((uVar13 < 0x8000000000000000) && (uVar13 != 0)) && (2 < uVar13 - 1)) {
                            uVar10 = (uint64_t)
                                     CONCAT21(CONCAT11(*(undefined *)(iVar8 + 1), *(undefined *)(iVar8 + 2)), 
                                              *(undefined *)(iVar8 + 3));
                            if (((uVar10 <= uVar13 - 4) && (iVar11 = (uVar13 - 4) - uVar10, iVar11 != 0)) &&
                               (iVar1 = uVar10 + iVar8, 2 < iVar11 - 1U)) {
                                uVar10 = (uint64_t)
                                         CONCAT21(CONCAT11(*(undefined *)(iVar1 + 5), *(undefined *)(iVar1 + 6)), 
                                                  *(undefined *)(iVar1 + 7));
                                if (uVar10 <= iVar11 - 4U) {
                                    uVar13 = uVar13 - ((iVar11 - 4U) - uVar10);
                                    goto code_r0x0001801ca17a;
                                }
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1cb;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1e3;
                        func_0x0001802295a0(0x1804b3878, 0x668, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1f9;
                        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
code_r0x0001801ca17a:
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca185;
                    iVar5 = func_0x0001802149b0(iVar12, iVar8, uVar13);
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca18e;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1a6;
                        func_0x0001802295a0(0x1804b3878, 0x66f, 0x1804b39b0);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca1bc;
                        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        goto code_r0x0001801ca46a;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca213;
                iVar5 = func_0x0001802149b0(iVar12, in_R8, *(undefined8 *)((int64_t)&arg_40h + iVar7));
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca22e;
                    iVar5 = func_0x0001802146d0(iVar12, (int64_t)&arg_60h + iVar7, 0);
                    if (0 < iVar5) {
                        puVar3 = *(undefined8 **)((int64_t)&arg_48h + iVar7);
                        *(int64_t *)((int64_t)&var_10h + iVar7) = iVar14;
                        uVar15 = puVar3[0x8c];
                        uVar2 = *puVar3;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca25e;
                        iVar8 = func_0x00018022fea0(uVar2, 0x1804af24c, uVar15, (int64_t)&arg_e0h + iVar7);
                        *(int64_t *)((int64_t)&var_20h + iVar7) = iVar8;
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca26d;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca285;
                            func_0x0001802295a0(0x1804b3878, 0x67e, 0x1804b39b0);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca29b;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                            iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                        } else {
                            iVar5 = *(int32_t *)((int64_t)&arg_1f8h + iVar7);
                            iVar8 = (int64_t)&arg_120h + iVar7;
                            *(int64_t *)((int64_t)&arg_30h + iVar7) = iVar14;
                            uVar15 = puVar3[0x8c];
                            if (iVar5 != 0) {
                                iVar8 = *(int64_t *)((int64_t)&arg_50h + iVar7);
                            }
                            uVar2 = *puVar3;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca2d8;
                            uVar9 = func_0x00018020f750(in_RDX);
                            iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                            *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                            *(int64_t *)((int64_t)&var_8h + iVar7) = iVar11;
                            *(undefined8 *)((int64_t)&var_10h + iVar7) = uVar15;
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca300;
                            iVar6 = func_0x00018025c2e0(iVar12, 0, uVar9, uVar2);
                            if (0 < iVar6) {
                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca31b;
                                iVar6 = func_0x00018025c340(iVar12, (int64_t)&arg_60h + iVar7, iVar14);
                                if (0 < iVar6) {
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca333;
                                    iVar6 = func_0x00018025be60(iVar12, iVar8, (int64_t)&arg_30h + iVar7);
                                    if ((0 < iVar6) && (*(int64_t *)((int64_t)&arg_30h + iVar7) == iVar14)) {
                                        if (iVar5 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca363;
                                            iVar5 = func_0x0001802262e0(*(undefined8 *)((int64_t)&arg_58h + iVar7), 
                                                                        iVar8, iVar14);
                                            *(uint32_t *)((int64_t)&arg_28h + iVar7) = (uint32_t)(iVar5 == 0);
                                            if (iVar5 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca37b;
                                                func_0x000180229480();
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca393;
                                                func_0x0001802295a0(0x1804b3878, 0x695, 0x1804b39b0);
                                                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3a9;
                                                func_0x00018019b5e0(in_RCX, 0x33, 0xfd, 0);
                                            }
                                        } else {
                                            *(undefined4 *)((int64_t)&arg_28h + iVar7) = 1;
                                        }
                                        goto code_r0x0001801ca46a;
                                    }
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3b3;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3cb;
                            func_0x0001802295a0(0x1804b3878, 0x68b, 0x1804b39b0);
                            *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3e1;
                            func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                        }
                        goto code_r0x0001801ca46a;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca3e8;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca400;
                func_0x0001802295a0(0x1804b3878, 0x676, 0x1804b39b0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca416;
                func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
                iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
                goto code_r0x0001801ca46a;
            }
        }
    }
    iVar11 = *(int64_t *)((int64_t)&var_20h + iVar7);
code_r0x0001801ca46a:
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca47c;
    func_0x000180244fc0((int64_t)&arg_a0h + iVar7, 0x40);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca48e;
    func_0x000180244fc0((int64_t)&arg_e0h + iVar7, 0x40);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca496;
    func_0x00018022ecc0(iVar11);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca49e;
    func_0x000180215310(iVar12);
    *(undefined8 *)((int64_t)&uStack_38 + iVar7) = 0x1801ca4b2;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_160h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801ca4d0
// Address: 0x1801ca4d0
// Size: 229 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_878h because it doesn't fit into ProtoModel

undefined8 fcn.1801ca4d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint32_t in_EDX;
    uint32_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    uint32_t *puVar7;
    undefined8 unaff_RDI;
    undefined4 *puVar8;
    int64_t in_R8;
    uint64_t uVar9;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801ca4e3;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    uVar6 = 0;
    if ((char)in_EDX < '\0') {
        uVar9 = 1;
    } else {
        uVar9 = 2;
        if ((in_EDX >> 8 & 1) != 0) {
            uVar9 = uVar6;
        }
    }
    iVar2 = *(int64_t *)(in_RCX + 0x878);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    iVar2 = *(int64_t *)(iVar2 + 0x88);
    if (iVar2 != -0x1d) {
        puVar8 = (undefined4 *)(in_R8 + 0x18);
        puVar7 = (uint32_t *)0x1804b3204;
        do {
            if (puVar8[-2] != 0) {
                if (uVar6 < 0x1d) {
                    uVar5 = *puVar7;
                } else {
                    iVar4 = *(int64_t *)(in_RCX + 0x878);
                    uVar1 = *puVar8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801ca55d;
                    iVar4 = func_0x00018019aba0(iVar4 + 0x80, uVar9, uVar1, (int64_t)&arg_28h + iVar3);
                    if (iVar4 == 0) {
                        return 0;
                    }
                    uVar5 = *(uint32_t *)(iVar4 + 8);
                }
                if ((in_EDX & uVar5) == 0) {
                    return 0;
                }
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                    uVar5 = uVar5 & 2;
                } else {
                    uVar5 = uVar5 & 1;
                }
                if (uVar5 != 0) {
                    return 0;
                }
            }
            uVar6 = uVar6 + 1;
            puVar7 = puVar7 + 0xe;
            puVar8 = puVar8 + 10;
        } while (uVar6 < iVar2 + 0x1dU);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801ca5c0
// Address: 0x1801ca5c0
// Size: 484 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh

void fcn.1801ca5c0(int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t uVar7;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ca5d8;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&var_10h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3);
    if (*(int64_t *)(in_RCX + 0x110) == 0) {
        iVar6 = *(int64_t *)(in_RCX + 0x108);
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ca61e;
        puVar4 = (undefined *)func_0x000180224d60(0x50, 0x1804b3a00, 0x41);
        if (puVar4 != (undefined *)0x0) {
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ca644;
                iVar5 = func_0x0001802248d0(iVar6, 0x1804b3a00, 0x45);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ca661;
                    func_0x000180224990(puVar4, 0x1804b3a00, 0x46);
                    goto code_r0x0001801ca784;
                }
            }
            *(int64_t *)(puVar4 + 0x40) = iVar5;
            *(undefined8 *)(puVar4 + 0x48) = 0;
            uVar1 = *(undefined8 *)(in_RCX + 0x108);
            uVar2 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ca68c;
            func_0x000180498030(iVar5, uVar2, uVar1);
            iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x140);
            if (in_EDX == 0) {
                uVar7 = iVar6 + 0xc;
            } else {
                iVar5 = 1;
                if (*(int32_t *)(in_RCX + 0x48) == 0x100) {
                    iVar5 = 3;
                }
                uVar7 = iVar5 + iVar6;
            }
            if (uVar7 == *(uint32_t *)(in_RCX + 0x108)) {
                *(int64_t *)(puVar4 + 8) = iVar6;
                *(undefined2 *)(puVar4 + 0x10) = *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x148);
                *puVar4 = *(undefined *)(*(int64_t *)(in_RCX + 0x4f0) + 0x138);
                *(undefined8 *)(puVar4 + 0x18) = 0;
                *(undefined8 *)(puVar4 + 0x20) = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x140);
                *(int32_t *)(puVar4 + 0x28) = in_EDX;
                *(undefined8 *)(puVar4 + 0x30) = *(undefined8 *)(in_RCX + 0xc70);
                *(undefined8 *)(puVar4 + 0x38) = *(undefined8 *)(in_RCX + 0xc80);
                *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
                *(char *)((int64_t)&var_8h + iVar3 + 6) =
                     (char)((uint32_t)*(uint16_t *)(puVar4 + 0x10) * 2 - *(int32_t *)(puVar4 + 0x28) >> 8);
                *(char *)((int64_t)&var_8h + iVar3 + 7) = puVar4[0x10] * '\x02' - puVar4[0x28];
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ca758;
                iVar6 = func_0x0001801a6610((int64_t)&var_8h + iVar3, puVar4);
                if (iVar6 != 0) {
                    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ca773;
                    func_0x0001801a6700(uVar1, iVar6);
                    goto code_r0x0001801ca784;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ca782;
            func_0x0001801cae70(puVar4);
        }
    }
code_r0x0001801ca784:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801ca791;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_10h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801ca7b0
// Address: 0x1801ca7b0
// Size: 229 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh

undefined8 fcn.1801ca7b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ca7c5;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    if (in_R8D != 0x101) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ca7e2;
        iVar1 = func_0x000180244000(in_RDX);
        if (iVar1 == 0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ca7f7;
    iVar1 = func_0x0001802442b0(in_RDX);
    if ((iVar1 != 0) && (uVar3 = *(uint64_t *)((int64_t)&arg_40h + iVar2), uVar3 < 0x80000000)) {
        if (in_R8D != 0x101) {
            *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x140) = uVar3 - 0xc;
            *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x158) = *(int64_t *)((int64_t)&arg_40h + iVar2) + -0xc;
            uVar3 = *(uint64_t *)((int64_t)&arg_40h + iVar2);
        }
        *(int64_t *)(in_RCX + 0x108) = (int64_t)(int32_t)uVar3;
        *(undefined8 *)(in_RCX + 0x110) = 0;
        if (in_R8D != 3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ca86a;
            iVar1 = fcn.1801ca5c0(*(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
            if (iVar1 == 0) {
                return 0;
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ca8a0
// Address: 0x1801ca8a0
// Size: 1338 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ca8a0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    bool bVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    int64_t iVar12;
    uint64_t in_RDX;
    undefined *puVar13;
    char cVar14;
    int64_t iVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x1801ca8ba;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    uVar1 = *(undefined8 *)(in_RCX + 0x40);
    bVar4 = true;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801ca8d2;
    iVar5 = func_0x0001801c2dc0();
    if (iVar5 != 0) {
        iVar12 = *(int64_t *)(in_RCX + 0x4f0);
        uVar11 = *(uint64_t *)(iVar12 + 0x130);
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801ca8f0;
        uVar8 = func_0x0001801c2c40(in_RCX);
        if ((uVar8 <= uVar11) &&
           (((cVar14 = (char)in_RDX, *(int64_t *)(in_RCX + 0x110) != 0 || (cVar14 != '\x16')) ||
            (*(int64_t *)(in_RCX + 0x108) == *(int64_t *)(iVar12 + 0x140) + 0xc)))) {
            uVar10 = *(undefined8 *)(in_RCX + 0xc80);
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0xa8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801ca938;
            iVar9 = (*pcVar2)(uVar10);
            iVar12 = *(int64_t *)(in_RCX + 0x108);
            iVar15 = 0;
            *(undefined4 *)(in_RCX + 0x68) = 1;
            if (iVar12 != 0) {
                uVar16 = *(undefined4 *)((int64_t)&var_10h + iVar7);
                *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)((int64_t)&var_8h + iVar7);
                do {
                    if ((cVar14 == '\x16') && (uVar11 = *(uint64_t *)(in_RCX + 0x110), uVar11 != 0)) {
                        if (iVar15 == 0) {
                            iVar15 = *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x150);
                        } else {
                            if (uVar11 < 0xd) {
                                return 0xffffffff;
                            }
                            *(uint64_t *)(in_RCX + 0x110) = uVar11 - 0xc;
                            *(int64_t *)(in_RCX + 0x108) = iVar12 + 0xc;
                        }
                    }
                    uVar10 = *(undefined8 *)(in_RCX + 0x58);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801ca9c2;
                    iVar5 = func_0x000180219d10(uVar10, 0xd, 0, 0);
                    uVar11 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130);
                    uVar8 = uVar11 - (iVar5 + iVar9);
                    if (uVar11 <= (uint64_t)(iVar5 + iVar9)) {
                        uVar8 = 0;
                    }
                    if (uVar8 < 0xd) {
                        uVar10 = *(undefined8 *)(in_RCX + 0x58);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801caa02;
                        uVar10 = func_0x000180219d10(uVar10, 0xb, 0, 0);
                        if ((int32_t)uVar10 < 1) {
                            *(undefined4 *)(in_RCX + 0x68) = 2;
                            return uVar10;
                        }
                        uVar8 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130);
                        if (uVar8 <= iVar9 + 0xcU) {
                            return 0xffffffff;
                        }
                        uVar8 = uVar8 - iVar9;
                    }
                    if (*(uint32_t *)(in_RCX + 0x108) <= uVar8) {
                        uVar8 = *(uint64_t *)(in_RCX + 0x108);
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801caa42;
                    uVar6 = func_0x0001801976c0(in_RCX);
                    if (uVar6 < uVar8) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801caa51;
                        uVar6 = func_0x0001801976c0(in_RCX);
                        uVar8 = (uint64_t)uVar6;
                    }
                    if (cVar14 == '\x16') {
                        if (uVar8 < 0xc) {
                            return 0xffffffff;
                        }
                        iVar12 = *(int64_t *)(in_RCX + 0x4f0);
                        *(int64_t *)(iVar12 + 0x150) = iVar15;
                        *(uint64_t *)(iVar12 + 0x158) = uVar8 - 0xc;
                        if ((*(int64_t *)(in_RCX + 0x4f8) != 0) && (iVar12 = *(int64_t *)(in_RCX + 0x110), iVar12 != 0))
                        {
                            iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                            uVar16 = *(undefined4 *)(iVar3 + 8 + iVar12);
                            *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(iVar3 + iVar12);
                        }
                        iVar12 = *(int64_t *)(in_RCX + 0x4f0);
                        puVar13 = (undefined *)
                                  (*(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + *(int64_t *)(in_RCX + 0x110));
                        *puVar13 = *(undefined *)(iVar12 + 0x138);
                        puVar13[1] = *(undefined *)(iVar12 + 0x142);
                        puVar13[2] = *(undefined *)(iVar12 + 0x141);
                        puVar13[3] = *(undefined *)(iVar12 + 0x140);
                        puVar13[4] = *(undefined *)(iVar12 + 0x149);
                        puVar13[5] = *(undefined *)(iVar12 + 0x148);
                        puVar13[6] = *(undefined *)(iVar12 + 0x152);
                        puVar13[7] = *(undefined *)(iVar12 + 0x151);
                        puVar13[8] = *(undefined *)(iVar12 + 0x150);
                        puVar13[9] = *(undefined *)(iVar12 + 0x15a);
                        puVar13[10] = *(undefined *)(iVar12 + 0x159);
                        puVar13[0xb] = *(undefined *)(iVar12 + 0x158);
                    }
                    *(int64_t *)((int64_t)&var_18h + iVar7) = (int64_t)&arg_58h + iVar7;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cab72;
                    iVar5 = func_0x0001801c8060(in_RCX, in_RDX & 0xff);
                    if (((cVar14 == '\x16') && (*(int64_t *)(in_RCX + 0x4f8) != 0)) &&
                       (iVar12 = *(int64_t *)(in_RCX + 0x110), iVar12 != 0)) {
                        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                        *(undefined8 *)(iVar3 + iVar12) = *(undefined8 *)((int64_t)&arg_68h + iVar7);
                        *(undefined4 *)(iVar3 + 8 + iVar12) = uVar16;
                    }
                    if (iVar5 < 1) {
                        if (!bVar4) {
                            return 0xffffffff;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cabc2;
                        uVar10 = func_0x000180193e90(in_RCX);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cabd5;
                        iVar5 = func_0x000180219d10(uVar10, 0x2b, 0, 0);
                        if (iVar5 < 1) {
                            return 0xffffffff;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cabe5;
                        uVar11 = func_0x000180193b40(in_RCX);
                        if ((uVar11 >> 0xc & 1) != 0) {
                            return 0xffffffff;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cabf8;
                        iVar5 = func_0x0001801c2dc0(in_RCX);
                        if (iVar5 == 0) {
                            return 0xffffffff;
                        }
                        bVar4 = false;
                    } else {
                        uVar11 = *(uint64_t *)((int64_t)&arg_58h + iVar7);
                        if (uVar8 != uVar11) {
                            return 0xffffffff;
                        }
                        if ((cVar14 == '\x16') &&
                           (iVar12 = *(int64_t *)(in_RCX + 0x4f0), *(int32_t *)(iVar12 + 0x1cc) == 0)) {
                            puVar13 = (undefined *)
                                      (*(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + *(int64_t *)(in_RCX + 0x110));
                            if ((iVar15 == 0) && (*(int32_t *)(in_RCX + 0x48) != 0x100)) {
                                *puVar13 = *(undefined *)(iVar12 + 0x138);
                                puVar13[1] = *(undefined *)(iVar12 + 0x142);
                                puVar13[2] = *(undefined *)(iVar12 + 0x141);
                                puVar13[3] = *(undefined *)(iVar12 + 0x140);
                                puVar13[4] = *(undefined *)(iVar12 + 0x149);
                                puVar13[5] = *(undefined *)(iVar12 + 0x148);
                                *(undefined2 *)(puVar13 + 6) = 0;
                                puVar13[8] = 0;
                                puVar13[9] = *(undefined *)(iVar12 + 0x142);
                                puVar13[10] = *(undefined *)(iVar12 + 0x141);
                                puVar13[0xb] = *(undefined *)(iVar12 + 0x140);
                            } else {
                                puVar13 = puVar13 + 0xc;
                            }
                            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cacef;
                            iVar5 = func_0x0001801dac70(in_RCX, puVar13);
                            if (iVar5 == 0) {
                                return 0xffffffff;
                            }
                            uVar11 = *(uint64_t *)((int64_t)&arg_58h + iVar7);
                        }
                        uVar8 = *(uint64_t *)(in_RCX + 0x108);
                        if (uVar11 == uVar8) {
                            pcVar2 = *(code **)(in_RCX + 0x4f8);
                            if (pcVar2 != (code *)0x0) {
                                iVar12 = *(int64_t *)(in_RCX + 0x110);
                                iVar15 = *(int64_t *)(in_RCX + 0xf8);
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = *(undefined8 *)(in_RCX + 0x500);
                                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar7) = uVar1;
                                uVar1 = *(undefined8 *)(iVar15 + 8);
                                *(uint64_t *)((int64_t)&var_18h + iVar7) = iVar12 + uVar8;
                                uVar16 = *(undefined4 *)(in_RCX + 0x48);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cada6;
                                (*pcVar2)(1, uVar16, in_RDX & 0xff, uVar1);
                            }
                            *(undefined8 *)(in_RCX + 0x110) = 0;
                            *(undefined8 *)(in_RCX + 0x108) = 0;
                            return 1;
                        }
                        *(int64_t *)(in_RCX + 0x110) = *(int64_t *)(in_RCX + 0x110) + uVar11;
                        iVar12 = *(int64_t *)(in_RCX + 0x4f0);
                        *(uint64_t *)(in_RCX + 0x108) = uVar8 - uVar11;
                        iVar15 = iVar15 + (uVar11 - 0xc);
                        *(uint64_t *)((int64_t)&arg_58h + iVar7) = uVar11 - 0xc;
                        *(int64_t *)(iVar12 + 0x150) = iVar15;
                        *(undefined8 *)(iVar12 + 0x158) = 0;
                    }
                    iVar12 = *(int64_t *)(in_RCX + 0x108);
                } while (iVar12 != 0);
            }
            return 0;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801cae70
// Address: 0x1801cae70
// Size: 93 bytes
// ============================================================
void fcn.1801cae70(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801cae80;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)(arg1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cae9c;
        fcn.180224990(uVar1, 0x1804b3a00, 0x62);
        uVar1 = *(undefined8 *)(arg1 + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801caeb2;
        fcn.180224990(uVar1, 0x1804b3a00, 99);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801caec7;
        fcn.180224990(arg1, 0x1804b3a00, 100);
    }
    return;
}

// ============================================================
// Function: FUN_1801caed0
// Address: 0x1801caed0
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

int64_t fcn.1801caed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801caef0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar4 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801caf14;
    iVar2 = func_0x000180224d60(0x50, 0x1804b3a00, 0x41);
    if (iVar2 == 0) {
        return 0;
    }
    iVar3 = iVar4;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801caf36;
        iVar3 = func_0x0001802248d0(in_RCX, 0x1804b3a00, 0x45);
        if (iVar3 == 0) {
            uVar5 = 0x46;
            goto code_r0x0001801caf44;
        }
    }
    *(int64_t *)(iVar2 + 0x40) = iVar3;
    if (in_EDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801caf7a;
        iVar4 = func_0x000180224d60(in_RCX + 7U >> 3, 0x1804b3a00, 0x50);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801caf97;
            fcn.180224990(iVar3, 0x1804b3a00, 0x52);
            uVar5 = 0x53;
code_r0x0001801caf44:
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801caf53;
            fcn.180224990(iVar2, 0x1804b3a00, uVar5);
            return 0;
        }
    }
    *(int64_t *)(iVar2 + 0x48) = iVar4;
    return iVar2;
}

// ============================================================
// Function: FUN_1801cafd0
// Address: 0x1801cafd0
// Size: 342 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801cafd0(int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint8_t *in_RDX;
    undefined8 uVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cafe5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(uint64_t *)(in_RDX + 8);
    if (uVar1 < (uint64_t)(*(int64_t *)(in_RDX + 0x20) + *(int64_t *)(in_RDX + 0x18))) {
code_r0x0001801cb0e1:
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cb0e6;
        func_0x000180229480();
        uVar4 = 0x1ca;
    } else {
        uVar5 = 0x454c;
        if (0x454c < *(uint64_t *)(in_RCX + 0x9c0)) {
            uVar5 = *(uint64_t *)(in_RCX + 0x9c0);
        }
        if (uVar5 < uVar1) goto code_r0x0001801cb0e1;
        if (*(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 400) == 0) {
            uVar4 = *(undefined8 *)(in_RCX + 0xf8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cb045;
            iVar3 = func_0x0001802264b0(uVar4, uVar1 + 0xc);
            if (iVar3 != 0) {
                *(uint64_t *)(in_RCX + 0x2f0) = uVar1;
                *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x180) = uVar1;
                *(uint32_t *)(in_RCX + 0x2f8) = (uint32_t)*in_RDX;
                *(uint8_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x178) = *in_RDX;
                *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x188) = *(undefined2 *)(in_RDX + 0x10);
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cb04f;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cb067;
            func_0x0001802295a0(0x1804b3a00, 0x1d4, 0x1804b3a20);
            uVar4 = 0x50;
            uVar6 = 0x80007;
            goto code_r0x0001801cb109;
        }
        if (uVar1 == *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x180)) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cb0da;
        func_0x000180229480();
        uVar4 = 0x1e2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cb0fe;
    func_0x0001802295a0(0x1804b3a00, uVar4, 0x1804b3a20);
    uVar6 = 0x98;
    uVar4 = 0x2f;
code_r0x0001801cb109:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cb114;
    func_0x00018019b5e0(in_RCX, uVar4, uVar6, 0);
    return 0;
}

// ============================================================
// Function: FUN_1801cb130
// Address: 0x1801cb130
// Size: 622 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_37h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_36h
// WARNING: [rz-ghidra] Removing arg arg_9c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801cb130(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_148h)
{
    undefined2 uVar1;
    uint16_t uVar2;
    undefined8 uVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    int64_t in_RCX;
    uint64_t uVar12;
    undefined4 *in_RDX;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801cb148;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_138h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar9);
    uVar13 = *(uint64_t *)(in_RDX + 8);
    if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RDX + 6) + uVar13) goto code_r0x0001801cb314;
    uVar1 = *(undefined2 *)(in_RDX + 4);
    *(undefined8 *)((int64_t)&arg_30h + iVar9) = 0;
    *(char *)((int64_t)&arg_30h + iVar9 + 7) = (char)uVar1;
    iVar10 = *(int64_t *)(in_RCX + 0x4f0);
    *(char *)((int64_t)&arg_30h + iVar9 + 6) = (char)((uint16_t)uVar1 >> 8);
    uVar3 = *(undefined8 *)(iVar10 + 0x118);
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb1ab;
    iVar10 = func_0x0001801a6680(uVar3, (int64_t)&arg_30h + iVar9);
    if ((iVar10 != 0) && (uVar13 != *(uint64_t *)(in_RDX + 2))) {
        iVar10 = 0;
    }
    uVar2 = *(uint16_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110);
    if ((((*(uint16_t *)(in_RDX + 4) <= uVar2) || (uVar2 + 10 < (uint32_t)*(uint16_t *)(in_RDX + 4))) || (iVar10 != 0))
       || ((uVar2 == 0 && (*(char *)in_RDX == '\x14')))) {
        for (; uVar13 != 0; uVar13 = uVar13 - *(int64_t *)((int64_t)&arg_28h + iVar9)) {
            uVar12 = uVar13;
            if (0x100 < uVar13) {
                uVar12 = 0x100;
            }
            pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x80);
            *(int64_t *)((int64_t)&var_18h + iVar9) = (int64_t)&arg_28h + iVar9;
            *(undefined4 *)((int64_t)&var_10h + iVar9) = 0;
            *(uint64_t *)((int64_t)&var_8h + iVar9) = uVar12;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb389;
            iVar8 = (*pcVar4)(in_RCX, 0x16, 0, (int64_t)&arg_38h + iVar9);
            if (iVar8 < 1) break;
        }
        goto code_r0x0001801cb314;
    }
    if (uVar13 != *(uint64_t *)(in_RDX + 2)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb20d;
        func_0x0001801cb450(in_RCX, in_RDX);
        goto code_r0x0001801cb314;
    }
    uVar12 = 0x454c;
    if (0x454c < *(uint64_t *)(in_RCX + 0x9c0)) {
        uVar12 = *(uint64_t *)(in_RCX + 0x9c0);
    }
    if (uVar12 < uVar13) goto code_r0x0001801cb314;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb238;
    puVar11 = (undefined4 *)
              fcn.1801caed0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                            *(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
    if (puVar11 == (undefined4 *)0x0) goto code_r0x0001801cb314;
    uVar5 = in_RDX[1];
    uVar6 = in_RDX[2];
    uVar7 = in_RDX[3];
    *puVar11 = *in_RDX;
    puVar11[1] = uVar5;
    puVar11[2] = uVar6;
    puVar11[3] = uVar7;
    uVar5 = in_RDX[5];
    uVar6 = in_RDX[6];
    uVar7 = in_RDX[7];
    puVar11[4] = in_RDX[4];
    puVar11[5] = uVar5;
    puVar11[6] = uVar6;
    puVar11[7] = uVar7;
    uVar5 = in_RDX[9];
    uVar6 = in_RDX[10];
    uVar7 = in_RDX[0xb];
    puVar11[8] = in_RDX[8];
    puVar11[9] = uVar5;
    puVar11[10] = uVar6;
    puVar11[0xb] = uVar7;
    uVar5 = in_RDX[0xd];
    uVar6 = in_RDX[0xe];
    uVar7 = in_RDX[0xf];
    puVar11[0xc] = in_RDX[0xc];
    puVar11[0xd] = uVar5;
    puVar11[0xe] = uVar6;
    puVar11[0xf] = uVar7;
    if (uVar13 == 0) {
code_r0x0001801cb2a0:
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb2ad;
        iVar10 = func_0x0001801a6610((int64_t)&arg_30h + iVar9, puVar11);
        if (iVar10 != 0) {
            uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb2c8;
            iVar10 = func_0x0001801a6700(uVar3, iVar10);
            if (iVar10 != 0) goto code_r0x0001801cb314;
        }
    } else {
        uVar3 = *(undefined8 *)(puVar11 + 0x10);
        pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0x80);
        *(int64_t *)((int64_t)&var_18h + iVar9) = (int64_t)&arg_28h + iVar9;
        *(undefined4 *)((int64_t)&var_10h + iVar9) = 0;
        *(uint64_t *)((int64_t)&var_8h + iVar9) = uVar13;
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb295;
        iVar8 = (*pcVar4)(in_RCX, 0x16, 0, uVar3);
        if ((0 < iVar8) && (*(uint64_t *)((int64_t)&arg_28h + iVar9) == uVar13)) goto code_r0x0001801cb2a0;
    }
    uVar3 = *(undefined8 *)(puVar11 + 0x10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb2e7;
    fcn.180224990(uVar3, 0x1804b3a00, 0x62);
    uVar3 = *(undefined8 *)(puVar11 + 0x12);
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb2fd;
    fcn.180224990(uVar3, 0x1804b3a00, 99);
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb312;
    fcn.180224990(puVar11, 0x1804b3a00, 100);
code_r0x0001801cb314:
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801cb324;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_138h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1801cb3a0
// Address: 0x1801cb3a0
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_47h
// WARNING: [rz-ghidra] Detected overlap for variable arg_46h
// WARNING: [rz-ghidra] Removing arg arg_c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c80h because it doesn't fit into ProtoModel

uint64_t fcn.1801cb3a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                      int64_t arg_58h, int64_t arg_60h, int64_t arg_f8h, int64_t arg_108h)
{
    int32_t *piVar1;
    undefined2 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined *puVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined8 uVar16;
    int64_t in_RCX;
    int16_t iVar17;
    uint64_t in_RDX;
    int64_t iVar18;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar19;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cb3b0;
    iVar15 = fcn.18045a350();
    iVar15 = -iVar15;
    if (0 < (int32_t)in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb3c1;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar15), *(int64_t *)((int64_t)aiStackX_18 + iVar15 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb3d9;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar15), *(int64_t *)((int64_t)aiStackX_18 + iVar15 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)(&stack0x00000030 + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb3ef;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar15));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb401;
    iVar11 = fcn.1801c2bb0();
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb40d;
        iVar11 = fcn.18019b690(in_RCX);
        if (iVar11 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb419;
            iVar11 = fcn.18019b2a0(in_RCX);
            if (iVar11 != 0) {
                uVar16 = *(undefined8 *)((int64_t)aiStackX_18 + iVar15);
                *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_28h + iVar15);
                iVar9 = iVar15 + 0x18;
                *(undefined8 *)((int64_t)aiStackX_18 + iVar15) = unaff_RSI;
                *(undefined8 *)((int64_t)&uStackX_10 + iVar15) = 0x1801c2970;
                iVar12 = fcn.18045a350();
                iVar12 = -iVar12;
                if (*(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c0) != 0) {
                    *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2990;
                    uVar13 = fcn.1802450c0(*(int64_t *)((int64_t)&arg_38h + iVar12 + iVar15), 
                                           *(int64_t *)((int64_t)&arg_48h + iVar12 + iVar15));
                    iVar14 = *(int64_t *)(in_RCX + 0x4f0);
                    iVar18 = -1;
                    if (*(uint64_t *)(iVar14 + 0x1c0) < uVar13) {
                        iVar11 = -1;
                        uVar13 = 0;
                    } else {
                        uVar13 = *(uint64_t *)(iVar14 + 0x1c0) - uVar13;
                        if (uVar13 < 0xe4e1c1) {
                            if (uVar13 < 15000000) {
                                iVar11 = -1;
                            } else {
                                iVar11 = 0;
                            }
                        } else {
                            iVar11 = 1;
                        }
                    }
                    uVar19 = 0;
                    if (0 < iVar11) {
                        uVar19 = uVar13;
                    }
                    if (uVar19 == 0) {
                        pcVar3 = *(code **)(iVar14 + 0x1d0);
                        if (pcVar3 == (code *)0x0) {
                            *(int32_t *)(iVar14 + 0x1c8) = *(int32_t *)(iVar14 + 0x1c8) * 2;
                            if (60000000 < *(uint32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8)) {
                                *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8) = 60000000;
                            }
                        } else {
                            uVar4 = *(undefined8 *)(in_RCX + 0x40);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c29f7;
                            uVar10 = (*pcVar3)(uVar4);
                            *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8) = uVar10;
                        }
                        piVar1 = (int32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1b8);
                        *piVar1 = *piVar1 + 1;
                        if (2 < *(uint32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1b8)) {
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2a51;
                            uVar13 = fcn.180193b40(*(int64_t *)(&stack0x00000070 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x00000088 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x00000090 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x00000098 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x000000c0 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x000000c8 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x000000d0 + iVar12 + iVar15), 
                                                   *(int64_t *)((int64_t)&arg_f8h + iVar12 + iVar15));
                            if ((uVar13 >> 0xc & 1) == 0) {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2a60;
                                fcn.180193e90(*(int64_t *)((int64_t)&arg_50h + iVar12 + iVar15));
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2a73;
                                iVar11 = fcn.180219d10(*(int64_t *)((int64_t)&arg_58h + iVar12 + iVar15), 
                                                       *(int64_t *)((int64_t)&arg_60h + iVar12 + iVar15), 
                                                       *(int64_t *)(&stack0x00000068 + iVar12 + iVar15));
                                if ((uint64_t)(int64_t)iVar11 < *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130)) {
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130) = (int64_t)iVar11;
                                }
                            }
                        }
                        iVar14 = *(int64_t *)(in_RCX + 0x4f0);
                        if (0xc < *(uint32_t *)(iVar14 + 0x1b8)) {
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2aa2;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar12 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar12 + iVar15));
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2aba;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar12 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar12 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar12 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar12 + iVar15), 
                                          *(int64_t *)(&stack0x00000068 + iVar12 + iVar15));
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2acd;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_58h + iVar12 + iVar15));
                            return 0xffffffff;
                        }
                        iVar8 = *(int64_t *)(iVar14 + 0x1c0);
                        *(undefined8 *)((int64_t)&arg_50h + iVar12 + iVar15) = uVar16;
                        if (iVar8 == 0) {
                            pcVar3 = *(code **)(iVar14 + 0x1d0);
                            if (pcVar3 == (code *)0x0) {
                                *(undefined4 *)(iVar14 + 0x1c8) = 1000000;
                            } else {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b00;
                                uVar10 = (*pcVar3)(in_RCX, 0);
                                *(undefined4 *)(iVar14 + 0x1c8) = uVar10;
                            }
                        }
                        uVar13 = (uint64_t)*(uint32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8) * 1000;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b2b;
                        iVar14 = fcn.1802450c0(*(int64_t *)((int64_t)&arg_38h + iVar12 + iVar15), 
                                               *(int64_t *)((int64_t)&arg_48h + iVar12 + iVar15));
                        if (uVar13 < -iVar14 - 1U || uVar13 - (-iVar14 - 1U) == 0) {
                            iVar18 = iVar14 + uVar13;
                        }
                        *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c0) = iVar18;
                        iVar18 = *(int64_t *)(in_RCX + 0x4f0);
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b57;
                        fcn.180193c40(*(int64_t *)((int64_t)&arg_50h + iVar12 + iVar15));
                        uVar16 = *(undefined8 *)(iVar18 + 0x1c0);
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b66;
                        uVar16 = fcn.1801c30c0(uVar16);
                        *(undefined8 *)((int64_t)&arg_48h + iVar12 + iVar15) = uVar16;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b80;
                        fcn.180219d10(*(int64_t *)((int64_t)&arg_58h + iVar12 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar12 + iVar15), 
                                      *(int64_t *)(&stack0x00000068 + iVar12 + iVar15));
                        uVar16 = *(undefined8 *)((int64_t)&arg_50h + iVar12 + iVar15);
                        *(undefined8 *)((int64_t)&arg_50h + iVar12 + iVar15) =
                             *(undefined8 *)((int64_t)&arg_58h + iVar12 + iVar15);
                        *(undefined8 *)((int64_t)&arg_58h + iVar12 + iVar15) = unaff_RBP;
                        *(undefined8 *)((int64_t)&arg_60h + iVar12 + iVar15) =
                             *(undefined8 *)((int64_t)&arg_38h + iVar12 + iVar15);
                        *(undefined8 *)((int64_t)&arg_38h + iVar12 + iVar15) = uVar16;
                        *(undefined8 *)(&stack0x00000030 + iVar12 + iVar15) = unaff_R12;
                        *(undefined8 *)((int64_t)&arg_28h + iVar12 + iVar15) = unaff_R13;
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar12 + iVar15 + 8) = unaff_R14;
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar12 + iVar15) = unaff_R15;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801cb802;
                        iVar15 = fcn.18045a350();
                        iVar15 = -iVar15;
                        *(uint64_t *)((int64_t)&arg_48h + iVar15 + iVar12 + iVar9 + -0x18) =
                             *(uint64_t *)0x1806a3940 ^ (int64_t)aiStackX_18 + iVar15 + iVar12 + iVar9 + -0x18;
                        uVar16 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb82a;
                        uVar16 = fcn.18001ed90(uVar16);
                        *(undefined8 *)((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18) = uVar16;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb839;
                        iVar18 = fcn.1801a67e0((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18);
                        do {
                            if (iVar18 == 0) {
code_r0x0001801cb9bc:
                                uVar13 = *(uint64_t *)((int64_t)&arg_48h + iVar15 + iVar12 + iVar9 + -0x18);
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb9c9;
                                uVar13 = fcn.180459870(uVar13 ^ (int64_t)aiStackX_18 + iVar15 + iVar12 + iVar9 + -0x18);
                                return uVar13;
                            }
                            iVar18 = *(int64_t *)(iVar18 + 8);
                            *(undefined8 *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x18) = 0;
                            iVar17 = *(int16_t *)(iVar18 + 0x10) * 2 - *(int16_t *)(iVar18 + 0x28);
                            iVar18 = *(int64_t *)(in_RCX + 0x4f0);
                            *(char *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x11) = (char)iVar17;
                            *(char *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x12) =
                                 (char)((uint16_t)iVar17 >> 8);
                            uVar16 = *(undefined8 *)(iVar18 + 0x120);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb89b;
                            iVar18 = fcn.1801a6680(uVar16, (int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x18);
                            if (iVar18 == 0) {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb9ec;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x18));
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cba04;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)(&stack0x00000068 + iVar15 + iVar12 + iVar9 + -0x18));
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cba1a;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_58h + iVar15 + iVar12 + iVar9 + -0x18));
                                goto code_r0x0001801cb9bc;
                            }
                            puVar5 = *(undefined **)(iVar18 + 8);
                            iVar14 = 1;
                            iVar18 = *(int64_t *)(puVar5 + 8);
                            uVar16 = *(undefined8 *)(puVar5 + 0x40);
                            if (*(int32_t *)(puVar5 + 0x28) == 0) {
                                iVar14 = 0xc;
                            }
                            uVar4 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb8d0;
                            fcn.180498030(uVar4, uVar16, iVar18 + iVar14);
                            iVar18 = *(int64_t *)(in_RCX + 0x4f0);
                            *(int64_t *)(in_RCX + 0x108) = *(int64_t *)(puVar5 + 8) + iVar14;
                            uVar2 = *(undefined2 *)(puVar5 + 0x10);
                            uVar16 = *(undefined8 *)(puVar5 + 8);
                            uVar4 = *(undefined8 *)(puVar5 + 0x20);
                            *(undefined *)(iVar18 + 0x138) = *puVar5;
                            *(undefined8 *)(iVar18 + 0x140) = uVar16;
                            *(undefined2 *)(iVar18 + 0x148) = uVar2;
                            *(undefined8 *)(iVar18 + 0x158) = uVar4;
                            *(undefined8 *)(iVar18 + 0x150) = 0;
                            uVar16 = *(undefined8 *)(in_RCX + 0xc70);
                            uVar4 = *(undefined8 *)(in_RCX + 0xc80);
                            *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1cc) = 1;
                            iVar18 = *(int64_t *)(puVar5 + 0x30);
                            uVar6 = *(undefined8 *)(in_RCX + 0x58);
                            *(int64_t *)(in_RCX + 0xc70) = iVar18;
                            uVar7 = *(undefined8 *)(puVar5 + 0x38);
                            *(undefined8 *)(in_RCX + 0xc80) = uVar7;
                            pcVar3 = *(code **)(iVar18 + 0x58);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb959;
                            (*pcVar3)(uVar7, uVar6);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb96e;
                            iVar11 = fcn.1801ca8a0(*(int64_t *)(&stack0x00000068 + iVar15 + iVar12 + iVar9 + -0x18), 
                                                   *(int64_t *)(&stack0x00000070 + iVar15 + iVar12 + iVar9 + -0x18), 
                                                   *(int64_t *)(&stack0x00000078 + iVar15 + iVar12 + iVar9 + -0x18));
                            *(undefined8 *)(in_RCX + 0xc70) = uVar16;
                            *(undefined8 *)(in_RCX + 0xc80) = uVar4;
                            *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1cc) = 0;
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb9a0;
                            fcn.180219d10(*(int64_t *)((int64_t)&arg_58h + iVar15 + iVar12 + iVar9 + -0x18), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar15 + iVar12 + iVar9 + -0x18), 
                                          *(int64_t *)(&stack0x00000068 + iVar15 + iVar12 + iVar9 + -0x18));
                            if (iVar11 < 1) goto code_r0x0001801cb9bc;
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb9ae;
                            iVar18 = fcn.1801a67e0((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18);
                        } while( true );
                    }
                }
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb425;
            uVar16 = fcn.180193c40(*(int64_t *)(&stack0x00000030 + iVar15));
            *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb432;
            fcn.18021b250(uVar16, 1);
        }
    }
    return in_RDX & 0xffffffff;
}

// ============================================================
// Function: FUN_1801cb450
// Address: 0x1801cb450
// Size: 906 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_9c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_27h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.1801cb450(int64_t placeholder_0, int64_t arg_128h, int64_t arg_178h, int64_t arg_1a8h)
{
    undefined2 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t iVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    undefined4 *in_RDX;
    uint8_t *puVar15;
    int64_t iVar16;
    uint64_t uVar17;
    int32_t iVar18;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801cb466;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_128h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8);
    uVar17 = *(uint64_t *)(in_RDX + 8);
    if (*(uint64_t *)(in_RDX + 2) < *(int64_t *)(in_RDX + 6) + uVar17) goto code_r0x0001801cb7b3;
    uVar13 = 0x454c;
    if (0x454c < *(uint64_t *)(placeholder_0 + 0x9c0)) {
        uVar13 = *(uint64_t *)(placeholder_0 + 0x9c0);
    }
    if ((uVar13 < *(uint64_t *)(in_RDX + 2)) || (uVar17 == 0)) goto code_r0x0001801cb7b3;
    uVar1 = *(undefined2 *)(in_RDX + 4);
    *(undefined8 *)((int64_t)&var_20h + iVar8) = 0;
    *(char *)((int64_t)&var_20h + iVar8 + 7) = (char)uVar1;
    iVar9 = *(int64_t *)(placeholder_0 + 0x4f0);
    *(char *)((int64_t)&var_20h + iVar8 + 6) = (char)((uint16_t)uVar1 >> 8);
    uVar2 = *(undefined8 *)(iVar9 + 0x118);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb4f1;
    iVar9 = fcn.1801a6680(uVar2, (int64_t)&var_20h + iVar8);
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb507;
        puVar10 = (undefined4 *)
                  fcn.1801caed0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                                *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                *(int64_t *)((int64_t)&iStackX_10 + iVar8));
        if (puVar10 != (undefined4 *)0x0) {
            uVar4 = in_RDX[1];
            uVar5 = in_RDX[2];
            uVar6 = in_RDX[3];
            *puVar10 = *in_RDX;
            puVar10[1] = uVar4;
            puVar10[2] = uVar5;
            puVar10[3] = uVar6;
            uVar4 = in_RDX[5];
            uVar5 = in_RDX[6];
            uVar6 = in_RDX[7];
            puVar10[4] = in_RDX[4];
            puVar10[5] = uVar4;
            puVar10[6] = uVar5;
            puVar10[7] = uVar6;
            uVar4 = in_RDX[9];
            uVar5 = in_RDX[10];
            uVar6 = in_RDX[0xb];
            puVar10[8] = in_RDX[8];
            puVar10[9] = uVar4;
            puVar10[10] = uVar5;
            puVar10[0xb] = uVar6;
            uVar4 = in_RDX[0xd];
            uVar5 = in_RDX[0xe];
            uVar6 = in_RDX[0xf];
            puVar10[0xc] = in_RDX[0xc];
            puVar10[0xd] = uVar4;
            puVar10[0xe] = uVar5;
            puVar10[0xf] = uVar6;
            *(undefined8 *)(puVar10 + 8) = *(undefined8 *)(puVar10 + 2);
            *(undefined8 *)(puVar10 + 6) = 0;
            goto code_r0x0001801cb551;
        }
    } else {
        puVar10 = *(undefined4 **)(iVar9 + 8);
        if (*(int64_t *)(puVar10 + 2) != *(int64_t *)(in_RDX + 2)) goto code_r0x0001801cb7b3;
code_r0x0001801cb551:
        if (*(int64_t *)(puVar10 + 0x12) == 0) {
            do {
                uVar13 = uVar17;
                if (0x100 < uVar17) {
                    uVar13 = 0x100;
                }
                pcVar3 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0x80);
                *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = (int64_t)&var_18h + iVar8;
                *(undefined4 *)(&stack0x00000000 + iVar8) = 0;
                *(uint64_t *)(&stack0xfffffffffffffff8 + iVar8) = uVar13;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb599;
                iVar7 = (*pcVar3)(placeholder_0, 0x16, 0, &stack0x00000028 + iVar8);
                if (iVar7 < 1) goto joined_r0x0001801cb75a;
                uVar17 = uVar17 - *(int64_t *)((int64_t)&var_18h + iVar8);
            } while (uVar17 != 0);
            goto code_r0x0001801cb7b3;
        }
        iVar16 = *(int64_t *)(puVar10 + 0x10);
        iVar11 = *(int64_t *)(in_RDX + 6);
        pcVar3 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0x80);
        *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = (int64_t)&var_18h + iVar8;
        *(undefined4 *)(&stack0x00000000 + iVar8) = 0;
        *(uint64_t *)(&stack0xfffffffffffffff8 + iVar8) = uVar17;
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb5e4;
        iVar7 = (*pcVar3)(placeholder_0, 0x16, 0, iVar16 + iVar11);
        if ((0 < iVar7) && (*(uint64_t *)((int64_t)&var_18h + iVar8) == uVar17)) {
            uVar14 = in_RDX[6];
            uVar13 = (uint64_t)(int32_t)uVar14;
            iVar7 = (int32_t)uVar17;
            if (iVar7 < 9) {
                if ((int32_t)uVar14 < (int32_t)(iVar7 + uVar14)) {
                    do {
                        uVar14 = (uint32_t)uVar13;
                        puVar15 = (uint8_t *)(((int64_t)(int32_t)uVar14 >> 3) + *(int64_t *)(puVar10 + 0x12));
                        uVar13 = (uint64_t)(uVar14 + 1);
                        *puVar15 = *puVar15 | (uint8_t)(1 << (uVar14 & 7));
                    } while ((int32_t)(uVar14 + 1) < in_RDX[6] + iVar7);
                }
            } else {
                puVar15 = (uint8_t *)(((int64_t)uVar13 >> 3) + *(int64_t *)(puVar10 + 0x12));
                *puVar15 = *puVar15 | *(uint8_t *)((uint64_t)(uVar14 & 7) + 0x1804b39f0);
                iVar18 = in_RDX[6];
                iVar12 = (iVar18 >> 3) + 1;
                if (iVar12 < iVar7 + -1 + iVar18 >> 3) {
                    iVar16 = (int64_t)iVar12;
                    do {
                        iVar12 = iVar12 + 1;
                        *(undefined *)(iVar16 + *(int64_t *)(puVar10 + 0x12)) = 0xff;
                        iVar18 = in_RDX[6];
                        iVar16 = iVar16 + 1;
                    } while (iVar12 < iVar7 + -1 + iVar18 >> 3);
                }
                puVar15 = (uint8_t *)(((int64_t)(iVar7 + iVar18) + -1 >> 3) + *(int64_t *)(puVar10 + 0x12));
                *puVar15 = *puVar15 | *(uint8_t *)((uint64_t)(iVar7 + iVar18 & 7) + 0x1804b39f8);
            }
            if (*(int64_t *)(in_RDX + 2) != 0) {
                iVar16 = *(int64_t *)(puVar10 + 0x12);
                uVar14 = (uint32_t)*(int64_t *)(in_RDX + 2);
                if (*(char *)(((int64_t)(int32_t)uVar14 + -1 >> 3) + iVar16) ==
                    *(char *)((uint64_t)(uVar14 & 7) + 0x1804b39f8)) {
                    iVar7 = ((int32_t)(uVar14 - 1) >> 3) + -1;
                    if (-1 < iVar7) {
                        iVar11 = (int64_t)iVar7;
                        do {
                            if (*(char *)(iVar16 + iVar11) != -1) goto code_r0x0001801cb726;
                            iVar11 = iVar11 + -1;
                        } while (-1 < iVar11);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb722;
                    fcn.180224990(iVar16, 0x1804b3a00, 0x2af);
                    *(undefined8 *)(puVar10 + 0x12) = 0;
                }
code_r0x0001801cb726:
                if (iVar9 != 0) goto code_r0x0001801cb7b3;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb73c;
                iVar9 = func_0x0001801a6610((int64_t)&var_20h + iVar8, puVar10);
                if (iVar9 == 0) goto code_r0x0001801cb768;
                uVar2 = *(undefined8 *)(*(int64_t *)(placeholder_0 + 0x4f0) + 0x118);
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb757;
                iVar9 = func_0x0001801a6700(uVar2, iVar9);
            }
        }
joined_r0x0001801cb75a:
        if (iVar9 != 0) goto code_r0x0001801cb7b3;
    }
code_r0x0001801cb768:
    if (puVar10 != (undefined4 *)0x0) {
        uVar2 = *(undefined8 *)(puVar10 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb783;
        fcn.180224990(uVar2, 0x1804b3a00, 0x62);
        uVar2 = *(undefined8 *)(puVar10 + 0x12);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb799;
        fcn.180224990(uVar2, 0x1804b3a00, 99);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb7ae;
        fcn.180224990(puVar10, 0x1804b3a00, 100);
    }
code_r0x0001801cb7b3:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1801cb7c3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_128h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1801cb7e0
// Address: 0x1801cb7e0
// Size: 577 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_47h
// WARNING: [rz-ghidra] Detected overlap for variable arg_46h
// WARNING: [rz-ghidra] Removing arg arg_c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c80h because it doesn't fit into ProtoModel

uint64_t fcn.1801cb3a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                      int64_t arg_58h, int64_t arg_60h, int64_t arg_f8h, int64_t arg_108h)
{
    int32_t *piVar1;
    undefined2 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    undefined *puVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined8 uVar16;
    int64_t in_RCX;
    int16_t iVar17;
    uint64_t in_RDX;
    int64_t iVar18;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar19;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cb3b0;
    iVar15 = fcn.18045a350();
    iVar15 = -iVar15;
    if (0 < (int32_t)in_RDX) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb3c1;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar15), *(int64_t *)((int64_t)aiStackX_18 + iVar15 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb3d9;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar15), *(int64_t *)((int64_t)aiStackX_18 + iVar15 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)(&stack0x00000030 + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb3ef;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar15));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb401;
    iVar11 = fcn.1801c2bb0();
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb40d;
        iVar11 = fcn.18019b690(in_RCX);
        if (iVar11 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb419;
            iVar11 = fcn.18019b2a0(in_RCX);
            if (iVar11 != 0) {
                uVar16 = *(undefined8 *)((int64_t)aiStackX_18 + iVar15);
                *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_28h + iVar15);
                iVar9 = iVar15 + 0x18;
                *(undefined8 *)((int64_t)aiStackX_18 + iVar15) = unaff_RSI;
                *(undefined8 *)((int64_t)&uStackX_10 + iVar15) = 0x1801c2970;
                iVar12 = fcn.18045a350();
                iVar12 = -iVar12;
                if (*(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c0) != 0) {
                    *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2990;
                    uVar13 = fcn.1802450c0(*(int64_t *)((int64_t)&arg_38h + iVar12 + iVar15), 
                                           *(int64_t *)((int64_t)&arg_48h + iVar12 + iVar15));
                    iVar14 = *(int64_t *)(in_RCX + 0x4f0);
                    iVar18 = -1;
                    if (*(uint64_t *)(iVar14 + 0x1c0) < uVar13) {
                        iVar11 = -1;
                        uVar13 = 0;
                    } else {
                        uVar13 = *(uint64_t *)(iVar14 + 0x1c0) - uVar13;
                        if (uVar13 < 0xe4e1c1) {
                            if (uVar13 < 15000000) {
                                iVar11 = -1;
                            } else {
                                iVar11 = 0;
                            }
                        } else {
                            iVar11 = 1;
                        }
                    }
                    uVar19 = 0;
                    if (0 < iVar11) {
                        uVar19 = uVar13;
                    }
                    if (uVar19 == 0) {
                        pcVar3 = *(code **)(iVar14 + 0x1d0);
                        if (pcVar3 == (code *)0x0) {
                            *(int32_t *)(iVar14 + 0x1c8) = *(int32_t *)(iVar14 + 0x1c8) * 2;
                            if (60000000 < *(uint32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8)) {
                                *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8) = 60000000;
                            }
                        } else {
                            uVar4 = *(undefined8 *)(in_RCX + 0x40);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c29f7;
                            uVar10 = (*pcVar3)(uVar4);
                            *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8) = uVar10;
                        }
                        piVar1 = (int32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1b8);
                        *piVar1 = *piVar1 + 1;
                        if (2 < *(uint32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1b8)) {
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2a51;
                            uVar13 = fcn.180193b40(*(int64_t *)(&stack0x00000070 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x00000088 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x00000090 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x00000098 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x000000c0 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x000000c8 + iVar12 + iVar15), 
                                                   *(int64_t *)(&stack0x000000d0 + iVar12 + iVar15), 
                                                   *(int64_t *)((int64_t)&arg_f8h + iVar12 + iVar15));
                            if ((uVar13 >> 0xc & 1) == 0) {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2a60;
                                fcn.180193e90(*(int64_t *)((int64_t)&arg_50h + iVar12 + iVar15));
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2a73;
                                iVar11 = fcn.180219d10(*(int64_t *)((int64_t)&arg_58h + iVar12 + iVar15), 
                                                       *(int64_t *)((int64_t)&arg_60h + iVar12 + iVar15), 
                                                       *(int64_t *)(&stack0x00000068 + iVar12 + iVar15));
                                if ((uint64_t)(int64_t)iVar11 < *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130)) {
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130) = (int64_t)iVar11;
                                }
                            }
                        }
                        iVar14 = *(int64_t *)(in_RCX + 0x4f0);
                        if (0xc < *(uint32_t *)(iVar14 + 0x1b8)) {
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2aa2;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar12 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar12 + iVar15));
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2aba;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar12 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar12 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar12 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar12 + iVar15), 
                                          *(int64_t *)(&stack0x00000068 + iVar12 + iVar15));
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2acd;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_58h + iVar12 + iVar15));
                            return 0xffffffff;
                        }
                        iVar8 = *(int64_t *)(iVar14 + 0x1c0);
                        *(undefined8 *)((int64_t)&arg_50h + iVar12 + iVar15) = uVar16;
                        if (iVar8 == 0) {
                            pcVar3 = *(code **)(iVar14 + 0x1d0);
                            if (pcVar3 == (code *)0x0) {
                                *(undefined4 *)(iVar14 + 0x1c8) = 1000000;
                            } else {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b00;
                                uVar10 = (*pcVar3)(in_RCX, 0);
                                *(undefined4 *)(iVar14 + 0x1c8) = uVar10;
                            }
                        }
                        uVar13 = (uint64_t)*(uint32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8) * 1000;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b2b;
                        iVar14 = fcn.1802450c0(*(int64_t *)((int64_t)&arg_38h + iVar12 + iVar15), 
                                               *(int64_t *)((int64_t)&arg_48h + iVar12 + iVar15));
                        if (uVar13 < -iVar14 - 1U || uVar13 - (-iVar14 - 1U) == 0) {
                            iVar18 = iVar14 + uVar13;
                        }
                        *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c0) = iVar18;
                        iVar18 = *(int64_t *)(in_RCX + 0x4f0);
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b57;
                        fcn.180193c40(*(int64_t *)((int64_t)&arg_50h + iVar12 + iVar15));
                        uVar16 = *(undefined8 *)(iVar18 + 0x1c0);
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b66;
                        uVar16 = fcn.1801c30c0(uVar16);
                        *(undefined8 *)((int64_t)&arg_48h + iVar12 + iVar15) = uVar16;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801c2b80;
                        fcn.180219d10(*(int64_t *)((int64_t)&arg_58h + iVar12 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar12 + iVar15), 
                                      *(int64_t *)(&stack0x00000068 + iVar12 + iVar15));
                        uVar16 = *(undefined8 *)((int64_t)&arg_50h + iVar12 + iVar15);
                        *(undefined8 *)((int64_t)&arg_50h + iVar12 + iVar15) =
                             *(undefined8 *)((int64_t)&arg_58h + iVar12 + iVar15);
                        *(undefined8 *)((int64_t)&arg_58h + iVar12 + iVar15) = unaff_RBP;
                        *(undefined8 *)((int64_t)&arg_60h + iVar12 + iVar15) =
                             *(undefined8 *)((int64_t)&arg_38h + iVar12 + iVar15);
                        *(undefined8 *)((int64_t)&arg_38h + iVar12 + iVar15) = uVar16;
                        *(undefined8 *)(&stack0x00000030 + iVar12 + iVar15) = unaff_R12;
                        *(undefined8 *)((int64_t)&arg_28h + iVar12 + iVar15) = unaff_R13;
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar12 + iVar15 + 8) = unaff_R14;
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar12 + iVar15) = unaff_R15;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar12 + iVar15) = 0x1801cb802;
                        iVar15 = fcn.18045a350();
                        iVar15 = -iVar15;
                        *(uint64_t *)((int64_t)&arg_48h + iVar15 + iVar12 + iVar9 + -0x18) =
                             *(uint64_t *)0x1806a3940 ^ (int64_t)aiStackX_18 + iVar15 + iVar12 + iVar9 + -0x18;
                        uVar16 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb82a;
                        uVar16 = fcn.18001ed90(uVar16);
                        *(undefined8 *)((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18) = uVar16;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb839;
                        iVar18 = fcn.1801a67e0((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18);
                        do {
                            if (iVar18 == 0) {
code_r0x0001801cb9bc:
                                uVar13 = *(uint64_t *)((int64_t)&arg_48h + iVar15 + iVar12 + iVar9 + -0x18);
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb9c9;
                                uVar13 = fcn.180459870(uVar13 ^ (int64_t)aiStackX_18 + iVar15 + iVar12 + iVar9 + -0x18);
                                return uVar13;
                            }
                            iVar18 = *(int64_t *)(iVar18 + 8);
                            *(undefined8 *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x18) = 0;
                            iVar17 = *(int16_t *)(iVar18 + 0x10) * 2 - *(int16_t *)(iVar18 + 0x28);
                            iVar18 = *(int64_t *)(in_RCX + 0x4f0);
                            *(char *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x11) = (char)iVar17;
                            *(char *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x12) =
                                 (char)((uint16_t)iVar17 >> 8);
                            uVar16 = *(undefined8 *)(iVar18 + 0x120);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb89b;
                            iVar18 = fcn.1801a6680(uVar16, (int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x18);
                            if (iVar18 == 0) {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb9ec;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x18));
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cba04;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar15 + iVar12 + iVar9 + -0x18), 
                                              *(int64_t *)(&stack0x00000068 + iVar15 + iVar12 + iVar9 + -0x18));
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cba1a;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_58h + iVar15 + iVar12 + iVar9 + -0x18));
                                goto code_r0x0001801cb9bc;
                            }
                            puVar5 = *(undefined **)(iVar18 + 8);
                            iVar14 = 1;
                            iVar18 = *(int64_t *)(puVar5 + 8);
                            uVar16 = *(undefined8 *)(puVar5 + 0x40);
                            if (*(int32_t *)(puVar5 + 0x28) == 0) {
                                iVar14 = 0xc;
                            }
                            uVar4 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb8d0;
                            fcn.180498030(uVar4, uVar16, iVar18 + iVar14);
                            iVar18 = *(int64_t *)(in_RCX + 0x4f0);
                            *(int64_t *)(in_RCX + 0x108) = *(int64_t *)(puVar5 + 8) + iVar14;
                            uVar2 = *(undefined2 *)(puVar5 + 0x10);
                            uVar16 = *(undefined8 *)(puVar5 + 8);
                            uVar4 = *(undefined8 *)(puVar5 + 0x20);
                            *(undefined *)(iVar18 + 0x138) = *puVar5;
                            *(undefined8 *)(iVar18 + 0x140) = uVar16;
                            *(undefined2 *)(iVar18 + 0x148) = uVar2;
                            *(undefined8 *)(iVar18 + 0x158) = uVar4;
                            *(undefined8 *)(iVar18 + 0x150) = 0;
                            uVar16 = *(undefined8 *)(in_RCX + 0xc70);
                            uVar4 = *(undefined8 *)(in_RCX + 0xc80);
                            *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1cc) = 1;
                            iVar18 = *(int64_t *)(puVar5 + 0x30);
                            uVar6 = *(undefined8 *)(in_RCX + 0x58);
                            *(int64_t *)(in_RCX + 0xc70) = iVar18;
                            uVar7 = *(undefined8 *)(puVar5 + 0x38);
                            *(undefined8 *)(in_RCX + 0xc80) = uVar7;
                            pcVar3 = *(code **)(iVar18 + 0x58);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb959;
                            (*pcVar3)(uVar7, uVar6);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb96e;
                            iVar11 = fcn.1801ca8a0(*(int64_t *)(&stack0x00000068 + iVar15 + iVar12 + iVar9 + -0x18), 
                                                   *(int64_t *)(&stack0x00000070 + iVar15 + iVar12 + iVar9 + -0x18), 
                                                   *(int64_t *)(&stack0x00000078 + iVar15 + iVar12 + iVar9 + -0x18));
                            *(undefined8 *)(in_RCX + 0xc70) = uVar16;
                            *(undefined8 *)(in_RCX + 0xc80) = uVar4;
                            *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1cc) = 0;
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb9a0;
                            fcn.180219d10(*(int64_t *)((int64_t)&arg_58h + iVar15 + iVar12 + iVar9 + -0x18), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar15 + iVar12 + iVar9 + -0x18), 
                                          *(int64_t *)(&stack0x00000068 + iVar15 + iVar12 + iVar9 + -0x18));
                            if (iVar11 < 1) goto code_r0x0001801cb9bc;
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + iVar12 + iVar9 + -0x18) = 0x1801cb9ae;
                            iVar18 = fcn.1801a67e0((int64_t)&arg_38h + iVar15 + iVar12 + iVar9 + -0x18);
                        } while( true );
                    }
                }
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb425;
            uVar16 = fcn.180193c40(*(int64_t *)(&stack0x00000030 + iVar15));
            *(undefined8 *)((int64_t)&uStack_10 + iVar15) = 0x1801cb432;
            fcn.18021b250(uVar16, 1);
        }
    }
    return in_RDX & 0xffffffff;
}

// ============================================================
// Function: FUN_1801cba30
// Address: 0x1801cba30
// Size: 672 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1801cba30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint16_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iVar10;
    undefined8 unaff_R14;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801cba43;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    bVar4 = false;
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cba65;
    uVar7 = fcn.18001ed90(uVar7);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = uVar7;
    while( true ) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cba8a;
        iVar8 = fcn.1801a67e0((int64_t)&arg_28h + iVar6);
        if (iVar8 == 0) {
            return 0;
        }
        iVar10 = *(int64_t *)(iVar8 + 8);
        uVar1 = *(uint16_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110);
        if (uVar1 <= *(uint16_t *)(iVar10 + 0x10)) break;
        if ((((*(int32_t *)(in_RCX + 0x78) != 0) && (*(uint16_t *)(iVar10 + 0x10) == 0)) && (uVar1 == 1)) &&
           (*(int32_t *)(in_RCX + 0xac) == 0x17)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbb33;
            iVar9 = fcn.1801a67e0((int64_t)&arg_28h + iVar6);
            if (iVar9 != 0) {
                iVar2 = *(int64_t *)(iVar9 + 8);
                if (*(int16_t *)(iVar2 + 0x10) == *(int16_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110)) {
                    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbb60;
                    func_0x0001801a6800(uVar7);
                    uVar7 = *(undefined8 *)(iVar10 + 0x40);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbb76;
                    fcn.180224990(uVar7, 0x1804b3a00, 0x62);
                    uVar7 = *(undefined8 *)(iVar10 + 0x48);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbb8c;
                    fcn.180224990(uVar7, 0x1804b3a00, 99);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbba1;
                    fcn.180224990(iVar10, 0x1804b3a00, 100);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbba9;
                    func_0x0001801a65e0(iVar8);
                    iVar8 = iVar9;
                    iVar10 = iVar2;
                    break;
                }
            }
            bVar4 = true;
            break;
        }
        uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbadb;
        func_0x0001801a6800(uVar7);
        uVar7 = *(undefined8 *)(iVar10 + 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbaf1;
        fcn.180224990(uVar7, 0x1804b3a00, 0x62);
        uVar7 = *(undefined8 *)(iVar10 + 0x48);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbb07;
        fcn.180224990(uVar7, 0x1804b3a00, 99);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbb1c;
        fcn.180224990(iVar10, 0x1804b3a00, 100);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbb24;
        func_0x0001801a65e0(iVar8);
    }
    if (*(int64_t *)(iVar10 + 0x48) != 0) {
        return 0;
    }
    if ((*(int16_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110) != *(int16_t *)(iVar10 + 0x10)) && (!bVar4)) {
        return 0;
    }
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
    uVar3 = *(undefined8 *)(iVar10 + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbbee;
    func_0x0001801a6800(uVar7);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbbf9;
    iVar5 = fcn.1801cafd0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    if ((iVar5 != 0) && (*(int64_t *)(iVar10 + 0x20) != 0)) {
        iVar9 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        iVar2 = *(int64_t *)(iVar10 + 0x18);
        uVar7 = *(undefined8 *)(iVar10 + 0x40);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbc28;
        fcn.180498030(iVar2 + iVar9 + 0xc, uVar7);
    }
    uVar7 = *(undefined8 *)(iVar10 + 0x40);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbc3e;
    fcn.180224990(uVar7, 0x1804b3a00, 0x62);
    uVar7 = *(undefined8 *)(iVar10 + 0x48);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbc54;
    fcn.180224990(uVar7, 0x1804b3a00, 99);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbc69;
    fcn.180224990(iVar10, 0x1804b3a00, 100);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801cbc71;
    func_0x0001801a65e0(iVar8);
    if (iVar5 == 0) {
        *(undefined8 *)(in_RCX + 0x108) = 0;
        return 0xffffffff;
    }
    if (bVar4) {
        *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110) = 0;
        *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10e) = 0;
    }
    *in_RDX = uVar3;
    return 1;
}

// ============================================================
// Function: FUN_1801cbcd0
// Address: 0x1801cbcd0
// Size: 262 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801cbcd0(int64_t arg_28h, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cbce0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10c) = *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10e);
    iVar1 = *(int64_t *)(in_RCX + 0x4f0);
    if (in_R8D == 0x101) {
        *(undefined *)(iVar1 + 0x138) = 1;
        *(undefined8 *)(iVar1 + 0x140) = 0;
        *(undefined2 *)(iVar1 + 0x148) = *(undefined2 *)(iVar1 + 0x10c);
        *(undefined8 *)(iVar1 + 0x150) = 0;
        *(undefined8 *)(iVar1 + 0x158) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801cbd4c;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
        if (iVar2 != 0) {
            return true;
        }
    } else {
        *(int16_t *)(iVar1 + 0x10e) = *(int16_t *)(iVar1 + 0x10e) + 1;
        iVar1 = *(int64_t *)(in_RCX + 0x4f0);
        *(char *)(iVar1 + 0x138) = (char)in_R8D;
        *(undefined2 *)(iVar1 + 0x148) = *(undefined2 *)(iVar1 + 0x10c);
        *(undefined8 *)(iVar1 + 0x140) = 0;
        *(undefined8 *)(iVar1 + 0x150) = 0;
        *(undefined8 *)(iVar1 + 0x158) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801cbdab;
        iVar2 = fcn.180243f60(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801cbdb7;
            iVar2 = fcn.180244a20(in_RDX);
            return iVar2 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801cbde0
// Address: 0x1801cbde0
// Size: 146 bytes
// ============================================================
undefined8 fcn.1801cbde0(int64_t param_1)
{
    int16_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cbdec;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int32_t *)(param_1 + 0x48) == 0x100) {
        piVar1 = (int16_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x10e);
        *piVar1 = *piVar1 + 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801cbe28;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801cbe31;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801cbe49;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801cbe5f;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801cbe80
// Address: 0x1801cbe80
// Size: 416 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801cbe80(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_a8h)
{
    int16_t *piVar1;
    undefined uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined *puVar5;
    code *pcVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined uVar10;
    int64_t in_RCX;
    undefined uVar11;
    int32_t *in_RDX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cbe95;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    iVar4 = *(int64_t *)(in_RCX + 0x4f0);
    *(undefined (*) [16])(iVar4 + 0x178) = ZEXT816(0);
    *(undefined (*) [16])(iVar4 + 0x188) = ZEXT816(0);
    *(undefined (*) [16])(iVar4 + 0x198) = ZEXT816(0);
    *(undefined (*) [16])(iVar4 + 0x1a8) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801cbed3;
    iVar8 = func_0x0001801cc140(0, (int64_t)&arg_48h + iVar9, (int64_t)&arg_58h + iVar9);
    while( true ) {
        if (iVar8 != 0) {
            iVar8 = *(int32_t *)(in_RCX + 0x2f8);
            *in_RDX = iVar8;
            puVar5 = *(undefined **)(*(int64_t *)(in_RCX + 0xf8) + 8);
            if (iVar8 == 0x101) {
                pcVar6 = *(code **)(in_RCX + 0x4f8);
                if (pcVar6 != (code *)0x0) {
                    uVar3 = *(undefined4 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&arg_28h + iVar9) = *(undefined8 *)(in_RCX + 0x500);
                    *(undefined8 *)((int64_t)&var_20h + iVar9) = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined8 *)((int64_t)&var_18h + iVar9) = 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801cbf58;
                    (*pcVar6)(0, uVar3, 0x14);
                }
            } else {
                uVar7 = *(undefined8 *)(iVar4 + 0x180);
                *puVar5 = *(undefined *)(iVar4 + 0x178);
                puVar5[3] = (char)uVar7;
                uVar10 = (undefined)((uint64_t)uVar7 >> 8);
                puVar5[2] = uVar10;
                uVar11 = (undefined)((uint64_t)uVar7 >> 0x10);
                puVar5[1] = uVar11;
                puVar5[4] = *(undefined *)(iVar4 + 0x189);
                uVar2 = *(undefined *)(iVar4 + 0x188);
                puVar5[10] = uVar10;
                puVar5[5] = uVar2;
                *(undefined2 *)(puVar5 + 6) = 0;
                puVar5[8] = 0;
                puVar5[9] = uVar11;
                puVar5[0xb] = (char)uVar7;
                *(undefined (*) [16])(iVar4 + 0x178) = ZEXT816(0);
                *(undefined (*) [16])(iVar4 + 0x188) = ZEXT816(0);
                *(undefined (*) [16])(iVar4 + 0x198) = ZEXT816(0);
                *(undefined (*) [16])(iVar4 + 0x1a8) = ZEXT816(0);
                piVar1 = (int16_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110);
                *piVar1 = *piVar1 + 1;
                *(int64_t *)(in_RCX + 0x100) = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + 0xc;
            }
            return 1;
        }
        if (1 < *(int32_t *)((int64_t)&arg_48h + iVar9) + 3U) break;
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801cbefe;
        iVar8 = func_0x0001801cc140(in_RCX, (int64_t)&arg_48h + iVar9, (int64_t)&arg_58h + iVar9);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801cc020
// Address: 0x1801cc020
// Size: 273 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801cc020(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 *in_RDX;
    int64_t iVar7;
    char *pcVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801cc044;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar2 = *(int64_t *)(in_RCX + 0x108);
    pcVar8 = *(char **)(*(int64_t *)(in_RCX + 0xf8) + 8);
    if (*(int32_t *)(in_RCX + 0x2f8) == 0x101) {
code_r0x0001801cc106:
        *in_RDX = *(undefined8 *)(in_RCX + 0x108);
        uVar6 = 1;
    } else {
        if (*pcVar8 == '\x14') {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801cc08b;
            iVar4 = func_0x0001801aed80();
            if (iVar4 != 0) goto code_r0x0001801cc096;
        } else {
code_r0x0001801cc096:
            iVar7 = iVar2 + 0xc;
            if (*(int32_t *)(in_RCX + 0x48) == 0x100) {
                pcVar8 = pcVar8 + 0xc;
                iVar7 = iVar2;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801cc0b4;
            iVar4 = func_0x0001801dac70(in_RCX, pcVar8, iVar7);
            if (iVar4 != 0) {
                pcVar3 = *(code **)(in_RCX + 0x4f8);
                if (pcVar3 != (code *)0x0) {
                    iVar2 = *(int64_t *)(in_RCX + 0x108);
                    iVar7 = *(int64_t *)(in_RCX + 0xf8);
                    uVar1 = *(undefined4 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&var_18h + iVar5) = *(undefined8 *)(in_RCX + 0x500);
                    uVar6 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x40);
                    *(int64_t *)((int64_t)&var_8h + iVar5) = iVar2 + 0xc;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801cc106;
                    (*pcVar3)(0, uVar1, 0x16, uVar6);
                }
                goto code_r0x0001801cc106;
            }
        }
        uVar6 = 0;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801cc140
// Address: 0x1801cc140
// Size: 1237 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_9c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_27h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_37h
// WARNING: [rz-ghidra] Detected overlap for variable arg_36h

undefined8 fcn.1801cc140(int64_t placeholder_0, int64_t arg2, int64_t arg_a8h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    int16_t iVar4;
    undefined8 uVar5;
    char *pcVar6;
    code *pcVar7;
    bool bVar8;
    int32_t iVar9;
    undefined4 uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    undefined8 uStack_40;
    
    var_10h = arg2;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    uVar5 = *(undefined8 *)(placeholder_0 + 0x40);
    bVar8 = false;
    *(undefined4 *)arg2 = 0;
    pcVar6 = *(char **)(*(int64_t *)(placeholder_0 + 0xf8) + 8);
    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc18e;
    iVar9 = fcn.1801cba30(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11));
    do {
        if (iVar9 < 0) {
            return 0;
        }
        if (iVar9 != 0) {
            *(int64_t *)(placeholder_0 + 0x108) = var_88h;
            *in_R8 = var_88h;
            return 1;
        }
        pcVar7 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0x80);
        *(int64_t **)(&stack0xfffffffffffffff8 + iVar11) = &var_20h;
        *(undefined4 *)(&stack0xfffffffffffffff0 + iVar11) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar11) = 0xc;
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc1cd;
        iVar9 = (*pcVar7)(placeholder_0, 0x16, &var_8h, pcVar6);
        if (iVar9 < 1) {
code_r0x0001801cc5ec:
            *(undefined4 *)(placeholder_0 + 0x68) = 3;
            *in_R8 = 0;
            return 0;
        }
        if ((char)var_8h == '\x14') {
            if (*pcVar6 != '\x01') {
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc56c;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar11));
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc584;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                              *(int64_t *)((int64_t)&var_18h + iVar11));
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc59a;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar11));
                *(undefined8 *)(placeholder_0 + 0x108) = 0;
                *in_R8 = 0;
                return 0;
            }
            uVar12 = var_20h - 1;
            *(uint64_t *)(placeholder_0 + 0x108) = uVar12;
            iVar11 = *(int64_t *)(*(int64_t *)(placeholder_0 + 0xf8) + 8);
            *(undefined4 *)(placeholder_0 + 0x2f8) = 0x101;
            *(int64_t *)(placeholder_0 + 0x100) = iVar11 + 1;
            *(uint64_t *)(placeholder_0 + 0x2f0) = uVar12;
            *in_R8 = uVar12;
            return 1;
        }
        if (var_20h != 0xc) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc524;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11));
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc53c;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11));
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc552;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar11));
            *(undefined8 *)(placeholder_0 + 0x108) = 0;
            *in_R8 = 0;
            return 0;
        }
        cVar1 = pcVar6[7];
        cVar2 = pcVar6[6];
        cVar3 = pcVar6[8];
        var_88h = (int64_t)CONCAT21(CONCAT11(pcVar6[9], pcVar6[10]), pcVar6[0xb]);
        if (*(uint64_t *)(*(int64_t *)(placeholder_0 + 0xd08) * 0x40 + 0xd30 + placeholder_0) < (uint64_t)var_88h) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc4f4;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11));
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc50c;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11));
code_r0x0001801cc3f7:
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc3ff;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar11));
code_r0x0001801cc3ff:
            *(undefined8 *)(placeholder_0 + 0x108) = 0;
            *in_R8 = 0;
            return 0;
        }
        iVar4 = *(int16_t *)(*(int64_t *)(placeholder_0 + 0x4f0) + 0x110);
        if (CONCAT11(pcVar6[4], pcVar6[5]) != iVar4) {
            if ((((*(int32_t *)(placeholder_0 + 0x78) == 0) || (CONCAT11(pcVar6[4], pcVar6[5]) != 0)) || (iVar4 != 1))
               || ((*pcVar6 != '\x01' || (*(int32_t *)(placeholder_0 + 0xac) != 0x17)))) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc39b;
                uVar10 = fcn.1801cb130(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                       *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                       *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), 
                                       *(int64_t *)(&stack0x00000108 + iVar11));
                goto code_r0x0001801cc39b;
            }
            bVar8 = true;
        }
        if ((var_88h != 0) && ((uint64_t)var_88h < (uint64_t)CONCAT21(CONCAT11(pcVar6[1], pcVar6[2]), pcVar6[3]))) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc3ca;
            uVar10 = fcn.1801cb450(placeholder_0, *(int64_t *)(&stack0x000000e8 + iVar11), 
                                   *(int64_t *)(&stack0x00000138 + iVar11), *(int64_t *)(&stack0x00000168 + iVar11));
code_r0x0001801cc39b:
            *(undefined4 *)var_10h = uVar10;
            return 0;
        }
        if ((((*(int32_t *)(placeholder_0 + 0x78) != 0) ||
             (*(int64_t *)(*(int64_t *)(placeholder_0 + 0x4f0) + 400) != 0)) ||
            (*(int32_t *)(placeholder_0 + 0xac) == 1)) || (*pcVar6 != '\0')) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc41b;
            iVar9 = fcn.1801cafd0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar11));
            if (iVar9 != 0) {
                if (var_88h == 0) {
                    var_20h = 0;
                } else {
                    pcVar7 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0x80);
                    *(int64_t **)(&stack0xfffffffffffffff8 + iVar11) = &var_20h;
                    *(undefined4 *)(&stack0xfffffffffffffff0 + iVar11) = 0;
                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar11) = var_88h;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc457;
                    iVar9 = (*pcVar7)(placeholder_0, 0x16, 0, 
                                      pcVar6 + (uint64_t)CONCAT21(CONCAT11(cVar2, cVar1), cVar3) + 0xc);
                    if (iVar9 < 1) goto code_r0x0001801cc5ec;
                }
                if (var_20h != var_88h) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc479;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar11));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc491;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), 
                                  *(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_18h + iVar11));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc4a7;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar11));
                    *(undefined8 *)(placeholder_0 + 0x108) = 0;
                    *in_R8 = 0;
                    return 0;
                }
                if (bVar8) {
                    *(undefined2 *)(*(int64_t *)(placeholder_0 + 0x4f0) + 0x110) = 0;
                    *(undefined2 *)(*(int64_t *)(placeholder_0 + 0x4f0) + 0x10e) = 0;
                }
                *(int64_t *)(placeholder_0 + 0x108) = var_88h;
                *in_R8 = var_88h;
                return 1;
            }
            goto code_r0x0001801cc3ff;
        }
        if (((pcVar6[1] != '\0') || (pcVar6[2] != '\0')) || (pcVar6[3] != '\0')) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc3d1;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11));
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc3e9;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                          *(int64_t *)((int64_t)&var_18h + iVar11));
            goto code_r0x0001801cc3f7;
        }
        pcVar7 = *(code **)(placeholder_0 + 0x4f8);
        if (pcVar7 != (code *)0x0) {
            uVar10 = *(undefined4 *)(placeholder_0 + 0x48);
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar11) = *(undefined8 *)(placeholder_0 + 0x500);
            *(undefined8 *)(&stack0xfffffffffffffff0 + iVar11) = uVar5;
            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar11) = 0xc;
            *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc36f;
            (*pcVar7)(0, uVar10, 0x16, pcVar6);
        }
        *(undefined8 *)(placeholder_0 + 0x108) = 0;
        *(undefined8 *)((int64_t)&uStack_40 + iVar11) = 0x1801cc385;
        iVar9 = fcn.1801cba30(*(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11));
    } while( true );
}

// ============================================================
// Function: FUN_1801cc620
// Address: 0x1801cc620
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801cc620(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cc63b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc65c;
    fcn.180224990(iVar1, 0x1804a9450, 0x1d9);
    *in_RDX = 0;
    *in_R8 = 0;
    iVar1 = *(int64_t *)(in_RCX + 8);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc685;
        iVar2 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar2));
        *in_RDX = iVar2;
        if (iVar2 == 0) {
            return 0;
        }
        *in_R8 = iVar1;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801cc6e0
// Address: 0x1801cc6e0
// Size: 243 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801cc6e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cc6f5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc716;
    iVar3 = fcn.180197550(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
    if (iVar3 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc738;
    iVar4 = fcn.180215470();
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc74b;
        iVar1 = fcn.180214840(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2));
        if (0 < iVar1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc764;
            iVar1 = fcn.1802149b0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar2));
            if (0 < iVar1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc77d;
                iVar1 = fcn.1802149b0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                                      *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                                      *(int64_t *)(&stack0x00000068 + iVar2));
                if (0 < iVar1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc791;
                    iVar1 = fcn.1802146d0(*(int64_t *)((int64_t)&var_18h + iVar2), 
                                          *(int64_t *)((int64_t)&var_20h + iVar2), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar2));
                    if (0 < iVar1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc79d;
                        fcn.180215310(iVar4);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc7a5;
                        fcn.1801975c0(iVar3);
                        return 1;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc7b4;
    fcn.180215310(iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc7bc;
    fcn.1801975c0(iVar3);
    return 0;
}

// ============================================================
// Function: FUN_1801cc7e0
// Address: 0x1801cc7e0
// Size: 688 bytes
// ============================================================
undefined8 fcn.1801cc7e0(int64_t param_1)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cc7ec;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    // switch table (52 cases) at 0x1801cca38
    switch(*(undefined4 *)(param_1 + 0xac)) {
    case 1:
        if (*(int32_t *)(param_1 + 0xba4) != -1) {
            *(undefined4 *)(param_1 + 0xac) = 0x2f;
            return 1;
        }
        return 2;
    default:
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cca01;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        break;
    case 8:
        if (*(int32_t *)(param_1 + 0xba8) == 4) {
            if ((*(char *)(param_1 + 0xb50) != '\0') || (uVar1 = 0xf, *(int32_t *)(param_1 + 0xb3c) == 0)) {
                uVar1 = 0xe;
            }
            *(undefined4 *)(param_1 + 0xac) = uVar1;
            return 1;
        }
        if ((*(uint8_t *)(param_1 + 0x84) & 1) != 0) goto code_r0x0001801cc86e;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc864;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        break;
    case 10:
    case 0x14:
    case 0x2f:
    case 0x31:
code_r0x0001801cc86e:
        *(undefined4 *)(param_1 + 0xac) = 1;
        return 1;
    case 0xc:
        if ((*(int32_t *)(param_1 + 0xf0) == 3) || (*(int32_t *)(param_1 + 0xf0) == 7)) {
            *(undefined4 *)(param_1 + 0xac) = 0x33;
        } else if (((*(uint32_t *)(param_1 + 0x9a8) >> 0x14 & 1) == 0) || (*(int32_t *)(param_1 + 0x8c8) != 0)) {
            if (*(int32_t *)(param_1 + 0x340) == 0) {
                *(undefined4 *)(param_1 + 0xac) = 0x14;
            } else if ((*(char *)(param_1 + 0xb50) == '\0') && (*(int32_t *)(param_1 + 0xb3c) != 0)) {
                *(undefined4 *)(param_1 + 0xac) = 0xf;
            } else {
                *(undefined4 *)(param_1 + 0xac) = 0xe;
            }
        } else {
            *(undefined4 *)(param_1 + 0xac) = 0x12;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cc903;
        uVar3 = fcn.1802450c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)(param_1 + 0x90) = uVar3;
        return 1;
    case 0xe:
    case 0xf:
        uVar1 = 0x14;
        if (*(int32_t *)(param_1 + 0x340) == 1) {
            uVar1 = 0x11;
        }
        *(undefined4 *)(param_1 + 0xac) = uVar1;
        return 1;
    case 0x11:
        *(undefined4 *)(param_1 + 0xac) = 0x14;
        return 1;
    case 0x33:
        if ((*(int32_t *)(param_1 + 0xb18) == 2) && ((*(uint32_t *)(param_1 + 0x160) & 0x2000) == 0)) {
            *(undefined4 *)(param_1 + 0xac) = 0x34;
            return 1;
        }
    case 0x12:
    case 0x34:
        if (*(int32_t *)(param_1 + 0x340) == 0) {
            *(undefined4 *)(param_1 + 0xac) = 0x14;
            return 1;
        }
        if ((*(char *)(param_1 + 0xb50) == '\0') && (*(int32_t *)(param_1 + 0xb3c) != 0)) {
            *(undefined4 *)(param_1 + 0xac) = 0xf;
            return 1;
        }
        *(undefined4 *)(param_1 + 0xac) = 0xe;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cca19;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801cca2f;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801cca90
// Address: 0x1801cca90
// Size: 516 bytes
// ============================================================
undefined8 fcn.1801cca90(int64_t param_1, code **param_2, undefined4 *param_3)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cca9c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    // switch table (40 cases) at 0x1801ccc40
    switch(*(undefined4 *)(param_1 + 0xac)) {
    case 0xd:
        *param_2 = (code *)0x1801cfdb0;
        *param_3 = 1;
        return 1;
    case 0xe:
        *param_2 = (code *)0x1801cfb30;
        *param_3 = 0xb;
        return 1;
    default:
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ccc07;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ccc1f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801ccc35;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    case 0x10:
        *param_2 = (code *)0x1801d01c0;
        *param_3 = 0x10;
        return 1;
    case 0x11:
        *param_2 = (code *)0x1801b01f0;
        *param_3 = 0xf;
        return 1;
    case 0x12:
        break;
    case 0x13:
        *param_2 = (code *)0x1801d05d0;
        *param_3 = 0x43;
        return 1;
    case 0x14:
        *param_2 = (code *)0x1801b0640;
        *param_3 = 0x14;
        return 1;
    case 0x2f:
        *param_2 = (code *)0x1801b0830;
        *param_3 = 0x18;
        return 1;
    case 0x33:
        *param_2 = (code *)0x0;
        *param_3 = 0xffffffff;
        return 1;
    case 0x34:
        *param_2 = (code *)0x1801d0550;
        *param_3 = 5;
        return 1;
    }
    pcVar2 = fcn.1801cbde0;
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(param_1 + 0x18) + 0xd8) + 0x50) & 8) == 0) {
        pcVar2 = (code *)0x1801b05d0;
    }
    *param_2 = pcVar2;
    *param_3 = 0x101;
    return 1;
}

// ============================================================
// Function: FUN_1801ccdc0
// Address: 0x1801ccdc0
// Size: 128 bytes
// ============================================================
uint64_t fcn.1801ccdc0(int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                      int64_t arg_98h, int64_t arg_c8h, int64_t arg_208h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iStack_10;
    
    iStack_10 = 0x1801ccdcc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = *(int32_t *)(in_RCX + 0xac);
    if ((iVar4 == 4) || (iVar4 == 5)) {
        *(undefined8 *)(&stack0x00000018 + iVar5) = *(undefined8 *)(&stack0x00000018 + iVar5);
        *(undefined8 *)(&stack0x00000010 + iVar5) = 0x1801d06bc;
        iVar8 = fcn.18045a350();
        iVar8 = -iVar8;
        if (*(char *)(in_RCX + 0xb52) == '\x02') {
            *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d06d0;
            uVar9 = fcn.1801d09a0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar5));
            return uVar9;
        }
        iVar4 = *(int32_t *)(in_RCX + 0x68);
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar5) = unaff_RDI;
        if (iVar4 == 8) {
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d06ed;
        fcn.180229b10();
        uVar6 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0703;
        iVar4 = fcn.1801a2880(in_RCX, uVar6);
        if ((iVar4 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
            *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0717;
            fcn.180229900();
            *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d071c;
            fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), *(int64_t *)(&stack0x00000040 + iVar8 + iVar5)
                         );
            *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0734;
            fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), *(int64_t *)(&stack0x00000040 + iVar8 + iVar5)
                          , *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5), 
                          *(int64_t *)(&stack0x00000068 + iVar8 + iVar5));
            uVar1 = *(undefined4 *)(in_RCX + 0x990);
            *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d073f;
            fcn.1801affa0(uVar1);
            *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0752;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_58h + iVar8 + iVar5));
            return 0;
        }
        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0764;
        fcn.1802299d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), *(int64_t *)(&stack0x00000040 + iVar8 + iVar5));
        if ((0 < iVar4) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
            return 4;
        }
        iVar7 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar5) = unaff_RSI;
        uVar6 = *(undefined8 *)(iVar7 + 0x2c8);
        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0798;
        uVar6 = fcn.180222340(uVar6, 0);
        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d07a3;
        iVar7 = fcn.180238400(uVar6);
        if (iVar7 != 0) {
            *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d07b7;
            iVar4 = fcn.18022fd20(iVar7);
            if (iVar4 == 0) {
                *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d07d0;
                iVar7 = fcn.1801a2080(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5));
                if (iVar7 == 0) {
                    *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d07dd;
                    fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar5));
                    *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d07f5;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000068 + iVar8 + iVar5));
                } else if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                            (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) ||
                          ((*(uint32_t *)(iVar7 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) != 0)) {
                    *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d086a;
                    iVar4 = fcn.1802375f0(uVar6);
                    if (iVar4 != 0) {
                        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d08a9;
                        fcn.18021fe80(*(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                                      *(int64_t *)(&stack0x00000068 + iVar8 + iVar5));
                        *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = uVar6;
                        *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
                        uVar6 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d08dd;
                        fcn.18022ecc0(uVar6);
                        *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                            (iVar4 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar4)) && (iVar4 != 0x10000)) {
                            *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d092c;
                            iVar4 = fcn.180197770(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5));
                            return (uint64_t)(-(uint32_t)(iVar4 != 0) & 2);
                        }
                        return 2;
                    }
                    *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0873;
                    fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar5));
                    *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d088b;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000068 + iVar8 + iVar5));
                } else {
                    *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d083a;
                    fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar5));
                    *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0852;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000068 + iVar8 + iVar5));
                }
                goto code_r0x0001801d0980;
            }
        }
        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d095d;
        fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), *(int64_t *)(&stack0x00000040 + iVar8 + iVar5));
        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d0975;
        fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar8 + iVar5));
code_r0x0001801d0980:
        *(undefined8 *)(&stack0x00000010 + iVar8 + iVar5) = 0x1801d098b;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_58h + iVar8 + iVar5));
        return 0;
    }
    if ((iVar4 != 8) && (iVar4 != 0x2b)) {
        *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x1801ccdf6;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar5), *(int64_t *)(&stack0x00000020 + iVar5));
        *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x1801cce0e;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar5), *(int64_t *)(&stack0x00000020 + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar5));
        *(undefined8 *)((int64_t)&iStack_10 + iVar5) = 0x1801cce24;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0;
    }
    *(undefined8 *)(&stack0x00000018 + iVar5) = *(undefined8 *)(&stack0x00000018 + iVar5);
    *(undefined8 *)(&stack0x00000010 + iVar5) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar5) = 0x1801d0c4d;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar4 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar5) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar5) = 0;
    if (in_EDX == 4) {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x60);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0c7e;
            iVar3 = (*pcVar2)();
            if (iVar3 < 0) {
                *(undefined4 *)(in_RCX + 0x68) = 4;
                return 4;
            }
            if (iVar3 == 0) {
                *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0c9c;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar5));
                *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0cb4;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                              *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar5));
                *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0cca;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5));
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0ce2;
        iVar3 = fcn.1801ce740(in_RCX);
        if (iVar3 != 0) {
            if (*(int32_t *)(in_RCX + 0xba8) == 4) {
                return 1;
            }
            return 2;
        }
    } else if (in_EDX != 5) {
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0ee0;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), *(int64_t *)(&stack0x00000038 + iVar8 + iVar5));
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0ef8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), *(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar5));
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0f0e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar5) = unaff_RBP;
    iVar7 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar5) = unaff_RSI;
    if (*(int64_t *)(iVar7 + 0x208) == 0) {
code_r0x0001801d0d41:
        pcVar2 = *(code **)(iVar7 + 200);
        if (pcVar2 != (code *)0x0) {
            uVar6 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0d5d;
            iVar4 = (*pcVar2)(uVar6, (int64_t)&arg_60h + iVar8 + iVar5, (int64_t)&arg_50h + iVar8 + iVar5);
        }
    } else {
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0d3b;
        iVar4 = fcn.1801bca70(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                              *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5), 
                              *(int64_t *)((int64_t)&arg_58h + iVar8 + iVar5), 
                              *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar5));
        if (iVar4 == 0) goto code_r0x0001801d0d41;
    }
    if (iVar4 < 0) {
        *(undefined4 *)(in_RCX + 0x68) = 4;
        return 5;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar4 == 1) {
        if ((*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5) != 0) &&
           (*(int64_t *)((int64_t)&arg_60h + iVar8 + iVar5) != 0)) {
            *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0da9;
            iVar3 = fcn.180199810(*(int64_t *)(&stack0x00000040 + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000068 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000070 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x00000078 + iVar8 + iVar5), 
                                  *(int64_t *)(&stack0x000000a8 + iVar8 + iVar5));
            if (iVar3 != 0) {
                *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0dba;
                iVar3 = fcn.180199550(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5), 
                                      *(int64_t *)(&stack0x00000068 + iVar8 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_98h + iVar8 + iVar5));
                if (iVar3 != 0) goto code_r0x0001801d0dc0;
            }
            iVar4 = 0;
            goto code_r0x0001801d0dc0;
        }
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0e20;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), *(int64_t *)(&stack0x00000038 + iVar8 + iVar5));
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0e38;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), *(int64_t *)(&stack0x00000038 + iVar8 + iVar5), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar5));
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0e4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar5));
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0e54;
        fcn.18021fe80(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar5));
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0e5e;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar5));
    } else {
code_r0x0001801d0dc0:
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0dca;
        fcn.18021fe80(*(int64_t *)(&stack0x00000038 + iVar8 + iVar5), *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar5));
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0dd4;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar5));
        if (iVar4 != 0) {
            *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0de0;
            iVar4 = fcn.1801ce740(in_RCX);
            if (iVar4 != 0) goto code_r0x0001801d0e87;
        }
    }
    if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
        *(undefined4 *)(in_RCX + 0x340) = 0;
        *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0e0a;
        fcn.1801c6e50(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), *(int64_t *)(&stack0x00000038 + iVar8 + iVar5));
        return 2;
    }
    *(undefined4 *)(in_RCX + 0x340) = 2;
    *(undefined4 *)(in_RCX + 0xb3c) = 0;
    *(undefined8 *)(&stack0x00000008 + iVar8 + iVar5) = 0x1801d0e77;
    uVar9 = fcn.1801da790(*(int64_t *)((int64_t)&arg_30h + iVar8 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar8 + iVar5), *(int64_t *)(&stack0x00000040 + iVar8 + iVar5)
                          , *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar5));
    if ((int32_t)uVar9 == 0) {
        return uVar9;
    }
code_r0x0001801d0e87:
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar4 = **(int32_t **)(in_RCX + 0x18), iVar4 < 0x304)) || (iVar4 == 0x10000)) ||
       ((*(uint64_t *)(in_RCX + 0x9a8) & 0x100000000) != 0)) {
        *(undefined4 *)(in_RCX + 0xb3c) = 0;
    }
    return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 1);
}

// ============================================================
// Function: FUN_1801cce40
// Address: 0x1801cce40
// Size: 814 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801cce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 uVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cce5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)(in_RCX + 0x108) = 0;
    iVar3 = *(int32_t *)(in_RCX + 0xac);
    uVar7 = 0;
    if (iVar3 == 0xd) {
        if ((*(int32_t *)(in_RCX + 0xf0) == 2) && (*(int32_t *)(in_RCX + 0x1538) != 0)) {
            if ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x14 & 1) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd121;
                iVar3 = func_0x0001801b2cf0();
                if (iVar3 == 0) {
                    return 0;
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd12e;
            iVar3 = func_0x00018019c050();
            if (iVar3 == 0) {
                return 4;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            return 2;
        }
        *(undefined4 *)(in_RCX + 0x9c8) = 1;
        return 2;
    }
    if (iVar3 == 0x10) {
        iVar6 = *(int64_t *)(in_RCX + 0x3b0);
        uVar5 = *(undefined8 *)(in_RCX + 0x3b8);
        uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c);
        if ((uVar1 & 0x20) == 0) {
            if ((iVar6 == 0) && ((uVar1 & 8) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd07d;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd095;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4), 
                              *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd0ab;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd0c1;
                iVar3 = func_0x0001801c6380(in_RCX, iVar6, uVar5, 1);
                if (iVar3 != 0) {
                    return 2;
                }
                iVar6 = 0;
                uVar5 = 0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd065;
            iVar3 = func_0x0001801bcbf0(in_RCX);
            if (iVar3 != 0) {
                return 2;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd0e7;
        func_0x000180224b90(iVar6, uVar5, 0x1804b3b98, 0xe86);
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
        return 0;
    }
    if (iVar3 == 0x12) {
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) {
            return 2;
        }
        if (*(int32_t *)(in_RCX + 0x8c8) == 1) {
            return 2;
        }
        if ((*(int32_t *)(in_RCX + 0xf0) == 2) && (*(int32_t *)(in_RCX + 0x1538) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ccfc2;
            iVar3 = func_0x0001801b2cf0(in_RCX, 0x52);
        } else {
            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8) = *(undefined8 *)(in_RCX + 0x300);
            if (*(undefined4 **)(in_RCX + 0x390) != (undefined4 *)0x0) {
                uVar7 = **(undefined4 **)(in_RCX + 0x390);
            }
            *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f0) = uVar7;
            pcVar2 = **(code ***)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd012;
            iVar3 = (*pcVar2)(in_RCX);
            if (iVar3 == 0) {
                return 0;
            }
            pcVar2 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cd033;
            iVar3 = (*pcVar2)(in_RCX, 0x12);
        }
    } else if (iVar3 == 0x14) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ccec2;
        iVar3 = func_0x00018019c050();
        if (iVar3 != 1) {
            return 5;
        }
        if ((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) {
            return 2;
        }
        iVar3 = **(int32_t **)(in_RCX + 0x18);
        if (iVar3 < 0x304) {
            return 2;
        }
        if (iVar3 == 0x10000) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ccf06;
        iVar3 = func_0x0001801b0080(in_RCX);
        if (iVar3 == 0) {
            return 0;
        }
        if (*(int32_t *)(in_RCX + 0xba8) == 4) {
            return 2;
        }
        pcVar2 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ccf34;
        iVar3 = (*pcVar2)(in_RCX, 0x112);
        if (iVar3 == 0) {
            return 0;
        }
        if ((*(uint32_t *)(in_RCX + 0x160) & 0x2000) == 0) {
            return 2;
        }
        pcVar2 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801ccf65;
        iVar3 = (*pcVar2)(in_RCX, 0x111);
    } else {
        if (iVar3 != 0x2f) {
            return 2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cce9d;
        iVar3 = func_0x00018019c050();
        if (iVar3 != 1) {
            return 4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cceb0;
        iVar3 = func_0x0001801b4650(in_RCX, 1);
    }
    if (iVar3 != 0) {
        return 2;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801cd170
// Address: 0x1801cd170
// Size: 349 bytes
// ============================================================
uint64_t fcn.1801cd170(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_c0h,
                      int64_t arg_c8h, int64_t arg_d0h, int64_t arg_128h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    code *pcVar11;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar12;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801cd17a;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    iVar7 = *(int32_t *)(in_RCX + 0xac);
    if (iVar7 == 1) {
        iVar7 = 1;
    } else {
        if (iVar7 == 0xd) {
            *(undefined4 *)(in_RCX + 0x84) = 0;
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                if (*(int32_t *)(in_RCX + 0xb18) == 1) {
                    *(undefined8 *)(&stack0x00000088 + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_80h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_78h + iVar10) = 0;
                    *(undefined4 *)((int64_t)&arg_70h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_68h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_60h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_58h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_50h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_48h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_38h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_30h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&arg_28h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&var_20h + iVar10) = 0;
                    *(undefined8 *)((int64_t)&uStack_8 + iVar10) = 0x1801cd2a6;
                    iVar7 = func_0x0001801a4960(in_RCX, 0x10000, 1, 0);
                    return (uint64_t)(-(uint32_t)(iVar7 != 0) & 2);
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_8 + iVar10) = 0x1801cd22b;
                uVar9 = func_0x0001801db380(in_RCX);
                if ((int32_t)uVar9 == 0) {
                    return uVar9;
                }
            }
            return 2;
        }
        if (iVar7 == 0x12) {
            if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
                return 2;
            }
            if (*(int32_t *)(in_RCX + 0x508) == 0) {
                return 2;
            }
            *(undefined4 *)(in_RCX + 200) = 0;
            return 2;
        }
        if (iVar7 != 0x32) {
            if (iVar7 != 0x33) {
                return 2;
            }
            if (*(int32_t *)(in_RCX + 0xf0) == 7) {
                return 2;
            }
            if (*(int32_t *)(in_RCX + 0xf0) == 0) {
                return 2;
            }
        }
        iVar7 = 0;
    }
    iVar12 = 1;
    *(undefined8 *)((int64_t)&arg_a8h + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_b0h + iVar10) = unaff_RBP;
    *(undefined8 *)(&stack0x00000090 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x00000088 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_80h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_78h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_70h + iVar10) = unaff_R15;
    *(undefined8 *)((int64_t)&arg_68h + iVar10) = 0x1801b08cd;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar2 = *(undefined8 *)(in_RCX + 0x40);
    iVar1 = *(int32_t *)(in_RCX + 0xc0);
    iVar3 = *(int64_t *)(in_RCX + 8);
    if (iVar7 != 0) {
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            uVar4 = *(undefined8 *)(in_RCX + 0xf8);
            *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b090c;
            func_0x000180226310(uVar4);
            *(undefined8 *)(in_RCX + 0xf8) = 0;
        }
        *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b091b;
        iVar7 = func_0x000180197630(in_RCX);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0924;
            fcn.180229480(*(int64_t *)(&stack0x00000090 + iVar8 + iVar10), 
                          *(int64_t *)(&stack0x00000098 + iVar8 + iVar10));
            *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b093c;
            fcn.1802295a0(*(int64_t *)(&stack0x00000090 + iVar8 + iVar10), 
                          *(int64_t *)(&stack0x00000098 + iVar8 + iVar10), 
                          *(int64_t *)(&stack0x000000a0 + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_c0h + iVar8 + iVar10));
            *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0952;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_b0h + iVar8 + iVar10));
            return 0;
        }
        *(undefined8 *)(in_RCX + 0x108) = 0;
    }
    piVar5 = *(int32_t **)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_c0h + iVar8 + iVar10) = unaff_RDI;
    if (((((*(uint8_t *)(*(int64_t *)(piVar5 + 0x36) + 0x50) & 8) == 0) && (iVar7 = *piVar5, 0x303 < iVar7)) &&
        (iVar7 != 0x10000)) && ((*(int32_t *)(in_RCX + 0x78) == 0 && (*(int32_t *)(in_RCX + 0xba8) == 4)))) {
        *(undefined4 *)(in_RCX + 0xba8) = 1;
    }
    if (iVar1 != 0) {
        *(undefined4 *)(in_RCX + 0xba0) = 0;
        *(undefined4 *)(in_RCX + 0x7c) = 0;
        *(undefined4 *)(in_RCX + 0xc0) = 0;
        *(undefined4 *)(in_RCX + 0xa60) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b09ea;
        func_0x0001801da740(in_RCX);
        piVar5 = *(int32_t **)(in_RCX + 0x18);
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            if ((((*(uint8_t *)(*(int64_t *)(piVar5 + 0x36) + 0x50) & 8) == 0) && (0x303 < *piVar5)) &&
               (*piVar5 != 0x10000)) {
                iVar6 = *(int64_t *)(in_RCX + 0xb88);
                if ((*(uint8_t *)(iVar6 + 0x50) & 1) != 0) {
                    uVar4 = *(undefined8 *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0a64;
                    func_0x00018019c8a0(iVar6, uVar4);
                }
            } else {
                *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0a73;
                func_0x000180198390(in_RCX, 1);
            }
            if (*(int32_t *)(in_RCX + 0x508) != 0) {
                LOCK();
                piVar5 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x9c);
                *piVar5 = *piVar5 + 1;
                UNLOCK();
            }
            *(undefined8 *)(in_RCX + 0x70) = 0x18019b570;
            LOCK();
            piVar5 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x80);
            *piVar5 = *piVar5 + 1;
            UNLOCK();
        } else {
            if ((((*(uint8_t *)(*(int64_t *)(piVar5 + 0x36) + 0x50) & 8) != 0) || (*piVar5 < 0x304)) ||
               (*piVar5 == 0x10000)) {
                *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0a1c;
                func_0x000180198390(in_RCX, 2);
            }
            LOCK();
            piVar5 = (int32_t *)(iVar3 + 0x8c);
            *piVar5 = *piVar5 + 1;
            UNLOCK();
            *(undefined8 *)(in_RCX + 0x70) = 0x18019b330;
        }
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110) = 0;
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10c) = 0;
            *(undefined2 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x10e) = 0;
            *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0ae8;
            func_0x0001801c2610(in_RCX);
        }
    }
    pcVar11 = *(code **)(in_RCX + 0x958);
    if ((pcVar11 == (code *)0x0) && (pcVar11 = *(code **)(iVar3 + 0x120), pcVar11 == (code *)0x0)) {
        *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0b5d;
        func_0x00018019b750(in_RCX, 0);
    } else {
        *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0b0a;
        func_0x00018019b750(in_RCX, 0);
        if ((((iVar1 != 0) ||
             (((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
              (iVar7 = **(int32_t **)(in_RCX + 0x18), iVar7 < 0x304)))) || (iVar7 == 0x10000)) ||
           ((*(int64_t *)(in_RCX + 0x260) == 0 || (*(int64_t *)(in_RCX + 0x2e8) == 0)))) {
            *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0b51;
            (*pcVar11)(uVar2, 0x20, 1);
        }
    }
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar10) = 0x1801b0b74;
        func_0x00018019b750(in_RCX, 1);
        uVar9 = 2;
    } else {
        uVar9 = 1;
    }
    return uVar9;
}

// ============================================================
// Function: FUN_1801cd2d0
// Address: 0x1801cd2d0
// Size: 1596 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_49h
// WARNING: [rz-ghidra] Removing arg arg_a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a10h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bh
// WARNING: [rz-ghidra] Removing arg arg_878h because it doesn't fit into ProtoModel

uint64_t fcn.1801cd2d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a0h,
                      int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h,
                      int64_t arg_d0h, int64_t arg_d8h, int64_t arg_128h, int64_t arg_188h)
{
    undefined4 *puVar1;
    int16_t *piVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    uint8_t uVar5;
    uint8_t uVar6;
    char cVar7;
    code *pcVar8;
    int32_t *piVar9;
    code **ppcVar10;
    uint16_t uVar11;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    bool bVar17;
    int32_t iVar18;
    int32_t iVar19;
    int64_t iVar20;
    int64_t iVar21;
    int64_t iVar22;
    int64_t iVar23;
    int64_t iVar24;
    uint64_t uVar25;
    int64_t iVar26;
    int64_t iVar27;
    int64_t iVar28;
    uint8_t *puVar29;
    int64_t in_RCX;
    uint8_t *puVar30;
    uint8_t **in_RDX;
    uint32_t uVar31;
    undefined4 uVar32;
    undefined8 unaff_RBP;
    uint64_t uVar33;
    undefined8 *puVar34;
    int64_t *piVar35;
    undefined8 uVar36;
    undefined8 uVar37;
    uint8_t *puVar38;
    uint8_t *puVar39;
    undefined8 unaff_R12;
    int64_t iVar40;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar41;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined8 uStack_20;
    undefined8 uStack_18;
    uint8_t *puStack_10;
    
    puStack_10 = (uint8_t *)0x1801cd2e5;
    iVar27 = fcn.18045a350();
    iVar27 = -iVar27;
    // switch table (48 cases) at 0x1801cd8a0
    switch(*(undefined4 *)(in_RCX + 0xac)) {
    case 2:
        puVar38 = in_RDX[1];
        if ((uint8_t *)0x1 < puVar38) {
            *in_RDX = *in_RDX + 2;
            in_RDX[1] = puVar38 + -2;
            puVar39 = *in_RDX;
            puVar29 = in_RDX[1];
            *(uint8_t **)((int64_t)&arg_28h + iVar27) = puVar39;
            *(uint8_t **)((int64_t)&arg_30h + iVar27) = puVar29;
            if (puVar38 + -2 != (uint8_t *)0x0) {
                uVar3 = *puVar39;
                puVar29 = (uint8_t *)(uint64_t)uVar3;
                if (puVar29 <= puVar38 + -3) {
                    *(int64_t *)((int64_t)&arg_30h + iVar27) = (int64_t)(puVar38 + -3) - (int64_t)puVar29;
                    *(uint8_t **)((int64_t)&arg_28h + iVar27) = puVar39 + 1 + (int64_t)puVar29;
                    uVar32 = *(undefined4 *)((int64_t)&arg_28h + iVar27 + 4);
                    uVar14 = *(undefined4 *)((int64_t)&arg_30h + iVar27);
                    uVar15 = *(undefined4 *)((int64_t)&arg_30h + iVar27 + 4);
                    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&arg_28h + iVar27);
                    *(undefined4 *)((int64_t)in_RDX + 4) = uVar32;
                    *(undefined4 *)(in_RDX + 1) = uVar14;
                    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar15;
                    uVar37 = *(undefined8 *)(in_RCX + 0x4f0);
                    *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd395;
                    fcn.180498030(uVar37, puVar39 + 1, uVar3);
                    *(uint8_t **)(*(int64_t *)(in_RCX + 0x4f0) + 0x100) = puVar29;
                    return 1;
                }
            }
        }
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd3bf;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd3d7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                      *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_30h + iVar27), 
                      *(int64_t *)((int64_t)&arg_48h + iVar27));
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd3ed;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar27));
        return 0;
    case 3:
        uVar37 = *(undefined8 *)((int64_t)&arg_38h + iVar27);
        *(undefined8 *)((int64_t)&arg_38h + iVar27) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)((int64_t)&arg_28h + iVar27) = *(undefined8 *)((int64_t)&arg_58h + iVar27);
        *(undefined8 *)((int64_t)&var_20h + iVar27) = uVar37;
        *(undefined8 *)((int64_t)&var_18h + iVar27) = unaff_R12;
        *(undefined8 *)((int64_t)&var_10h + iVar27) = unaff_R13;
        *(undefined8 *)((int64_t)&var_8h + iVar27) = unaff_R14;
        *(undefined8 *)(&stack0x00000000 + iVar27) = unaff_R15;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar27) = 0x1801d29fc;
        iVar26 = fcn.18045a350();
        iVar26 = -iVar26;
        uVar37 = *(undefined8 *)(in_RCX + 0x40);
        bVar17 = false;
        *(undefined8 *)((int64_t)&arg_50h + iVar27) = 0;
        puVar38 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar27 + -8) = uVar37;
        if (puVar38 < (uint8_t *)0x2) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3498;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
            goto code_r0x0001801d349d;
        }
        puVar39 = *in_RDX;
        uVar3 = *puVar39;
        puVar1 = (undefined4 *)(puVar39 + 2);
        uVar4 = puVar39[1];
        *in_RDX = (uint8_t *)puVar1;
        puVar38 = puVar38 + -2;
        in_RDX[1] = puVar38;
        if ((*(int32_t *)(in_RCX + 0x48) == 0x304) && (CONCAT11(uVar3, uVar4) == 0x303)) {
            if ((uint8_t *)0x1f < puVar38) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2a81;
                iVar18 = fcn.180497f30(0x1804af260, puVar1, 0x20);
                if (iVar18 != 0) goto code_r0x0001801d2b38;
                if (*(int32_t *)(in_RCX + 0x8c8) != 0) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2a97;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2aaf;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                    goto code_r0x0001801d34bb;
                }
                *(undefined4 *)(in_RCX + 0x8c8) = 1;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2ad3;
                iVar18 = fcn.1801a5230(in_RCX, 0x304);
                if (iVar18 != 0) {
                    bVar17 = true;
                    if (in_RDX[1] < (uint8_t *)0x20) {
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2b24;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                        goto code_r0x0001801d349d;
                    }
                    *in_RDX = *in_RDX + 0x20;
                    in_RDX[1] = in_RDX[1] + -0x20;
                    goto code_r0x0001801d2b56;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2adc;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
code_r0x0001801d2ae1:
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2af4;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                goto code_r0x0001801d34bb;
            }
code_r0x0001801d3487:
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d348c;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
code_r0x0001801d349d:
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d34b0;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
        } else {
            if (puVar38 < (uint8_t *)0x20) goto code_r0x0001801d3487;
code_r0x0001801d2b38:
            uVar32 = *(undefined4 *)(puVar39 + 6);
            uVar14 = *(undefined4 *)(puVar39 + 10);
            uVar15 = *(undefined4 *)(puVar39 + 0xe);
            *(undefined4 *)(in_RCX + 0x164) = *puVar1;
            *(undefined4 *)(in_RCX + 0x168) = uVar32;
            *(undefined4 *)(in_RCX + 0x16c) = uVar14;
            *(undefined4 *)(in_RCX + 0x170) = uVar15;
            uVar32 = *(undefined4 *)(puVar39 + 0x16);
            uVar14 = *(undefined4 *)(puVar39 + 0x1a);
            uVar15 = *(undefined4 *)(puVar39 + 0x1e);
            *(undefined4 *)(in_RCX + 0x174) = *(undefined4 *)(puVar39 + 0x12);
            *(undefined4 *)(in_RCX + 0x178) = uVar32;
            *(undefined4 *)(in_RCX + 0x17c) = uVar14;
            *(undefined4 *)(in_RCX + 0x180) = uVar15;
            *in_RDX = *in_RDX + 0x20;
            in_RDX[1] = in_RDX[1] + -0x20;
code_r0x0001801d2b56:
            puVar38 = *in_RDX;
            puVar29 = in_RDX[1];
            puVar39 = in_RDX[1];
            *(uint8_t **)((int64_t)&var_38h + iVar27) = puVar38;
            *(uint8_t **)((int64_t)&var_30h + iVar27) = puVar29;
            if (puVar39 == (uint8_t *)0x0) {
code_r0x0001801d347b:
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3480;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                goto code_r0x0001801d349d;
            }
            puVar39 = puVar39 + -1;
            puVar29 = (uint8_t *)(uint64_t)*puVar38;
            puVar38 = puVar38 + 1;
            *(uint8_t **)((int64_t)&arg_58h + iVar27) = puVar38;
            if (puVar39 < puVar29) goto code_r0x0001801d347b;
            *(uint8_t **)((int64_t)&var_38h + iVar27) = puVar29 + (int64_t)puVar38;
            *(int64_t *)((int64_t)&var_30h + iVar27) = (int64_t)puVar39 - (int64_t)puVar29;
            uVar32 = *(undefined4 *)((int64_t)&var_38h + iVar27 + 4);
            uVar14 = *(undefined4 *)((int64_t)&var_30h + iVar27);
            uVar15 = *(undefined4 *)((int64_t)&var_30h + iVar27 + 4);
            *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_38h + iVar27);
            *(undefined4 *)((int64_t)in_RDX + 4) = uVar32;
            *(undefined4 *)(in_RDX + 1) = uVar14;
            *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar15;
            if ((uint8_t *)0x20 < puVar29) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3456;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d346e;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                goto code_r0x0001801d34bb;
            }
            puVar39 = in_RDX[1];
            if (puVar39 < (uint8_t *)0x2) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d344a;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                goto code_r0x0001801d349d;
            }
            puVar30 = *in_RDX;
            *(uint8_t **)((int64_t)&arg_60h + iVar27) = puVar30;
            *in_RDX = puVar30 + 2;
            in_RDX[1] = puVar39 + -2;
            if (puVar39 + -2 == (uint8_t *)0x0) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d343e;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                goto code_r0x0001801d349d;
            }
            uVar3 = puVar30[2];
            *in_RDX = puVar30 + 3;
            puVar30 = puVar39 + -3;
            *(uint32_t *)((int64_t)&arg_48h + iVar27) = (uint32_t)uVar3;
            in_RDX[1] = puVar30;
            if ((puVar30 != (uint8_t *)0x0) || (bVar17)) {
                puVar12 = *in_RDX;
                puVar13 = in_RDX[1];
                *(uint8_t **)((int64_t)&var_38h + iVar27) = puVar12;
                *(uint8_t **)((int64_t)&var_30h + iVar27) = puVar13;
                if ((uint8_t *)0x1 < puVar30) {
                    puVar30 = (uint8_t *)(uint64_t)CONCAT11(*puVar12, puVar12[1]);
                    if (puVar30 <= puVar39 + -5) {
                        iVar20 = (int64_t)(puVar39 + -5) - (int64_t)puVar30;
                        *(uint8_t **)((int64_t)&var_38h + iVar27) = puVar12 + 2 + (int64_t)puVar30;
                        *(int64_t *)((int64_t)&var_30h + iVar27) = iVar20;
                        if (iVar20 == 0) {
                            uVar32 = *(undefined4 *)((int64_t)&var_38h + iVar27 + 4);
                            uVar14 = *(undefined4 *)((int64_t)&var_30h + iVar27);
                            uVar15 = *(undefined4 *)((int64_t)&var_30h + iVar27 + 4);
                            *(uint8_t **)((int64_t)&uStack_20 + iVar27) = puVar12 + 2;
                            *(uint8_t **)((int64_t)&uStack_18 + iVar27) = puVar30;
                            *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_38h + iVar27);
                            *(undefined4 *)((int64_t)in_RDX + 4) = uVar32;
                            *(undefined4 *)(in_RDX + 1) = uVar14;
                            *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar15;
                            if (in_RDX[1] == (uint8_t *)0x0) {
                                if (!bVar17) goto code_r0x0001801d2c67;
                                goto code_r0x0001801d2caa;
                            }
                        }
                    }
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3419;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3431;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar27) = 0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar27) = 0;
code_r0x0001801d2c67:
                *(undefined4 *)((int64_t)&arg_28h + iVar26 + iVar27) = 1;
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2c87;
                iVar18 = fcn.1801c9450(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27), 
                                       *(int64_t *)(&stack0x00000098 + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_a0h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_a8h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_b0h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_b8h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_c0h + iVar26 + iVar27));
                if (iVar18 == 0) goto code_r0x0001801d34c6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2c9e;
                iVar18 = fcn.1801af2b0(*(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27));
                if (iVar18 == 0) goto code_r0x0001801d34c6;
                puVar38 = *(uint8_t **)((int64_t)&arg_58h + iVar27);
code_r0x0001801d2caa:
                piVar9 = *(int32_t **)(in_RCX + 0x18);
                uVar31 = *(uint32_t *)(*(int64_t *)(piVar9 + 0x36) + 0x50) & 8;
                if ((((uVar31 == 0) && (0x303 < *piVar9)) && (*piVar9 != 0x10000)) || (bVar17)) {
                    if (*(int32_t *)((int64_t)&arg_48h + iVar27) == 0) {
                        if (puVar29 == *(uint8_t **)(in_RCX + 0x940)) {
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2d2b;
                            iVar18 = fcn.180497f30(puVar38, in_RCX + 0x920, puVar29);
                            if (iVar18 == 0) {
                                iVar18 = 0;
                                if (bVar17) {
                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2d48;
                                    iVar18 = fcn.1801ce270(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27));
                                    if (iVar18 != 0) {
                                        iVar18 = *(int32_t *)(in_RCX + 0xf0);
                                        *(undefined8 *)((int64_t)&arg_48h + iVar27) = 0;
                                        if (iVar18 == 7) {
                                            *(undefined8 *)((int64_t)&arg_88h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_80h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_78h + iVar26 + iVar27) = 0;
                                            *(undefined4 *)((int64_t)&arg_70h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_68h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_60h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_58h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_50h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_48h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_40h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_38h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&arg_28h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2dbd;
                                            iVar18 = fcn.1801a4960(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_80h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27), 
                                                                   *(int64_t *)(&stack0x00000098 + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_a0h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_a8h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_b0h + iVar26 + iVar27));
                                            if (iVar18 == 0) goto code_r0x0001801d2ec9;
                                        }
                                        uVar37 = *(undefined8 *)(in_RCX + 0xc80);
                                        pcVar8 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0x60);
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2ddf;
                                        (*pcVar8)(uVar37, 0x304);
                                        *(undefined4 *)((int64_t)&arg_28h + iVar26 + iVar27) = 1;
                                        *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2dff;
                                        iVar18 = fcn.1801c9450(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27), 
                                                               *(int64_t *)(&stack0x00000098 + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_a0h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_a8h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_b0h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_b8h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_c0h + iVar26 + iVar27));
                                        if (iVar18 != 0) {
                                            iVar20 = *(int64_t *)((int64_t)&arg_48h + iVar27);
                                            *(undefined4 *)((int64_t)&arg_28h + iVar26 + iVar27) = 1;
                                            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2e25;
                                            iVar18 = fcn.1801c9b70(in_RCX, 0x800, iVar20, 0, 
                                                                   *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
                                            if (iVar18 != 0) {
                                                uVar37 = *(undefined8 *)((int64_t)&arg_48h + iVar27);
                                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                     0x1801d2e43;
                                                fcn.180224990(uVar37, 0x1804b3b98, 0x74d);
                                                *(undefined8 *)((int64_t)&arg_48h + iVar27) = 0;
                                                if ((*(int64_t *)(in_RCX + 0xb28) == 0) &&
                                                   (*(int64_t *)(in_RCX + 0x308) != 0)) {
                                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                         0x1801d2e5e;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                                  *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                         0x1801d2e76;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                                  *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                                  *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                         0x1801d2e8c;
                                                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27));
                                                } else {
                                                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                         0x1801d2ea3;
                                                    iVar18 = fcn.1801ae390(*(int64_t *)
                                                                            ((int64_t)&arg_50h + iVar26 + iVar27), 
                                                                           *(int64_t *)
                                                                            ((int64_t)&arg_a0h + iVar26 + iVar27), 
                                                                           *(int64_t *)
                                                                            ((int64_t)&arg_a8h + iVar26 + iVar27));
                                                    if (iVar18 != 0) {
                                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                             0x1801d2ec5;
                                                        iVar18 = fcn.1801dac70(*(int64_t *)
                                                                                ((int64_t)&var_20h + iVar26 + iVar27));
                                                        if (iVar18 != 0) {
                                                            return 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
code_r0x0001801d2ec9:
                                        uVar37 = *(undefined8 *)((int64_t)&arg_48h + iVar27);
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2edf;
                                        fcn.180224990(uVar37, 0x1804b3b98, 0x770);
                                        return 0;
                                    }
                                    goto code_r0x0001801d34c6;
                                }
                                goto code_r0x0001801d2f1b;
                            }
                        }
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2eef;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2f07;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                    } else {
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2ce4;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2cfc;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                    }
                } else {
                    iVar18 = *(int32_t *)((int64_t)&arg_48h + iVar27);
code_r0x0001801d2f1b:
                    if (((uVar31 != 0) || (*piVar9 < 0x304)) || (uVar37 = 0x200, *piVar9 == 0x10000)) {
                        uVar37 = 0x100;
                    }
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2f4a;
                    iVar19 = fcn.1801ca4d0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27));
                    if (iVar19 == 0) {
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2f53;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2f6b;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                    } else {
                        *(undefined4 *)(in_RCX + 0x508) = 0;
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                            (iVar19 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar19)) && (iVar19 != 0x10000)) {
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2fb0;
                            iVar19 = fcn.1801a2f70(in_RCX + 0xc50);
                            if (iVar19 != 0) {
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2fb9;
                                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2fd1;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                                goto code_r0x0001801d34bb;
                            }
                            *(undefined8 *)((int64_t)&arg_28h + iVar26 + iVar27) = 0;
                            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3002;
                            iVar19 = fcn.1801c9d00(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
                            if (iVar19 == 0) goto code_r0x0001801d34c6;
                        } else {
                            if (((0x300 < *(int32_t *)(in_RCX + 0x48)) &&
                                (pcVar8 = *(code **)(in_RCX + 0xae0), pcVar8 != (code *)0x0)) &&
                               (iVar20 = *(int64_t *)(in_RCX + 0x8f8), *(int64_t *)(iVar20 + 800) != 0)) {
                                uVar36 = *(undefined8 *)((int64_t)&uStack_20 + iVar27 + -8);
                                *(undefined8 *)((int64_t)&arg_28h + iVar26 + iVar27) = *(undefined8 *)(in_RCX + 0xae8);
                                *(undefined8 *)((int64_t)&var_38h + iVar27) = 0;
                                *(int64_t *)((int64_t)&var_20h + iVar26 + iVar27) = (int64_t)&var_38h + iVar27;
                                *(undefined4 *)((int64_t)&arg_48h + iVar27) = 0x200;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d306e;
                                iVar19 = (*pcVar8)(uVar36, iVar20 + 0x50, (int64_t)&arg_48h + iVar27);
                                if ((iVar19 == 0) || (*(int32_t *)((int64_t)&arg_48h + iVar27) < 1)) {
                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3158;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                                    goto code_r0x0001801d2ae1;
                                }
                                *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 8) =
                                     (int64_t)*(int32_t *)((int64_t)&arg_48h + iVar27);
                                iVar20 = *(int64_t *)((int64_t)&var_38h + iVar27);
                                if (iVar20 == 0) {
                                    uVar36 = *(undefined8 *)((int64_t)&arg_60h + iVar27);
                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d30a8;
                                    iVar20 = fcn.1801a0300(in_RCX, uVar36, 0);
                                }
                                *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8) = iVar20;
                            }
                            if ((puVar29 != (uint8_t *)0x0) &&
                               (iVar20 = *(int64_t *)(in_RCX + 0x8f8), puVar29 == *(uint8_t **)(iVar20 + 0x250))) {
                                uVar36 = *(undefined8 *)((int64_t)&arg_58h + iVar27);
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d30de;
                                iVar19 = fcn.180497f30(uVar36, iVar20 + 600, puVar29);
                                if (iVar19 == 0) {
                                    *(undefined4 *)(in_RCX + 0x508) = 1;
                                }
                            }
                        }
                        iVar20 = *(int64_t *)(in_RCX + 0x8f8);
                        if (*(int32_t *)(in_RCX + 0x508) == 0) {
                            if (*(int64_t *)(iVar20 + 0x250) != 0) {
                                LOCK();
                                piVar9 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x90);
                                *piVar9 = *piVar9 + 1;
                                UNLOCK();
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3186;
                                iVar19 = fcn.18019d4c0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27));
                                if (iVar19 == 0) goto code_r0x0001801d34c6;
                            }
                            **(undefined4 **)(int64_t *)(in_RCX + 0x8f8) = *(undefined4 *)(in_RCX + 0x48);
                            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                                (iVar19 = **(int32_t **)(in_RCX + 0x18), iVar19 < 0x304)) || (iVar19 == 0x10000)) {
                                *(uint8_t **)(*(int64_t *)(in_RCX + 0x8f8) + 0x250) = puVar29;
                                if (puVar29 != (uint8_t *)0x0) {
                                    iVar20 = *(int64_t *)(in_RCX + 0x8f8);
                                    uVar36 = *(undefined8 *)((int64_t)&arg_58h + iVar27);
                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d31ef;
                                    fcn.180498030(iVar20 + 600, uVar36, puVar29);
                                }
                            }
code_r0x0001801d31f1:
                            iVar20 = 0;
                            iVar19 = *(int32_t *)(in_RCX + 0x48);
                            if (iVar19 == **(int32_t **)(in_RCX + 0x8f8)) {
                                *(int32_t *)(in_RCX + 0x418) = iVar19;
                                *(int32_t *)(in_RCX + 0x41c) = iVar19;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3240;
                                iVar19 = fcn.1801ce270(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27));
                                if (iVar19 == 0) goto code_r0x0001801d34c6;
                                if ((*(int32_t *)(in_RCX + 0x508) == 0) ||
                                   (iVar18 == (*(int32_t **)(in_RCX + 0x8f8))[0xbc])) {
                                    if (iVar18 == 0) {
code_r0x0001801d3296:
                                        iVar40 = *(int64_t *)((int64_t)&arg_50h + iVar27);
                                        *(undefined4 *)((int64_t)&arg_28h + iVar26 + iVar27) = 1;
                                        *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                                        *(int64_t *)(in_RCX + 0x390) = iVar20;
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d32b9;
                                        iVar18 = fcn.1801c9b70(in_RCX, uVar37, iVar40, 0, 
                                                               *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
                                        if (iVar18 != 0) {
                                            ppcVar10 = *(code ***)(*(int32_t **)(in_RCX + 0x18) + 0x36);
                                            if ((((*(uint8_t *)(ppcVar10 + 10) & 8) != 0) ||
                                                (iVar18 = **(int32_t **)(in_RCX + 0x18), iVar18 < 0x304)) ||
                                               (iVar18 == 0x10000)) {
code_r0x0001801d3372:
                                                uVar37 = *(undefined8 *)((int64_t)&arg_50h + iVar27);
                                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                     0x1801d3388;
                                                fcn.180224990(uVar37, 0x1804b3b98, 0x728);
                                                return 3;
                                            }
                                            pcVar8 = *ppcVar10;
                                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d32f6;
                                            iVar18 = (*pcVar8)(in_RCX);
                                            if (iVar18 != 0) {
                                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                     0x1801d3306;
                                                iVar18 = fcn.1801b4590(*(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27)
                                                                      );
                                                if (iVar18 != 0) {
                                                    if (((*(uint32_t *)(in_RCX + 0x160) & 0x2000) != 0) ||
                                                       ((*(int32_t *)(in_RCX + 0xf0) == 0 &&
                                                        ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x14 & 1) == 0)))) {
                                                        pcVar8 = *(code **)(*(int64_t *)
                                                                             (*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x10
                                                                           );
                                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                             0x1801d3349;
                                                        iVar18 = (*pcVar8)(in_RCX, 0x92);
                                                        if (iVar18 == 0) goto code_r0x0001801d34c6;
                                                    }
                                                    pcVar8 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8)
                                                                       + 0x10);
                                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) =
                                                         0x1801d336a;
                                                    iVar18 = (*pcVar8)(in_RCX, 0x91);
                                                    if (iVar18 != 0) goto code_r0x0001801d3372;
                                                }
                                            }
                                        }
                                        goto code_r0x0001801d34c6;
                                    }
                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d339a;
                                    iVar19 = fcn.1801af1c0(in_RCX);
                                    if (iVar19 == 0) {
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d33a3;
                                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d33bb;
                                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                                    } else {
                                        uVar36 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x118);
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d33de;
                                        iVar20 = fcn.18019e430(uVar36, iVar18);
                                        if (iVar20 != 0) goto code_r0x0001801d3296;
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d33ec;
                                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3404;
                                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                                    }
                                } else {
                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3262;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d327a;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                  *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                                }
                            } else {
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3200;
                                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3218;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                            }
                        } else {
                            if (*(int64_t *)(in_RCX + 0x8d0) == *(int64_t *)(iVar20 + 0x278)) {
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d311e;
                                iVar19 = fcn.180497f30(iVar20 + 0x280, in_RCX + 0x8d8);
                                if (iVar19 == 0) goto code_r0x0001801d31f1;
                            }
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d312b;
                            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d3143;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                        }
                    }
                }
            }
        }
code_r0x0001801d34bb:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d34c6;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27));
code_r0x0001801d34c6:
        uVar37 = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d34dc;
        fcn.180224990(uVar37, 0x1804b3b98, 0x72b);
        return 0;
    case 4:
        uVar37 = *(undefined8 *)((int64_t)&arg_58h + iVar27);
        uVar36 = *(undefined8 *)((int64_t)&arg_38h + iVar27);
        *(undefined8 *)((int64_t)&arg_38h + iVar27) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)((int64_t)&arg_28h + iVar27) = uVar36;
        *(undefined8 *)((int64_t)&var_20h + iVar27) = unaff_R14;
        *(undefined8 *)((int64_t)&var_18h + iVar27) = 0x1801d24e3;
        iVar26 = fcn.18045a350();
        iVar26 = -iVar26;
        uVar25 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar27 + -8) = *(undefined8 *)(in_RCX + 8);
        cVar7 = *(char *)(in_RCX + 0xb52);
        *(undefined8 *)((int64_t)&arg_48h + iVar27) = 0;
        if (cVar7 == '\x02') {
            *(undefined8 *)((int64_t)&arg_58h + iVar27) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2517;
            iVar18 = fcn.1801b2020(*(int64_t *)((int64_t)&arg_80h + iVar26 + iVar27), 
                                   *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27), 
                                   *(int64_t *)(&stack0x00000098 + iVar26 + iVar27));
            if (iVar18 != 0) {
                if (*(int64_t *)((int64_t)&arg_58h + iVar27) == 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2526;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
                    *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d253e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27));
                    *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2554;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
                    return 0;
                }
                uVar37 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2574;
                fcn.18022ecc0(uVar37);
                uVar25 = 2;
                *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = *(undefined8 *)((int64_t)&arg_58h + iVar27);
            }
            return uVar25;
        }
        *(undefined8 *)((int64_t)&arg_c8h + iVar26 + iVar27) = uVar37;
        *(undefined8 *)((int64_t)&arg_90h + iVar26 + iVar27) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_88h + iVar26 + iVar27) = unaff_R13;
        *(undefined8 *)((int64_t)&arg_80h + iVar26 + iVar27) = unaff_R15;
        if (cVar7 != '\0') {
            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d25b9;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d25d1;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27));
            goto code_r0x0001801d297f;
        }
        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d25e6;
        iVar20 = fcn.180221f20();
        *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = iVar20;
        if (iVar20 == 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d25fe;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
code_r0x0001801d2603:
            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2616;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27));
            goto code_r0x0001801d297f;
        }
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)) && (iVar18 != 0x10000)) {
            if (in_RDX[1] != (uint8_t *)0x0) {
                uVar3 = **in_RDX;
                *in_RDX = *in_RDX + 1;
                in_RDX[1] = in_RDX[1] + -1;
                if (uVar3 == 0) goto code_r0x0001801d2670;
            }
        } else {
code_r0x0001801d2670:
            if ((uint8_t *)0x2 < in_RDX[1]) {
                puVar38 = *in_RDX;
                puVar39 = in_RDX[1] + -3;
                uVar3 = *puVar38;
                uVar4 = puVar38[1];
                uVar5 = puVar38[2];
                *in_RDX = puVar38 + 3;
                in_RDX[1] = puVar39;
                if ((puVar39 == (uint8_t *)(uint64_t)CONCAT21(CONCAT11(uVar3, uVar4), uVar5)) &&
                   (puVar39 != (uint8_t *)0x0)) {
                    while ((uint8_t *)0x2 < puVar39) {
                        puVar29 = *in_RDX;
                        puVar39 = puVar39 + -3;
                        puVar38 = puVar29 + 3;
                        uVar31 = (uint32_t)CONCAT21(CONCAT11(*puVar29, puVar29[1]), puVar29[2]);
                        *in_RDX = puVar38;
                        puVar29 = (uint8_t *)(uint64_t)uVar31;
                        in_RDX[1] = puVar39;
                        if (puVar39 < puVar29) break;
                        *(uint8_t **)((int64_t)&arg_60h + iVar27) = puVar38;
                        *in_RDX = puVar38 + uVar31;
                        in_RDX[1] = puVar39 + -(int64_t)puVar29;
                        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2722;
                        iVar20 = fcn.18021ff10(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
                        *(int64_t *)((int64_t)&arg_48h + iVar27) = iVar20;
                        if (iVar20 == 0) {
                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d292b;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2943;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27));
                            goto code_r0x0001801d297f;
                        }
                        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d273f;
                        iVar20 = fcn.18021fff0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_a8h + iVar26 + iVar27));
                        if (iVar20 == 0) {
                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2901;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2919;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27));
                            goto code_r0x0001801d297f;
                        }
                        if (*(uint8_t **)((int64_t)&arg_60h + iVar27) != puVar38 + (int64_t)puVar29) {
                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d28dc;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
                            goto code_r0x0001801d28e1;
                        }
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                            (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)) && (iVar18 != 0x10000)) {
                            puVar39 = *in_RDX;
                            puVar29 = in_RDX[1];
                            puVar38 = in_RDX[1];
                            *(undefined8 *)((int64_t)&arg_58h + iVar27) = 0;
                            *(uint8_t **)((int64_t)&uStack_20 + iVar27) = puVar39;
                            *(uint8_t **)((int64_t)&uStack_18 + iVar27) = puVar29;
                            if ((uint8_t *)0x1 < puVar38) {
                                puVar38 = puVar38 + -2;
                                puVar29 = (uint8_t *)(uint64_t)CONCAT11(*puVar39, puVar39[1]);
                                if (puVar29 <= puVar38) {
                                    *(uint8_t **)((int64_t)&puStack_10 + iVar27) = puVar39 + 2;
                                    *(uint8_t **)((int64_t)&uStack_20 + iVar27) = puVar39 + 2 + (int64_t)puVar29;
                                    *(int64_t *)((int64_t)&uStack_18 + iVar27) = (int64_t)puVar38 - (int64_t)puVar29;
                                    uVar32 = *(undefined4 *)((int64_t)&uStack_20 + iVar27);
                                    uVar14 = *(undefined4 *)((int64_t)&uStack_20 + iVar27 + 4);
                                    uVar15 = *(undefined4 *)((int64_t)&uStack_18 + iVar27);
                                    uVar16 = *(undefined4 *)((int64_t)&uStack_18 + iVar27 + 4);
                                    *(uint8_t **)(&stack0xfffffffffffffff8 + iVar27) = puVar29;
                                    *(uint32_t *)((int64_t)&arg_48h + iVar26 + iVar27) = (uint32_t)(uVar25 == 0);
                                    *(undefined8 *)((int64_t)&arg_40h + iVar26 + iVar27) = 0;
                                    *(undefined4 *)in_RDX = uVar32;
                                    *(undefined4 *)((int64_t)in_RDX + 4) = uVar14;
                                    *(undefined4 *)(in_RDX + 1) = uVar15;
                                    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar16;
                                    *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2806;
                                    iVar18 = fcn.1801c9450(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_b0h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_b8h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_c0h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_c8h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_d0h + iVar26 + iVar27), 
                                                           *(int64_t *)((int64_t)&arg_d8h + iVar26 + iVar27), 
                                                           *(int64_t *)(&stack0x000000e0 + iVar26 + iVar27));
                                    if (iVar18 != 0) {
                                        iVar20 = *(int64_t *)((int64_t)&arg_48h + iVar27);
                                        iVar40 = *(int64_t *)((int64_t)&arg_58h + iVar27);
                                        *(uint32_t *)((int64_t)&arg_48h + iVar26 + iVar27) =
                                             (uint32_t)(in_RDX[1] == (uint8_t *)0x0);
                                        *(uint64_t *)((int64_t)&arg_40h + iVar26 + iVar27) = uVar25;
                                        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2832;
                                        iVar18 = fcn.1801c9b70(in_RCX, 0x1000, iVar40, iVar20, 
                                                               *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_80h + iVar26 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27));
                                        if (iVar18 != 0) {
                                            uVar37 = *(undefined8 *)((int64_t)&arg_58h + iVar27);
                                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d284c;
                                            fcn.180224990(uVar37, 0x1804b3b98, 0x814);
                                            goto code_r0x0001801d284c;
                                        }
                                    }
                                    uVar37 = *(undefined8 *)((int64_t)&arg_58h + iVar27);
                                    *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d289b;
                                    fcn.180224990(uVar37, 0x1804b3b98, 0x810);
                                    goto code_r0x0001801d298a;
                                }
                            }
                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d28a5;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d28bd;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27));
                            goto code_r0x0001801d297f;
                        }
code_r0x0001801d284c:
                        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2863;
                        iVar18 = fcn.180222110(*(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
                        if (iVar18 == 0) {
                            *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d28cd;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
                            goto code_r0x0001801d2603;
                        }
                        puVar39 = in_RDX[1];
                        uVar25 = uVar25 + 1;
                        *(undefined8 *)((int64_t)&arg_48h + iVar27) = 0;
                        if (puVar39 == (uint8_t *)0x0) {
                            return 2;
                        }
                    }
                    *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2950;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
code_r0x0001801d28e1:
                    *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d28f4;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27));
                    goto code_r0x0001801d297f;
                }
            }
        }
        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d295c;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2974;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27));
code_r0x0001801d297f:
        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d298a;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
code_r0x0001801d298a:
        uVar37 = *(undefined8 *)((int64_t)&arg_48h + iVar27);
        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d2993;
        fcn.18021fe80(uVar37);
        uVar37 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
        *(undefined8 *)((int64_t)&var_18h + iVar26 + iVar27) = 0x1801d29a6;
        fcn.180238640(uVar37);
        *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
        return 0;
    default:
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd860;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd878;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                      *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_30h + iVar27), 
                      *(int64_t *)((int64_t)&arg_48h + iVar27));
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd88e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar27));
        return 0;
    case 6:
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd43c;
        iVar18 = fcn.1801d0f20(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                               *(int64_t *)((int64_t)&arg_28h + iVar27));
        return (uint64_t)(-(uint32_t)(iVar18 != 0) & 3);
    case 7:
        uVar37 = *(undefined8 *)((int64_t)&arg_38h + iVar27);
        *(undefined8 *)((int64_t)&arg_60h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)((int64_t)&arg_38h + iVar27) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar27) = *(undefined8 *)((int64_t)&arg_58h + iVar27);
        *(undefined8 *)((int64_t)&arg_28h + iVar27) = uVar37;
        *(undefined8 *)((int64_t)&var_20h + iVar27) = unaff_R12;
        *(undefined8 *)((int64_t)&var_18h + iVar27) = unaff_R13;
        *(undefined8 *)((int64_t)&var_10h + iVar27) = unaff_R14;
        *(undefined8 *)((int64_t)&var_8h + iVar27) = unaff_R15;
        *(undefined8 *)(&stack0x00000000 + iVar27) = 0x1801d17da;
        iVar40 = fcn.18045a350();
        iVar40 = -iVar40;
        iVar26 = *(int64_t *)(in_RCX + 0x300);
        iVar20 = *(int64_t *)(in_RCX + 8);
        uVar32 = *(undefined4 *)in_RDX;
        uVar14 = *(undefined4 *)((int64_t)in_RDX + 4);
        uVar15 = *(undefined4 *)(in_RDX + 1);
        uVar16 = *(undefined4 *)((int64_t)in_RDX + 0xc);
        uVar37 = *(undefined8 *)(in_RCX + 0x4e0);
        *(undefined8 *)((int64_t)&arg_b0h + iVar40 + iVar27) = 0;
        iVar28 = 0;
        uVar31 = *(uint32_t *)(iVar26 + 0x1c);
        *(undefined8 *)((int64_t)&arg_a8h + iVar40 + iVar27) = 0;
        *(int64_t *)((int64_t)&arg_b8h + iVar40 + iVar27) = iVar20;
        *(undefined4 *)((int64_t)&arg_58h + iVar40 + iVar27) = uVar32;
        *(undefined4 *)((int64_t)&arg_58h + iVar40 + iVar27 + 4) = uVar14;
        *(undefined4 *)((int64_t)&arg_60h + iVar40 + iVar27) = uVar15;
        *(undefined4 *)((int64_t)&arg_60h + iVar40 + iVar27 + 4) = uVar16;
        *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1823;
        fcn.18022ecc0(uVar37);
        *(undefined8 *)(in_RCX + 0x4e0) = 0;
        if ((uVar31 & 0x1c8) != 0) {
            puVar39 = *in_RDX;
            puVar29 = in_RDX[1];
            puVar38 = in_RDX[1];
            *(uint8_t **)((int64_t)&arg_48h + iVar40 + iVar27) = puVar39;
            *(uint8_t **)((int64_t)&arg_50h + iVar40 + iVar27) = puVar29;
            if ((uint8_t *)0x1 < puVar38) {
                puVar38 = puVar38 + -2;
                puVar29 = (uint8_t *)(uint64_t)CONCAT11(*puVar39, puVar39[1]);
                if (puVar29 <= puVar38) {
                    *(uint8_t **)((int64_t)&arg_48h + iVar40 + iVar27) = puVar39 + 2 + (int64_t)puVar29;
                    *(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27) = (int64_t)puVar38 - (int64_t)puVar29;
                    uVar32 = *(undefined4 *)((int64_t)&arg_48h + iVar40 + iVar27 + 4);
                    uVar14 = *(undefined4 *)((int64_t)&arg_50h + iVar40 + iVar27);
                    uVar15 = *(undefined4 *)((int64_t)&arg_50h + iVar40 + iVar27 + 4);
                    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&arg_48h + iVar40 + iVar27);
                    *(undefined4 *)((int64_t)in_RDX + 4) = uVar32;
                    *(undefined4 *)(in_RDX + 1) = uVar14;
                    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar15;
                    if (puVar29 < (uint8_t *)0x101) {
                        iVar26 = *(int64_t *)(in_RCX + 0x8f8);
                        uVar37 = *(undefined8 *)(iVar26 + 0x2a0);
                        if (puVar29 == (uint8_t *)0x0) {
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d18e8;
                            fcn.180224990(uVar37, 0x1804b3b98, 0x8b1);
                            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2a0) = 0;
                        } else {
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1910;
                            fcn.180224990(uVar37, 0x1804a9450, 0x1f6);
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1928;
                            iVar20 = fcn.180223270(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                            *(int64_t *)(iVar26 + 0x2a0) = iVar20;
                            if (iVar20 == 0) {
                                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1939;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1951;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                                goto code_r0x0001801d1def;
                            }
                        }
                        iVar20 = *(int64_t *)((int64_t)&arg_b8h + iVar40 + iVar27);
                        goto code_r0x0001801d1994;
                    }
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d189b;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d18b3;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                    iVar28 = 0;
                    goto code_r0x0001801d1def;
                }
            }
            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1966;
            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                          *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
code_r0x0001801d1972:
            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d197e;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                          *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                          *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                          *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
            goto code_r0x0001801d1def;
        }
code_r0x0001801d1994:
        if ((uVar31 & 0x48) == 0) {
            if ((uVar31 & 0x20) == 0) {
                if ((uVar31 & 0x102) == 0) {
                    if ((uVar31 & 0x84) == 0) {
                        if (uVar31 != 0) {
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1d55;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1d6d;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                            goto code_r0x0001801d1def;
                        }
                        goto code_r0x0001801d1d7a;
                    }
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d19f3;
                    iVar18 = fcn.1801d3990(*(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_48h + iVar40 + iVar27));
                } else {
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d19d4;
                    iVar18 = fcn.1801d3500(*(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_70h + iVar40 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_78h + iVar40 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_90h + iVar40 + iVar27));
                }
            } else {
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d19b7;
                iVar18 = fcn.1801d3bf0(*(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_48h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
            }
            iVar26 = 0;
            if (iVar18 == 0) goto code_r0x0001801d1dfa;
            iVar21 = *(int64_t *)((int64_t)&arg_a8h + iVar40 + iVar27);
            if (iVar21 == 0) goto code_r0x0001801d1d7a;
            uVar25 = *(uint64_t *)((int64_t)&arg_60h + iVar40 + iVar27);
            puVar38 = in_RDX[1];
            *(undefined8 *)((int64_t)&arg_a8h + iVar40 + iVar27) = 0;
            uVar33 = uVar25 - (int64_t)puVar38;
            if ((uVar25 < uVar33) || (0x7fffffffffffffff < uVar33)) {
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1d29;
                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1d41;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
            } else if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1b28;
                iVar18 = fcn.1801ac160(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                if (iVar18 != 0) goto code_r0x0001801d1aa9;
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1b35;
                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1b4d;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
            } else if (puVar38 < (uint8_t *)0x2) {
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1afa;
                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1b12;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
            } else {
                *in_RDX = *in_RDX + 2;
                in_RDX[1] = puVar38 + -2;
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1aa1;
                iVar18 = fcn.1801a98b0(*(int64_t *)((int64_t)&arg_48h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27));
                iVar26 = iVar28;
                if (iVar18 < 1) goto code_r0x0001801d1dfa;
code_r0x0001801d1aa9:
                uVar37 = *(undefined8 *)(in_RCX + 0x400);
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1ac0;
                iVar18 = fcn.1801ab730(iVar20, uVar37, (int64_t)&arg_a8h + iVar40 + iVar27);
                if (iVar18 == 0) {
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1acd;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1ae5;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                } else {
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1b6a;
                    iVar18 = fcn.1801b4960(in_RDX, (int64_t)&arg_48h + iVar40 + iVar27);
                    if ((iVar18 == 0) || (in_RDX[1] != (uint8_t *)0x0)) {
                        *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1d13;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                        goto code_r0x0001801d1972;
                    }
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1b81;
                    iVar28 = fcn.180215470();
                    if (iVar28 == 0) {
                        *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1b8e;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                    } else {
                        if (*(int64_t *)((int64_t)&arg_a8h + iVar40 + iVar27) != 0) {
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1bcc;
                            fcn.18020f750();
                        }
                        uVar37 = *(undefined8 *)(iVar20 + 0x460);
                        *(undefined8 *)((int64_t)&arg_38h + iVar40 + iVar27) = 0;
                        *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27) = iVar21;
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = uVar37;
                        *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1bfe;
                        iVar18 = fcn.18025cbd0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_48h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_90h + iVar40 + iVar27));
                        if (iVar18 < 1) {
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1c07;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                        } else {
                            if ((*(int64_t *)(in_RCX + 0x400) == 0) ||
                               (*(int32_t *)(*(int64_t *)(in_RCX + 0x400) + 0x1c) != 0x390)) {
code_r0x0001801d1c5e:
                                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1c74;
                                iVar20 = fcn.1801ae2b0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27));
                                iVar26 = iVar28;
                                if (iVar20 == 0) goto code_r0x0001801d1dfa;
                                *(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27) = iVar20;
                                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1c9c;
                                iVar18 = fcn.18025c530(*(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_48h + iVar40 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1cb8;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_b8h + iVar40 + iVar27), 0x1804b3b98, 0xa06);
                                if (0 < iVar18) {
                                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1cf1;
                                    fcn.180215310(iVar28);
                                    return 3;
                                }
                                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1cc1;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1cd9;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                                goto code_r0x0001801d1def;
                            }
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1c35;
                            iVar18 = fcn.18025dd20(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27));
                            if (0 < iVar18) {
                                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1c4b;
                                iVar18 = fcn.18025de80(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27));
                                if (0 < iVar18) goto code_r0x0001801d1c5e;
                            }
                            *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1c54;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                        }
                    }
                    *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1ba6;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                }
            }
        } else {
code_r0x0001801d1d7a:
            if (((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20) & 0x44) == 0) && ((uVar31 & 0x1c8) == 0)) {
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1d94;
                iVar18 = fcn.1801ce590(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                iVar26 = iVar28;
                if (iVar18 == 0) goto code_r0x0001801d1dfa;
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1d9d;
                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1db5;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
            } else {
                if (in_RDX[1] == (uint8_t *)0x0) {
                    return 3;
                }
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1dcc;
                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27));
                *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1de4;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_40h + iVar40 + iVar27), 
                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
            }
        }
code_r0x0001801d1def:
        *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1dfa;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_48h + iVar40 + iVar27));
        iVar26 = iVar28;
code_r0x0001801d1dfa:
        *(undefined8 *)(&stack0x00000000 + iVar40 + iVar27) = 0x1801d1e02;
        fcn.180215310(iVar26);
        return 0;
    case 8:
        uVar37 = *(undefined8 *)((int64_t)&arg_38h + iVar27);
        *(undefined8 *)((int64_t)&arg_38h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)((int64_t)&arg_30h + iVar27) = *(undefined8 *)((int64_t)&arg_58h + iVar27);
        *(undefined8 *)((int64_t)&arg_28h + iVar27) = 0x1801d120d;
        iVar40 = fcn.18045a350();
        iVar40 = -iVar40;
        iVar26 = *(int64_t *)(in_RCX + 0x408);
        iVar20 = *(int64_t *)(in_RCX + 0x118);
        if (iVar26 == 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1254;
            uVar36 = fcn.180224e40(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27));
            *(undefined8 *)(in_RCX + 0x408) = uVar36;
        } else {
            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1238;
            fcn.1804986e0(iVar26, 0, iVar20 * 4);
        }
        iVar26 = *(int64_t *)(in_RCX + 0x408);
        *(undefined8 *)((int64_t)&arg_a8h + iVar40 + iVar27) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_b0h + iVar40 + iVar27) = uVar37;
        *(undefined8 *)((int64_t)&arg_80h + iVar40 + iVar27) = unaff_R14;
        if (iVar26 == 0) {
            return 0;
        }
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)) && (iVar18 != 0x10000)) {
            uVar3 = *(uint8_t *)(in_RCX + 0x84);
            *(undefined8 *)((int64_t)&arg_a0h + iVar40 + iVar27) = 0;
            if ((uVar3 & 1) != 0) {
                return 1;
            }
            uVar37 = *(undefined8 *)(in_RCX + 0x348);
            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d12dd;
            fcn.180224990(uVar37, 0x1804b3b98, 0xa40);
            uVar37 = *(undefined8 *)(in_RCX + 0xbb0);
            *(undefined8 *)(in_RCX + 0x348) = 0;
            *(undefined8 *)(in_RCX + 0x350) = 0;
            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1304;
            fcn.180224990(uVar37, 0x1804b3b98, 0xa43);
            *(undefined8 *)(in_RCX + 0xbb0) = 0;
            *(undefined8 *)(in_RCX + 3000) = 0;
            puVar39 = *in_RDX;
            puVar29 = in_RDX[1];
            puVar38 = in_RDX[1];
            *(uint8_t **)((int64_t)&arg_60h + iVar40 + iVar27) = puVar39;
            *(uint8_t **)((int64_t)&arg_68h + iVar40 + iVar27) = puVar29;
            if (puVar38 != (uint8_t *)0x0) {
                puVar38 = puVar38 + -1;
                puVar29 = (uint8_t *)(uint64_t)*puVar39;
                if (puVar29 <= puVar38) {
                    *(uint8_t **)((int64_t)&arg_60h + iVar40 + iVar27) = puVar29 + (int64_t)(puVar39 + 1);
                    *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27) = (int64_t)puVar38 - (int64_t)puVar29;
                    uVar32 = *(undefined4 *)((int64_t)&arg_60h + iVar40 + iVar27);
                    uVar14 = *(undefined4 *)((int64_t)&arg_60h + iVar40 + iVar27 + 4);
                    uVar15 = *(undefined4 *)((int64_t)&arg_68h + iVar40 + iVar27);
                    uVar16 = *(undefined4 *)((int64_t)&arg_68h + iVar40 + iVar27 + 4);
                    *(uint8_t **)((int64_t)&arg_68h + iVar40 + iVar27) = puVar29;
                    *(uint8_t **)((int64_t)&arg_60h + iVar40 + iVar27) = puVar39 + 1;
                    *(undefined4 *)in_RDX = uVar32;
                    *(undefined4 *)((int64_t)in_RDX + 4) = uVar14;
                    *(undefined4 *)(in_RDX + 1) = uVar15;
                    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar16;
                    *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1376;
                    iVar18 = fcn.1801cc620(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27));
                    if (iVar18 != 0) {
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d138b;
                        iVar18 = fcn.1801b4960(in_RDX, (int64_t)&arg_70h + iVar40 + iVar27);
                        if (iVar18 == 0) {
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1394;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d13ac;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27));
                            goto code_r0x0001801d168f;
                        }
                        *(undefined4 *)((int64_t)&arg_58h + iVar40 + iVar27) = 1;
                        *(undefined8 *)((int64_t)&arg_50h + iVar40 + iVar27) = 0;
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d13dc;
                        iVar18 = fcn.1801c9450(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_70h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_a0h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_c0h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_c8h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_d0h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_d8h + iVar40 + iVar27), 
                                               *(int64_t *)(&stack0x000000e0 + iVar40 + iVar27), 
                                               *(int64_t *)(&stack0x000000e8 + iVar40 + iVar27), 
                                               *(int64_t *)(&stack0x000000f0 + iVar40 + iVar27));
                        if (iVar18 == 0) {
code_r0x0001801d145a:
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1471;
                            fcn.180224990(*(undefined8 *)((int64_t)&arg_a0h + iVar40 + iVar27), 0x1804b3b98, 0xa57);
                            return 0;
                        }
                        *(undefined4 *)((int64_t)&arg_58h + iVar40 + iVar27) = 1;
                        *(undefined8 *)((int64_t)&arg_50h + iVar40 + iVar27) = 0;
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1402;
                        iVar18 = fcn.1801c9b70(in_RCX, 0x4000, *(int64_t *)((int64_t)&arg_a0h + iVar40 + iVar27), 0, 
                                               *(int64_t *)((int64_t)&arg_70h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_90h + iVar40 + iVar27), 
                                               *(int64_t *)(&stack0x00000098 + iVar40 + iVar27));
                        if (iVar18 == 0) goto code_r0x0001801d145a;
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d141d;
                        fcn.180224990(*(undefined8 *)((int64_t)&arg_a0h + iVar40 + iVar27), 0x1804b3b98, 0xa5a);
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1425;
                        iVar18 = fcn.1801ab7c0(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar40 + iVar27));
                        if (iVar18 == 0) {
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1432;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d144a;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27));
                            goto code_r0x0001801d168f;
                        }
                        goto code_r0x0001801d1612;
                    }
                }
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d147b;
            fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
        } else {
            puVar39 = *in_RDX;
            puVar29 = in_RDX[1];
            puVar38 = in_RDX[1];
            *(uint8_t **)((int64_t)&arg_60h + iVar40 + iVar27) = puVar39;
            *(uint8_t **)((int64_t)&arg_68h + iVar40 + iVar27) = puVar29;
            if (puVar38 != (uint8_t *)0x0) {
                puVar38 = puVar38 + -1;
                puVar29 = (uint8_t *)(uint64_t)*puVar39;
                if (puVar29 <= puVar38) {
                    *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27) = (int64_t)puVar38 - (int64_t)puVar29;
                    *(uint8_t **)((int64_t)&arg_60h + iVar40 + iVar27) = puVar39 + 1 + (int64_t)puVar29;
                    uVar32 = *(undefined4 *)((int64_t)&arg_60h + iVar40 + iVar27 + 4);
                    uVar14 = *(undefined4 *)((int64_t)&arg_68h + iVar40 + iVar27);
                    uVar15 = *(undefined4 *)((int64_t)&arg_68h + iVar40 + iVar27 + 4);
                    *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&arg_60h + iVar40 + iVar27);
                    *(undefined4 *)((int64_t)in_RDX + 4) = uVar32;
                    *(undefined4 *)(in_RDX + 1) = uVar14;
                    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar15;
                    uVar37 = *(undefined8 *)(in_RCX + 0x348);
                    *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d14e4;
                    fcn.180224990(uVar37, 0x1804a9450, 0x1d9);
                    *(undefined8 *)(in_RCX + 0x348) = 0;
                    *(undefined8 *)(in_RCX + 0x350) = 0;
                    if (puVar29 != (uint8_t *)0x0) {
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1510;
                        iVar26 = fcn.180223170(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27));
                        *(int64_t *)(in_RCX + 0x348) = iVar26;
                        if (iVar26 == 0) {
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d155d;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1575;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27));
                            goto code_r0x0001801d168f;
                        }
                        *(uint8_t **)(in_RCX + 0x350) = puVar29;
                    }
                    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
code_r0x0001801d15ff:
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d160a;
                        iVar18 = fcn.1801ae830(*(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_70h + iVar40 + iVar27));
                        if (iVar18 == 0) {
                            return 0;
                        }
code_r0x0001801d1612:
                        if (in_RDX[1] == (uint8_t *)0x0) {
                            *(undefined4 *)(in_RCX + 0x340) = 1;
                            if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                                (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)) && (iVar18 != 0x10000)) {
                                return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 2);
                            }
                            return 2;
                        }
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d161e;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                    } else {
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1545;
                        iVar18 = fcn.1801b4960(in_RDX, (int64_t)&arg_70h + iVar40 + iVar27);
                        if (iVar18 != 0) {
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1595;
                            iVar18 = fcn.1801ab8b0(*(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_70h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_78h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_88h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_90h + iVar40 + iVar27));
                            if (iVar18 == 0) {
                                *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d159e;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                                *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d15b6;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27));
                                goto code_r0x0001801d168f;
                            }
                            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d15ce;
                            iVar18 = fcn.1801ab7c0(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_88h + iVar40 + iVar27));
                            if (iVar18 == 0) {
                                *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d15d7;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                                *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d15ef;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27));
                                goto code_r0x0001801d168f;
                            }
                            goto code_r0x0001801d15ff;
                        }
                        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d154e;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
                    }
                    goto code_r0x0001801d1671;
                }
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d166c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27));
        }
code_r0x0001801d1671:
        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d1684;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_50h + iVar40 + iVar27), 
                      *(int64_t *)((int64_t)&arg_58h + iVar40 + iVar27), 
                      *(int64_t *)((int64_t)&arg_60h + iVar40 + iVar27), 
                      *(int64_t *)((int64_t)&arg_68h + iVar40 + iVar27), 
                      *(int64_t *)((int64_t)&arg_80h + iVar40 + iVar27));
code_r0x0001801d168f:
        *(undefined8 *)((int64_t)&arg_28h + iVar40 + iVar27) = 0x1801d169a;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_70h + iVar40 + iVar27));
        return 0;
    case 9:
        if (in_RDX[1] == (uint8_t *)0x0) {
            if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c) & 0x20) != 0) {
                *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd4e4;
                iVar18 = fcn.1801bd2f0(*(int64_t *)((int64_t)&arg_38h + iVar27));
                if (iVar18 < 1) {
                    *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd4ed;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
                    *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd505;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_30h + iVar27), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar27));
                    goto code_r0x0001801cd4b3;
                }
            }
            iVar26 = *(int64_t *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd521;
            iVar18 = fcn.1801ce590(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                                   *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_48h + iVar27));
            if (iVar18 == 0) {
                return 0;
            }
            if ((*(int32_t *)(in_RCX + 0xa20) == -1) || (pcVar8 = *(code **)(iVar26 + 0x268), pcVar8 == (code *)0x0)) {
code_r0x0001801cd5ad:
                if (*(int64_t *)(in_RCX + 0xb68) != 0) {
                    *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd5bf;
                    iVar18 = fcn.180198540(*(int64_t *)((int64_t)&var_20h + iVar27), 
                                           *(int64_t *)((int64_t)&arg_28h + iVar27));
                    if ((iVar18 == 0) && ((*(uint8_t *)(in_RCX + 0x948) & 1) != 0)) {
                        return 0;
                    }
                }
                return 1;
            }
            uVar37 = *(undefined8 *)(iVar26 + 0x270);
            uVar36 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd547;
            iVar18 = (*pcVar8)(uVar36, uVar37);
            if (iVar18 == 0) {
                *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd550;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
                *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd568;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_30h + iVar27), 
                              *(int64_t *)((int64_t)&arg_48h + iVar27));
            } else {
                if (-1 < iVar18) goto code_r0x0001801cd5ad;
                *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd582;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
                *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd59a;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_30h + iVar27), 
                              *(int64_t *)((int64_t)&arg_48h + iVar27));
            }
        } else {
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd48d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd4a5;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                          *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_30h + iVar27), 
                          *(int64_t *)((int64_t)&arg_48h + iVar27));
        }
code_r0x0001801cd4b3:
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd4bb;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar27));
        return 0;
    case 10:
        break;
    case 0xb:
        *(undefined8 *)((int64_t)&arg_38h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)((int64_t)&arg_30h + iVar27) = 0x1801b191c;
        iVar26 = fcn.18045a350();
        iVar26 = -iVar26;
        puVar38 = in_RDX[1];
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
            if (puVar38 != (uint8_t *)0x0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b19e1;
                fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
                *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b19f9;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27));
                *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1a0f;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
                return 0;
            }
        } else if (*(int32_t *)(in_RCX + 0x48) == 0x100) {
            if (puVar38 != (uint8_t *)0x2) {
code_r0x0001801b1998:
                *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b199d;
                fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
                *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b19b5;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27));
                *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b19cb;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
                return 0;
            }
        } else if (puVar38 != (uint8_t *)0x0) goto code_r0x0001801b1998;
        if (*(int64_t *)(in_RCX + 0x300) == 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b195d;
            fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1975;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b198b;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
            return 0;
        }
        *(undefined4 *)(in_RCX + 0x1b8) = 1;
        *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1a29;
        iVar18 = fcn.1801c6d70(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27));
        if (iVar18 == 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1a32;
            fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1a4a;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1a60;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
            return 0;
        }
        if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) &&
           (*(int32_t *)(in_RCX + 0x48) == 0x100)) {
            piVar2 = (int16_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x110);
            *piVar2 = *piVar2 + 1;
        }
        return 3;
    case 0xc:
        uVar37 = *(undefined8 *)((int64_t)&arg_58h + iVar27);
        uVar36 = *(undefined8 *)((int64_t)&arg_38h + iVar27);
        *(undefined8 *)((int64_t)&arg_58h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)((int64_t)&arg_38h + iVar27) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar27) = uVar36;
        *(undefined8 *)((int64_t)&arg_28h + iVar27) = unaff_R14;
        *(undefined8 *)((int64_t)&var_20h + iVar27) = 0x1801b1ab3;
        iVar26 = fcn.18045a350();
        iVar26 = -iVar26;
        bVar17 = false;
        if ((*(int64_t *)(in_RCX + 0x260) == 0) || (*(int64_t *)(in_RCX + 0x2e8) == 0)) {
            bVar17 = true;
        }
        *(undefined8 *)((int64_t)&arg_80h + iVar26 + iVar27) = uVar37;
        if (*(int32_t *)(in_RCX + 0x78) != 0) {
            pcVar8 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x68);
            if (pcVar8 != (code *)0x0) {
                uVar37 = *(undefined8 *)(in_RCX + 0xc78);
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1b01;
                (*pcVar8)(uVar37, 0);
            }
            if (*(int32_t *)(in_RCX + 0xba8) != 4) {
                *(undefined4 *)(in_RCX + 0xc0) = 1;
            }
            if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                 (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)) && (iVar18 != 0x10000)) &&
               (*(int64_t *)(in_RCX + 0xbc8) == 0)) {
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1b5b;
                iVar18 = fcn.1801da790(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
                if (iVar18 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1b68;
                iVar20 = fcn.180215470();
                *(int64_t *)(in_RCX + 0xbc8) = iVar20;
                if (iVar20 == 0) {
                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1b79;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1b91;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1ba7;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
                    return 0;
                }
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1bbd;
                iVar18 = fcn.180214b00(*(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
                if (iVar18 == 0) {
                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1bc6;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1bde;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1bf4;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
                    uVar37 = *(undefined8 *)(in_RCX + 0xbc8);
                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1c00;
                    fcn.180215310(uVar37);
                    *(undefined8 *)(in_RCX + 0xbc8) = 0;
                    return 0;
                }
            }
        }
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)) && (iVar18 != 0x10000)) {
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1c3b;
            iVar18 = fcn.1801a2f70(in_RCX + 0xc50);
            if (iVar18 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1c44;
                fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1c5c;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1c72;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
                return 0;
            }
        }
        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
             (iVar18 = **(int32_t **)(in_RCX + 0x18), iVar18 < 0x304)) || (iVar18 == 0x10000)) &&
           (*(int32_t *)(in_RCX + 0x1b8) == 0)) {
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1ca7;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1cbf;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1cd5;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
            return 0;
        }
        *(undefined4 *)(in_RCX + 0x1b8) = 0;
        puVar38 = *(uint8_t **)(in_RCX + 0x2e8);
        if (puVar38 != in_RDX[1]) {
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1cf4;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1d0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1d22;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
            return 0;
        }
        puVar39 = *in_RDX;
        *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1d3b;
        iVar18 = fcn.1802262e0(puVar39, in_RCX + 0x268, puVar38);
        if (iVar18 != 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1d44;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1d5c;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1d72;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
            return 0;
        }
        if ((uint8_t *)0x40 < puVar38) {
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1d84;
            fcn.180229480(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1d9c;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1db2;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
            return 0;
        }
        if (*(int32_t *)(in_RCX + 0x78) == 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1dea;
            fcn.180498030(in_RCX + 0x468, in_RCX + 0x268, puVar38);
            *(uint8_t **)(in_RCX + 0x4a8) = puVar38;
        } else {
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1dd5;
            fcn.180498030(in_RCX + 0x420, in_RCX + 0x268, puVar38);
            *(uint8_t **)(in_RCX + 0x460) = puVar38;
        }
        iVar20 = *(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36);
        if ((((*(uint8_t *)(iVar20 + 0x50) & 8) == 0) && (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)) &&
           (iVar18 != 0x10000)) {
            if (*(int32_t *)(in_RCX + 0x78) == 0) {
                pcVar8 = *(code **)(iVar20 + 8);
                *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27) = (int64_t)&arg_78h + iVar26 + iVar27;
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1e65;
                iVar18 = (*pcVar8)(in_RCX, in_RCX + 0x5f4, in_RCX + 0x5b4, 0);
                if (iVar18 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1e75;
                iVar18 = fcn.1801b45f0(*(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                if (iVar18 == 0) {
                    return 0;
                }
                if ((*(uint32_t *)(in_RCX + 0x160) & 0x2000) == 0) {
                    pcVar8 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x10);
                    *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1ea2;
                    iVar18 = (*pcVar8)(in_RCX, 0x111);
                    if (iVar18 == 0) {
                        return 0;
                    }
                }
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1eb2;
                iVar18 = fcn.1801d16c0(*(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27));
            } else {
                if (*(int32_t *)(in_RCX + 0xba8) == 4) goto code_r0x0001801b1eba;
                pcVar8 = *(code **)(iVar20 + 0x10);
                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1e3f;
                iVar18 = (*pcVar8)(in_RCX, 0x121);
            }
            if (iVar18 == 0) {
                return 0;
            }
        }
code_r0x0001801b1eba:
        if (((bVar17) && (*(int64_t *)(in_RCX + 0x260) != 0)) &&
           ((*(int64_t *)(in_RCX + 0x2e8) != 0 &&
            (pcVar8 = *(code **)(*(int64_t *)(in_RCX + 0xc68) + 0x70), pcVar8 != (code *)0x0)))) {
            uVar37 = *(undefined8 *)(in_RCX + 0xc78);
            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0x1801b1eee;
            (*pcVar8)(uVar37, 0);
        }
        return 1;
    case 0x2a:
        puVar39 = *in_RDX;
        puVar29 = in_RDX[1];
        puVar38 = in_RDX[1];
        *(undefined8 *)((int64_t)&arg_48h + iVar27) = 0;
        *(uint8_t **)((int64_t)&arg_28h + iVar27) = puVar39;
        *(uint8_t **)((int64_t)&arg_30h + iVar27) = puVar29;
        if ((uint8_t *)0x1 < puVar38) {
            puVar38 = puVar38 + -2;
            puVar29 = (uint8_t *)(uint64_t)CONCAT11(*puVar39, puVar39[1]);
            if (puVar29 <= puVar38) {
                iVar26 = (int64_t)puVar38 - (int64_t)puVar29;
                *(uint8_t **)((int64_t)&arg_28h + iVar27) = puVar29 + (int64_t)(puVar39 + 2);
                *(int64_t *)((int64_t)&arg_30h + iVar27) = iVar26;
                if (iVar26 == 0) {
                    uVar32 = *(undefined4 *)((int64_t)&arg_28h + iVar27);
                    uVar14 = *(undefined4 *)((int64_t)&arg_28h + iVar27 + 4);
                    uVar15 = *(undefined4 *)((int64_t)&arg_30h + iVar27);
                    uVar16 = *(undefined4 *)((int64_t)&arg_30h + iVar27 + 4);
                    *(uint8_t **)((int64_t)&arg_28h + iVar27) = puVar39 + 2;
                    *(uint8_t **)((int64_t)&arg_30h + iVar27) = puVar29;
                    *(undefined4 *)in_RDX = uVar32;
                    *(undefined4 *)((int64_t)in_RDX + 4) = uVar14;
                    *(undefined4 *)(in_RDX + 1) = uVar15;
                    *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar16;
                    if (in_RDX[1] == (uint8_t *)0x0) {
                        *(undefined4 *)((int64_t)&var_20h + iVar27) = 1;
                        *(undefined8 *)((int64_t)&var_18h + iVar27) = 0;
                        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd790;
                        iVar18 = fcn.1801c9450(*(int64_t *)((int64_t)&var_18h + iVar27), 
                                               *(int64_t *)((int64_t)&var_20h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_30h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_38h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_48h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_50h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_68h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_88h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_90h + iVar27), 
                                               *(int64_t *)(&stack0x00000098 + iVar27), 
                                               *(int64_t *)((int64_t)&arg_a0h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_a8h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_b0h + iVar27), 
                                               *(int64_t *)((int64_t)&arg_b8h + iVar27));
                        if (iVar18 != 0) {
                            *(undefined4 *)((int64_t)&var_20h + iVar27) = 1;
                            *(undefined8 *)((int64_t)&var_18h + iVar27) = 0;
                            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd7b6;
                            iVar18 = fcn.1801c9b70(in_RCX, 0x400, *(int64_t *)((int64_t)&arg_48h + iVar27), 0, 
                                                   *(int64_t *)((int64_t)&arg_38h + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_48h + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_50h + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_58h + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_60h + iVar27));
                            if (iVar18 != 0) {
                                *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd7d1;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar27), 0x1804b3b98, 0x1012);
                                return 3;
                            }
                        }
                        goto code_r0x0001801cd81b;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd7ed;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd805;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                      *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_30h + iVar27), 
                      *(int64_t *)((int64_t)&arg_48h + iVar27));
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd81b;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar27));
code_r0x0001801cd81b:
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd832;
        fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar27), 0x1804b3b98, 0x1016);
        return 0;
    case 0x2b:
        uVar37 = *(undefined8 *)((int64_t)&arg_58h + iVar27);
        uVar36 = *(undefined8 *)((int64_t)&arg_38h + iVar27);
        *(undefined8 *)((int64_t)&arg_38h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)((int64_t)&arg_30h + iVar27) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_28h + iVar27) = uVar36;
        *(undefined8 *)((int64_t)&var_20h + iVar27) = unaff_R12;
        *(undefined8 *)((int64_t)&var_18h + iVar27) = unaff_R13;
        *(undefined8 *)((int64_t)&var_10h + iVar27) = unaff_R14;
        *(undefined8 *)((int64_t)&var_8h + iVar27) = unaff_R15;
        *(undefined8 *)(&stack0x00000000 + iVar27) = 0x1801b1386;
        iVar20 = fcn.18045a350();
        iVar20 = -iVar20;
        *(uint64_t *)((int64_t)&arg_128h + iVar20 + iVar27) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&var_8h + iVar20 + iVar27;
        iVar24 = 0;
        iVar40 = 0;
        *(undefined4 *)((int64_t)&arg_48h + iVar20 + iVar27) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar20 + iVar27) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar27) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b13bb;
        iVar21 = fcn.180215470();
        *(undefined8 *)((int64_t)&arg_50h + iVar20 + iVar27) = 0;
        iVar26 = *(int64_t *)(in_RCX + 8);
        iVar28 = iVar24;
        if (iVar21 == 0) {
            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b13d1;
            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b13e9;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b13ff;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_48h + iVar20 + iVar27));
            goto code_r0x0001801b18a6;
        }
        iVar23 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)((int64_t)&arg_188h + iVar20 + iVar27) = uVar37;
        iVar22 = *(int64_t *)(iVar23 + 0x2b8);
        if (iVar22 == 0) {
            if (*(int64_t *)(iVar23 + 0x2c0) != 0) {
                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1434;
                iVar22 = fcn.180238400();
                if (iVar22 != 0) goto code_r0x0001801b1440;
            }
            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1870;
            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
code_r0x0001801b1875:
            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1888;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                          *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
            iVar40 = iVar24;
        } else {
code_r0x0001801b1440:
            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b144d;
            iVar23 = fcn.1801a2080(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                   *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                                   *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27));
            if (iVar23 == 0) {
                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1457;
                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b146f;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
                iVar40 = iVar24;
            } else if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1535;
                iVar18 = fcn.1801ac160(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
                if (iVar18 == 0) {
                    *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b153e;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                    *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1556;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
                } else {
code_r0x0001801b14d6:
                    uVar37 = *(undefined8 *)(in_RCX + 0x400);
                    *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b14ea;
                    iVar18 = fcn.1801ab730(iVar26, uVar37, (int64_t)&arg_60h + iVar20 + iVar27);
                    if (iVar18 == 0) {
                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b14f3;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                        goto code_r0x0001801b1875;
                    }
                    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
                        if (in_RDX[1] != (uint8_t *)0x40) {
code_r0x0001801b1597:
                            if (in_RDX[1] == (uint8_t *)0x80) {
                                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b15a9;
                                iVar18 = fcn.180203a00(iVar22);
                                if (iVar18 == 0x3d4) goto code_r0x0001801b15b0;
                            }
                            goto code_r0x0001801b15b5;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1581;
                        iVar18 = fcn.180203a00(iVar22);
                        if (iVar18 != 0x32b) {
                            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1590;
                            iVar18 = fcn.180203a00(iVar22);
                            if (iVar18 != 0x3d3) goto code_r0x0001801b1597;
                        }
code_r0x0001801b15b0:
                        uVar31 = *(uint32_t *)(in_RDX + 1);
code_r0x0001801b15e1:
                        puVar38 = (uint8_t *)(uint64_t)uVar31;
                        if (in_RDX[1] < puVar38) {
                            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1852;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                        } else {
                            puVar39 = *in_RDX;
                            puVar29 = in_RDX[1] + -(int64_t)puVar38;
                            in_RDX[1] = puVar29;
                            *in_RDX = puVar38 + (int64_t)puVar39;
                            if (puVar29 == (uint8_t *)0x0) {
                                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1647;
                                iVar18 = fcn.1801ae510(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27));
                                iVar28 = iVar40;
                                if (iVar18 == 0) goto code_r0x0001801b18a6;
                                if (*(int64_t *)((int64_t)&arg_60h + iVar20 + iVar27) != 0) {
                                    *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1663;
                                    fcn.18020f750();
                                }
                                uVar37 = *(undefined8 *)(iVar26 + 0x460);
                                *(undefined8 *)((int64_t)&arg_38h + iVar20 + iVar27) = 0;
                                *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27) = iVar22;
                                *(undefined8 *)((int64_t)&arg_28h + iVar20 + iVar27) = uVar37;
                                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b168e;
                                iVar18 = fcn.18025cbd0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_80h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_88h + iVar20 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_90h + iVar20 + iVar27));
                                if (iVar18 < 1) {
                                    *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1697;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                                } else {
                                    *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b16c2;
                                    iVar18 = fcn.180203a00(iVar22);
                                    if ((iVar18 == 0x32b) || (iVar18 - 0x3d3U < 2)) {
                                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b16e7;
                                        iVar24 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                                        iVar28 = iVar24;
                                        if (iVar24 == 0) goto code_r0x0001801b18a6;
                                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1701;
                                        fcn.180226680(iVar24, puVar39, uVar31);
                                    }
                                    if ((*(int64_t *)(in_RCX + 0x400) == 0) ||
                                       (*(int32_t *)(*(int64_t *)(in_RCX + 0x400) + 0x1c) != 0x390)) {
code_r0x0001801b174e:
                                        if (*(int32_t *)(in_RCX + 0x48) != 0x300) {
                                            *(undefined8 *)((int64_t)&arg_28h + iVar20 + iVar27) =
                                                 *(undefined8 *)((int64_t)&arg_58h + iVar20 + iVar27);
                                            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b17f9;
                                            iVar18 = fcn.18025c530(*(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar27), 
                                                                   *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
                                            if (0 < iVar18) {
code_r0x0001801b1809:
                                                iVar28 = iVar24;
                                                if ((((*(int32_t *)(in_RCX + 0x78) == 0) &&
                                                     ((*(uint8_t *)
                                                        (*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8)
                                                      == 0)) && (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)
                                                    ) && ((iVar18 != 0x10000 && (*(int32_t *)(in_RCX + 0x340) == 1)))) {
                                                    *(undefined4 *)((int64_t)&arg_48h + iVar20 + iVar27) = 2;
                                                } else {
                                                    *(undefined4 *)((int64_t)&arg_48h + iVar20 + iVar27) = 3;
                                                }
                                                goto code_r0x0001801b18a6;
                                            }
                                            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1802;
                                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
code_r0x0001801b17ad:
                                            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b17c0;
                                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                                                          *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                                                          *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                                                          *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
                                            iVar40 = iVar24;
                                            goto code_r0x0001801b1893;
                                        }
                                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b176d;
                                        iVar18 = fcn.18025cc30(*(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_48h + iVar20 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_60h + iVar20 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_68h + iVar20 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar27), 
                                                               *(int64_t *)((int64_t)&arg_78h + iVar20 + iVar27));
                                        if (0 < iVar18) {
                                            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b178d;
                                            iVar18 = fcn.180215040(*(int64_t *)(&stack0x00000098 + iVar20 + iVar27));
                                            if (0 < iVar18) {
                                                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b179f;
                                                iVar18 = fcn.18025c840(*(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27)
                                                                       , *(int64_t *)
                                                                          ((int64_t)&arg_68h + iVar20 + iVar27), 
                                                                       *(int64_t *)((int64_t)&arg_70h + iVar20 + iVar27)
                                                                      );
                                                if (0 < iVar18) goto code_r0x0001801b1809;
                                                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b17a8;
                                                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                              *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                                                goto code_r0x0001801b17ad;
                                            }
                                        }
                                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b17d5;
                                        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                                    } else {
                                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1728;
                                        iVar18 = fcn.18025dd20(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27));
                                        if (0 < iVar18) {
                                            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b173b;
                                            iVar18 = fcn.18025de80(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27));
                                            if (0 < iVar18) goto code_r0x0001801b174e;
                                        }
                                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1744;
                                        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                                      *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                                    }
                                }
                                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b16af;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
                                iVar40 = iVar24;
                                goto code_r0x0001801b1893;
                            }
                            *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1608;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                        }
                    } else {
code_r0x0001801b15b5:
                        if ((uint8_t *)0x1 < in_RDX[1]) {
                            puVar38 = *in_RDX;
                            uVar31 = (uint32_t)CONCAT11(*puVar38, puVar38[1]);
                            *in_RDX = puVar38 + 2;
                            in_RDX[1] = in_RDX[1] + -2;
                            goto code_r0x0001801b15e1;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1861;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                    }
                    *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1620;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
                }
            } else {
                if ((uint8_t *)0x1 < in_RDX[1]) {
                    *in_RDX = *in_RDX + 2;
                    in_RDX[1] = in_RDX[1] + -2;
                    *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b14ce;
                    iVar18 = fcn.1801a98b0(*(int64_t *)((int64_t)&arg_48h + iVar20 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_50h + iVar20 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_60h + iVar20 + iVar27));
                    if (iVar18 < 1) goto code_r0x0001801b18a6;
                    goto code_r0x0001801b14d6;
                }
                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b1502;
                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
                *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b151a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_40h + iVar20 + iVar27), 
                              *(int64_t *)((int64_t)&arg_58h + iVar20 + iVar27));
            }
        }
code_r0x0001801b1893:
        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b189e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_48h + iVar20 + iVar27));
        iVar28 = iVar40;
code_r0x0001801b18a6:
        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b18b2;
        fcn.180219f80(*(int64_t *)((int64_t)&arg_28h + iVar20 + iVar27), 
                      *(int64_t *)((int64_t)&arg_30h + iVar20 + iVar27));
        *(undefined8 *)(in_RCX + 0x1a8) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b18c5;
        fcn.180215310(iVar21);
        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b18da;
        fcn.180224990(iVar28, 0x1804af528, 0x25d);
        *(undefined8 *)(&stack0x00000000 + iVar20 + iVar27) = 0x1801b18ee;
        uVar25 = fcn.180459870(*(uint64_t *)((int64_t)&arg_128h + iVar20 + iVar27) ^ (int64_t)&var_8h + iVar20 + iVar27)
        ;
        return uVar25;
    case 0x2d:
        if (in_RDX[1] != (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd638;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd650;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27), 
                          *(int64_t *)((int64_t)&arg_28h + iVar27), *(int64_t *)((int64_t)&arg_30h + iVar27), 
                          *(int64_t *)((int64_t)&arg_48h + iVar27));
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd666;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar27));
            return 0;
        }
        if ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x1e & 1) != 0) {
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd69c;
            fcn.1801c6e50(*(int64_t *)((int64_t)&var_18h + iVar27), *(int64_t *)((int64_t)&var_20h + iVar27));
            return 1;
        }
        if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) {
            *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd6c7;
            fcn.180194190(*(int64_t *)((int64_t)&var_18h + iVar27));
            return 1;
        }
        *(undefined8 *)((int64_t)&puStack_10 + iVar27) = 0x1801cd6e3;
        fcn.180194200(*(int64_t *)((int64_t)&var_18h + iVar27));
        return 1;
    case 0x31:
        *(undefined8 *)((int64_t)&arg_48h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
        *(undefined8 *)((int64_t)&arg_38h + iVar27) = *(undefined8 *)((int64_t)&arg_38h + iVar27);
        *(undefined8 *)((int64_t)&arg_30h + iVar27) = 0x1801b1f20;
        iVar26 = fcn.18045a350();
        iVar26 = -iVar26;
        *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1f35;
        iVar18 = fcn.1801a2f70(in_RCX + 0xc50);
        if (iVar18 == 0) {
            if (in_RDX[1] != (uint8_t *)0x0) {
                uVar3 = **in_RDX;
                *in_RDX = *in_RDX + 1;
                puVar38 = in_RDX[1] + -1;
                in_RDX[1] = puVar38;
                if (puVar38 == (uint8_t *)0x0) {
                    if (uVar3 != 0) {
                        if (uVar3 != 1) {
                            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1f98;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
                            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1fb0;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                          *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27));
                            goto code_r0x0001801b2002;
                        }
                        *(undefined4 *)(in_RCX + 0xba4) = 0;
                    }
                    *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1fc7;
                    iVar18 = fcn.1801b4650(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_80h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27), 
                                           *(int64_t *)(&stack0x00000098 + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_a0h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_a8h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_b0h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_b8h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_c8h + iVar26 + iVar27), 
                                           *(int64_t *)(&stack0x00000108 + iVar26 + iVar27), 
                                           *(int64_t *)(&stack0x00000148 + iVar26 + iVar27), 
                                           *(int64_t *)(&stack0x00000198 + iVar26 + iVar27), 
                                           *(int64_t *)(&stack0x000001a0 + iVar26 + iVar27));
                    return (uint64_t)(iVar18 != 0);
                }
            }
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1fdf;
            fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1ff7;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27));
        } else {
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1f3e;
            fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b1f56;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                          *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27));
        }
code_r0x0001801b2002:
        *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) = 0x1801b200d;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_78h + iVar26 + iVar27));
        return 0;
    }
    uVar37 = *(undefined8 *)((int64_t)&arg_38h + iVar27);
    *(undefined8 *)((int64_t)&arg_38h + iVar27) = *(undefined8 *)((int64_t)&arg_50h + iVar27);
    *(undefined8 *)((int64_t)&arg_30h + iVar27) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_28h + iVar27) = *(undefined8 *)((int64_t)&arg_58h + iVar27);
    *(undefined8 *)((int64_t)&var_20h + iVar27) = uVar37;
    *(undefined8 *)((int64_t)&var_18h + iVar27) = unaff_R12;
    *(undefined8 *)((int64_t)&var_10h + iVar27) = unaff_R13;
    *(undefined8 *)((int64_t)&var_8h + iVar27) = unaff_R14;
    *(undefined8 *)(&stack0x00000000 + iVar27) = unaff_R15;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar27) = 0x1801d1e27;
    iVar26 = fcn.18045a350();
    iVar26 = -iVar26;
    puVar38 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_c8h + iVar26 + iVar27) = 0;
    uVar32 = 0;
    *(undefined8 *)((int64_t)&arg_d8h + iVar26 + iVar27) = 0;
    iVar20 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar26 + iVar27) = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_d0h + iVar26 + iVar27) = 0;
    if (puVar38 < (uint8_t *)0x4) {
code_r0x0001801d1fc1:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d1fc6;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
code_r0x0001801d1fcb:
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d1fde;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
        iVar40 = 0;
    } else {
        puVar39 = *in_RDX;
        uVar3 = *puVar39;
        uVar4 = puVar39[1];
        uVar5 = puVar39[2];
        uVar6 = puVar39[3];
        in_RDX[1] = puVar38 + -4;
        *in_RDX = puVar39 + 4;
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar18 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar18)) && (iVar18 != 0x10000)) {
            if ((uint8_t *)0x3 < puVar38 + -4) {
                uVar32 = CONCAT31(CONCAT21(CONCAT11(puVar39[4], puVar39[5]), puVar39[6]), puVar39[7]);
                *in_RDX = puVar39 + 8;
                in_RDX[1] = puVar38 + -8;
                puVar39 = *in_RDX;
                puVar29 = in_RDX[1];
                *(uint8_t **)((int64_t)&arg_50h + iVar26 + iVar27) = puVar39;
                *(uint8_t **)((int64_t)&arg_58h + iVar26 + iVar27) = puVar29;
                if (puVar38 + -8 != (uint8_t *)0x0) {
                    puVar29 = (uint8_t *)(uint64_t)*puVar39;
                    *(uint8_t **)((int64_t)&arg_d8h + iVar26 + iVar27) = puVar39 + 1;
                    *(uint8_t **)((int64_t)&arg_d0h + iVar26 + iVar27) = puVar29;
                    if (puVar29 <= puVar38 + -9) {
                        *(uint8_t **)((int64_t)&arg_50h + iVar26 + iVar27) = puVar29 + (int64_t)(puVar39 + 1);
                        *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27) = (int64_t)(puVar38 + -9) - (int64_t)puVar29;
                        uVar14 = *(undefined4 *)((int64_t)&arg_50h + iVar26 + iVar27 + 4);
                        uVar15 = *(undefined4 *)((int64_t)&arg_58h + iVar26 + iVar27);
                        uVar16 = *(undefined4 *)((int64_t)&arg_58h + iVar26 + iVar27 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&arg_50h + iVar26 + iVar27);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar14;
                        *(undefined4 *)(in_RDX + 1) = uVar15;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar16;
                        goto code_r0x0001801d1f59;
                    }
                }
            }
            goto code_r0x0001801d1fc1;
        }
code_r0x0001801d1f59:
        if (in_RDX[1] < (uint8_t *)0x2) goto code_r0x0001801d1fc1;
        puVar38 = *in_RDX;
        uVar11 = CONCAT11(*puVar38, puVar38[1]);
        uVar41 = (uint32_t)uVar11;
        *in_RDX = puVar38 + 2;
        puVar38 = in_RDX[1] + -2;
        in_RDX[1] = puVar38;
        piVar9 = *(int32_t **)(in_RCX + 0x18);
        uVar31 = *(uint32_t *)(*(int64_t *)(piVar9 + 0x36) + 0x50) & 8;
        iVar40 = iVar20;
        if (((uVar31 == 0) && (0x303 < *piVar9)) && (*piVar9 != 0x10000)) {
            if ((uVar11 != 0) && ((uint8_t *)(uint64_t)uVar41 <= puVar38)) {
code_r0x0001801d206f:
                puVar34 = (undefined8 *)(in_RCX + 0x8f8);
                uVar37 = *puVar34;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d207c;
                iVar28 = fcn.18019dc20(uVar37, 0);
                *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27) = iVar28;
                if (iVar28 != 0) {
                    if (((*(uint8_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x50) & 1) != 0) &&
                       ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                         (iVar18 = **(int32_t **)(in_RCX + 0x18), iVar18 < 0x304)) || (iVar18 == 0x10000)))) {
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d20e9;
                        fcn.18019c8a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27));
                    }
                    uVar37 = *puVar34;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d20f8;
                    fcn.18019c980(uVar37);
                    *puVar34 = *(undefined8 *)((int64_t)&arg_50h + iVar26 + iVar27);
                    goto code_r0x0001801d2100;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d208b;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d20a3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                goto code_r0x0001801d1fe9;
            }
            goto code_r0x0001801d1fc1;
        }
        if (puVar38 != (uint8_t *)(uint64_t)uVar41) goto code_r0x0001801d1fc1;
        if (uVar11 == 0) {
            return 3;
        }
        if ((((uVar31 == 0) && (0x303 < *piVar9)) && (*piVar9 != 0x10000)) ||
           (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x250) != 0)) goto code_r0x0001801d206f;
code_r0x0001801d2100:
        piVar35 = (int64_t *)(in_RCX + 0x8f8);
        iVar28 = *piVar35;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2108;
        uVar37 = fcn.1802450c0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                               *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27));
        *(undefined8 *)(iVar28 + 0x2e0) = uVar37;
        iVar28 = *piVar35;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2117;
        fcn.18019dbf0(iVar28);
        uVar37 = *(undefined8 *)(*piVar35 + 800);
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2133;
        fcn.180224990(uVar37, 0x1804b3b98, 0xae8);
        *(undefined8 *)(*piVar35 + 800) = 0;
        *(undefined8 *)(*piVar35 + 0x328) = 0;
        iVar28 = *piVar35;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2161;
        uVar37 = fcn.1802248d0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                               *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
        *(undefined8 *)(iVar28 + 800) = uVar37;
        if (*(int64_t *)(*piVar35 + 800) != 0) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d21b2;
            iVar18 = fcn.1801b4900(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27));
            if (iVar18 == 0) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d21bb;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
            } else {
                *(uint32_t *)(*piVar35 + 0x330) = CONCAT31(CONCAT21(CONCAT11(uVar3, uVar4), uVar5), uVar6);
                *(undefined4 *)(*piVar35 + 0x334) = uVar32;
                *(uint64_t *)(*piVar35 + 0x328) = (uint64_t)uVar41;
                if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                    (iVar18 = **(int32_t **)(in_RCX + 0x18), iVar18 < 0x304)) || (iVar18 == 0x10000)) {
code_r0x0001801d22db:
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d22f6;
                    iVar40 = fcn.180215540(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                    if (iVar40 == 0) {
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d230b;
                        fcn.18019b6a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                        goto code_r0x0001801d1ff4;
                    }
                    *(undefined8 *)((int64_t)&arg_28h + iVar26 + iVar27) = 0;
                    *(int64_t *)((int64_t)&var_20h + iVar26 + iVar27) = iVar40;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2352;
                    iVar18 = fcn.180214220(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_48h + iVar26 + iVar27), 
                                           *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27));
                    if (iVar18 == 0) {
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d235b;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2373;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                    } else {
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d238b;
                        fcn.180215590(iVar40);
                        iVar40 = 0;
                        *(uint64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x250) =
                             (uint64_t)*(uint32_t *)((int64_t)&arg_c0h + iVar26 + iVar27);
                        *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b0) = 0;
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                            (iVar18 = **(int32_t **)(in_RCX + 0x18), iVar18 < 0x304)) || (iVar18 == 0x10000)) {
                            return 3;
                        }
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d23e6;
                        uVar37 = fcn.1801a0380(in_RCX);
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d23f1;
                        iVar18 = fcn.18020f800(uVar37);
                        if (0 < iVar18) {
                            iVar20 = *(int64_t *)(in_RCX + 0x8f8);
                            *(undefined4 *)((int64_t)&arg_48h + iVar26 + iVar27) = 1;
                            *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27) = (int64_t)iVar18;
                            *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27) = iVar20 + 0x50;
                            *(undefined8 *)((int64_t)&arg_30h + iVar26 + iVar27) =
                                 *(undefined8 *)((int64_t)&arg_d0h + iVar26 + iVar27);
                            *(undefined8 *)((int64_t)&arg_28h + iVar26 + iVar27) =
                                 *(undefined8 *)((int64_t)&arg_d8h + iVar26 + iVar27);
                            *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 10;
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d247e;
                            iVar19 = fcn.1801b40a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_80h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_88h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27), 
                                                   *(int64_t *)(&stack0x00000098 + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_a0h + iVar26 + iVar27), 
                                                   *(int64_t *)((int64_t)&arg_a8h + iVar26 + iVar27), 
                                                   *(int64_t *)(&stack0x00000118 + iVar26 + iVar27));
                            if (iVar19 != 0) {
                                *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 8) = (int64_t)iVar18;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d24ab;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_c8h + iVar26 + iVar27), 0x1804b3b98, 0xb48);
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d24b8;
                                fcn.180198390(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                                return 1;
                            }
                            goto code_r0x0001801d1ff4;
                        }
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d23fa;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2412;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
                    }
                    goto code_r0x0001801d1fe9;
                }
                puVar39 = *in_RDX;
                puVar29 = in_RDX[1];
                puVar38 = in_RDX[1];
                *(uint8_t **)((int64_t)&arg_50h + iVar26 + iVar27) = puVar39;
                *(uint8_t **)((int64_t)&arg_58h + iVar26 + iVar27) = puVar29;
                if ((uint8_t *)0x1 < puVar38) {
                    puVar38 = puVar38 + -2;
                    puVar29 = (uint8_t *)(uint64_t)CONCAT11(*puVar39, puVar39[1]);
                    if (puVar29 <= puVar38) {
                        iVar40 = (int64_t)puVar38 - (int64_t)puVar29;
                        *(uint8_t **)((int64_t)&arg_50h + iVar26 + iVar27) = puVar39 + 2 + (int64_t)puVar29;
                        *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27) = iVar40;
                        if (iVar40 == 0) {
                            uVar32 = *(undefined4 *)((int64_t)&arg_50h + iVar26 + iVar27);
                            uVar14 = *(undefined4 *)((int64_t)&arg_50h + iVar26 + iVar27 + 4);
                            uVar15 = *(undefined4 *)((int64_t)&arg_58h + iVar26 + iVar27);
                            uVar16 = *(undefined4 *)((int64_t)&arg_58h + iVar26 + iVar27 + 4);
                            *(uint8_t **)((int64_t)&arg_50h + iVar26 + iVar27) = puVar39 + 2;
                            *(uint8_t **)((int64_t)&arg_58h + iVar26 + iVar27) = puVar29;
                            *(undefined4 *)in_RDX = uVar32;
                            *(undefined4 *)((int64_t)in_RDX + 4) = uVar14;
                            *(undefined4 *)(in_RDX + 1) = uVar15;
                            *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar16;
                            if (in_RDX[1] == (uint8_t *)0x0) {
                                *(undefined4 *)((int64_t)&arg_28h + iVar26 + iVar27) = 1;
                                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d22a6;
                                iVar18 = fcn.1801c9450(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_70h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_90h + iVar26 + iVar27), 
                                                       *(int64_t *)(&stack0x00000098 + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_a0h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_a8h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_b0h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_b8h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_c0h + iVar26 + iVar27));
                                iVar40 = 0;
                                if (iVar18 == 0) goto code_r0x0001801d1ff4;
                                *(undefined4 *)((int64_t)&arg_28h + iVar26 + iVar27) = 1;
                                *(undefined8 *)((int64_t)&var_20h + iVar26 + iVar27) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d22d3;
                                iVar18 = fcn.1801c9b70(in_RCX, 0x2000, *(int64_t *)((int64_t)&arg_c8h + iVar26 + iVar27)
                                                       , 0, *(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_58h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_60h + iVar26 + iVar27), 
                                                       *(int64_t *)((int64_t)&arg_68h + iVar26 + iVar27));
                                iVar40 = iVar20;
                                if (iVar18 == 0) goto code_r0x0001801d1ff4;
                                goto code_r0x0001801d22db;
                            }
                        }
                    }
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2315;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                              *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
            }
            goto code_r0x0001801d1fcb;
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d217c;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2194;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_28h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_30h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_38h + iVar26 + iVar27), 
                      *(int64_t *)((int64_t)&arg_50h + iVar26 + iVar27));
    }
code_r0x0001801d1fe9:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d1ff4;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_40h + iVar26 + iVar27));
code_r0x0001801d1ff4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d1ffc;
    fcn.180215590(iVar40);
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar26 + iVar27) = 0x1801d2016;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_c8h + iVar26 + iVar27), 0x1804b3b98, 0xb50);
    return 0;
}

// ============================================================
// Function: FUN_1801cd910
// Address: 0x1801cd910
// Size: 1562 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801cd910(int64_t arg_28h)
{
    undefined4 *puVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cd920;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = *(uint32_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8;
    if (((uVar6 == 0) && (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) {
    // switch table (43 cases) at 0x1801cde7c
        switch(*(undefined4 *)(in_RCX + 0xac)) {
        case 1:
            if (in_EDX == 4) {
                *(undefined4 *)(in_RCX + 0xac) = 10;
                return 1;
            }
            if (in_EDX == 0x18) {
                if ((*(uint32_t *)(in_RCX + 0x160) & 0x2000) == 0) {
                    *(undefined4 *)(in_RCX + 0xac) = 0x31;
                    return 1;
                }
            } else if ((in_EDX == 0xd) && (*(int32_t *)(in_RCX + 0xba8) == 1)) {
                *(undefined4 *)(in_RCX + 0xba8) = 4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cdb25;
                iVar3 = fcn.1801affd0(in_RCX);
                if (iVar3 != 0) goto code_r0x0001801cdb2d;
            }
            break;
        case 3:
            if (in_EDX == 8) {
                *(undefined4 *)(in_RCX + 0xac) = 0x2a;
                return 1;
            }
            break;
        case 4:
        case 5:
            if (in_EDX == 0xf) {
                *(undefined4 *)(in_RCX + 0xac) = 0x2b;
                return 1;
            }
            break;
        case 8:
            goto joined_r0x0001801cda46;
        case 0xd:
            if (in_EDX == 2) {
                *(undefined4 *)(in_RCX + 0xac) = 3;
                return 1;
            }
            break;
        case 0x2a:
            if (*(int32_t *)(in_RCX + 0x508) != 0) goto joined_r0x0001801cda8f;
            if (in_EDX == 0xd) {
code_r0x0001801cdb2d:
                *(undefined4 *)(in_RCX + 0xac) = 8;
                return 1;
            }
joined_r0x0001801cda46:
            if (in_EDX == 0xb) {
                *(undefined4 *)(in_RCX + 0xac) = 4;
                return 1;
            }
            break;
        case 0x2b:
joined_r0x0001801cda8f:
            if (in_EDX == 0x14) {
                *(undefined4 *)(in_RCX + 0xac) = 0xc;
                return 1;
            }
        }
        goto code_r0x0001801cd9d5;
    }
    puVar1 = (undefined4 *)(in_RCX + 0xac);
    // switch table (50 cases) at 0x1801cdec8
    switch(*puVar1) {
    case 1:
        if (in_EDX == 0) {
            *puVar1 = 0x2d;
            return 1;
        }
        break;
    case 3:
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            iVar3 = *(int32_t *)(in_RCX + 0xa60);
            goto joined_r0x0001801cddae;
        }
        if ((uVar6 != 0) && (in_EDX == 3)) {
code_r0x0001801cdbdf:
            *puVar1 = 2;
            return 1;
        }
        if (((0x300 < *(int32_t *)(in_RCX + 0x48)) && (*(int64_t *)(in_RCX + 0xae0) != 0)) &&
           ((*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 800) != 0 && (in_EDX == 0x101)))) {
            *(undefined4 *)(in_RCX + 0x508) = 1;
            *puVar1 = 0xb;
            return 1;
        }
        uVar6 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
        if ((uVar6 & 0x54) == 0) {
            if (in_EDX == 0xb) {
                *puVar1 = 4;
                return 1;
            }
            break;
        }
        uVar2 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c);
        if ((uVar2 & 0x1a6) == 0) {
            if (((uVar2 & 0x1c8) != 0) && (in_EDX == 0xc)) goto code_r0x0001801cdd6b;
            if (in_EDX == 0xd) {
                if (((*(int32_t *)(in_RCX + 0x48) < 0x301) || ((uVar6 & 4) == 0)) && ((uVar6 & 0x50) == 0)) {
                    *puVar1 = 8;
                    return 1;
                }
                break;
            }
            goto code_r0x0001801cdd88;
        }
        goto joined_r0x0001801cdd65;
    case 4:
    case 5:
        if ((*(int32_t *)(in_RCX + 0xa34) != 0) && (in_EDX == 0x16)) {
            *puVar1 = 6;
            return 1;
        }
    case 6:
        uVar6 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c);
        if ((uVar6 & 0x1a6) == 0) {
            if (((uVar6 & 0x1c8) != 0) && (in_EDX == 0xc)) goto code_r0x0001801cdd6b;
code_r0x0001801cdd18:
            if (in_EDX == 0xd) {
                if (((*(int32_t *)(in_RCX + 0x48) < 0x301) ||
                    ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20) & 4) == 0)) &&
                   ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20) & 0x50) == 0)) {
                    *(undefined4 *)(in_RCX + 0xac) = 8;
                    return 1;
                }
            } else {
code_r0x0001801cdd88:
                if (in_EDX == 0xe) {
                    *(undefined4 *)(in_RCX + 0xac) = 9;
                    return 1;
                }
            }
        } else {
joined_r0x0001801cdd65:
            if (in_EDX == 0xc) {
code_r0x0001801cdd6b:
                *puVar1 = 7;
                return 1;
            }
        }
        break;
    case 7:
        goto code_r0x0001801cdd18;
    case 8:
        goto code_r0x0001801cdd88;
    case 10:
        if (in_EDX != 0x101) break;
        goto code_r0x0001801cdde8;
    case 0xb:
        if (in_EDX == 0x14) {
            *puVar1 = 0xc;
            return 1;
        }
        break;
    case 0xd:
        if (in_EDX == 2) {
code_r0x0001801cdb9b:
            *puVar1 = 3;
            return 1;
        }
        if ((uVar6 != 0) && (in_EDX == 3)) goto code_r0x0001801cdbdf;
        break;
    case 0x14:
        iVar3 = *(int32_t *)(in_RCX + 0xa60);
joined_r0x0001801cddae:
        if (iVar3 == 0) {
            if (in_EDX == 0x101) {
code_r0x0001801cdde8:
                *puVar1 = 0xb;
                return 1;
            }
        } else if (in_EDX == 4) {
            *puVar1 = 10;
            return 1;
        }
        break;
    case 0x32:
        if (in_EDX == 2) goto code_r0x0001801cdb9b;
    }
code_r0x0001801cd9d5:
    if (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) != 0) && (in_EDX == 0x101)) {
        *(undefined8 *)(in_RCX + 0x108) = 0;
        *(undefined4 *)(in_RCX + 0x68) = 3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cda10;
        uVar5 = fcn.180193c40(*(int64_t *)(&stack0x00000030 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cda20;
        fcn.180219ce0(uVar5, 0xf);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cda2d;
        fcn.18021b250(uVar5, 9);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cde40;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cde58;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cde6e;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1801cdf30
// Address: 0x1801cdf30
// Size: 831 bytes
// ============================================================
undefined8 fcn.1801cdf30(int64_t param_1)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cdf3c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar6 = *(uint32_t *)(*(int64_t *)(*(int32_t **)(param_1 + 0x18) + 0x36) + 0x50) & 8;
    if (((uVar6 == 0) && (iVar2 = **(int32_t **)(param_1 + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8) = *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + 8);
        *(undefined8 *)((int64_t)aiStackX_10 + iVar5) = 0x1801cc7ec;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        switch(*(undefined4 *)(param_1 + 0xac)) {
        case 1:
            if (*(int32_t *)(param_1 + 0xba4) == -1) {
                return 2;
            }
            *(undefined4 *)(param_1 + 0xac) = 0x2f;
            return 1;
        default:
            *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar5) = 0x1801cca01;
            fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar3 + iVar5), *(int64_t *)(&stack0x00000040 + iVar3 + iVar5)
                         );
            break;
        case 8:
            if (*(int32_t *)(param_1 + 0xba8) == 4) {
                if ((*(char *)(param_1 + 0xb50) != '\0') || (uVar1 = 0xf, *(int32_t *)(param_1 + 0xb3c) == 0)) {
                    uVar1 = 0xe;
                }
                *(undefined4 *)(param_1 + 0xac) = uVar1;
                return 1;
            }
            if ((*(uint8_t *)(param_1 + 0x84) & 1) != 0) goto code_r0x0001801cc86e;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar5) = 0x1801cc864;
            fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar3 + iVar5), *(int64_t *)(&stack0x00000040 + iVar3 + iVar5)
                         );
            break;
        case 10:
        case 0x14:
        case 0x2f:
        case 0x31:
code_r0x0001801cc86e:
            *(undefined4 *)(param_1 + 0xac) = 1;
            return 1;
        case 0xc:
            if ((*(int32_t *)(param_1 + 0xf0) == 3) || (*(int32_t *)(param_1 + 0xf0) == 7)) {
                *(undefined4 *)(param_1 + 0xac) = 0x33;
            } else if (((*(uint32_t *)(param_1 + 0x9a8) >> 0x14 & 1) == 0) || (*(int32_t *)(param_1 + 0x8c8) != 0)) {
                if (*(int32_t *)(param_1 + 0x340) == 0) {
                    *(undefined4 *)(param_1 + 0xac) = 0x14;
                } else if ((*(char *)(param_1 + 0xb50) == '\0') && (*(int32_t *)(param_1 + 0xb3c) != 0)) {
                    *(undefined4 *)(param_1 + 0xac) = 0xf;
                } else {
                    *(undefined4 *)(param_1 + 0xac) = 0xe;
                }
            } else {
                *(undefined4 *)(param_1 + 0xac) = 0x12;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar5) = 0x1801cc903;
            uVar4 = fcn.1802450c0(*(int64_t *)(&stack0x00000038 + iVar3 + iVar5), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar5));
            *(undefined8 *)(param_1 + 0x90) = uVar4;
            return 1;
        case 0xe:
        case 0xf:
            uVar1 = 0x14;
            if (*(int32_t *)(param_1 + 0x340) == 1) {
                uVar1 = 0x11;
            }
            *(undefined4 *)(param_1 + 0xac) = uVar1;
            return 1;
        case 0x11:
            *(undefined4 *)(param_1 + 0xac) = 0x14;
            return 1;
        case 0x33:
            if ((*(int32_t *)(param_1 + 0xb18) == 2) && ((*(uint32_t *)(param_1 + 0x160) & 0x2000) == 0)) {
                *(undefined4 *)(param_1 + 0xac) = 0x34;
                return 1;
            }
        case 0x12:
        case 0x34:
            if (*(int32_t *)(param_1 + 0x340) == 0) {
                *(undefined4 *)(param_1 + 0xac) = 0x14;
                return 1;
            }
            if ((*(char *)(param_1 + 0xb50) == '\0') && (*(int32_t *)(param_1 + 0xb3c) != 0)) {
                *(undefined4 *)(param_1 + 0xac) = 0xf;
                return 1;
            }
            *(undefined4 *)(param_1 + 0xac) = 0xe;
            return 1;
        }
        *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar5) = 0x1801cca19;
        fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar3 + iVar5), *(int64_t *)(&stack0x00000040 + iVar3 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar3 + iVar5), *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar3 + iVar5));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + iVar5) = 0x1801cca2f;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar5));
        return 0;
    }
    // switch table (51 cases) at 0x1801ce200
    switch(*(undefined4 *)(param_1 + 0xac)) {
    case 1:
        if (*(int32_t *)(param_1 + 0xba0) == 0) {
            return 2;
        }
    case 0:
    case 2:
        *(undefined4 *)(param_1 + 0xac) = 0xd;
        return 1;
    case 3:
        if (((*(uint32_t *)(param_1 + 0x9a8) >> 0x14 & 1) == 0) || (uVar1 = 0x12, *(int32_t *)(param_1 + 0xf0) == 7)) {
            uVar1 = 0xd;
        }
        *(undefined4 *)(param_1 + 0xac) = uVar1;
        return 1;
    default:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce1c8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10))
        ;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce1e0;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10)
                      , *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce1f6;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar5));
        break;
    case 9:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce042;
        uVar4 = fcn.1802450c0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)(param_1 + 0x90) = uVar4;
        uVar1 = 0xe;
        if (*(int32_t *)(param_1 + 0x340) == 0) {
            uVar1 = 0x10;
        }
        *(undefined4 *)(param_1 + 0xac) = uVar1;
        return 1;
    case 0xc:
        if (*(int32_t *)(param_1 + 0x508) == 0) {
            *(undefined4 *)(param_1 + 0xac) = 1;
            return 1;
        }
        *(undefined4 *)(param_1 + 0xac) = 0x12;
        return 1;
    case 0xd:
        if ((*(int32_t *)(param_1 + 0xf0) == 2) && ((*(uint32_t *)(param_1 + 0x160) & 0x2000) == 0)) {
            *(uint32_t *)(param_1 + 0xac) = ~(*(uint32_t *)(param_1 + 0x9a8) >> 0xf) & 0x20 | 0x12;
            return 1;
        }
    case 0x32:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801cdffa;
        uVar4 = fcn.1802450c0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)(param_1 + 0x88) = uVar4;
        return 2;
    case 0xe:
        *(undefined4 *)(param_1 + 0xac) = 0x10;
        return 1;
    case 0x10:
        *(uint32_t *)(param_1 + 0xac) = (*(int32_t *)(param_1 + 0x340) != 1) + 0x11;
        if ((*(uint8_t *)(param_1 + 0x160) & 0x10) == 0) {
            return 1;
        }
        *(undefined4 *)(param_1 + 0xac) = 0x12;
        return 1;
    case 0x11:
        *(undefined4 *)(param_1 + 0xac) = 0x12;
        return 1;
    case 0x12:
        if (*(int32_t *)(param_1 + 0x8c8) == 1) {
            *(undefined4 *)(param_1 + 0xac) = 0xd;
            return 1;
        }
        if (*(int32_t *)(param_1 + 0xf0) == 2) {
            *(undefined4 *)(param_1 + 0xac) = 0x32;
            return 1;
        }
        if ((uVar6 == 0) && (*(int32_t *)(param_1 + 0x4b4) != 0)) {
            *(undefined4 *)(param_1 + 0xac) = 0x13;
            return 1;
        }
    case 0x13:
        *(undefined4 *)(param_1 + 0xac) = 0x14;
        return 1;
    case 0x14:
        if (*(int32_t *)(param_1 + 0x508) == 0) {
            return 2;
        }
code_r0x0001801ce14e:
        *(undefined4 *)(param_1 + 0xac) = 1;
        return 1;
    case 0x2d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce19e;
        iVar2 = func_0x0001801c5840(param_1, 1);
        if (iVar2 == 0) goto code_r0x0001801ce14e;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce1aa;
        iVar2 = func_0x0001801b24a0(param_1);
        if (iVar2 != 0) {
            *(undefined4 *)(param_1 + 0xac) = 0xd;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ce270
// Address: 0x1801ce270
// Size: 461 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ce270(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ce285;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce297;
    iVar4 = fcn.1801a0300();
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce2a4;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce2bc;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce2d2;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce2fb;
    iVar2 = fcn.1801a85b0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce304;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce31c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce332;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce34c;
    fcn.180197690(in_RCX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce357;
    iVar2 = fcn.180221a50(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
    if (iVar2 < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce360;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce378;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce38e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
         (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) &&
       ((*(int64_t *)(in_RCX + 0x300) != 0 &&
        (*(int32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x18) != *(int32_t *)(iVar4 + 0x18))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce3da;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce3f2;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce408;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8);
    if (iVar6 != 0) {
        *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x300) = *(undefined4 *)(iVar6 + 0x18);
    }
    iVar2 = *(int32_t *)(in_RCX + 0x508);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    if ((iVar2 == 0) || (*(int32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x300) == *(int32_t *)(iVar4 + 0x18))) {
code_r0x0001801ce569:
        *(int64_t *)(in_RCX + 0x300) = iVar4;
        uVar7 = 1;
    } else {
        if (((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
           ((iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304 || (iVar2 == 0x10000)))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce537;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce54f;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce565;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        uVar1 = *(undefined4 *)(iVar4 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce496;
        iVar5 = fcn.1801a08e0(uVar7, uVar1);
        iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce4b1;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce4c9;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce4df;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        if (iVar5 != 0) {
            uVar1 = *(undefined4 *)(iVar6 + 0x40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce4f6;
            iVar6 = fcn.1801a08e0(uVar7, uVar1);
            if (iVar5 == iVar6) goto code_r0x0001801ce569;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce500;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce518;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce52e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801ce43d
// Address: 0x1801ce43d
// Size: 333 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ce270(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ce285;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce297;
    iVar4 = fcn.1801a0300();
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce2a4;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce2bc;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce2d2;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce2fb;
    iVar2 = fcn.1801a85b0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce304;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce31c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce332;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce34c;
    fcn.180197690(in_RCX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce357;
    iVar2 = fcn.180221a50(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
    if (iVar2 < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce360;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce378;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce38e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
         (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) &&
       ((*(int64_t *)(in_RCX + 0x300) != 0 &&
        (*(int32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x18) != *(int32_t *)(iVar4 + 0x18))))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce3da;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce3f2;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce408;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8);
    if (iVar6 != 0) {
        *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x300) = *(undefined4 *)(iVar6 + 0x18);
    }
    iVar2 = *(int32_t *)(in_RCX + 0x508);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    if ((iVar2 == 0) || (*(int32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x300) == *(int32_t *)(iVar4 + 0x18))) {
code_r0x0001801ce569:
        *(int64_t *)(in_RCX + 0x300) = iVar4;
        uVar7 = 1;
    } else {
        if (((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
           ((iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304 || (iVar2 == 0x10000)))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce537;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce54f;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce565;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        uVar1 = *(undefined4 *)(iVar4 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce496;
        iVar5 = fcn.1801a08e0(uVar7, uVar1);
        iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce4b1;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce4c9;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce4df;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        if (iVar5 != 0) {
            uVar1 = *(undefined4 *)(iVar6 + 0x40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce4f6;
            iVar6 = fcn.1801a08e0(uVar7, uVar1);
            if (iVar5 == iVar6) goto code_r0x0001801ce569;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce500;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce518;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ce52e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1801ce590
// Address: 0x1801ce590
// Size: 431 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801ce590(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ce5a5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
    uVar2 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c);
    if ((uVar1 & 0xab) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce5c7;
        fcn.1801b1140();
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce5d8;
        iVar6 = fcn.1801a2080(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
        if ((iVar6 == 0) || ((uVar1 & *(uint32_t *)(iVar6 + 4)) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce6ea;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce702;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
code_r0x0001801ce708:
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce718;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
            return 0;
        }
        if (((uVar2 & 0x41) != 0) && (*(int64_t *)((int64_t)&arg_28h + iVar5) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce5ff;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce617;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce62d;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
            return 0;
        }
        if (((uVar2 & 2) != 0) && (*(int64_t *)(in_RCX + 0x4e0) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce654;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce66c;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce682;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
            return 0;
        }
        if ((*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) == 0) && ((*(uint32_t *)(iVar6 + 4) & 8) != 0)) {
            uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce6bc;
            iVar4 = fcn.1801972c0(uVar3, in_RCX);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce6c5;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ce6dd;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                              *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)(&stack0x00000048 + iVar5));
                goto code_r0x0001801ce708;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801ce740
// Address: 0x1801ce740
// Size: 102 bytes
// ============================================================
undefined8 fcn.1801ce740(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ce74c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ce759;
    iVar1 = func_0x0001801acca0();
    if ((iVar1 != 0) && (*(int64_t *)(param_1 + 0x3d0) != 0)) {
        if ((*(uint32_t *)(*(int64_t *)(param_1 + 0x878) + 0x1c) & 0x30001) != 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar2) = 0xfffffffe;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ce78f;
            iVar1 = func_0x0001801aa4c0(param_1, 0, 0, 0);
            if (iVar1 == 0) {
                return 0;
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801ce7b0
// Address: 0x1801ce7b0
// Size: 271 bytes
// ============================================================
undefined8
fcn.1801ce7b0(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_R14;
    uint64_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_R15;
    uint64_t uVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_38;
    
    uStack_38 = 0x1801ce7c7;
    var_18h = arg3;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar9 = 0;
    uVar12 = 1;
    if ((*(int32_t *)(placeholder_0 + 0xba0) == 0) &&
       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0)) {
        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce810;
        iVar5 = fcn.1801a2690(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
        if ((iVar5 == 0) || (0x301 < *(int32_t *)(placeholder_0 + 0x9b4))) goto code_r0x0001801ce820;
    } else {
code_r0x0001801ce820:
        uVar12 = 0;
    }
    *(uint32_t *)((int64_t)&arg_50h + iVar6) = uVar12;
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce832;
    iVar5 = func_0x0001801a9160(placeholder_0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce83b;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce853;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce869;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_10h + iVar6));
        return 0;
    }
    if (placeholder_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce882;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce89a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce8b0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_10h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = unaff_R15;
    iVar7 = ((uint64_t)uVar12 ^ 1) * 2;
    uVar11 = iVar7 + 0xfffa;
    if ((*(uint8_t *)(placeholder_0 + 0x9b0) & 0x80) == 0) {
        uVar11 = iVar7 + 0xfffc;
    }
    *(uint64_t *)((int64_t)&var_8h + iVar6) = uVar11;
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce8f9;
    iVar5 = fcn.180222010(placeholder_1);
    uVar10 = uVar9;
    uVar13 = uVar9;
    if (0 < iVar5) {
        while (uVar9 < uVar11) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce919;
            iVar7 = fcn.180222340(placeholder_1, uVar13);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce930;
            iVar5 = fcn.1801a85b0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            if (iVar5 == 0) {
                pcVar3 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0xb0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce959;
                iVar5 = (*pcVar3)(iVar7, *(undefined8 *)((int64_t)&arg_60h + iVar6), 
                                  (int64_t)&iStackX_20 + iVar6 + -0x20);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce9fa;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
                    goto code_r0x0001801ce9ff;
                }
                if (uVar10 == 0) {
                    bVar14 = (*(uint32_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) >> 3 & 1) ==
                             0;
                    uVar1 = *(undefined4 *)(placeholder_0 + 0x41c);
                    iVar8 = 0x34;
                    if (bVar14) {
                        iVar8 = 0x2c;
                    }
                    *(undefined4 *)((int64_t)&arg_68h + iVar6) = *(undefined4 *)(iVar8 + iVar7);
                    iVar8 = 0x38;
                    if (bVar14) {
                        iVar8 = 0x30;
                    }
                    uVar2 = *(undefined4 *)(iVar8 + iVar7);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce9b1;
                    iVar5 = fcn.1801afd90(placeholder_0, uVar2, uVar1);
                    if (-1 < iVar5) {
                        uVar1 = *(undefined4 *)(placeholder_0 + 0x41c);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce9cb;
                        iVar5 = fcn.1801afd90(placeholder_0, *(undefined4 *)((int64_t)&arg_68h + iVar6), uVar1);
                        if (iVar5 < 1) {
                            uVar10 = 1;
                        }
                    }
                }
                uVar9 = uVar9 + *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20);
            }
            uVar12 = (int32_t)uVar13 + 1;
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce9e6;
            iVar5 = fcn.180222010(placeholder_1);
            if (iVar5 <= (int32_t)uVar12) break;
            uVar13 = (uint64_t)uVar12;
            uVar11 = *(uint64_t *)((int64_t)&var_8h + iVar6);
        }
        if ((uVar9 != 0) && (uVar10 != 0)) {
            uVar4 = *(undefined8 *)((int64_t)&arg_60h + iVar6);
            if (*(int32_t *)((int64_t)&arg_50h + iVar6) == 0) {
code_r0x0001801cea6c:
                if ((*(uint8_t *)(placeholder_0 + 0x9b0) & 0x80) == 0) {
                    return 1;
                }
                pcVar3 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0xb0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea91;
                iVar5 = (*pcVar3)(0x1804b3b20, uVar4, (int64_t)&iStackX_20 + iVar6 + -0x20);
                if (iVar5 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea9a;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
            } else {
                pcVar3 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0xb0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea5c;
                iVar5 = (*pcVar3)(0x1804b3ad0, uVar4, (int64_t)&iStackX_20 + iVar6 + -0x20);
                if (iVar5 != 0) goto code_r0x0001801cea6c;
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea65;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
            }
code_r0x0001801ce9ff:
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea12;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6)
                          , *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6));
            goto code_r0x0001801ceadf;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ceab0;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ceac8;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
code_r0x0001801ceadf:
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ceaec;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_10h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801ce8bf
// Address: 0x1801ce8bf
// Size: 585 bytes
// ============================================================
undefined8
fcn.1801ce7b0(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_R14;
    uint64_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_R15;
    uint64_t uVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_38;
    
    uStack_38 = 0x1801ce7c7;
    var_18h = arg3;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar9 = 0;
    uVar12 = 1;
    if ((*(int32_t *)(placeholder_0 + 0xba0) == 0) &&
       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) & 8) == 0)) {
        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce810;
        iVar5 = fcn.1801a2690(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
        if ((iVar5 == 0) || (0x301 < *(int32_t *)(placeholder_0 + 0x9b4))) goto code_r0x0001801ce820;
    } else {
code_r0x0001801ce820:
        uVar12 = 0;
    }
    *(uint32_t *)((int64_t)&arg_50h + iVar6) = uVar12;
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce832;
    iVar5 = func_0x0001801a9160(placeholder_0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce83b;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce853;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce869;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_10h + iVar6));
        return 0;
    }
    if (placeholder_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce882;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce89a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce8b0;
        fcn.18019b5e0(*(int64_t *)((int64_t)&var_10h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar6) = unaff_R15;
    iVar7 = ((uint64_t)uVar12 ^ 1) * 2;
    uVar11 = iVar7 + 0xfffa;
    if ((*(uint8_t *)(placeholder_0 + 0x9b0) & 0x80) == 0) {
        uVar11 = iVar7 + 0xfffc;
    }
    *(uint64_t *)((int64_t)&var_8h + iVar6) = uVar11;
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce8f9;
    iVar5 = fcn.180222010(placeholder_1);
    uVar10 = uVar9;
    uVar13 = uVar9;
    if (0 < iVar5) {
        while (uVar9 < uVar11) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce919;
            iVar7 = fcn.180222340(placeholder_1, uVar13);
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce930;
            iVar5 = fcn.1801a85b0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            if (iVar5 == 0) {
                pcVar3 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0xb0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce959;
                iVar5 = (*pcVar3)(iVar7, *(undefined8 *)((int64_t)&arg_60h + iVar6), 
                                  (int64_t)&iStackX_20 + iVar6 + -0x20);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce9fa;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
                    goto code_r0x0001801ce9ff;
                }
                if (uVar10 == 0) {
                    bVar14 = (*(uint32_t *)(*(int64_t *)(*(int64_t *)(placeholder_0 + 0x18) + 0xd8) + 0x50) >> 3 & 1) ==
                             0;
                    uVar1 = *(undefined4 *)(placeholder_0 + 0x41c);
                    iVar8 = 0x34;
                    if (bVar14) {
                        iVar8 = 0x2c;
                    }
                    *(undefined4 *)((int64_t)&arg_68h + iVar6) = *(undefined4 *)(iVar8 + iVar7);
                    iVar8 = 0x38;
                    if (bVar14) {
                        iVar8 = 0x30;
                    }
                    uVar2 = *(undefined4 *)(iVar8 + iVar7);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce9b1;
                    iVar5 = fcn.1801afd90(placeholder_0, uVar2, uVar1);
                    if (-1 < iVar5) {
                        uVar1 = *(undefined4 *)(placeholder_0 + 0x41c);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce9cb;
                        iVar5 = fcn.1801afd90(placeholder_0, *(undefined4 *)((int64_t)&arg_68h + iVar6), uVar1);
                        if (iVar5 < 1) {
                            uVar10 = 1;
                        }
                    }
                }
                uVar9 = uVar9 + *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20);
            }
            uVar12 = (int32_t)uVar13 + 1;
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ce9e6;
            iVar5 = fcn.180222010(placeholder_1);
            if (iVar5 <= (int32_t)uVar12) break;
            uVar13 = (uint64_t)uVar12;
            uVar11 = *(uint64_t *)((int64_t)&var_8h + iVar6);
        }
        if ((uVar9 != 0) && (uVar10 != 0)) {
            uVar4 = *(undefined8 *)((int64_t)&arg_60h + iVar6);
            if (*(int32_t *)((int64_t)&arg_50h + iVar6) == 0) {
code_r0x0001801cea6c:
                if ((*(uint8_t *)(placeholder_0 + 0x9b0) & 0x80) == 0) {
                    return 1;
                }
                pcVar3 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0xb0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea91;
                iVar5 = (*pcVar3)(0x1804b3b20, uVar4, (int64_t)&iStackX_20 + iVar6 + -0x20);
                if (iVar5 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea9a;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
            } else {
                pcVar3 = *(code **)(*(int64_t *)(placeholder_0 + 0x18) + 0xb0);
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea5c;
                iVar5 = (*pcVar3)(0x1804b3ad0, uVar4, (int64_t)&iStackX_20 + iVar6 + -0x20);
                if (iVar5 != 0) goto code_r0x0001801cea6c;
                *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea65;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
            }
code_r0x0001801ce9ff:
            *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801cea12;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6)
                          , *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6));
            goto code_r0x0001801ceadf;
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ceab0;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ceac8;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar6), *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
code_r0x0001801ceadf:
    *(undefined8 *)((int64_t)&uStack_38 + iVar6) = 0x1801ceaec;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_10h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801ceb10
// Address: 0x1801ceb10
// Size: 556 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1801ceb10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_78h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801ceb26;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = *(int64_t *)(in_RCX + 0x4e0);
    iVar3 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
    iVar6 = 0;
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ceb4f;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18)
                     );
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ceb67;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18)
                      , *(int64_t *)((int64_t)&iStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ceb7d;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        iVar6 = iVar3;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ceb8a;
        iVar3 = func_0x0001801c6690();
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ceb97;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18));
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cebaf;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          , *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)&arg_28h + iVar2));
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cebc5;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cebdb;
            iVar1 = func_0x0001801c5dc0(in_RCX, iVar3, iVar4, 0);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cebf0;
                iVar4 = func_0x00018022eef0(iVar3, (int64_t)&arg_28h + iVar2);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cebfd;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cec15;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cec2b;
                    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cec33;
                    fcn.18022ecc0(iVar3);
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cec4e;
                iVar1 = func_0x00018022fbd0(iVar3);
                iVar5 = iVar1 - iVar4;
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cec6c;
                    iVar1 = func_0x000180244b60(in_RDX, iVar5, (int64_t)&arg_38h + iVar2, 2);
                    if (iVar1 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cec75;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cec8d;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ceca3;
                        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
                        goto code_r0x0001801ced09;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cecb4;
                    fcn.1804986e0(*(undefined8 *)((int64_t)&arg_38h + iVar2), 0, iVar5);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cecca;
                iVar1 = func_0x000180244bf0(in_RDX, *(undefined8 *)((int64_t)&arg_28h + iVar2), iVar4, 2);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801cecd3;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ceceb;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ced01;
                    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
                } else {
                    iVar6 = 1;
                }
            }
        }
    }
code_r0x0001801ced09:
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ced20;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar2), 0x1804b3b98, 0xcd0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1801ced28;
    fcn.18022ecc0(iVar3);
    return iVar6;
}

// ============================================================
// Function: FUN_1801ced40
// Address: 0x1801ced40
// Size: 147 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801ced40(int64_t arg_38h, int64_t arg_138h, int64_t arg_188h, int64_t arg_190h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 in_RDX;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801ced51;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_138h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar8 = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced87;
    iVar6 = fcn.1801b1140();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced91;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceda9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cedbf;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    uVar9 = puVar2[0x8c];
    uVar3 = *puVar2;
    *(undefined8 *)((int64_t)&arg_188h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cede0;
    iVar6 = func_0x000180259210(uVar3, iVar6, uVar9);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceded;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee05;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee1b;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    *(undefined8 *)((int64_t)&arg_190h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee41;
    iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee60;
        iVar4 = func_0x000180265330(iVar6);
        if (0 < iVar4) {
            uVar9 = *puVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee7c;
            iVar4 = func_0x00018021b9c0(uVar9, iVar7, 0x20, 0);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee89;
                iVar8 = fcn.180215470();
                if (iVar8 != 0) {
                    uVar9 = 0x3d6;
                    if ((uVar1 & 0x80) == 0) {
                        uVar9 = 0x329;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceea9;
                    uVar9 = fcn.18022ccf0(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceeb1;
                    func_0x00018022e160(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceebc;
                    iVar4 = fcn.180214840(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                         );
                    if (0 < iVar4) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceed9;
                        iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                              *(int64_t *)(&stack0x00000040 + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar5));
                        if (0 < iVar4) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceef6;
                            iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                  *(int64_t *)(&stack0x00000030 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                  *(int64_t *)(&stack0x00000040 + iVar5), 
                                                  *(int64_t *)(&stack0x00000048 + iVar5));
                            if (0 < iVar4) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef10;
                                iVar4 = fcn.1802146d0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar5));
                                if (0 < iVar4) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef20;
                                    fcn.180215310(iVar8);
                                    *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) =
                                         (int64_t)&iStackX_20 + iVar5 + -8;
                                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 8;
                                    iVar8 = 0;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef4d;
                                    iVar4 = fcn.180258740(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                                          *(int64_t *)(&stack0x00000028 + iVar5), 
                                                          *(int64_t *)(&stack0x00000030 + iVar5), 
                                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                          *(int64_t *)(&stack0x00000040 + iVar5));
                                    if (0 < iVar4) {
                                        *(undefined8 *)((int64_t)&uStackX_8 + iVar5) = 0xff;
                                        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0x20;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef87;
                                        iVar4 = func_0x000180265070(iVar6, (int64_t)&arg_38h + iVar5, 
                                                                    (int64_t)&uStackX_8 + iVar5, iVar7);
                                        if (0 < iVar4) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefad;
                                            iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                                            if (iVar4 != 0) {
                                                uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                if (0x7f < uVar10) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefd2;
                                                    iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                                                    if (iVar4 == 0) goto code_r0x0001801cf02b;
                                                    uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefee;
                                                iVar4 = func_0x000180244bf0(in_RDX, (int64_t)&arg_38h + iVar5, uVar10, 1
                                                                           );
                                                if (iVar4 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceffa;
                                                    fcn.180258be0(iVar6);
                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                    goto code_r0x0001801cf094;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x0001801cf02b:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf030;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf045;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf058;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf060;
    fcn.180258be0(iVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf07a;
    fcn.180224b90(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf082;
    fcn.180215310(iVar8);
code_r0x0001801cf094:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf0a4;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_138h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801cedd3
// Address: 0x1801cedd3
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801ced40(int64_t arg_38h, int64_t arg_138h, int64_t arg_188h, int64_t arg_190h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 in_RDX;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801ced51;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_138h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar8 = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced87;
    iVar6 = fcn.1801b1140();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced91;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceda9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cedbf;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    uVar9 = puVar2[0x8c];
    uVar3 = *puVar2;
    *(undefined8 *)((int64_t)&arg_188h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cede0;
    iVar6 = func_0x000180259210(uVar3, iVar6, uVar9);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceded;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee05;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee1b;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    *(undefined8 *)((int64_t)&arg_190h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee41;
    iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee60;
        iVar4 = func_0x000180265330(iVar6);
        if (0 < iVar4) {
            uVar9 = *puVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee7c;
            iVar4 = func_0x00018021b9c0(uVar9, iVar7, 0x20, 0);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee89;
                iVar8 = fcn.180215470();
                if (iVar8 != 0) {
                    uVar9 = 0x3d6;
                    if ((uVar1 & 0x80) == 0) {
                        uVar9 = 0x329;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceea9;
                    uVar9 = fcn.18022ccf0(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceeb1;
                    func_0x00018022e160(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceebc;
                    iVar4 = fcn.180214840(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                         );
                    if (0 < iVar4) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceed9;
                        iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                              *(int64_t *)(&stack0x00000040 + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar5));
                        if (0 < iVar4) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceef6;
                            iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                  *(int64_t *)(&stack0x00000030 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                  *(int64_t *)(&stack0x00000040 + iVar5), 
                                                  *(int64_t *)(&stack0x00000048 + iVar5));
                            if (0 < iVar4) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef10;
                                iVar4 = fcn.1802146d0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar5));
                                if (0 < iVar4) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef20;
                                    fcn.180215310(iVar8);
                                    *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) =
                                         (int64_t)&iStackX_20 + iVar5 + -8;
                                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 8;
                                    iVar8 = 0;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef4d;
                                    iVar4 = fcn.180258740(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                                          *(int64_t *)(&stack0x00000028 + iVar5), 
                                                          *(int64_t *)(&stack0x00000030 + iVar5), 
                                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                          *(int64_t *)(&stack0x00000040 + iVar5));
                                    if (0 < iVar4) {
                                        *(undefined8 *)((int64_t)&uStackX_8 + iVar5) = 0xff;
                                        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0x20;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef87;
                                        iVar4 = func_0x000180265070(iVar6, (int64_t)&arg_38h + iVar5, 
                                                                    (int64_t)&uStackX_8 + iVar5, iVar7);
                                        if (0 < iVar4) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefad;
                                            iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                                            if (iVar4 != 0) {
                                                uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                if (0x7f < uVar10) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefd2;
                                                    iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                                                    if (iVar4 == 0) goto code_r0x0001801cf02b;
                                                    uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefee;
                                                iVar4 = func_0x000180244bf0(in_RDX, (int64_t)&arg_38h + iVar5, uVar10, 1
                                                                           );
                                                if (iVar4 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceffa;
                                                    fcn.180258be0(iVar6);
                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                    goto code_r0x0001801cf094;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x0001801cf02b:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf030;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf045;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf058;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf060;
    fcn.180258be0(iVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf07a;
    fcn.180224b90(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf082;
    fcn.180215310(iVar8);
code_r0x0001801cf094:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf0a4;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_138h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801cee28
// Address: 0x1801cee28
// Size: 612 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801ced40(int64_t arg_38h, int64_t arg_138h, int64_t arg_188h, int64_t arg_190h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 in_RDX;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801ced51;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_138h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar8 = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced87;
    iVar6 = fcn.1801b1140();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced91;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceda9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cedbf;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    uVar9 = puVar2[0x8c];
    uVar3 = *puVar2;
    *(undefined8 *)((int64_t)&arg_188h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cede0;
    iVar6 = func_0x000180259210(uVar3, iVar6, uVar9);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceded;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee05;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee1b;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    *(undefined8 *)((int64_t)&arg_190h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee41;
    iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee60;
        iVar4 = func_0x000180265330(iVar6);
        if (0 < iVar4) {
            uVar9 = *puVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee7c;
            iVar4 = func_0x00018021b9c0(uVar9, iVar7, 0x20, 0);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee89;
                iVar8 = fcn.180215470();
                if (iVar8 != 0) {
                    uVar9 = 0x3d6;
                    if ((uVar1 & 0x80) == 0) {
                        uVar9 = 0x329;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceea9;
                    uVar9 = fcn.18022ccf0(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceeb1;
                    func_0x00018022e160(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceebc;
                    iVar4 = fcn.180214840(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                         );
                    if (0 < iVar4) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceed9;
                        iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                              *(int64_t *)(&stack0x00000040 + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar5));
                        if (0 < iVar4) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceef6;
                            iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                  *(int64_t *)(&stack0x00000030 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                  *(int64_t *)(&stack0x00000040 + iVar5), 
                                                  *(int64_t *)(&stack0x00000048 + iVar5));
                            if (0 < iVar4) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef10;
                                iVar4 = fcn.1802146d0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar5));
                                if (0 < iVar4) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef20;
                                    fcn.180215310(iVar8);
                                    *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) =
                                         (int64_t)&iStackX_20 + iVar5 + -8;
                                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 8;
                                    iVar8 = 0;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef4d;
                                    iVar4 = fcn.180258740(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                                          *(int64_t *)(&stack0x00000028 + iVar5), 
                                                          *(int64_t *)(&stack0x00000030 + iVar5), 
                                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                          *(int64_t *)(&stack0x00000040 + iVar5));
                                    if (0 < iVar4) {
                                        *(undefined8 *)((int64_t)&uStackX_8 + iVar5) = 0xff;
                                        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0x20;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef87;
                                        iVar4 = func_0x000180265070(iVar6, (int64_t)&arg_38h + iVar5, 
                                                                    (int64_t)&uStackX_8 + iVar5, iVar7);
                                        if (0 < iVar4) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefad;
                                            iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                                            if (iVar4 != 0) {
                                                uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                if (0x7f < uVar10) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefd2;
                                                    iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                                                    if (iVar4 == 0) goto code_r0x0001801cf02b;
                                                    uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefee;
                                                iVar4 = func_0x000180244bf0(in_RDX, (int64_t)&arg_38h + iVar5, uVar10, 1
                                                                           );
                                                if (iVar4 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceffa;
                                                    fcn.180258be0(iVar6);
                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                    goto code_r0x0001801cf094;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x0001801cf02b:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf030;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf045;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf058;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf060;
    fcn.180258be0(iVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf07a;
    fcn.180224b90(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf082;
    fcn.180215310(iVar8);
code_r0x0001801cf094:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf0a4;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_138h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801cf08c
// Address: 0x1801cf08c
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801ced40(int64_t arg_38h, int64_t arg_138h, int64_t arg_188h, int64_t arg_190h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 in_RDX;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801ced51;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_138h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar8 = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced87;
    iVar6 = fcn.1801b1140();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced91;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceda9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cedbf;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    uVar9 = puVar2[0x8c];
    uVar3 = *puVar2;
    *(undefined8 *)((int64_t)&arg_188h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cede0;
    iVar6 = func_0x000180259210(uVar3, iVar6, uVar9);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceded;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee05;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee1b;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    *(undefined8 *)((int64_t)&arg_190h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee41;
    iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee60;
        iVar4 = func_0x000180265330(iVar6);
        if (0 < iVar4) {
            uVar9 = *puVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee7c;
            iVar4 = func_0x00018021b9c0(uVar9, iVar7, 0x20, 0);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee89;
                iVar8 = fcn.180215470();
                if (iVar8 != 0) {
                    uVar9 = 0x3d6;
                    if ((uVar1 & 0x80) == 0) {
                        uVar9 = 0x329;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceea9;
                    uVar9 = fcn.18022ccf0(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceeb1;
                    func_0x00018022e160(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceebc;
                    iVar4 = fcn.180214840(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                         );
                    if (0 < iVar4) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceed9;
                        iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                              *(int64_t *)(&stack0x00000040 + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar5));
                        if (0 < iVar4) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceef6;
                            iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                  *(int64_t *)(&stack0x00000030 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                  *(int64_t *)(&stack0x00000040 + iVar5), 
                                                  *(int64_t *)(&stack0x00000048 + iVar5));
                            if (0 < iVar4) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef10;
                                iVar4 = fcn.1802146d0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar5));
                                if (0 < iVar4) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef20;
                                    fcn.180215310(iVar8);
                                    *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) =
                                         (int64_t)&iStackX_20 + iVar5 + -8;
                                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 8;
                                    iVar8 = 0;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef4d;
                                    iVar4 = fcn.180258740(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                                          *(int64_t *)(&stack0x00000028 + iVar5), 
                                                          *(int64_t *)(&stack0x00000030 + iVar5), 
                                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                          *(int64_t *)(&stack0x00000040 + iVar5));
                                    if (0 < iVar4) {
                                        *(undefined8 *)((int64_t)&uStackX_8 + iVar5) = 0xff;
                                        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0x20;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef87;
                                        iVar4 = func_0x000180265070(iVar6, (int64_t)&arg_38h + iVar5, 
                                                                    (int64_t)&uStackX_8 + iVar5, iVar7);
                                        if (0 < iVar4) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefad;
                                            iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                                            if (iVar4 != 0) {
                                                uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                if (0x7f < uVar10) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefd2;
                                                    iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                                                    if (iVar4 == 0) goto code_r0x0001801cf02b;
                                                    uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefee;
                                                iVar4 = func_0x000180244bf0(in_RDX, (int64_t)&arg_38h + iVar5, uVar10, 1
                                                                           );
                                                if (iVar4 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceffa;
                                                    fcn.180258be0(iVar6);
                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                    goto code_r0x0001801cf094;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x0001801cf02b:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf030;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf045;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf058;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf060;
    fcn.180258be0(iVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf07a;
    fcn.180224b90(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf082;
    fcn.180215310(iVar8);
code_r0x0001801cf094:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf0a4;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_138h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801cf094
// Address: 0x1801cf094
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801ced40(int64_t arg_38h, int64_t arg_138h, int64_t arg_188h, int64_t arg_190h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 uVar9;
    undefined8 in_RDX;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801ced51;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_138h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    puVar2 = *(undefined8 **)(in_RCX + 8);
    iVar8 = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced87;
    iVar6 = fcn.1801b1140();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ced91;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceda9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cedbf;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    uVar9 = puVar2[0x8c];
    uVar3 = *puVar2;
    *(undefined8 *)((int64_t)&arg_188h + iVar5) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cede0;
    iVar6 = func_0x000180259210(uVar3, iVar6, uVar9);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceded;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee05;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5));
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee1b;
        fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        goto code_r0x0001801cf094;
    }
    *(undefined8 *)((int64_t)&arg_190h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee41;
    iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee60;
        iVar4 = func_0x000180265330(iVar6);
        if (0 < iVar4) {
            uVar9 = *puVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee7c;
            iVar4 = func_0x00018021b9c0(uVar9, iVar7, 0x20, 0);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cee89;
                iVar8 = fcn.180215470();
                if (iVar8 != 0) {
                    uVar9 = 0x3d6;
                    if ((uVar1 & 0x80) == 0) {
                        uVar9 = 0x329;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceea9;
                    uVar9 = fcn.18022ccf0(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceeb1;
                    func_0x00018022e160(uVar9);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceebc;
                    iVar4 = fcn.180214840(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                          *(int64_t *)(&stack0x00000040 + iVar5), *(int64_t *)(&stack0x00000048 + iVar5)
                                         );
                    if (0 < iVar4) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceed9;
                        iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)(&stack0x00000030 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                              *(int64_t *)(&stack0x00000040 + iVar5), 
                                              *(int64_t *)(&stack0x00000048 + iVar5));
                        if (0 < iVar4) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceef6;
                            iVar4 = fcn.1802149b0(*(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar5), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                  *(int64_t *)(&stack0x00000030 + iVar5), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                  *(int64_t *)(&stack0x00000040 + iVar5), 
                                                  *(int64_t *)(&stack0x00000048 + iVar5));
                            if (0 < iVar4) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef10;
                                iVar4 = fcn.1802146d0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                      *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar5));
                                if (0 < iVar4) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef20;
                                    fcn.180215310(iVar8);
                                    *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) =
                                         (int64_t)&iStackX_20 + iVar5 + -8;
                                    *(undefined4 *)((int64_t)&var_8h + iVar5) = 8;
                                    iVar8 = 0;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef4d;
                                    iVar4 = fcn.180258740(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                                          *(int64_t *)(&stack0x00000028 + iVar5), 
                                                          *(int64_t *)(&stack0x00000030 + iVar5), 
                                                          *(int64_t *)((int64_t)&arg_38h + iVar5), 
                                                          *(int64_t *)(&stack0x00000040 + iVar5));
                                    if (0 < iVar4) {
                                        *(undefined8 *)((int64_t)&uStackX_8 + iVar5) = 0xff;
                                        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0x20;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cef87;
                                        iVar4 = func_0x000180265070(iVar6, (int64_t)&arg_38h + iVar5, 
                                                                    (int64_t)&uStackX_8 + iVar5, iVar7);
                                        if (0 < iVar4) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefad;
                                            iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                  *(int64_t *)((int64_t)&arg_38h + iVar5));
                                            if (iVar4 != 0) {
                                                uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                if (0x7f < uVar10) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefd2;
                                                    iVar4 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar5 + -0x20), 
                                                                          *(int64_t *)((int64_t)&uStackX_8 + iVar5), 
                                                                          *(int64_t *)((int64_t)&arg_38h + iVar5));
                                                    if (iVar4 == 0) goto code_r0x0001801cf02b;
                                                    uVar10 = *(uint64_t *)((int64_t)&uStackX_8 + iVar5);
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cefee;
                                                iVar4 = func_0x000180244bf0(in_RDX, (int64_t)&arg_38h + iVar5, uVar10, 1
                                                                           );
                                                if (iVar4 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801ceffa;
                                                    fcn.180258be0(iVar6);
                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                    goto code_r0x0001801cf094;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x0001801cf02b:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf030;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf045;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                  *(int64_t *)((int64_t)&uStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf058;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf060;
    fcn.180258be0(iVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf07a;
    fcn.180224b90(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf082;
    fcn.180215310(iVar8);
code_r0x0001801cf094:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801cf0a4;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_138h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801cf0c0
// Address: 0x1801cf0c0
// Size: 113 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_184h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_164h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel

void fcn.1801cf0c0(int64_t arg_38h, int64_t arg_98h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801cf0d6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x24);
    if ((uVar1 >> 0x16 & 1) == 0) {
        if ((uVar1 >> 0x17 & 1) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf43d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf455;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf46b;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar6));
            goto code_r0x0001801cf39a;
        }
        uVar11 = 0x3f5;
    } else {
        uVar11 = 0x4a4;
    }
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf148;
    iVar7 = fcn.180197550(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
    iVar10 = 0;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf159;
        iVar8 = fcn.180215470();
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf170;
            iVar5 = fcn.180214840(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf18d;
                iVar5 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6)
                                      , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6));
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1aa;
                    iVar5 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                          *(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar6));
                    if (0 < iVar5) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1c4;
                        iVar5 = fcn.1802146d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        if (0 < iVar5) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1d4;
                            fcn.180215310(iVar8);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1dc;
                            fcn.1801975c0(iVar7);
                            *(undefined8 *)((int64_t)&var_8h + iVar6) = 0x20;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1fc;
                            iVar7 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            iVar10 = iVar9;
                            if (iVar7 != 0) {
                                uVar3 = *puVar2;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf227;
                                iVar5 = func_0x00018021b9c0(uVar3, iVar7, 0x20, 0);
                                if (0 < iVar5) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf23d;
                                    iVar9 = fcn.1801b1140(in_RCX);
                                    if (iVar9 != 0) {
                                        uVar3 = puVar2[0x8c];
                                        uVar4 = *puVar2;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf268;
                                        iVar10 = func_0x000180259210(uVar4, iVar9, uVar3);
                                        if (iVar10 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf287;
                                            iVar5 = func_0x000180265330(iVar10);
                                            if (0 < iVar5) {
                                                *(int64_t *)(&stack0xfffffffffffffff0 + iVar6) =
                                                     (int64_t)&iStackX_20 + iVar6 + -8;
                                                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20;
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf2c0;
                                                iVar5 = fcn.180258740(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                                      *(int64_t *)(&stack0x00000028 + iVar6), 
                                                                      *(int64_t *)(&stack0x00000030 + iVar6));
                                                if (0 < iVar5) {
                                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6) = 0;
                                                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = uVar11;
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf2fa;
                                                    iVar5 = fcn.180258740(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar6 + -8), 
                                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                                          *(int64_t *)(&stack0x00000028 + iVar6), 
                                                                          *(int64_t *)(&stack0x00000030 + iVar6));
                                                    if (0 < iVar5) {
                                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20;
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf328;
                                                        iVar5 = func_0x000180265070(iVar10, 0, 
                                                                                    &stack0xfffffffffffffff8 + iVar6, 
                                                                                    iVar7);
                                                        if (0 < iVar5) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf34d;
                                                            iVar5 = fcn.180243f60(*(int64_t *)
                                                                                   (&stack0xffffffffffffffe8 + iVar6), 
                                                                                  *(int64_t *)
                                                                                   ((int64_t)&iStackX_20 + iVar6 + -8));
                                                            if (iVar5 != 0) {
                                                                uVar3 = *(undefined8 *)
                                                                         ((int64_t)&iStackX_20 + iVar6 + -0x20);
                                                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20
                                                                ;
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) =
                                                                     0x1801cf36f;
                                                                iVar5 = func_0x000180265070(iVar10, uVar3, 
                                                                                            &stack0xfffffffffffffff8 +
                                                                                            iVar6, iVar7);
                                                                if (0 < iVar5) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) =
                                                                         0x1801cf37b;
                                                                    fcn.180258be0(iVar10);
                                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                                    goto code_r0x0001801cf39a;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            goto code_r0x0001801cf3e5;
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ce;
        fcn.180215310(iVar8);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3d6;
        fcn.1801975c0(iVar7);
    }
code_r0x0001801cf3e5:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ea;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ff;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf40f;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf417;
    fcn.180258be0(iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf431;
    fcn.180224b90(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
code_r0x0001801cf39a:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3a7;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801cf131
// Address: 0x1801cf131
// Size: 617 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_184h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_164h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel

void fcn.1801cf0c0(int64_t arg_38h, int64_t arg_98h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801cf0d6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x24);
    if ((uVar1 >> 0x16 & 1) == 0) {
        if ((uVar1 >> 0x17 & 1) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf43d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf455;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf46b;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar6));
            goto code_r0x0001801cf39a;
        }
        uVar11 = 0x3f5;
    } else {
        uVar11 = 0x4a4;
    }
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf148;
    iVar7 = fcn.180197550(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
    iVar10 = 0;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf159;
        iVar8 = fcn.180215470();
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf170;
            iVar5 = fcn.180214840(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf18d;
                iVar5 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6)
                                      , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6));
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1aa;
                    iVar5 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                          *(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar6));
                    if (0 < iVar5) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1c4;
                        iVar5 = fcn.1802146d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        if (0 < iVar5) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1d4;
                            fcn.180215310(iVar8);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1dc;
                            fcn.1801975c0(iVar7);
                            *(undefined8 *)((int64_t)&var_8h + iVar6) = 0x20;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1fc;
                            iVar7 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            iVar10 = iVar9;
                            if (iVar7 != 0) {
                                uVar3 = *puVar2;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf227;
                                iVar5 = func_0x00018021b9c0(uVar3, iVar7, 0x20, 0);
                                if (0 < iVar5) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf23d;
                                    iVar9 = fcn.1801b1140(in_RCX);
                                    if (iVar9 != 0) {
                                        uVar3 = puVar2[0x8c];
                                        uVar4 = *puVar2;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf268;
                                        iVar10 = func_0x000180259210(uVar4, iVar9, uVar3);
                                        if (iVar10 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf287;
                                            iVar5 = func_0x000180265330(iVar10);
                                            if (0 < iVar5) {
                                                *(int64_t *)(&stack0xfffffffffffffff0 + iVar6) =
                                                     (int64_t)&iStackX_20 + iVar6 + -8;
                                                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20;
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf2c0;
                                                iVar5 = fcn.180258740(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                                      *(int64_t *)(&stack0x00000028 + iVar6), 
                                                                      *(int64_t *)(&stack0x00000030 + iVar6));
                                                if (0 < iVar5) {
                                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6) = 0;
                                                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = uVar11;
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf2fa;
                                                    iVar5 = fcn.180258740(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar6 + -8), 
                                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                                          *(int64_t *)(&stack0x00000028 + iVar6), 
                                                                          *(int64_t *)(&stack0x00000030 + iVar6));
                                                    if (0 < iVar5) {
                                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20;
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf328;
                                                        iVar5 = func_0x000180265070(iVar10, 0, 
                                                                                    &stack0xfffffffffffffff8 + iVar6, 
                                                                                    iVar7);
                                                        if (0 < iVar5) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf34d;
                                                            iVar5 = fcn.180243f60(*(int64_t *)
                                                                                   (&stack0xffffffffffffffe8 + iVar6), 
                                                                                  *(int64_t *)
                                                                                   ((int64_t)&iStackX_20 + iVar6 + -8));
                                                            if (iVar5 != 0) {
                                                                uVar3 = *(undefined8 *)
                                                                         ((int64_t)&iStackX_20 + iVar6 + -0x20);
                                                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20
                                                                ;
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) =
                                                                     0x1801cf36f;
                                                                iVar5 = func_0x000180265070(iVar10, uVar3, 
                                                                                            &stack0xfffffffffffffff8 +
                                                                                            iVar6, iVar7);
                                                                if (0 < iVar5) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) =
                                                                         0x1801cf37b;
                                                                    fcn.180258be0(iVar10);
                                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                                    goto code_r0x0001801cf39a;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            goto code_r0x0001801cf3e5;
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ce;
        fcn.180215310(iVar8);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3d6;
        fcn.1801975c0(iVar7);
    }
code_r0x0001801cf3e5:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ea;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ff;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf40f;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf417;
    fcn.180258be0(iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf431;
    fcn.180224b90(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
code_r0x0001801cf39a:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3a7;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801cf39a
// Address: 0x1801cf39a
// Size: 32 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_184h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_164h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel

void fcn.1801cf0c0(int64_t arg_38h, int64_t arg_98h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801cf0d6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x24);
    if ((uVar1 >> 0x16 & 1) == 0) {
        if ((uVar1 >> 0x17 & 1) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf43d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf455;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf46b;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar6));
            goto code_r0x0001801cf39a;
        }
        uVar11 = 0x3f5;
    } else {
        uVar11 = 0x4a4;
    }
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf148;
    iVar7 = fcn.180197550(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
    iVar10 = 0;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf159;
        iVar8 = fcn.180215470();
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf170;
            iVar5 = fcn.180214840(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf18d;
                iVar5 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6)
                                      , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6));
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1aa;
                    iVar5 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                          *(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar6));
                    if (0 < iVar5) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1c4;
                        iVar5 = fcn.1802146d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        if (0 < iVar5) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1d4;
                            fcn.180215310(iVar8);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1dc;
                            fcn.1801975c0(iVar7);
                            *(undefined8 *)((int64_t)&var_8h + iVar6) = 0x20;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1fc;
                            iVar7 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            iVar10 = iVar9;
                            if (iVar7 != 0) {
                                uVar3 = *puVar2;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf227;
                                iVar5 = func_0x00018021b9c0(uVar3, iVar7, 0x20, 0);
                                if (0 < iVar5) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf23d;
                                    iVar9 = fcn.1801b1140(in_RCX);
                                    if (iVar9 != 0) {
                                        uVar3 = puVar2[0x8c];
                                        uVar4 = *puVar2;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf268;
                                        iVar10 = func_0x000180259210(uVar4, iVar9, uVar3);
                                        if (iVar10 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf287;
                                            iVar5 = func_0x000180265330(iVar10);
                                            if (0 < iVar5) {
                                                *(int64_t *)(&stack0xfffffffffffffff0 + iVar6) =
                                                     (int64_t)&iStackX_20 + iVar6 + -8;
                                                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20;
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf2c0;
                                                iVar5 = fcn.180258740(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                                      *(int64_t *)(&stack0x00000028 + iVar6), 
                                                                      *(int64_t *)(&stack0x00000030 + iVar6));
                                                if (0 < iVar5) {
                                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6) = 0;
                                                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = uVar11;
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf2fa;
                                                    iVar5 = fcn.180258740(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar6 + -8), 
                                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                                          *(int64_t *)(&stack0x00000028 + iVar6), 
                                                                          *(int64_t *)(&stack0x00000030 + iVar6));
                                                    if (0 < iVar5) {
                                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20;
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf328;
                                                        iVar5 = func_0x000180265070(iVar10, 0, 
                                                                                    &stack0xfffffffffffffff8 + iVar6, 
                                                                                    iVar7);
                                                        if (0 < iVar5) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf34d;
                                                            iVar5 = fcn.180243f60(*(int64_t *)
                                                                                   (&stack0xffffffffffffffe8 + iVar6), 
                                                                                  *(int64_t *)
                                                                                   ((int64_t)&iStackX_20 + iVar6 + -8));
                                                            if (iVar5 != 0) {
                                                                uVar3 = *(undefined8 *)
                                                                         ((int64_t)&iStackX_20 + iVar6 + -0x20);
                                                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20
                                                                ;
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) =
                                                                     0x1801cf36f;
                                                                iVar5 = func_0x000180265070(iVar10, uVar3, 
                                                                                            &stack0xfffffffffffffff8 +
                                                                                            iVar6, iVar7);
                                                                if (0 < iVar5) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) =
                                                                         0x1801cf37b;
                                                                    fcn.180258be0(iVar10);
                                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                                    goto code_r0x0001801cf39a;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            goto code_r0x0001801cf3e5;
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ce;
        fcn.180215310(iVar8);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3d6;
        fcn.1801975c0(iVar7);
    }
code_r0x0001801cf3e5:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ea;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ff;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf40f;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf417;
    fcn.180258be0(iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf431;
    fcn.180224b90(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
code_r0x0001801cf39a:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3a7;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801cf3ba
// Address: 0x1801cf3ba
// Size: 126 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_184h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_164h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3b8h because it doesn't fit into ProtoModel

void fcn.1801cf0c0(int64_t arg_38h, int64_t arg_98h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined4 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801cf0d6;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_38h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar6 + -0x20) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x24);
    if ((uVar1 >> 0x16 & 1) == 0) {
        if ((uVar1 >> 0x17 & 1) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf43d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf455;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf46b;
            fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar6));
            goto code_r0x0001801cf39a;
        }
        uVar11 = 0x3f5;
    } else {
        uVar11 = 0x4a4;
    }
    puVar2 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf148;
    iVar7 = fcn.180197550(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
    iVar10 = 0;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf159;
        iVar8 = fcn.180215470();
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf170;
            iVar5 = fcn.180214840(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf18d;
                iVar5 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6)
                                      , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar6));
                if (0 < iVar5) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1aa;
                    iVar5 = fcn.1802149b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                          *(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                          *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar6));
                    if (0 < iVar5) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1c4;
                        iVar5 = fcn.1802146d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        if (0 < iVar5) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1d4;
                            fcn.180215310(iVar8);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1dc;
                            fcn.1801975c0(iVar7);
                            *(undefined8 *)((int64_t)&var_8h + iVar6) = 0x20;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf1fc;
                            iVar7 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            iVar10 = iVar9;
                            if (iVar7 != 0) {
                                uVar3 = *puVar2;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf227;
                                iVar5 = func_0x00018021b9c0(uVar3, iVar7, 0x20, 0);
                                if (0 < iVar5) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf23d;
                                    iVar9 = fcn.1801b1140(in_RCX);
                                    if (iVar9 != 0) {
                                        uVar3 = puVar2[0x8c];
                                        uVar4 = *puVar2;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf268;
                                        iVar10 = func_0x000180259210(uVar4, iVar9, uVar3);
                                        if (iVar10 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf287;
                                            iVar5 = func_0x000180265330(iVar10);
                                            if (0 < iVar5) {
                                                *(int64_t *)(&stack0xfffffffffffffff0 + iVar6) =
                                                     (int64_t)&iStackX_20 + iVar6 + -8;
                                                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20;
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf2c0;
                                                iVar5 = fcn.180258740(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                                                      *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                                      *(int64_t *)(&stack0x00000028 + iVar6), 
                                                                      *(int64_t *)(&stack0x00000030 + iVar6));
                                                if (0 < iVar5) {
                                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar6) = 0;
                                                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar6) = uVar11;
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf2fa;
                                                    iVar5 = fcn.180258740(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                                                          *(int64_t *)
                                                                           ((int64_t)&iStackX_20 + iVar6 + -8), 
                                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                                          *(int64_t *)(&stack0x00000028 + iVar6), 
                                                                          *(int64_t *)(&stack0x00000030 + iVar6));
                                                    if (0 < iVar5) {
                                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20;
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf328;
                                                        iVar5 = func_0x000180265070(iVar10, 0, 
                                                                                    &stack0xfffffffffffffff8 + iVar6, 
                                                                                    iVar7);
                                                        if (0 < iVar5) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf34d;
                                                            iVar5 = fcn.180243f60(*(int64_t *)
                                                                                   (&stack0xffffffffffffffe8 + iVar6), 
                                                                                  *(int64_t *)
                                                                                   ((int64_t)&iStackX_20 + iVar6 + -8));
                                                            if (iVar5 != 0) {
                                                                uVar3 = *(undefined8 *)
                                                                         ((int64_t)&iStackX_20 + iVar6 + -0x20);
                                                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar6) = 0x20
                                                                ;
                                                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) =
                                                                     0x1801cf36f;
                                                                iVar5 = func_0x000180265070(iVar10, uVar3, 
                                                                                            &stack0xfffffffffffffff8 +
                                                                                            iVar6, iVar7);
                                                                if (0 < iVar5) {
                                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) =
                                                                         0x1801cf37b;
                                                                    fcn.180258be0(iVar10);
                                                                    *(int64_t *)(in_RCX + 0x3b0) = iVar7;
                                                                    *(undefined8 *)(in_RCX + 0x3b8) = 0x20;
                                                                    goto code_r0x0001801cf39a;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            goto code_r0x0001801cf3e5;
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ce;
        fcn.180215310(iVar8);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3d6;
        fcn.1801975c0(iVar7);
    }
code_r0x0001801cf3e5:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ea;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3ff;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf40f;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_8h + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf417;
    fcn.180258be0(iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf431;
    fcn.180224b90(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
code_r0x0001801cf39a:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801cf3a7;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6));
    return;
}

