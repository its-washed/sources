// Chunk 13 - 50 functions

// ============================================================
// Function: FUN_1800219d0
// Address: 0x1800219d0
// Size: 1149 bytes
// ============================================================
void fcn.1800219d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t *piVar5;
    double *pdVar6;
    uint32_t *puVar7;
    code *pcVar8;
    undefined auVar9 [16];
    int32_t iVar10;
    int32_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    undefined8 *puVar15;
    undefined (*pauVar16) [16];
    uint64_t unaff_RBX;
    undefined8 *puVar17;
    int64_t unaff_RBP;
    undefined4 uVar18;
    int64_t unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar19;
    uint32_t uVar20;
    uint64_t uVar21;
    uint64_t unaff_R14;
    undefined8 uVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_28h;
    undefined4 uStack_1c;
    int64_t var_18h;
    undefined4 uStack_c;
    
    iVar10 = (int32_t)arg3;
    iVar19 = (int64_t)iVar10;
    if (iVar10 < 1) {
        if (iVar10 < -9999) {
            uVar13 = func_0x000180085370(arg1, arg3 & 0xffffffff);
        } else {
            uVar13 = iVar19 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar13 = *(int64_t *)(arg1 + 0x28) + -0x10 + iVar19 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar13) {
            uVar13 = *(uint64_t *)0x180782430;
        }
    }
    if (uVar13 != *(uint64_t *)0x180782430) {
        iVar11 = *(int32_t *)(uVar13 + 0xc);
        if (iVar11 == 3) {
            uVar22 = func_0x000180085ea0(arg1, arg3 & 0xffffffff, 0);
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar10 = func_0x000180085510(arg2, 1), iVar10 == 0)) {
                func_0x000180099450(arg2, 0x18063d8d0);
                func_0x000180087960(arg2);
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            puVar15 = *(undefined8 **)(arg2 + 0x40);
            *puVar15 = uVar22;
            *(undefined4 *)((int64_t)puVar15 + 0xc) = 3;
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            return;
        }
        if (iVar11 == 4) {
            iVar10 = func_0x000180085f50(arg1, arg3 & 0xffffffff, 0);
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar11 = func_0x000180085510(arg2, 1), iVar11 == 0)) {
                func_0x000180099450(arg2, 0x18063d8d0);
                func_0x000180087960(arg2);
                pcVar8 = (code *)swi(3);
                (*pcVar8)();
                return;
            }
            pdVar6 = *(double **)(arg2 + 0x40);
            *(undefined4 *)((int64_t)pdVar6 + 0xc) = 3;
            *pdVar6 = (double)iVar10;
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            return;
        }
        if (iVar11 == 6) {
            iVar19 = func_0x0001800860c0(arg1, arg3 & 0xffffffff, 0);
            if (iVar19 != 0) {
                uVar22 = func_0x000180498cd0(iVar19);
                if (*(uint64_t *)(*(int64_t *)(arg2 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg2 + 0x20) + 0x30))
                {
                    (**(code **)0x180782658)(arg2, 1);
                }
                if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U)) &&
                   (iVar10 = func_0x000180085510(arg2, 1), iVar10 == 0)) {
                    func_0x000180099450(arg2, 0x18063d8d0);
                    func_0x000180087960(arg2);
                    pcVar8 = (code *)swi(3);
                    (*pcVar8)();
                    return;
                }
                puVar15 = *(undefined8 **)(arg2 + 0x40);
                uVar22 = func_0x00018009a8e0(arg2, iVar19, uVar22);
                *puVar15 = uVar22;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 6;
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
                return;
            }
        } else if (1 < iVar11 + 1U) {
            if (iVar11 == 1) {
                iVar10 = func_0x000180085ff0(arg1, arg3 & 0xffffffff);
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U)) &&
                   (iVar11 = func_0x000180085510(arg2, 1), iVar11 == 0)) {
                    func_0x000180099450(arg2, 0x18063d8d0);
                    func_0x000180087960(arg2);
                    pcVar8 = (code *)swi(3);
                    (*pcVar8)();
                    return;
                }
                puVar7 = *(uint32_t **)(arg2 + 0x40);
                *puVar7 = (uint32_t)(iVar10 != 0);
                puVar7[3] = 1;
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
                return;
            }
            if (iVar11 == 5) {
                puVar14 = (undefined4 *)func_0x000180086200(arg1, arg3 & 0xffffffff);
                uVar18 = puVar14[2];
                uVar3 = puVar14[1];
                uVar4 = *puVar14;
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U)) &&
                   (iVar10 = func_0x000180085510(arg2, 1), iVar10 == 0)) {
                    func_0x000180099450(arg2, 0x18063d8d0);
                    func_0x000180087960(arg2);
                    pcVar8 = (code *)swi(3);
                    (*pcVar8)();
                    return;
                }
                puVar14 = *(undefined4 **)(arg2 + 0x40);
                *puVar14 = uVar4;
                puVar14[1] = uVar3;
                puVar14[2] = uVar18;
                puVar14[3] = 5;
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
                return;
            }
            if (iVar11 == 8) {
                puVar15 = (undefined8 *)func_0x000180085430(arg1, arg3 & 0xffffffff);
                uVar22 = *puVar15;
                if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
                }
                puVar15 = *(undefined8 **)(arg2 + 0x40);
                *puVar15 = uVar22;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 8;
            } else if (iVar11 == 0xb) {
                puVar15 = (undefined8 *)func_0x000180085430(arg1, arg3 & 0xffffffff);
                uVar22 = *puVar15;
                if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
                }
                puVar15 = *(undefined8 **)(arg2 + 0x40);
                *puVar15 = uVar22;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 0xb;
            } else {
                if (iVar11 != 10) {
                    if (iVar11 == 7) {
                        uVar20 = 0;
                        uVar13 = arg3 & 0xffffffff;
                        while( true ) {
                            *(uint64_t *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBX;
                            *(int64_t *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RBP;
                            *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RSI;
                            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RDI;
                            *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x18) = unaff_R14;
                            unaff_R14 = (uint64_t)uVar20;
                            iVar10 = (int32_t)uVar13;
                            unaff_RBX = (uint64_t)iVar10;
                            uVar21 = *(uint64_t *)0x180782430;
                            if (iVar10 < 1) {
                                if (iVar10 < -9999) {
                                    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x1800218f3;
                                    uVar12 = func_0x000180085370(arg1, uVar13);
                                } else {
                                    uVar12 = unaff_RBX * 0x10 + *(int64_t *)(arg1 + 0x40);
                                }
                            } else {
                                uVar12 = *(int64_t *)(arg1 + 0x28) + -0x10 + unaff_RBX * 0x10;
                                if (*(uint64_t *)(arg1 + 0x40) <= uVar12) {
                                    uVar12 = *(uint64_t *)0x180782430;
                                }
                            }
                            if ((uVar12 == uVar21) || (*(int32_t *)(uVar12 + 0xc) != 7)) break;
                            if (iVar10 < 0) {
                                unaff_RBX = (uint64_t)
                                            (uint32_t)
                                            (iVar10 + 1 +
                                            (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4));
                            }
                            if (0x20 < (int32_t)uVar20) {
                                return;
                            }
                            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x180021931;
                            func_0x000180086fd0(arg2, 0, 0);
                            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x180021939;
                            func_0x000180086510(arg1);
                            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x180021943;
                            iVar10 = func_0x000180087970(arg1, unaff_RBX & 0xffffffff);
                            if (iVar10 == 0) {
                                return;
                            }
                            uVar20 = uVar20 + 1;
                            uVar13 = 0xfffffffe;
                            puVar17 = (undefined8 *)((int64_t)*(undefined **)0x20 + -0x40);
                            *(undefined **)0x20 = (BADSPACEBASE *)((int64_t)*(undefined **)0x20 + -0x40);
                            *puVar17 = 0x180021965;
                            unaff_RBP = arg2;
                            unaff_RSI = arg1;
                        }
                        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x40) = 0x1800219ba;
                        fcn.1800219d0(arg1, arg2, uVar13);
                        return;
                    }
                    if (iVar11 == 2) {
                        uVar22 = func_0x0001800862a0(arg1, arg3 & 0xffffffff);
                        if (iVar10 < 1) {
                            if (iVar10 < -9999) {
                                uVar13 = func_0x000180085370(arg1, arg3 & 0xffffffff);
                            } else {
                                uVar13 = iVar19 * 0x10 + *(int64_t *)(arg1 + 0x40);
                            }
                        } else {
                            uVar13 = *(int64_t *)(arg1 + 0x28) + -0x10 + iVar19 * 0x10;
                            if (*(uint64_t *)(arg1 + 0x40) <= uVar13) {
                                uVar13 = *(uint64_t *)0x180782430;
                            }
                        }
                        if (*(int32_t *)(uVar13 + 0xc) == 2) {
                            uVar18 = *(undefined4 *)(uVar13 + 8);
                        } else {
                            uVar18 = 0xffffffff;
                        }
                        if (((*(char *)0x180777010 != '\0') &&
                            (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U)) &&
                           (iVar10 = func_0x000180085510(arg2, 1), iVar10 == 0)) {
                            func_0x000180099450(arg2, 0x18063d8d0);
                            func_0x000180087960(arg2);
                            pcVar8 = (code *)swi(3);
                            (*pcVar8)();
                            return;
                        }
                        puVar15 = *(undefined8 **)(arg2 + 0x40);
                        *puVar15 = uVar22;
                        *(undefined4 *)(puVar15 + 1) = uVar18;
                        *(undefined4 *)((int64_t)puVar15 + 0xc) = 2;
                        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
                        return;
                    }
                    if (iVar11 != 9) {
                        return;
                    }
                    iVar10 = func_0x0001800863e0(arg1, arg3 & 0xffffffff);
                    if (iVar10 != *(int32_t *)0x1807823dc) {
                        uVar22 = func_0x000180086300(arg1, arg3 & 0xffffffffU);
                        puVar15 = *(undefined8 **)(arg2 + 0x40);
                        *puVar15 = uVar22;
                        *(undefined4 *)((int64_t)puVar15 + 0xc) = 9;
                        if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
                            iVar11 = *(int32_t *)(arg2 + 0x60) - (int32_t)(int32_t *)(arg2 + 0x60);
                            iVar10 = iVar11 * 2;
                            if (iVar11 < 1) {
                                iVar10 = iVar11 + 1;
                            }
                            func_0x000180093240(arg2, iVar10, 0);
                        }
                        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
                        iVar10 = func_0x0001800863e0(arg1, arg3 & 0xffffffff);
                        if (iVar10 == 0) {
                            return;
                        }
                        *(char *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 3) = (char)iVar10;
                        return;
                    }
                    pauVar16 = (undefined (*) [16])func_0x000180086300(arg1, arg3 & 0xffffffffU);
                    if (*(int64_t *)(*pauVar16 + 8) != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(*(int64_t *)(*pauVar16 + 8) + 8);
                        *piVar1 = *piVar1 + 1;
                        UNLOCK();
                    }
                    pcVar8 = *(code **)0x180782630;
                    piVar5 = *(int64_t **)(*pauVar16 + 8);
                    _var_28h = *(undefined (*) [12])*pauVar16;
                    auVar9 = *pauVar16;
                    if (piVar5 != (int64_t *)0x0) {
                        LOCK();
                        *(int32_t *)(piVar5 + 1) = *(int32_t *)(piVar5 + 1) + 1;
                        UNLOCK();
                    }
                    uStack_c = (undefined4)((uint64_t)piVar5 >> 0x20);
                    uStack_1c = uStack_c;
                    _var_18h = auVar9;
                    (*pcVar8)(arg2, &var_28h);
                    if (piVar5 == (int64_t *)0x0) {
                        return;
                    }
                    LOCK();
                    piVar2 = piVar5 + 1;
                    iVar10 = *(int32_t *)piVar2;
                    *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                    UNLOCK();
                    if (iVar10 != 1) {
                        return;
                    }
                    (**(code **)*piVar5)(piVar5);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                    iVar10 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar10 != 1) {
                        return;
                    }
    // WARNING: Could not recover jumptable at 0x000180021dc3. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)(*piVar5 + 8))(piVar5);
                    return;
                }
                uVar22 = func_0x000180086440(arg1, arg3 & 0xffffffff);
                if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                    *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
                }
                puVar15 = *(undefined8 **)(arg2 + 0x40);
                *puVar15 = uVar22;
                *(undefined4 *)((int64_t)puVar15 + 0xc) = 10;
            }
            if (*(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x40) < 0x11) {
                iVar11 = *(int32_t *)(arg2 + 0x60) - (int32_t)(int32_t *)(arg2 + 0x60);
                iVar10 = iVar11 * 2;
                if (iVar11 < 1) {
                    iVar10 = iVar11 + 1;
                }
                func_0x000180093240(arg2, iVar10, 0);
            }
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            return;
        }
    }
    func_0x000180086510(arg2);
    return;
}

// ============================================================
// Function: FUN_180021e50
// Address: 0x180021e50
// Size: 2741 bytes
// ============================================================
void fcn.180021e50(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t **ppiVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    undefined *puVar17;
    undefined *puVar18;
    uint32_t uVar19;
    int64_t **ppiVar20;
    int64_t *piVar21;
    undefined8 *puVar22;
    bool bVar23;
    bool bVar24;
    undefined4 uVar25;
    undefined8 uStack_120;
    undefined auStack_118 [8];
    undefined auStack_110 [24];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined8 uStack_a0;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar18 = auStack_118;
    puVar17 = auStack_118;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    var_d8h._0_4_ = 0;
    ppiVar20 = *(int64_t ***)(arg1 + 0x28);
    ppiVar3 = *(int64_t ***)(arg1 + 0x40);
    ppiVar9 = ppiVar20;
    if (ppiVar3 <= ppiVar20) {
        ppiVar9 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar9 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar9 + 0xc) != 9)) {
        ppiVar9 = ppiVar20;
        if (ppiVar3 <= ppiVar20) {
            ppiVar9 = *(int64_t ***)0x180782430;
        }
        if ((ppiVar9 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar9 + 0xc) != 2)) {
code_r0x00018002289f:
            func_0x000180088380(arg1, 1, 0x1806217f0);
code_r0x0001800228b2:
            func_0x000180088380(arg1, 1, 0x1806217f0);
code_r0x0001800228c5:
            func_0x000180087960(arg1);
            goto code_r0x0001800228ce;
        }
        if (ppiVar3 <= ppiVar20) {
            ppiVar20 = *(int64_t ***)0x180782430;
        }
        if ((*(int32_t *)((int64_t)ppiVar20 + 0xc) != 2) || (piVar16 = *ppiVar20, piVar16 == (int64_t *)0x0))
        goto code_r0x00018002289f;
        if (**(int64_t **)(piVar16[10] + 8) == 0) {
            func_0x000180088560(arg1, 0x180621868);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar12 = (*(int64_t **)(piVar16[10] + 8))[1];
        puVar17 = auStack_118;
        if (((iVar12 != 0) && (iVar12 = *(int64_t *)(iVar12 + 0x48), puVar17 = auStack_118, iVar12 != 0)) &&
           (puVar17 = auStack_118, *(int32_t *)(iVar12 + 8) != 0)) {
            func_0x000180088560(arg1, 0x180621810);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    } else {
        ppiVar9 = ppiVar20;
        if (ppiVar3 <= ppiVar20) {
            ppiVar9 = *(int64_t ***)0x180782430;
        }
        if (((*(int32_t *)((int64_t)ppiVar9 + 0xc) != 9) ||
            (*(uint8_t *)((int64_t)*ppiVar9 + 3) != *(uint32_t *)0x1807823dc)) ||
           (*ppiVar9 == (int64_t *)0xfffffffffffffff0)) {
            func_0x000180088380(arg1, 1, 0x1806217c8);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (ppiVar3 <= ppiVar20) {
            ppiVar20 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar20 + 0xc) == 9) {
            piVar16 = *ppiVar20 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar20 + 0xc) == 2) {
            piVar16 = *ppiVar20;
        } else {
            piVar16 = (int64_t *)0x0;
        }
        if (piVar16[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar16[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_e0h = *piVar16;
        var_c0h = piVar16[1];
        var_c8h = var_e0h;
        func_0x00018000b4d0(&var_78h, *(undefined8 *)(*(int64_t *)(var_e0h + 0x18) + 8));
        piVar16 = &var_78h;
        if (0xf < (uint64_t)var_60h) {
            piVar16 = (int64_t *)var_78h;
        }
        if (var_68h == 5) {
            iVar8 = func_0x000180497f30(piVar16, 0x1806217c0);
            bVar23 = iVar8 == 0;
        } else {
            bVar23 = false;
        }
        if ((uint64_t)var_60h < 0x10) {
code_r0x000180021faf:
            if (!bVar23) goto code_r0x0001800228b2;
            bVar23 = false;
            func_0x000180020690(&var_98h, arg1);
            var_d0h = var_90h;
            piVar16 = (int64_t *)var_b8h;
            ppiVar20 = (int64_t **)var_98h;
            if (var_98h != var_90h) {
                do {
                    if (**(int64_t **)((*ppiVar20)[10] + 8) != 0) {
                        iVar12 = (*(int64_t **)((*ppiVar20)[10] + 8))[1];
                        iVar4 = *(int64_t *)(iVar12 + 0x48);
                        bVar24 = bVar23;
                        if ((iVar4 == 0) || (*(int32_t *)(iVar4 + 8) == 0)) {
code_r0x000180022034:
                            bVar23 = bVar24;
                            bVar24 = false;
                        } else {
                            iVar8 = *(int32_t *)(iVar4 + 8);
                            do {
                                if (iVar8 == 0) {
                                    piVar16 = (int64_t *)0x0;
                                    bVar24 = true;
                                    goto code_r0x000180022034;
                                }
                                LOCK();
                                iVar7 = *(int32_t *)(iVar4 + 8);
                                bVar23 = iVar8 == iVar7;
                                if (bVar23) {
                                    *(int32_t *)(iVar4 + 8) = iVar8 + 1;
                                    iVar7 = iVar8;
                                }
                                UNLOCK();
                                iVar8 = iVar7;
                            } while (!bVar23);
                            piVar16 = *(int64_t **)(iVar12 + 0x48);
                            bVar23 = true;
                            bVar24 = true;
                            if (*(int64_t *)(iVar12 + 0x40) == 0) goto code_r0x000180022034;
                            bVar24 = true;
                        }
                        if ((bVar23) && (bVar23 = false, piVar16 != (int64_t *)0x0)) {
                            LOCK();
                            piVar21 = piVar16 + 1;
                            iVar8 = *(int32_t *)piVar21;
                            *(int32_t *)piVar21 = *(int32_t *)piVar21 + -1;
                            UNLOCK();
                            if (iVar8 == 1) {
                                (**(code **)*piVar16)(piVar16);
                                LOCK();
                                piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
                                iVar8 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar8 == 1) {
                                    (**(code **)(*piVar16 + 8))(piVar16);
                                }
                            }
                        }
                        if (bVar24) {
                            iVar14 = 0;
                            iVar4 = *(int64_t *)(iVar12 + 0x48);
                            if (iVar4 != 0) {
                                iVar8 = *(int32_t *)(iVar4 + 8);
                                do {
                                    if (iVar8 == 0) goto code_r0x0001800220ec;
                                    LOCK();
                                    iVar7 = *(int32_t *)(iVar4 + 8);
                                    bVar24 = iVar8 == iVar7;
                                    if (bVar24) {
                                        *(int32_t *)(iVar4 + 8) = iVar8 + 1;
                                        iVar7 = iVar8;
                                    }
                                    UNLOCK();
                                    iVar8 = iVar7;
                                } while (!bVar24);
                                iVar14 = *(int64_t *)(iVar12 + 0x40);
                                piVar21 = *(int64_t **)(iVar12 + 0x48);
                                if (piVar21 != (int64_t *)0x0) {
                                    LOCK();
                                    piVar2 = piVar21 + 1;
                                    iVar8 = *(int32_t *)piVar2;
                                    *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                                    UNLOCK();
                                    if (iVar8 == 1) {
                                        (**(code **)*piVar21)(piVar21);
                                        LOCK();
                                        piVar1 = (int32_t *)((int64_t)piVar21 + 0xc);
                                        iVar8 = *piVar1;
                                        *piVar1 = *piVar1 + -1;
                                        UNLOCK();
                                        if (iVar8 == 1) {
                                            (**(code **)(*piVar21 + 8))(piVar21);
                                        }
                                    }
                                }
                            }
code_r0x0001800220ec:
                            if (iVar14 == var_e0h) {
                                piVar16 = *ppiVar20;
                                if (piVar16 != (int64_t *)0x0) goto code_r0x000180022203;
                                break;
                            }
                        }
                    }
                    ppiVar20 = ppiVar20 + 1;
                } while (ppiVar20 != (int64_t **)var_d0h);
            }
            var_f8h = 0;
            func_0x0001800869f0(arg1, *(undefined8 *)0x1807823f0, 0, 0);
            func_0x0001800867f0(arg1, 0x1806217e0, 0xb);
            iVar8 = func_0x0001800878a0(arg1, 1, 1);
            if (iVar8 != 0) goto code_r0x0001800228c5;
            iVar12 = *(int64_t *)(arg1 + 0x40);
            if (*(int32_t *)(iVar12 + -4) == 9) {
                piVar16 = (int64_t *)(*(int64_t *)(iVar12 + -0x10) + 0x10);
            } else if (*(int32_t *)(iVar12 + -4) == 2) {
                piVar16 = *(int64_t **)(iVar12 + -0x10);
            } else {
                piVar16 = (int64_t *)0x0;
            }
            if (piVar16[1] != 0) {
                LOCK();
                piVar1 = (int32_t *)(piVar16[1] + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            var_b8h = *piVar16;
            piVar21 = (int64_t *)piVar16[1];
            *(int64_t *)(var_b8h + 0x70) = var_e0h;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            var_a8h = var_e0h;
            var_d8h._0_4_ = 2;
            var_b0h = (int64_t)piVar21;
            piVar16 = (int64_t *)
                      (**(code **)0x180782570)(*(undefined8 *)(*(int64_t *)(arg1 + 0x50) + 0x98), &var_d8h, &var_a8h);
            if (piVar21 != (int64_t *)0x0) {
                LOCK();
                piVar2 = piVar21 + 1;
                iVar8 = *(int32_t *)piVar2;
                *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)*piVar21)(piVar21);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar21 + 0xc);
                    iVar8 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        (**(code **)(*piVar21 + 8))(piVar21);
                    }
                }
            }
code_r0x000180022203:
            if (var_98h != 0) {
                puVar17 = auStack_118;
                if ((0xfff < (uint64_t)((var_88h - var_98h >> 3) * 8)) &&
                   (iVar12 = var_98h - *(int64_t *)(var_98h + -8), var_98h = *(int64_t *)(var_98h + -8),
                   puVar17 = auStack_118, 0x1f < iVar12 - 8U)) goto code_r0x00018002223f;
                goto code_r0x000180022249;
            }
        } else {
            uVar15 = var_60h + 1;
            if (uVar15 < 0x1000) {
code_r0x000180021faa:
                func_0x000180459c3c(var_78h, uVar15);
                goto code_r0x000180021faf;
            }
            piVar16 = (int64_t *)var_60h;
            if ((var_78h - *(int64_t *)(var_78h + -8)) - 8U < 0x20) {
                uVar15 = var_60h + 0x28;
                var_78h = *(int64_t *)(var_78h + -8);
                goto code_r0x000180021faa;
            }
code_r0x00018002223f:
            var_98h = 5;
            pcVar5 = (code *)swi(0x29);
            (*pcVar5)(5);
            puVar17 = auStack_110;
code_r0x000180022249:
            *(undefined8 *)(puVar17 + -8) = 0x180022251;
            func_0x000180459c3c(var_98h);
            _var_98h = ZEXT816(0);
            var_88h = 0;
        }
        iVar12 = var_c0h;
        if (var_c0h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_c0h + 8);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                pcVar5 = **(code ***)var_c0h;
                *(undefined8 *)(puVar17 + -8) = 0x18002227f;
                (*pcVar5)(var_c0h);
                LOCK();
                piVar1 = (int32_t *)(iVar12 + 0xc);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    pcVar5 = *(code **)(*(int64_t *)iVar12 + 8);
                    *(undefined8 *)(puVar17 + -8) = 0x180022295;
                    (*pcVar5)(iVar12);
                }
            }
        }
    }
    bVar23 = false;
    ppiVar20 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar20) {
        ppiVar20 = *(int64_t ***)0x180782430;
    }
    puVar18 = puVar17;
    if (*(int32_t *)((int64_t)ppiVar20 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        *(undefined8 *)(puVar17 + -8) = 0x1800222dd;
        iVar8 = func_0x0001800a8360(arg1, ppiVar20);
        if (iVar8 == 0) goto code_r0x0001800228ce;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            *(undefined8 *)(puVar17 + -8) = 0x1800222fe;
            (**(code **)0x180782658)(arg1, 1);
        }
        ppiVar20 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar20) {
            ppiVar20 = *(int64_t ***)0x180782430;
        }
    }
    ppiVar3 = *(int64_t ***)0x180782430;
    piVar21 = *ppiVar20 + 3;
    *(int64_t **)(puVar17 + 0x38) = piVar21;
    if (piVar21 == (int64_t *)0x0) {
code_r0x0001800228ce:
        *(undefined8 *)(puVar18 + -8) = 0x1800228e1;
        func_0x000180088470(arg1, 2, 6);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    ppiVar9 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
    ppiVar20 = *(int64_t ***)(arg1 + 0x40);
    if (ppiVar20 <= ppiVar9) {
        ppiVar9 = *(int64_t ***)0x180782430;
    }
    ppiVar9 = ppiVar9 + 2;
    if (ppiVar9 < ppiVar20) {
        do {
            *(undefined4 *)(ppiVar9 + -2) = *(undefined4 *)ppiVar9;
            *(undefined4 *)((int64_t)ppiVar9 + -0xc) = *(undefined4 *)((int64_t)ppiVar9 + 4);
            *(undefined4 *)(ppiVar9 + -1) = *(undefined4 *)(ppiVar9 + 1);
            *(undefined4 *)((int64_t)ppiVar9 + -4) = *(undefined4 *)((int64_t)ppiVar9 + 0xc);
            ppiVar9 = ppiVar9 + 2;
            ppiVar20 = *(int64_t ***)(arg1 + 0x40);
        } while (ppiVar9 < ppiVar20);
    } else {
        *(int64_t **)(puVar17 + 0x38) = piVar21;
    }
    ppiVar20 = ppiVar20 + -2;
    *(int64_t ***)(arg1 + 0x40) = ppiVar20;
    ppiVar9 = *(int64_t ***)(arg1 + 0x28);
    if (ppiVar20 <= *(int64_t ***)(arg1 + 0x28)) {
        ppiVar9 = ppiVar3;
    }
    ppiVar9 = ppiVar9 + 2;
    if (ppiVar9 < ppiVar20) {
        do {
            *(undefined4 *)(ppiVar9 + -2) = *(undefined4 *)ppiVar9;
            *(undefined4 *)((int64_t)ppiVar9 + -0xc) = *(undefined4 *)((int64_t)ppiVar9 + 4);
            *(undefined4 *)(ppiVar9 + -1) = *(undefined4 *)(ppiVar9 + 1);
            *(undefined4 *)((int64_t)ppiVar9 + -4) = *(undefined4 *)((int64_t)ppiVar9 + 0xc);
            ppiVar9 = ppiVar9 + 2;
            ppiVar20 = *(int64_t ***)(arg1 + 0x40);
        } while (ppiVar9 < ppiVar20);
    }
    *(int64_t ***)(arg1 + 0x40) = ppiVar20 + -2;
    var_b8h = *(int64_t *)(arg1 + 0x28);
    *(undefined8 *)(puVar17 + -8) = 0x18002242c;
    iVar12 = func_0x000180085760(piVar16);
    if (iVar12 == 0) goto code_r0x00018002280e;
    piVar16[8] = piVar16[8] + -0x10;
    *(undefined8 *)(puVar17 + -8) = 0x180022442;
    func_0x000180013530();
    iVar4 = *(int64_t *)(iVar12 + 0x50);
    *(uint8_t *)(iVar12 + 1) = *(uint8_t *)(iVar12 + 1) | 0x40;
    *(undefined4 *)(iVar4 + 0x88) = 8;
    *(undefined8 *)(iVar4 + 0x78) = 0x203fffffffffff3f;
    uVar11 = **(undefined8 **)0x180782610;
    *(undefined8 *)(puVar17 + -8) = 0x180022476;
    puVar10 = (undefined4 *)(**(code **)0x180782558)(uVar11);
    if (puVar10 != (undefined4 *)0x0) {
        uVar15 = *(uint64_t *)(iVar4 + 0x78);
        *puVar10 = 8;
        *(uint64_t *)(puVar10 + 10) = uVar15 | 0x200000000000003f;
        *(int64_t *)(puVar10 + 6) = iVar12;
    }
    var_d0h = *(int64_t *)(iVar12 + 0x50);
    iVar4 = *(int64_t *)(*(int64_t *)(piVar16[10] + 8) + 8);
    piVar16 = (int64_t *)var_b8h;
    if (((iVar4 == 0) || (iVar14 = *(int64_t *)(iVar4 + 0x48), iVar14 == 0)) || (*(int32_t *)(iVar14 + 8) == 0)) {
code_r0x00018002250a:
        puVar17[0x30] = 0;
    } else {
        iVar8 = *(int32_t *)(iVar14 + 8);
        do {
            if (iVar8 == 0) {
                bVar23 = true;
                piVar16 = (int64_t *)0x0;
                goto code_r0x00018002250a;
            }
            LOCK();
            iVar7 = *(int32_t *)(iVar14 + 8);
            bVar23 = iVar8 == iVar7;
            if (bVar23) {
                *(int32_t *)(iVar14 + 8) = iVar8 + 1;
                iVar7 = iVar8;
            }
            UNLOCK();
            iVar8 = iVar7;
        } while (!bVar23);
        piVar16 = *(int64_t **)(iVar4 + 0x48);
        bVar23 = true;
        *(undefined8 *)(puVar17 + 0x38) = *(undefined8 *)(puVar17 + 0x38);
        if (*(int64_t *)(iVar4 + 0x40) == 0) goto code_r0x00018002250a;
        puVar17[0x30] = 1;
    }
    if ((bVar23) && (piVar16 != (int64_t *)0x0)) {
        LOCK();
        piVar21 = piVar16 + 1;
        iVar8 = *(int32_t *)piVar21;
        *(int32_t *)piVar21 = *(int32_t *)piVar21 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            pcVar5 = *(code **)*piVar16;
            *(undefined8 *)(puVar17 + -8) = 0x18002252f;
            (*pcVar5)();
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                pcVar5 = *(code **)(*piVar16 + 8);
                *(undefined8 *)(puVar17 + -8) = 0x180022545;
                (*pcVar5)();
            }
        }
    }
    if (puVar17[0x30] != '\0') {
        iVar14 = *(int64_t *)(iVar4 + 0x48);
        if (iVar14 == 0) {
            uVar11 = 0;
        } else {
            uVar11 = *(undefined8 *)(iVar4 + 0x40);
            LOCK();
            *(int32_t *)(iVar14 + 0xc) = *(int32_t *)(iVar14 + 0xc) + 1;
            UNLOCK();
        }
        *(undefined8 *)(var_d0h + 0x40) = uVar11;
        piVar16 = *(int64_t **)(var_d0h + 0x48);
        *(int64_t *)(var_d0h + 0x48) = iVar14;
        if (piVar16 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                pcVar5 = *(code **)(*piVar16 + 8);
                *(undefined8 *)(puVar17 + -8) = 0x180022589;
                (*pcVar5)();
            }
        }
    }
    *(undefined8 *)(puVar17 + -8) = 0x18002259d;
    func_0x000180086cc0(iVar12, 0xffffd8f0, 0x1805aae80);
    if (((int64_t **)(*(int64_t *)(iVar12 + 0x40) - 0x10U) != *(int64_t ***)0x180782430) &&
       (*(int32_t *)(*(int64_t *)(iVar12 + 0x40) + -4) == 0)) {
        *(undefined8 *)(puVar17 + -8) = 0x1800225b9;
        uVar25 = func_0x000180018f70();
        *(undefined8 *)(puVar17 + -8) = 0x1800225c1;
        func_0x000180019a70(uVar25, iVar12);
    }
    *(int64_t *)(iVar12 + 0x40) = *(int64_t *)(iVar12 + 0x40) + -0x10;
    if ((*(char *)0x180777010 != '\0') &&
       (**(uint64_t **)(iVar12 + 0x18) <
        (uint64_t)
        ((int64_t)-(int32_t)(*(int64_t *)(iVar12 + 0x40) - *(int64_t *)(iVar12 + 0x28) >> 4) * 0x10 +
        *(int64_t *)(iVar12 + 0x40)))) {
        *(undefined8 *)(puVar17 + -8) = 0x1800225fb;
        iVar8 = func_0x000180085510(iVar12);
        if (iVar8 == 0) {
            *(undefined8 *)(puVar17 + -8) = 0x180022886;
            func_0x000180099450(iVar12, 0x18063d8d0);
            *(undefined8 *)(puVar17 + -8) = 0x18002288e;
            func_0x000180087960(iVar12);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
    }
    uVar15 = *(uint64_t *)(iVar12 + 0x40);
    uVar13 = *(uint64_t *)(iVar12 + 0x28);
    if (uVar15 < uVar13) {
        do {
            *(undefined4 *)(uVar15 + 0xc) = 0;
            uVar15 = *(int64_t *)(iVar12 + 0x40) + 0x10;
            *(uint64_t *)(iVar12 + 0x40) = uVar15;
            uVar13 = *(uint64_t *)(iVar12 + 0x28);
        } while (uVar15 < uVar13);
    }
    *(uint64_t *)(iVar12 + 0x40) = uVar13;
    if (*(int64_t *)(*(int64_t *)(iVar12 + 0x20) + 0x550) != 0x1800135b0) {
        *(undefined8 *)(*(int64_t *)(iVar12 + 0x20) + 0x550) = 0x1800135b0;
    }
    _var_a8h = ZEXT816(0);
    *(undefined8 *)(puVar17 + -8) = 0x18002266d;
    func_0x000180086fd0(iVar12, 0, 0);
    *(undefined8 *)(puVar17 + -8) = 0x18002267a;
    func_0x000180086fd0(iVar12, 0, 0);
    *(undefined8 *)(puVar17 + -8) = 0x18002268e;
    func_0x000180086cc0(iVar12, 0xffffd8f0, 0x1805aae80);
    *(undefined8 *)(puVar17 + -8) = 0x1800226a2;
    func_0x000180087370(iVar12, 0xfffffffe, 0x1805aae90);
    *(undefined *)(*(int64_t *)(*(int64_t *)(iVar12 + 0x40) + -0x10) + 4) = 1;
    *(undefined8 *)(puVar17 + -8) = 0x1800226bb;
    func_0x000180087650(iVar12, 0xfffffffe);
    if ((*(uint8_t *)(iVar12 + 1) & 4) != 0) {
        *(uint8_t *)(iVar12 + 1) = *(uint8_t *)(iVar12 + 1) & 0xfb;
        *(undefined8 *)(iVar12 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar12 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar12 + 0x20) + 0x18) = iVar12;
    }
    *(undefined8 *)(puVar17 + -8) = 0x1800226e5;
    func_0x000180085370(iVar12, 0xffffd8ee);
    puVar22 = (undefined8 *)(*(int64_t *)(iVar12 + 0x40) + -0x10);
    *(undefined8 *)(iVar12 + 0x58) = *puVar22;
    *(undefined8 **)(iVar12 + 0x40) = puVar22;
    *(undefined8 *)(puVar17 + -8) = 0x180022705;
    piVar16 = (int64_t *)func_0x000180085370(iVar12, 0xffffd8ee);
    *(undefined *)(*piVar16 + 6) = 0;
    *(undefined8 *)(puVar17 + -8) = 0x180022711;
    piVar16 = (int64_t *)func_0x000180008740();
    iVar4 = *(int64_t *)(*piVar16 + 0x20);
    *(undefined8 *)(puVar17 + -8) = 0x180022724;
    func_0x0001800205e0(&var_c8h, iVar12);
    *(undefined8 *)(puVar17 + -8) = 0x18002272a;
    func_0x000180012f50();
    _var_98h = ZEXT816(0);
    var_88h = 0;
    var_80h = 0;
    *(undefined8 *)(puVar17 + -8) = 0x180022743;
    uVar11 = func_0x000180498cd0(*(undefined8 *)(puVar17 + 0x38));
    *(undefined8 *)(puVar17 + -8) = 0x180022754;
    uVar25 = func_0x000180004830(&var_98h, *(undefined8 *)(puVar17 + 0x38), uVar11);
    *(undefined4 *)(puVar17 + 0x20) = 0;
    *(undefined8 *)(puVar17 + -8) = 0x18002276d;
    cVar6 = func_0x0001800131b0(uVar25, iVar12, &var_98h, 0x1805aae98);
    if (0xf < (uint64_t)var_80h) {
        iVar14 = var_98h;
        if ((0xfff < var_80h + 1U) && (iVar14 = *(int64_t *)(var_98h + -8), 0x1f < (var_98h - iVar14) - 8U)) {
            iVar14 = 5;
            pcVar5 = (code *)swi(0x29);
            (*pcVar5)(5);
            puVar17 = puVar17 + 8;
        }
        *(undefined8 *)(puVar17 + -8) = 0x1800227b3;
        func_0x000180459c3c(iVar14);
    }
    if (cVar6 == '\0') {
        *(undefined8 *)(puVar17 + 0x28) = 0;
        puVar17[0x20] = 1;
        uVar15 = 0;
        piVar16 = &var_98h;
    } else {
        uVar15 = (int64_t)(ppiVar20 + -2) - var_b8h >> 4;
        iVar8 = (int32_t)uVar15;
        if (0 < iVar8) {
            uVar19 = 1;
            do {
                *(undefined8 *)(puVar17 + -8) = 0x180022850;
                fcn.1800219d0(arg1, iVar12, (uint64_t)uVar19);
                uVar19 = uVar19 + 1;
            } while ((int32_t)uVar19 <= iVar8);
        }
        *(undefined8 *)(puVar17 + 0x28) = 0;
        puVar17[0x20] = 0;
        uVar15 = uVar15 & 0xffffffff;
        piVar16 = &var_78h;
    }
    *(undefined8 *)(puVar17 + -8) = 0x1800227da;
    (**(code **)0x180782530)(iVar4 + 0x7f8, piVar16, var_c8h, uVar15);
    iVar12 = var_c0h;
    if (var_c0h != 0) {
        LOCK();
        piVar1 = (int32_t *)(var_c0h + 8);
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            pcVar5 = **(code ***)var_c0h;
            *(undefined8 *)(puVar17 + -8) = 0x1800227f9;
            (*pcVar5)(var_c0h);
            LOCK();
            piVar1 = (int32_t *)(iVar12 + 0xc);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                pcVar5 = *(code **)(*(int64_t *)iVar12 + 8);
                *(undefined8 *)(puVar17 + -8) = 0x18002280e;
                (*pcVar5)(iVar12);
            }
        }
    }
code_r0x00018002280e:
    *(undefined8 *)(puVar17 + -8) = 0x18002281c;
    func_0x000180459870(var_58h ^ (uint64_t)puVar17);
    return;
}

// ============================================================
// Function: FUN_180022910
// Address: 0x180022910
// Size: 1349 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h

void fcn.180022910(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    func_0x000180018f70();
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, 0x1800208f0, 0x180621898, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621898);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, 0x180020ef0, 0x180621880, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621880);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_68h = 0x1806218c0;
    func_0x0001800869f0(arg2, 0x180021000, 0x1806218b0, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x1806218b0);
    piVar4 = &var_68h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x1806218b0);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_60h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_60h = 0x1806218e8;
    func_0x0001800869f0(arg2, 0x180021250, 0x1806218d0, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x1806218d0);
    piVar4 = &var_60h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x1806218d0);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_58h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_58h = 0x180621910;
    func_0x0001800869f0(arg2, 0x1800213d0, 0x180621900, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621900);
    piVar4 = &var_58h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621900);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_50h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_50h = 0x180621930;
    func_0x0001800869f0(arg2, 0x180021560, 0x180621920, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621920);
    piVar4 = &var_50h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621920);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_48h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_48h = 0x180621958;
    func_0x0001800869f0(arg2, 0x180021610, 0x180621940, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621940);
    piVar4 = &var_48h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621940);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_40h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_40h = 0x180621980;
    func_0x0001800869f0(arg2, 0x180021760, 0x180621970, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621970);
    piVar4 = &var_40h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621970);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_38h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_38h = 0x1806219a8;
    func_0x0001800869f0(arg2, 0x180021850, 0x180621998, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621998);
    piVar4 = &var_38h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621998);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_30h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_30h = 0x1806219c8;
    func_0x0001800869f0(arg2, fcn.180021e50, 0x1806219b8, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x1806219b8);
    piVar4 = &var_30h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x1806219b8);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != (int64_t *)&stack0xffffffffffffffd8);
    return;
}

// ============================================================
// Function: FUN_180022e70
// Address: 0x180022e70
// Size: 35 bytes
// ============================================================
void fcn.180022e70(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t in_stack_00000008;
    
    fcn.180023230(in_stack_00000008);
    if ((*(int64_t *)arg1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180022ea0
// Address: 0x180022ea0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180022ea0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar4 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x38) >> 3 <= *(uint64_t *)(arg1 + 0x10)) {
            fcn.180023230(in_stack_ffffffffffffffb8);
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            func_0x00018000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
            return;
        }
        ppiVar5 = (int64_t **)*ppiVar4;
        if (ppiVar5 != ppiVar4) {
            var_8h = (int64_t)ppiVar5[1];
            iVar6 = *(int64_t *)(arg1 + 0x18);
            iVar9 = ((((((uint64_t)*(uint8_t *)(ppiVar5 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                    0x10;
            var_18h = iVar9 + iVar6;
            var_20h = iVar9 + 8 + iVar6;
            var_10h = *(int64_t *)var_18h;
            ppiVar8 = *(int64_t ***)var_20h;
            ppiVar11 = ppiVar5;
            while( true ) {
                piVar7 = ppiVar11[4];
                ppiVar10 = (int64_t **)*ppiVar11;
                if (piVar7 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = piVar7 + 1;
                    iVar3 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)*piVar7)(piVar7);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                        iVar3 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)(*piVar7 + 8))(piVar7);
                        }
                    }
                }
                func_0x000180459c3c(ppiVar11, 0x28);
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                if (ppiVar11 == ppiVar8) break;
                ppiVar11 = ppiVar10;
                if (ppiVar10 == ppiVar4) {
                    if ((int64_t **)var_10h == ppiVar5) {
                        *(int64_t ***)var_18h = ppiVar10;
                    }
code_r0x000180023001:
                    *(int64_t ***)var_8h = ppiVar10;
                    ppiVar10[1] = (int64_t *)var_8h;
                    return;
                }
            }
            ppiVar8 = (int64_t **)var_8h;
            if ((int64_t **)var_10h == ppiVar5) {
                *(int64_t ***)var_18h = ppiVar4;
                ppiVar8 = ppiVar4;
            }
            *(int64_t ***)var_20h = ppiVar8;
            while (ppiVar10 != ppiVar4) {
                var_10h = ((((((uint64_t)*(uint8_t *)(ppiVar10 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x11)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x12)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x13)) * 0x100000001b3 &
                          *(uint64_t *)(arg1 + 0x30)) * 0x10;
                ppiVar5 = (int64_t **)(var_10h + iVar6);
                var_10h = iVar6 + 8 + var_10h;
                ppiVar8 = *(int64_t ***)var_10h;
                ppiVar11 = ppiVar10;
                while( true ) {
                    piVar7 = ppiVar11[4];
                    ppiVar10 = (int64_t **)*ppiVar11;
                    if (piVar7 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar7 + 1;
                        iVar3 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar7)(piVar7);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar7 + 8))(piVar7);
                            }
                        }
                    }
                    func_0x000180459c3c(ppiVar11, 0x28);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar11 == ppiVar8) break;
                    ppiVar11 = ppiVar10;
                    if (ppiVar10 == ppiVar4) {
                        *ppiVar5 = (int64_t *)ppiVar10;
                        goto code_r0x000180023001;
                    }
                }
                *ppiVar5 = (int64_t *)ppiVar4;
                *(int64_t ***)var_10h = ppiVar4;
            }
            goto code_r0x000180023001;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180022ec0
// Address: 0x180022ec0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180022ea0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar4 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x38) >> 3 <= *(uint64_t *)(arg1 + 0x10)) {
            fcn.180023230(in_stack_ffffffffffffffb8);
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            func_0x00018000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
            return;
        }
        ppiVar5 = (int64_t **)*ppiVar4;
        if (ppiVar5 != ppiVar4) {
            var_8h = (int64_t)ppiVar5[1];
            iVar6 = *(int64_t *)(arg1 + 0x18);
            iVar9 = ((((((uint64_t)*(uint8_t *)(ppiVar5 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                    0x10;
            var_18h = iVar9 + iVar6;
            var_20h = iVar9 + 8 + iVar6;
            var_10h = *(int64_t *)var_18h;
            ppiVar8 = *(int64_t ***)var_20h;
            ppiVar11 = ppiVar5;
            while( true ) {
                piVar7 = ppiVar11[4];
                ppiVar10 = (int64_t **)*ppiVar11;
                if (piVar7 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = piVar7 + 1;
                    iVar3 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)*piVar7)(piVar7);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                        iVar3 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)(*piVar7 + 8))(piVar7);
                        }
                    }
                }
                func_0x000180459c3c(ppiVar11, 0x28);
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                if (ppiVar11 == ppiVar8) break;
                ppiVar11 = ppiVar10;
                if (ppiVar10 == ppiVar4) {
                    if ((int64_t **)var_10h == ppiVar5) {
                        *(int64_t ***)var_18h = ppiVar10;
                    }
code_r0x000180023001:
                    *(int64_t ***)var_8h = ppiVar10;
                    ppiVar10[1] = (int64_t *)var_8h;
                    return;
                }
            }
            ppiVar8 = (int64_t **)var_8h;
            if ((int64_t **)var_10h == ppiVar5) {
                *(int64_t ***)var_18h = ppiVar4;
                ppiVar8 = ppiVar4;
            }
            *(int64_t ***)var_20h = ppiVar8;
            while (ppiVar10 != ppiVar4) {
                var_10h = ((((((uint64_t)*(uint8_t *)(ppiVar10 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x11)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x12)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x13)) * 0x100000001b3 &
                          *(uint64_t *)(arg1 + 0x30)) * 0x10;
                ppiVar5 = (int64_t **)(var_10h + iVar6);
                var_10h = iVar6 + 8 + var_10h;
                ppiVar8 = *(int64_t ***)var_10h;
                ppiVar11 = ppiVar10;
                while( true ) {
                    piVar7 = ppiVar11[4];
                    ppiVar10 = (int64_t **)*ppiVar11;
                    if (piVar7 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar7 + 1;
                        iVar3 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar7)(piVar7);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar7 + 8))(piVar7);
                            }
                        }
                    }
                    func_0x000180459c3c(ppiVar11, 0x28);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar11 == ppiVar8) break;
                    ppiVar11 = ppiVar10;
                    if (ppiVar10 == ppiVar4) {
                        *ppiVar5 = (int64_t *)ppiVar10;
                        goto code_r0x000180023001;
                    }
                }
                *ppiVar5 = (int64_t *)ppiVar4;
                *(int64_t ***)var_10h = ppiVar4;
            }
            goto code_r0x000180023001;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180022f0d
// Address: 0x180022f0d
// Size: 284 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180022ea0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar4 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x38) >> 3 <= *(uint64_t *)(arg1 + 0x10)) {
            fcn.180023230(in_stack_ffffffffffffffb8);
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            func_0x00018000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
            return;
        }
        ppiVar5 = (int64_t **)*ppiVar4;
        if (ppiVar5 != ppiVar4) {
            var_8h = (int64_t)ppiVar5[1];
            iVar6 = *(int64_t *)(arg1 + 0x18);
            iVar9 = ((((((uint64_t)*(uint8_t *)(ppiVar5 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                    0x10;
            var_18h = iVar9 + iVar6;
            var_20h = iVar9 + 8 + iVar6;
            var_10h = *(int64_t *)var_18h;
            ppiVar8 = *(int64_t ***)var_20h;
            ppiVar11 = ppiVar5;
            while( true ) {
                piVar7 = ppiVar11[4];
                ppiVar10 = (int64_t **)*ppiVar11;
                if (piVar7 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = piVar7 + 1;
                    iVar3 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)*piVar7)(piVar7);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                        iVar3 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)(*piVar7 + 8))(piVar7);
                        }
                    }
                }
                func_0x000180459c3c(ppiVar11, 0x28);
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                if (ppiVar11 == ppiVar8) break;
                ppiVar11 = ppiVar10;
                if (ppiVar10 == ppiVar4) {
                    if ((int64_t **)var_10h == ppiVar5) {
                        *(int64_t ***)var_18h = ppiVar10;
                    }
code_r0x000180023001:
                    *(int64_t ***)var_8h = ppiVar10;
                    ppiVar10[1] = (int64_t *)var_8h;
                    return;
                }
            }
            ppiVar8 = (int64_t **)var_8h;
            if ((int64_t **)var_10h == ppiVar5) {
                *(int64_t ***)var_18h = ppiVar4;
                ppiVar8 = ppiVar4;
            }
            *(int64_t ***)var_20h = ppiVar8;
            while (ppiVar10 != ppiVar4) {
                var_10h = ((((((uint64_t)*(uint8_t *)(ppiVar10 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x11)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x12)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x13)) * 0x100000001b3 &
                          *(uint64_t *)(arg1 + 0x30)) * 0x10;
                ppiVar5 = (int64_t **)(var_10h + iVar6);
                var_10h = iVar6 + 8 + var_10h;
                ppiVar8 = *(int64_t ***)var_10h;
                ppiVar11 = ppiVar10;
                while( true ) {
                    piVar7 = ppiVar11[4];
                    ppiVar10 = (int64_t **)*ppiVar11;
                    if (piVar7 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar7 + 1;
                        iVar3 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar7)(piVar7);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar7 + 8))(piVar7);
                            }
                        }
                    }
                    func_0x000180459c3c(ppiVar11, 0x28);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar11 == ppiVar8) break;
                    ppiVar11 = ppiVar10;
                    if (ppiVar10 == ppiVar4) {
                        *ppiVar5 = (int64_t *)ppiVar10;
                        goto code_r0x000180023001;
                    }
                }
                *ppiVar5 = (int64_t *)ppiVar4;
                *(int64_t ***)var_10h = ppiVar4;
            }
            goto code_r0x000180023001;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180023029
// Address: 0x180023029
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180022ea0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar4 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x38) >> 3 <= *(uint64_t *)(arg1 + 0x10)) {
            fcn.180023230(in_stack_ffffffffffffffb8);
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            func_0x00018000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
            return;
        }
        ppiVar5 = (int64_t **)*ppiVar4;
        if (ppiVar5 != ppiVar4) {
            var_8h = (int64_t)ppiVar5[1];
            iVar6 = *(int64_t *)(arg1 + 0x18);
            iVar9 = ((((((uint64_t)*(uint8_t *)(ppiVar5 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                    0x10;
            var_18h = iVar9 + iVar6;
            var_20h = iVar9 + 8 + iVar6;
            var_10h = *(int64_t *)var_18h;
            ppiVar8 = *(int64_t ***)var_20h;
            ppiVar11 = ppiVar5;
            while( true ) {
                piVar7 = ppiVar11[4];
                ppiVar10 = (int64_t **)*ppiVar11;
                if (piVar7 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = piVar7 + 1;
                    iVar3 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)*piVar7)(piVar7);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                        iVar3 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)(*piVar7 + 8))(piVar7);
                        }
                    }
                }
                func_0x000180459c3c(ppiVar11, 0x28);
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                if (ppiVar11 == ppiVar8) break;
                ppiVar11 = ppiVar10;
                if (ppiVar10 == ppiVar4) {
                    if ((int64_t **)var_10h == ppiVar5) {
                        *(int64_t ***)var_18h = ppiVar10;
                    }
code_r0x000180023001:
                    *(int64_t ***)var_8h = ppiVar10;
                    ppiVar10[1] = (int64_t *)var_8h;
                    return;
                }
            }
            ppiVar8 = (int64_t **)var_8h;
            if ((int64_t **)var_10h == ppiVar5) {
                *(int64_t ***)var_18h = ppiVar4;
                ppiVar8 = ppiVar4;
            }
            *(int64_t ***)var_20h = ppiVar8;
            while (ppiVar10 != ppiVar4) {
                var_10h = ((((((uint64_t)*(uint8_t *)(ppiVar10 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x11)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x12)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x13)) * 0x100000001b3 &
                          *(uint64_t *)(arg1 + 0x30)) * 0x10;
                ppiVar5 = (int64_t **)(var_10h + iVar6);
                var_10h = iVar6 + 8 + var_10h;
                ppiVar8 = *(int64_t ***)var_10h;
                ppiVar11 = ppiVar10;
                while( true ) {
                    piVar7 = ppiVar11[4];
                    ppiVar10 = (int64_t **)*ppiVar11;
                    if (piVar7 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar7 + 1;
                        iVar3 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar7)(piVar7);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar7 + 8))(piVar7);
                            }
                        }
                    }
                    func_0x000180459c3c(ppiVar11, 0x28);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar11 == ppiVar8) break;
                    ppiVar11 = ppiVar10;
                    if (ppiVar10 == ppiVar4) {
                        *ppiVar5 = (int64_t *)ppiVar10;
                        goto code_r0x000180023001;
                    }
                }
                *ppiVar5 = (int64_t *)ppiVar4;
                *(int64_t ***)var_10h = ppiVar4;
            }
            goto code_r0x000180023001;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180023033
// Address: 0x180023033
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180022ea0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar4 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x38) >> 3 <= *(uint64_t *)(arg1 + 0x10)) {
            fcn.180023230(in_stack_ffffffffffffffb8);
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            func_0x00018000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
            return;
        }
        ppiVar5 = (int64_t **)*ppiVar4;
        if (ppiVar5 != ppiVar4) {
            var_8h = (int64_t)ppiVar5[1];
            iVar6 = *(int64_t *)(arg1 + 0x18);
            iVar9 = ((((((uint64_t)*(uint8_t *)(ppiVar5 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                    0x10;
            var_18h = iVar9 + iVar6;
            var_20h = iVar9 + 8 + iVar6;
            var_10h = *(int64_t *)var_18h;
            ppiVar8 = *(int64_t ***)var_20h;
            ppiVar11 = ppiVar5;
            while( true ) {
                piVar7 = ppiVar11[4];
                ppiVar10 = (int64_t **)*ppiVar11;
                if (piVar7 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = piVar7 + 1;
                    iVar3 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)*piVar7)(piVar7);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                        iVar3 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)(*piVar7 + 8))(piVar7);
                        }
                    }
                }
                func_0x000180459c3c(ppiVar11, 0x28);
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                if (ppiVar11 == ppiVar8) break;
                ppiVar11 = ppiVar10;
                if (ppiVar10 == ppiVar4) {
                    if ((int64_t **)var_10h == ppiVar5) {
                        *(int64_t ***)var_18h = ppiVar10;
                    }
code_r0x000180023001:
                    *(int64_t ***)var_8h = ppiVar10;
                    ppiVar10[1] = (int64_t *)var_8h;
                    return;
                }
            }
            ppiVar8 = (int64_t **)var_8h;
            if ((int64_t **)var_10h == ppiVar5) {
                *(int64_t ***)var_18h = ppiVar4;
                ppiVar8 = ppiVar4;
            }
            *(int64_t ***)var_20h = ppiVar8;
            while (ppiVar10 != ppiVar4) {
                var_10h = ((((((uint64_t)*(uint8_t *)(ppiVar10 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x11)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x12)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x13)) * 0x100000001b3 &
                          *(uint64_t *)(arg1 + 0x30)) * 0x10;
                ppiVar5 = (int64_t **)(var_10h + iVar6);
                var_10h = iVar6 + 8 + var_10h;
                ppiVar8 = *(int64_t ***)var_10h;
                ppiVar11 = ppiVar10;
                while( true ) {
                    piVar7 = ppiVar11[4];
                    ppiVar10 = (int64_t **)*ppiVar11;
                    if (piVar7 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar7 + 1;
                        iVar3 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar7)(piVar7);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar7 + 8))(piVar7);
                            }
                        }
                    }
                    func_0x000180459c3c(ppiVar11, 0x28);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar11 == ppiVar8) break;
                    ppiVar11 = ppiVar10;
                    if (ppiVar10 == ppiVar4) {
                        *ppiVar5 = (int64_t *)ppiVar10;
                        goto code_r0x000180023001;
                    }
                }
                *ppiVar5 = (int64_t *)ppiVar4;
                *(int64_t ***)var_10h = ppiVar4;
            }
            goto code_r0x000180023001;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180023039
// Address: 0x180023039
// Size: 297 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180022ea0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar4 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x38) >> 3 <= *(uint64_t *)(arg1 + 0x10)) {
            fcn.180023230(in_stack_ffffffffffffffb8);
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            func_0x00018000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
            return;
        }
        ppiVar5 = (int64_t **)*ppiVar4;
        if (ppiVar5 != ppiVar4) {
            var_8h = (int64_t)ppiVar5[1];
            iVar6 = *(int64_t *)(arg1 + 0x18);
            iVar9 = ((((((uint64_t)*(uint8_t *)(ppiVar5 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                    0x10;
            var_18h = iVar9 + iVar6;
            var_20h = iVar9 + 8 + iVar6;
            var_10h = *(int64_t *)var_18h;
            ppiVar8 = *(int64_t ***)var_20h;
            ppiVar11 = ppiVar5;
            while( true ) {
                piVar7 = ppiVar11[4];
                ppiVar10 = (int64_t **)*ppiVar11;
                if (piVar7 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = piVar7 + 1;
                    iVar3 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)*piVar7)(piVar7);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                        iVar3 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)(*piVar7 + 8))(piVar7);
                        }
                    }
                }
                func_0x000180459c3c(ppiVar11, 0x28);
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                if (ppiVar11 == ppiVar8) break;
                ppiVar11 = ppiVar10;
                if (ppiVar10 == ppiVar4) {
                    if ((int64_t **)var_10h == ppiVar5) {
                        *(int64_t ***)var_18h = ppiVar10;
                    }
code_r0x000180023001:
                    *(int64_t ***)var_8h = ppiVar10;
                    ppiVar10[1] = (int64_t *)var_8h;
                    return;
                }
            }
            ppiVar8 = (int64_t **)var_8h;
            if ((int64_t **)var_10h == ppiVar5) {
                *(int64_t ***)var_18h = ppiVar4;
                ppiVar8 = ppiVar4;
            }
            *(int64_t ***)var_20h = ppiVar8;
            while (ppiVar10 != ppiVar4) {
                var_10h = ((((((uint64_t)*(uint8_t *)(ppiVar10 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x11)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x12)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x13)) * 0x100000001b3 &
                          *(uint64_t *)(arg1 + 0x30)) * 0x10;
                ppiVar5 = (int64_t **)(var_10h + iVar6);
                var_10h = iVar6 + 8 + var_10h;
                ppiVar8 = *(int64_t ***)var_10h;
                ppiVar11 = ppiVar10;
                while( true ) {
                    piVar7 = ppiVar11[4];
                    ppiVar10 = (int64_t **)*ppiVar11;
                    if (piVar7 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar7 + 1;
                        iVar3 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar7)(piVar7);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar7 + 8))(piVar7);
                            }
                        }
                    }
                    func_0x000180459c3c(ppiVar11, 0x28);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar11 == ppiVar8) break;
                    ppiVar11 = ppiVar10;
                    if (ppiVar10 == ppiVar4) {
                        *ppiVar5 = (int64_t *)ppiVar10;
                        goto code_r0x000180023001;
                    }
                }
                *ppiVar5 = (int64_t *)ppiVar4;
                *(int64_t ***)var_10h = ppiVar4;
            }
            goto code_r0x000180023001;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180023162
// Address: 0x180023162
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180022ea0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar4 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x38) >> 3 <= *(uint64_t *)(arg1 + 0x10)) {
            fcn.180023230(in_stack_ffffffffffffffb8);
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            func_0x00018000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
            return;
        }
        ppiVar5 = (int64_t **)*ppiVar4;
        if (ppiVar5 != ppiVar4) {
            var_8h = (int64_t)ppiVar5[1];
            iVar6 = *(int64_t *)(arg1 + 0x18);
            iVar9 = ((((((uint64_t)*(uint8_t *)(ppiVar5 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar5 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) *
                    0x10;
            var_18h = iVar9 + iVar6;
            var_20h = iVar9 + 8 + iVar6;
            var_10h = *(int64_t *)var_18h;
            ppiVar8 = *(int64_t ***)var_20h;
            ppiVar11 = ppiVar5;
            while( true ) {
                piVar7 = ppiVar11[4];
                ppiVar10 = (int64_t **)*ppiVar11;
                if (piVar7 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = piVar7 + 1;
                    iVar3 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)*piVar7)(piVar7);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                        iVar3 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)(*piVar7 + 8))(piVar7);
                        }
                    }
                }
                func_0x000180459c3c(ppiVar11, 0x28);
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                if (ppiVar11 == ppiVar8) break;
                ppiVar11 = ppiVar10;
                if (ppiVar10 == ppiVar4) {
                    if ((int64_t **)var_10h == ppiVar5) {
                        *(int64_t ***)var_18h = ppiVar10;
                    }
code_r0x000180023001:
                    *(int64_t ***)var_8h = ppiVar10;
                    ppiVar10[1] = (int64_t *)var_8h;
                    return;
                }
            }
            ppiVar8 = (int64_t **)var_8h;
            if ((int64_t **)var_10h == ppiVar5) {
                *(int64_t ***)var_18h = ppiVar4;
                ppiVar8 = ppiVar4;
            }
            *(int64_t ***)var_20h = ppiVar8;
            while (ppiVar10 != ppiVar4) {
                var_10h = ((((((uint64_t)*(uint8_t *)(ppiVar10 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x11)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x12)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar10 + 0x13)) * 0x100000001b3 &
                          *(uint64_t *)(arg1 + 0x30)) * 0x10;
                ppiVar5 = (int64_t **)(var_10h + iVar6);
                var_10h = iVar6 + 8 + var_10h;
                ppiVar8 = *(int64_t ***)var_10h;
                ppiVar11 = ppiVar10;
                while( true ) {
                    piVar7 = ppiVar11[4];
                    ppiVar10 = (int64_t **)*ppiVar11;
                    if (piVar7 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar7 + 1;
                        iVar3 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar7)(piVar7);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar7 + 8))(piVar7);
                            }
                        }
                    }
                    func_0x000180459c3c(ppiVar11, 0x28);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar11 == ppiVar8) break;
                    ppiVar11 = ppiVar10;
                    if (ppiVar10 == ppiVar4) {
                        *ppiVar5 = (int64_t *)ppiVar10;
                        goto code_r0x000180023001;
                    }
                }
                *ppiVar5 = (int64_t *)ppiVar4;
                *(int64_t ***)var_10h = ppiVar4;
            }
            goto code_r0x000180023001;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180023200
// Address: 0x180023200
// Size: 43 bytes
// ============================================================
int64_t fcn.180023200(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1806219d8;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x20);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023230
// Address: 0x180023230
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180023230(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar6 = *(undefined8 **)arg2;
    while (puVar6 != (undefined8 *)0x0) {
        piVar4 = (int64_t *)puVar6[4];
        puVar5 = (undefined8 *)*puVar6;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(puVar6, 0x28);
        puVar6 = puVar5;
    }
    return;
}

// ============================================================
// Function: FUN_180023249
// Address: 0x180023249
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180023230(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar6 = *(undefined8 **)arg2;
    while (puVar6 != (undefined8 *)0x0) {
        piVar4 = (int64_t *)puVar6[4];
        puVar5 = (undefined8 *)*puVar6;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(puVar6, 0x28);
        puVar6 = puVar5;
    }
    return;
}

// ============================================================
// Function: FUN_1800232ad
// Address: 0x1800232ad
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180023230(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    undefined8 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar6 = *(undefined8 **)arg2;
    while (puVar6 != (undefined8 *)0x0) {
        piVar4 = (int64_t *)puVar6[4];
        puVar5 = (undefined8 *)*puVar6;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        fcn.180459c3c(puVar6, 0x28);
        puVar6 = puVar5;
    }
    return;
}

// ============================================================
// Function: FUN_1800232c0
// Address: 0x1800232c0
// Size: 4 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800232c0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((*(int64_t *)(arg1 + 8) != 0) &&
       (piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0x20), piVar3 != (int64_t *)0x0)) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar5 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar5 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    iVar4 = *(int64_t *)(arg1 + 8);
    if (iVar4 == 0) {
        return;
    }
    if ((iVar4 != 0) &&
       (iVar5 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar4, in_R9, unaff_RBX), iVar5 == 0)) {
        uVar6 = (*(code *)0x699ff6)();
        uVar6 = fcn.18046b63c(uVar6);
        puVar7 = (undefined4 *)fcn.18046b77c();
        *puVar7 = uVar6;
    }
    return;
}

// ============================================================
// Function: FUN_1800232c4
// Address: 0x1800232c4
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800232c0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((*(int64_t *)(arg1 + 8) != 0) &&
       (piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0x20), piVar3 != (int64_t *)0x0)) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar5 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar5 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    iVar4 = *(int64_t *)(arg1 + 8);
    if (iVar4 == 0) {
        return;
    }
    if ((iVar4 != 0) &&
       (iVar5 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar4, in_R9, unaff_RBX), iVar5 == 0)) {
        uVar6 = (*(code *)0x699ff6)();
        uVar6 = fcn.18046b63c(uVar6);
        puVar7 = (undefined4 *)fcn.18046b77c();
        *puVar7 = uVar6;
    }
    return;
}

// ============================================================
// Function: FUN_1800232e3
// Address: 0x1800232e3
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800232c0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((*(int64_t *)(arg1 + 8) != 0) &&
       (piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0x20), piVar3 != (int64_t *)0x0)) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar5 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar5 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    iVar4 = *(int64_t *)(arg1 + 8);
    if (iVar4 == 0) {
        return;
    }
    if ((iVar4 != 0) &&
       (iVar5 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar4, in_R9, unaff_RBX), iVar5 == 0)) {
        uVar6 = (*(code *)0x699ff6)();
        uVar6 = fcn.18046b63c(uVar6);
        puVar7 = (undefined4 *)fcn.18046b77c();
        *puVar7 = uVar6;
    }
    return;
}

// ============================================================
// Function: FUN_180023319
// Address: 0x180023319
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800232c0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((*(int64_t *)(arg1 + 8) != 0) &&
       (piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0x20), piVar3 != (int64_t *)0x0)) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar5 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar5 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    iVar4 = *(int64_t *)(arg1 + 8);
    if (iVar4 == 0) {
        return;
    }
    if ((iVar4 != 0) &&
       (iVar5 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar4, in_R9, unaff_RBX), iVar5 == 0)) {
        uVar6 = (*(code *)0x699ff6)();
        uVar6 = fcn.18046b63c(uVar6);
        puVar7 = (undefined4 *)fcn.18046b77c();
        *puVar7 = uVar6;
    }
    return;
}

// ============================================================
// Function: FUN_18002332c
// Address: 0x18002332c
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800232c0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((*(int64_t *)(arg1 + 8) != 0) &&
       (piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0x20), piVar3 != (int64_t *)0x0)) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar5 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar5 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    iVar4 = *(int64_t *)(arg1 + 8);
    if (iVar4 == 0) {
        return;
    }
    if ((iVar4 != 0) &&
       (iVar5 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar4, in_R9, unaff_RBX), iVar5 == 0)) {
        uVar6 = (*(code *)0x699ff6)();
        uVar6 = fcn.18046b63c(uVar6);
        puVar7 = (undefined4 *)fcn.18046b77c();
        *puVar7 = uVar6;
    }
    return;
}

// ============================================================
// Function: FUN_180023360
// Address: 0x180023360
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.180023360(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined8 *puVar5;
    undefined4 *puVar6;
    int64_t var_8h;
    
    fcn.180086ba0(arg1, *(undefined8 *)0x180782630, 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar5 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
    iVar1 = *(int64_t *)(arg1 + 0x40);
    puVar6 = (undefined4 *)fcn.1800a0ea0(*puVar5, iVar1 + -0x10);
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *(undefined4 *)(iVar1 + -0x10) = *puVar6;
    *(undefined4 *)(iVar1 + -0xc) = uVar2;
    *(undefined4 *)(iVar1 + -8) = uVar3;
    *(undefined4 *)(iVar1 + -4) = uVar4;
    return *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + -4);
}

// ============================================================
// Function: FUN_1800233d0
// Address: 0x1800233d0
// Size: 269 bytes
// ============================================================
undefined8 fcn.1800233d0(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar2 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar2 + 0xc) == 9) {
        if ((*(uint8_t *)(*piVar2 + 3) == *(uint32_t *)0x1807823dc) && (*piVar2 != -0x10)) {
            piVar2 = piVar4 + 2;
            if (*(int64_t **)(arg1 + 0x40) <= piVar4 + 2) {
                piVar2 = *(int64_t **)0x180782430;
            }
            if (((*(int32_t *)((int64_t)piVar2 + 0xc) == 9) && (*(uint8_t *)(*piVar2 + 3) == *(uint32_t *)0x1807823dc))
               && (*piVar2 != -0x10)) {
                fcn.180023360(arg1);
                piVar4 = *(int64_t **)(arg1 + 0x28);
                if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if (*(int32_t *)((int64_t)piVar4 + 0xc) == 9) {
                    puVar5 = (undefined8 *)(*piVar4 + 0x10);
                } else if (*(int32_t *)((int64_t)piVar4 + 0xc) == 2) {
                    puVar5 = (undefined8 *)*piVar4;
                } else {
                    puVar5 = (undefined8 *)0x0;
                }
                fcn.180086ba0(arg1, *puVar5, 0);
                func_0x000180085bf0(arg1, 2);
                func_0x000180087440(arg1, 0xfffffffd);
                return 0;
            }
            func_0x000180088380(arg1, 2, 0x1806217c8);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800234e0
// Address: 0x1800234e0
// Size: 172 bytes
// ============================================================
undefined8 fcn.1800234e0(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar2 + 0xc) == 9) && (*(uint8_t *)(*piVar2 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*piVar2 != -0x10)) {
        fcn.180023360(arg1);
        piVar2 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar2 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar2 + 0xc) == 9) {
            puVar4 = (undefined8 *)(*piVar2 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar2 + 0xc) == 2) {
            puVar4 = (undefined8 *)*piVar2;
        } else {
            puVar4 = (undefined8 *)0x0;
        }
        fcn.180086ba0(arg1, *puVar4, 0);
        func_0x000180086510(arg1);
        func_0x000180087440(arg1, 0xfffffffd);
        return 0;
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180023590
// Address: 0x180023590
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180023590(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(uint8_t *)(*piVar6 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*piVar6 != -0x10)) {
        fcn.180023360(arg1);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            puVar9 = (undefined8 *)(*piVar6 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            puVar9 = (undefined8 *)*piVar6;
        } else {
            puVar9 = (undefined8 *)0x0;
        }
        fcn.180086ba0(arg1, *puVar9, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar7;
        *(undefined4 *)(iVar1 + -0xc) = uVar3;
        *(undefined4 *)(iVar1 + -8) = uVar4;
        *(undefined4 *)(iVar1 + -4) = uVar5;
        func_0x000180086b20(arg1, *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0);
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_1800235d6
// Address: 0x1800235d6
// Size: 160 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180023590(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(uint8_t *)(*piVar6 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*piVar6 != -0x10)) {
        fcn.180023360(arg1);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            puVar9 = (undefined8 *)(*piVar6 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            puVar9 = (undefined8 *)*piVar6;
        } else {
            puVar9 = (undefined8 *)0x0;
        }
        fcn.180086ba0(arg1, *puVar9, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar7;
        *(undefined4 *)(iVar1 + -0xc) = uVar3;
        *(undefined4 *)(iVar1 + -8) = uVar4;
        *(undefined4 *)(iVar1 + -4) = uVar5;
        func_0x000180086b20(arg1, *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0);
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_180023676
// Address: 0x180023676
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180023590(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(uint8_t *)(*piVar6 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*piVar6 != -0x10)) {
        fcn.180023360(arg1);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            puVar9 = (undefined8 *)(*piVar6 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            puVar9 = (undefined8 *)*piVar6;
        } else {
            puVar9 = (undefined8 *)0x0;
        }
        fcn.180086ba0(arg1, *puVar9, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar1 = *(int64_t *)(arg1 + 0x40);
        puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *(undefined4 *)(iVar1 + -0x10) = *puVar7;
        *(undefined4 *)(iVar1 + -0xc) = uVar3;
        *(undefined4 *)(iVar1 + -8) = uVar4;
        *(undefined4 *)(iVar1 + -4) = uVar5;
        func_0x000180086b20(arg1, *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0);
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_180023690
// Address: 0x180023690
// Size: 19 bytes
// ============================================================
undefined8 fcn.180023690(int64_t arg1)
{
    fcn.180023360(arg1);
    return 1;
}

// ============================================================
// Function: FUN_1800236b0
// Address: 0x1800236b0
// Size: 271 bytes
// ============================================================
undefined8 fcn.1800236b0(int64_t arg1)
{
    int64_t **ppiVar1;
    code *pcVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    
    ppiVar7 = *(int64_t ***)(arg1 + 0x28);
    ppiVar1 = *(int64_t ***)(arg1 + 0x40);
    ppiVar3 = ppiVar7;
    if (ppiVar1 <= ppiVar7) {
        ppiVar3 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar3 + 0xc) != 9) ||
        (*(uint8_t *)((int64_t)*ppiVar3 + 3) != *(uint32_t *)0x1807823dc)) ||
       (*ppiVar3 == (int64_t *)0xfffffffffffffff0)) {
        func_0x000180088380(arg1, 1, 0x1806217c8);
        pcVar2 = (code *)swi(3);
        uVar6 = (*pcVar2)();
        return uVar6;
    }
    ppiVar3 = ppiVar7 + 2;
    ppiVar4 = ppiVar3;
    if (ppiVar1 <= ppiVar3) {
        ppiVar4 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar4 + 0xc) == 9) &&
        (*(uint8_t *)((int64_t)*ppiVar4 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*ppiVar4 != (int64_t *)0xfffffffffffffff0)) {
        if (ppiVar1 <= ppiVar7) {
            ppiVar7 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar7 + 0xc) == 9) {
            piVar8 = *ppiVar7 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar7 + 0xc) == 2) {
            piVar8 = *ppiVar7;
        } else {
            piVar8 = (int64_t *)0x0;
        }
        if (ppiVar1 <= ppiVar3) {
            ppiVar3 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar3 + 0xc) == 9) {
            piVar5 = *ppiVar3 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar3 + 0xc) == 2) {
            piVar5 = *ppiVar3;
        } else {
            piVar5 = (int64_t *)0x0;
        }
        func_0x000180086b20(arg1, *piVar8 == *piVar5);
        return 1;
    }
    func_0x000180088380(arg1, 2, 0x1806217c8);
    pcVar2 = (code *)swi(3);
    uVar6 = (*pcVar2)();
    return uVar6;
}

// ============================================================
// Function: FUN_1800237c0
// Address: 0x1800237c0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800237c0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(uint8_t *)(*piVar6 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*piVar6 != -0x10)) {
        fcn.180023360(arg1);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            puVar9 = (undefined8 *)(*piVar6 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            puVar9 = (undefined8 *)*piVar6;
        } else {
            puVar9 = (undefined8 *)0x0;
        }
        uVar8 = *puVar9;
        fcn.180086ba0(arg1, uVar8, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar10 = *(int64_t *)(arg1 + 0x40);
        puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar10 + -0x20), (undefined4 *)(iVar10 + -0x10));
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)(iVar10 + -0x10) = *puVar7;
        *(undefined4 *)(iVar10 + -0xc) = uVar2;
        *(undefined4 *)(iVar10 + -8) = uVar3;
        *(undefined4 *)(iVar10 + -4) = uVar4;
        fcn.180086ba0(arg1, uVar8, 0);
        func_0x000180086510(arg1);
        func_0x000180087440(arg1, 0xfffffffc);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            iVar10 = *piVar6 + 0x10;
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            iVar10 = *piVar6;
        } else {
            iVar10 = 0;
        }
        (**(code **)0x180782630)(arg1, iVar10);
        fcn.180086ba0(arg1, uVar8, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar5 = func_0x000180085510(arg1, 1);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                func_0x000180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar8 = (*pcVar1)();
                return uVar8;
            }
        }
        puVar7 = *(undefined4 **)(arg1 + 0x40);
        *puVar7 = puVar7[-0xc];
        puVar7[1] = puVar7[-0xb];
        puVar7[2] = puVar7[-10];
        puVar7[3] = puVar7[-9];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087440(arg1, 0xfffffffb);
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar1 = (code *)swi(3);
    uVar8 = (*pcVar1)();
    return uVar8;
}

// ============================================================
// Function: FUN_180023803
// Address: 0x180023803
// Size: 206 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800237c0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(uint8_t *)(*piVar6 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*piVar6 != -0x10)) {
        fcn.180023360(arg1);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            puVar9 = (undefined8 *)(*piVar6 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            puVar9 = (undefined8 *)*piVar6;
        } else {
            puVar9 = (undefined8 *)0x0;
        }
        uVar8 = *puVar9;
        fcn.180086ba0(arg1, uVar8, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar10 = *(int64_t *)(arg1 + 0x40);
        puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar10 + -0x20), (undefined4 *)(iVar10 + -0x10));
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)(iVar10 + -0x10) = *puVar7;
        *(undefined4 *)(iVar10 + -0xc) = uVar2;
        *(undefined4 *)(iVar10 + -8) = uVar3;
        *(undefined4 *)(iVar10 + -4) = uVar4;
        fcn.180086ba0(arg1, uVar8, 0);
        func_0x000180086510(arg1);
        func_0x000180087440(arg1, 0xfffffffc);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            iVar10 = *piVar6 + 0x10;
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            iVar10 = *piVar6;
        } else {
            iVar10 = 0;
        }
        (**(code **)0x180782630)(arg1, iVar10);
        fcn.180086ba0(arg1, uVar8, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar5 = func_0x000180085510(arg1, 1);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                func_0x000180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar8 = (*pcVar1)();
                return uVar8;
            }
        }
        puVar7 = *(undefined4 **)(arg1 + 0x40);
        *puVar7 = puVar7[-0xc];
        puVar7[1] = puVar7[-0xb];
        puVar7[2] = puVar7[-10];
        puVar7[3] = puVar7[-9];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087440(arg1, 0xfffffffb);
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar1 = (code *)swi(3);
    uVar8 = (*pcVar1)();
    return uVar8;
}

// ============================================================
// Function: FUN_1800238d1
// Address: 0x1800238d1
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800237c0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(uint8_t *)(*piVar6 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*piVar6 != -0x10)) {
        fcn.180023360(arg1);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            puVar9 = (undefined8 *)(*piVar6 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            puVar9 = (undefined8 *)*piVar6;
        } else {
            puVar9 = (undefined8 *)0x0;
        }
        uVar8 = *puVar9;
        fcn.180086ba0(arg1, uVar8, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar10 = *(int64_t *)(arg1 + 0x40);
        puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar10 + -0x20), (undefined4 *)(iVar10 + -0x10));
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)(iVar10 + -0x10) = *puVar7;
        *(undefined4 *)(iVar10 + -0xc) = uVar2;
        *(undefined4 *)(iVar10 + -8) = uVar3;
        *(undefined4 *)(iVar10 + -4) = uVar4;
        fcn.180086ba0(arg1, uVar8, 0);
        func_0x000180086510(arg1);
        func_0x000180087440(arg1, 0xfffffffc);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            iVar10 = *piVar6 + 0x10;
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            iVar10 = *piVar6;
        } else {
            iVar10 = 0;
        }
        (**(code **)0x180782630)(arg1, iVar10);
        fcn.180086ba0(arg1, uVar8, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar5 = func_0x000180085510(arg1, 1);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                func_0x000180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar8 = (*pcVar1)();
                return uVar8;
            }
        }
        puVar7 = *(undefined4 **)(arg1 + 0x40);
        *puVar7 = puVar7[-0xc];
        puVar7[1] = puVar7[-0xb];
        puVar7[2] = puVar7[-10];
        puVar7[3] = puVar7[-9];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087440(arg1, 0xfffffffb);
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar1 = (code *)swi(3);
    uVar8 = (*pcVar1)();
    return uVar8;
}

// ============================================================
// Function: FUN_180023907
// Address: 0x180023907
// Size: 149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800237c0(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(uint8_t *)(*piVar6 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*piVar6 != -0x10)) {
        fcn.180023360(arg1);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            puVar9 = (undefined8 *)(*piVar6 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            puVar9 = (undefined8 *)*piVar6;
        } else {
            puVar9 = (undefined8 *)0x0;
        }
        uVar8 = *puVar9;
        fcn.180086ba0(arg1, uVar8, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar10 = *(int64_t *)(arg1 + 0x40);
        puVar7 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar10 + -0x20), (undefined4 *)(iVar10 + -0x10));
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)(iVar10 + -0x10) = *puVar7;
        *(undefined4 *)(iVar10 + -0xc) = uVar2;
        *(undefined4 *)(iVar10 + -8) = uVar3;
        *(undefined4 *)(iVar10 + -4) = uVar4;
        fcn.180086ba0(arg1, uVar8, 0);
        func_0x000180086510(arg1);
        func_0x000180087440(arg1, 0xfffffffc);
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
            iVar10 = *piVar6 + 0x10;
        } else if (*(int32_t *)((int64_t)piVar6 + 0xc) == 2) {
            iVar10 = *piVar6;
        } else {
            iVar10 = 0;
        }
        (**(code **)0x180782630)(arg1, iVar10);
        fcn.180086ba0(arg1, uVar8, 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar5 = func_0x000180085510(arg1, 1);
            if (iVar5 == 0) {
                func_0x000180099450(arg1, 0x18063d8d0);
                func_0x000180087960(arg1);
                pcVar1 = (code *)swi(3);
                uVar8 = (*pcVar1)();
                return uVar8;
            }
        }
        puVar7 = *(undefined4 **)(arg1 + 0x40);
        *puVar7 = puVar7[-0xc];
        puVar7[1] = puVar7[-0xb];
        puVar7[2] = puVar7[-10];
        puVar7[3] = puVar7[-9];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087440(arg1, 0xfffffffb);
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar1 = (code *)swi(3);
    uVar8 = (*pcVar1)();
    return uVar8;
}

// ============================================================
// Function: FUN_1800239a0
// Address: 0x1800239a0
// Size: 516 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

void fcn.1800239a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    func_0x000180018f70();
    func_0x000180086fd0(arg2, 0, 0);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.1800233d0, 0x180621a08, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621a08);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.1800234e0, 0x1806219f8, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x1806219f8);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180023590, 0x180621a18, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621a18);
    *(undefined *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 4) = 1;
    func_0x000180087370(arg2, 0xfffffffe, 0x180621a10);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180023690, 0x180621a40, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621a40);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.1800236b0, 0x180621a28, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180621a28);
    var_38h = 0x180621a68;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    func_0x0001800869f0(arg2, fcn.1800237c0, 0x180621a58, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180621a58);
    piVar4 = &var_38h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180621a58);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_30h);
    return;
}

// ============================================================
// Function: FUN_180023bb0
// Address: 0x180023bb0
// Size: 364 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180023bb0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [16];
    bool bVar11;
    bool bVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined *puVar18;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    uint64_t uStack_20;
    uint64_t uStack_18;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar15 = *(int64_t *)(arg1 + 8);
    var_40h = arg2;
    var_68h._0_4_ = 0;
    if (iVar15 == 0) {
        var_50h = 0;
        stack0xffffffffffffffa1 = SUB1615(ZEXT816(0), 1);
        auVar10[15] = 0;
        auVar10._0_15_ = stack0xffffffffffffffa1;
        _var_60h = auVar10 << 8;
        piVar14 = &var_60h;
        var_48h = 0xf;
        bVar12 = false;
        bVar11 = true;
    } else {
        iVar17 = *(int64_t *)(iVar15 + 0x28);
        if (iVar17 == 0) {
            iVar17 = iVar15 + 0x30;
        }
        var_28h = 0;
        uStack_20 = 0;
        _var_38h = ZEXT816(0);
        uVar13 = func_0x000180498cd0(iVar17);
        func_0x000180004830(&var_38h, iVar17, uVar13);
        piVar14 = &var_38h;
        bVar12 = true;
        bVar11 = false;
    }
    uVar2 = *(undefined4 *)piVar14;
    uVar3 = *(undefined4 *)((int64_t)piVar14 + 4);
    uVar4 = *(undefined4 *)(piVar14 + 1);
    uVar5 = *(undefined4 *)((int64_t)piVar14 + 0xc);
    uVar6 = *(undefined4 *)(piVar14 + 2);
    uVar7 = *(undefined4 *)((int64_t)piVar14 + 0x14);
    uVar8 = *(undefined4 *)(piVar14 + 3);
    uVar9 = *(undefined4 *)((int64_t)piVar14 + 0x1c);
    piVar14[2] = 0;
    piVar14[3] = 0xf;
    *(undefined *)piVar14 = 0;
    *(undefined4 *)arg2 = uVar2;
    *(undefined4 *)(arg2 + 4) = uVar3;
    *(undefined4 *)(arg2 + 8) = uVar4;
    *(undefined4 *)(arg2 + 0xc) = uVar5;
    *(undefined4 *)(arg2 + 0x10) = uVar6;
    *(undefined4 *)(arg2 + 0x14) = uVar7;
    *(undefined4 *)(arg2 + 0x18) = uVar8;
    *(undefined4 *)(arg2 + 0x1c) = uVar9;
    if ((bVar11) && (0xf < (uint64_t)var_48h)) {
        uVar16 = var_48h + 1;
        iVar15 = var_60h;
        if (uVar16 < 0x1000) {
code_r0x000180023cab:
            fcn.180459c3c(iVar15, uVar16);
            goto code_r0x000180023cb0;
        }
        if ((var_60h - *(int64_t *)(var_60h + -8)) - 8U < 0x20) {
            uVar16 = var_48h + 0x28;
            iVar15 = *(int64_t *)(var_60h + -8);
            goto code_r0x000180023cab;
        }
code_r0x000180023ce8:
        pcVar1 = (code *)swi(0x29);
        iVar15 = (*pcVar1)(5);
        puVar18 = auStack_80;
    } else {
code_r0x000180023cb0:
        puVar18 = auStack_88;
        if ((!bVar12) || (puVar18 = auStack_88, uStack_20 < 0x10)) goto code_r0x000180023cf7;
        iVar15 = var_38h;
        puVar18 = auStack_88;
        if ((0xfff < uStack_20 + 1) &&
           (iVar15 = *(int64_t *)(var_38h + -8), puVar18 = auStack_88,
           0x1f < (var_38h - *(int64_t *)(var_38h + -8)) - 8U)) goto code_r0x000180023ce8;
    }
    *(undefined8 *)(puVar18 + -8) = 0x180023cf7;
    fcn.180459c3c(iVar15);
code_r0x000180023cf7:
    *(undefined8 *)(puVar18 + -8) = 0x180023d07;
    func_0x000180459870(*(uint64_t *)(puVar18 + 0x70) ^ (uint64_t)puVar18);
    return;
}

// ============================================================
// Function: FUN_180023d20
// Address: 0x180023d20
// Size: 43 bytes
// ============================================================
int64_t fcn.180023d20(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x20);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023d50
// Address: 0x180023d50
// Size: 43 bytes
// ============================================================
int64_t fcn.180023d50(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023d80
// Address: 0x180023d80
// Size: 43 bytes
// ============================================================
int64_t fcn.180023d80(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023db0
// Address: 0x180023db0
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023db0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x180621f08;
    puVar2 = *(undefined8 **)(arg1 + 0x20);
    while (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar2[2];
        puVar2[2] = 0;
        (**(code **)*puVar2)(puVar2, 1);
        puVar2 = puVar1;
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023db6
// Address: 0x180023db6
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023db0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x180621f08;
    puVar2 = *(undefined8 **)(arg1 + 0x20);
    while (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar2[2];
        puVar2[2] = 0;
        (**(code **)*puVar2)(puVar2, 1);
        puVar2 = puVar1;
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023dd8
// Address: 0x180023dd8
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023db0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x180621f08;
    puVar2 = *(undefined8 **)(arg1 + 0x20);
    while (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar2[2];
        puVar2[2] = 0;
        (**(code **)*puVar2)(puVar2, 1);
        puVar2 = puVar1;
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023e01
// Address: 0x180023e01
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023db0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x180621f08;
    puVar2 = *(undefined8 **)(arg1 + 0x20);
    while (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar2[2];
        puVar2[2] = 0;
        (**(code **)*puVar2)(puVar2, 1);
        puVar2 = puVar1;
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023e1b
// Address: 0x180023e1b
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023db0(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x180621f08;
    puVar2 = *(undefined8 **)(arg1 + 0x20);
    while (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar2[2];
        puVar2[2] = 0;
        (**(code **)*puVar2)(puVar2, 1);
        puVar2 = puVar1;
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023e40
// Address: 0x180023e40
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023e40(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x1806220b8;
    puVar3 = *(undefined8 **)(arg1 + 0x28);
    while (puVar3 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar3[5];
        puVar3[5] = 0;
        puVar2 = *(undefined8 **)(arg1 + 0x20);
        puVar4 = puVar3;
        while ((puVar3 = puVar1, puVar4 != puVar2 && (puVar4 != (undefined8 *)0x0))) {
            puVar3 = (undefined8 *)puVar4[2];
            puVar4[2] = 0;
            (**(code **)*puVar4)(puVar4, 1);
            puVar4 = puVar3;
        }
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023e46
// Address: 0x180023e46
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023e40(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x1806220b8;
    puVar3 = *(undefined8 **)(arg1 + 0x28);
    while (puVar3 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar3[5];
        puVar3[5] = 0;
        puVar2 = *(undefined8 **)(arg1 + 0x20);
        puVar4 = puVar3;
        while ((puVar3 = puVar1, puVar4 != puVar2 && (puVar4 != (undefined8 *)0x0))) {
            puVar3 = (undefined8 *)puVar4[2];
            puVar4[2] = 0;
            (**(code **)*puVar4)(puVar4, 1);
            puVar4 = puVar3;
        }
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023e68
// Address: 0x180023e68
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023e40(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x1806220b8;
    puVar3 = *(undefined8 **)(arg1 + 0x28);
    while (puVar3 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar3[5];
        puVar3[5] = 0;
        puVar2 = *(undefined8 **)(arg1 + 0x20);
        puVar4 = puVar3;
        while ((puVar3 = puVar1, puVar4 != puVar2 && (puVar4 != (undefined8 *)0x0))) {
            puVar3 = (undefined8 *)puVar4[2];
            puVar4[2] = 0;
            (**(code **)*puVar4)(puVar4, 1);
            puVar4 = puVar3;
        }
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023ecb
// Address: 0x180023ecb
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023e40(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x1806220b8;
    puVar3 = *(undefined8 **)(arg1 + 0x28);
    while (puVar3 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar3[5];
        puVar3[5] = 0;
        puVar2 = *(undefined8 **)(arg1 + 0x20);
        puVar4 = puVar3;
        while ((puVar3 = puVar1, puVar4 != puVar2 && (puVar4 != (undefined8 *)0x0))) {
            puVar3 = (undefined8 *)puVar4[2];
            puVar4[2] = 0;
            (**(code **)*puVar4)(puVar4, 1);
            puVar4 = puVar3;
        }
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023ee5
// Address: 0x180023ee5
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180023e40(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0x1806220b8;
    puVar3 = *(undefined8 **)(arg1 + 0x28);
    while (puVar3 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)puVar3[5];
        puVar3[5] = 0;
        puVar2 = *(undefined8 **)(arg1 + 0x20);
        puVar4 = puVar3;
        while ((puVar3 = puVar1, puVar4 != puVar2 && (puVar4 != (undefined8 *)0x0))) {
            puVar3 = (undefined8 *)puVar4[2];
            puVar4[2] = 0;
            (**(code **)*puVar4)(puVar4, 1);
            puVar4 = puVar3;
        }
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023f00
// Address: 0x180023f00
// Size: 43 bytes
// ============================================================
int64_t fcn.180023f00(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x38);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180023f30
// Address: 0x180023f30
// Size: 508 bytes
// ============================================================
void fcn.180023f30(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    undefined8 uVar13;
    
    fcn.180086ba0(arg1, arg2, 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar10 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
    iVar1 = *(int64_t *)(arg1 + 0x40);
    puVar11 = (undefined4 *)fcn.1800a0ea0(*puVar10, iVar1 + -0x10);
    uVar6 = puVar11[1];
    uVar7 = puVar11[2];
    uVar8 = puVar11[3];
    *(undefined4 *)(iVar1 + -0x10) = *puVar11;
    *(undefined4 *)(iVar1 + -0xc) = uVar6;
    *(undefined4 *)(iVar1 + -8) = uVar7;
    *(undefined4 *)(iVar1 + -4) = uVar8;
    uVar2 = *(uint64_t *)(arg1 + 0x40);
    if ((uVar2 - 0x10 != *(int64_t *)0x180782430) && (*(int32_t *)(uVar2 - 4) == 7)) {
        return;
    }
    *(uint64_t *)(arg1 + 0x40) = uVar2 - 0x10;
    if (((*(char *)0x180777010 == '\0') || (uVar2 <= **(uint64_t **)(arg1 + 0x18))) ||
       (iVar9 = func_0x000180085510(arg1, 1), iVar9 != 0)) {
        piVar3 = *(int64_t **)(arg1 + 0x40);
        *piVar3 = arg2;
        *(undefined4 *)(piVar3 + 1) = 0;
        *(undefined4 *)((int64_t)piVar3 + 0xc) = 2;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180086fd0(arg1, 0, 0);
        func_0x000180086fd0(arg1, 0, 0);
        if ((int32_t)arg3 == 0) {
            uVar13 = 0x180621a84;
        } else if ((int32_t)arg3 == 1) {
            uVar13 = 0x180621a80;
        } else {
            uVar13 = 0x180621a90;
        }
        uVar12 = func_0x000180498cd0(uVar13);
        func_0x0001800867f0(arg1, uVar13, uVar12);
        func_0x000180087370(arg1, 0xfffffffe, 0x180621a88);
        func_0x000180087650(arg1, 0xfffffffe);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar9 = func_0x000180085510(arg1, 1), iVar9 != 0)) {
            puVar11 = *(undefined4 **)(arg1 + 0x40);
            *puVar11 = puVar11[-4];
            puVar11[1] = puVar11[-3];
            puVar11[2] = puVar11[-2];
            puVar11[3] = puVar11[-1];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar4 = *(undefined4 **)(arg1 + 0x40);
            for (puVar11 = puVar4; puVar4 + -0xc < puVar11; puVar11 = puVar11 + -4) {
                *puVar11 = puVar11[-4];
                puVar11[1] = puVar11[-3];
                puVar11[2] = puVar11[-2];
                puVar11[3] = puVar11[-1];
            }
            puVar11 = *(undefined4 **)(arg1 + 0x40);
            uVar6 = puVar11[1];
            uVar7 = puVar11[2];
            uVar8 = puVar11[3];
            puVar4[-0xc] = *puVar11;
            puVar4[-0xb] = uVar6;
            puVar4[-10] = uVar7;
            puVar4[-9] = uVar8;
            func_0x000180087440(arg1, 0xffffd8f0);
            return;
        }
    }
    func_0x000180099450(arg1, 0x18063d8d0);
    func_0x000180087960(arg1);
    pcVar5 = (code *)swi(3);
    (*pcVar5)();
    return;
}

// ============================================================
// Function: FUN_180024130
// Address: 0x180024130
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180024130(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar7 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    fcn.180023f30(arg1, arg2, arg3);
    func_0x000180085bf0(arg1, uVar7 & 0xffffffff);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    iVar1 = *(int64_t *)(arg1 + 0x40);
    puVar6 = (undefined4 *)fcn.1800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
    iVar5 = *(int64_t *)0x180782430;
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *(undefined4 *)(iVar1 + -0x10) = *puVar6;
    *(undefined4 *)(iVar1 + -0xc) = uVar2;
    *(undefined4 *)(iVar1 + -8) = uVar3;
    *(undefined4 *)(iVar1 + -4) = uVar4;
    iVar1 = *(int64_t *)(arg1 + 0x40);
    if ((((iVar1 + -0x10 != iVar5) && (*(int32_t *)(iVar1 + -4) != 0)) && (iVar1 + -0x10 != iVar5)) &&
       (*(int32_t *)(iVar1 + -4) != -1)) {
        func_0x000180085a50(arg1, uVar7 & 0xffffffff);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        return 1;
    }
    *(int64_t *)(arg1 + 0x40) = iVar1 + -0x30;
    return 0;
}

