// Chunk 136 - 50 functions

// ============================================================
// Function: FUN_1801d4370
// Address: 0x1801d4370
// Size: 70 bytes
// ============================================================
undefined4
fcn.1801d4370(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint64_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    int32_t *piVar6;
    undefined8 in_RDX;
    int64_t iVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h;
    int64_t var_19h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b4h;
    int64_t var_1a8h;
    int64_t var_19ch;
    int64_t var_194h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_16ch;
    int64_t var_15ch;
    int64_t var_14ch;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = 0x1801d4386;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    if (in_RCX != (undefined4 *)0x0) {
        iVar7 = *(int64_t *)(in_RCX + 0xbe);
        piVar6 = in_RCX + 0xc0;
        if ((iVar7 != 0) || (*piVar6 != 0)) {
            *(undefined8 *)(&stack0x00000240 + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = 0;
            *(undefined4 *)((int64_t)&arg_28h + iVar5 + 4) = *in_RCX;
            *(undefined8 *)(&stack0x00000250 + iVar5) = unaff_R14;
            *(undefined4 *)((int64_t)&arg_28h + iVar5) = 1;
            if (iVar7 != 0) {
                piVar6 = (int32_t *)(iVar7 + 0x18);
            }
            var_19h._0_1_ = (undefined)*piVar6;
            var_18h = (undefined)((uint32_t)*piVar6 >> 8);
            var_130h = (int64_t)&var_18h;
            *(int64_t **)((int64_t)&arg_30h + iVar5) = &var_138h;
            var_138h._0_4_ = 2;
            var_128h._0_4_ = 0;
            if (in_RCX[0xbc] != 0) {
                var_8h._0_1_ = (undefined)in_RCX[0xbc];
                var_118h = (int64_t)&var_8h;
                *(int64_t **)((int64_t)&arg_38h + iVar5) = &var_120h;
                var_120h._0_4_ = 1;
                var_110h._0_4_ = 0;
            }
            uVar1 = *(uint64_t *)(in_RCX + 0xb8);
            var_100h = (int64_t)(in_RCX + 0x14);
            var_108h._0_4_ = in_RCX[2];
            *(int64_t **)((int64_t)&arg_40h + iVar5) = &var_108h;
            var_e8h = (int64_t)(in_RCX + 0x96);
            var_f0h._0_4_ = in_RCX[0x94];
            *(int64_t **)((int64_t)&arg_48h + iVar5) = &var_f0h;
            var_d0h = (int64_t)(in_RCX + 0xa0);
            var_d8h._0_4_ = in_RCX[0x9e];
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar1;
            iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar2, 8);
            var_f8h._0_4_ = 0;
            var_e0h._0_4_ = 0;
            var_c8h._0_4_ = 0;
            *(uint64_t *)((int64_t)&arg_58h + iVar5) = (uVar1 - iVar7 >> 1) + iVar7 >> 0x1d;
            auVar3._8_8_ = 0;
            auVar3._0_8_ = *(uint64_t *)(in_RCX + 0xb6);
            iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar3, 8);
            *(uint64_t *)((int64_t)&arg_60h + iVar5) = (*(uint64_t *)(in_RCX + 0xb6) - iVar7 >> 1) + iVar7 >> 0x1d;
            iVar7 = *(int64_t *)(in_RCX + 0xae);
            *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4545;
                uVar4 = func_0x0001802362e0(iVar7, (int64_t)&var_10h + iVar5);
                *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar4;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xc6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4574;
                var_c0h._0_4_ = func_0x000180498cd0(iVar7);
                var_b0h._0_4_ = 0;
                var_b8h = iVar7;
            }
            if (*(int64_t *)(in_RCX + 200) != 0) {
                var_a8h._0_4_ = in_RCX[0xca];
                var_98h._0_4_ = 0;
                var_a0h = *(int64_t *)(in_RCX + 200);
            }
            iVar7 = *(int64_t *)(in_RCX + 0xa8);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d45f5;
                var_90h._0_4_ = func_0x000180498cd0(iVar7);
                var_80h._0_4_ = 0;
                var_88h = iVar7;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xaa);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d462e;
                var_78h._0_4_ = func_0x000180498cd0(iVar7);
                var_68h._0_4_ = 0;
                var_70h = iVar7;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xd6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4667;
                var_60h._0_4_ = func_0x000180498cd0(iVar7);
                var_50h._0_4_ = 0;
                var_58h = iVar7;
            }
            if (*(int64_t *)(in_RCX + 0xd0) != 0) {
                var_48h._0_4_ = in_RCX[0xd2];
                var_38h._0_4_ = 0;
                var_40h = *(int64_t *)(in_RCX + 0xd0);
            }
            if (*(int64_t *)(in_RCX + 0xd8) != 0) {
                var_30h._0_4_ = in_RCX[0xda];
                var_20h = var_20h & 0xffffffff00000000;
                var_28h = *(int64_t *)(in_RCX + 0xd8);
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4733;
            uVar4 = func_0x0001802642c0((int64_t)&arg_28h + iVar5, in_RDX, 0x1804b4420);
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d474c;
            func_0x000180224990(*(undefined8 *)((int64_t)&var_10h + iVar5), 0x1804b45e8, 0xdd);
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d43b6
// Address: 0x1801d43b6
// Size: 765 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_158h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h

undefined4
fcn.1801d4370(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint64_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    int32_t *piVar6;
    undefined8 in_RDX;
    int64_t iVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h;
    int64_t var_19h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b4h;
    int64_t var_1a8h;
    int64_t var_19ch;
    int64_t var_194h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_16ch;
    int64_t var_15ch;
    int64_t var_14ch;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = 0x1801d4386;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    if (in_RCX != (undefined4 *)0x0) {
        iVar7 = *(int64_t *)(in_RCX + 0xbe);
        piVar6 = in_RCX + 0xc0;
        if ((iVar7 != 0) || (*piVar6 != 0)) {
            *(undefined8 *)(&stack0x00000240 + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = 0;
            *(undefined4 *)((int64_t)&arg_28h + iVar5 + 4) = *in_RCX;
            *(undefined8 *)(&stack0x00000250 + iVar5) = unaff_R14;
            *(undefined4 *)((int64_t)&arg_28h + iVar5) = 1;
            if (iVar7 != 0) {
                piVar6 = (int32_t *)(iVar7 + 0x18);
            }
            var_19h._0_1_ = (undefined)*piVar6;
            var_18h = (undefined)((uint32_t)*piVar6 >> 8);
            var_130h = (int64_t)&var_18h;
            *(int64_t **)((int64_t)&arg_30h + iVar5) = &var_138h;
            var_138h._0_4_ = 2;
            var_128h._0_4_ = 0;
            if (in_RCX[0xbc] != 0) {
                var_8h._0_1_ = (undefined)in_RCX[0xbc];
                var_118h = (int64_t)&var_8h;
                *(int64_t **)((int64_t)&arg_38h + iVar5) = &var_120h;
                var_120h._0_4_ = 1;
                var_110h._0_4_ = 0;
            }
            uVar1 = *(uint64_t *)(in_RCX + 0xb8);
            var_100h = (int64_t)(in_RCX + 0x14);
            var_108h._0_4_ = in_RCX[2];
            *(int64_t **)((int64_t)&arg_40h + iVar5) = &var_108h;
            var_e8h = (int64_t)(in_RCX + 0x96);
            var_f0h._0_4_ = in_RCX[0x94];
            *(int64_t **)((int64_t)&arg_48h + iVar5) = &var_f0h;
            var_d0h = (int64_t)(in_RCX + 0xa0);
            var_d8h._0_4_ = in_RCX[0x9e];
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar1;
            iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar2, 8);
            var_f8h._0_4_ = 0;
            var_e0h._0_4_ = 0;
            var_c8h._0_4_ = 0;
            *(uint64_t *)((int64_t)&arg_58h + iVar5) = (uVar1 - iVar7 >> 1) + iVar7 >> 0x1d;
            auVar3._8_8_ = 0;
            auVar3._0_8_ = *(uint64_t *)(in_RCX + 0xb6);
            iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar3, 8);
            *(uint64_t *)((int64_t)&arg_60h + iVar5) = (*(uint64_t *)(in_RCX + 0xb6) - iVar7 >> 1) + iVar7 >> 0x1d;
            iVar7 = *(int64_t *)(in_RCX + 0xae);
            *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4545;
                uVar4 = func_0x0001802362e0(iVar7, (int64_t)&var_10h + iVar5);
                *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar4;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xc6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4574;
                var_c0h._0_4_ = func_0x000180498cd0(iVar7);
                var_b0h._0_4_ = 0;
                var_b8h = iVar7;
            }
            if (*(int64_t *)(in_RCX + 200) != 0) {
                var_a8h._0_4_ = in_RCX[0xca];
                var_98h._0_4_ = 0;
                var_a0h = *(int64_t *)(in_RCX + 200);
            }
            iVar7 = *(int64_t *)(in_RCX + 0xa8);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d45f5;
                var_90h._0_4_ = func_0x000180498cd0(iVar7);
                var_80h._0_4_ = 0;
                var_88h = iVar7;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xaa);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d462e;
                var_78h._0_4_ = func_0x000180498cd0(iVar7);
                var_68h._0_4_ = 0;
                var_70h = iVar7;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xd6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4667;
                var_60h._0_4_ = func_0x000180498cd0(iVar7);
                var_50h._0_4_ = 0;
                var_58h = iVar7;
            }
            if (*(int64_t *)(in_RCX + 0xd0) != 0) {
                var_48h._0_4_ = in_RCX[0xd2];
                var_38h._0_4_ = 0;
                var_40h = *(int64_t *)(in_RCX + 0xd0);
            }
            if (*(int64_t *)(in_RCX + 0xd8) != 0) {
                var_30h._0_4_ = in_RCX[0xda];
                var_20h = var_20h & 0xffffffff00000000;
                var_28h = *(int64_t *)(in_RCX + 0xd8);
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4733;
            uVar4 = func_0x0001802642c0((int64_t)&arg_28h + iVar5, in_RDX, 0x1804b4420);
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d474c;
            func_0x000180224990(*(undefined8 *)((int64_t)&var_10h + iVar5), 0x1804b45e8, 0xdd);
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d46b3
// Address: 0x1801d46b3
// Size: 174 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_158h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h

undefined4
fcn.1801d4370(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint64_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    int32_t *piVar6;
    undefined8 in_RDX;
    int64_t iVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h;
    int64_t var_19h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b4h;
    int64_t var_1a8h;
    int64_t var_19ch;
    int64_t var_194h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_16ch;
    int64_t var_15ch;
    int64_t var_14ch;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = 0x1801d4386;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    if (in_RCX != (undefined4 *)0x0) {
        iVar7 = *(int64_t *)(in_RCX + 0xbe);
        piVar6 = in_RCX + 0xc0;
        if ((iVar7 != 0) || (*piVar6 != 0)) {
            *(undefined8 *)(&stack0x00000240 + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = 0;
            *(undefined4 *)((int64_t)&arg_28h + iVar5 + 4) = *in_RCX;
            *(undefined8 *)(&stack0x00000250 + iVar5) = unaff_R14;
            *(undefined4 *)((int64_t)&arg_28h + iVar5) = 1;
            if (iVar7 != 0) {
                piVar6 = (int32_t *)(iVar7 + 0x18);
            }
            var_19h._0_1_ = (undefined)*piVar6;
            var_18h = (undefined)((uint32_t)*piVar6 >> 8);
            var_130h = (int64_t)&var_18h;
            *(int64_t **)((int64_t)&arg_30h + iVar5) = &var_138h;
            var_138h._0_4_ = 2;
            var_128h._0_4_ = 0;
            if (in_RCX[0xbc] != 0) {
                var_8h._0_1_ = (undefined)in_RCX[0xbc];
                var_118h = (int64_t)&var_8h;
                *(int64_t **)((int64_t)&arg_38h + iVar5) = &var_120h;
                var_120h._0_4_ = 1;
                var_110h._0_4_ = 0;
            }
            uVar1 = *(uint64_t *)(in_RCX + 0xb8);
            var_100h = (int64_t)(in_RCX + 0x14);
            var_108h._0_4_ = in_RCX[2];
            *(int64_t **)((int64_t)&arg_40h + iVar5) = &var_108h;
            var_e8h = (int64_t)(in_RCX + 0x96);
            var_f0h._0_4_ = in_RCX[0x94];
            *(int64_t **)((int64_t)&arg_48h + iVar5) = &var_f0h;
            var_d0h = (int64_t)(in_RCX + 0xa0);
            var_d8h._0_4_ = in_RCX[0x9e];
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar1;
            iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar2, 8);
            var_f8h._0_4_ = 0;
            var_e0h._0_4_ = 0;
            var_c8h._0_4_ = 0;
            *(uint64_t *)((int64_t)&arg_58h + iVar5) = (uVar1 - iVar7 >> 1) + iVar7 >> 0x1d;
            auVar3._8_8_ = 0;
            auVar3._0_8_ = *(uint64_t *)(in_RCX + 0xb6);
            iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar3, 8);
            *(uint64_t *)((int64_t)&arg_60h + iVar5) = (*(uint64_t *)(in_RCX + 0xb6) - iVar7 >> 1) + iVar7 >> 0x1d;
            iVar7 = *(int64_t *)(in_RCX + 0xae);
            *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4545;
                uVar4 = func_0x0001802362e0(iVar7, (int64_t)&var_10h + iVar5);
                *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar4;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xc6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4574;
                var_c0h._0_4_ = func_0x000180498cd0(iVar7);
                var_b0h._0_4_ = 0;
                var_b8h = iVar7;
            }
            if (*(int64_t *)(in_RCX + 200) != 0) {
                var_a8h._0_4_ = in_RCX[0xca];
                var_98h._0_4_ = 0;
                var_a0h = *(int64_t *)(in_RCX + 200);
            }
            iVar7 = *(int64_t *)(in_RCX + 0xa8);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d45f5;
                var_90h._0_4_ = func_0x000180498cd0(iVar7);
                var_80h._0_4_ = 0;
                var_88h = iVar7;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xaa);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d462e;
                var_78h._0_4_ = func_0x000180498cd0(iVar7);
                var_68h._0_4_ = 0;
                var_70h = iVar7;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xd6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4667;
                var_60h._0_4_ = func_0x000180498cd0(iVar7);
                var_50h._0_4_ = 0;
                var_58h = iVar7;
            }
            if (*(int64_t *)(in_RCX + 0xd0) != 0) {
                var_48h._0_4_ = in_RCX[0xd2];
                var_38h._0_4_ = 0;
                var_40h = *(int64_t *)(in_RCX + 0xd0);
            }
            if (*(int64_t *)(in_RCX + 0xd8) != 0) {
                var_30h._0_4_ = in_RCX[0xda];
                var_20h = var_20h & 0xffffffff00000000;
                var_28h = *(int64_t *)(in_RCX + 0xd8);
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4733;
            uVar4 = func_0x0001802642c0((int64_t)&arg_28h + iVar5, in_RDX, 0x1804b4420);
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d474c;
            func_0x000180224990(*(undefined8 *)((int64_t)&var_10h + iVar5), 0x1804b45e8, 0xdd);
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d4761
// Address: 0x1801d4761
// Size: 13 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_158h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h

undefined4
fcn.1801d4370(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint64_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    int32_t *piVar6;
    undefined8 in_RDX;
    int64_t iVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    undefined var_18h;
    int64_t var_19h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b4h;
    int64_t var_1a8h;
    int64_t var_19ch;
    int64_t var_194h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_16ch;
    int64_t var_15ch;
    int64_t var_14ch;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = 0x1801d4386;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    if (in_RCX != (undefined4 *)0x0) {
        iVar7 = *(int64_t *)(in_RCX + 0xbe);
        piVar6 = in_RCX + 0xc0;
        if ((iVar7 != 0) || (*piVar6 != 0)) {
            *(undefined8 *)(&stack0x00000240 + iVar5) = unaff_RDI;
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = 0;
            *(undefined4 *)((int64_t)&arg_28h + iVar5 + 4) = *in_RCX;
            *(undefined8 *)(&stack0x00000250 + iVar5) = unaff_R14;
            *(undefined4 *)((int64_t)&arg_28h + iVar5) = 1;
            if (iVar7 != 0) {
                piVar6 = (int32_t *)(iVar7 + 0x18);
            }
            var_19h._0_1_ = (undefined)*piVar6;
            var_18h = (undefined)((uint32_t)*piVar6 >> 8);
            var_130h = (int64_t)&var_18h;
            *(int64_t **)((int64_t)&arg_30h + iVar5) = &var_138h;
            var_138h._0_4_ = 2;
            var_128h._0_4_ = 0;
            if (in_RCX[0xbc] != 0) {
                var_8h._0_1_ = (undefined)in_RCX[0xbc];
                var_118h = (int64_t)&var_8h;
                *(int64_t **)((int64_t)&arg_38h + iVar5) = &var_120h;
                var_120h._0_4_ = 1;
                var_110h._0_4_ = 0;
            }
            uVar1 = *(uint64_t *)(in_RCX + 0xb8);
            var_100h = (int64_t)(in_RCX + 0x14);
            var_108h._0_4_ = in_RCX[2];
            *(int64_t **)((int64_t)&arg_40h + iVar5) = &var_108h;
            var_e8h = (int64_t)(in_RCX + 0x96);
            var_f0h._0_4_ = in_RCX[0x94];
            *(int64_t **)((int64_t)&arg_48h + iVar5) = &var_f0h;
            var_d0h = (int64_t)(in_RCX + 0xa0);
            var_d8h._0_4_ = in_RCX[0x9e];
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar1;
            iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar2, 8);
            var_f8h._0_4_ = 0;
            var_e0h._0_4_ = 0;
            var_c8h._0_4_ = 0;
            *(uint64_t *)((int64_t)&arg_58h + iVar5) = (uVar1 - iVar7 >> 1) + iVar7 >> 0x1d;
            auVar3._8_8_ = 0;
            auVar3._0_8_ = *(uint64_t *)(in_RCX + 0xb6);
            iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar3, 8);
            *(uint64_t *)((int64_t)&arg_60h + iVar5) = (*(uint64_t *)(in_RCX + 0xb6) - iVar7 >> 1) + iVar7 >> 0x1d;
            iVar7 = *(int64_t *)(in_RCX + 0xae);
            *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4545;
                uVar4 = func_0x0001802362e0(iVar7, (int64_t)&var_10h + iVar5);
                *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar4;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xc6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4574;
                var_c0h._0_4_ = func_0x000180498cd0(iVar7);
                var_b0h._0_4_ = 0;
                var_b8h = iVar7;
            }
            if (*(int64_t *)(in_RCX + 200) != 0) {
                var_a8h._0_4_ = in_RCX[0xca];
                var_98h._0_4_ = 0;
                var_a0h = *(int64_t *)(in_RCX + 200);
            }
            iVar7 = *(int64_t *)(in_RCX + 0xa8);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d45f5;
                var_90h._0_4_ = func_0x000180498cd0(iVar7);
                var_80h._0_4_ = 0;
                var_88h = iVar7;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xaa);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d462e;
                var_78h._0_4_ = func_0x000180498cd0(iVar7);
                var_68h._0_4_ = 0;
                var_70h = iVar7;
            }
            iVar7 = *(int64_t *)(in_RCX + 0xd6);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4667;
                var_60h._0_4_ = func_0x000180498cd0(iVar7);
                var_50h._0_4_ = 0;
                var_58h = iVar7;
            }
            if (*(int64_t *)(in_RCX + 0xd0) != 0) {
                var_48h._0_4_ = in_RCX[0xd2];
                var_38h._0_4_ = 0;
                var_40h = *(int64_t *)(in_RCX + 0xd0);
            }
            if (*(int64_t *)(in_RCX + 0xd8) != 0) {
                var_30h._0_4_ = in_RCX[0xda];
                var_20h = var_20h & 0xffffffff00000000;
                var_28h = *(int64_t *)(in_RCX + 0xd8);
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d4733;
            uVar4 = func_0x0001802642c0((int64_t)&arg_28h + iVar5, in_RDX, 0x1804b4420);
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1801d474c;
            func_0x000180224990(*(undefined8 *)((int64_t)&var_10h + iVar5), 0x1804b45e8, 0xdd);
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d4770
// Address: 0x1801d4770
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801d4770(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d4785;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d47a3;
    fcn.180224990(iVar2, 0x1804b45e8, 0xe7);
    *in_RCX = 0;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d47c6;
        iVar2 = fcn.180223270(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                             );
        *in_RCX = iVar2;
        return iVar2 != 0;
    }
    return true;
}

// ============================================================
// Function: FUN_1801d4800
// Address: 0x1801d4800
// Size: 143 bytes
// ============================================================
undefined8 fcn.1801d4800(int64_t param_1)
{
    int64_t iVar1;
    char *pcVar2;
    int32_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d480c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    pcVar2 = (char *)(param_1 + 0x1007);
    iVar3 = 8;
    do {
        *pcVar2 = *pcVar2 + '\x01';
        if (*pcVar2 != '\0') break;
        pcVar2 = pcVar2 + -1;
        iVar3 = iVar3 + -1;
    } while (0 < (int64_t)(pcVar2 + (-0xfff - param_1)));
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d484e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d4866;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d487c;
        func_0x0001801d5640(param_1, 0x50, 0x147, 0);
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d4890
// Address: 0x1801d4890
// Size: 124 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_104ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801d4890(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d489c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x1c) == 1) {
        if (*(uint64_t *)(in_RCX + 0x698) <= *(uint64_t *)(in_RCX + 0x690)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d48c8;
            uVar5 = fcn.1801d79c0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
            if ((int32_t)uVar5 == 0) {
                return uVar5;
            }
            *(undefined8 *)(in_RCX + 0x80) = 0;
        }
    } else if ((*(uint64_t *)(in_RCX + 0xfd0) <= *(uint64_t *)(in_RCX + 0xfd8)) && (*(int64_t *)(in_RCX + 0x6c0) == 0))
    {
        uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1801d78c0;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(in_RCX + 0x10);
        if (*(int64_t *)(in_RCX + 0x6a0) == 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar4) = uVar5;
            *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar4) = unaff_RBP;
            iVar2 = *(int32_t *)(in_RCX + 0x104c);
            iVar7 = 0x14;
            if (iVar1 == 0) {
                iVar7 = 0xc;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7904;
            iVar3 = fcn.1801d59d0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if ((iVar3 != 0) && (iVar7 = 0x414, iVar1 == 0)) {
                iVar7 = 0x40c;
            }
            uVar8 = iVar7 + (uint64_t)(iVar2 + 0x140);
            if (1 < *(uint64_t *)(in_RCX + 0x1140)) {
                uVar8 = uVar8 * *(uint64_t *)(in_RCX + 0x1140);
            }
            uVar9 = *(uint64_t *)(in_RCX + 0x6a8);
            if (*(uint64_t *)(in_RCX + 0x6a8) <= uVar8) {
                uVar9 = uVar8;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7953;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7962;
                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d797a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7990;
                fcn.1801d5640(*(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
                return 0;
            }
            *(int64_t *)(in_RCX + 0x6a0) = iVar7;
            *(uint64_t *)(in_RCX + 0x6b0) = uVar9;
        }
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d4910
// Address: 0x1801d4910
// Size: 160 bytes
// ============================================================
undefined8 fcn.1801d4910(int64_t param_1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d491c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int32_t *)(param_1 + 0x1c) == 1) {
        if ((*(uint64_t *)(param_1 + 0x698) <= *(uint64_t *)(param_1 + 0x690)) ||
           (((*(uint64_t *)(param_1 + 0x690) == 0 && (*(uint64_t *)(param_1 + 0x698) == 1)) &&
            (*(int64_t *)(param_1 + 0x80) == 0)))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d4959;
            func_0x0001801d7830(param_1, 0);
            *(undefined8 *)(param_1 + 0x698) = 0;
            return 1;
        }
    } else if ((((*(uint64_t *)(param_1 + 0xfd0) <= *(uint64_t *)(param_1 + 0xfd8)) &&
                (*(uint64_t *)(param_1 + 0xfd8) == *(uint64_t *)(param_1 + 0xfe0))) &&
               (*(int64_t *)(param_1 + 0x6c0) == 0)) && (*(int32_t *)(param_1 + 0xfe8) != 0xf1)) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
        *(undefined8 *)((int64_t)auStackX_10 + iVar3) = 0x1801d77cc;
        iVar4 = fcn.18045a350();
        if ((*(uint8_t *)(param_1 + 0x50) & 2) != 0) {
            uVar1 = *(undefined8 *)(param_1 + 0x6b0);
            uVar2 = *(undefined8 *)(param_1 + 0x6a0);
            *(undefined8 *)((int64_t)auStackX_10 + -iVar4 + iVar3) = 0x1801d77eb;
            func_0x000180244fc0(uVar2, uVar1);
        }
        uVar1 = *(undefined8 *)(param_1 + 0x6a0);
        *(undefined8 *)((int64_t)auStackX_10 + -iVar4 + iVar3) = 0x1801d7804;
        fcn.180224990(uVar1, 0x1804b46d8, 0x11c);
        *(undefined8 *)(param_1 + 0x6a0) = 0;
        *(undefined8 *)(param_1 + 0xff0) = 0;
        *(undefined8 *)(param_1 + 0xff8) = 0;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d49b0
// Address: 0x1801d49b0
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.1801d49b0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d49c0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = 1;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x6c0) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d49f8;
            uVar1 = fcn.18021b300(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d4a02;
        fcn.1801d6e10(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2));
    }
    return uVar1;
}

// ============================================================
// Function: FUN_1801d4a80
// Address: 0x1801d4a80
// Size: 31 bytes
// ============================================================
void fcn.1801d4a80(int64_t param_1)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x0001801d4a9c. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(*(int64_t *)(param_1 + 0x1148) + 0x40))();
    return;
}

// ============================================================
// Function: FUN_1801d4aa0
// Address: 0x1801d4aa0
// Size: 156 bytes
// ============================================================
int64_t fcn.1801d4aa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int64_t iVar11;
    undefined8 *puVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iVar14;
    undefined8 unaff_R15;
    int64_t iStack_10;
    
    iStack_10 = 0x1801d4aac;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((*(uint64_t *)(in_RCX + 0x690) < *(uint64_t *)(in_RCX + 0x698)) &&
       (*(int64_t *)(in_RCX + 0x80 + *(uint64_t *)(in_RCX + 0x690) * 0x30) != 0)) {
        *(undefined8 *)((int64_t)&iStack_10 + iVar6) = 0x1801d4ad9;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)(&stack0x00000020 + iVar6));
        *(undefined8 *)((int64_t)&iStack_10 + iVar6) = 0x1801d4af1;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)(&stack0x00000020 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&iStack_10 + iVar6) = 0x1801d4b07;
        fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar6));
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x48);
        *(undefined8 *)((int64_t)&iStack_10 + iVar6) = 0x1801d4b20;
        iVar4 = (*pcVar2)();
        if (iVar4 != 0) {
            *(undefined8 *)(in_RCX + 0x690) = 0;
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)(&stack0x00000018 + iVar6);
            *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RSI;
            *(undefined8 *)(&stack0x00000018 + iVar6) = unaff_RDI;
            *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_R14;
            *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_R15;
            *(undefined8 *)(&stack0x00000020 + iVar6 + -0x20) = 0x1801d4b5e;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar10 = 0;
            iVar13 = iVar10;
            if (*(uint64_t *)(in_RCX + 0x690) < *(uint64_t *)(in_RCX + 0x698)) {
                do {
                    while( true ) {
                        iVar11 = (*(int64_t *)(in_RCX + 0x690) + 2) * 0x30 + in_RCX;
                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4b9e;
                        (*(code *)0x69a006)(0);
                        if (*(int64_t *)(in_RCX + 0x40) == 0) {
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4cdb;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4cf3;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4d09;
                            fcn.1801d5640(*(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6));
                            iVar8 = 0xfffffffe;
                            goto code_r0x0001801d4d0e;
                        }
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x88);
                        if (pcVar2 != (code *)0x0) {
                            uVar1 = *(undefined4 *)(iVar11 + 0x2c);
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4bc4;
                            iVar8 = (*pcVar2)(in_RCX, uVar1);
                            if ((int32_t)iVar8 != 1) {
                                return iVar8;
                            }
                        }
                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4be1;
                        iVar4 = fcn.18021b2c0(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6));
                        iVar14 = (int64_t)iVar4;
                        iVar8 = iVar10;
                        if (-1 < iVar4) break;
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4c80;
                        iVar5 = fcn.18021b270(uVar3, 8);
                        if (iVar5 == 0) {
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4c8e;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4ca6;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4cac;
                            (*(code *)0x699ff6)();
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4cbf;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6));
                            iVar8 = 0xfffffffe;
                        }
code_r0x0001801d4cc4:
                        if (iVar4 < 1) {
code_r0x0001801d4d0e:
                            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                                return iVar8;
                            }
                            *(undefined8 *)(iVar11 + 0x20) = 0;
                            iVar13 = *(int64_t *)(in_RCX + 0x698);
                            iVar10 = *(int64_t *)(in_RCX + 0x690) + 1;
                            *(int64_t *)(in_RCX + 0x690) = iVar10;
                            if (iVar10 != iVar13) {
                                return iVar8;
                            }
                            if ((*(uint8_t *)(in_RCX + 0x58) & 0x10) == 0) {
                                return iVar8;
                            }
                            if (iVar13 != 0) {
                                puVar12 = (undefined8 *)((iVar13 + 1) * 0x30 + in_RCX);
                                do {
                                    if (*(int32_t *)(puVar12 + 5) == 0) {
                                        uVar3 = *puVar12;
                                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4d71;
                                        fcn.180224990(uVar3, 0x1804b46d8, 0x88);
                                    } else {
                                        *(undefined4 *)(puVar12 + 5) = 0;
                                    }
                                    *puVar12 = 0;
                                    puVar12 = puVar12 + -6;
                                    iVar13 = iVar13 + -1;
                                } while (iVar13 != 0);
                            }
                            *(undefined8 *)(in_RCX + 0x698) = 0;
                            return iVar8;
                        }
                        *(int64_t *)(iVar11 + 0x18) = *(int64_t *)(iVar11 + 0x18) + iVar13;
                        *(int64_t *)(iVar11 + 0x20) = *(int64_t *)(iVar11 + 0x20) - iVar13;
                    }
                    if (iVar4 == 0) {
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4bff;
                        iVar5 = fcn.18021b270(uVar3, 8);
                        if (iVar5 == 0) goto code_r0x0001801d4c06;
                    } else {
code_r0x0001801d4c06:
                        iVar8 = 1;
                    }
                    iVar13 = iVar14;
                    if (iVar14 != *(int64_t *)(iVar11 + 0x20)) goto code_r0x0001801d4cc4;
                    *(int64_t *)(iVar11 + 0x18) = *(int64_t *)(iVar11 + 0x18) + iVar14;
                    *(undefined8 *)(iVar11 + 0x20) = 0;
                    uVar9 = *(int64_t *)(in_RCX + 0x690) + 1;
                    *(uint64_t *)(in_RCX + 0x690) = uVar9;
                } while (uVar9 < *(uint64_t *)(in_RCX + 0x698));
                if ((uVar9 == *(uint64_t *)(in_RCX + 0x698)) && ((*(uint8_t *)(in_RCX + 0x58) & 0x10) != 0)) {
                    *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4c4d;
                    fcn.1801d7830(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
                    *(undefined8 *)(in_RCX + 0x698) = 0;
                }
            }
            return 1;
        }
    }
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801d4b40
// Address: 0x1801d4b40
// Size: 588 bytes
// ============================================================
int64_t fcn.1801d4aa0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int64_t iVar11;
    undefined8 *puVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t iVar14;
    undefined8 unaff_R15;
    int64_t iStack_10;
    
    iStack_10 = 0x1801d4aac;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((*(uint64_t *)(in_RCX + 0x690) < *(uint64_t *)(in_RCX + 0x698)) &&
       (*(int64_t *)(in_RCX + 0x80 + *(uint64_t *)(in_RCX + 0x690) * 0x30) != 0)) {
        *(undefined8 *)((int64_t)&iStack_10 + iVar6) = 0x1801d4ad9;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)(&stack0x00000020 + iVar6));
        *(undefined8 *)((int64_t)&iStack_10 + iVar6) = 0x1801d4af1;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar6), *(int64_t *)(&stack0x00000020 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&iStack_10 + iVar6) = 0x1801d4b07;
        fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar6));
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x48);
        *(undefined8 *)((int64_t)&iStack_10 + iVar6) = 0x1801d4b20;
        iVar4 = (*pcVar2)();
        if (iVar4 != 0) {
            *(undefined8 *)(in_RCX + 0x690) = 0;
            *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)(&stack0x00000018 + iVar6);
            *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RSI;
            *(undefined8 *)(&stack0x00000018 + iVar6) = unaff_RDI;
            *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_R14;
            *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_R15;
            *(undefined8 *)(&stack0x00000020 + iVar6 + -0x20) = 0x1801d4b5e;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            iVar10 = 0;
            iVar13 = iVar10;
            if (*(uint64_t *)(in_RCX + 0x690) < *(uint64_t *)(in_RCX + 0x698)) {
                do {
                    while( true ) {
                        iVar11 = (*(int64_t *)(in_RCX + 0x690) + 2) * 0x30 + in_RCX;
                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4b9e;
                        (*(code *)0x69a006)(0);
                        if (*(int64_t *)(in_RCX + 0x40) == 0) {
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4cdb;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4cf3;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4d09;
                            fcn.1801d5640(*(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6));
                            iVar8 = 0xfffffffe;
                            goto code_r0x0001801d4d0e;
                        }
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x88);
                        if (pcVar2 != (code *)0x0) {
                            uVar1 = *(undefined4 *)(iVar11 + 0x2c);
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4bc4;
                            iVar8 = (*pcVar2)(in_RCX, uVar1);
                            if ((int32_t)iVar8 != 1) {
                                return iVar8;
                            }
                        }
                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4be1;
                        iVar4 = fcn.18021b2c0(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6));
                        iVar14 = (int64_t)iVar4;
                        iVar8 = iVar10;
                        if (-1 < iVar4) break;
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4c80;
                        iVar5 = fcn.18021b270(uVar3, 8);
                        if (iVar5 == 0) {
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4c8e;
                            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4ca6;
                            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                          *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4cac;
                            (*(code *)0x699ff6)();
                            *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4cbf;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar6));
                            iVar8 = 0xfffffffe;
                        }
code_r0x0001801d4cc4:
                        if (iVar4 < 1) {
code_r0x0001801d4d0e:
                            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                                return iVar8;
                            }
                            *(undefined8 *)(iVar11 + 0x20) = 0;
                            iVar13 = *(int64_t *)(in_RCX + 0x698);
                            iVar10 = *(int64_t *)(in_RCX + 0x690) + 1;
                            *(int64_t *)(in_RCX + 0x690) = iVar10;
                            if (iVar10 != iVar13) {
                                return iVar8;
                            }
                            if ((*(uint8_t *)(in_RCX + 0x58) & 0x10) == 0) {
                                return iVar8;
                            }
                            if (iVar13 != 0) {
                                puVar12 = (undefined8 *)((iVar13 + 1) * 0x30 + in_RCX);
                                do {
                                    if (*(int32_t *)(puVar12 + 5) == 0) {
                                        uVar3 = *puVar12;
                                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4d71;
                                        fcn.180224990(uVar3, 0x1804b46d8, 0x88);
                                    } else {
                                        *(undefined4 *)(puVar12 + 5) = 0;
                                    }
                                    *puVar12 = 0;
                                    puVar12 = puVar12 + -6;
                                    iVar13 = iVar13 + -1;
                                } while (iVar13 != 0);
                            }
                            *(undefined8 *)(in_RCX + 0x698) = 0;
                            return iVar8;
                        }
                        *(int64_t *)(iVar11 + 0x18) = *(int64_t *)(iVar11 + 0x18) + iVar13;
                        *(int64_t *)(iVar11 + 0x20) = *(int64_t *)(iVar11 + 0x20) - iVar13;
                    }
                    if (iVar4 == 0) {
                        uVar3 = *(undefined8 *)(in_RCX + 0x40);
                        *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4bff;
                        iVar5 = fcn.18021b270(uVar3, 8);
                        if (iVar5 == 0) goto code_r0x0001801d4c06;
                    } else {
code_r0x0001801d4c06:
                        iVar8 = 1;
                    }
                    iVar13 = iVar14;
                    if (iVar14 != *(int64_t *)(iVar11 + 0x20)) goto code_r0x0001801d4cc4;
                    *(int64_t *)(iVar11 + 0x18) = *(int64_t *)(iVar11 + 0x18) + iVar14;
                    *(undefined8 *)(iVar11 + 0x20) = 0;
                    uVar9 = *(int64_t *)(in_RCX + 0x690) + 1;
                    *(uint64_t *)(in_RCX + 0x690) = uVar9;
                } while (uVar9 < *(uint64_t *)(in_RCX + 0x698));
                if ((uVar9 == *(uint64_t *)(in_RCX + 0x698)) && ((*(uint8_t *)(in_RCX + 0x58) & 0x10) != 0)) {
                    *(undefined8 *)(&stack0x00000020 + iVar7 + iVar6 + -0x20) = 0x1801d4c4d;
                    fcn.1801d7830(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
                    *(undefined8 *)(in_RCX + 0x698) = 0;
                }
            }
            return 1;
        }
    }
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801d4da0
// Address: 0x1801d4da0
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801d4da0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d4db0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d4dc6;
        uVar2 = fcn.18021b280(in_RDX);
        if ((int32_t)uVar2 == 0) {
            return uVar2;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d4dde;
    fcn.180219f80(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(int64_t *)(in_RCX + 0x40) = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_1801d4e00
// Address: 0x1801d4e00
// Size: 310 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801d4e00(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    int64_t *in_RDX;
    undefined4 *in_R8;
    undefined *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d4e1b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = *(uint64_t *)(in_RCX + 0xfd8);
    uVar4 = *(uint64_t *)(in_RCX + 0xfd0);
    if (uVar4 <= uVar6) {
        do {
            if (*(uint64_t *)(in_RCX + 0xfe0) != uVar4) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d4f01;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d4f19;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d4f2f;
                fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar3));
                return 0xfffffffe;
            }
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d4e5d;
            uVar5 = (*pcVar2)(in_RCX);
            if ((int32_t)uVar5 != 1) {
                return uVar5;
            }
            uVar6 = *(uint64_t *)(in_RCX + 0xfd8);
            uVar4 = *(uint64_t *)(in_RCX + 0xfd0);
        } while (uVar4 <= uVar6);
    }
    iVar1 = in_RCX + uVar6 * 0x48;
    *(uint64_t *)(in_RCX + 0xfd8) = uVar6 + 1;
    *in_RDX = (int64_t)(undefined4 *)(iVar1 + 0x6d0);
    *in_R8 = *(undefined4 *)(iVar1 + 0x6d0);
    *in_R9 = *(undefined *)(iVar1 + 0x6d4);
    **(int64_t **)((int64_t)&arg_48h + iVar3) = *(int64_t *)(iVar1 + 0x6f0) + *(int64_t *)(iVar1 + 0x6e8);
    **(undefined8 **)((int64_t)&arg_50h + iVar3) = *(undefined8 *)(iVar1 + 0x6d8);
    if (*(int32_t *)(in_RCX + 0x10) != 0) {
        **(undefined2 **)((int64_t)&arg_58h + iVar3) = *(undefined2 *)(iVar1 + 0x708);
        **(undefined8 **)((int64_t)&arg_60h + iVar3) = *(undefined8 *)(iVar1 + 0x70a);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d4f40
// Address: 0x1801d4f40
// Size: 292 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d4f40(int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d4f55;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar2 = in_RCX + *(uint64_t *)(in_RCX + 0xfe0) * 0x48 + 0x6d0;
    if ((*(uint64_t *)(in_RCX + 0xfe0) < *(uint64_t *)(in_RCX + 0xfd8)) && (in_RDX == iVar2)) {
        if (in_R8 <= *(uint64_t *)(iVar2 + 8)) {
            if ((*(uint8_t *)(in_RCX + 0x50) & 2) != 0) {
                iVar3 = *(int64_t *)(iVar2 + 0x20);
                iVar4 = *(int64_t *)(iVar2 + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d4fce;
                func_0x000180244fc0(iVar3 + iVar4, in_R8);
            }
            *(int64_t *)(iVar2 + 0x18) = *(int64_t *)(iVar2 + 0x18) + in_R8;
            piVar1 = (int64_t *)(iVar2 + 8);
            *piVar1 = *piVar1 - in_R8;
            if ((((*piVar1 == 0) &&
                 (*(int64_t *)(in_RCX + 0xfe0) = *(int64_t *)(in_RCX + 0xfe0) + 1,
                 *(int64_t *)(in_RCX + 0xfd8) == *(int64_t *)(in_RCX + 0xfe0))) &&
                ((*(uint8_t *)(in_RCX + 0x58) & 0x10) != 0)) && (*(int64_t *)(in_RCX + 0x6c0) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d5007;
                func_0x0001801d77c0(in_RCX);
            }
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d4f95;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d4fad;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d5021;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d5039;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d504f;
    fcn.1801d5640(*(int64_t *)(&stack0x00000040 + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801d5070
// Address: 0x1801d5070
// Size: 31 bytes
// ============================================================
void fcn.1801d5070(int64_t param_1)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x0001801d508c. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(*(int64_t *)(param_1 + 0x1148) + 0x18))();
    return;
}

// ============================================================
// Function: FUN_1801d5130
// Address: 0x1801d5130
// Size: 646 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801d5130(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d5140;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5158;
    iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5169;
        iVar1 = fcn.18022a900(iVar3, in_RCX + 0x50);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5172;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d518a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d519c;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d51b8;
    iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d51c9;
        iVar1 = fcn.18022a630(*(int64_t *)(&stack0x00000038 + iVar2));
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d51d2;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d51ea;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d51fc;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    }
    if (*(int32_t *)(in_RCX + 0x1c) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d521e;
        iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5236;
            iVar1 = fcn.18022a5d0(iVar3, in_RCX + 0x6a8);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5243;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d525b;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d526d;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5286;
        iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d529a;
            iVar1 = fcn.18022a5d0(iVar3, in_RCX + 0x1060);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d52a3;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d52bb;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d52cd;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d52e9;
        iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d52fd;
            iVar1 = fcn.18022a5d0(iVar3, in_RCX + 0x1068);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5306;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d531e;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5330;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0;
            }
        }
    }
    if (*(int32_t *)(in_RCX + 0x20) == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5352;
        iVar3 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5366;
            iVar1 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d536f;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5387;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5399;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d53c0
// Address: 0x1801d53c0
// Size: 41 bytes
// ============================================================
undefined8 fcn.1801d53c0(int64_t param_1)
{
    fcn.18045a350();
    if (*(undefined8 **)(param_1 + 0x1040) == (undefined8 *)0x0) {
        return 0;
    }
    return **(undefined8 **)(param_1 + 0x1040);
}

// ============================================================
// Function: FUN_1801d5400
// Address: 0x1801d5400
// Size: 561 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801d5400(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_e0h, int64_t arg_e8h,
                      int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                      int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_130h, int64_t arg_140h,
                      int64_t arg_148h, int64_t arg_150h, int64_t arg_168h, int64_t arg_170h, int64_t arg_178h,
                      int64_t arg_180h, int64_t arg_190h)
{
    undefined4 uVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    code *pcVar10;
    uint32_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    undefined8 uVar14;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801d5424;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    piVar2 = *(int64_t **)((int64_t)&arg_190h + iVar12);
    uVar3 = *(undefined8 *)((int64_t)&arg_130h + iVar12);
    uVar4 = *(undefined8 *)((int64_t)&arg_128h + iVar12);
    uVar5 = *(undefined8 *)((int64_t)&arg_118h + iVar12);
    uVar6 = *(undefined8 *)((int64_t)&arg_110h + iVar12);
    uVar1 = *(undefined4 *)((int64_t)&arg_c0h + iVar12);
    *(int64_t **)((int64_t)&arg_70h + iVar12) = piVar2;
    *(undefined8 *)((int64_t)&arg_68h + iVar12) = *(undefined8 *)((int64_t)&arg_180h + iVar12);
    *(undefined8 *)((int64_t)&arg_60h + iVar12) = *(undefined8 *)((int64_t)&arg_178h + iVar12);
    *(undefined8 *)((int64_t)&arg_58h + iVar12) = *(undefined8 *)((int64_t)&arg_170h + iVar12);
    *(undefined8 *)((int64_t)&arg_50h + iVar12) = *(undefined8 *)((int64_t)&arg_168h + iVar12);
    *(undefined8 *)((int64_t)&arg_48h + iVar12) = *(undefined8 *)((int64_t)&arg_150h + iVar12);
    *(undefined8 *)((int64_t)&arg_40h + iVar12) = *(undefined8 *)((int64_t)&arg_148h + iVar12);
    *(undefined8 *)((int64_t)&arg_38h + iVar12) = *(undefined8 *)((int64_t)&arg_140h + iVar12);
    *(undefined8 *)((int64_t)&arg_30h + iVar12) = uVar3;
    *(undefined8 *)((int64_t)&arg_28h + iVar12) = uVar4;
    *(undefined8 *)((int64_t)&var_20h + iVar12) = uVar5;
    *(undefined8 *)((int64_t)&var_18h + iVar12) = uVar6;
    *(undefined4 *)((int64_t)&var_10h + iVar12) = uVar1;
    *(undefined4 *)((int64_t)&var_8h + iVar12) = *(undefined4 *)((int64_t)&arg_b8h + iVar12);
    *(undefined8 *)((int64_t)&uStack_20 + iVar12) = 0x1801d54e9;
    uVar13 = func_0x0001801d6f60();
    if ((int32_t)uVar13 != 1) {
        return uVar13;
    }
    if (in_R8D < 0x304) {
        if (in_R8D != 0x303) {
            if (in_R8D == 0x300) {
                uVar14 = 0x1804b8130;
                goto code_r0x0001801d5577;
            }
            if ((in_R8D != 0x301) && (in_R8D != 0x302)) goto code_r0x0001801d552e;
        }
        uVar14 = 0x1804b8270;
    } else if (in_R8D == 0x304) {
        uVar14 = 0x1804b8410;
    } else {
        if (in_R8D != 0x10000) {
code_r0x0001801d552e:
            *(undefined8 *)((int64_t)&uStack_20 + iVar12) = 0x1801d5533;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar12), *(int64_t *)((int64_t)&var_10h + iVar12));
            *(undefined8 *)((int64_t)&uStack_20 + iVar12) = 0x1801d554b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar12), *(int64_t *)((int64_t)&var_10h + iVar12), 
                          *(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12), 
                          *(int64_t *)((int64_t)&arg_38h + iVar12));
            *(undefined8 *)((int64_t)&uStack_20 + iVar12) = 0x1801d555d;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar12));
            uVar13 = 0xfffffffe;
            goto code_r0x0001801d55fe;
        }
        uVar14 = 0x1804b8550;
    }
code_r0x0001801d5577:
    iVar7 = *piVar2;
    uVar8 = *(undefined8 *)((int64_t)&arg_e8h + iVar12);
    uVar9 = *(undefined8 *)((int64_t)&arg_e0h + iVar12);
    *(undefined8 *)((int64_t)&arg_48h + iVar12) = uVar3;
    *(undefined8 *)(iVar7 + 0x1148) = uVar14;
    iVar7 = *piVar2;
    *(undefined8 *)((int64_t)&arg_40h + iVar12) = uVar4;
    pcVar10 = **(code ***)(iVar7 + 0x1148);
    *(undefined4 *)((int64_t)&arg_38h + iVar12) = *(undefined4 *)((int64_t)&arg_120h + iVar12);
    *(undefined8 *)((int64_t)&arg_30h + iVar12) = uVar5;
    *(undefined8 *)((int64_t)&arg_28h + iVar12) = uVar6;
    *(undefined8 *)((int64_t)&var_20h + iVar12) = *(undefined8 *)((int64_t)&arg_108h + iVar12);
    *(undefined8 *)((int64_t)&var_18h + iVar12) = *(undefined8 *)((int64_t)&arg_100h + iVar12);
    *(undefined8 *)((int64_t)&var_10h + iVar12) = *(undefined8 *)((int64_t)&arg_f8h + iVar12);
    *(undefined8 *)((int64_t)&var_8h + iVar12) = *(undefined8 *)((int64_t)&arg_f0h + iVar12);
    *(undefined8 *)((int64_t)&uStack_20 + iVar12) = 0x1801d55f7;
    uVar11 = (*pcVar10)(iVar7, uVar1, uVar9, uVar8);
    uVar13 = (uint64_t)uVar11;
    if (uVar11 == 1) {
        return uVar13;
    }
code_r0x0001801d55fe:
    *(undefined8 *)((int64_t)&uStack_20 + iVar12) = 0x1801d5606;
    fcn.1801d6e10(*(int64_t *)((int64_t)&var_8h + iVar12), *(int64_t *)((int64_t)&var_10h + iVar12), 
                  *(int64_t *)((int64_t)&var_18h + iVar12));
    *piVar2 = 0;
    return uVar13;
}

// ============================================================
// Function: FUN_1801d5640
// Address: 0x1801d5640
// Size: 64 bytes
// ============================================================
void fcn.1801d5640(int64_t arg4, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t in_RCX;
    undefined4 in_EDX;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801d5651;
    var_20h = arg4;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar1) = 0x1801d5673;
    fcn.180229700(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1));
    *(undefined4 *)(in_RCX + 0x1008) = in_EDX;
    return;
}

// ============================================================
// Function: FUN_1801d5680
// Address: 0x1801d5680
// Size: 347 bytes
// ============================================================
void fcn.1801d5680(int64_t arg_38h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_70h, int64_t arg_80h,
                  int64_t arg_88h, int64_t arg_98h, int64_t arg_a8h, int64_t arg_b8h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x1801d568e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_b8h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6);
    *(undefined8 *)((int64_t)&var_8h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d56bd;
    uVar4 = func_0x00018020ef80(in_R8);
    if (((uVar4 >> 0x15 & 1) == 0) && (*(int32_t *)(in_RCX + 0x10b0) == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d56d4;
        iVar5 = func_0x00018020f800(in_R9);
        if (0 < iVar5) {
            *(int64_t *)((int64_t)&var_8h + iVar6) = (int64_t)iVar5;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d56f4;
    puVar7 = (undefined4 *)func_0x000180229bc0((int64_t)aiStackX_18 + iVar6 + -8, 0x1804b46f8, in_RCX + 0x14);
    uVar1 = puVar7[1];
    uVar2 = puVar7[2];
    uVar3 = puVar7[3];
    *(undefined4 *)((int64_t)&arg_38h + iVar6) = *puVar7;
    *(undefined4 *)((int64_t)&arg_38h + iVar6 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000040 + iVar6) = uVar2;
    *(undefined4 *)(&stack0x00000044 + iVar6) = uVar3;
    uVar1 = puVar7[5];
    uVar2 = puVar7[6];
    uVar3 = puVar7[7];
    *(undefined4 *)((int64_t)&arg_48h + iVar6) = puVar7[4];
    *(undefined4 *)((int64_t)&arg_48h + iVar6 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000050 + iVar6) = uVar2;
    *(undefined4 *)(&stack0x00000054 + iVar6) = uVar3;
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = *(undefined8 *)(puVar7 + 8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d5726;
    puVar7 = (undefined4 *)func_0x000180229cc0((int64_t)aiStackX_18 + iVar6 + -8, 0x1804b4708, (int64_t)&var_8h + iVar6)
    ;
    uVar1 = puVar7[1];
    uVar2 = puVar7[2];
    uVar3 = puVar7[3];
    *(undefined4 *)((int64_t)&arg_60h + iVar6) = *puVar7;
    *(undefined4 *)((int64_t)&arg_60h + iVar6 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000068 + iVar6) = uVar2;
    *(undefined4 *)(&stack0x0000006c + iVar6) = uVar3;
    uVar1 = puVar7[5];
    uVar2 = puVar7[6];
    uVar3 = puVar7[7];
    *(undefined4 *)((int64_t)&arg_70h + iVar6) = puVar7[4];
    *(undefined4 *)((int64_t)&arg_70h + iVar6 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000078 + iVar6) = uVar2;
    *(undefined4 *)(&stack0x0000007c + iVar6) = uVar3;
    *(undefined8 *)((int64_t)&arg_80h + iVar6) = *(undefined8 *)(puVar7 + 8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d5752;
    puVar7 = (undefined4 *)func_0x000180229ba0((int64_t)aiStackX_18 + iVar6 + -8);
    uVar1 = puVar7[1];
    uVar2 = puVar7[2];
    uVar3 = puVar7[3];
    *(undefined4 *)((int64_t)&arg_88h + iVar6) = *puVar7;
    *(undefined4 *)((int64_t)&arg_88h + iVar6 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000090 + iVar6) = uVar2;
    *(undefined4 *)(&stack0x00000094 + iVar6) = uVar3;
    uVar1 = puVar7[5];
    uVar2 = puVar7[6];
    uVar3 = puVar7[7];
    *(undefined4 *)((int64_t)&arg_98h + iVar6) = puVar7[4];
    *(undefined4 *)((int64_t)&arg_98h + iVar6 + 4) = uVar1;
    *(undefined4 *)(&stack0x000000a0 + iVar6) = uVar2;
    *(undefined4 *)(&stack0x000000a4 + iVar6) = uVar3;
    *(undefined8 *)((int64_t)&arg_a8h + iVar6) = *(undefined8 *)(puVar7 + 8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d5784;
    iVar5 = func_0x000180211920(in_RDX, (int64_t)&arg_38h + iVar6);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d578d;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d57a5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d57b7;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d57d0;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_b8h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801d57e0
// Address: 0x1801d57e0
// Size: 52 bytes
// ============================================================
void fcn.1801d57e0(undefined8 *param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d57ec;
    iVar2 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801d5807;
    fcn.180224990(uVar1, 0x1804b46d8, 0x1c);
    *param_1 = 0;
    return;
}

// ============================================================
// Function: FUN_1801d5830
// Address: 0x1801d5830
// Size: 83 bytes
// ============================================================
undefined8 fcn.1801d5830(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    bool bVar4;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801d583a;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x1801d5842;
    uVar3 = func_0x00018020e940();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x1801d584a;
    iVar1 = func_0x000180203a00(uVar3);
    if (iVar1 < 0x2a2) {
        if (iVar1 - 0x2a0U < 2) {
            return 1;
        }
        if (iVar1 == 4) {
            return 1;
        }
        bVar4 = iVar1 == 0x40;
    } else {
        if (iVar1 == 0x2a2) {
            return 1;
        }
        bVar4 = iVar1 == 0x2a3;
    }
    if (bVar4) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d5890
// Address: 0x1801d5890
// Size: 261 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801d5890(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    undefined4 uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d58a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *(int32_t *)(in_RDX + 4);
    if ((iVar1 != 0x17) && (1 < iVar1 - 0x15U)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d58be;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d58d6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d58ec;
        fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_40h + iVar5));
        return 0;
    }
    pcVar3 = *(code **)(in_RCX + 0x1128);
    if (pcVar3 != (code *)0x0) {
        uVar4 = *(undefined8 *)(in_RCX + 0x1118);
        uVar2 = *(undefined4 *)(in_RCX + 0x14);
        *(char *)((int64_t)&arg_40h + iVar5) = (char)iVar1;
        *(undefined8 *)((int64_t)&var_20h + iVar5) = uVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar5) = 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d5931;
        (*pcVar3)(0, uVar2, 0x101);
    }
    if (((*(int32_t *)(in_RDX + 4) == 0x16) || (*(int32_t *)(in_RDX + 4) == 0x15)) && (*(int64_t *)(in_RDX + 8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d594a;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d5962;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d5978;
        fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_40h + iVar5));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d59a0
// Address: 0x1801d59a0
// Size: 41 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_104ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

bool fcn.1801d59a0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801d59aa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801d59bb;
    iVar1 = fcn.1801d79c0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar2));
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_1801d59d0
// Address: 0x1801d59d0
// Size: 95 bytes
// ============================================================
undefined8 fcn.1801d59d0(int64_t arg_30h)
{
    code *pcVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801d59da;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((*(uint32_t *)(in_RCX + 0x50) >> 0x11 & 1) != 0) {
        return 0;
    }
    pcVar1 = *(code **)(in_RCX + 0x1130);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    if (pcVar1 != (code *)0x0) {
        uVar2 = *(undefined8 *)(in_RCX + 0x1118);
        *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1801d5a1a;
        iVar3 = (*pcVar1)(uVar2, 0xf, 0, 0);
        if (iVar3 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d5a30
// Address: 0x1801d5a30
// Size: 391 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801d5a30(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d5a45;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0x1040) != 0) {
        if (0x4400 < *(uint64_t *)(in_RDX + 8)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5a6b;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5a83;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5a99;
            fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_40h + iVar2));
            return 0;
        }
        if (*(int64_t *)(in_RDX + 0x30) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5acb;
            iVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2));
            *(int64_t *)(in_RDX + 0x30) = iVar3;
            if (iVar3 == 0) goto code_r0x0001801d5b5d;
        }
        *(undefined4 *)((int64_t)&iStackX_20 + iVar2 + -8) = *(undefined4 *)(in_RDX + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5af8;
        iVar1 = fcn.180247820(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
        if (iVar1 < 0) {
code_r0x0001801d5b5d:
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5b62;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5b7a;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5b90;
            fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_40h + iVar2));
            return 0;
        }
        *(int64_t *)(in_RDX + 8) = (int64_t)iVar1;
        *(undefined8 *)(in_RDX + 0x20) = *(undefined8 *)(in_RDX + 0x30);
    }
    if (0x4000 < *(uint64_t *)(in_RDX + 8)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5b1d;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5b35;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5b4b;
        fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_40h + iVar2));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d5bc0
// Address: 0x1801d5bc0
// Size: 815 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int32_t fcn.1801d5bc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t *puVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t in_R8;
    int32_t in_R9D;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801d5be2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RDX == 0) {
        return -1;
    }
    iVar9 = *(int64_t *)(in_RCX + 0x6a0);
    uVar10 = *(uint64_t *)(in_RCX + 0x6c0);
    iVar5 = 0;
    iVar8 = 7 - (uint64_t)((int32_t)iVar9 - 4U & 7);
    if (in_R9D == 0) {
        if (uVar10 == 0) {
            *(int64_t *)(in_RCX + 0x6b8) = iVar8;
        }
        *(undefined8 *)(in_RCX + 0xff8) = 0;
        *(int64_t *)(in_RCX + 0xff0) = *(int64_t *)(in_RCX + 0x6b8) + iVar9;
    }
    iVar1 = *(int64_t *)(in_RCX + 0xff0);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5c54;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5c6c;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5c82;
        fcn.1801d5640(0, *(int64_t *)((int64_t)&var_20h + iVar6));
        return -2;
    }
    iVar2 = *(int64_t *)(in_RCX + 0xff8);
    iVar9 = iVar9 + iVar8;
    *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar9;
    if ((iVar1 != iVar9) && (*(int32_t *)((int64_t)&arg_48h + iVar6) == 1)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5cb1;
        fcn.180498030(iVar9, iVar1, uVar10 + iVar2);
        *(undefined8 *)(in_RCX + 0xff0) = *(undefined8 *)((int64_t)&arg_30h + iVar6);
        *(int64_t *)(in_RCX + 0x6b8) = iVar8 + iVar2;
    }
    if (*(int32_t *)(in_RCX + 0x10) != 0) {
        if (uVar10 == 0) {
            if (in_R9D != 0) {
                return -1;
            }
        } else {
            uVar7 = uVar10;
            if (uVar10 < in_RDX) goto code_r0x0001801d5d20;
        }
    }
    uVar7 = in_RDX;
    if (uVar10 < in_RDX) {
        uVar7 = *(int64_t *)(in_RCX + 0x6b0) - *(int64_t *)(in_RCX + 0x6b8);
        if (uVar7 < in_RDX) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5d5d;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5d75;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6));
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5d8b;
            fcn.1801d5640(0, *(int64_t *)((int64_t)&var_20h + iVar6));
            return -2;
        }
        uVar11 = in_RDX;
        if ((((*(int32_t *)(in_RCX + 0x100c) != 0) || (*(int32_t *)(in_RCX + 0x10) != 0)) && (in_RDX <= in_R8)) &&
           (uVar11 = in_R8, uVar7 < in_R8)) {
            uVar11 = uVar7;
        }
        do {
            iVar9 = *(int64_t *)(in_RCX + 0x38);
            if (iVar9 == 0) {
                iVar9 = *(int64_t *)(in_RCX + 0x40);
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5ddd;
                (*(code *)0x69a006)(0);
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5e8f;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                 );
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5ea7;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)((int64_t)&arg_28h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5ebd;
                    fcn.1801d5640(0, *(int64_t *)((int64_t)&var_20h + iVar6));
                    iVar5 = -2;
                    goto code_r0x0001801d5ec3;
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5dd1;
                (*(code *)0x69a006)();
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5dff;
            iVar4 = func_0x00018021ac80(iVar9, *(int64_t *)((int64_t)&arg_30h + iVar6) + iVar2 + uVar10, 
                                        (int32_t)uVar11 - (int32_t)uVar10);
            if (iVar4 < 1) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5e4c;
                iVar4 = fcn.18021b270(iVar9, 8);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5e80;
                    iVar5 = func_0x000180219d10(iVar9, 2, 0, 0);
                    iVar5 = -2 - (uint32_t)(iVar5 != 0);
code_r0x0001801d5ec3:
                    *(uint64_t *)(in_RCX + 0x6c0) = uVar10;
                    if ((*(uint8_t *)(in_RCX + 0x58) & 0x10) == 0) {
                        return iVar5;
                    }
                    if (*(int32_t *)(in_RCX + 0x10) == 0) {
                        if (uVar10 + iVar2 == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5ee7;
                            func_0x0001801d77c0(in_RCX);
                            return iVar5;
                        }
                        return iVar5;
                    }
                    return iVar5;
                }
                if (*(int64_t *)(in_RCX + 0x38) == 0) goto code_r0x0001801d5ec3;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d5e5e;
                fcn.180219f80(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                *(undefined8 *)(in_RCX + 0x38) = 0;
            } else {
                uVar10 = uVar10 + (int64_t)iVar4;
                if (*(int32_t *)(in_RCX + 0x10) != 0) {
                    if (uVar10 < in_RDX) {
                        in_RDX = uVar10;
                    }
                    break;
                }
            }
        } while (uVar10 < in_RDX);
        puVar3 = *(uint64_t **)((int64_t)&arg_50h + iVar6);
        *(int64_t *)(in_RCX + 0x6b8) = *(int64_t *)(in_RCX + 0x6b8) + in_RDX;
        *(uint64_t *)(in_RCX + 0x6c0) = uVar10 - in_RDX;
        *(int64_t *)(in_RCX + 0xff8) = *(int64_t *)(in_RCX + 0xff8) + in_RDX;
        *puVar3 = in_RDX;
        return 1;
    }
code_r0x0001801d5d20:
    *(int64_t *)(in_RCX + 0xff8) = *(int64_t *)(in_RCX + 0xff8) + uVar7;
    puVar3 = *(uint64_t **)((int64_t)&arg_50h + iVar6);
    *(int64_t *)(in_RCX + 0x6b8) = *(int64_t *)(in_RCX + 0x6b8) + uVar7;
    *(uint64_t *)(in_RCX + 0x6c0) = uVar10 - uVar7;
    *puVar3 = uVar7;
    return 1;
}

// ============================================================
// Function: FUN_1801d5f00
// Address: 0x1801d5f00
// Size: 181 bytes
// ============================================================
undefined8 fcn.1801d5f00(int64_t param_1, int32_t *param_2)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d5f0c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*param_2 != *(int32_t *)(param_1 + 0x14)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d5f1e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d5f36;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d5f4c;
        fcn.1801d5640(0, *(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    uVar2 = 0x4140;
    if (*(int64_t *)(param_1 + 0x1040) != 0) {
        uVar2 = 0x4540;
    }
    if (uVar2 < *(uint64_t *)(param_2 + 2)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d5f74;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d5f8c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d5fa2;
        fcn.1801d5640(0, *(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d5fc0
// Address: 0x1801d5fc0
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801d5fc0(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d5fd0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RDX + 0x30) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d5ff9;
        iVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2));
        *(int64_t *)(in_RDX + 0x30) = iVar3;
        if (iVar3 == 0) {
            return 0;
        }
    }
    *(undefined4 *)((int64_t)&iStackX_20 + iVar2 + -8) = *(undefined4 *)(in_RDX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801d6022;
    iVar1 = fcn.180247820(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
    if (iVar1 < 0) {
        return 0;
    }
    *(int64_t *)(in_RDX + 8) = (int64_t)iVar1;
    *(undefined8 *)(in_RDX + 0x20) = *(undefined8 *)(in_RDX + 0x30);
    return 1;
}

// ============================================================
// Function: FUN_1801d6060
// Address: 0x1801d6060
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801d6060(int64_t arg_28h, int64_t arg_48h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    int64_t in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d6070;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(int64_t *)(in_RCX + 0x1140) != 0) && (*(int64_t *)(in_RCX + 0x1020) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d6094;
        uVar4 = func_0x00018020e940();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d609c;
        uVar2 = func_0x00018020ef80(uVar4);
        if ((((uVar2 >> 0x17 & 1) != 0) &&
            ((((iVar1 = *(int32_t *)(in_RCX + 0x14), iVar1 == 0x302 || (iVar1 == 0x303)) || (iVar1 == 0x100)) ||
             ((iVar1 == 0xfeff || (iVar1 == 0xfefd)))))) && (in_R8 != 0)) {
            uVar5 = (in_R8 - 1U) / **(uint64_t **)((int64_t)&arg_48h + iVar3) + 1;
            if (*(uint64_t *)(in_RCX + 0x1140) <= uVar5) {
                uVar5 = *(uint64_t *)(in_RCX + 0x1140);
            }
            return uVar5;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d6110
// Address: 0x1801d6110
// Size: 2960 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1801d6110(int64_t arg_28h, int64_t arg_68h, int64_t arg_78h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    code *pcVar4;
    uint8_t *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    int32_t iVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    undefined8 uVar17;
    char *pcVar18;
    int64_t in_RCX;
    uint64_t uVar19;
    uint64_t *puVar20;
    int64_t *piVar21;
    uint64_t *puVar22;
    uint64_t uVar23;
    uint64_t uVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801d6132;
    iVar15 = fcn.18045a350();
    iVar15 = -iVar15;
    *(uint64_t *)((int64_t)&arg_68h + iVar15) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_28h + iVar15;
    uVar23 = 0;
    uVar24 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar15) = 0;
    if (*(int64_t *)(in_RCX + 0x6a0) != 0) {
code_r0x0001801d6178:
        iVar16 = *(int64_t *)(in_RCX + 0x1140);
        if (iVar16 == 0) {
            iVar16 = 1;
        }
        *(int64_t *)((int64_t)&var_18h + iVar15) = iVar16;
        puVar22 = (uint64_t *)(in_RCX + 0x6d8);
        do {
            puVar20 = puVar22;
            if ((*(int32_t *)(in_RCX + 0xfe8) != 0xf1) || (*(uint64_t *)(in_RCX + 0xff8) < 5)) {
                uVar17 = *(undefined8 *)(in_RCX + 0x6b0);
                pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x20);
                *(int64_t *)(&stack0x00000000 + iVar15) = (int64_t)&var_10h + iVar15;
                *(uint32_t *)(&stack0xfffffffffffffff8 + iVar15) = (uint32_t)(uVar24 == 0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d61f5;
                iVar11 = (*pcVar4)(in_RCX, 5, uVar17, 0);
                if (iVar11 < 1) goto code_r0x0001801d6c6f;
                uVar19 = *(uint64_t *)(in_RCX + 0xff8);
                puVar5 = *(uint8_t **)(in_RCX + 0xff0);
                *(undefined4 *)(in_RCX + 0xfe8) = 0xf1;
                if (0x7fffffffffffffff < uVar19) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6c3e;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                  *(int64_t *)(&stack0x00000000 + iVar15));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6c56;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                  *(int64_t *)(&stack0x00000000 + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                                  *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15));
                    goto code_r0x0001801d6c61;
                }
                if (uVar19 < 2) {
code_r0x0001801d6c2d:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6c32;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                  *(int64_t *)(&stack0x00000000 + iVar15));
                } else {
                    uVar1 = *puVar5;
                    if (uVar19 == 2) goto code_r0x0001801d6c2d;
                    if ((((*(int32_t *)(in_RCX + 0x18) == 1) && (*(int32_t *)(in_RCX + 0x10d4) != 0)) &&
                        ((uVar1 & 0x80) != 0)) && (puVar5[2] == 1)) {
                        uVar19 = (uint64_t)(CONCAT11(uVar1, puVar5[1]) & 0x7fff);
                        *(undefined4 *)((int64_t)puVar20 + -4) = 0x16;
                        *puVar20 = uVar19;
                        *(undefined4 *)(puVar20 + -1) = 2;
                        if (uVar19 <= *(int64_t *)(in_RCX + 0x6b0) - 2U) {
code_r0x0001801d634f:
                            pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x30);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6364;
                            iVar11 = (*pcVar4)(in_RCX, puVar20 + -1);
                            if (iVar11 != 0) goto code_r0x0001801d6372;
                            goto code_r0x0001801d6c6f;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d629b;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                      *(int64_t *)(&stack0x00000000 + iVar15));
code_r0x0001801d62a0:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d62b3;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                      *(int64_t *)(&stack0x00000000 + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                                      *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15)
                                     );
                        goto code_r0x0001801d6c61;
                    }
                    if ((1 < uVar19 - 1) && (uVar12 = (uint32_t)CONCAT11(puVar5[1], puVar5[2]), 1 < uVar19 - 3)) {
                        uVar2 = puVar5[3];
                        uVar3 = puVar5[4];
                        *(uint32_t *)((int64_t)puVar20 + -4) = (uint32_t)uVar1;
                        *puVar20 = (uint64_t)CONCAT11(uVar2, uVar3);
                        *(uint32_t *)(puVar20 + -1) = uVar12;
                        if (uVar12 != 2) {
                            pcVar4 = *(code **)(in_RCX + 0x1128);
                            if (pcVar4 != (code *)0x0) {
                                *(undefined8 *)(&stack0x00000000 + iVar15) = *(undefined8 *)(in_RCX + 0x1118);
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar15) = 5;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d633b;
                                (*pcVar4)(0, uVar12, 0x100);
                            }
                            if (*puVar20 <= *(int64_t *)(in_RCX + 0x6b0) - 5U) goto code_r0x0001801d634f;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6b9d;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                          *(int64_t *)(&stack0x00000000 + iVar15));
                            goto code_r0x0001801d62a0;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6bac;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                      *(int64_t *)(&stack0x00000000 + iVar15));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6bc4;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                      *(int64_t *)(&stack0x00000000 + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                                      *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15)
                                     );
                        goto code_r0x0001801d6c61;
                    }
                    pcVar4 = *(code **)(in_RCX + 0x1128);
                    if (pcVar4 != (code *)0x0) {
                        *(undefined8 *)(&stack0x00000000 + iVar15) = *(undefined8 *)(in_RCX + 0x1118);
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar15) = 5;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6c03;
                        (*pcVar4)(0, 0, 0x100);
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6c08;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                  *(int64_t *)(&stack0x00000000 + iVar15));
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6c20;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15), 
                              *(int64_t *)((int64_t)&var_8h + iVar15), *(int64_t *)((int64_t)&var_10h + iVar15), 
                              *(int64_t *)((int64_t)&arg_28h + iVar15));
                goto code_r0x0001801d6c61;
            }
code_r0x0001801d6372:
            uVar19 = *puVar20 - 3;
            if (*(int32_t *)(puVar20 + -1) != 2) {
                uVar19 = *puVar20;
            }
            if (uVar19 != 0) {
                pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x20);
                *(int64_t *)(&stack0x00000000 + iVar15) = (int64_t)&var_10h + iVar15;
                *(undefined4 *)(&stack0xfffffffffffffff8 + iVar15) = 0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d63ac;
                iVar11 = (*pcVar4)(in_RCX, uVar19, uVar19);
                if (iVar11 < 1) goto code_r0x0001801d6c6f;
            }
            *(undefined4 *)(in_RCX + 0xfe8) = 0xf0;
            uVar12 = 2;
            if (*(int32_t *)(puVar20 + -1) != 2) {
                uVar12 = 5;
            }
            uVar24 = uVar24 + 1;
            uVar19 = (uint64_t)uVar12 + *(int64_t *)(in_RCX + 0xff0);
            puVar20[4] = uVar19;
            puVar20[1] = *puVar20;
            puVar20[3] = uVar19;
            *(undefined8 *)(in_RCX + 0xff8) = 0;
            *(undefined4 *)(in_RCX + 0x10d4) = 0;
            if (((*(uint64_t *)((int64_t)&var_18h + iVar15) <= uVar24) || (*(int32_t *)((int64_t)puVar20 + -4) != 0x17))
               || ((((iVar11 = *(int32_t *)(in_RCX + 0x14), iVar11 != 0x302 &&
                     (((iVar11 != 0x303 && (iVar11 != 0x100)) && (iVar11 != 0xfeff)))) && (iVar11 != 0xfefd)) ||
                   (*(int64_t *)(in_RCX + 0x1020) == 0)))) goto code_r0x0001801d64a7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d644a;
            uVar17 = func_0x00018020e940();
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6452;
            uVar12 = func_0x00018020ef80(uVar17);
            if ((((uVar12 >> 0x17 & 1) == 0) || (*(int64_t *)(in_RCX + 0x6a0) == 0)) ||
               ((*(uint64_t *)(in_RCX + 0x6c0) < 5 ||
                ((pcVar18 = (char *)(*(int64_t *)(in_RCX + 0x6a0) + *(int64_t *)(in_RCX + 0x6b8)), *pcVar18 != '\x17' ||
                 (puVar22 = puVar20 + 9, *(uint64_t *)(in_RCX + 0x6c0) < (uint64_t)CONCAT11(pcVar18[3], pcVar18[4]) + 5)
                 ))))) goto code_r0x0001801d64a7;
        } while( true );
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6170;
    iVar11 = func_0x0001801d78b0();
    if (iVar11 != 0) goto code_r0x0001801d6178;
    goto code_r0x0001801d6c6f;
code_r0x0001801d64a7:
    if ((uVar24 == 1) &&
       (((*(int32_t *)((int64_t)puVar20 + -4) == 0x14 && (*(int32_t *)(in_RCX + 0x14) == 0x304)) &&
        (*(int32_t *)(in_RCX + 0x1048) != 0)))) {
        if ((*puVar20 == 1) && (*(char *)puVar20[3] == '\x01')) {
            pcVar4 = *(code **)(in_RCX + 0x1128);
            if (pcVar4 != (code *)0x0) {
                *(undefined8 *)(&stack0x00000000 + iVar15) = *(undefined8 *)(in_RCX + 0x1118);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar15) = 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6519;
                (*pcVar4)(0, 0x304, 0x14);
            }
            *(undefined4 *)((int64_t)puVar20 + -4) = 0x16;
            *(int64_t *)(in_RCX + 0x1010) = *(int64_t *)(in_RCX + 0x1010) + 1;
            if (*(uint64_t *)(in_RCX + 0x1010) < 0x21) {
                *(undefined8 *)(in_RCX + 0xfd0) = 0;
                *(undefined8 *)(in_RCX + 0xfd8) = 0;
                *(undefined8 *)(in_RCX + 0xfe0) = 0;
                goto code_r0x0001801d6c6f;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6536;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15));
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d654e;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15), 
                          *(int64_t *)((int64_t)&var_8h + iVar15), *(int64_t *)((int64_t)&var_10h + iVar15), 
                          *(int64_t *)((int64_t)&arg_28h + iVar15));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6584;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15));
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d659c;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15), 
                          *(int64_t *)((int64_t)&var_8h + iVar15), *(int64_t *)((int64_t)&var_10h + iVar15), 
                          *(int64_t *)((int64_t)&arg_28h + iVar15));
        }
code_r0x0001801d6c61:
        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6c6c;
        fcn.1801d5640(0, *(int64_t *)((int64_t)&var_20h + iVar15));
        goto code_r0x0001801d6c6f;
    }
    if (*(int64_t *)(in_RCX + 0x1038) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d65bd;
        iVar16 = func_0x00018020e940();
        if (iVar16 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d65ca;
            iVar11 = func_0x00018020f800(iVar16);
            if (0x3f < iVar11 - 1U) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d65d7;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15));
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d65ef;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15), 
                              *(int64_t *)((int64_t)&var_8h + iVar15), *(int64_t *)((int64_t)&var_10h + iVar15), 
                              *(int64_t *)((int64_t)&arg_28h + iVar15));
                goto code_r0x0001801d6c61;
            }
            uVar23 = (uint64_t)iVar11;
        }
    }
    if ((*(int32_t *)(in_RCX + 0x10b0) == 0) || (*(int64_t *)(in_RCX + 0x1038) == 0)) {
        if (uVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6756;
            iVar16 = func_0x000180224e40(uVar24, 0x10, 0x1804b46d8);
            *(int64_t *)((int64_t)&var_8h + iVar15) = iVar16;
            if (iVar16 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6769;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15));
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6781;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15), 
                              *(int64_t *)((int64_t)&var_8h + iVar15), *(int64_t *)((int64_t)&var_10h + iVar15), 
                              *(int64_t *)((int64_t)&arg_28h + iVar15));
                goto code_r0x0001801d6c61;
            }
        }
    } else {
        uVar19 = 0;
        if (uVar24 != 0) {
            puVar22 = (uint64_t *)(in_RCX + 0x6d8);
            do {
                uVar6 = *puVar22;
                if (uVar6 < uVar23) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d670b;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                  *(int64_t *)(&stack0x00000000 + iVar15));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6723;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                  *(int64_t *)(&stack0x00000000 + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                                  *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15));
                    goto code_r0x0001801d6c61;
                }
                uVar7 = puVar22[3];
                *puVar22 = uVar6 - uVar23;
                pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6660;
                iVar11 = (*pcVar4)(in_RCX, puVar22 + -1, (int64_t)&arg_28h + iVar15);
                if (iVar11 == 0) {
code_r0x0001801d66d9:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d66de;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                  *(int64_t *)(&stack0x00000000 + iVar15));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d66f6;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                  *(int64_t *)(&stack0x00000000 + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                                  *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15));
                    goto code_r0x0001801d6c61;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6674;
                iVar11 = func_0x0001802262e0((int64_t)&arg_28h + iVar15, (uVar7 - uVar23) + uVar6, uVar23);
                if (iVar11 != 0) goto code_r0x0001801d66d9;
                uVar19 = uVar19 + 1;
                puVar22 = puVar22 + 9;
            } while (uVar19 < uVar24);
        }
        uVar23 = 0;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d668c;
    func_0x000180229b10();
    iVar16 = *(int64_t *)(in_RCX + 0x1148);
    piVar21 = *(int64_t **)((int64_t)&var_8h + iVar15);
    *(uint64_t *)(&stack0x00000000 + iVar15) = uVar23;
    *(int64_t **)(&stack0xfffffffffffffff8 + iVar15) = piVar21;
    pcVar4 = *(code **)(iVar16 + 8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d66b5;
    iVar11 = (*pcVar4)(in_RCX, in_RCX + 0x6d0, uVar24);
    if (iVar11 == 0) {
        if (*(int32_t *)(in_RCX + 0x1008) == -1) {
            if ((uVar24 == 1) && (pcVar4 = *(code **)(in_RCX + 0x1120), pcVar4 != (code *)0x0)) {
                uVar17 = *(undefined8 *)(in_RCX + 0x1118);
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d67af;
                iVar11 = (*pcVar4)(uVar17);
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d67bc;
                    func_0x0001802299d0();
                    if (*(int32_t *)(in_RCX + 0x1050) == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d67d0;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                      *(int64_t *)(&stack0x00000000 + iVar15));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d67e8;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                      *(int64_t *)(&stack0x00000000 + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                                      *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15)
                                     );
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d67fe;
                        fcn.1801d5640(0, *(int64_t *)((int64_t)&var_20h + iVar15));
                    } else {
                        uVar23 = *(int64_t *)(in_RCX + 0x6d8) + *(int64_t *)(in_RCX + 0x1058);
                        if (*(int32_t *)(in_RCX + 0x1050) + 0x68 < uVar23) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d681a;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                          *(int64_t *)(&stack0x00000000 + iVar15));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6832;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                          *(int64_t *)(&stack0x00000000 + iVar15), 
                                          *(int64_t *)((int64_t)&var_8h + iVar15), 
                                          *(int64_t *)((int64_t)&var_10h + iVar15), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar15));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6848;
                            fcn.1801d5640(0, *(int64_t *)((int64_t)&var_20h + iVar15));
                        } else {
                            *(uint64_t *)(in_RCX + 0x1058) = uVar23;
                            *(undefined8 *)(in_RCX + 0x6d8) = 0;
                            *(undefined8 *)(in_RCX + 0xfd0) = 0;
                            *(undefined8 *)(in_RCX + 0xfd8) = 0;
                            *(undefined8 *)(in_RCX + 0xfe0) = 0;
                            *(undefined8 *)(in_RCX + 0x1000) = 0;
                        }
                    }
                    goto code_r0x0001801d6ad0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6899;
            func_0x000180229900();
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d689e;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15));
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d68b6;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15), 
                          *(int64_t *)((int64_t)&var_8h + iVar15), *(int64_t *)((int64_t)&var_10h + iVar15), 
                          *(int64_t *)((int64_t)&arg_28h + iVar15));
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d68cc;
            fcn.1801d5640(0, *(int64_t *)((int64_t)&var_20h + iVar15));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d66d1;
            func_0x000180229900();
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d68d9;
        func_0x000180229900();
        if ((*(int64_t *)(in_RCX + 0x1020) == 0) || (*(int32_t *)(in_RCX + 0x10b0) != 0)) {
code_r0x0001801d69ce:
            uVar23 = 0;
            if (uVar24 != 0) {
                puVar22 = (uint64_t *)(in_RCX + 0x6d8);
                do {
                    pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x38);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d69f5;
                    iVar11 = (*pcVar4)(in_RCX, puVar22 + -1);
                    if (iVar11 == 0) goto code_r0x0001801d6ad0;
                    if ((*(uint32_t *)(in_RCX + 0x104c) != 0x4000) &&
                       ((uint64_t)*(uint32_t *)(in_RCX + 0x104c) < *puVar22)) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6b28;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                      *(int64_t *)(&stack0x00000000 + iVar15));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6b40;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                      *(int64_t *)(&stack0x00000000 + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                                      *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15)
                                     );
                        goto code_r0x0001801d6ac0;
                    }
                    puVar22[2] = 0;
                    if (*puVar22 == 0) {
                        uVar19 = *(int64_t *)(in_RCX + 0x1010) + 1;
                        *(uint64_t *)(in_RCX + 0x1010) = uVar19;
                        if (0x20 < uVar19) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6a38;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                          *(int64_t *)(&stack0x00000000 + iVar15));
                            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6a50;
                            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), 
                                          *(int64_t *)(&stack0x00000000 + iVar15), 
                                          *(int64_t *)((int64_t)&var_8h + iVar15), 
                                          *(int64_t *)((int64_t)&var_10h + iVar15), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar15));
                            goto code_r0x0001801d6ac0;
                        }
                    } else {
                        *(undefined8 *)(in_RCX + 0x1010) = 0;
                    }
                    uVar23 = uVar23 + 1;
                    puVar22 = puVar22 + 9;
                } while (uVar23 < uVar24);
            }
            if ((*(int32_t *)(in_RCX + 0x20) != 1) || (*(int32_t *)(in_RCX + 0x6d4) != 0x17)) {
code_r0x0001801d6b79:
                *(uint64_t *)(in_RCX + 0xfd0) = uVar24;
                *(undefined8 *)(in_RCX + 0xfd8) = 0;
                *(undefined8 *)(in_RCX + 0xfe0) = 0;
                goto code_r0x0001801d6ad0;
            }
            if (*(uint32_t *)(in_RCX + 0x1050) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6a9d;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15));
            } else {
                uVar23 = *(int64_t *)(in_RCX + 0x6d8) + *(int64_t *)(in_RCX + 0x1058);
                if (uVar23 <= *(uint32_t *)(in_RCX + 0x1050)) {
                    *(uint64_t *)(in_RCX + 0x1058) = uVar23;
                    goto code_r0x0001801d6b79;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6b61;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15));
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6ab5;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15), 
                          *(int64_t *)((int64_t)&var_8h + iVar15), *(int64_t *)((int64_t)&var_10h + iVar15), 
                          *(int64_t *)((int64_t)&arg_28h + iVar15));
        } else {
            uVar17 = *(undefined8 *)(in_RCX + 0x1038);
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6900;
            iVar16 = func_0x00018020e940(uVar17);
            if ((iVar16 == 0) || (uVar24 == 0)) goto code_r0x0001801d69ce;
            iVar16 = in_RCX + 0x6d0;
            uVar19 = uVar24;
            do {
                pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d694c;
                iVar13 = (*pcVar4)(in_RCX, iVar16, (int64_t)&arg_28h + iVar15);
                if (((iVar13 == 0) || (piVar21 == (int64_t *)0x0)) || (iVar8 = *piVar21, iVar8 == 0)) {
code_r0x0001801d696e:
                    iVar13 = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d696a;
                    iVar14 = func_0x0001802262e0((int64_t)&arg_28h + iVar15, iVar8, uVar23);
                    iVar13 = iVar11;
                    if (iVar14 != 0) goto code_r0x0001801d696e;
                }
                iVar11 = 0;
                if (*(uint64_t *)(iVar16 + 8) <= uVar23 + 0x4400) {
                    iVar11 = iVar13;
                }
                piVar21 = piVar21 + 2;
                iVar16 = iVar16 + 0x48;
                uVar19 = uVar19 - 1;
            } while (uVar19 != 0);
            if (iVar11 != 0) goto code_r0x0001801d69ce;
            if (*(int32_t *)(in_RCX + 0x1008) != -1) goto code_r0x0001801d6ad0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d699f;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15));
            *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d69b7;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar15), *(int64_t *)(&stack0x00000000 + iVar15), 
                          *(int64_t *)((int64_t)&var_8h + iVar15), *(int64_t *)((int64_t)&var_10h + iVar15), 
                          *(int64_t *)((int64_t)&arg_28h + iVar15));
        }
code_r0x0001801d6ac0:
        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6acb;
        fcn.1801d5640(0, *(int64_t *)((int64_t)&var_20h + iVar15));
    }
code_r0x0001801d6ad0:
    puVar9 = *(undefined8 **)((int64_t)&var_8h + iVar15);
    puVar10 = puVar9;
    if (puVar9 != (undefined8 *)0x0) {
        for (; uVar24 != 0; uVar24 = uVar24 - 1) {
            if (*(int32_t *)(puVar10 + 1) != 0) {
                uVar17 = *puVar10;
                *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6afd;
                fcn.180224990(uVar17, 0x1804b46d8, 0x3d7);
            }
            puVar10 = puVar10 + 2;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6b1c;
        fcn.180224990(puVar9, 0x1804b46d8, 0x3d9);
    }
code_r0x0001801d6c6f:
    *(undefined8 *)((int64_t)&uStack_30 + iVar15) = 0x1801d6c7f;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_68h + iVar15) ^ (int64_t)&var_28h + iVar15);
    return;
}

// ============================================================
// Function: FUN_1801d6ca0
// Address: 0x1801d6ca0
// Size: 355 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8
fcn.1801d6ca0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_58h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *in_RDX;
    int64_t iVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    uint64_t in_R8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801d6cc2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar8 = 0;
    if (in_R8 != 0) {
        iVar6 = *(int64_t *)((int64_t)&arg_48h + iVar5);
        piVar7 = (int64_t *)(*(int64_t *)(&stack0x00000050 + iVar5) + 0x18);
        piVar1 = *(int64_t **)((int64_t)&arg_58h + iVar5);
        do {
            iVar2 = piVar7[-3];
            iVar3 = piVar7[-1];
            *(uint32_t *)((int64_t)piVar7 + 0x14) = (uint32_t)*in_RDX;
            iVar4 = 4;
            if (*(int32_t *)(in_RCX + 0x10) != 0) {
                iVar4 = 0xc;
            }
            iVar9 = 7 - (uint64_t)(iVar4 + (int32_t)iVar2 & 7);
            *piVar7 = iVar9;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801d6d3a;
            iVar4 = func_0x000180244550(iVar6, iVar2, iVar3);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801d6dce;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801d6de6;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5)
                              , *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801d6dfc;
                fcn.1801d5640(0, *(int64_t *)((int64_t)&iStackX_20 + iVar5));
                return 0;
            }
            *piVar1 = *piVar1 + 1;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801d6d53;
            iVar4 = func_0x000180243f60(iVar6, iVar9, 0);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801d6d97;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20));
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801d6daf;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5)
                              , *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5));
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801d6dc5;
                fcn.1801d5640(0, *(int64_t *)((int64_t)&iStackX_20 + iVar5));
                return 0;
            }
            uVar8 = uVar8 + 1;
            iVar6 = iVar6 + 0x38;
            in_RDX = in_RDX + 0x18;
            piVar7 = piVar7 + 6;
        } while (uVar8 < in_R8);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d6e10
// Address: 0x1801d6e10
// Size: 331 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801d6e10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t in_RCX;
    undefined8 *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d6e2a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6e39;
    fcn.180219f80(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6e42;
    fcn.180219f80(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6e4b;
    fcn.180219f80(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    uVar1 = *(undefined8 *)(in_RCX + 0x6a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6e64;
    fcn.180224990(uVar1, 0x1804b46d8, 0x1c);
    *(undefined8 *)(in_RCX + 0x6a0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6e77;
    fcn.1801d7830(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    uVar1 = *(undefined8 *)(in_RCX + 0x1020);
    *(undefined8 *)(in_RCX + 0x698) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6e8a;
    func_0x000180211410(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x1028);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6e96;
    func_0x000180257070(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x1038);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6ea2;
    func_0x000180215310(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x1040);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6eae;
    func_0x000180247700(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0x10c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6ec7;
    fcn.180224990(uVar1, 0x1804b46d8, 0x5b6);
    uVar1 = *(undefined8 *)(in_RCX + 0x10c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6ee0;
    fcn.180224990(uVar1, 0x1804b46d8, 0x5b7);
    if (*(int32_t *)(in_RCX + 0x14) == 0x300) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6efa;
        func_0x000180244fc0(in_RCX + 0x1070, 0x40);
    }
    puVar6 = (undefined8 *)(in_RCX + 0x700);
    iVar7 = 0x20;
    do {
        uVar1 = *puVar6;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d6f25;
        fcn.180224990(uVar1, 0x1804b46d8, 0x25);
        *puVar6 = 0;
        puVar6 = puVar6 + 9;
        iVar7 = iVar7 + -1;
    } while (iVar7 != 0);
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = 0x18022499a;
    iVar7 = fcn.18045a350(in_RCX, 0x1804b46d8, 0x5bd);
    iVar7 = -iVar7;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (in_RCX != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar7 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar4 + -8) = 0x18047ca3c;
            iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, in_RCX);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar4 + -8) = 0x18047ca46;
                uVar3 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar4 + -8) = 0x18047ca4d;
                uVar3 = fcn.18046b63c(uVar3);
                *(undefined8 *)((int64_t)&iStackX_20 + iVar7 + iVar4 + -8) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar3;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1801d6f60
// Address: 0x1801d6f60
// Size: 1014 bytes
// ============================================================
undefined8
fcn.1801d6f60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
             int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t *piVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 *puVar8;
    undefined8 unaff_RSI;
    int64_t *piVar9;
    undefined8 unaff_RDI;
    undefined4 in_R8D;
    undefined4 in_R9D;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [4];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d6f73;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d6f99;
    puVar7 = (undefined8 *)fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
    **(undefined8 **)((int64_t)&arg_b0h + iVar6) = 0;
    if (puVar7 == (undefined8 *)0x0) {
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    piVar9 = *(int64_t **)((int64_t)&arg_90h + iVar6);
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
    *(undefined4 *)((int64_t)puVar7 + 0x104c) = 0x4000;
    if (piVar9 != (int64_t *)0x0) {
        iVar2 = *piVar9;
        while (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d700f;
            iVar5 = fcn.180498f10(iVar2, 0x1804ad990);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7022;
                iVar5 = fcn.180229fc0(*(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d702f;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
                    goto code_r0x0001801d72ab;
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7048;
                iVar5 = fcn.180498f10(iVar2, 0x1804ad9b0);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d705b;
                    iVar5 = fcn.18022a610(piVar9, (int64_t)puVar7 + 0x104c);
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7068;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
                        goto code_r0x0001801d72ab;
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7081;
                    iVar5 = fcn.180498f10(iVar2, 0x1804ad9c0);
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7094;
                        iVar5 = fcn.18022a630(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10));
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d709d;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
                            goto code_r0x0001801d72ab;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d70b6;
                        iVar5 = fcn.180498f10(iVar2, 0x1804ad998);
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d70c9;
                            iVar5 = fcn.180229fc0(*(int64_t *)(&stack0x00000040 + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar6));
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d70d2;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
                                goto code_r0x0001801d72ab;
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d70eb;
                            iVar5 = fcn.180498f10(iVar2, 0x1804ad9a8);
                            if (iVar5 != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7241;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7259;
                                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar6));
                                goto code_r0x0001801d72c3;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7102;
                            iVar5 = fcn.180229fc0(*(int64_t *)(&stack0x00000040 + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar6));
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7235;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
                                goto code_r0x0001801d72ab;
                            }
                        }
                    }
                }
            }
            piVar1 = piVar9 + 5;
            piVar9 = piVar9 + 5;
            iVar2 = *piVar1;
        }
    }
    iVar5 = *(int32_t *)((int64_t)&arg_50h + iVar6);
    *(undefined4 *)((int64_t)puVar7 + 0x1c) = *(undefined4 *)((int64_t)&arg_48h + iVar6);
    puVar7[0x21b] = *(undefined8 *)((int64_t)&arg_60h + iVar6);
    puVar7[5] = *(undefined8 *)((int64_t)&arg_68h + iVar6);
    *puVar7 = in_RCX;
    puVar7[1] = in_RDX;
    *(undefined4 *)((int64_t)puVar7 + 0x14) = in_R8D;
    *(undefined4 *)(puVar7 + 3) = in_R9D;
    *(int32_t *)(puVar7 + 4) = iVar5;
    *(undefined4 *)(puVar7 + 0x201) = 0xffffffff;
    *(undefined4 *)(puVar7 + 0x1fd) = 0xf0;
    if (iVar5 == 0) {
        *(undefined4 *)((int64_t)puVar7 + 0x10d4) = 1;
    }
    iVar2 = *(int64_t *)((int64_t)&arg_80h + iVar6);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7189;
        iVar5 = fcn.18021b280(iVar2);
        if (iVar5 == 0) goto code_r0x0001801d72d0;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d719a;
    fcn.180219f80(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
    puVar7[8] = iVar2;
    iVar2 = *(int64_t *)((int64_t)&arg_78h + iVar6);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d71b3;
        iVar5 = fcn.18021b280(iVar2);
        if (iVar5 == 0) goto code_r0x0001801d72d0;
    }
    puVar7[7] = iVar2;
    iVar2 = *(int64_t *)((int64_t)&arg_88h + iVar6);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d71d4;
        iVar5 = fcn.18021b280(iVar2);
        if (iVar5 == 0) goto code_r0x0001801d72d0;
    }
    piVar3 = *(int32_t **)((int64_t)&arg_a0h + iVar6);
    uVar4 = *(undefined8 *)((int64_t)&arg_a8h + iVar6);
    puVar7[9] = iVar2;
    puVar7[0x223] = uVar4;
    if ((piVar3 != (int32_t *)0x0) && (iVar5 = *piVar3, iVar5 != 0)) {
        puVar8 = (undefined8 *)(piVar3 + 2);
        do {
            if (iVar5 == 1) {
                puVar7[0x224] = *puVar8;
            } else if (iVar5 == 2) {
                puVar7[0x225] = *puVar8;
            } else if (iVar5 == 3) {
                puVar7[0x226] = *puVar8;
            } else if (iVar5 == 4) {
                puVar7[0x227] = *puVar8;
            }
            iVar5 = *(int32_t *)(puVar8 + 1);
            puVar8 = puVar8 + 2;
        } while (iVar5 != 0);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d729d;
    iVar5 = fcn.1801d5130(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
    if (iVar5 != 0) {
        if (((*(uint32_t *)(puVar7 + 10) >> 0xb & 1) == 0) && (*(int32_t *)((int64_t)puVar7 + 0x14) < 0x302)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d7309;
            iVar5 = fcn.18020f2b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6));
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d731c;
                iVar5 = fcn.18020f2b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6));
                if (iVar5 == 0) {
                    *(undefined4 *)(puVar7 + 0x203) = 1;
                }
            }
        }
        **(int64_t **)((int64_t)&arg_b0h + iVar6) = (int64_t)puVar7;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d72a6;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8));
code_r0x0001801d72ab:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d72be;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar6));
code_r0x0001801d72c3:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d72d0;
    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10));
code_r0x0001801d72d0:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801d72d8;
    fcn.1801d6e10(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + -8), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar6));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801d7360
// Address: 0x1801d7360
// Size: 558 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801d7360(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h)
{
    undefined4 uVar1;
    uint64_t uVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined *in_R8;
    undefined8 in_R9;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801d737e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar8 = 5;
    if (*(int32_t *)(in_RCX + 0x10) != 0) {
        iVar8 = 0xd;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d73ad;
    iVar6 = func_0x0001802442b0(in_R9, (int64_t)&var_18h + iVar7);
    if (iVar6 != 0) {
        uVar2 = *(uint64_t *)((int64_t)&var_18h + iVar7);
        puVar3 = *(undefined4 **)((int64_t)&arg_68h + iVar7);
        uVar4 = *(uint64_t *)(puVar3 + 2);
        if ((uVar4 <= (uVar2 - in_RDX) + 0x50) && (uVar2 <= uVar4)) {
            if (uVar2 < uVar4) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d73f2;
                iVar6 = func_0x000180243f60(in_R9, uVar4 - uVar2, 0);
                if (iVar6 == 0) goto code_r0x0001801d7540;
            }
            if ((*(int32_t *)(in_RCX + 0x10b0) == 0) || (in_RDX == 0)) {
code_r0x0001801d744b:
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7458;
                iVar6 = func_0x0001802442b0(in_R9, (int64_t)&var_20h + iVar7);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7468;
                    iVar6 = func_0x000180244000(in_R9);
                    if (iVar6 != 0) {
                        if (*(int64_t *)(in_RCX + 0x1128) != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7486;
                            func_0x000180244270(in_R9);
                            pcVar5 = *(code **)(in_RCX + 0x1128);
                            uVar1 = *puVar3;
                            *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)(in_RCX + 0x1118);
                            *(int64_t *)((int64_t)&var_8h + iVar7) = iVar8;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d74b9;
                            (*pcVar5)(1, uVar1, 0x100);
                            if ((*(int32_t *)(in_RCX + 0x14) == 0x304) && (*(int64_t *)(in_RCX + 0x1020) != 0)) {
                                pcVar5 = *(code **)(in_RCX + 0x1128);
                                uVar1 = *puVar3;
                                *(undefined *)((int64_t)&arg_48h + iVar7) = *in_R8;
                                *(undefined8 *)((int64_t)&var_10h + iVar7) = *(undefined8 *)(in_RCX + 0x1118);
                                *(undefined8 *)((int64_t)&var_8h + iVar7) = 1;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7505;
                                (*pcVar5)(1, uVar1, 0x101);
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d750d;
                        iVar6 = func_0x000180244200(in_R9);
                        if (iVar6 != 0) {
                            *(int64_t *)(puVar3 + 2) = *(int64_t *)(puVar3 + 2) + iVar8;
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7516;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                        goto code_r0x0001801d754a;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7539;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7418;
                iVar6 = func_0x000180243f60(in_R9, in_RDX, (int64_t)&arg_48h + iVar7);
                if (iVar6 != 0) {
                    pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d743f;
                    iVar6 = (*pcVar5)(in_RCX, puVar3, *(undefined8 *)((int64_t)&arg_48h + iVar7));
                    if (iVar6 != 0) {
                        *(int64_t *)(puVar3 + 2) = *(int64_t *)(puVar3 + 2) + in_RDX;
                        goto code_r0x0001801d744b;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7522;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            }
            goto code_r0x0001801d754a;
        }
    }
code_r0x0001801d7540:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7545;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
code_r0x0001801d754a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d755d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                  *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                  *(int64_t *)(&stack0x00000038 + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d7573;
    fcn.1801d5640(0, *(int64_t *)(&stack0x00000030 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1801d7590
// Address: 0x1801d7590
// Size: 268 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_1140h because it doesn't fit into ProtoModel

undefined8 fcn.1801d7590(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d75aa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(int32_t *)(in_RCX + 0x10b0) == 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d75d4;
        iVar2 = func_0x000180243f60(in_R8);
        if (iVar2 != 0) {
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d75f7;
            iVar2 = (*pcVar1)(in_RCX, in_R9, *(undefined8 *)((int64_t)&arg_38h + iVar3));
            if (iVar2 != 0) goto code_r0x0001801d7607;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d7600;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    } else {
code_r0x0001801d7607:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d761a;
        iVar2 = func_0x000180244860(in_R8, 0x50 - in_RDX, 0);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d762b;
            iVar2 = func_0x0001802442b0(in_R8, (int64_t)&var_18h + iVar3);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d7637;
                iVar4 = func_0x000180244270(in_R8);
                iVar4 = iVar4 - *(int64_t *)((int64_t)&var_18h + iVar3);
                *(int64_t *)(in_R9 + 8) = *(int64_t *)((int64_t)&var_18h + iVar3);
                *(int64_t *)(in_R9 + 0x20) = iVar4;
                *(int64_t *)(in_R9 + 0x28) = iVar4;
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d7657;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d766f;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d7685;
    fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_40h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801d76a0
// Address: 0x1801d76a0
// Size: 276 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1801d76a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar6;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d76c0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = *(undefined8 **)((int64_t)&arg_48h + iVar5);
    *puVar2 = 0;
    iVar6 = *(int64_t *)(in_R8 + 0x10) + 0x400;
    if (*(int64_t *)(in_RCX + 0x1040) == 0) {
        iVar6 = *(int64_t *)(in_R8 + 0x10);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d7701;
    iVar4 = func_0x0001802446f0(in_RDX, in_R9 & 0xff, 1);
    if (iVar4 != 0) {
        uVar1 = *(undefined4 *)(in_R8 + 4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d7716;
        iVar4 = func_0x0001802446f0(in_RDX, uVar1, 2);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d7727;
            iVar4 = func_0x000180244a90(in_RDX, 2);
            if (iVar4 != 0) {
                iVar3 = *(int64_t *)(in_RCX + 0x1030);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d7742;
                    iVar4 = func_0x000180243f60(in_RDX, iVar3, 0);
                    if (iVar4 == 0) goto code_r0x0001801d7764;
                }
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d7759;
                    iVar4 = func_0x000180244860(in_RDX, iVar6, puVar2);
                    if (iVar4 == 0) goto code_r0x0001801d7764;
                }
                return 1;
            }
        }
    }
code_r0x0001801d7764:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d7769;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d7781;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801d7797;
    fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_40h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801d77c0
// Address: 0x1801d77c0
// Size: 102 bytes
// ============================================================
undefined8 fcn.1801d4910(int64_t param_1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d491c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int32_t *)(param_1 + 0x1c) == 1) {
        if ((*(uint64_t *)(param_1 + 0x698) <= *(uint64_t *)(param_1 + 0x690)) ||
           (((*(uint64_t *)(param_1 + 0x690) == 0 && (*(uint64_t *)(param_1 + 0x698) == 1)) &&
            (*(int64_t *)(param_1 + 0x80) == 0)))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d4959;
            fcn.1801d7830(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10), *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)(param_1 + 0x698) = 0;
            return 1;
        }
    } else if ((((*(uint64_t *)(param_1 + 0xfd0) <= *(uint64_t *)(param_1 + 0xfd8)) &&
                (*(uint64_t *)(param_1 + 0xfd8) == *(uint64_t *)(param_1 + 0xfe0))) &&
               (*(int64_t *)(param_1 + 0x6c0) == 0)) && (*(int32_t *)(param_1 + 0xfe8) != 0xf1)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + 8) = *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + 8);
        *(undefined8 *)((int64_t)aiStackX_10 + iVar3) = 0x1801d77cc;
        iVar4 = fcn.18045a350();
        if ((*(uint8_t *)(param_1 + 0x50) & 2) != 0) {
            uVar1 = *(undefined8 *)(param_1 + 0x6b0);
            uVar2 = *(undefined8 *)(param_1 + 0x6a0);
            *(undefined8 *)((int64_t)aiStackX_10 + -iVar4 + iVar3) = 0x1801d77eb;
            func_0x000180244fc0(uVar2, uVar1);
        }
        uVar1 = *(undefined8 *)(param_1 + 0x6a0);
        *(undefined8 *)((int64_t)aiStackX_10 + -iVar4 + iVar3) = 0x1801d7804;
        fcn.180224990(uVar1, 0x1804b46d8, 0x11c);
        *(undefined8 *)(param_1 + 0x6a0) = 0;
        *(undefined8 *)(param_1 + 0xff0) = 0;
        *(undefined8 *)(param_1 + 0xff8) = 0;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d7830
// Address: 0x1801d7830
// Size: 27 bytes
// ============================================================
void fcn.1801d7830(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint64_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar4;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d783c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint64_t *)(in_RCX + 0x698);
    if (in_RDX < uVar1) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        iVar5 = uVar1 - in_RDX;
        puVar4 = (undefined8 *)((uVar1 + 1) * 0x30 + in_RCX);
        do {
            if (*(int32_t *)(puVar4 + 5) == 0) {
                uVar2 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d788f;
                fcn.180224990(uVar2, 0x1804b46d8, 0x88);
            } else {
                *(undefined4 *)(puVar4 + 5) = 0;
            }
            *puVar4 = 0;
            puVar4 = puVar4 + -6;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801d784b
// Address: 0x1801d784b
// Size: 91 bytes
// ============================================================
void fcn.1801d7830(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint64_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar4;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d783c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint64_t *)(in_RCX + 0x698);
    if (in_RDX < uVar1) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        iVar5 = uVar1 - in_RDX;
        puVar4 = (undefined8 *)((uVar1 + 1) * 0x30 + in_RCX);
        do {
            if (*(int32_t *)(puVar4 + 5) == 0) {
                uVar2 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d788f;
                fcn.180224990(uVar2, 0x1804b46d8, 0x88);
            } else {
                *(undefined4 *)(puVar4 + 5) = 0;
            }
            *puVar4 = 0;
            puVar4 = puVar4 + -6;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801d78a6
// Address: 0x1801d78a6
// Size: 6 bytes
// ============================================================
void fcn.1801d7830(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint64_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar4;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d783c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint64_t *)(in_RCX + 0x698);
    if (in_RDX < uVar1) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        iVar5 = uVar1 - in_RDX;
        puVar4 = (undefined8 *)((uVar1 + 1) * 0x30 + in_RCX);
        do {
            if (*(int32_t *)(puVar4 + 5) == 0) {
                uVar2 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d788f;
                fcn.180224990(uVar2, 0x1804b46d8, 0x88);
            } else {
                *(undefined4 *)(puVar4 + 5) = 0;
            }
            *puVar4 = 0;
            puVar4 = puVar4 + -6;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801d78b0
// Address: 0x1801d78b0
// Size: 39 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_104ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801d4890(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d489c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x1c) == 1) {
        if (*(uint64_t *)(in_RCX + 0x698) <= *(uint64_t *)(in_RCX + 0x690)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d48c8;
            uVar5 = fcn.1801d79c0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
            if ((int32_t)uVar5 == 0) {
                return uVar5;
            }
            *(undefined8 *)(in_RCX + 0x80) = 0;
        }
    } else if ((*(uint64_t *)(in_RCX + 0xfd0) <= *(uint64_t *)(in_RCX + 0xfd8)) && (*(int64_t *)(in_RCX + 0x6c0) == 0))
    {
        uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1801d78c0;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(in_RCX + 0x10);
        if (*(int64_t *)(in_RCX + 0x6a0) == 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar4) = uVar5;
            *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar4) = unaff_RBP;
            iVar2 = *(int32_t *)(in_RCX + 0x104c);
            iVar7 = 0x14;
            if (iVar1 == 0) {
                iVar7 = 0xc;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7904;
            iVar3 = fcn.1801d59d0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if ((iVar3 != 0) && (iVar7 = 0x414, iVar1 == 0)) {
                iVar7 = 0x40c;
            }
            uVar8 = iVar7 + (uint64_t)(iVar2 + 0x140);
            if (1 < *(uint64_t *)(in_RCX + 0x1140)) {
                uVar8 = uVar8 * *(uint64_t *)(in_RCX + 0x1140);
            }
            uVar9 = *(uint64_t *)(in_RCX + 0x6a8);
            if (*(uint64_t *)(in_RCX + 0x6a8) <= uVar8) {
                uVar9 = uVar8;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7953;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7962;
                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d797a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7990;
                fcn.1801d5640(0, *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
                return 0;
            }
            *(int64_t *)(in_RCX + 0x6a0) = iVar7;
            *(uint64_t *)(in_RCX + 0x6b0) = uVar9;
        }
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d78d7
// Address: 0x1801d78d7
// Size: 10 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_104ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801d4890(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d489c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x1c) == 1) {
        if (*(uint64_t *)(in_RCX + 0x698) <= *(uint64_t *)(in_RCX + 0x690)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d48c8;
            uVar5 = fcn.1801d79c0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
            if ((int32_t)uVar5 == 0) {
                return uVar5;
            }
            *(undefined8 *)(in_RCX + 0x80) = 0;
        }
    } else if ((*(uint64_t *)(in_RCX + 0xfd0) <= *(uint64_t *)(in_RCX + 0xfd8)) && (*(int64_t *)(in_RCX + 0x6c0) == 0))
    {
        uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1801d78c0;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(in_RCX + 0x10);
        if (*(int64_t *)(in_RCX + 0x6a0) == 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar4) = uVar5;
            *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar4) = unaff_RBP;
            iVar2 = *(int32_t *)(in_RCX + 0x104c);
            iVar7 = 0x14;
            if (iVar1 == 0) {
                iVar7 = 0xc;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7904;
            iVar3 = fcn.1801d59d0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if ((iVar3 != 0) && (iVar7 = 0x414, iVar1 == 0)) {
                iVar7 = 0x40c;
            }
            uVar8 = iVar7 + (uint64_t)(iVar2 + 0x140);
            if (1 < *(uint64_t *)(in_RCX + 0x1140)) {
                uVar8 = uVar8 * *(uint64_t *)(in_RCX + 0x1140);
            }
            uVar9 = *(uint64_t *)(in_RCX + 0x6a8);
            if (*(uint64_t *)(in_RCX + 0x6a8) <= uVar8) {
                uVar9 = uVar8;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7953;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7962;
                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d797a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7990;
                fcn.1801d5640(0, *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
                return 0;
            }
            *(int64_t *)(in_RCX + 0x6a0) = iVar7;
            *(uint64_t *)(in_RCX + 0x6b0) = uVar9;
        }
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d78e1
// Address: 0x1801d78e1
// Size: 75 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_104ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801d4890(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d489c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x1c) == 1) {
        if (*(uint64_t *)(in_RCX + 0x698) <= *(uint64_t *)(in_RCX + 0x690)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d48c8;
            uVar5 = fcn.1801d79c0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
            if ((int32_t)uVar5 == 0) {
                return uVar5;
            }
            *(undefined8 *)(in_RCX + 0x80) = 0;
        }
    } else if ((*(uint64_t *)(in_RCX + 0xfd0) <= *(uint64_t *)(in_RCX + 0xfd8)) && (*(int64_t *)(in_RCX + 0x6c0) == 0))
    {
        uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1801d78c0;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(in_RCX + 0x10);
        if (*(int64_t *)(in_RCX + 0x6a0) == 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar4) = uVar5;
            *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar4) = unaff_RBP;
            iVar2 = *(int32_t *)(in_RCX + 0x104c);
            iVar7 = 0x14;
            if (iVar1 == 0) {
                iVar7 = 0xc;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7904;
            iVar3 = fcn.1801d59d0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if ((iVar3 != 0) && (iVar7 = 0x414, iVar1 == 0)) {
                iVar7 = 0x40c;
            }
            uVar8 = iVar7 + (uint64_t)(iVar2 + 0x140);
            if (1 < *(uint64_t *)(in_RCX + 0x1140)) {
                uVar8 = uVar8 * *(uint64_t *)(in_RCX + 0x1140);
            }
            uVar9 = *(uint64_t *)(in_RCX + 0x6a8);
            if (*(uint64_t *)(in_RCX + 0x6a8) <= uVar8) {
                uVar9 = uVar8;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7953;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7962;
                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d797a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7990;
                fcn.1801d5640(0, *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
                return 0;
            }
            *(int64_t *)(in_RCX + 0x6a0) = iVar7;
            *(uint64_t *)(in_RCX + 0x6b0) = uVar9;
        }
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d792c
// Address: 0x1801d792c
// Size: 49 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_104ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801d4890(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d489c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x1c) == 1) {
        if (*(uint64_t *)(in_RCX + 0x698) <= *(uint64_t *)(in_RCX + 0x690)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d48c8;
            uVar5 = fcn.1801d79c0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
            if ((int32_t)uVar5 == 0) {
                return uVar5;
            }
            *(undefined8 *)(in_RCX + 0x80) = 0;
        }
    } else if ((*(uint64_t *)(in_RCX + 0xfd0) <= *(uint64_t *)(in_RCX + 0xfd8)) && (*(int64_t *)(in_RCX + 0x6c0) == 0))
    {
        uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1801d78c0;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(in_RCX + 0x10);
        if (*(int64_t *)(in_RCX + 0x6a0) == 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar4) = uVar5;
            *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar4) = unaff_RBP;
            iVar2 = *(int32_t *)(in_RCX + 0x104c);
            iVar7 = 0x14;
            if (iVar1 == 0) {
                iVar7 = 0xc;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7904;
            iVar3 = fcn.1801d59d0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if ((iVar3 != 0) && (iVar7 = 0x414, iVar1 == 0)) {
                iVar7 = 0x40c;
            }
            uVar8 = iVar7 + (uint64_t)(iVar2 + 0x140);
            if (1 < *(uint64_t *)(in_RCX + 0x1140)) {
                uVar8 = uVar8 * *(uint64_t *)(in_RCX + 0x1140);
            }
            uVar9 = *(uint64_t *)(in_RCX + 0x6a8);
            if (*(uint64_t *)(in_RCX + 0x6a8) <= uVar8) {
                uVar9 = uVar8;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7953;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7962;
                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d797a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7990;
                fcn.1801d5640(0, *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
                return 0;
            }
            *(int64_t *)(in_RCX + 0x6a0) = iVar7;
            *(uint64_t *)(in_RCX + 0x6b0) = uVar9;
        }
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d795d
// Address: 0x1801d795d
// Size: 94 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_104ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801d4890(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d489c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 0x1c) == 1) {
        if (*(uint64_t *)(in_RCX + 0x698) <= *(uint64_t *)(in_RCX + 0x690)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801d48c8;
            uVar5 = fcn.1801d79c0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4));
            if ((int32_t)uVar5 == 0) {
                return uVar5;
            }
            *(undefined8 *)(in_RCX + 0x80) = 0;
        }
    } else if ((*(uint64_t *)(in_RCX + 0xfd0) <= *(uint64_t *)(in_RCX + 0xfd8)) && (*(int64_t *)(in_RCX + 0x6c0) == 0))
    {
        uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x1801d78c0;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        iVar1 = *(int32_t *)(in_RCX + 0x10);
        if (*(int64_t *)(in_RCX + 0x6a0) == 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar4) = uVar5;
            *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar4) = unaff_RBP;
            iVar2 = *(int32_t *)(in_RCX + 0x104c);
            iVar7 = 0x14;
            if (iVar1 == 0) {
                iVar7 = 0xc;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7904;
            iVar3 = fcn.1801d59d0(*(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if ((iVar3 != 0) && (iVar7 = 0x414, iVar1 == 0)) {
                iVar7 = 0x40c;
            }
            uVar8 = iVar7 + (uint64_t)(iVar2 + 0x140);
            if (1 < *(uint64_t *)(in_RCX + 0x1140)) {
                uVar8 = uVar8 * *(uint64_t *)(in_RCX + 0x1140);
            }
            uVar9 = *(uint64_t *)(in_RCX + 0x6a8);
            if (*(uint64_t *)(in_RCX + 0x6a8) <= uVar8) {
                uVar9 = uVar8;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7953;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7962;
                fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d797a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar6 + iVar4));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + iVar4) = 0x1801d7990;
                fcn.1801d5640(0, *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
                return 0;
            }
            *(int64_t *)(in_RCX + 0x6a0) = iVar7;
            *(uint64_t *)(in_RCX + 0x6b0) = uVar9;
        }
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801d79c0
// Address: 0x1801d79c0
// Size: 495 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_104ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1030h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_698h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_670h because it doesn't fit into ProtoModel

undefined8 fcn.1801d79c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_60h)
{
    uint64_t uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar6;
    int64_t *piVar7;
    undefined8 *puVar8;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    int64_t in_R8;
    int64_t in_R9;
    int64_t iVar10;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d79dd;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_R8 == 0) || ((iVar10 = 0, 1 < in_RDX && (iVar10 = 0, in_R9 == 0)))) {
        iVar6 = 0xe;
        if (*(int32_t *)(in_RCX + 0x10) == 0) {
            iVar6 = 5;
        }
        iVar10 = (uint64_t)(*(int32_t *)(in_RCX + 0x14) == 0x304) + 0x57 + (uint64_t)*(uint32_t *)(in_RCX + 0x104c) +
                 *(int64_t *)(in_RCX + 0x1030) + iVar6;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801d7a3a;
        iVar3 = fcn.1801d59d0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
        if (iVar3 != 0) {
            iVar10 = iVar10 + 0x400;
        }
        if ((*(uint32_t *)(in_RCX + 0x50) >> 0xb & 1) == 0) {
            iVar10 = iVar10 + 0x57 + iVar6;
        }
    }
    uVar9 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    piVar7 = (int64_t *)(in_RCX + 0x60);
    if (in_RDX != 0) {
        do {
            iVar6 = in_R9;
            if (uVar9 == 0) {
                iVar6 = in_R8;
            }
            if (iVar6 == 0) {
                iVar6 = iVar10;
            }
            if (piVar7[2] != iVar6) {
                iVar5 = *piVar7;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801d7a9c;
                fcn.180224990(iVar5, 0x1804b46d8, 0xbe);
                *piVar7 = 0;
            }
            iVar5 = *piVar7;
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801d7abe;
                iVar5 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                if (iVar5 == 0) {
                    if (*(uint64_t *)(in_RCX + 0x698) < uVar9) {
                        *(uint64_t *)(in_RCX + 0x698) = uVar9;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801d7b30;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801d7b48;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801d7b5e;
                    fcn.1801d5640(0, *(int64_t *)((int64_t)&iStackX_20 + iVar4));
                    return 0;
                }
            }
            piVar7[1] = 0;
            uVar9 = uVar9 + 1;
            piVar7[3] = 0;
            piVar7[4] = 0;
            piVar7[5] = 0;
            *piVar7 = iVar5;
            piVar7[2] = iVar6;
            piVar7 = piVar7 + 6;
        } while (uVar9 < in_RDX);
    }
    uVar1 = *(uint64_t *)(in_RCX + 0x698);
    if (uVar9 < uVar1) {
        puVar8 = (undefined8 *)((uVar1 + 1) * 0x30 + in_RCX);
        iVar10 = uVar1 - uVar9;
        do {
            if (*(int32_t *)(puVar8 + 5) == 0) {
                uVar2 = *puVar8;
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801d7b77;
                fcn.180224990(uVar2, 0x1804b46d8, 0x88);
            } else {
                *(undefined4 *)(puVar8 + 5) = 0;
            }
            *puVar8 = 0;
            puVar8 = puVar8 + -6;
            iVar10 = iVar10 + -1;
        } while (iVar10 != 0);
    }
    *(uint64_t *)(in_RCX + 0x698) = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_1801d7bb0
// Address: 0x1801d7bb0
// Size: 48 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1110h because it doesn't fit into ProtoModel

void fcn.1801d7bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    uint64_t uVar12;
    undefined8 in_RDX;
    int64_t *piVar13;
    undefined8 unaff_RSI;
    uint8_t *puVar14;
    int64_t *piVar15;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar16;
    undefined8 unaff_R13;
    uint64_t uVar17;
    undefined8 unaff_R15;
    int64_t *piVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_10d8h;
    int64_t var_998h;
    int64_t var_990h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801d7bc9;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10);
    uVar17 = 0;
    *(undefined8 *)(&stack0x00001168 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x00001120 + iVar10) = unaff_RDI;
    iVar11 = *(int64_t *)(in_RCX + 0x1038);
    *(undefined8 *)(&stack0x00001118 + iVar10) = unaff_R13;
    *(int64_t *)((int64_t)&arg_50h + iVar10) = in_R8;
    *(undefined8 *)((int64_t)&arg_48h + iVar10) = in_RDX;
    *(undefined4 *)((int64_t)&arg_30h + iVar10) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar10) = 0;
    iVar8 = 0;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c31;
        iVar11 = func_0x00018020e940();
        iVar8 = 0;
        if (iVar11 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x1038);
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c42;
            iVar8 = func_0x00018020f590(uVar2);
            *(int32_t *)((int64_t)&arg_30h + iVar10) = iVar8;
            if (iVar8 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c51;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c69;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -8)
                              , *(int64_t *)((int64_t)aiStackX_18 + iVar10), *(int64_t *)((int64_t)&arg_30h + iVar10));
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c7f;
                fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_28h + iVar10));
                goto code_r0x0001801d7f35;
            }
        }
    }
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x50);
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7ca0;
    iVar9 = (*pcVar3)(in_RCX, in_RDX, in_R8, (int64_t)&arg_28h + iVar10);
    if (iVar9 == 0) goto code_r0x0001801d7f35;
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x58);
    *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -8) = (int64_t)&arg_38h + iVar10;
    *(int64_t *)((int64_t)&var_8h + iVar10) = in_RCX + 0x60;
    *(int64_t **)((int64_t)aiStackX_18 + iVar10 + -0x18) = &var_10d8h;
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7ce0;
    iVar9 = (*pcVar3)(in_RCX, in_RDX, in_R8, (int64_t)&arg_58h + iVar10);
    if (iVar9 == 0) goto code_r0x0001801d7f35;
    *(undefined8 *)(&stack0x00001110 + iVar10) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7d04;
    fcn.1804986e0(&var_998h, 0, 0x948);
    uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
    if (uVar12 + in_R8 != 0) {
        piVar13 = &var_10d8h;
        piVar15 = &var_990h;
        uVar16 = uVar17;
        do {
            *(undefined8 *)((int64_t)&arg_40h + iVar10) = 0;
            if (uVar16 < uVar12) {
                puVar14 = (uint8_t *)((int64_t)&arg_58h + iVar10);
            } else {
                puVar14 = (uint8_t *)(*(int64_t *)((int64_t)&arg_48h + iVar10) + (uVar16 - uVar12) * 0x18);
            }
            pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x60);
            if (pcVar3 == (code *)0x0) {
                uVar7 = *puVar14;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7d5e;
                uVar7 = (*pcVar3)(in_RCX, puVar14);
            }
            *(uint32_t *)((int64_t)piVar15 + -4) = (uint32_t)uVar7;
            *(undefined4 *)(piVar15 + -1) = *(undefined4 *)(puVar14 + 4);
            pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x68);
            *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18) = (int64_t)&arg_40h + iVar10;
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7d96;
            iVar8 = (*pcVar3)(in_RCX, piVar13, puVar14);
            if (iVar8 == 0) goto code_r0x0001801d7f35;
            iVar11 = *(int64_t *)((int64_t)&arg_40h + iVar10);
            iVar4 = *(int64_t *)(in_RCX + 0x1040);
            piVar15[3] = iVar11;
            iVar5 = *(int64_t *)(puVar14 + 0x10);
            *piVar15 = iVar5;
            iVar6 = *(int64_t *)(puVar14 + 8);
            piVar15[4] = iVar6;
            if (iVar4 != 0) {
                *(int32_t *)((int64_t)aiStackX_18 + iVar10 + -0x18) = (int32_t)iVar5;
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7dd5;
                iVar8 = func_0x0001802477c0(iVar4, iVar11, (int32_t)iVar5 + 0x400);
                if (-1 < iVar8) {
                    piVar15[4] = piVar15[3];
                    *piVar15 = (int64_t)iVar8;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7df2;
                    iVar8 = func_0x000180243f60(piVar13, (int64_t)iVar8, 0);
                    if (iVar8 != 0) goto code_r0x0001801d7e41;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7dfb;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7e13;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -8)
                              , *(int64_t *)((int64_t)aiStackX_18 + iVar10), *(int64_t *)((int64_t)&arg_30h + iVar10));
                goto code_r0x0001801d7f1a;
            }
            if (iVar11 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7e31;
                iVar8 = func_0x0001802445f0(piVar13, iVar6, iVar5);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f93;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar10));
                    goto code_r0x0001801d7f08;
                }
                piVar15[4] = piVar15[3];
            }
code_r0x0001801d7e41:
            pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x70);
            if (pcVar3 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7e61;
                iVar8 = (*pcVar3)(in_RCX, puVar14, piVar13, piVar15 + -1);
                if (iVar8 == 0) goto code_r0x0001801d7f35;
            }
            iVar8 = *(int32_t *)((int64_t)&arg_30h + iVar10);
            pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x78);
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7e89;
            iVar9 = (*pcVar3)(in_RCX, (int64_t)iVar8, piVar13, piVar15 + -1);
            if (iVar9 == 0) goto code_r0x0001801d7f35;
            uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
            uVar16 = uVar16 + 1;
            piVar13 = piVar13 + 7;
            piVar15 = piVar15 + 9;
        } while (uVar16 < uVar12 + in_R8);
    }
    if (uVar12 == 0) {
code_r0x0001801d7fa9:
        iVar11 = *(int64_t *)((int64_t)&arg_50h + iVar10);
        *(int64_t *)((int64_t)&var_8h + iVar10) = (int64_t)iVar8;
        iVar4 = *(int64_t *)(in_RCX + 0x1148);
        *(undefined8 *)((int64_t)aiStackX_18 + iVar10 + -0x18) = 0;
        pcVar3 = *(code **)(iVar4 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7fe4;
        iVar9 = (*pcVar3)(in_RCX, &var_998h + uVar12 * 9, iVar11);
        if (0 < iVar9) {
            uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
            if (iVar11 + uVar12 != 0) {
                piVar13 = &var_10d8h;
                piVar15 = &var_998h;
                piVar18 = (int64_t *)(in_RCX + 0x80);
                uVar16 = uVar17;
                do {
                    if (uVar16 < uVar12) {
                        iVar11 = (int64_t)&arg_58h + iVar10;
                    } else {
                        iVar11 = *(int64_t *)((int64_t)&arg_48h + iVar10) + (uVar16 - uVar12) * 0x18;
                    }
                    iVar4 = *(int64_t *)(in_RCX + 0x1148);
                    *(int64_t **)((int64_t)aiStackX_18 + iVar10 + -0x18) = piVar15;
                    pcVar3 = *(code **)(iVar4 + 0x80);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d8071;
                    iVar9 = (*pcVar3)(in_RCX, (int64_t)iVar8, iVar11, piVar13);
                    if (iVar9 == 0) break;
                    piVar1 = piVar15 + 1;
                    uVar16 = uVar16 + 1;
                    uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
                    piVar15 = piVar15 + 9;
                    *piVar18 = *piVar1;
                    piVar13 = piVar13 + 7;
                    piVar18 = piVar18 + 6;
                } while (uVar16 < *(int64_t *)((int64_t)&arg_50h + iVar10) + uVar12);
            }
            goto code_r0x0001801d7f35;
        }
        if (*(int32_t *)(in_RCX + 0x1008) != -1) goto code_r0x0001801d7f35;
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7ffb;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar10));
    } else {
        iVar11 = *(int64_t *)(in_RCX + 0x1148);
        *(int64_t *)((int64_t)&var_8h + iVar10) = (int64_t)iVar8;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar10 + -0x18) = 0;
        pcVar3 = *(code **)(iVar11 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7ee5;
        iVar9 = (*pcVar3)(in_RCX, &var_998h, 1);
        if (0 < iVar9) {
            uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
            goto code_r0x0001801d7fa9;
        }
        if (*(int32_t *)(in_RCX + 0x1008) != -1) goto code_r0x0001801d7f35;
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7efc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar10));
    }
code_r0x0001801d7f08:
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f14;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar10), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar10), 
                  *(int64_t *)((int64_t)&arg_30h + iVar10));
code_r0x0001801d7f1a:
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f2a;
    fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_28h + iVar10));
code_r0x0001801d7f35:
    if (*(int64_t *)((int64_t)&arg_38h + iVar10) != 0) {
        piVar13 = &var_10d8h;
        do {
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f60;
            func_0x000180243fb0(piVar13);
            uVar17 = uVar17 + 1;
            piVar13 = piVar13 + 7;
        } while (uVar17 < *(uint64_t *)((int64_t)&arg_38h + iVar10));
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f80;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801d7be0
// Address: 0x1801d7be0
// Size: 266 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1168h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1118h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1110h because it doesn't fit into ProtoModel

void fcn.1801d7bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    uint64_t uVar12;
    undefined8 in_RDX;
    int64_t *piVar13;
    undefined8 unaff_RSI;
    uint8_t *puVar14;
    int64_t *piVar15;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar16;
    undefined8 unaff_R13;
    uint64_t uVar17;
    undefined8 unaff_R15;
    int64_t *piVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    int64_t var_10d8h;
    int64_t var_998h;
    int64_t var_990h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801d7bc9;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10);
    uVar17 = 0;
    *(undefined8 *)(&stack0x00001168 + iVar10) = unaff_RSI;
    *(undefined8 *)(&stack0x00001120 + iVar10) = unaff_RDI;
    iVar11 = *(int64_t *)(in_RCX + 0x1038);
    *(undefined8 *)(&stack0x00001118 + iVar10) = unaff_R13;
    *(int64_t *)((int64_t)&arg_50h + iVar10) = in_R8;
    *(undefined8 *)((int64_t)&arg_48h + iVar10) = in_RDX;
    *(undefined4 *)((int64_t)&arg_30h + iVar10) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar10) = 0;
    iVar8 = 0;
    if (iVar11 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c31;
        iVar11 = func_0x00018020e940();
        iVar8 = 0;
        if (iVar11 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x1038);
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c42;
            iVar8 = func_0x00018020f590(uVar2);
            *(int32_t *)((int64_t)&arg_30h + iVar10) = iVar8;
            if (iVar8 < 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c51;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c69;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -8)
                              , *(int64_t *)((int64_t)aiStackX_18 + iVar10), *(int64_t *)((int64_t)&arg_30h + iVar10));
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7c7f;
                fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_28h + iVar10));
                goto code_r0x0001801d7f35;
            }
        }
    }
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x50);
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7ca0;
    iVar9 = (*pcVar3)(in_RCX, in_RDX, in_R8, (int64_t)&arg_28h + iVar10);
    if (iVar9 == 0) goto code_r0x0001801d7f35;
    pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x58);
    *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -8) = (int64_t)&arg_38h + iVar10;
    *(int64_t *)((int64_t)&var_8h + iVar10) = in_RCX + 0x60;
    *(int64_t **)((int64_t)aiStackX_18 + iVar10 + -0x18) = &var_10d8h;
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7ce0;
    iVar9 = (*pcVar3)(in_RCX, in_RDX, in_R8, (int64_t)&arg_58h + iVar10);
    if (iVar9 == 0) goto code_r0x0001801d7f35;
    *(undefined8 *)(&stack0x00001110 + iVar10) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7d04;
    fcn.1804986e0(&var_998h, 0, 0x948);
    uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
    if (uVar12 + in_R8 != 0) {
        piVar13 = &var_10d8h;
        piVar15 = &var_990h;
        uVar16 = uVar17;
        do {
            *(undefined8 *)((int64_t)&arg_40h + iVar10) = 0;
            if (uVar16 < uVar12) {
                puVar14 = (uint8_t *)((int64_t)&arg_58h + iVar10);
            } else {
                puVar14 = (uint8_t *)(*(int64_t *)((int64_t)&arg_48h + iVar10) + (uVar16 - uVar12) * 0x18);
            }
            pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x60);
            if (pcVar3 == (code *)0x0) {
                uVar7 = *puVar14;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7d5e;
                uVar7 = (*pcVar3)(in_RCX, puVar14);
            }
            *(uint32_t *)((int64_t)piVar15 + -4) = (uint32_t)uVar7;
            *(undefined4 *)(piVar15 + -1) = *(undefined4 *)(puVar14 + 4);
            pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x68);
            *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18) = (int64_t)&arg_40h + iVar10;
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7d96;
            iVar8 = (*pcVar3)(in_RCX, piVar13, puVar14);
            if (iVar8 == 0) goto code_r0x0001801d7f35;
            iVar11 = *(int64_t *)((int64_t)&arg_40h + iVar10);
            iVar4 = *(int64_t *)(in_RCX + 0x1040);
            piVar15[3] = iVar11;
            iVar5 = *(int64_t *)(puVar14 + 0x10);
            *piVar15 = iVar5;
            iVar6 = *(int64_t *)(puVar14 + 8);
            piVar15[4] = iVar6;
            if (iVar4 != 0) {
                *(int32_t *)((int64_t)aiStackX_18 + iVar10 + -0x18) = (int32_t)iVar5;
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7dd5;
                iVar8 = func_0x0001802477c0(iVar4, iVar11, (int32_t)iVar5 + 0x400);
                if (-1 < iVar8) {
                    piVar15[4] = piVar15[3];
                    *piVar15 = (int64_t)iVar8;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7df2;
                    iVar8 = func_0x000180243f60(piVar13, (int64_t)iVar8, 0);
                    if (iVar8 != 0) goto code_r0x0001801d7e41;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7dfb;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)&var_8h + iVar10));
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7e13;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                              *(int64_t *)((int64_t)&var_8h + iVar10), *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -8)
                              , *(int64_t *)((int64_t)aiStackX_18 + iVar10), *(int64_t *)((int64_t)&arg_30h + iVar10));
                goto code_r0x0001801d7f1a;
            }
            if (iVar11 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7e31;
                iVar8 = func_0x0001802445f0(piVar13, iVar6, iVar5);
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f93;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar10));
                    goto code_r0x0001801d7f08;
                }
                piVar15[4] = piVar15[3];
            }
code_r0x0001801d7e41:
            pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x70);
            if (pcVar3 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7e61;
                iVar8 = (*pcVar3)(in_RCX, puVar14, piVar13, piVar15 + -1);
                if (iVar8 == 0) goto code_r0x0001801d7f35;
            }
            iVar8 = *(int32_t *)((int64_t)&arg_30h + iVar10);
            pcVar3 = *(code **)(*(int64_t *)(in_RCX + 0x1148) + 0x78);
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7e89;
            iVar9 = (*pcVar3)(in_RCX, (int64_t)iVar8, piVar13, piVar15 + -1);
            if (iVar9 == 0) goto code_r0x0001801d7f35;
            uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
            uVar16 = uVar16 + 1;
            piVar13 = piVar13 + 7;
            piVar15 = piVar15 + 9;
        } while (uVar16 < uVar12 + in_R8);
    }
    if (uVar12 == 0) {
code_r0x0001801d7fa9:
        iVar11 = *(int64_t *)((int64_t)&arg_50h + iVar10);
        *(int64_t *)((int64_t)&var_8h + iVar10) = (int64_t)iVar8;
        iVar4 = *(int64_t *)(in_RCX + 0x1148);
        *(undefined8 *)((int64_t)aiStackX_18 + iVar10 + -0x18) = 0;
        pcVar3 = *(code **)(iVar4 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7fe4;
        iVar9 = (*pcVar3)(in_RCX, &var_998h + uVar12 * 9, iVar11);
        if (0 < iVar9) {
            uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
            if (iVar11 + uVar12 != 0) {
                piVar13 = &var_10d8h;
                piVar15 = &var_998h;
                piVar18 = (int64_t *)(in_RCX + 0x80);
                uVar16 = uVar17;
                do {
                    if (uVar16 < uVar12) {
                        iVar11 = (int64_t)&arg_58h + iVar10;
                    } else {
                        iVar11 = *(int64_t *)((int64_t)&arg_48h + iVar10) + (uVar16 - uVar12) * 0x18;
                    }
                    iVar4 = *(int64_t *)(in_RCX + 0x1148);
                    *(int64_t **)((int64_t)aiStackX_18 + iVar10 + -0x18) = piVar15;
                    pcVar3 = *(code **)(iVar4 + 0x80);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d8071;
                    iVar9 = (*pcVar3)(in_RCX, (int64_t)iVar8, iVar11, piVar13);
                    if (iVar9 == 0) break;
                    piVar1 = piVar15 + 1;
                    uVar16 = uVar16 + 1;
                    uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
                    piVar15 = piVar15 + 9;
                    *piVar18 = *piVar1;
                    piVar13 = piVar13 + 7;
                    piVar18 = piVar18 + 6;
                } while (uVar16 < *(int64_t *)((int64_t)&arg_50h + iVar10) + uVar12);
            }
            goto code_r0x0001801d7f35;
        }
        if (*(int32_t *)(in_RCX + 0x1008) != -1) goto code_r0x0001801d7f35;
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7ffb;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar10));
    } else {
        iVar11 = *(int64_t *)(in_RCX + 0x1148);
        *(int64_t *)((int64_t)&var_8h + iVar10) = (int64_t)iVar8;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar10 + -0x18) = 0;
        pcVar3 = *(code **)(iVar11 + 8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7ee5;
        iVar9 = (*pcVar3)(in_RCX, &var_998h, 1);
        if (0 < iVar9) {
            uVar12 = *(uint64_t *)((int64_t)&arg_28h + iVar10);
            goto code_r0x0001801d7fa9;
        }
        if (*(int32_t *)(in_RCX + 0x1008) != -1) goto code_r0x0001801d7f35;
        *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7efc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar10));
    }
code_r0x0001801d7f08:
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f14;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar10 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar10), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar10 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar10), 
                  *(int64_t *)((int64_t)&arg_30h + iVar10));
code_r0x0001801d7f1a:
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f2a;
    fcn.1801d5640(0, *(int64_t *)((int64_t)&arg_28h + iVar10));
code_r0x0001801d7f35:
    if (*(int64_t *)((int64_t)&arg_38h + iVar10) != 0) {
        piVar13 = &var_10d8h;
        do {
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f60;
            func_0x000180243fb0(piVar13);
            uVar17 = uVar17 + 1;
            piVar13 = piVar13 + 7;
        } while (uVar17 < *(uint64_t *)((int64_t)&arg_38h + iVar10));
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801d7f80;
    func_0x000180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10));
    return;
}

