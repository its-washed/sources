// Chunk 111 - 50 functions

// ============================================================
// Function: FUN_1801820f0
// Address: 0x1801820f0
// Size: 189 bytes
// ============================================================
undefined8 fcn.1801820f0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar1 = fcn.180184890(2, 1, 0, arg1 + 0x150);
    if (iVar1 != 0) {
        iVar2 = fcn.18045b9a8(0x1804a7440, 0x5c);
        uVar3 = fcn.1801723e0(unaff_retaddr);
        fcn.180172b00(uVar3, 4, 0x1804a74e0, iVar2 + 1, 0xfb, 0x1804a74c8);
        return 0xffffffff;
    }
    iVar2 = fcn.180181e00(arg1, *(undefined4 *)(arg1 + 0x150));
    *(undefined8 *)(iVar2 + 0xf8) = 0x180181760;
    fcn.180183b00(iVar2);
    *(undefined4 *)(iVar2 + 0x38) = 3;
    *(int32_t *)(arg1 + 0x40) = *(int32_t *)(arg1 + 0x40) + 1;
    return 0;
}

// ============================================================
// Function: FUN_1801821b0
// Address: 0x1801821b0
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801821b0(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_fffffffffffffff0;
    
    if (((arg1 != 0) && (iVar1 = *(int64_t *)arg1, iVar1 != 0)) && (*(int32_t *)(iVar1 + 4) != 3)) {
        *(undefined4 *)(iVar1 + 4) = 3;
        iVar3 = fcn.18045b9a8(0x1804a7440, 0x5c);
        uVar2 = (*(code *)0x699ddc)();
        uVar4 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar4, 1, 0x1804a7588, uVar2, iVar3 + 1, 0x1b8, 0x1804a7578);
        fcn.180181e80(iVar1);
        fcn.180180fe0(iVar1);
        *(undefined8 *)arg1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801821bf
// Address: 0x1801821bf
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801821b0(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_fffffffffffffff0;
    
    if (((arg1 != 0) && (iVar1 = *(int64_t *)arg1, iVar1 != 0)) && (*(int32_t *)(iVar1 + 4) != 3)) {
        *(undefined4 *)(iVar1 + 4) = 3;
        iVar3 = fcn.18045b9a8(0x1804a7440, 0x5c);
        uVar2 = (*(code *)0x699ddc)();
        uVar4 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar4, 1, 0x1804a7588, uVar2, iVar3 + 1, 0x1b8, 0x1804a7578);
        fcn.180181e80(iVar1);
        fcn.180180fe0(iVar1);
        *(undefined8 *)arg1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801821dd
// Address: 0x1801821dd
// Size: 132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801821b0(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_fffffffffffffff0;
    
    if (((arg1 != 0) && (iVar1 = *(int64_t *)arg1, iVar1 != 0)) && (*(int32_t *)(iVar1 + 4) != 3)) {
        *(undefined4 *)(iVar1 + 4) = 3;
        iVar3 = fcn.18045b9a8(0x1804a7440, 0x5c);
        uVar2 = (*(code *)0x699ddc)();
        uVar4 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar4, 1, 0x1804a7588, uVar2, iVar3 + 1, 0x1b8, 0x1804a7578);
        fcn.180181e80(iVar1);
        fcn.180180fe0(iVar1);
        *(undefined8 *)arg1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180182261
// Address: 0x180182261
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801821b0(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_fffffffffffffff0;
    
    if (((arg1 != 0) && (iVar1 = *(int64_t *)arg1, iVar1 != 0)) && (*(int32_t *)(iVar1 + 4) != 3)) {
        *(undefined4 *)(iVar1 + 4) = 3;
        iVar3 = fcn.18045b9a8(0x1804a7440, 0x5c);
        uVar2 = (*(code *)0x699ddc)();
        uVar4 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar4, 1, 0x1804a7588, uVar2, iVar3 + 1, 0x1b8, 0x1804a7578);
        fcn.180181e80(iVar1);
        fcn.180180fe0(iVar1);
        *(undefined8 *)arg1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18018226c
// Address: 0x18018226c
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801821b0(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_fffffffffffffff0;
    
    if (((arg1 != 0) && (iVar1 = *(int64_t *)arg1, iVar1 != 0)) && (*(int32_t *)(iVar1 + 4) != 3)) {
        *(undefined4 *)(iVar1 + 4) = 3;
        iVar3 = fcn.18045b9a8(0x1804a7440, 0x5c);
        uVar2 = (*(code *)0x699ddc)();
        uVar4 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar4, 1, 0x1804a7588, uVar2, iVar3 + 1, 0x1b8, 0x1804a7578);
        fcn.180181e80(iVar1);
        fcn.180180fe0(iVar1);
        *(undefined8 *)arg1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180182270
// Address: 0x180182270
// Size: 316 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180182270(int64_t arg1)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    uint32_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStackY_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    puVar3 = (uint32_t *)fcn.1801813b0(0x1a0);
    fcn.180184a70();
    puVar3[1] = 0;
    uVar2 = (*(code *)0x699f74)();
    puVar3[0xc] = uVar2;
    uVar2 = (*(code *)0x699ddc)();
    puVar3[0xd] = uVar2;
    puVar1 = puVar3 + 0x32;
    *(uint32_t **)puVar1 = puVar1;
    *(uint32_t **)(puVar3 + 0x34) = puVar1;
    *(undefined8 *)(puVar3 + 0x3c) = 0x180182e70;
    *(undefined8 *)(puVar3 + 0x42) = 0x180182e70;
    *(undefined8 *)(puVar3 + 0x38) = 0;
    puVar3[0x3a] = 0;
    *(undefined8 *)(puVar3 + 0x3e) = 0;
    puVar3[0x40] = 0;
    (*(code *)0x699f00)(puVar3 + 0x5e);
    *(undefined8 *)(puVar3 + 0x54) = 0xffffffffffffffff;
    fcn.180473698(&var_28h);
    *(uint64_t *)(puVar3 + 2) = (int64_t)(int32_t)var_28h * 1000 + (uint64_t)(uint16_t)var_20h;
    uVar4 = fcn.180189210(var_38h);
    *puVar3 = *puVar3 | (uint32_t)arg1;
    *(undefined8 *)(puVar3 + 8) = uVar4;
    *(undefined8 *)(puVar3 + 4) = uVar4;
    iVar5 = fcn.18045b9a8(0x1804a7440, 0x5c);
    uVar2 = puVar3[0xd];
    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
    var_38h = 0x1804a7548;
    var_40h._0_4_ = 0x1af;
    var_48h = iVar5 + 1;
    fcn.180172b00(uVar4, 1, 0x1804a7558, uVar2);
    fcn.180459870(var_18h ^ (uint64_t)auStackY_68);
    return;
}

// ============================================================
// Function: FUN_1801823b0
// Address: 0x1801823b0
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801823b0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)arg2 == 0) {
        *(int64_t *)arg2 = arg1;
    }
    if (*(int32_t *)(arg2 + 8) == 0) {
        *(undefined4 *)(arg2 + 8) = 0x400;
    }
    if (*(int64_t *)(arg2 + 0x10) == 0) {
        uVar9 = fcn.180174350();
        *(undefined8 *)(arg2 + 0x10) = uVar9;
    }
    (*(code *)0x699f1c)(arg1 + 0x178);
    if ((*(int32_t *)(arg1 + 0x154) != -1) || (iVar8 = fcn.1801820f0(arg1), iVar8 == 0)) {
        iVar8 = (*(code *)0x8000000000000013)((int64_t)*(int32_t *)(arg1 + 0x154), 0x18063e354, 1, 0);
        if (iVar8 < 1) {
            iVar10 = fcn.18045b9a8(0x1804a7440, 0x5c);
            uVar9 = fcn.1801723e0(var_20h);
            fcn.180172b00(uVar9, 4, 0x1804a7520, iVar10 + 1, 0x12f, 0x1804a7508);
        } else {
            piVar1 = (int64_t *)(arg1 + 0x168);
            piVar2 = (int64_t *)(arg1 + 0x160);
            piVar3 = (int64_t *)(arg1 + 0x170);
            if (*(int64_t *)(arg1 + 0x168) == 0) {
                *piVar3 = 0;
                *piVar2 = 0;
                *piVar1 = 0x10;
                uVar9 = fcn.1801813b0(0x400);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
            }
            iVar10 = *piVar1;
            iVar11 = *piVar2;
            if (iVar11 == iVar10) {
                iVar8 = (int32_t)iVar10 * 2;
                if (iVar8 == 0) {
                    iVar8 = 0x10;
                }
                uVar9 = func_0x000180181320(*(undefined8 *)(arg1 + 0x158), (int64_t)iVar8 << 6, iVar10 << 6);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
                *piVar1 = (int64_t)iVar8;
            } else if (*piVar3 + iVar11 == iVar10) {
                func_0x000180498030(*(int64_t *)(arg1 + 0x158), *piVar3 * 0x40 + *(int64_t *)(arg1 + 0x158), iVar11 << 6
                                   );
                *piVar3 = 0;
            }
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            iVar10 = *(int64_t *)(arg1 + 0x158);
            iVar11 = (*piVar2 + *piVar3) * 0x40;
            puVar4 = (undefined4 *)(iVar11 + iVar10);
            *puVar4 = *(undefined4 *)arg2;
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x14);
            uVar6 = *(undefined4 *)(arg2 + 0x18);
            uVar7 = *(undefined4 *)(arg2 + 0x1c);
            puVar4 = (undefined4 *)(iVar11 + 0x10 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x10);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x24);
            uVar6 = *(undefined4 *)(arg2 + 0x28);
            uVar7 = *(undefined4 *)(arg2 + 0x2c);
            puVar4 = (undefined4 *)(iVar11 + 0x20 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x20);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x34);
            uVar6 = *(undefined4 *)(arg2 + 0x38);
            uVar7 = *(undefined4 *)(arg2 + 0x3c);
            puVar4 = (undefined4 *)(iVar11 + 0x30 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x30);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            *piVar2 = *piVar2 + 1;
        }
    }
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f34)(arg1 + 0x178);
    return;
}

// ============================================================
// Function: FUN_18018241c
// Address: 0x18018241c
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801823b0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)arg2 == 0) {
        *(int64_t *)arg2 = arg1;
    }
    if (*(int32_t *)(arg2 + 8) == 0) {
        *(undefined4 *)(arg2 + 8) = 0x400;
    }
    if (*(int64_t *)(arg2 + 0x10) == 0) {
        uVar9 = fcn.180174350();
        *(undefined8 *)(arg2 + 0x10) = uVar9;
    }
    (*(code *)0x699f1c)(arg1 + 0x178);
    if ((*(int32_t *)(arg1 + 0x154) != -1) || (iVar8 = fcn.1801820f0(arg1), iVar8 == 0)) {
        iVar8 = (*(code *)0x8000000000000013)((int64_t)*(int32_t *)(arg1 + 0x154), 0x18063e354, 1, 0);
        if (iVar8 < 1) {
            iVar10 = fcn.18045b9a8(0x1804a7440, 0x5c);
            uVar9 = fcn.1801723e0(var_20h);
            fcn.180172b00(uVar9, 4, 0x1804a7520, iVar10 + 1, 0x12f, 0x1804a7508);
        } else {
            piVar1 = (int64_t *)(arg1 + 0x168);
            piVar2 = (int64_t *)(arg1 + 0x160);
            piVar3 = (int64_t *)(arg1 + 0x170);
            if (*(int64_t *)(arg1 + 0x168) == 0) {
                *piVar3 = 0;
                *piVar2 = 0;
                *piVar1 = 0x10;
                uVar9 = fcn.1801813b0(0x400);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
            }
            iVar10 = *piVar1;
            iVar11 = *piVar2;
            if (iVar11 == iVar10) {
                iVar8 = (int32_t)iVar10 * 2;
                if (iVar8 == 0) {
                    iVar8 = 0x10;
                }
                uVar9 = func_0x000180181320(*(undefined8 *)(arg1 + 0x158), (int64_t)iVar8 << 6, iVar10 << 6);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
                *piVar1 = (int64_t)iVar8;
            } else if (*piVar3 + iVar11 == iVar10) {
                func_0x000180498030(*(int64_t *)(arg1 + 0x158), *piVar3 * 0x40 + *(int64_t *)(arg1 + 0x158), iVar11 << 6
                                   );
                *piVar3 = 0;
            }
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            iVar10 = *(int64_t *)(arg1 + 0x158);
            iVar11 = (*piVar2 + *piVar3) * 0x40;
            puVar4 = (undefined4 *)(iVar11 + iVar10);
            *puVar4 = *(undefined4 *)arg2;
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x14);
            uVar6 = *(undefined4 *)(arg2 + 0x18);
            uVar7 = *(undefined4 *)(arg2 + 0x1c);
            puVar4 = (undefined4 *)(iVar11 + 0x10 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x10);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x24);
            uVar6 = *(undefined4 *)(arg2 + 0x28);
            uVar7 = *(undefined4 *)(arg2 + 0x2c);
            puVar4 = (undefined4 *)(iVar11 + 0x20 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x20);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x34);
            uVar6 = *(undefined4 *)(arg2 + 0x38);
            uVar7 = *(undefined4 *)(arg2 + 0x3c);
            puVar4 = (undefined4 *)(iVar11 + 0x30 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x30);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            *piVar2 = *piVar2 + 1;
        }
    }
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f34)(arg1 + 0x178);
    return;
}

// ============================================================
// Function: FUN_18018247b
// Address: 0x18018247b
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801823b0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)arg2 == 0) {
        *(int64_t *)arg2 = arg1;
    }
    if (*(int32_t *)(arg2 + 8) == 0) {
        *(undefined4 *)(arg2 + 8) = 0x400;
    }
    if (*(int64_t *)(arg2 + 0x10) == 0) {
        uVar9 = fcn.180174350();
        *(undefined8 *)(arg2 + 0x10) = uVar9;
    }
    (*(code *)0x699f1c)(arg1 + 0x178);
    if ((*(int32_t *)(arg1 + 0x154) != -1) || (iVar8 = fcn.1801820f0(arg1), iVar8 == 0)) {
        iVar8 = (*(code *)0x8000000000000013)((int64_t)*(int32_t *)(arg1 + 0x154), 0x18063e354, 1, 0);
        if (iVar8 < 1) {
            iVar10 = fcn.18045b9a8(0x1804a7440, 0x5c);
            uVar9 = fcn.1801723e0(var_20h);
            fcn.180172b00(uVar9, 4, 0x1804a7520, iVar10 + 1, 0x12f, 0x1804a7508);
        } else {
            piVar1 = (int64_t *)(arg1 + 0x168);
            piVar2 = (int64_t *)(arg1 + 0x160);
            piVar3 = (int64_t *)(arg1 + 0x170);
            if (*(int64_t *)(arg1 + 0x168) == 0) {
                *piVar3 = 0;
                *piVar2 = 0;
                *piVar1 = 0x10;
                uVar9 = fcn.1801813b0(0x400);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
            }
            iVar10 = *piVar1;
            iVar11 = *piVar2;
            if (iVar11 == iVar10) {
                iVar8 = (int32_t)iVar10 * 2;
                if (iVar8 == 0) {
                    iVar8 = 0x10;
                }
                uVar9 = func_0x000180181320(*(undefined8 *)(arg1 + 0x158), (int64_t)iVar8 << 6, iVar10 << 6);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
                *piVar1 = (int64_t)iVar8;
            } else if (*piVar3 + iVar11 == iVar10) {
                func_0x000180498030(*(int64_t *)(arg1 + 0x158), *piVar3 * 0x40 + *(int64_t *)(arg1 + 0x158), iVar11 << 6
                                   );
                *piVar3 = 0;
            }
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            iVar10 = *(int64_t *)(arg1 + 0x158);
            iVar11 = (*piVar2 + *piVar3) * 0x40;
            puVar4 = (undefined4 *)(iVar11 + iVar10);
            *puVar4 = *(undefined4 *)arg2;
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x14);
            uVar6 = *(undefined4 *)(arg2 + 0x18);
            uVar7 = *(undefined4 *)(arg2 + 0x1c);
            puVar4 = (undefined4 *)(iVar11 + 0x10 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x10);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x24);
            uVar6 = *(undefined4 *)(arg2 + 0x28);
            uVar7 = *(undefined4 *)(arg2 + 0x2c);
            puVar4 = (undefined4 *)(iVar11 + 0x20 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x20);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x34);
            uVar6 = *(undefined4 *)(arg2 + 0x38);
            uVar7 = *(undefined4 *)(arg2 + 0x3c);
            puVar4 = (undefined4 *)(iVar11 + 0x30 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x30);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            *piVar2 = *piVar2 + 1;
        }
    }
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f34)(arg1 + 0x178);
    return;
}

// ============================================================
// Function: FUN_18018257f
// Address: 0x18018257f
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801823b0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)arg2 == 0) {
        *(int64_t *)arg2 = arg1;
    }
    if (*(int32_t *)(arg2 + 8) == 0) {
        *(undefined4 *)(arg2 + 8) = 0x400;
    }
    if (*(int64_t *)(arg2 + 0x10) == 0) {
        uVar9 = fcn.180174350();
        *(undefined8 *)(arg2 + 0x10) = uVar9;
    }
    (*(code *)0x699f1c)(arg1 + 0x178);
    if ((*(int32_t *)(arg1 + 0x154) != -1) || (iVar8 = fcn.1801820f0(arg1), iVar8 == 0)) {
        iVar8 = (*(code *)0x8000000000000013)((int64_t)*(int32_t *)(arg1 + 0x154), 0x18063e354, 1, 0);
        if (iVar8 < 1) {
            iVar10 = fcn.18045b9a8(0x1804a7440, 0x5c);
            uVar9 = fcn.1801723e0(var_20h);
            fcn.180172b00(uVar9, 4, 0x1804a7520, iVar10 + 1, 0x12f, 0x1804a7508);
        } else {
            piVar1 = (int64_t *)(arg1 + 0x168);
            piVar2 = (int64_t *)(arg1 + 0x160);
            piVar3 = (int64_t *)(arg1 + 0x170);
            if (*(int64_t *)(arg1 + 0x168) == 0) {
                *piVar3 = 0;
                *piVar2 = 0;
                *piVar1 = 0x10;
                uVar9 = fcn.1801813b0(0x400);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
            }
            iVar10 = *piVar1;
            iVar11 = *piVar2;
            if (iVar11 == iVar10) {
                iVar8 = (int32_t)iVar10 * 2;
                if (iVar8 == 0) {
                    iVar8 = 0x10;
                }
                uVar9 = func_0x000180181320(*(undefined8 *)(arg1 + 0x158), (int64_t)iVar8 << 6, iVar10 << 6);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
                *piVar1 = (int64_t)iVar8;
            } else if (*piVar3 + iVar11 == iVar10) {
                func_0x000180498030(*(int64_t *)(arg1 + 0x158), *piVar3 * 0x40 + *(int64_t *)(arg1 + 0x158), iVar11 << 6
                                   );
                *piVar3 = 0;
            }
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            iVar10 = *(int64_t *)(arg1 + 0x158);
            iVar11 = (*piVar2 + *piVar3) * 0x40;
            puVar4 = (undefined4 *)(iVar11 + iVar10);
            *puVar4 = *(undefined4 *)arg2;
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x14);
            uVar6 = *(undefined4 *)(arg2 + 0x18);
            uVar7 = *(undefined4 *)(arg2 + 0x1c);
            puVar4 = (undefined4 *)(iVar11 + 0x10 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x10);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x24);
            uVar6 = *(undefined4 *)(arg2 + 0x28);
            uVar7 = *(undefined4 *)(arg2 + 0x2c);
            puVar4 = (undefined4 *)(iVar11 + 0x20 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x20);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x34);
            uVar6 = *(undefined4 *)(arg2 + 0x38);
            uVar7 = *(undefined4 *)(arg2 + 0x3c);
            puVar4 = (undefined4 *)(iVar11 + 0x30 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x30);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            *piVar2 = *piVar2 + 1;
        }
    }
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f34)(arg1 + 0x178);
    return;
}

// ============================================================
// Function: FUN_180182584
// Address: 0x180182584
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801823b0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(int64_t *)arg2 == 0) {
        *(int64_t *)arg2 = arg1;
    }
    if (*(int32_t *)(arg2 + 8) == 0) {
        *(undefined4 *)(arg2 + 8) = 0x400;
    }
    if (*(int64_t *)(arg2 + 0x10) == 0) {
        uVar9 = fcn.180174350();
        *(undefined8 *)(arg2 + 0x10) = uVar9;
    }
    (*(code *)0x699f1c)(arg1 + 0x178);
    if ((*(int32_t *)(arg1 + 0x154) != -1) || (iVar8 = fcn.1801820f0(arg1), iVar8 == 0)) {
        iVar8 = (*(code *)0x8000000000000013)((int64_t)*(int32_t *)(arg1 + 0x154), 0x18063e354, 1, 0);
        if (iVar8 < 1) {
            iVar10 = fcn.18045b9a8(0x1804a7440, 0x5c);
            uVar9 = fcn.1801723e0(var_20h);
            fcn.180172b00(uVar9, 4, 0x1804a7520, iVar10 + 1, 0x12f, 0x1804a7508);
        } else {
            piVar1 = (int64_t *)(arg1 + 0x168);
            piVar2 = (int64_t *)(arg1 + 0x160);
            piVar3 = (int64_t *)(arg1 + 0x170);
            if (*(int64_t *)(arg1 + 0x168) == 0) {
                *piVar3 = 0;
                *piVar2 = 0;
                *piVar1 = 0x10;
                uVar9 = fcn.1801813b0(0x400);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
            }
            iVar10 = *piVar1;
            iVar11 = *piVar2;
            if (iVar11 == iVar10) {
                iVar8 = (int32_t)iVar10 * 2;
                if (iVar8 == 0) {
                    iVar8 = 0x10;
                }
                uVar9 = func_0x000180181320(*(undefined8 *)(arg1 + 0x158), (int64_t)iVar8 << 6, iVar10 << 6);
                *(undefined8 *)(arg1 + 0x158) = uVar9;
                *piVar1 = (int64_t)iVar8;
            } else if (*piVar3 + iVar11 == iVar10) {
                func_0x000180498030(*(int64_t *)(arg1 + 0x158), *piVar3 * 0x40 + *(int64_t *)(arg1 + 0x158), iVar11 << 6
                                   );
                *piVar3 = 0;
            }
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            iVar10 = *(int64_t *)(arg1 + 0x158);
            iVar11 = (*piVar2 + *piVar3) * 0x40;
            puVar4 = (undefined4 *)(iVar11 + iVar10);
            *puVar4 = *(undefined4 *)arg2;
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x14);
            uVar6 = *(undefined4 *)(arg2 + 0x18);
            uVar7 = *(undefined4 *)(arg2 + 0x1c);
            puVar4 = (undefined4 *)(iVar11 + 0x10 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x10);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x24);
            uVar6 = *(undefined4 *)(arg2 + 0x28);
            uVar7 = *(undefined4 *)(arg2 + 0x2c);
            puVar4 = (undefined4 *)(iVar11 + 0x20 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x20);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            uVar5 = *(undefined4 *)(arg2 + 0x34);
            uVar6 = *(undefined4 *)(arg2 + 0x38);
            uVar7 = *(undefined4 *)(arg2 + 0x3c);
            puVar4 = (undefined4 *)(iVar11 + 0x30 + iVar10);
            *puVar4 = *(undefined4 *)(arg2 + 0x30);
            puVar4[1] = uVar5;
            puVar4[2] = uVar6;
            puVar4[3] = uVar7;
            *piVar2 = *piVar2 + 1;
        }
    }
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f34)(arg1 + 0x178);
    return;
}

// ============================================================
// Function: FUN_1801825a0
// Address: 0x1801825a0
// Size: 325 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.1801825a0(int64_t arg1, int64_t arg2)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    uVar12 = arg2 & 0xffffffff;
    if (*(int32_t *)(arg1 + 0x110) != 0) {
        func_0x000180182b20();
        iVar13 = (int64_t)((int32_t)arg2 * 1000);
        iVar10 = iVar13;
        if ((*(int64_t *)(arg1 + 0xe0) != 0) &&
           (iVar10 = *(int64_t *)(*(int64_t *)(arg1 + 0xe0) + -8) - *(int64_t *)(arg1 + 0x20), iVar13 < iVar10)) {
            iVar10 = iVar13;
        }
        iVar13 = iVar10;
        if ((*(int64_t *)(arg1 + 0xf8) != 0) &&
           (iVar13 = ((*(int64_t *)(*(int64_t *)(arg1 + 0xf8) + -8) + *(int64_t *)(arg1 + 8) * -1000) -
                     *(int64_t *)(arg1 + 0x20)) + *(int64_t *)(arg1 + 0x10), iVar10 < iVar13)) {
            iVar13 = iVar10;
        }
        if (iVar13 < 0) goto code_r0x0001801826de;
        uVar8 = (int32_t)(iVar13 / 1000) + 1;
        if ((int32_t)uVar8 < (int32_t)arg2) {
            uVar12 = (uint64_t)uVar8;
        }
    }
    if (*(int32_t *)(arg1 + 0x130) == 0) {
        (*(code *)0x699d32)(uVar12);
    } else {
        iVar9 = func_0x00018018a2b0(arg1, uVar12);
        if (iVar9 < 0) {
            iVar10 = fcn.18045b9a8(0x1804a7440, 0x5c);
            uVar11 = fcn.1801723e0(in_stack_ffffffffffffffe0);
            fcn.180172b00(uVar11, 1, 0x1804a74a8, -iVar9, iVar10 + 1, 0x68, 0x1804a7428);
        }
    }
    func_0x000180182b20(arg1);
    if (*(int32_t *)(arg1 + 4) == 0) {
        return 0;
    }
code_r0x0001801826de:
    if (*(int32_t *)(arg1 + 0x110) != 0) {
        iVar10 = *(int64_t *)(arg1 + 8);
        iVar13 = *(int64_t *)(arg1 + 0x20);
        iVar2 = *(int64_t *)(arg1 + 0x10);
        func_0x0001801814e0(arg1 + 0xe0, iVar13);
        func_0x0001801814e0(arg1 + 0xf8, (iVar10 * 1000 - iVar2) + iVar13);
    }
    if (*(int32_t *)(arg1 + 0x48) == 0) {
        if (*(int32_t *)(arg1 + 0xd8) != 0) {
            ppiVar3 = *(int64_t ***)(int64_t **)(arg1 + 200);
            while (ppiVar6 = ppiVar3, ppiVar6 != (int64_t **)(arg1 + 200)) {
                ppiVar1 = ppiVar6 + -9;
                ppiVar3 = (int64_t **)*ppiVar6;
                if (((*(int32_t *)(ppiVar6 + -1) != -1) &&
                    (iVar9 = *(int32_t *)(ppiVar6 + -1) + -1, *(int32_t *)(ppiVar6 + -1) = iVar9, iVar9 == 0)) &&
                   ((*(uint32_t *)((int64_t)ppiVar6 + -0xc) & 1) == 0)) {
                    *(uint32_t *)((int64_t)ppiVar6 + -0xc) = *(uint32_t *)((int64_t)ppiVar6 + -0xc) | 1;
                    ppiVar4 = (int64_t **)ppiVar6[1];
                    piVar5 = *ppiVar6;
                    piVar5[1] = (int64_t)ppiVar4;
                    *ppiVar4 = piVar5;
                    *(int32_t *)(*ppiVar1 + 0x1b) = *(int32_t *)(*ppiVar1 + 0x1b) + -1;
                }
                if ((*(uint32_t *)((int64_t)ppiVar6 + -0xc) & 4) == 0) {
                    *(uint32_t *)((int64_t)ppiVar6 + -0xc) = *(uint32_t *)((int64_t)ppiVar6 + -0xc) | 4;
                    *(int32_t *)(*ppiVar1 + 9) = *(int32_t *)(*ppiVar1 + 9) + 1;
                    ppiVar6[-3] = (int64_t *)(*ppiVar1)[(int64_t)*(int32_t *)(ppiVar6 + -2) + 0xf];
                    (*ppiVar1)[(int64_t)*(int32_t *)(ppiVar6 + -2) + 0xf] = (int64_t)ppiVar1;
                }
            }
        }
        if (*(int32_t *)(arg1 + 0x48) == 0) {
            return 0;
        }
    }
    iVar9 = 0;
    iVar10 = 10;
    do {
        piVar5 = *(int64_t **)(arg1 + 0x50 + iVar10 * 8);
        while (piVar7 = piVar5, piVar7 != (int64_t *)0x0) {
            piVar5 = (int64_t *)piVar7[6];
            if (((*(uint32_t *)((int64_t)piVar7 + 0x3c) & 4) != 0) && (*piVar7 == arg1)) {
                if (((*(uint32_t *)((int64_t)piVar7 + 0x3c) & 2) != 0) && ((code *)piVar7[3] != (code *)0x0)) {
                    (*(code *)piVar7[3])(piVar7);
                    iVar9 = iVar9 + 1;
                }
                *(uint32_t *)((int64_t)piVar7 + 0x3c) = *(uint32_t *)((int64_t)piVar7 + 0x3c) & 0xfffffffb;
                uVar8 = *(uint32_t *)((int64_t)piVar7 + 0x3c);
                if ((uVar8 & 1) != 0) {
                    if ((uVar8 & 2) != 0) {
                        *(uint32_t *)((int64_t)piVar7 + 0x3c) = uVar8 & 0xfffffffd;
                        *(int32_t *)(*piVar7 + 0x44) = *(int32_t *)(*piVar7 + 0x44) + -1;
                    }
                    if ((*(uint8_t *)((int64_t)piVar7 + 0x3c) & 4) == 0) {
                        fcn.180180fe0(piVar7);
                    }
                }
            }
        }
        *(undefined8 *)(arg1 + 0x50 + iVar10 * 8) = 0;
        iVar10 = iVar10 + -1;
    } while (iVar10 != -1);
    *(undefined4 *)(arg1 + 0x48) = 0;
    return iVar9;
}

// ============================================================
// Function: FUN_1801826e5
// Address: 0x1801826e5
// Size: 365 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.1801825a0(int64_t arg1, int64_t arg2)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    uVar12 = arg2 & 0xffffffff;
    if (*(int32_t *)(arg1 + 0x110) != 0) {
        func_0x000180182b20();
        iVar13 = (int64_t)((int32_t)arg2 * 1000);
        iVar10 = iVar13;
        if ((*(int64_t *)(arg1 + 0xe0) != 0) &&
           (iVar10 = *(int64_t *)(*(int64_t *)(arg1 + 0xe0) + -8) - *(int64_t *)(arg1 + 0x20), iVar13 < iVar10)) {
            iVar10 = iVar13;
        }
        iVar13 = iVar10;
        if ((*(int64_t *)(arg1 + 0xf8) != 0) &&
           (iVar13 = ((*(int64_t *)(*(int64_t *)(arg1 + 0xf8) + -8) + *(int64_t *)(arg1 + 8) * -1000) -
                     *(int64_t *)(arg1 + 0x20)) + *(int64_t *)(arg1 + 0x10), iVar10 < iVar13)) {
            iVar13 = iVar10;
        }
        if (iVar13 < 0) goto code_r0x0001801826de;
        uVar8 = (int32_t)(iVar13 / 1000) + 1;
        if ((int32_t)uVar8 < (int32_t)arg2) {
            uVar12 = (uint64_t)uVar8;
        }
    }
    if (*(int32_t *)(arg1 + 0x130) == 0) {
        (*(code *)0x699d32)(uVar12);
    } else {
        iVar9 = func_0x00018018a2b0(arg1, uVar12);
        if (iVar9 < 0) {
            iVar10 = fcn.18045b9a8(0x1804a7440, 0x5c);
            uVar11 = fcn.1801723e0(in_stack_ffffffffffffffe0);
            fcn.180172b00(uVar11, 1, 0x1804a74a8, -iVar9, iVar10 + 1, 0x68, 0x1804a7428);
        }
    }
    func_0x000180182b20(arg1);
    if (*(int32_t *)(arg1 + 4) == 0) {
        return 0;
    }
code_r0x0001801826de:
    if (*(int32_t *)(arg1 + 0x110) != 0) {
        iVar10 = *(int64_t *)(arg1 + 8);
        iVar13 = *(int64_t *)(arg1 + 0x20);
        iVar2 = *(int64_t *)(arg1 + 0x10);
        func_0x0001801814e0(arg1 + 0xe0, iVar13);
        func_0x0001801814e0(arg1 + 0xf8, (iVar10 * 1000 - iVar2) + iVar13);
    }
    if (*(int32_t *)(arg1 + 0x48) == 0) {
        if (*(int32_t *)(arg1 + 0xd8) != 0) {
            ppiVar3 = *(int64_t ***)(int64_t **)(arg1 + 200);
            while (ppiVar6 = ppiVar3, ppiVar6 != (int64_t **)(arg1 + 200)) {
                ppiVar1 = ppiVar6 + -9;
                ppiVar3 = (int64_t **)*ppiVar6;
                if (((*(int32_t *)(ppiVar6 + -1) != -1) &&
                    (iVar9 = *(int32_t *)(ppiVar6 + -1) + -1, *(int32_t *)(ppiVar6 + -1) = iVar9, iVar9 == 0)) &&
                   ((*(uint32_t *)((int64_t)ppiVar6 + -0xc) & 1) == 0)) {
                    *(uint32_t *)((int64_t)ppiVar6 + -0xc) = *(uint32_t *)((int64_t)ppiVar6 + -0xc) | 1;
                    ppiVar4 = (int64_t **)ppiVar6[1];
                    piVar5 = *ppiVar6;
                    piVar5[1] = (int64_t)ppiVar4;
                    *ppiVar4 = piVar5;
                    *(int32_t *)(*ppiVar1 + 0x1b) = *(int32_t *)(*ppiVar1 + 0x1b) + -1;
                }
                if ((*(uint32_t *)((int64_t)ppiVar6 + -0xc) & 4) == 0) {
                    *(uint32_t *)((int64_t)ppiVar6 + -0xc) = *(uint32_t *)((int64_t)ppiVar6 + -0xc) | 4;
                    *(int32_t *)(*ppiVar1 + 9) = *(int32_t *)(*ppiVar1 + 9) + 1;
                    ppiVar6[-3] = (int64_t *)(*ppiVar1)[(int64_t)*(int32_t *)(ppiVar6 + -2) + 0xf];
                    (*ppiVar1)[(int64_t)*(int32_t *)(ppiVar6 + -2) + 0xf] = (int64_t)ppiVar1;
                }
            }
        }
        if (*(int32_t *)(arg1 + 0x48) == 0) {
            return 0;
        }
    }
    iVar9 = 0;
    iVar10 = 10;
    do {
        piVar5 = *(int64_t **)(arg1 + 0x50 + iVar10 * 8);
        while (piVar7 = piVar5, piVar7 != (int64_t *)0x0) {
            piVar5 = (int64_t *)piVar7[6];
            if (((*(uint32_t *)((int64_t)piVar7 + 0x3c) & 4) != 0) && (*piVar7 == arg1)) {
                if (((*(uint32_t *)((int64_t)piVar7 + 0x3c) & 2) != 0) && ((code *)piVar7[3] != (code *)0x0)) {
                    (*(code *)piVar7[3])(piVar7);
                    iVar9 = iVar9 + 1;
                }
                *(uint32_t *)((int64_t)piVar7 + 0x3c) = *(uint32_t *)((int64_t)piVar7 + 0x3c) & 0xfffffffb;
                uVar8 = *(uint32_t *)((int64_t)piVar7 + 0x3c);
                if ((uVar8 & 1) != 0) {
                    if ((uVar8 & 2) != 0) {
                        *(uint32_t *)((int64_t)piVar7 + 0x3c) = uVar8 & 0xfffffffd;
                        *(int32_t *)(*piVar7 + 0x44) = *(int32_t *)(*piVar7 + 0x44) + -1;
                    }
                    if ((*(uint8_t *)((int64_t)piVar7 + 0x3c) & 4) == 0) {
                        fcn.180180fe0(piVar7);
                    }
                }
            }
        }
        *(undefined8 *)(arg1 + 0x50 + iVar10 * 8) = 0;
        iVar10 = iVar10 + -1;
    } while (iVar10 != -1);
    *(undefined4 *)(arg1 + 0x48) = 0;
    return iVar9;
}

// ============================================================
// Function: FUN_180182852
// Address: 0x180182852
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.1801825a0(int64_t arg1, int64_t arg2)
{
    int64_t **ppiVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t *piVar7;
    uint32_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    
    uVar12 = arg2 & 0xffffffff;
    if (*(int32_t *)(arg1 + 0x110) != 0) {
        func_0x000180182b20();
        iVar13 = (int64_t)((int32_t)arg2 * 1000);
        iVar10 = iVar13;
        if ((*(int64_t *)(arg1 + 0xe0) != 0) &&
           (iVar10 = *(int64_t *)(*(int64_t *)(arg1 + 0xe0) + -8) - *(int64_t *)(arg1 + 0x20), iVar13 < iVar10)) {
            iVar10 = iVar13;
        }
        iVar13 = iVar10;
        if ((*(int64_t *)(arg1 + 0xf8) != 0) &&
           (iVar13 = ((*(int64_t *)(*(int64_t *)(arg1 + 0xf8) + -8) + *(int64_t *)(arg1 + 8) * -1000) -
                     *(int64_t *)(arg1 + 0x20)) + *(int64_t *)(arg1 + 0x10), iVar10 < iVar13)) {
            iVar13 = iVar10;
        }
        if (iVar13 < 0) goto code_r0x0001801826de;
        uVar8 = (int32_t)(iVar13 / 1000) + 1;
        if ((int32_t)uVar8 < (int32_t)arg2) {
            uVar12 = (uint64_t)uVar8;
        }
    }
    if (*(int32_t *)(arg1 + 0x130) == 0) {
        (*(code *)0x699d32)(uVar12);
    } else {
        iVar9 = func_0x00018018a2b0(arg1, uVar12);
        if (iVar9 < 0) {
            iVar10 = fcn.18045b9a8(0x1804a7440, 0x5c);
            uVar11 = fcn.1801723e0(in_stack_ffffffffffffffe0);
            fcn.180172b00(uVar11, 1, 0x1804a74a8, -iVar9, iVar10 + 1, 0x68, 0x1804a7428);
        }
    }
    func_0x000180182b20(arg1);
    if (*(int32_t *)(arg1 + 4) == 0) {
        return 0;
    }
code_r0x0001801826de:
    if (*(int32_t *)(arg1 + 0x110) != 0) {
        iVar10 = *(int64_t *)(arg1 + 8);
        iVar13 = *(int64_t *)(arg1 + 0x20);
        iVar2 = *(int64_t *)(arg1 + 0x10);
        func_0x0001801814e0(arg1 + 0xe0, iVar13);
        func_0x0001801814e0(arg1 + 0xf8, (iVar10 * 1000 - iVar2) + iVar13);
    }
    if (*(int32_t *)(arg1 + 0x48) == 0) {
        if (*(int32_t *)(arg1 + 0xd8) != 0) {
            ppiVar3 = *(int64_t ***)(int64_t **)(arg1 + 200);
            while (ppiVar6 = ppiVar3, ppiVar6 != (int64_t **)(arg1 + 200)) {
                ppiVar1 = ppiVar6 + -9;
                ppiVar3 = (int64_t **)*ppiVar6;
                if (((*(int32_t *)(ppiVar6 + -1) != -1) &&
                    (iVar9 = *(int32_t *)(ppiVar6 + -1) + -1, *(int32_t *)(ppiVar6 + -1) = iVar9, iVar9 == 0)) &&
                   ((*(uint32_t *)((int64_t)ppiVar6 + -0xc) & 1) == 0)) {
                    *(uint32_t *)((int64_t)ppiVar6 + -0xc) = *(uint32_t *)((int64_t)ppiVar6 + -0xc) | 1;
                    ppiVar4 = (int64_t **)ppiVar6[1];
                    piVar5 = *ppiVar6;
                    piVar5[1] = (int64_t)ppiVar4;
                    *ppiVar4 = piVar5;
                    *(int32_t *)(*ppiVar1 + 0x1b) = *(int32_t *)(*ppiVar1 + 0x1b) + -1;
                }
                if ((*(uint32_t *)((int64_t)ppiVar6 + -0xc) & 4) == 0) {
                    *(uint32_t *)((int64_t)ppiVar6 + -0xc) = *(uint32_t *)((int64_t)ppiVar6 + -0xc) | 4;
                    *(int32_t *)(*ppiVar1 + 9) = *(int32_t *)(*ppiVar1 + 9) + 1;
                    ppiVar6[-3] = (int64_t *)(*ppiVar1)[(int64_t)*(int32_t *)(ppiVar6 + -2) + 0xf];
                    (*ppiVar1)[(int64_t)*(int32_t *)(ppiVar6 + -2) + 0xf] = (int64_t)ppiVar1;
                }
            }
        }
        if (*(int32_t *)(arg1 + 0x48) == 0) {
            return 0;
        }
    }
    iVar9 = 0;
    iVar10 = 10;
    do {
        piVar5 = *(int64_t **)(arg1 + 0x50 + iVar10 * 8);
        while (piVar7 = piVar5, piVar7 != (int64_t *)0x0) {
            piVar5 = (int64_t *)piVar7[6];
            if (((*(uint32_t *)((int64_t)piVar7 + 0x3c) & 4) != 0) && (*piVar7 == arg1)) {
                if (((*(uint32_t *)((int64_t)piVar7 + 0x3c) & 2) != 0) && ((code *)piVar7[3] != (code *)0x0)) {
                    (*(code *)piVar7[3])(piVar7);
                    iVar9 = iVar9 + 1;
                }
                *(uint32_t *)((int64_t)piVar7 + 0x3c) = *(uint32_t *)((int64_t)piVar7 + 0x3c) & 0xfffffffb;
                uVar8 = *(uint32_t *)((int64_t)piVar7 + 0x3c);
                if ((uVar8 & 1) != 0) {
                    if ((uVar8 & 2) != 0) {
                        *(uint32_t *)((int64_t)piVar7 + 0x3c) = uVar8 & 0xfffffffd;
                        *(int32_t *)(*piVar7 + 0x44) = *(int32_t *)(*piVar7 + 0x44) + -1;
                    }
                    if ((*(uint8_t *)((int64_t)piVar7 + 0x3c) & 4) == 0) {
                        fcn.180180fe0(piVar7);
                    }
                }
            }
        }
        *(undefined8 *)(arg1 + 0x50 + iVar10 * 8) = 0;
        iVar10 = iVar10 + -1;
    } while (iVar10 != -1);
    *(undefined4 *)(arg1 + 0x48) = 0;
    return iVar9;
}

// ============================================================
// Function: FUN_180182870
// Address: 0x180182870
// Size: 428 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.180182870(int64_t arg1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    if (arg1 == 0) {
        return 0xffffffff;
    }
    if (*(int32_t *)(arg1 + 4) == 1) {
        return 0xfffffffe;
    }
    *(undefined4 *)(arg1 + 4) = 1;
    uVar2 = (*(code *)0x699f74)();
    *(undefined4 *)(arg1 + 0x30) = uVar2;
    uVar2 = (*(code *)0x699ddc)();
    *(undefined4 *)(arg1 + 0x34) = uVar2;
    iVar3 = fcn.18045b9a8(0x1804a7440, 0x5c);
    uVar2 = *(undefined4 *)(arg1 + 0x34);
    uVar4 = fcn.1801723e0(in_stack_fffffffffffffff0);
    fcn.180172b00(uVar4, 1, 0x1804a75b8, uVar2, iVar3 + 1, 0x1c6);
    if (*(int32_t *)(arg1 + 0x40) == 0) {
        (*(code *)0x699f1c)(arg1 + 0x178);
        if (*(int32_t *)(arg1 + 0x154) == -1) {
            fcn.1801820f0(arg1);
        }
        (*(code *)0x699f34)(arg1 + 0x178);
    }
    iVar1 = *(int32_t *)(arg1 + 4);
    while (iVar1 != 0) {
        if (iVar1 == 2) {
            (*(code *)0x699d32)(10);
            fcn.180182b20(iVar3 + 1);
        } else {
            *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg1 + 0x28) + 1;
            if ((((*(uint8_t *)arg1 & 4) != 0) && (*(uint32_t *)(arg1 + 0x44) <= *(uint32_t *)(arg1 + 0x40))) ||
               (fcn.1801825a0(arg1, 100), (*(uint8_t *)arg1 & 1) != 0)) break;
        }
        iVar1 = *(int32_t *)(arg1 + 4);
    }
    *(undefined4 *)(arg1 + 4) = 0;
    uVar4 = fcn.180189210(0x1804a75a8);
    *(undefined8 *)(arg1 + 0x18) = uVar4;
    if (((*(uint8_t *)arg1 & 2) != 0) && (*(int32_t *)(arg1 + 4) != 3)) {
        *(undefined4 *)(arg1 + 4) = 3;
        iVar3 = fcn.18045b9a8(0x1804a7440, 0x5c);
        uVar2 = (*(code *)0x699ddc)();
        uVar4 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar4, 1, 0x1804a7588, uVar2, iVar3 + 1, 0x1b8, 0x1804a7578);
        fcn.180181e80(arg1);
        fcn.180180fe0(arg1);
    }
    return 0;
}

// ============================================================
// Function: FUN_180182a20
// Address: 0x180182a20
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.180182a20(int64_t arg1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg1 == 0) {
        return 0xffffffff;
    }
    if (*(int32_t *)(arg1 + 4) == 0) {
        return 0xfffffffe;
    }
    iVar4 = fcn.18045b9a8(0x1804a7440, 0x5c);
    uVar2 = (*(code *)0x699ddc)();
    uVar5 = fcn.1801723e0(in_stack_ffffffffffffffb0);
    fcn.180172b00(uVar5, 1, 0x1804a75e8, uVar2, iVar4 + 1, 0x1f9, 0x1804a75d8);
    iVar1 = *(int32_t *)(arg1 + 0x34);
    iVar3 = (*(code *)0x699ddc)();
    if (iVar3 != iVar1) {
        _var_48h = ZEXT816(0);
        _var_38h = ZEXT816(0);
        _var_28h = ZEXT816(0);
        _var_18h = ZEXT816(0);
        fcn.1801823b0(arg1, (int64_t)&var_48h);
    }
    *(undefined4 *)(arg1 + 4) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180182a53
// Address: 0x180182a53
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.180182a20(int64_t arg1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg1 == 0) {
        return 0xffffffff;
    }
    if (*(int32_t *)(arg1 + 4) == 0) {
        return 0xfffffffe;
    }
    iVar4 = fcn.18045b9a8(0x1804a7440, 0x5c);
    uVar2 = (*(code *)0x699ddc)();
    uVar5 = fcn.1801723e0(in_stack_ffffffffffffffb0);
    fcn.180172b00(uVar5, 1, 0x1804a75e8, uVar2, iVar4 + 1, 0x1f9, 0x1804a75d8);
    iVar1 = *(int32_t *)(arg1 + 0x34);
    iVar3 = (*(code *)0x699ddc)();
    if (iVar3 != iVar1) {
        _var_48h = ZEXT816(0);
        _var_38h = ZEXT816(0);
        _var_28h = ZEXT816(0);
        _var_18h = ZEXT816(0);
        fcn.1801823b0(arg1, (int64_t)&var_48h);
    }
    *(undefined4 *)(arg1 + 4) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180182ad2
// Address: 0x180182ad2
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.180182a20(int64_t arg1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg1 == 0) {
        return 0xffffffff;
    }
    if (*(int32_t *)(arg1 + 4) == 0) {
        return 0xfffffffe;
    }
    iVar4 = fcn.18045b9a8(0x1804a7440, 0x5c);
    uVar2 = (*(code *)0x699ddc)();
    uVar5 = fcn.1801723e0(in_stack_ffffffffffffffb0);
    fcn.180172b00(uVar5, 1, 0x1804a75e8, uVar2, iVar4 + 1, 0x1f9, 0x1804a75d8);
    iVar1 = *(int32_t *)(arg1 + 0x34);
    iVar3 = (*(code *)0x699ddc)();
    if (iVar3 != iVar1) {
        _var_48h = ZEXT816(0);
        _var_38h = ZEXT816(0);
        _var_28h = ZEXT816(0);
        _var_18h = ZEXT816(0);
        fcn.1801823b0(arg1, (int64_t)&var_48h);
    }
    *(undefined4 *)(arg1 + 4) = 0;
    return 0;
}

// ============================================================
// Function: FUN_180182b20
// Address: 0x180182b20
// Size: 210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180182b20(int64_t arg1, int64_t arg_28h)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    uint64_t arg_38h;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStackY_48 [32];
    int64_t var_28h;
    int64_t var_20h;
    
    arg_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_48;
    iVar3 = fcn.180189210(arg_38h);
    uVar7 = *(uint64_t *)(arg1 + 8);
    iVar6 = *(int64_t *)(arg1 + 0x10);
    *(int64_t *)(arg1 + 0x20) = iVar3;
    auVar1._8_8_ = 0;
    auVar1._0_8_ = uVar7;
    iVar5 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar1, 8);
    iVar4 = fcn.180467bd4(0);
    if ((uint64_t)(iVar3 - iVar6) / 1000000 + ((uVar7 - iVar5 >> 1) + iVar5 >> 9) != iVar4) {
        fcn.180473698(&var_28h);
        uVar7 = *(int64_t *)(arg1 + 0x20) - *(int64_t *)(arg1 + 0x10);
        auVar2._8_8_ = 0;
        auVar2._0_8_ = uVar7;
        iVar6 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar2, 8);
        *(uint64_t *)(arg1 + 8) =
             ((int64_t)(int32_t)var_28h * 1000 - ((uVar7 - iVar6 >> 1) + iVar6 >> 9)) + (uint64_t)(uint16_t)var_20h;
    }
    fcn.180459870(arg_38h ^ (uint64_t)auStackY_48);
    return;
}

// ============================================================
// Function: FUN_180182c00
// Address: 0x180182c00
// Size: 237 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.180182c00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined auVar1 [16];
    int64_t *piVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    
    uVar4 = (uint32_t)arg3;
    if (uVar4 == 0) {
        return (int64_t *)0x0;
    }
    piVar2 = (int64_t *)fcn.1801813b0(0x70);
    *(undefined4 *)(piVar2 + 1) = 0x10;
    *(undefined4 *)(piVar2 + 7) = 5;
    *(int32_t *)(piVar2 + 8) = (int32_t)arg4;
    *(uint32_t *)(piVar2 + 0xd) = uVar4;
    fcn.180182b20(arg1, in_stack_ffffffffffffffd8);
    uVar5 = (arg3 & 0xffffffffU) * 1000 + *(int64_t *)(arg1 + 0x20);
    piVar2[9] = uVar5;
    if ((999 < uVar4) && (uVar4 == (int32_t)((arg3 & 0xffffffffU) / 100) * 100)) {
        auVar1._8_8_ = 0;
        auVar1._0_8_ = uVar5;
        iVar3 = SUB168(ZEXT816(0x4f8b588e368f0847) * auVar1, 8);
        piVar2[9] = ((uVar5 - iVar3 >> 1) + iVar3 >> 0x10) * 100000;
    }
    fcn.180181860(arg1 + 0xe0, piVar2 + 10);
    *piVar2 = arg1;
    iVar3 = fcn.180174350();
    piVar2[2] = iVar3;
    piVar2[3] = arg2;
    if ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 2) == 0) {
        *(uint32_t *)((int64_t)piVar2 + 0x3c) = *(uint32_t *)((int64_t)piVar2 + 0x3c) | 2;
        *(int32_t *)(*piVar2 + 0x44) = *(int32_t *)(*piVar2 + 0x44) + 1;
    }
    *(int32_t *)(arg1 + 0x110) = *(int32_t *)(arg1 + 0x110) + 1;
    return piVar2;
}

// ============================================================
// Function: FUN_180182cf0
// Address: 0x180182cf0
// Size: 125 bytes
// ============================================================
void fcn.180182cf0(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    
    uVar1 = *(uint32_t *)(arg1 + 0x3c);
    if ((uVar1 & 2) == 0) {
        return;
    }
    if ((uVar1 & 1) != 0) goto code_r0x000180182d44;
    if (*(int32_t *)(arg1 + 8) == 0x10) {
        iVar2 = *(int64_t *)arg1 + 0xe0;
code_r0x000180182d2f:
        func_0x0001801819b0(iVar2, arg1 + 0x50);
    } else if (*(int32_t *)(arg1 + 8) == 0x20) {
        iVar2 = *(int64_t *)arg1 + 0xf8;
        goto code_r0x000180182d2f;
    }
    *(int32_t *)(*(int64_t *)arg1 + 0x110) = *(int32_t *)(*(int64_t *)arg1 + 0x110) + -1;
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 1;
    uVar1 = *(uint32_t *)(arg1 + 0x3c);
code_r0x000180182d44:
    if ((uVar1 & 2) != 0) {
        *(uint32_t *)(arg1 + 0x3c) = uVar1 & 0xfffffffd;
        *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + -1;
    }
    if ((*(uint8_t *)(arg1 + 0x3c) & 4) != 0) {
        return;
    }
    if (arg1 != 0) {
        fcn.180460d90();
        LOCK();
        *(int32_t *)0x18077e0f4 = *(int32_t *)0x18077e0f4 + 1;
        UNLOCK();
    }
    return;
}

// ============================================================
// Function: FUN_180182d70
// Address: 0x180182d70
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180182d70(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(int32_t *)(arg1 + 8) == 0x10) {
        iVar2 = *(int64_t *)arg1;
        if ((*(uint8_t *)(arg1 + 0x3c) & 1) == 0) {
            func_0x0001801819b0(iVar2 + 0xe0, arg1 + 0x50);
        } else {
            *(int32_t *)(iVar2 + 0x110) = *(int32_t *)(iVar2 + 0x110) + 1;
        }
        if (*(int32_t *)(arg1 + 0x40) == 0) {
            *(undefined4 *)(arg1 + 0x40) = 1;
        }
        if ((int32_t)arg2 != 0) {
            *(int32_t *)(arg1 + 0x68) = (int32_t)arg2;
        }
        uVar1 = *(uint32_t *)(arg1 + 0x68);
        uVar5 = (uint64_t)uVar1 * 1000 + *(int64_t *)(iVar2 + 0x20);
        *(uint64_t *)(arg1 + 0x48) = uVar5;
        if ((999 < uVar1) && (uVar1 == (uVar1 / 100) * 100)) {
            auVar3._8_8_ = 0;
            auVar3._0_8_ = uVar5;
            iVar4 = SUB168(ZEXT816(0x4f8b588e368f0847) * auVar3, 8);
            *(uint64_t *)(arg1 + 0x48) = ((uVar5 - iVar4 >> 1) + iVar4 >> 0x10) * 100000;
        }
        fcn.180181860(iVar2 + 0xe0, arg1 + 0x50);
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffe;
        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
        }
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffb;
    }
    return;
}

// ============================================================
// Function: FUN_180182d8d
// Address: 0x180182d8d
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180182d70(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(int32_t *)(arg1 + 8) == 0x10) {
        iVar2 = *(int64_t *)arg1;
        if ((*(uint8_t *)(arg1 + 0x3c) & 1) == 0) {
            func_0x0001801819b0(iVar2 + 0xe0, arg1 + 0x50);
        } else {
            *(int32_t *)(iVar2 + 0x110) = *(int32_t *)(iVar2 + 0x110) + 1;
        }
        if (*(int32_t *)(arg1 + 0x40) == 0) {
            *(undefined4 *)(arg1 + 0x40) = 1;
        }
        if ((int32_t)arg2 != 0) {
            *(int32_t *)(arg1 + 0x68) = (int32_t)arg2;
        }
        uVar1 = *(uint32_t *)(arg1 + 0x68);
        uVar5 = (uint64_t)uVar1 * 1000 + *(int64_t *)(iVar2 + 0x20);
        *(uint64_t *)(arg1 + 0x48) = uVar5;
        if ((999 < uVar1) && (uVar1 == (uVar1 / 100) * 100)) {
            auVar3._8_8_ = 0;
            auVar3._0_8_ = uVar5;
            iVar4 = SUB168(ZEXT816(0x4f8b588e368f0847) * auVar3, 8);
            *(uint64_t *)(arg1 + 0x48) = ((uVar5 - iVar4 >> 1) + iVar4 >> 0x10) * 100000;
        }
        fcn.180181860(iVar2 + 0xe0, arg1 + 0x50);
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffe;
        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
        }
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffb;
    }
    return;
}

// ============================================================
// Function: FUN_180182d92
// Address: 0x180182d92
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180182d70(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(int32_t *)(arg1 + 8) == 0x10) {
        iVar2 = *(int64_t *)arg1;
        if ((*(uint8_t *)(arg1 + 0x3c) & 1) == 0) {
            func_0x0001801819b0(iVar2 + 0xe0, arg1 + 0x50);
        } else {
            *(int32_t *)(iVar2 + 0x110) = *(int32_t *)(iVar2 + 0x110) + 1;
        }
        if (*(int32_t *)(arg1 + 0x40) == 0) {
            *(undefined4 *)(arg1 + 0x40) = 1;
        }
        if ((int32_t)arg2 != 0) {
            *(int32_t *)(arg1 + 0x68) = (int32_t)arg2;
        }
        uVar1 = *(uint32_t *)(arg1 + 0x68);
        uVar5 = (uint64_t)uVar1 * 1000 + *(int64_t *)(iVar2 + 0x20);
        *(uint64_t *)(arg1 + 0x48) = uVar5;
        if ((999 < uVar1) && (uVar1 == (uVar1 / 100) * 100)) {
            auVar3._8_8_ = 0;
            auVar3._0_8_ = uVar5;
            iVar4 = SUB168(ZEXT816(0x4f8b588e368f0847) * auVar3, 8);
            *(uint64_t *)(arg1 + 0x48) = ((uVar5 - iVar4 >> 1) + iVar4 >> 0x10) * 100000;
        }
        fcn.180181860(iVar2 + 0xe0, arg1 + 0x50);
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffe;
        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
        }
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffb;
    }
    return;
}

// ============================================================
// Function: FUN_180182df1
// Address: 0x180182df1
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180182d70(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(int32_t *)(arg1 + 8) == 0x10) {
        iVar2 = *(int64_t *)arg1;
        if ((*(uint8_t *)(arg1 + 0x3c) & 1) == 0) {
            func_0x0001801819b0(iVar2 + 0xe0, arg1 + 0x50);
        } else {
            *(int32_t *)(iVar2 + 0x110) = *(int32_t *)(iVar2 + 0x110) + 1;
        }
        if (*(int32_t *)(arg1 + 0x40) == 0) {
            *(undefined4 *)(arg1 + 0x40) = 1;
        }
        if ((int32_t)arg2 != 0) {
            *(int32_t *)(arg1 + 0x68) = (int32_t)arg2;
        }
        uVar1 = *(uint32_t *)(arg1 + 0x68);
        uVar5 = (uint64_t)uVar1 * 1000 + *(int64_t *)(iVar2 + 0x20);
        *(uint64_t *)(arg1 + 0x48) = uVar5;
        if ((999 < uVar1) && (uVar1 == (uVar1 / 100) * 100)) {
            auVar3._8_8_ = 0;
            auVar3._0_8_ = uVar5;
            iVar4 = SUB168(ZEXT816(0x4f8b588e368f0847) * auVar3, 8);
            *(uint64_t *)(arg1 + 0x48) = ((uVar5 - iVar4 >> 1) + iVar4 >> 0x10) * 100000;
        }
        fcn.180181860(iVar2 + 0xe0, arg1 + 0x50);
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffe;
        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
        }
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffb;
    }
    return;
}

// ============================================================
// Function: FUN_180182e4a
// Address: 0x180182e4a
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180182d70(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(int32_t *)(arg1 + 8) == 0x10) {
        iVar2 = *(int64_t *)arg1;
        if ((*(uint8_t *)(arg1 + 0x3c) & 1) == 0) {
            func_0x0001801819b0(iVar2 + 0xe0, arg1 + 0x50);
        } else {
            *(int32_t *)(iVar2 + 0x110) = *(int32_t *)(iVar2 + 0x110) + 1;
        }
        if (*(int32_t *)(arg1 + 0x40) == 0) {
            *(undefined4 *)(arg1 + 0x40) = 1;
        }
        if ((int32_t)arg2 != 0) {
            *(int32_t *)(arg1 + 0x68) = (int32_t)arg2;
        }
        uVar1 = *(uint32_t *)(arg1 + 0x68);
        uVar5 = (uint64_t)uVar1 * 1000 + *(int64_t *)(iVar2 + 0x20);
        *(uint64_t *)(arg1 + 0x48) = uVar5;
        if ((999 < uVar1) && (uVar1 == (uVar1 / 100) * 100)) {
            auVar3._8_8_ = 0;
            auVar3._0_8_ = uVar5;
            iVar4 = SUB168(ZEXT816(0x4f8b588e368f0847) * auVar3, 8);
            *(uint64_t *)(arg1 + 0x48) = ((uVar5 - iVar4 >> 1) + iVar4 >> 0x10) * 100000;
        }
        fcn.180181860(iVar2 + 0xe0, arg1 + 0x50);
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffe;
        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
        }
        *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffb;
    }
    return;
}

// ============================================================
// Function: FUN_180182e80
// Address: 0x180182e80
// Size: 26 bytes
// ============================================================
int64_t fcn.180182e80(int64_t arg1)
{
    undefined4 uVar1;
    
    uVar1 = (*(code *)0x699f8a)();
    *(undefined4 *)arg1 = uVar1;
    return arg1;
}

// ============================================================
// Function: FUN_180182ed0
// Address: 0x180182ed0
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180182ed0(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000040;
    int64_t in_stack_00000068;
    int64_t in_stack_00000080;
    int64_t in_stack_000000d0;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.180193020(var_28h, var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, 
                          in_stack_00000028, in_stack_00000030, in_stack_00000040, arg_58h, in_stack_00000068, 
                          in_stack_00000080, in_stack_000000d0);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7718, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x79), 0x1804a7698);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a7740, uVar7, iVar5 + 1, 0x7c, 0x1804a7698);
    return iVar3;
}

// ============================================================
// Function: FUN_180182eed
// Address: 0x180182eed
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180182ed0(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000040;
    int64_t in_stack_00000068;
    int64_t in_stack_00000080;
    int64_t in_stack_000000d0;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.180193020(var_28h, var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, 
                          in_stack_00000028, in_stack_00000030, in_stack_00000040, arg_58h, in_stack_00000068, 
                          in_stack_00000080, in_stack_000000d0);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7718, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x79), 0x1804a7698);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a7740, uVar7, iVar5 + 1, 0x7c, 0x1804a7698);
    return iVar3;
}

// ============================================================
// Function: FUN_180182f11
// Address: 0x180182f11
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180182ed0(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000040;
    int64_t in_stack_00000068;
    int64_t in_stack_00000080;
    int64_t in_stack_000000d0;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.180193020(var_28h, var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, 
                          in_stack_00000028, in_stack_00000030, in_stack_00000040, arg_58h, in_stack_00000068, 
                          in_stack_00000080, in_stack_000000d0);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7718, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x79), 0x1804a7698);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a7740, uVar7, iVar5 + 1, 0x7c, 0x1804a7698);
    return iVar3;
}

// ============================================================
// Function: FUN_180182f26
// Address: 0x180182f26
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180182ed0(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000040;
    int64_t in_stack_00000068;
    int64_t in_stack_00000080;
    int64_t in_stack_000000d0;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.180193020(var_28h, var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, 
                          in_stack_00000028, in_stack_00000030, in_stack_00000040, arg_58h, in_stack_00000068, 
                          in_stack_00000080, in_stack_000000d0);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7718, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x79), 0x1804a7698);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a7740, uVar7, iVar5 + 1, 0x7c, 0x1804a7698);
    return iVar3;
}

// ============================================================
// Function: FUN_180182fb3
// Address: 0x180182fb3
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180182ed0(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000040;
    int64_t in_stack_00000068;
    int64_t in_stack_00000080;
    int64_t in_stack_000000d0;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.180193020(var_28h, var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, 
                          in_stack_00000028, in_stack_00000030, in_stack_00000040, arg_58h, in_stack_00000068, 
                          in_stack_00000080, in_stack_000000d0);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7718, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x79), 0x1804a7698);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a7740, uVar7, iVar5 + 1, 0x7c, 0x1804a7698);
    return iVar3;
}

// ============================================================
// Function: FUN_180183020
// Address: 0x180183020
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180183020(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.1801932d0(var_28h, unaff_retaddr);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7770, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x8d), 0x1804a7760);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a77a0, uVar7, iVar5 + 1, 0x90, 0x1804a7760);
    return iVar3;
}

// ============================================================
// Function: FUN_18018303d
// Address: 0x18018303d
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180183020(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.1801932d0(var_28h, unaff_retaddr);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7770, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x8d), 0x1804a7760);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a77a0, uVar7, iVar5 + 1, 0x90, 0x1804a7760);
    return iVar3;
}

// ============================================================
// Function: FUN_180183061
// Address: 0x180183061
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180183020(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.1801932d0(var_28h, unaff_retaddr);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7770, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x8d), 0x1804a7760);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a77a0, uVar7, iVar5 + 1, 0x90, 0x1804a7760);
    return iVar3;
}

// ============================================================
// Function: FUN_180183076
// Address: 0x180183076
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180183020(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.1801932d0(var_28h, unaff_retaddr);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7770, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x8d), 0x1804a7760);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a77a0, uVar7, iVar5 + 1, 0x90, 0x1804a7760);
    return iVar3;
}

// ============================================================
// Function: FUN_180183103
// Address: 0x180183103
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

int32_t fcn.180183020(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    
    iVar3 = fcn.1801932d0(var_28h, unaff_retaddr);
    if (iVar3 == 1) {
        return 0;
    }
    iVar3 = fcn.180193b00(var_20h, in_stack_ffffffffffffffe8, var_10h, unaff_RBX, unaff_retaddr, unaff_RBP, 
                          in_stack_00000010, var_18h);
    uVar4 = (undefined4)((uint64_t)in_stack_ffffffffffffffe8 >> 0x20);
    if (iVar3 == 2) {
        return -2;
    }
    if (iVar3 == 3) {
        return -3;
    }
    if (iVar3 == 5) {
        iVar5 = fcn.18045b9a8(0x1804a76b0);
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar1 = *puVar6;
        puVar6 = (undefined4 *)fcn.18046b77c();
        uVar2 = *puVar6;
        uVar7 = fcn.1804736a0(uVar1);
        uVar8 = fcn.1801723e0(var_10h);
        fcn.180172b00(uVar8, 4, 0x1804a7770, uVar2, uVar7, iVar5 + 1, CONCAT44(uVar4, 0x8d), 0x1804a7760);
        return 5;
    }
    iVar5 = fcn.18045b9a8(0x1804a76b0, 0x5c);
    uVar4 = fcn.180220550(var_28h);
    uVar7 = fcn.1802204e0(uVar4, 0);
    uVar8 = fcn.1801723e0(var_10h);
    fcn.180172b00(uVar8, 4, 0x1804a77a0, uVar7, iVar5 + 1, 0x90, 0x1804a7760);
    return iVar3;
}

// ============================================================
// Function: FUN_180183180
// Address: 0x180183180
// Size: 433 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180183180(int64_t arg1)
{
    char *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    char *pcVar7;
    char *pcVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(int32_t *)0x18077e150 == 0) {
        func_0x00018019a3b0(0x200002, 0);
        *(int32_t *)0x18077e150 = 1;
    }
    uVar4 = func_0x00018019a2d0();
    iVar5 = func_0x000180192520(uVar4);
    if (iVar5 == 0) {
        return 0;
    }
    uVar4 = 0;
    if (arg1 == 0) {
code_r0x0001801832dd:
        uVar3 = func_0x000180191a20(iVar5, 0x21, 0, 0);
        func_0x000180191a20(iVar5, 0x21, uVar3 | 2, 0);
        func_0x000180192fc0(iVar5, uVar4, 0);
    } else {
        pcVar1 = *(char **)(arg1 + 0x10);
        pcVar7 = (char *)0x0;
        if ((pcVar1 != (char *)0x0) && (*pcVar1 != '\0')) {
            pcVar7 = pcVar1;
        }
        pcVar1 = *(char **)(arg1 + 0x18);
        pcVar8 = (char *)0x0;
        if ((pcVar1 != (char *)0x0) && (*pcVar1 != '\0')) {
            pcVar8 = pcVar1;
        }
        if ((pcVar7 == (char *)0x0) && (pcVar8 == (char *)0x0)) {
code_r0x000180183230:
            if ((*(char **)arg1 != (char *)0x0) && (**(char **)arg1 != '\0')) {
                iVar2 = func_0x000180198d30(iVar5);
                if (iVar2 == 0) {
                    uVar4 = 0x1804a7648;
                    goto code_r0x00018018328e;
                }
            }
            pcVar1 = *(char **)(arg1 + 8);
            if ((pcVar1 == (char *)0x0) || (*pcVar1 == '\0')) {
code_r0x0001801832af:
                if (*(int16_t *)(arg1 + 0x20) != 0) {
                    if (*(int16_t *)(arg1 + 0x22) == 0) {
                        uVar4 = 3;
                    } else {
                        uVar4 = 1;
                        if ((pcVar7 == (char *)0x0) && (pcVar8 == (char *)0x0)) {
                            func_0x000180192f40(iVar5);
                        }
                    }
                }
                goto code_r0x0001801832dd;
            }
            iVar2 = func_0x000180198a80(iVar5, pcVar1, 1);
            if (iVar2 == 0) {
                uVar4 = 0x1804a7660;
            } else {
                iVar2 = func_0x000180191960(iVar5);
                if (iVar2 != 0) goto code_r0x0001801832af;
                uVar4 = 0x1804a7678;
            }
        } else {
            iVar2 = func_0x0001801924a0(iVar5, pcVar7, pcVar8);
            if (iVar2 != 0) goto code_r0x000180183230;
            uVar4 = 0x1804a7628;
        }
code_r0x00018018328e:
        uVar6 = fcn.1804605f8(2);
        fcn.180094530(uVar6, uVar4);
        func_0x000180191f00(iVar5);
        iVar5 = 0;
    }
    return iVar5;
}

// ============================================================
// Function: FUN_180183350
// Address: 0x180183350
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180183350(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t unaff_RDI;
    int64_t unaff_retaddr;
    int64_t var_8h;
    
    iVar1 = fcn.180194050();
    if (iVar1 == 0) {
        return 0;
    }
    fcn.1801949d0(unaff_RDI, unaff_retaddr);
    return iVar1;
}

// ============================================================
// Function: FUN_1801833a0
// Address: 0x1801833a0
// Size: 27 bytes
// ============================================================
undefined8 fcn.1801833a0(undefined8 placeholder_0, int64_t arg2)
{
    fcn.180193380(placeholder_0, 0x37, 0, arg2);
    return 0;
}

// ============================================================
// Function: FUN_1801833d0
// Address: 0x1801833d0
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801833d0(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStackY_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    undefined auStack_48 [16];
    undefined auStack_38 [16];
    undefined auStack_28 [16];
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    iVar1 = *(int64_t *)(arg1 + 0x28);
    if (iVar1 != 0) {
        _var_58h = ZEXT816(0);
        auStack_48 = ZEXT816(0);
        auStack_38 = ZEXT816(0);
        auStack_28 = ZEXT816(0);
        _var_98h = ZEXT816(0);
        _var_88h = ZEXT816(0);
        _var_78h = ZEXT816(0);
        _var_68h = ZEXT816(0);
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar4 = *(undefined8 *)(iVar1 + 0x58);
        iVar3 = fcn.180184cd0(*(undefined8 *)(iVar1 + 0x60), &var_98h, 0x40);
        uVar4 = fcn.180184cd0(uVar4, &var_58h, 0x40);
        uVar5 = fcn.1801723e0(var_a0h);
        var_a0h = 0x1804a7870;
        var_a8h._0_4_ = 0x1e;
        var_b8h = iVar3;
        var_b0h = iVar2 + 1;
        fcn.180172b00(uVar5, 3, 0x1804a7888, uVar4);
        *(undefined4 *)(iVar1 + 0x4c) = 0x8a;
        fcn.180183710(iVar1);
    }
    fcn.180459870(var_18h ^ (uint64_t)auStackY_d8);
    return;
}

// ============================================================
// Function: FUN_1801833fd
// Address: 0x1801833fd
// Size: 225 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801833d0(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStackY_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    undefined auStack_48 [16];
    undefined auStack_38 [16];
    undefined auStack_28 [16];
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    iVar1 = *(int64_t *)(arg1 + 0x28);
    if (iVar1 != 0) {
        _var_58h = ZEXT816(0);
        auStack_48 = ZEXT816(0);
        auStack_38 = ZEXT816(0);
        auStack_28 = ZEXT816(0);
        _var_98h = ZEXT816(0);
        _var_88h = ZEXT816(0);
        _var_78h = ZEXT816(0);
        _var_68h = ZEXT816(0);
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar4 = *(undefined8 *)(iVar1 + 0x58);
        iVar3 = fcn.180184cd0(*(undefined8 *)(iVar1 + 0x60), &var_98h, 0x40);
        uVar4 = fcn.180184cd0(uVar4, &var_58h, 0x40);
        uVar5 = fcn.1801723e0(var_a0h);
        var_a0h = 0x1804a7870;
        var_a8h._0_4_ = 0x1e;
        var_b8h = iVar3;
        var_b0h = iVar2 + 1;
        fcn.180172b00(uVar5, 3, 0x1804a7888, uVar4);
        *(undefined4 *)(iVar1 + 0x4c) = 0x8a;
        fcn.180183710(iVar1);
    }
    fcn.180459870(var_18h ^ (uint64_t)auStackY_d8);
    return;
}

// ============================================================
// Function: FUN_1801834de
// Address: 0x1801834de
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801833d0(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStackY_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    undefined auStack_48 [16];
    undefined auStack_38 [16];
    undefined auStack_28 [16];
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    iVar1 = *(int64_t *)(arg1 + 0x28);
    if (iVar1 != 0) {
        _var_58h = ZEXT816(0);
        auStack_48 = ZEXT816(0);
        auStack_38 = ZEXT816(0);
        auStack_28 = ZEXT816(0);
        _var_98h = ZEXT816(0);
        _var_88h = ZEXT816(0);
        _var_78h = ZEXT816(0);
        _var_68h = ZEXT816(0);
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar4 = *(undefined8 *)(iVar1 + 0x58);
        iVar3 = fcn.180184cd0(*(undefined8 *)(iVar1 + 0x60), &var_98h, 0x40);
        uVar4 = fcn.180184cd0(uVar4, &var_58h, 0x40);
        uVar5 = fcn.1801723e0(var_a0h);
        var_a0h = 0x1804a7870;
        var_a8h._0_4_ = 0x1e;
        var_b8h = iVar3;
        var_b0h = iVar2 + 1;
        fcn.180172b00(uVar5, 3, 0x1804a7888, uVar4);
        *(undefined4 *)(iVar1 + 0x4c) = 0x8a;
        fcn.180183710(iVar1);
    }
    fcn.180459870(var_18h ^ (uint64_t)auStackY_d8);
    return;
}

// ============================================================
// Function: FUN_180183500
// Address: 0x180183500
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180183500(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStackY_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    undefined auStack_48 [16];
    undefined auStack_38 [16];
    undefined auStack_28 [16];
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    iVar1 = *(int64_t *)(arg1 + 0x28);
    if (iVar1 != 0) {
        _var_58h = ZEXT816(0);
        auStack_48 = ZEXT816(0);
        auStack_38 = ZEXT816(0);
        auStack_28 = ZEXT816(0);
        _var_98h = ZEXT816(0);
        _var_88h = ZEXT816(0);
        _var_78h = ZEXT816(0);
        _var_68h = ZEXT816(0);
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar4 = *(undefined8 *)(iVar1 + 0x58);
        iVar3 = fcn.180184cd0(*(undefined8 *)(iVar1 + 0x60), &var_98h, 0x40);
        uVar4 = fcn.180184cd0(uVar4, &var_58h, 0x40);
        uVar5 = fcn.1801723e0(var_a0h);
        var_a0h = 0x1804a77c0;
        var_a8h._0_4_ = 0x11;
        var_b8h = iVar3;
        var_b0h = iVar2 + 1;
        fcn.180172b00(uVar5, 3, 0x1804a7840, uVar4);
        *(undefined4 *)(iVar1 + 0x4c) = 0x8a;
        fcn.180183710(iVar1);
    }
    fcn.180459870(var_18h ^ (uint64_t)auStackY_d8);
    return;
}

// ============================================================
// Function: FUN_18018352d
// Address: 0x18018352d
// Size: 225 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180183500(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStackY_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    undefined auStack_48 [16];
    undefined auStack_38 [16];
    undefined auStack_28 [16];
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    iVar1 = *(int64_t *)(arg1 + 0x28);
    if (iVar1 != 0) {
        _var_58h = ZEXT816(0);
        auStack_48 = ZEXT816(0);
        auStack_38 = ZEXT816(0);
        auStack_28 = ZEXT816(0);
        _var_98h = ZEXT816(0);
        _var_88h = ZEXT816(0);
        _var_78h = ZEXT816(0);
        _var_68h = ZEXT816(0);
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar4 = *(undefined8 *)(iVar1 + 0x58);
        iVar3 = fcn.180184cd0(*(undefined8 *)(iVar1 + 0x60), &var_98h, 0x40);
        uVar4 = fcn.180184cd0(uVar4, &var_58h, 0x40);
        uVar5 = fcn.1801723e0(var_a0h);
        var_a0h = 0x1804a77c0;
        var_a8h._0_4_ = 0x11;
        var_b8h = iVar3;
        var_b0h = iVar2 + 1;
        fcn.180172b00(uVar5, 3, 0x1804a7840, uVar4);
        *(undefined4 *)(iVar1 + 0x4c) = 0x8a;
        fcn.180183710(iVar1);
    }
    fcn.180459870(var_18h ^ (uint64_t)auStackY_d8);
    return;
}

// ============================================================
// Function: FUN_18018360e
// Address: 0x18018360e
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180183500(int64_t arg1, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStackY_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    undefined auStack_48 [16];
    undefined auStack_38 [16];
    undefined auStack_28 [16];
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    iVar1 = *(int64_t *)(arg1 + 0x28);
    if (iVar1 != 0) {
        _var_58h = ZEXT816(0);
        auStack_48 = ZEXT816(0);
        auStack_38 = ZEXT816(0);
        auStack_28 = ZEXT816(0);
        _var_98h = ZEXT816(0);
        _var_88h = ZEXT816(0);
        _var_78h = ZEXT816(0);
        _var_68h = ZEXT816(0);
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar4 = *(undefined8 *)(iVar1 + 0x58);
        iVar3 = fcn.180184cd0(*(undefined8 *)(iVar1 + 0x60), &var_98h, 0x40);
        uVar4 = fcn.180184cd0(uVar4, &var_58h, 0x40);
        uVar5 = fcn.1801723e0(var_a0h);
        var_a0h = 0x1804a77c0;
        var_a8h._0_4_ = 0x11;
        var_b8h = iVar3;
        var_b0h = iVar2 + 1;
        fcn.180172b00(uVar5, 3, 0x1804a7840, uVar4);
        *(undefined4 *)(iVar1 + 0x4c) = 0x8a;
        fcn.180183710(iVar1);
    }
    fcn.180459870(var_18h ^ (uint64_t)auStackY_d8);
    return;
}

// ============================================================
// Function: FUN_180183630
// Address: 0x180183630
// Size: 209 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Removing unreachable block (ram,0x000180475d6e)
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

uint64_t fcn.180183630(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined8 unaff_RSI;
    char cVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_18h;
    char cVar6;
    
    iVar1 = *(int32_t *)(arg1 + 0x40);
    if (((iVar1 == 0x100) || (iVar1 == 0x1000)) || (iVar1 == 0x2000)) {
        if (arg4 == 0) {
            arg4 = *(int64_t *)(arg1 + 0x60);
        }
        var_30h._0_4_ = func_0x000180184b50(arg4);
        var_38h = arg4;
        uVar3 = (*(code *)0x8000000000000014)((int64_t)*(int32_t *)(arg1 + 0x48), arg2, arg3 & 0xffffffff, 0);
        if (*(int16_t *)(*(int64_t *)(arg1 + 0x58) + 2) == 0) {
            var_8h = CONCAT44(var_8h._4_4_, 0x1c);
            (*(code *)0x8000000000000006)((int64_t)*(int32_t *)(arg1 + 0x48), *(int64_t *)(arg1 + 0x58), &var_8h);
            uVar3 = uVar3 & 0xffffffff;
        }
        return uVar3;
    }
    if (iVar1 == 0x100000) {
    // WARNING: Treating indirect jump as call
        uVar3 = (*(code *)0x8000000000000013)((int64_t)*(int32_t *)(arg1 + 0x48), arg2, arg3, 0);
        return uVar3;
    }
    if (iVar1 == 0x1000000) {
        iVar4 = fcn.18045a350(*(undefined8 *)(arg1 + 0x180));
        iVar4 = -iVar4;
        if (-1 < (int32_t)arg3) {
            *(int64_t *)((int64_t)&var_20h + iVar4) = (int64_t)&arg_58h + iVar4;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x180194ff0;
            uVar2 = func_0x000180198780();
            if (0 < (int32_t)uVar2) {
                uVar2 = *(uint32_t *)((int64_t)&arg_58h + iVar4);
            }
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x180194fa7;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x180194fbf;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0x180194fd1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar4));
        return 0xffffffff;
    }
    var_48h = 0;
    cVar5 = *(int32_t *)0x180781924 == 0;
    var_38h = var_38h & 0xffffffffffffff00;
    cVar6 = '\0';
    if ((bool)cVar5) {
        var_30h._0_4_ = *(undefined4 *)0x1806a3e28;
        var_30h._4_4_ = *(undefined4 *)0x1806a3e2c;
        uStack_28 = *(undefined4 *)0x1806a3e30;
        uStack_24 = *(undefined4 *)0x1806a3e34;
    }
    uVar2 = func_0x000180475da4(*(undefined4 *)(arg1 + 0x48), arg2, arg3, &var_48h);
    if (cVar5 == '\x02') {
        *(uint32_t *)(var_48h + 0x3a8) = *(uint32_t *)(var_48h + 0x3a8) & 0xfffffffd;
    }
    if (cVar6 != '\0') {
        var_18h._4_4_ = (undefined4)((uint64_t)unaff_RSI >> 0x20);
        iVar4 = func_0x00018045f958(&var_48h);
        *(undefined4 *)(iVar4 + 0x24) = var_18h._4_4_;
    }
    return (uint64_t)uVar2;
}

// ============================================================
// Function: FUN_180183710
// Address: 0x180183710
// Size: 520 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.180183710(int64_t arg1)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t unaff_RBX;
    uint64_t arg3;
    int64_t unaff_retaddr;
    int64_t var_8h;
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t iStack_28;
    uint64_t uStack_20;
    int64_t var_18h;
    int64_t var_10h;
    
    if ((*(uint32_t *)(arg1 + 0x3c) & 0x20) == 0) {
        if ((*(uint32_t *)(arg1 + 0x3c) & 1) == 0) {
            iVar1 = *(int32_t *)(*(int64_t *)arg1 + 0x34);
            uStack_40 = 0x180183738;
            iVar3 = (*(code *)0x699ddc)();
            if (iVar3 != iVar1) {
                uStack_48 = 0;
                uStack_40 = 0;
                uStack_38 = 0;
                _var_18h = ZEXT816(0);
                uStack_30 = 0x180181d50;
                uStack_20 = (uint64_t)*(uint32_t *)(arg1 + 0x44);
                iStack_28 = arg1;
                fcn.1801823b0(*(int64_t *)arg1, (int64_t)&uStack_48);
                return 0;
            }
        }
        uStack_40 = 0x18018375b;
        (*(code *)0x699f1c)(arg1 + 200);
        uVar2 = *(uint32_t *)(arg1 + 0x3c);
        if ((uVar2 & 0x20) != 0) {
            uStack_40 = 0x18018376f;
            (*(code *)0x699f34)(arg1 + 200);
            return 0;
        }
        if (((*(int64_t *)(arg1 + 0xb0) != 0) && (*(int32_t *)(arg1 + 0x4c) == 0)) && ((uVar2 & 0x2001) == 0)) {
            *(uint32_t *)(arg1 + 0x3c) = uVar2 | 0x2000;
            uStack_40 = 0x1801837b3;
            (*(code *)0x699f34)(arg1 + 200);
            uStack_40 = 0x1801837c4;
            iVar4 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uStack_40 = 0x1801837cd;
            uVar5 = fcn.1801723e0(unaff_retaddr);
            var_10h = 0x1804a7af8;
            var_18h._0_4_ = 0x25f;
            uStack_40 = 0x1801837f8;
            fcn.180172b00(uVar5, 3, 0x1804a7b08, iVar4 + 1);
            arg3 = 60000;
            if (*(uint32_t *)(arg1 + 0x124) != 0) {
                arg3 = (uint64_t)*(uint32_t *)(arg1 + 0x124);
            }
            uStack_40 = 0x18018381f;
            iVar4 = fcn.180182c00(*(int64_t *)arg1, 0x1801833d0, arg3, 1);
            *(int64_t *)(arg1 + 0x148) = iVar4;
            *(int64_t *)(iVar4 + 0x28) = arg1;
            return 0;
        }
        *(uint32_t *)(arg1 + 0x3c) = uVar2 | 0x20;
        uStack_40 = 0x18018384a;
        (*(code *)0x699f34)(arg1 + 200);
        uStack_40 = 0x180183852;
        fcn.180173810(unaff_RBX);
        uStack_40 = 0x18018385a;
        fcn.180173710(arg1);
        uStack_40 = 0x180183862;
        fcn.1801736e0(arg1);
        uStack_40 = 0x18018386a;
        fcn.1801737b0(arg1);
        uStack_40 = 0x180183872;
        fcn.1801737e0(arg1);
        uStack_40 = 0x18018387a;
        fcn.180173780(arg1);
        uStack_40 = 0x180183882;
        fcn.180173740(arg1);
        uStack_40 = 0x18018388a;
        fcn.180173690(arg1);
        if (*(int64_t *)(arg1 + 0x180) != 0) {
            uStack_40 = 0x18018389d;
            fcn.180183340();
            *(undefined8 *)(arg1 + 0x180) = 0;
        }
        if ((*(int64_t *)(arg1 + 0x188) != 0) && ((*(uint32_t *)(arg1 + 0x3c) & 0x8000) != 0)) {
            uStack_40 = 0x1801838be;
            fcn.180183170();
            *(undefined8 *)(arg1 + 0x188) = 0;
        }
        if (*(int64_t *)(arg1 + 400) != 0) {
            uStack_40 = 0x1801838d6;
            fcn.180460d90();
            *(undefined8 *)(arg1 + 400) = 0;
        }
        if ((*(uint32_t *)(arg1 + 0x40) & 0xfffff00) != 0) {
            uStack_40 = 0x1801838f1;
            (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(arg1 + 0x48));
            return 0;
        }
        if (*(uint32_t *)(arg1 + 0x40) == 0x20) {
            uStack_40 = 0x18018390b;
            fcn.180474154(*(undefined4 *)(arg1 + 0x48));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180183920
// Address: 0x180183920
// Size: 291 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.180183920(int64_t arg1)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    uint64_t arg3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000028;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    uVar5 = *(undefined8 *)(arg1 + 0x60);
    iVar3 = *(int32_t *)(arg1 + 0x48);
    uVar2 = fcn.180184b50(uVar5);
    iVar3 = (*(code *)0x8000000000000004)((int64_t)iVar3, uVar5, uVar2);
    if ((iVar3 < 0) && (iVar4 = (*(code *)0x800000000000006f)(), iVar4 != 0x2733)) {
        fcn.18047208c(0x180624fe0);
        uVar2 = (*(code *)0x800000000000006f)();
        *(undefined4 *)(arg1 + 0x4c) = uVar2;
        fcn.180181d00(arg1);
        return iVar3;
    }
    if (iVar3 == 0) {
        var_48h = 0;
        var_40h = 0;
        var_38h = 0;
        var_30h = 0x180184380;
        var_20h = (int64_t)*(uint32_t *)(arg1 + 0x44);
        _var_18h = ZEXT816(0);
        var_28h = arg1;
        fcn.1801823b0(*(int64_t *)arg1, (int64_t)&var_48h);
        return 0;
    }
    arg3 = 10000;
    if (*(uint32_t *)(arg1 + 0x120) != 0) {
        arg3 = (uint64_t)*(uint32_t *)(arg1 + 0x120);
    }
    iVar6 = fcn.180182c00(*(int64_t *)arg1, 0x180183500, arg3, 1);
    *(int64_t *)(arg1 + 0x140) = iVar6;
    *(int64_t *)(iVar6 + 0x28) = arg1;
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x80;
    if (2 < *(int32_t *)(arg1 + 0x48)) {
        iVar6 = *(int64_t *)arg1;
        if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
            var_30h = 0x180181c8b;
            uVar5 = fcn.180174350();
            *(undefined8 *)(arg1 + 0x10) = uVar5;
            *(undefined8 *)(arg1 + 0x18) = 0x180183a50;
            if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
                *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
                *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
            }
            piVar1 = (int32_t *)(iVar6 + 0x130);
            *piVar1 = *piVar1 + 1;
        }
        if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
            var_30h = 0x180181cbb;
            fcn.180173db0(in_stack_00000028);
        }
        *(undefined8 *)(arg1 + 0x18) = 0x180183a50;
        if ((*(uint32_t *)(arg1 + 0x50) & 4) == 0) {
            var_30h = 0x180181cdc;
            fcn.18018a050(iVar6, *(undefined4 *)(arg1 + 0x48), 4);
            *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | 4;
        }
        return 0;
    }
    return -1;
}

