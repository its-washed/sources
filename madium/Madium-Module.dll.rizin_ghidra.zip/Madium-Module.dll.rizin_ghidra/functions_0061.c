// Chunk 61 - 50 functions

// ============================================================
// Function: FUN_1800c6b55
// Address: 0x1800c6b55
// Size: 13 bytes
// ============================================================
void fcn.1800c6b55(int64_t arg_60h, int64_t arg_88h)
{
    return;
}

// ============================================================
// Function: FUN_1800c6b62
// Address: 0x1800c6b62
// Size: 7 bytes
// ============================================================
void fcn.1800c6b55(int64_t arg_60h, int64_t arg_88h)
{
    return;
}

// ============================================================
// Function: FUN_1800c6b69
// Address: 0x1800c6b69
// Size: 6 bytes
// ============================================================
void fcn.1800c6b69(void)
{
    code *pcVar1;
    
    fcn.180010010();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800c6b6f
// Address: 0x1800c6b6f
// Size: 6 bytes
// ============================================================
void fcn.1800c6b6f(void)
{
    code *pcVar1;
    
    fcn.180004720();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800c6b80
// Address: 0x1800c6b80
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c6b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char *pcVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3[2] == 0) {
        uVar14 = 0;
    } else if (arg2 == piVar3[3]) {
        uVar14 = 0;
    } else {
        uVar11 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        uVar13 = uVar15;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            iVar4 = *(int64_t *)(*piVar3 + uVar11 * 0x18);
            uVar14 = *piVar3 + uVar11 * 0x18;
            if ((iVar4 == arg2) || (uVar14 = uVar15, iVar4 == piVar3[3])) break;
            uVar11 = uVar11 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= piVar3[1] - 1U);
    }
    bVar16 = false;
    pcVar9 = (char *)(uVar14 + 0x10);
    if (uVar14 == 0) {
        pcVar9 = (char *)0x8;
    }
    if (*pcVar9 == '\0') {
        var_10h = arg2;
        if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
            iVar2 = *(int32_t *)arg3;
            if (*(char *)0x180778018 == '\0') {
                bVar16 = iVar2 != 0;
            } else if ((iVar2 != 0) && (iVar2 != 7)) {
                bVar16 = true;
            }
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            *puVar12 = bVar16;
        } else {
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            if (*(int32_t *)arg3 == 7) {
                *puVar12 = 0;
                uVar5 = *(undefined4 *)arg3;
                uVar6 = *(undefined4 *)(arg3 + 4);
                uVar7 = *(undefined4 *)(arg3 + 8);
                uVar8 = *(undefined4 *)(arg3 + 0xc);
                uVar1 = *(undefined8 *)(arg3 + 0x10);
                puVar10 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_10h);
                *puVar10 = uVar5;
                puVar10[1] = uVar6;
                puVar10[2] = uVar7;
                puVar10[3] = uVar8;
                *(undefined8 *)(puVar10 + 4) = uVar1;
                return;
            }
            *puVar12 = *(int32_t *)arg3 != 0;
        }
        func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), arg2, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800c6bab
// Address: 0x1800c6bab
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c6b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char *pcVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3[2] == 0) {
        uVar14 = 0;
    } else if (arg2 == piVar3[3]) {
        uVar14 = 0;
    } else {
        uVar11 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        uVar13 = uVar15;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            iVar4 = *(int64_t *)(*piVar3 + uVar11 * 0x18);
            uVar14 = *piVar3 + uVar11 * 0x18;
            if ((iVar4 == arg2) || (uVar14 = uVar15, iVar4 == piVar3[3])) break;
            uVar11 = uVar11 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= piVar3[1] - 1U);
    }
    bVar16 = false;
    pcVar9 = (char *)(uVar14 + 0x10);
    if (uVar14 == 0) {
        pcVar9 = (char *)0x8;
    }
    if (*pcVar9 == '\0') {
        var_10h = arg2;
        if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
            iVar2 = *(int32_t *)arg3;
            if (*(char *)0x180778018 == '\0') {
                bVar16 = iVar2 != 0;
            } else if ((iVar2 != 0) && (iVar2 != 7)) {
                bVar16 = true;
            }
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            *puVar12 = bVar16;
        } else {
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            if (*(int32_t *)arg3 == 7) {
                *puVar12 = 0;
                uVar5 = *(undefined4 *)arg3;
                uVar6 = *(undefined4 *)(arg3 + 4);
                uVar7 = *(undefined4 *)(arg3 + 8);
                uVar8 = *(undefined4 *)(arg3 + 0xc);
                uVar1 = *(undefined8 *)(arg3 + 0x10);
                puVar10 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_10h);
                *puVar10 = uVar5;
                puVar10[1] = uVar6;
                puVar10[2] = uVar7;
                puVar10[3] = uVar8;
                *(undefined8 *)(puVar10 + 4) = uVar1;
                return;
            }
            *puVar12 = *(int32_t *)arg3 != 0;
        }
        func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), arg2, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800c6bd2
// Address: 0x1800c6bd2
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c6b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char *pcVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3[2] == 0) {
        uVar14 = 0;
    } else if (arg2 == piVar3[3]) {
        uVar14 = 0;
    } else {
        uVar11 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        uVar13 = uVar15;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            iVar4 = *(int64_t *)(*piVar3 + uVar11 * 0x18);
            uVar14 = *piVar3 + uVar11 * 0x18;
            if ((iVar4 == arg2) || (uVar14 = uVar15, iVar4 == piVar3[3])) break;
            uVar11 = uVar11 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= piVar3[1] - 1U);
    }
    bVar16 = false;
    pcVar9 = (char *)(uVar14 + 0x10);
    if (uVar14 == 0) {
        pcVar9 = (char *)0x8;
    }
    if (*pcVar9 == '\0') {
        var_10h = arg2;
        if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
            iVar2 = *(int32_t *)arg3;
            if (*(char *)0x180778018 == '\0') {
                bVar16 = iVar2 != 0;
            } else if ((iVar2 != 0) && (iVar2 != 7)) {
                bVar16 = true;
            }
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            *puVar12 = bVar16;
        } else {
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            if (*(int32_t *)arg3 == 7) {
                *puVar12 = 0;
                uVar5 = *(undefined4 *)arg3;
                uVar6 = *(undefined4 *)(arg3 + 4);
                uVar7 = *(undefined4 *)(arg3 + 8);
                uVar8 = *(undefined4 *)(arg3 + 0xc);
                uVar1 = *(undefined8 *)(arg3 + 0x10);
                puVar10 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_10h);
                *puVar10 = uVar5;
                puVar10[1] = uVar6;
                puVar10[2] = uVar7;
                puVar10[3] = uVar8;
                *(undefined8 *)(puVar10 + 4) = uVar1;
                return;
            }
            *puVar12 = *(int32_t *)arg3 != 0;
        }
        func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), arg2, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800c6c1f
// Address: 0x1800c6c1f
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c6b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char *pcVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3[2] == 0) {
        uVar14 = 0;
    } else if (arg2 == piVar3[3]) {
        uVar14 = 0;
    } else {
        uVar11 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        uVar13 = uVar15;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            iVar4 = *(int64_t *)(*piVar3 + uVar11 * 0x18);
            uVar14 = *piVar3 + uVar11 * 0x18;
            if ((iVar4 == arg2) || (uVar14 = uVar15, iVar4 == piVar3[3])) break;
            uVar11 = uVar11 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= piVar3[1] - 1U);
    }
    bVar16 = false;
    pcVar9 = (char *)(uVar14 + 0x10);
    if (uVar14 == 0) {
        pcVar9 = (char *)0x8;
    }
    if (*pcVar9 == '\0') {
        var_10h = arg2;
        if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
            iVar2 = *(int32_t *)arg3;
            if (*(char *)0x180778018 == '\0') {
                bVar16 = iVar2 != 0;
            } else if ((iVar2 != 0) && (iVar2 != 7)) {
                bVar16 = true;
            }
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            *puVar12 = bVar16;
        } else {
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            if (*(int32_t *)arg3 == 7) {
                *puVar12 = 0;
                uVar5 = *(undefined4 *)arg3;
                uVar6 = *(undefined4 *)(arg3 + 4);
                uVar7 = *(undefined4 *)(arg3 + 8);
                uVar8 = *(undefined4 *)(arg3 + 0xc);
                uVar1 = *(undefined8 *)(arg3 + 0x10);
                puVar10 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_10h);
                *puVar10 = uVar5;
                puVar10[1] = uVar6;
                puVar10[2] = uVar7;
                puVar10[3] = uVar8;
                *(undefined8 *)(puVar10 + 4) = uVar1;
                return;
            }
            *puVar12 = *(int32_t *)arg3 != 0;
        }
        func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), arg2, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800c6c24
// Address: 0x1800c6c24
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c6b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char *pcVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3[2] == 0) {
        uVar14 = 0;
    } else if (arg2 == piVar3[3]) {
        uVar14 = 0;
    } else {
        uVar11 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        uVar13 = uVar15;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            iVar4 = *(int64_t *)(*piVar3 + uVar11 * 0x18);
            uVar14 = *piVar3 + uVar11 * 0x18;
            if ((iVar4 == arg2) || (uVar14 = uVar15, iVar4 == piVar3[3])) break;
            uVar11 = uVar11 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= piVar3[1] - 1U);
    }
    bVar16 = false;
    pcVar9 = (char *)(uVar14 + 0x10);
    if (uVar14 == 0) {
        pcVar9 = (char *)0x8;
    }
    if (*pcVar9 == '\0') {
        var_10h = arg2;
        if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
            iVar2 = *(int32_t *)arg3;
            if (*(char *)0x180778018 == '\0') {
                bVar16 = iVar2 != 0;
            } else if ((iVar2 != 0) && (iVar2 != 7)) {
                bVar16 = true;
            }
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            *puVar12 = bVar16;
        } else {
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            if (*(int32_t *)arg3 == 7) {
                *puVar12 = 0;
                uVar5 = *(undefined4 *)arg3;
                uVar6 = *(undefined4 *)(arg3 + 4);
                uVar7 = *(undefined4 *)(arg3 + 8);
                uVar8 = *(undefined4 *)(arg3 + 0xc);
                uVar1 = *(undefined8 *)(arg3 + 0x10);
                puVar10 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_10h);
                *puVar10 = uVar5;
                puVar10[1] = uVar6;
                puVar10[2] = uVar7;
                puVar10[3] = uVar8;
                *(undefined8 *)(puVar10 + 4) = uVar1;
                return;
            }
            *puVar12 = *(int32_t *)arg3 != 0;
        }
        func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), arg2, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800c6c70
// Address: 0x1800c6c70
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c6b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char *pcVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3[2] == 0) {
        uVar14 = 0;
    } else if (arg2 == piVar3[3]) {
        uVar14 = 0;
    } else {
        uVar11 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        uVar13 = uVar15;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            iVar4 = *(int64_t *)(*piVar3 + uVar11 * 0x18);
            uVar14 = *piVar3 + uVar11 * 0x18;
            if ((iVar4 == arg2) || (uVar14 = uVar15, iVar4 == piVar3[3])) break;
            uVar11 = uVar11 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= piVar3[1] - 1U);
    }
    bVar16 = false;
    pcVar9 = (char *)(uVar14 + 0x10);
    if (uVar14 == 0) {
        pcVar9 = (char *)0x8;
    }
    if (*pcVar9 == '\0') {
        var_10h = arg2;
        if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
            iVar2 = *(int32_t *)arg3;
            if (*(char *)0x180778018 == '\0') {
                bVar16 = iVar2 != 0;
            } else if ((iVar2 != 0) && (iVar2 != 7)) {
                bVar16 = true;
            }
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            *puVar12 = bVar16;
        } else {
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            if (*(int32_t *)arg3 == 7) {
                *puVar12 = 0;
                uVar5 = *(undefined4 *)arg3;
                uVar6 = *(undefined4 *)(arg3 + 4);
                uVar7 = *(undefined4 *)(arg3 + 8);
                uVar8 = *(undefined4 *)(arg3 + 0xc);
                uVar1 = *(undefined8 *)(arg3 + 0x10);
                puVar10 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_10h);
                *puVar10 = uVar5;
                puVar10[1] = uVar6;
                puVar10[2] = uVar7;
                puVar10[3] = uVar8;
                *(undefined8 *)(puVar10 + 4) = uVar1;
                return;
            }
            *puVar12 = *(int32_t *)arg3 != 0;
        }
        func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), arg2, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800c6cab
// Address: 0x1800c6cab
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c6b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char *pcVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    bool bVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if (piVar3[2] == 0) {
        uVar14 = 0;
    } else if (arg2 == piVar3[3]) {
        uVar14 = 0;
    } else {
        uVar11 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar15 = 0;
        uVar13 = uVar15;
        do {
            uVar11 = uVar11 & piVar3[1] - 1U;
            iVar4 = *(int64_t *)(*piVar3 + uVar11 * 0x18);
            uVar14 = *piVar3 + uVar11 * 0x18;
            if ((iVar4 == arg2) || (uVar14 = uVar15, iVar4 == piVar3[3])) break;
            uVar11 = uVar11 + 1 + uVar13;
            uVar13 = uVar13 + 1;
        } while (uVar13 <= piVar3[1] - 1U);
    }
    bVar16 = false;
    pcVar9 = (char *)(uVar14 + 0x10);
    if (uVar14 == 0) {
        pcVar9 = (char *)0x8;
    }
    if (*pcVar9 == '\0') {
        var_10h = arg2;
        if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
            iVar2 = *(int32_t *)arg3;
            if (*(char *)0x180778018 == '\0') {
                bVar16 = iVar2 != 0;
            } else if ((iVar2 != 0) && (iVar2 != 7)) {
                bVar16 = true;
            }
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            *puVar12 = bVar16;
        } else {
            puVar12 = (undefined *)(uVar14 + 0x11);
            if (uVar14 == 0) {
                puVar12 = (undefined *)0x9;
            }
            if (*(int32_t *)arg3 == 7) {
                *puVar12 = 0;
                uVar5 = *(undefined4 *)arg3;
                uVar6 = *(undefined4 *)(arg3 + 4);
                uVar7 = *(undefined4 *)(arg3 + 8);
                uVar8 = *(undefined4 *)(arg3 + 0xc);
                uVar1 = *(undefined8 *)(arg3 + 0x10);
                puVar10 = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_10h);
                *puVar10 = uVar5;
                puVar10[1] = uVar6;
                puVar10[2] = uVar7;
                puVar10[3] = uVar8;
                *(undefined8 *)(puVar10 + 4) = uVar1;
                return;
            }
            *puVar12 = *(int32_t *)arg3 != 0;
        }
        func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), arg2, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800c6d10
// Address: 0x1800c6d10
// Size: 24 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h

undefined fcn.1800c6d10(undefined8 placeholder_0, int64_t arg2)
{
    int64_t var_28h;
    
    fcn.1800c4d10(placeholder_0, &var_28h, arg2);
    return 0;
}

// ============================================================
// Function: FUN_1800c6d30
// Address: 0x1800c6d30
// Size: 70 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800c70e5)
// WARNING: Removing unreachable block (ram,0x0001800c7152)
// WARNING: Removing unreachable block (ram,0x0001800c71b1)
// WARNING: Removing unreachable block (ram,0x0001800c71bb)
// WARNING: Removing unreachable block (ram,0x0001800c71c5)
// WARNING: Removing unreachable block (ram,0x0001800c71d2)
// WARNING: Removing unreachable block (ram,0x0001800c71f0)
// WARNING: Removing unreachable block (ram,0x0001800c7221)
// WARNING: Removing unreachable block (ram,0x0001800c7228)
// WARNING: Removing unreachable block (ram,0x0001800c722c)
// WARNING: Removing unreachable block (ram,0x0001800c7235)
// WARNING: Removing unreachable block (ram,0x0001800c7202)
// WARNING: Removing unreachable block (ram,0x0001800c720b)
// WARNING: Removing unreachable block (ram,0x0001800c721c)
// WARNING: Removing unreachable block (ram,0x0001800c7274)
// WARNING: Removing unreachable block (ram,0x0001800c727a)
// WARNING: Removing unreachable block (ram,0x0001800c7283)
// WARNING: Removing unreachable block (ram,0x0001800c7289)
// WARNING: Removing unreachable block (ram,0x0001800c7292)
// WARNING: Removing unreachable block (ram,0x0001800c72b0)
// WARNING: Removing unreachable block (ram,0x0001800c72da)
// WARNING: Removing unreachable block (ram,0x0001800c72e1)
// WARNING: Removing unreachable block (ram,0x0001800c72e5)
// WARNING: Removing unreachable block (ram,0x0001800c72ea)
// WARNING: Removing unreachable block (ram,0x0001800c72c2)
// WARNING: Removing unreachable block (ram,0x0001800c72c7)
// WARNING: Removing unreachable block (ram,0x0001800c72d8)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h

uint64_t fcn.1800c6d30(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 *in_RAX;
    char *pcVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    undefined *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    uint64_t *puVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    bool bVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    uVar16 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = (uint64_t *)(arg2 + 0x40);
    if (uVar16 != 0) {
        uVar19 = 0;
        do {
            if (*puVar1 <= uVar19) break;
            fcn.1800c4d10(arg1);
            if ((*(char *)0x180778018 == '\0') || ((int32_t)var_88h != 7)) {
                var_20h = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
                piVar18 = *(int64_t **)(arg1 + 0x10);
                if (piVar18[2] == 0) {
                    iVar15 = 0;
                } else if (var_20h == piVar18[3]) {
                    iVar15 = 0;
                } else {
                    uVar16 = ((uint64_t)var_20h >> 5 ^ var_20h) >> 4;
                    uVar10 = 0;
                    do {
                        uVar16 = uVar16 & piVar18[1] - 1U;
                        iVar15 = *piVar18 + uVar16 * 0x18;
                        uVar14 = *(uint64_t *)(*piVar18 + uVar16 * 0x18);
                        if (uVar14 == var_20h) goto code_r0x0001800c6eec;
                        if (uVar14 == piVar18[3]) break;
                        uVar16 = uVar16 + 1 + uVar10;
                        uVar10 = uVar10 + 1;
                    } while (uVar10 <= piVar18[1] - 1U);
                    iVar15 = 0;
                }
code_r0x0001800c6eec:
                in_RAX = (undefined4 *)(iVar15 + 0x10);
                if (iVar15 == 0) {
                    in_RAX = (undefined4 *)0x8;
                }
                if (*(char *)in_RAX == '\0') {
                    if (*(char *)0x180777ff8 == '\0') {
                        if (*(char *)0x180778018 == '\0') goto code_r0x0001800c6f78;
                        if (((int32_t)var_88h == 0) || ((int32_t)var_88h == 7)) {
                            bVar20 = false;
                        } else {
                            bVar20 = true;
                        }
code_r0x0001800c6f7d:
                        puVar13 = (undefined *)(iVar15 + 0x11);
                        if (iVar15 == 0) {
                            puVar13 = (undefined *)0x9;
                        }
                        *puVar13 = bVar20;
                    } else {
                        if (*(char *)0x180778018 == '\0') {
code_r0x0001800c6f78:
                            bVar20 = (int32_t)var_88h != 0;
                            goto code_r0x0001800c6f7d;
                        }
                        puVar13 = (undefined *)(iVar15 + 0x11);
                        if (iVar15 == 0) {
                            puVar13 = (undefined *)0x9;
                        }
                        if ((int32_t)var_88h == 7) {
                            *puVar13 = 0;
                            uVar5 = var_88h._4_4_;
                            uVar6 = (undefined4)var_80h;
                            uVar7 = var_80h._4_4_;
                            iVar15 = var_78h;
                            in_RAX = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_20h);
                            *in_RAX = 7;
                            in_RAX[1] = uVar5;
                            in_RAX[2] = uVar6;
                            in_RAX[3] = uVar7;
                            *(int64_t *)(in_RAX + 4) = iVar15;
                            goto code_r0x0001800c6fa6;
                        }
                        *puVar13 = (int32_t)var_88h != 0;
                    }
                    in_RAX = (undefined4 *)func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), var_20h, &var_88h);
                }
            } else {
                uVar16 = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
                piVar18 = *(int64_t **)(arg1 + 0x78);
                if ((piVar18[2] != 0) && (uVar16 != piVar18[3])) {
                    uVar10 = (uVar16 >> 5 ^ uVar16) >> 4;
                    uVar14 = 0;
                    do {
                        uVar10 = uVar10 & piVar18[1] - 1U;
                        puVar17 = (uint64_t *)(uVar10 * 0x10 + *piVar18);
                        if (*puVar17 == uVar16) {
                            puVar11 = puVar17 + 1;
                            if (puVar17 == (uint64_t *)0x0) {
                                puVar11 = (uint64_t *)0x0;
                            }
                            if ((puVar11 != (uint64_t *)0x0) && (*(int32_t *)puVar11 == 0)) {
                                piVar18 = &var_88h;
                                goto code_r0x0001800c6e3a;
                            }
                            break;
                        }
                        if (*puVar17 == piVar18[3]) break;
                        uVar10 = uVar10 + 1 + uVar14;
                        uVar14 = uVar14 + 1;
                    } while (uVar14 <= piVar18[1] - 1U);
                }
                piVar18 = &var_70h;
                var_70h = 0;
                _var_68h = ZEXT816(0);
code_r0x0001800c6e3a:
                in_RAX = (undefined4 *)fcn.1800c6b80(arg1, uVar16, (int64_t)piVar18);
            }
code_r0x0001800c6fa6:
            uVar16 = *(uint64_t *)(arg2 + 0x30);
            uVar19 = uVar19 + 1;
        } while (uVar19 < uVar16);
    }
    uVar19 = *puVar1;
    if (uVar19 < uVar16) {
        if ((uVar19 != 0) && (iVar15 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + -8 + uVar19 * 8), iVar15 != 0)) {
            uVar2 = *(uint32_t *)(iVar15 + 8);
            in_RAX = (undefined4 *)(uint64_t)uVar2;
            if ((uVar2 == *(uint32_t *)0x180782740) || (uVar2 == *(uint32_t *)0x1807826b8)) goto code_r0x0001800c732c;
        }
        uVar16 = 0;
        do {
            var_88h = 1;
            _var_80h = ZEXT816(0);
            var_18h = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
            piVar18 = *(int64_t **)(arg1 + 0x10);
            uVar10 = uVar16;
            if ((piVar18[2] != 0) && (var_18h != piVar18[3])) {
                uVar12 = ((uint64_t)var_18h >> 5 ^ var_18h) >> 4;
                uVar14 = uVar16;
                do {
                    uVar12 = uVar12 & piVar18[1] - 1U;
                    uVar3 = *(uint64_t *)(*piVar18 + uVar12 * 0x18);
                    uVar10 = *piVar18 + uVar12 * 0x18;
                    if ((uVar3 == var_18h) || (uVar10 = uVar16, uVar3 == piVar18[3])) break;
                    uVar12 = uVar12 + 1 + uVar14;
                    uVar14 = uVar14 + 1;
                } while (uVar14 <= piVar18[1] - 1U);
            }
            pcVar8 = (char *)(uVar10 + 0x10);
            if (uVar10 == 0) {
                pcVar8 = (char *)0x8;
            }
            if (*pcVar8 == '\0') {
                if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
                    puVar13 = (undefined *)(uVar10 + 0x11);
                    if (uVar10 == 0) {
                        puVar13 = (undefined *)0x9;
                    }
                    *puVar13 = 1;
                    uVar4 = *(undefined8 *)(arg1 + 0x18);
                    if ((*(char *)0x180777ff8 != '\0') && (*(char *)0x180778018 != '\0')) {
                        func_0x0001800c6850(arg1, uVar4, var_18h, 0);
                    }
                    puVar9 = (undefined4 *)func_0x0001800c05e0(uVar4, &var_18h);
                    *puVar9 = (int32_t)var_88h;
                    puVar9[1] = var_88h._4_4_;
                    puVar9[2] = (undefined4)var_80h;
                    puVar9[3] = var_80h._4_4_;
                    *(undefined8 *)(puVar9 + 4) = 0;
                } else {
                    puVar13 = (undefined *)(uVar10 + 0x11);
                    if (uVar10 == 0) {
                        puVar13 = (undefined *)0x9;
                    }
                    *puVar13 = 1;
                    func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), var_18h, &var_88h);
                }
            }
            uVar19 = uVar19 + 1;
            in_RAX = (undefined4 *)arg2;
        } while (uVar19 < *(uint64_t *)(arg2 + 0x30));
    } else if (uVar16 < uVar19) {
        do {
            in_RAX = (undefined4 *)
                     fcn.1800c4d10(arg1, &var_70h, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar16 * 8));
            uVar16 = uVar16 + 1;
        } while (uVar16 < *puVar1);
    }
code_r0x0001800c732c:
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c6d76
// Address: 0x1800c6d76
// Size: 590 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800c70e5)
// WARNING: Removing unreachable block (ram,0x0001800c7152)
// WARNING: Removing unreachable block (ram,0x0001800c71b1)
// WARNING: Removing unreachable block (ram,0x0001800c71bb)
// WARNING: Removing unreachable block (ram,0x0001800c71c5)
// WARNING: Removing unreachable block (ram,0x0001800c71d2)
// WARNING: Removing unreachable block (ram,0x0001800c71f0)
// WARNING: Removing unreachable block (ram,0x0001800c7221)
// WARNING: Removing unreachable block (ram,0x0001800c7228)
// WARNING: Removing unreachable block (ram,0x0001800c722c)
// WARNING: Removing unreachable block (ram,0x0001800c7235)
// WARNING: Removing unreachable block (ram,0x0001800c7202)
// WARNING: Removing unreachable block (ram,0x0001800c720b)
// WARNING: Removing unreachable block (ram,0x0001800c721c)
// WARNING: Removing unreachable block (ram,0x0001800c7274)
// WARNING: Removing unreachable block (ram,0x0001800c727a)
// WARNING: Removing unreachable block (ram,0x0001800c7283)
// WARNING: Removing unreachable block (ram,0x0001800c7289)
// WARNING: Removing unreachable block (ram,0x0001800c7292)
// WARNING: Removing unreachable block (ram,0x0001800c72b0)
// WARNING: Removing unreachable block (ram,0x0001800c72da)
// WARNING: Removing unreachable block (ram,0x0001800c72e1)
// WARNING: Removing unreachable block (ram,0x0001800c72e5)
// WARNING: Removing unreachable block (ram,0x0001800c72ea)
// WARNING: Removing unreachable block (ram,0x0001800c72c2)
// WARNING: Removing unreachable block (ram,0x0001800c72c7)
// WARNING: Removing unreachable block (ram,0x0001800c72d8)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h

uint64_t fcn.1800c6d30(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 *in_RAX;
    char *pcVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    undefined *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    uint64_t *puVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    bool bVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    uVar16 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = (uint64_t *)(arg2 + 0x40);
    if (uVar16 != 0) {
        uVar19 = 0;
        do {
            if (*puVar1 <= uVar19) break;
            fcn.1800c4d10(arg1);
            if ((*(char *)0x180778018 == '\0') || ((int32_t)var_88h != 7)) {
                var_20h = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
                piVar18 = *(int64_t **)(arg1 + 0x10);
                if (piVar18[2] == 0) {
                    iVar15 = 0;
                } else if (var_20h == piVar18[3]) {
                    iVar15 = 0;
                } else {
                    uVar16 = ((uint64_t)var_20h >> 5 ^ var_20h) >> 4;
                    uVar10 = 0;
                    do {
                        uVar16 = uVar16 & piVar18[1] - 1U;
                        iVar15 = *piVar18 + uVar16 * 0x18;
                        uVar14 = *(uint64_t *)(*piVar18 + uVar16 * 0x18);
                        if (uVar14 == var_20h) goto code_r0x0001800c6eec;
                        if (uVar14 == piVar18[3]) break;
                        uVar16 = uVar16 + 1 + uVar10;
                        uVar10 = uVar10 + 1;
                    } while (uVar10 <= piVar18[1] - 1U);
                    iVar15 = 0;
                }
code_r0x0001800c6eec:
                in_RAX = (undefined4 *)(iVar15 + 0x10);
                if (iVar15 == 0) {
                    in_RAX = (undefined4 *)0x8;
                }
                if (*(char *)in_RAX == '\0') {
                    if (*(char *)0x180777ff8 == '\0') {
                        if (*(char *)0x180778018 == '\0') goto code_r0x0001800c6f78;
                        if (((int32_t)var_88h == 0) || ((int32_t)var_88h == 7)) {
                            bVar20 = false;
                        } else {
                            bVar20 = true;
                        }
code_r0x0001800c6f7d:
                        puVar13 = (undefined *)(iVar15 + 0x11);
                        if (iVar15 == 0) {
                            puVar13 = (undefined *)0x9;
                        }
                        *puVar13 = bVar20;
                    } else {
                        if (*(char *)0x180778018 == '\0') {
code_r0x0001800c6f78:
                            bVar20 = (int32_t)var_88h != 0;
                            goto code_r0x0001800c6f7d;
                        }
                        puVar13 = (undefined *)(iVar15 + 0x11);
                        if (iVar15 == 0) {
                            puVar13 = (undefined *)0x9;
                        }
                        if ((int32_t)var_88h == 7) {
                            *puVar13 = 0;
                            uVar5 = var_88h._4_4_;
                            uVar6 = (undefined4)var_80h;
                            uVar7 = var_80h._4_4_;
                            iVar15 = var_78h;
                            in_RAX = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_20h);
                            *in_RAX = 7;
                            in_RAX[1] = uVar5;
                            in_RAX[2] = uVar6;
                            in_RAX[3] = uVar7;
                            *(int64_t *)(in_RAX + 4) = iVar15;
                            goto code_r0x0001800c6fa6;
                        }
                        *puVar13 = (int32_t)var_88h != 0;
                    }
                    in_RAX = (undefined4 *)func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), var_20h, &var_88h);
                }
            } else {
                uVar16 = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
                piVar18 = *(int64_t **)(arg1 + 0x78);
                if ((piVar18[2] != 0) && (uVar16 != piVar18[3])) {
                    uVar10 = (uVar16 >> 5 ^ uVar16) >> 4;
                    uVar14 = 0;
                    do {
                        uVar10 = uVar10 & piVar18[1] - 1U;
                        puVar17 = (uint64_t *)(uVar10 * 0x10 + *piVar18);
                        if (*puVar17 == uVar16) {
                            puVar11 = puVar17 + 1;
                            if (puVar17 == (uint64_t *)0x0) {
                                puVar11 = (uint64_t *)0x0;
                            }
                            if ((puVar11 != (uint64_t *)0x0) && (*(int32_t *)puVar11 == 0)) {
                                piVar18 = &var_88h;
                                goto code_r0x0001800c6e3a;
                            }
                            break;
                        }
                        if (*puVar17 == piVar18[3]) break;
                        uVar10 = uVar10 + 1 + uVar14;
                        uVar14 = uVar14 + 1;
                    } while (uVar14 <= piVar18[1] - 1U);
                }
                piVar18 = &var_70h;
                var_70h = 0;
                _var_68h = ZEXT816(0);
code_r0x0001800c6e3a:
                in_RAX = (undefined4 *)fcn.1800c6b80(arg1, uVar16, (int64_t)piVar18);
            }
code_r0x0001800c6fa6:
            uVar16 = *(uint64_t *)(arg2 + 0x30);
            uVar19 = uVar19 + 1;
        } while (uVar19 < uVar16);
    }
    uVar19 = *puVar1;
    if (uVar19 < uVar16) {
        if ((uVar19 != 0) && (iVar15 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + -8 + uVar19 * 8), iVar15 != 0)) {
            uVar2 = *(uint32_t *)(iVar15 + 8);
            in_RAX = (undefined4 *)(uint64_t)uVar2;
            if ((uVar2 == *(uint32_t *)0x180782740) || (uVar2 == *(uint32_t *)0x1807826b8)) goto code_r0x0001800c732c;
        }
        uVar16 = 0;
        do {
            var_88h = 1;
            _var_80h = ZEXT816(0);
            var_18h = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
            piVar18 = *(int64_t **)(arg1 + 0x10);
            uVar10 = uVar16;
            if ((piVar18[2] != 0) && (var_18h != piVar18[3])) {
                uVar12 = ((uint64_t)var_18h >> 5 ^ var_18h) >> 4;
                uVar14 = uVar16;
                do {
                    uVar12 = uVar12 & piVar18[1] - 1U;
                    uVar3 = *(uint64_t *)(*piVar18 + uVar12 * 0x18);
                    uVar10 = *piVar18 + uVar12 * 0x18;
                    if ((uVar3 == var_18h) || (uVar10 = uVar16, uVar3 == piVar18[3])) break;
                    uVar12 = uVar12 + 1 + uVar14;
                    uVar14 = uVar14 + 1;
                } while (uVar14 <= piVar18[1] - 1U);
            }
            pcVar8 = (char *)(uVar10 + 0x10);
            if (uVar10 == 0) {
                pcVar8 = (char *)0x8;
            }
            if (*pcVar8 == '\0') {
                if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
                    puVar13 = (undefined *)(uVar10 + 0x11);
                    if (uVar10 == 0) {
                        puVar13 = (undefined *)0x9;
                    }
                    *puVar13 = 1;
                    uVar4 = *(undefined8 *)(arg1 + 0x18);
                    if ((*(char *)0x180777ff8 != '\0') && (*(char *)0x180778018 != '\0')) {
                        func_0x0001800c6850(arg1, uVar4, var_18h, 0);
                    }
                    puVar9 = (undefined4 *)func_0x0001800c05e0(uVar4, &var_18h);
                    *puVar9 = (int32_t)var_88h;
                    puVar9[1] = var_88h._4_4_;
                    puVar9[2] = (undefined4)var_80h;
                    puVar9[3] = var_80h._4_4_;
                    *(undefined8 *)(puVar9 + 4) = 0;
                } else {
                    puVar13 = (undefined *)(uVar10 + 0x11);
                    if (uVar10 == 0) {
                        puVar13 = (undefined *)0x9;
                    }
                    *puVar13 = 1;
                    func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), var_18h, &var_88h);
                }
            }
            uVar19 = uVar19 + 1;
            in_RAX = (undefined4 *)arg2;
        } while (uVar19 < *(uint64_t *)(arg2 + 0x30));
    } else if (uVar16 < uVar19) {
        do {
            in_RAX = (undefined4 *)
                     fcn.1800c4d10(arg1, &var_70h, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar16 * 8));
            uVar16 = uVar16 + 1;
        } while (uVar16 < *puVar1);
    }
code_r0x0001800c732c:
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c6fc4
// Address: 0x1800c6fc4
// Size: 903 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800c70e5)
// WARNING: Removing unreachable block (ram,0x0001800c7152)
// WARNING: Removing unreachable block (ram,0x0001800c71b1)
// WARNING: Removing unreachable block (ram,0x0001800c71bb)
// WARNING: Removing unreachable block (ram,0x0001800c71c5)
// WARNING: Removing unreachable block (ram,0x0001800c71d2)
// WARNING: Removing unreachable block (ram,0x0001800c71f0)
// WARNING: Removing unreachable block (ram,0x0001800c7221)
// WARNING: Removing unreachable block (ram,0x0001800c7228)
// WARNING: Removing unreachable block (ram,0x0001800c722c)
// WARNING: Removing unreachable block (ram,0x0001800c7235)
// WARNING: Removing unreachable block (ram,0x0001800c7202)
// WARNING: Removing unreachable block (ram,0x0001800c720b)
// WARNING: Removing unreachable block (ram,0x0001800c721c)
// WARNING: Removing unreachable block (ram,0x0001800c7274)
// WARNING: Removing unreachable block (ram,0x0001800c727a)
// WARNING: Removing unreachable block (ram,0x0001800c7283)
// WARNING: Removing unreachable block (ram,0x0001800c7289)
// WARNING: Removing unreachable block (ram,0x0001800c7292)
// WARNING: Removing unreachable block (ram,0x0001800c72b0)
// WARNING: Removing unreachable block (ram,0x0001800c72da)
// WARNING: Removing unreachable block (ram,0x0001800c72e1)
// WARNING: Removing unreachable block (ram,0x0001800c72e5)
// WARNING: Removing unreachable block (ram,0x0001800c72ea)
// WARNING: Removing unreachable block (ram,0x0001800c72c2)
// WARNING: Removing unreachable block (ram,0x0001800c72c7)
// WARNING: Removing unreachable block (ram,0x0001800c72d8)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h

uint64_t fcn.1800c6d30(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 *in_RAX;
    char *pcVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    undefined *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    uint64_t *puVar17;
    int64_t *piVar18;
    uint64_t uVar19;
    bool bVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    uVar16 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = (uint64_t *)(arg2 + 0x40);
    if (uVar16 != 0) {
        uVar19 = 0;
        do {
            if (*puVar1 <= uVar19) break;
            fcn.1800c4d10(arg1);
            if ((*(char *)0x180778018 == '\0') || ((int32_t)var_88h != 7)) {
                var_20h = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
                piVar18 = *(int64_t **)(arg1 + 0x10);
                if (piVar18[2] == 0) {
                    iVar15 = 0;
                } else if (var_20h == piVar18[3]) {
                    iVar15 = 0;
                } else {
                    uVar16 = ((uint64_t)var_20h >> 5 ^ var_20h) >> 4;
                    uVar10 = 0;
                    do {
                        uVar16 = uVar16 & piVar18[1] - 1U;
                        iVar15 = *piVar18 + uVar16 * 0x18;
                        uVar14 = *(uint64_t *)(*piVar18 + uVar16 * 0x18);
                        if (uVar14 == var_20h) goto code_r0x0001800c6eec;
                        if (uVar14 == piVar18[3]) break;
                        uVar16 = uVar16 + 1 + uVar10;
                        uVar10 = uVar10 + 1;
                    } while (uVar10 <= piVar18[1] - 1U);
                    iVar15 = 0;
                }
code_r0x0001800c6eec:
                in_RAX = (undefined4 *)(iVar15 + 0x10);
                if (iVar15 == 0) {
                    in_RAX = (undefined4 *)0x8;
                }
                if (*(char *)in_RAX == '\0') {
                    if (*(char *)0x180777ff8 == '\0') {
                        if (*(char *)0x180778018 == '\0') goto code_r0x0001800c6f78;
                        if (((int32_t)var_88h == 0) || ((int32_t)var_88h == 7)) {
                            bVar20 = false;
                        } else {
                            bVar20 = true;
                        }
code_r0x0001800c6f7d:
                        puVar13 = (undefined *)(iVar15 + 0x11);
                        if (iVar15 == 0) {
                            puVar13 = (undefined *)0x9;
                        }
                        *puVar13 = bVar20;
                    } else {
                        if (*(char *)0x180778018 == '\0') {
code_r0x0001800c6f78:
                            bVar20 = (int32_t)var_88h != 0;
                            goto code_r0x0001800c6f7d;
                        }
                        puVar13 = (undefined *)(iVar15 + 0x11);
                        if (iVar15 == 0) {
                            puVar13 = (undefined *)0x9;
                        }
                        if ((int32_t)var_88h == 7) {
                            *puVar13 = 0;
                            uVar5 = var_88h._4_4_;
                            uVar6 = (undefined4)var_80h;
                            uVar7 = var_80h._4_4_;
                            iVar15 = var_78h;
                            in_RAX = (undefined4 *)func_0x0001800c05e0(arg1 + 0x80, &var_20h);
                            *in_RAX = 7;
                            in_RAX[1] = uVar5;
                            in_RAX[2] = uVar6;
                            in_RAX[3] = uVar7;
                            *(int64_t *)(in_RAX + 4) = iVar15;
                            goto code_r0x0001800c6fa6;
                        }
                        *puVar13 = (int32_t)var_88h != 0;
                    }
                    in_RAX = (undefined4 *)func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), var_20h, &var_88h);
                }
            } else {
                uVar16 = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
                piVar18 = *(int64_t **)(arg1 + 0x78);
                if ((piVar18[2] != 0) && (uVar16 != piVar18[3])) {
                    uVar10 = (uVar16 >> 5 ^ uVar16) >> 4;
                    uVar14 = 0;
                    do {
                        uVar10 = uVar10 & piVar18[1] - 1U;
                        puVar17 = (uint64_t *)(uVar10 * 0x10 + *piVar18);
                        if (*puVar17 == uVar16) {
                            puVar11 = puVar17 + 1;
                            if (puVar17 == (uint64_t *)0x0) {
                                puVar11 = (uint64_t *)0x0;
                            }
                            if ((puVar11 != (uint64_t *)0x0) && (*(int32_t *)puVar11 == 0)) {
                                piVar18 = &var_88h;
                                goto code_r0x0001800c6e3a;
                            }
                            break;
                        }
                        if (*puVar17 == piVar18[3]) break;
                        uVar10 = uVar10 + 1 + uVar14;
                        uVar14 = uVar14 + 1;
                    } while (uVar14 <= piVar18[1] - 1U);
                }
                piVar18 = &var_70h;
                var_70h = 0;
                _var_68h = ZEXT816(0);
code_r0x0001800c6e3a:
                in_RAX = (undefined4 *)fcn.1800c6b80(arg1, uVar16, (int64_t)piVar18);
            }
code_r0x0001800c6fa6:
            uVar16 = *(uint64_t *)(arg2 + 0x30);
            uVar19 = uVar19 + 1;
        } while (uVar19 < uVar16);
    }
    uVar19 = *puVar1;
    if (uVar19 < uVar16) {
        if ((uVar19 != 0) && (iVar15 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + -8 + uVar19 * 8), iVar15 != 0)) {
            uVar2 = *(uint32_t *)(iVar15 + 8);
            in_RAX = (undefined4 *)(uint64_t)uVar2;
            if ((uVar2 == *(uint32_t *)0x180782740) || (uVar2 == *(uint32_t *)0x1807826b8)) goto code_r0x0001800c732c;
        }
        uVar16 = 0;
        do {
            var_88h = 1;
            _var_80h = ZEXT816(0);
            var_18h = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar19 * 8);
            piVar18 = *(int64_t **)(arg1 + 0x10);
            uVar10 = uVar16;
            if ((piVar18[2] != 0) && (var_18h != piVar18[3])) {
                uVar12 = ((uint64_t)var_18h >> 5 ^ var_18h) >> 4;
                uVar14 = uVar16;
                do {
                    uVar12 = uVar12 & piVar18[1] - 1U;
                    uVar3 = *(uint64_t *)(*piVar18 + uVar12 * 0x18);
                    uVar10 = *piVar18 + uVar12 * 0x18;
                    if ((uVar3 == var_18h) || (uVar10 = uVar16, uVar3 == piVar18[3])) break;
                    uVar12 = uVar12 + 1 + uVar14;
                    uVar14 = uVar14 + 1;
                } while (uVar14 <= piVar18[1] - 1U);
            }
            pcVar8 = (char *)(uVar10 + 0x10);
            if (uVar10 == 0) {
                pcVar8 = (char *)0x8;
            }
            if (*pcVar8 == '\0') {
                if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
                    puVar13 = (undefined *)(uVar10 + 0x11);
                    if (uVar10 == 0) {
                        puVar13 = (undefined *)0x9;
                    }
                    *puVar13 = 1;
                    uVar4 = *(undefined8 *)(arg1 + 0x18);
                    if ((*(char *)0x180777ff8 != '\0') && (*(char *)0x180778018 != '\0')) {
                        func_0x0001800c6850(arg1, uVar4, var_18h, 0);
                    }
                    puVar9 = (undefined4 *)func_0x0001800c05e0(uVar4, &var_18h);
                    *puVar9 = (int32_t)var_88h;
                    puVar9[1] = var_88h._4_4_;
                    puVar9[2] = (undefined4)var_80h;
                    puVar9[3] = var_80h._4_4_;
                    *(undefined8 *)(puVar9 + 4) = 0;
                } else {
                    puVar13 = (undefined *)(uVar10 + 0x11);
                    if (uVar10 == 0) {
                        puVar13 = (undefined *)0x9;
                    }
                    *puVar13 = 1;
                    func_0x0001800c78c0(arg1, *(undefined8 *)(arg1 + 0x18), var_18h, &var_88h);
                }
            }
            uVar19 = uVar19 + 1;
            in_RAX = (undefined4 *)arg2;
        } while (uVar19 < *(uint64_t *)(arg2 + 0x30));
    } else if (uVar16 < uVar19) {
        do {
            in_RAX = (undefined4 *)
                     fcn.1800c4d10(arg1, &var_70h, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar16 * 8));
            uVar16 = uVar16 + 1;
        } while (uVar16 < *puVar1);
    }
code_r0x0001800c732c:
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c7350
// Address: 0x1800c7350
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c7350(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x80) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
    }
    func_0x000180028940(arg1 + 0x60);
    func_0x0001800c7a90(arg1 + 0x40);
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((arg2 & 1U) != 0) {
        func_0x000180459c3c(arg1, 0xb8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c73c0
// Address: 0x1800c73c0
// Size: 76 bytes
// ============================================================
void fcn.1800c73c0(int64_t arg1)
{
    int64_t in_stack_00000008;
    
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x80) = 0;
        *(undefined8 *)(arg1 + 0x88) = 0;
    }
    fcn.180028940(arg1 + 0x60);
    fcn.1800c7a90(in_stack_00000008);
    *(undefined8 *)arg1 = 0x18063f2c0;
    return;
}

// ============================================================
// Function: FUN_1800c7410
// Address: 0x1800c7410
// Size: 399 bytes
// ============================================================
void fcn.1800c7410(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined4 *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    if (*(char *)0x180777fd8 == '\0') {
        var_88h = 0x180640a40;
        var_80h = arg1;
        var_78h = arg2;
        (***(code ***)arg3)(arg3, &var_88h);
    } else {
        var_70h = 0x180640e60;
        _var_60h = ZEXT816(0);
        _var_50h = ZEXT816(0);
        var_68h = arg2;
        (***(code ***)arg3)(arg3, &var_70h);
        uVar10 = 0;
        uVar2 = *(uint64_t *)(arg2 + 8);
        uVar9 = uVar10;
        if (uVar2 != 0) {
            do {
                if (*(int64_t *)(*(int64_t *)arg2 + uVar9 * 0x18) != *(int64_t *)(arg2 + 0x18)) break;
                uVar9 = uVar9 + 1;
            } while (uVar9 < uVar2);
        }
        iVar11 = var_60h;
code_r0x0001800c7497:
        if (uVar9 != uVar2) {
            puVar1 = (uint64_t *)(*(int64_t *)arg2 + uVar9 * 0x18);
            if (((*(char *)(puVar1 + 2) == '\0') && (puVar1[1] != 0)) && (iVar5 = func_0x0001800bebd0(), iVar5 != 0)) {
                if (var_50h != 0) {
                    uVar3 = *puVar1;
                    if (uVar3 != var_48h) {
                        uVar6 = (uVar3 >> 5 ^ uVar3) >> 4;
                        uVar8 = uVar10;
                        do {
                            uVar6 = uVar6 & var_58h - 1U;
                            uVar4 = *(uint64_t *)(iVar11 + uVar6 * 8);
                            if (uVar4 == uVar3) goto code_r0x0001800c7526;
                            if (uVar4 == var_48h) break;
                            uVar6 = uVar6 + 1 + uVar8;
                            uVar8 = uVar8 + 1;
                        } while (uVar8 <= var_58h - 1U);
                    }
                }
                puVar7 = (undefined4 *)func_0x0001800ac540(arg1, puVar1);
                *puVar7 = 0;
                iVar11 = var_60h;
            }
code_r0x0001800c7526:
            do {
                uVar9 = uVar9 + 1;
                if (*(uint64_t *)(arg2 + 8) <= uVar9) break;
            } while (*(int64_t *)(*(int64_t *)arg2 + uVar9 * 0x18) == *(int64_t *)(arg2 + 0x18));
            goto code_r0x0001800c7497;
        }
        if (iVar11 != 0) {
            fcn.1800f4640(iVar11);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c75a0
// Address: 0x1800c75a0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c75a0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if (*(int64_t *)(arg2 + 8) != *(int64_t *)arg2) {
        iVar7 = *(int64_t *)(arg2 + 8);
        do {
            iVar1 = iVar7 + -0x28;
            if (*(char *)(iVar7 + -8) == '\0') {
                uVar3 = *(undefined4 *)(iVar7 + -0x20);
                uVar4 = *(undefined4 *)(iVar7 + -0x1c);
                uVar5 = *(undefined4 *)(iVar7 + -0x18);
                uVar6 = *(undefined4 *)(iVar7 + -0x14);
                uVar2 = *(undefined8 *)(iVar7 + -0x10);
                puVar8 = (undefined4 *)func_0x0001800c05e0(arg1, iVar1);
                *puVar8 = uVar3;
                puVar8[1] = uVar4;
                puVar8[2] = uVar5;
                puVar8[3] = uVar6;
                *(undefined8 *)(puVar8 + 4) = uVar2;
            } else {
                iVar7 = func_0x0001800c13d0();
                puVar8 = (undefined4 *)(iVar7 + 8);
                if (iVar7 == 0) {
                    puVar8 = (undefined4 *)0x0;
                }
                if (puVar8 != (undefined4 *)0x0) {
                    *puVar8 = 0;
                }
            }
            iVar7 = iVar1;
        } while (iVar1 != *(int64_t *)arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800c75b9
// Address: 0x1800c75b9
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c75a0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if (*(int64_t *)(arg2 + 8) != *(int64_t *)arg2) {
        iVar7 = *(int64_t *)(arg2 + 8);
        do {
            iVar1 = iVar7 + -0x28;
            if (*(char *)(iVar7 + -8) == '\0') {
                uVar3 = *(undefined4 *)(iVar7 + -0x20);
                uVar4 = *(undefined4 *)(iVar7 + -0x1c);
                uVar5 = *(undefined4 *)(iVar7 + -0x18);
                uVar6 = *(undefined4 *)(iVar7 + -0x14);
                uVar2 = *(undefined8 *)(iVar7 + -0x10);
                puVar8 = (undefined4 *)func_0x0001800c05e0(arg1, iVar1);
                *puVar8 = uVar3;
                puVar8[1] = uVar4;
                puVar8[2] = uVar5;
                puVar8[3] = uVar6;
                *(undefined8 *)(puVar8 + 4) = uVar2;
            } else {
                iVar7 = func_0x0001800c13d0();
                puVar8 = (undefined4 *)(iVar7 + 8);
                if (iVar7 == 0) {
                    puVar8 = (undefined4 *)0x0;
                }
                if (puVar8 != (undefined4 *)0x0) {
                    *puVar8 = 0;
                }
            }
            iVar7 = iVar1;
        } while (iVar1 != *(int64_t *)arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800c762b
// Address: 0x1800c762b
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c75a0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if (*(int64_t *)(arg2 + 8) != *(int64_t *)arg2) {
        iVar7 = *(int64_t *)(arg2 + 8);
        do {
            iVar1 = iVar7 + -0x28;
            if (*(char *)(iVar7 + -8) == '\0') {
                uVar3 = *(undefined4 *)(iVar7 + -0x20);
                uVar4 = *(undefined4 *)(iVar7 + -0x1c);
                uVar5 = *(undefined4 *)(iVar7 + -0x18);
                uVar6 = *(undefined4 *)(iVar7 + -0x14);
                uVar2 = *(undefined8 *)(iVar7 + -0x10);
                puVar8 = (undefined4 *)func_0x0001800c05e0(arg1, iVar1);
                *puVar8 = uVar3;
                puVar8[1] = uVar4;
                puVar8[2] = uVar5;
                puVar8[3] = uVar6;
                *(undefined8 *)(puVar8 + 4) = uVar2;
            } else {
                iVar7 = func_0x0001800c13d0();
                puVar8 = (undefined4 *)(iVar7 + 8);
                if (iVar7 == 0) {
                    puVar8 = (undefined4 *)0x0;
                }
                if (puVar8 != (undefined4 *)0x0) {
                    *puVar8 = 0;
                }
            }
            iVar7 = iVar1;
        } while (iVar1 != *(int64_t *)arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800c7640
// Address: 0x1800c7640
// Size: 629 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h

void fcn.1800c7640(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    
    _var_68h = ZEXT816(0);
    _var_58h = ZEXT816(0);
    if ((*(char *)0x180778018 != '\0') && (*(char *)0x180777ff8 == '\0')) {
        var_148h = 0x180640a40;
        var_140h = (int64_t)&var_68h;
        var_138h = arg2;
        (***(code ***)arg_38h)(arg_38h, &var_148h);
    }
    var_b0h = (int64_t)&var_68h;
    if (*(char *)0x180777ff8 != '\0') {
        var_b0h = arg_48h;
    }
    var_128h = 0x180640c50;
    var_100h._0_1_ = (undefined)arg_28h;
    var_f8h = arg_30h;
    var_f0h = arg_40h;
    _var_e8h = ZEXT816(0);
    uVar2 = 0;
    var_d8h = 0;
    _var_c8h = ZEXT816(0);
    var_b8h = 0;
    _var_a8h = ZEXT816(0);
    _var_98h = ZEXT816(0);
    var_80h = arg_50h;
    var_78h = arg_58h;
    if ((*(int64_t *)(arg1 + 0x10) != 0) || (var_d0h._0_1_ = 1, *(int64_t *)(arg3 + 0x10) != 0)) {
        var_d0h._0_1_ = 0;
    }
    var_120h = arg1;
    var_118h = arg2;
    var_110h = arg3;
    var_108h = arg4;
    (***(code ***)arg_38h)(arg_38h, &var_128h);
    if ((*(char *)0x180778018 != '\0') && (*(char *)0x180777ff8 == '\0')) {
        uVar1 = *(uint64_t *)(arg1 + 8);
        uVar3 = uVar2;
        if (uVar1 != 0) {
            do {
                if (*(int64_t *)(uVar3 * 0x20 + *(int64_t *)arg1) != *(int64_t *)(arg1 + 0x18)) break;
                uVar3 = uVar3 + 1;
            } while (uVar3 < uVar1);
        }
code_r0x0001800c77b5:
        if (uVar3 != uVar1) {
            iVar4 = *(int64_t *)arg1;
            if (*(int32_t *)(uVar3 * 0x20 + 8 + iVar4) == 7) {
                *(undefined4 *)(uVar3 * 0x20 + 8 + iVar4) = 0;
                iVar4 = *(int64_t *)arg1;
            }
            do {
                uVar3 = uVar3 + 1;
                if (*(uint64_t *)(arg1 + 8) <= uVar3) break;
            } while (*(int64_t *)(uVar3 * 0x20 + iVar4) == *(int64_t *)(arg1 + 0x18));
            goto code_r0x0001800c77b5;
        }
        uVar1 = *(uint64_t *)(arg3 + 8);
        if (uVar1 != 0) {
            do {
                if (*(int64_t *)(uVar2 * 0x20 + *(int64_t *)arg3) != *(int64_t *)(arg3 + 0x18)) break;
                uVar2 = uVar2 + 1;
            } while (uVar2 < uVar1);
        }
code_r0x0001800c7825:
        if (uVar2 != uVar1) {
            iVar4 = *(int64_t *)arg3;
            if (*(int32_t *)(uVar2 * 0x20 + 8 + iVar4) == 7) {
                *(undefined4 *)(uVar2 * 0x20 + 8 + iVar4) = 0;
                iVar4 = *(int64_t *)arg3;
            }
            do {
                uVar2 = uVar2 + 1;
                if (*(uint64_t *)(arg3 + 8) <= uVar2) break;
            } while (*(int64_t *)(uVar2 * 0x20 + iVar4) == *(int64_t *)(arg3 + 0x18));
            goto code_r0x0001800c7825;
        }
    }
    if (var_a8h != 0) {
        fcn.1800f4640();
        _var_a8h = ZEXT816(0);
    }
    fcn.180028940(&var_c8h);
    fcn.1800c7a90(var_138h);
    var_128h = 0x18063f2c0;
    if (var_68h != 0) {
        fcn.1800f4640();
    }
    return;
}

// ============================================================
// Function: FUN_1800c78c0
// Address: 0x1800c78c0
// Size: 463 bytes
// ============================================================
void fcn.1800c78c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_38h;
    
    var_18h = arg3;
    if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
        if (*(int32_t *)arg4 == 0) {
            if ((((*(char *)(arg1 + 0x58) == '\0') || (*(char *)0x180778018 != '\0')) &&
                (*(int64_t *)(arg2 + 0x10) != 0)) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
                piVar9 = (int64_t *)(*(int64_t *)(arg2 + 8) + -1);
                uVar7 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
                piVar8 = (int64_t *)0x0;
                do {
                    uVar7 = uVar7 & (uint64_t)piVar9;
                    piVar10 = (int64_t *)(uVar7 * 0x20 + *(int64_t *)arg2);
                    if (*piVar10 == arg3) {
                        piVar8 = piVar10 + 1;
                        if (piVar10 == (int64_t *)0x0) {
                            piVar8 = (int64_t *)0x0;
                        }
                        if (piVar8 == (int64_t *)0x0) {
                            return;
                        }
                        *(undefined4 *)piVar8 = 0;
                        return;
                    }
                    if (*piVar10 == *(int64_t *)(arg2 + 0x18)) {
                        return;
                    }
                    uVar7 = uVar7 + 1 + (int64_t)piVar8;
                    piVar8 = (int64_t *)((int64_t)piVar8 + 1);
                } while (piVar8 <= piVar9);
            }
        } else {
            uVar2 = *(undefined4 *)arg4;
            uVar3 = *(undefined4 *)(arg4 + 4);
            uVar4 = *(undefined4 *)(arg4 + 8);
            uVar5 = *(undefined4 *)(arg4 + 0xc);
            uVar1 = *(undefined8 *)(arg4 + 0x10);
            puVar6 = (undefined4 *)func_0x0001800c05e0(arg2, &var_18h);
            *puVar6 = uVar2;
            puVar6[1] = uVar3;
            puVar6[2] = uVar4;
            puVar6[3] = uVar5;
            *(undefined8 *)(puVar6 + 4) = uVar1;
        }
    } else if (*(int32_t *)arg4 != 7) {
        if (*(int32_t *)arg4 == 0) {
            if (((*(char *)(arg1 + 0x58) == '\0') && (*(int64_t *)(arg2 + 0x10) != 0)) &&
               (arg3 != *(int64_t *)(arg2 + 0x18))) {
                piVar9 = (int64_t *)(*(int64_t *)(arg2 + 8) + -1);
                uVar7 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
                piVar8 = (int64_t *)0x0;
                do {
                    uVar7 = uVar7 & (uint64_t)piVar9;
                    piVar10 = (int64_t *)(uVar7 * 0x20 + *(int64_t *)arg2);
                    if (*piVar10 == arg3) {
                        piVar8 = piVar10 + 1;
                        if (piVar10 == (int64_t *)0x0) {
                            piVar8 = (int64_t *)0x0;
                        }
                        if (piVar8 == (int64_t *)0x0) {
                            return;
                        }
                        func_0x0001800c6850(arg1, arg2, arg3, piVar8);
                        *(undefined4 *)piVar8 = 0;
                        return;
                    }
                    if (*piVar10 == *(int64_t *)(arg2 + 0x18)) {
                        return;
                    }
                    uVar7 = uVar7 + 1 + (int64_t)piVar8;
                    piVar8 = (int64_t *)((int64_t)piVar8 + 1);
                } while (piVar8 <= piVar9);
            }
        } else {
            func_0x0001800c6850();
            uVar2 = *(undefined4 *)arg4;
            uVar3 = *(undefined4 *)(arg4 + 4);
            uVar4 = *(undefined4 *)(arg4 + 8);
            uVar5 = *(undefined4 *)(arg4 + 0xc);
            uVar1 = *(undefined8 *)(arg4 + 0x10);
            puVar6 = (undefined4 *)func_0x0001800c05e0(arg2, &var_18h);
            *puVar6 = uVar2;
            puVar6[1] = uVar3;
            puVar6[2] = uVar4;
            puVar6[3] = uVar5;
            *(undefined8 *)(puVar6 + 4) = uVar1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7a90
// Address: 0x1800c7a90
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800c7a90(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)arg1;
    if (piVar5 != (int64_t *)0x0) {
        piVar1 = *(int64_t **)(arg1 + 8);
        for (; piVar5 != piVar1; piVar5 = piVar5 + 5) {
            if (*piVar5 != 0) {
                fcn.1800f4640();
                *piVar5 = 0;
                piVar5[1] = 0;
            }
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        piVar5 = &var_28h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), piVar5 = &var_28h, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            piVar5 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar5 + -8) = 0x1800c7b3c;
        func_0x000180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c7aa9
// Address: 0x1800c7aa9
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800c7a90(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)arg1;
    if (piVar5 != (int64_t *)0x0) {
        piVar1 = *(int64_t **)(arg1 + 8);
        for (; piVar5 != piVar1; piVar5 = piVar5 + 5) {
            if (*piVar5 != 0) {
                fcn.1800f4640();
                *piVar5 = 0;
                piVar5[1] = 0;
            }
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        piVar5 = &var_28h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), piVar5 = &var_28h, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            piVar5 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar5 + -8) = 0x1800c7b3c;
        func_0x000180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c7ab0
// Address: 0x1800c7ab0
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800c7a90(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)arg1;
    if (piVar5 != (int64_t *)0x0) {
        piVar1 = *(int64_t **)(arg1 + 8);
        for (; piVar5 != piVar1; piVar5 = piVar5 + 5) {
            if (*piVar5 != 0) {
                fcn.1800f4640();
                *piVar5 = 0;
                piVar5[1] = 0;
            }
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        piVar5 = &var_28h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), piVar5 = &var_28h, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            piVar5 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar5 + -8) = 0x1800c7b3c;
        func_0x000180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c7b13
// Address: 0x1800c7b13
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800c7a90(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)arg1;
    if (piVar5 != (int64_t *)0x0) {
        piVar1 = *(int64_t **)(arg1 + 8);
        for (; piVar5 != piVar1; piVar5 = piVar5 + 5) {
            if (*piVar5 != 0) {
                fcn.1800f4640();
                *piVar5 = 0;
                piVar5[1] = 0;
            }
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        piVar5 = &var_28h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), piVar5 = &var_28h, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            piVar5 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar5 + -8) = 0x1800c7b3c;
        func_0x000180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c7b4c
// Address: 0x1800c7b4c
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800c7a90(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)arg1;
    if (piVar5 != (int64_t *)0x0) {
        piVar1 = *(int64_t **)(arg1 + 8);
        for (; piVar5 != piVar1; piVar5 = piVar5 + 5) {
            if (*piVar5 != 0) {
                fcn.1800f4640();
                *piVar5 = 0;
                piVar5[1] = 0;
            }
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        piVar5 = &var_28h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), piVar5 = &var_28h, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            piVar5 = (int64_t *)auStack_20;
        }
        *(undefined8 *)((int64_t)piVar5 + -8) = 0x1800c7b3c;
        func_0x000180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c7b60
// Address: 0x1800c7b60
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t * fcn.1800c7b60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t *puVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)arg2;
    uVar5 = *(int64_t *)(arg1 + 8) - 1;
    uVar2 = (uVar1 >> 5 ^ uVar1) >> 4;
    uVar3 = 0;
    while( true ) {
        uVar2 = uVar2 & uVar5;
        puVar4 = (uint64_t *)(uVar2 * 0x20 + *(int64_t *)arg1);
        if (*puVar4 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar4 = uVar1;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar4;
        }
        if (*puVar4 == uVar1) break;
        uVar2 = uVar2 + 1 + uVar3;
        uVar3 = uVar3 + 1;
        if (uVar5 < uVar3) {
            return (uint64_t *)0x0;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1800c7bf0
// Address: 0x1800c7bf0
// Size: 140 bytes
// ============================================================
int64_t fcn.1800c7bf0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    
    uVar3 = 0;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)arg2;
    if (arg3 != 0) {
        iVar1 = func_0x000180459890(arg3 << 5);
        *(int64_t *)arg1 = iVar1;
        *(int64_t *)(arg1 + 8) = arg3;
        if (arg3 != 0) {
            do {
                iVar2 = uVar3 * 0x20;
                uVar3 = uVar3 + 1;
                *(undefined8 *)(iVar2 + iVar1) = *(undefined8 *)arg2;
                *(undefined (*) [16])(iVar2 + 8 + iVar1) = ZEXT816(0);
                *(undefined8 *)(iVar2 + 0x18 + iVar1) = 0;
                *(undefined8 *)(iVar2 + 8 + iVar1) = 0;
                *(undefined8 *)(iVar2 + 0x10 + iVar1) = 0;
            } while (uVar3 < (uint64_t)arg3);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c7c80
// Address: 0x1800c7c80
// Size: 151 bytes
// ============================================================
void fcn.1800c7c80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar2 = uVar4;
        puVar3 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_48;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_40;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x1800c7cf2;
        func_0x000180459c3c(uVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg2 + arg3 * 0x18;
    *(int64_t *)(arg1 + 0x10) = arg2 + arg4 * 0x18;
    return;
}

// ============================================================
// Function: FUN_1800c7d20
// Address: 0x1800c7d20
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c7d20(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar9 = &var_28h;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    piVar1 = *(int64_t **)(arg1 + 0x20);
    for (piVar8 = *(int64_t **)(arg1 + 0x18); piVar8 != piVar1; piVar8 = piVar8 + 5) {
        if (*piVar8 != 0) {
            fcn.1800f4640();
            *piVar8 = 0;
            piVar8[1] = 0;
        }
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x28)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar9 = (int64_t *)auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)((int64_t)piVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = fcn.18046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7d34
// Address: 0x1800c7d34
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c7d20(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar9 = &var_28h;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    piVar1 = *(int64_t **)(arg1 + 0x20);
    for (piVar8 = *(int64_t **)(arg1 + 0x18); piVar8 != piVar1; piVar8 = piVar8 + 5) {
        if (*piVar8 != 0) {
            fcn.1800f4640();
            *piVar8 = 0;
            piVar8[1] = 0;
        }
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x28)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar9 = (int64_t *)auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)((int64_t)piVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = fcn.18046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7d4b
// Address: 0x1800c7d4b
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c7d20(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar9 = &var_28h;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    piVar1 = *(int64_t **)(arg1 + 0x20);
    for (piVar8 = *(int64_t **)(arg1 + 0x18); piVar8 != piVar1; piVar8 = piVar8 + 5) {
        if (*piVar8 != 0) {
            fcn.1800f4640();
            *piVar8 = 0;
            piVar8[1] = 0;
        }
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x28)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar9 = (int64_t *)auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)((int64_t)piVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = fcn.18046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7d74
// Address: 0x1800c7d74
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c7d20(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar9 = &var_28h;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    piVar1 = *(int64_t **)(arg1 + 0x20);
    for (piVar8 = *(int64_t **)(arg1 + 0x18); piVar8 != piVar1; piVar8 = piVar8 + 5) {
        if (*piVar8 != 0) {
            fcn.1800f4640();
            *piVar8 = 0;
            piVar8[1] = 0;
        }
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x28)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar9 = (int64_t *)auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)((int64_t)piVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = fcn.18046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7d9b
// Address: 0x1800c7d9b
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c7d20(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_20 [24];
    
    piVar9 = &var_28h;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    piVar1 = *(int64_t **)(arg1 + 0x20);
    for (piVar8 = *(int64_t **)(arg1 + 0x18); piVar8 != piVar1; piVar8 = piVar8 + 5) {
        if (*piVar8 != 0) {
            fcn.1800f4640();
            *piVar8 = 0;
            piVar8[1] = 0;
        }
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x28)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        piVar9 = (int64_t *)auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)((int64_t)piVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = fcn.18046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)fcn.18046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7de0
// Address: 0x1800c7de0
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c7de0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(arg1 + 8);
    for (piVar2 = *(int64_t **)arg1; piVar2 != piVar1; piVar2 = piVar2 + 5) {
        if (*piVar2 != 0) {
            fcn.1800f4640();
            *piVar2 = 0;
            piVar2[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7df6
// Address: 0x1800c7df6
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c7de0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(arg1 + 8);
    for (piVar2 = *(int64_t **)arg1; piVar2 != piVar1; piVar2 = piVar2 + 5) {
        if (*piVar2 != 0) {
            fcn.1800f4640();
            *piVar2 = 0;
            piVar2[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7e22
// Address: 0x1800c7e22
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c7de0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(arg1 + 8);
    for (piVar2 = *(int64_t **)arg1; piVar2 != piVar1; piVar2 = piVar2 + 5) {
        if (*piVar2 != 0) {
            fcn.1800f4640();
            *piVar2 = 0;
            piVar2[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c7e30
// Address: 0x1800c7e30
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800c7e30(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)arg2;
    iVar2 = *(int64_t *)arg3;
    uVar4 = iVar1 + iVar2 & 0x8080808080808080;
    uVar5 = *(uint64_t *)(arg2 + 8) & *(uint64_t *)(arg3 + 8);
    *(uint64_t *)(arg1 + 8) = uVar5;
    uVar3 = uVar5 & 0x101010101010100 | 1;
    if (uVar5 == 0xffffffffffffffff) {
        uVar3 = 0;
    }
    uVar3 = uVar3 + (uVar4 - (uVar4 >> 7) | uVar4 ^ iVar1 + iVar2);
    uVar4 = uVar3 & 0x8080808080808080;
    *(uint64_t *)arg1 = uVar4 - (uVar4 >> 7) | uVar4 ^ uVar3;
    return arg1;
}

// ============================================================
// Function: FUN_1800c7ec0
// Address: 0x1800c7ec0
// Size: 576 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c7ec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int32_t **ppiVar8;
    int32_t **ppiVar9;
    int32_t **ppiVar10;
    int32_t **ppiVar11;
    int64_t *piVar12;
    int32_t *piVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    ppiVar10 = (int32_t **)0x0;
    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 != '\0')) {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
                if (*piVar12 == arg3) {
                    ppiVar8 = (int32_t **)(piVar12 + 1);
                    if (piVar12 == (int64_t *)0x0) {
                        ppiVar8 = ppiVar10;
                    }
                    bVar14 = ppiVar8 == (int32_t **)0x0;
                    goto code_r0x0001800c7fe8;
                }
                if (*piVar12 == piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
                ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
            } while (ppiVar8 <= (int32_t **)(piVar3[1] + -1));
        }
    } else {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
code_r0x0001800c7f30:
            uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
            piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
            if (*piVar12 == arg3) {
                ppiVar8 = (int32_t **)(piVar12 + 1);
                if (piVar12 == (int64_t *)0x0) {
                    ppiVar8 = ppiVar10;
                }
                if (ppiVar8 != (int32_t **)0x0) {
                    bVar14 = *(int32_t *)ppiVar8 == 0;
code_r0x0001800c7fe8:
                    if (!bVar14) goto code_r0x0001800c86bb;
                }
            } else if (*piVar12 != piVar3[3]) goto code_r0x0001800c7f4b;
        }
    }
code_r0x0001800c7fee:
    iVar1 = *(int32_t *)(arg3 + 8);
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826c0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
        return arg2;
    }
    if ((((iVar1 == *(int32_t *)0x180782670) || (iVar1 == *(int32_t *)0x1807826cc)) ||
        (iVar1 == *(int32_t *)0x1807826b4)) ||
       ((iVar1 == *(int32_t *)0x18078273c || (iVar1 == *(int32_t *)0x18078271c)))) {
code_r0x0001800c86bb:
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0xffffffffffffffff;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782728) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        iVar2 = func_0x0001800ac7f0(arg1 + 0x18, ppiVar8 + 4);
        ppiVar8 = (int32_t **)(iVar2 + 8);
        if (iVar2 == 0) {
            ppiVar8 = ppiVar10;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        *(int32_t **)(arg2 + 8) = *ppiVar8;
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x180782738) {
        *(undefined8 *)arg2 = 1;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x1807826b8) {
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)arg2 = 3;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782740) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = *(int64_t **)(arg1 + 8);
        if ((piVar3[2] != 0) && (ppiVar8 != (int32_t **)piVar3[3])) {
            uVar6 = ((uint64_t)ppiVar8 >> 5 ^ (uint64_t)ppiVar8) >> 4;
            ppiVar9 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                ppiVar11 = (int32_t **)(uVar6 * 0x10 + *piVar3);
                if ((int32_t **)*ppiVar11 == ppiVar8) {
                    ppiVar9 = ppiVar11 + 1;
                    if (ppiVar11 == (int32_t **)0x0) {
                        ppiVar9 = ppiVar10;
                    }
                    if ((ppiVar9 != (int32_t **)0x0) && (*(int32_t *)ppiVar9 != 0)) {
                        if ((int32_t *)((uint64_t)(*(char *)0x180778038 != '\0') + 2) < ppiVar8[8]) {
                            bVar14 = true;
                            ppiVar9 = ppiVar10;
                            goto code_r0x0001800c81a7;
                        }
                        ppiVar10 = (int32_t **)0x1;
                        uVar6 = 2;
                        goto code_r0x0001800c81e7;
                    }
                    break;
                }
                if ((int32_t **)*ppiVar11 == (int32_t **)piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar9;
                ppiVar9 = (int32_t **)((int64_t)ppiVar9 + 1);
            } while (ppiVar9 <= (int32_t **)(piVar3[1] + -1));
        }
        bVar14 = false;
        ppiVar9 = (int32_t **)0x1;
code_r0x0001800c81a7:
        uVar6 = (int64_t)ppiVar9 + 2;
        if (!bVar14) {
            piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
            uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
            uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
        }
code_r0x0001800c81e7:
        piVar13 = (int32_t *)0x0;
        if (ppiVar8[8] != (int32_t *)0x0) {
            do {
                fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(ppiVar8[7] + (int64_t)piVar13 * 2));
                iVar2 = var_58h;
                if ((var_58h == 0) && ((char)ppiVar10 == '\0')) {
                    iVar2 = 1;
                }
                piVar13 = (int32_t *)((int64_t)piVar13 + 1);
                uVar7 = iVar2 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ iVar2 + uVar6;
            } while (piVar13 < ppiVar8[8]);
        }
        *(uint64_t *)arg2 = uVar6;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x18078269c) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        uVar6 = *piVar3 + 1U & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar6 ^ *piVar3 + 1U;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782730) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
        uVar6 = *piVar3 + *piVar12 & 0x8080808080808080;
        uVar6 = (uVar6 ^ *piVar3 + *piVar12 | uVar6 - (uVar6 >> 7)) + 1;
        uVar7 = uVar6 & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
        goto code_r0x0001800c83b3;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826a0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 == (int32_t **)0x0) {
        ppiVar8 = ppiVar10;
        if (iVar1 == *(int32_t *)0x180782758) {
            ppiVar8 = (int32_t **)arg3;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782768) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                var_58h = 0;
                var_50h = -1;
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar2, (int64_t)&var_58h);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782668) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[6]);
                iVar4 = fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar4, iVar2);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782708) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
code_r0x0001800c869f:
                fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078270c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[4]);
                piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[6]);
                iVar2 = *piVar3;
                iVar4 = *piVar12;
                uVar6 = iVar2 + iVar4 & 0x8080808080808080;
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, (int64_t)ppiVar8[8]);
                uVar7 = (uVar6 - (uVar6 >> 7) | uVar6 ^ iVar2 + iVar4) + *piVar3;
                uVar6 = uVar7 & 0x8080808080808080;
                uVar7 = (uVar7 ^ uVar6 | uVar6 - (uVar6 >> 7)) + 2;
                uVar6 = uVar7 & 0x8080808080808080;
                *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar7 ^ uVar6;
                goto code_r0x0001800c83b3;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078275c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 == (int32_t **)0x0) {
                ppiVar8 = ppiVar10;
                if (iVar1 == *(int32_t *)0x180782674) {
                    ppiVar8 = (int32_t **)arg3;
                }
                if (ppiVar8 != (int32_t **)0x0) goto code_r0x0001800c869f;
                *(undefined8 *)arg2 = 0;
                goto code_r0x0001800c83b3;
            }
            piVar12 = (int64_t *)ppiVar8[6];
            uVar6 = 3;
            piVar3 = piVar12 + (int64_t)ppiVar8[7];
            for (; piVar12 != piVar3; piVar12 = piVar12 + 1) {
                piVar5 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, *piVar12);
                uVar7 = *piVar5 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar5 + uVar6;
            }
        } else {
            uVar6 = 10;
            if (ppiVar8[5] != (int32_t *)0x0) {
                do {
                    piVar13 = ppiVar8[4];
                    iVar2 = *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 2);
                    if (iVar2 != 0) {
                        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, iVar2);
                        uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                        uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
                    }
                    piVar3 = (int64_t *)
                             fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 4));
                    ppiVar10 = (int32_t **)((int64_t)ppiVar10 + 1);
                    uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                    uVar6 = (uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6) + 1;
                    uVar7 = uVar6 & 0x8080808080808080;
                    uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
                } while (ppiVar10 < ppiVar8[5]);
            }
        }
    } else {
        uVar6 = 10;
    }
    *(uint64_t *)arg2 = uVar6;
code_r0x0001800c83b3:
    *(undefined8 *)(arg2 + 8) = 0;
    return arg2;
code_r0x0001800c7f4b:
    uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
    ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
    if ((int32_t **)(piVar3[1] + -1) < ppiVar8) goto code_r0x0001800c7fee;
    goto code_r0x0001800c7f30;
}

// ============================================================
// Function: FUN_1800c8100
// Address: 0x1800c8100
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c7ec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int32_t **ppiVar8;
    int32_t **ppiVar9;
    int32_t **ppiVar10;
    int32_t **ppiVar11;
    int64_t *piVar12;
    int32_t *piVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    ppiVar10 = (int32_t **)0x0;
    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 != '\0')) {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
                if (*piVar12 == arg3) {
                    ppiVar8 = (int32_t **)(piVar12 + 1);
                    if (piVar12 == (int64_t *)0x0) {
                        ppiVar8 = ppiVar10;
                    }
                    bVar14 = ppiVar8 == (int32_t **)0x0;
                    goto code_r0x0001800c7fe8;
                }
                if (*piVar12 == piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
                ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
            } while (ppiVar8 <= (int32_t **)(piVar3[1] + -1));
        }
    } else {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
code_r0x0001800c7f30:
            uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
            piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
            if (*piVar12 == arg3) {
                ppiVar8 = (int32_t **)(piVar12 + 1);
                if (piVar12 == (int64_t *)0x0) {
                    ppiVar8 = ppiVar10;
                }
                if (ppiVar8 != (int32_t **)0x0) {
                    bVar14 = *(int32_t *)ppiVar8 == 0;
code_r0x0001800c7fe8:
                    if (!bVar14) goto code_r0x0001800c86bb;
                }
            } else if (*piVar12 != piVar3[3]) goto code_r0x0001800c7f4b;
        }
    }
code_r0x0001800c7fee:
    iVar1 = *(int32_t *)(arg3 + 8);
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826c0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
        return arg2;
    }
    if ((((iVar1 == *(int32_t *)0x180782670) || (iVar1 == *(int32_t *)0x1807826cc)) ||
        (iVar1 == *(int32_t *)0x1807826b4)) ||
       ((iVar1 == *(int32_t *)0x18078273c || (iVar1 == *(int32_t *)0x18078271c)))) {
code_r0x0001800c86bb:
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0xffffffffffffffff;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782728) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        iVar2 = func_0x0001800ac7f0(arg1 + 0x18, ppiVar8 + 4);
        ppiVar8 = (int32_t **)(iVar2 + 8);
        if (iVar2 == 0) {
            ppiVar8 = ppiVar10;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        *(int32_t **)(arg2 + 8) = *ppiVar8;
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x180782738) {
        *(undefined8 *)arg2 = 1;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x1807826b8) {
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)arg2 = 3;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782740) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = *(int64_t **)(arg1 + 8);
        if ((piVar3[2] != 0) && (ppiVar8 != (int32_t **)piVar3[3])) {
            uVar6 = ((uint64_t)ppiVar8 >> 5 ^ (uint64_t)ppiVar8) >> 4;
            ppiVar9 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                ppiVar11 = (int32_t **)(uVar6 * 0x10 + *piVar3);
                if ((int32_t **)*ppiVar11 == ppiVar8) {
                    ppiVar9 = ppiVar11 + 1;
                    if (ppiVar11 == (int32_t **)0x0) {
                        ppiVar9 = ppiVar10;
                    }
                    if ((ppiVar9 != (int32_t **)0x0) && (*(int32_t *)ppiVar9 != 0)) {
                        if ((int32_t *)((uint64_t)(*(char *)0x180778038 != '\0') + 2) < ppiVar8[8]) {
                            bVar14 = true;
                            ppiVar9 = ppiVar10;
                            goto code_r0x0001800c81a7;
                        }
                        ppiVar10 = (int32_t **)0x1;
                        uVar6 = 2;
                        goto code_r0x0001800c81e7;
                    }
                    break;
                }
                if ((int32_t **)*ppiVar11 == (int32_t **)piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar9;
                ppiVar9 = (int32_t **)((int64_t)ppiVar9 + 1);
            } while (ppiVar9 <= (int32_t **)(piVar3[1] + -1));
        }
        bVar14 = false;
        ppiVar9 = (int32_t **)0x1;
code_r0x0001800c81a7:
        uVar6 = (int64_t)ppiVar9 + 2;
        if (!bVar14) {
            piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
            uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
            uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
        }
code_r0x0001800c81e7:
        piVar13 = (int32_t *)0x0;
        if (ppiVar8[8] != (int32_t *)0x0) {
            do {
                fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(ppiVar8[7] + (int64_t)piVar13 * 2));
                iVar2 = var_58h;
                if ((var_58h == 0) && ((char)ppiVar10 == '\0')) {
                    iVar2 = 1;
                }
                piVar13 = (int32_t *)((int64_t)piVar13 + 1);
                uVar7 = iVar2 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ iVar2 + uVar6;
            } while (piVar13 < ppiVar8[8]);
        }
        *(uint64_t *)arg2 = uVar6;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x18078269c) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        uVar6 = *piVar3 + 1U & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar6 ^ *piVar3 + 1U;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782730) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
        uVar6 = *piVar3 + *piVar12 & 0x8080808080808080;
        uVar6 = (uVar6 ^ *piVar3 + *piVar12 | uVar6 - (uVar6 >> 7)) + 1;
        uVar7 = uVar6 & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
        goto code_r0x0001800c83b3;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826a0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 == (int32_t **)0x0) {
        ppiVar8 = ppiVar10;
        if (iVar1 == *(int32_t *)0x180782758) {
            ppiVar8 = (int32_t **)arg3;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782768) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                var_58h = 0;
                var_50h = -1;
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar2, (int64_t)&var_58h);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782668) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[6]);
                iVar4 = fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar4, iVar2);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782708) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
code_r0x0001800c869f:
                fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078270c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[4]);
                piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[6]);
                iVar2 = *piVar3;
                iVar4 = *piVar12;
                uVar6 = iVar2 + iVar4 & 0x8080808080808080;
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, (int64_t)ppiVar8[8]);
                uVar7 = (uVar6 - (uVar6 >> 7) | uVar6 ^ iVar2 + iVar4) + *piVar3;
                uVar6 = uVar7 & 0x8080808080808080;
                uVar7 = (uVar7 ^ uVar6 | uVar6 - (uVar6 >> 7)) + 2;
                uVar6 = uVar7 & 0x8080808080808080;
                *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar7 ^ uVar6;
                goto code_r0x0001800c83b3;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078275c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 == (int32_t **)0x0) {
                ppiVar8 = ppiVar10;
                if (iVar1 == *(int32_t *)0x180782674) {
                    ppiVar8 = (int32_t **)arg3;
                }
                if (ppiVar8 != (int32_t **)0x0) goto code_r0x0001800c869f;
                *(undefined8 *)arg2 = 0;
                goto code_r0x0001800c83b3;
            }
            piVar12 = (int64_t *)ppiVar8[6];
            uVar6 = 3;
            piVar3 = piVar12 + (int64_t)ppiVar8[7];
            for (; piVar12 != piVar3; piVar12 = piVar12 + 1) {
                piVar5 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, *piVar12);
                uVar7 = *piVar5 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar5 + uVar6;
            }
        } else {
            uVar6 = 10;
            if (ppiVar8[5] != (int32_t *)0x0) {
                do {
                    piVar13 = ppiVar8[4];
                    iVar2 = *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 2);
                    if (iVar2 != 0) {
                        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, iVar2);
                        uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                        uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
                    }
                    piVar3 = (int64_t *)
                             fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 4));
                    ppiVar10 = (int32_t **)((int64_t)ppiVar10 + 1);
                    uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                    uVar6 = (uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6) + 1;
                    uVar7 = uVar6 & 0x8080808080808080;
                    uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
                } while (ppiVar10 < ppiVar8[5]);
            }
        }
    } else {
        uVar6 = 10;
    }
    *(uint64_t *)arg2 = uVar6;
code_r0x0001800c83b3:
    *(undefined8 *)(arg2 + 8) = 0;
    return arg2;
code_r0x0001800c7f4b:
    uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
    ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
    if ((int32_t **)(piVar3[1] + -1) < ppiVar8) goto code_r0x0001800c7fee;
    goto code_r0x0001800c7f30;
}

// ============================================================
// Function: FUN_1800c8133
// Address: 0x1800c8133
// Size: 308 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c7ec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int32_t **ppiVar8;
    int32_t **ppiVar9;
    int32_t **ppiVar10;
    int32_t **ppiVar11;
    int64_t *piVar12;
    int32_t *piVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    ppiVar10 = (int32_t **)0x0;
    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 != '\0')) {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
                if (*piVar12 == arg3) {
                    ppiVar8 = (int32_t **)(piVar12 + 1);
                    if (piVar12 == (int64_t *)0x0) {
                        ppiVar8 = ppiVar10;
                    }
                    bVar14 = ppiVar8 == (int32_t **)0x0;
                    goto code_r0x0001800c7fe8;
                }
                if (*piVar12 == piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
                ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
            } while (ppiVar8 <= (int32_t **)(piVar3[1] + -1));
        }
    } else {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
code_r0x0001800c7f30:
            uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
            piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
            if (*piVar12 == arg3) {
                ppiVar8 = (int32_t **)(piVar12 + 1);
                if (piVar12 == (int64_t *)0x0) {
                    ppiVar8 = ppiVar10;
                }
                if (ppiVar8 != (int32_t **)0x0) {
                    bVar14 = *(int32_t *)ppiVar8 == 0;
code_r0x0001800c7fe8:
                    if (!bVar14) goto code_r0x0001800c86bb;
                }
            } else if (*piVar12 != piVar3[3]) goto code_r0x0001800c7f4b;
        }
    }
code_r0x0001800c7fee:
    iVar1 = *(int32_t *)(arg3 + 8);
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826c0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
        return arg2;
    }
    if ((((iVar1 == *(int32_t *)0x180782670) || (iVar1 == *(int32_t *)0x1807826cc)) ||
        (iVar1 == *(int32_t *)0x1807826b4)) ||
       ((iVar1 == *(int32_t *)0x18078273c || (iVar1 == *(int32_t *)0x18078271c)))) {
code_r0x0001800c86bb:
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0xffffffffffffffff;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782728) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        iVar2 = func_0x0001800ac7f0(arg1 + 0x18, ppiVar8 + 4);
        ppiVar8 = (int32_t **)(iVar2 + 8);
        if (iVar2 == 0) {
            ppiVar8 = ppiVar10;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        *(int32_t **)(arg2 + 8) = *ppiVar8;
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x180782738) {
        *(undefined8 *)arg2 = 1;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x1807826b8) {
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)arg2 = 3;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782740) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = *(int64_t **)(arg1 + 8);
        if ((piVar3[2] != 0) && (ppiVar8 != (int32_t **)piVar3[3])) {
            uVar6 = ((uint64_t)ppiVar8 >> 5 ^ (uint64_t)ppiVar8) >> 4;
            ppiVar9 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                ppiVar11 = (int32_t **)(uVar6 * 0x10 + *piVar3);
                if ((int32_t **)*ppiVar11 == ppiVar8) {
                    ppiVar9 = ppiVar11 + 1;
                    if (ppiVar11 == (int32_t **)0x0) {
                        ppiVar9 = ppiVar10;
                    }
                    if ((ppiVar9 != (int32_t **)0x0) && (*(int32_t *)ppiVar9 != 0)) {
                        if ((int32_t *)((uint64_t)(*(char *)0x180778038 != '\0') + 2) < ppiVar8[8]) {
                            bVar14 = true;
                            ppiVar9 = ppiVar10;
                            goto code_r0x0001800c81a7;
                        }
                        ppiVar10 = (int32_t **)0x1;
                        uVar6 = 2;
                        goto code_r0x0001800c81e7;
                    }
                    break;
                }
                if ((int32_t **)*ppiVar11 == (int32_t **)piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar9;
                ppiVar9 = (int32_t **)((int64_t)ppiVar9 + 1);
            } while (ppiVar9 <= (int32_t **)(piVar3[1] + -1));
        }
        bVar14 = false;
        ppiVar9 = (int32_t **)0x1;
code_r0x0001800c81a7:
        uVar6 = (int64_t)ppiVar9 + 2;
        if (!bVar14) {
            piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
            uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
            uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
        }
code_r0x0001800c81e7:
        piVar13 = (int32_t *)0x0;
        if (ppiVar8[8] != (int32_t *)0x0) {
            do {
                fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(ppiVar8[7] + (int64_t)piVar13 * 2));
                iVar2 = var_58h;
                if ((var_58h == 0) && ((char)ppiVar10 == '\0')) {
                    iVar2 = 1;
                }
                piVar13 = (int32_t *)((int64_t)piVar13 + 1);
                uVar7 = iVar2 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ iVar2 + uVar6;
            } while (piVar13 < ppiVar8[8]);
        }
        *(uint64_t *)arg2 = uVar6;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x18078269c) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        uVar6 = *piVar3 + 1U & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar6 ^ *piVar3 + 1U;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782730) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
        uVar6 = *piVar3 + *piVar12 & 0x8080808080808080;
        uVar6 = (uVar6 ^ *piVar3 + *piVar12 | uVar6 - (uVar6 >> 7)) + 1;
        uVar7 = uVar6 & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
        goto code_r0x0001800c83b3;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826a0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 == (int32_t **)0x0) {
        ppiVar8 = ppiVar10;
        if (iVar1 == *(int32_t *)0x180782758) {
            ppiVar8 = (int32_t **)arg3;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782768) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                var_58h = 0;
                var_50h = -1;
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar2, (int64_t)&var_58h);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782668) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[6]);
                iVar4 = fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar4, iVar2);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782708) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
code_r0x0001800c869f:
                fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078270c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[4]);
                piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[6]);
                iVar2 = *piVar3;
                iVar4 = *piVar12;
                uVar6 = iVar2 + iVar4 & 0x8080808080808080;
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, (int64_t)ppiVar8[8]);
                uVar7 = (uVar6 - (uVar6 >> 7) | uVar6 ^ iVar2 + iVar4) + *piVar3;
                uVar6 = uVar7 & 0x8080808080808080;
                uVar7 = (uVar7 ^ uVar6 | uVar6 - (uVar6 >> 7)) + 2;
                uVar6 = uVar7 & 0x8080808080808080;
                *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar7 ^ uVar6;
                goto code_r0x0001800c83b3;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078275c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 == (int32_t **)0x0) {
                ppiVar8 = ppiVar10;
                if (iVar1 == *(int32_t *)0x180782674) {
                    ppiVar8 = (int32_t **)arg3;
                }
                if (ppiVar8 != (int32_t **)0x0) goto code_r0x0001800c869f;
                *(undefined8 *)arg2 = 0;
                goto code_r0x0001800c83b3;
            }
            piVar12 = (int64_t *)ppiVar8[6];
            uVar6 = 3;
            piVar3 = piVar12 + (int64_t)ppiVar8[7];
            for (; piVar12 != piVar3; piVar12 = piVar12 + 1) {
                piVar5 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, *piVar12);
                uVar7 = *piVar5 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar5 + uVar6;
            }
        } else {
            uVar6 = 10;
            if (ppiVar8[5] != (int32_t *)0x0) {
                do {
                    piVar13 = ppiVar8[4];
                    iVar2 = *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 2);
                    if (iVar2 != 0) {
                        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, iVar2);
                        uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                        uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
                    }
                    piVar3 = (int64_t *)
                             fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 4));
                    ppiVar10 = (int32_t **)((int64_t)ppiVar10 + 1);
                    uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                    uVar6 = (uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6) + 1;
                    uVar7 = uVar6 & 0x8080808080808080;
                    uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
                } while (ppiVar10 < ppiVar8[5]);
            }
        }
    } else {
        uVar6 = 10;
    }
    *(uint64_t *)arg2 = uVar6;
code_r0x0001800c83b3:
    *(undefined8 *)(arg2 + 8) = 0;
    return arg2;
code_r0x0001800c7f4b:
    uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
    ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
    if ((int32_t **)(piVar3[1] + -1) < ppiVar8) goto code_r0x0001800c7fee;
    goto code_r0x0001800c7f30;
}

// ============================================================
// Function: FUN_1800c8267
// Address: 0x1800c8267
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c7ec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int32_t **ppiVar8;
    int32_t **ppiVar9;
    int32_t **ppiVar10;
    int32_t **ppiVar11;
    int64_t *piVar12;
    int32_t *piVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    ppiVar10 = (int32_t **)0x0;
    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 != '\0')) {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
                if (*piVar12 == arg3) {
                    ppiVar8 = (int32_t **)(piVar12 + 1);
                    if (piVar12 == (int64_t *)0x0) {
                        ppiVar8 = ppiVar10;
                    }
                    bVar14 = ppiVar8 == (int32_t **)0x0;
                    goto code_r0x0001800c7fe8;
                }
                if (*piVar12 == piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
                ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
            } while (ppiVar8 <= (int32_t **)(piVar3[1] + -1));
        }
    } else {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
code_r0x0001800c7f30:
            uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
            piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
            if (*piVar12 == arg3) {
                ppiVar8 = (int32_t **)(piVar12 + 1);
                if (piVar12 == (int64_t *)0x0) {
                    ppiVar8 = ppiVar10;
                }
                if (ppiVar8 != (int32_t **)0x0) {
                    bVar14 = *(int32_t *)ppiVar8 == 0;
code_r0x0001800c7fe8:
                    if (!bVar14) goto code_r0x0001800c86bb;
                }
            } else if (*piVar12 != piVar3[3]) goto code_r0x0001800c7f4b;
        }
    }
code_r0x0001800c7fee:
    iVar1 = *(int32_t *)(arg3 + 8);
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826c0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
        return arg2;
    }
    if ((((iVar1 == *(int32_t *)0x180782670) || (iVar1 == *(int32_t *)0x1807826cc)) ||
        (iVar1 == *(int32_t *)0x1807826b4)) ||
       ((iVar1 == *(int32_t *)0x18078273c || (iVar1 == *(int32_t *)0x18078271c)))) {
code_r0x0001800c86bb:
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0xffffffffffffffff;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782728) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        iVar2 = func_0x0001800ac7f0(arg1 + 0x18, ppiVar8 + 4);
        ppiVar8 = (int32_t **)(iVar2 + 8);
        if (iVar2 == 0) {
            ppiVar8 = ppiVar10;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        *(int32_t **)(arg2 + 8) = *ppiVar8;
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x180782738) {
        *(undefined8 *)arg2 = 1;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x1807826b8) {
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)arg2 = 3;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782740) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = *(int64_t **)(arg1 + 8);
        if ((piVar3[2] != 0) && (ppiVar8 != (int32_t **)piVar3[3])) {
            uVar6 = ((uint64_t)ppiVar8 >> 5 ^ (uint64_t)ppiVar8) >> 4;
            ppiVar9 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                ppiVar11 = (int32_t **)(uVar6 * 0x10 + *piVar3);
                if ((int32_t **)*ppiVar11 == ppiVar8) {
                    ppiVar9 = ppiVar11 + 1;
                    if (ppiVar11 == (int32_t **)0x0) {
                        ppiVar9 = ppiVar10;
                    }
                    if ((ppiVar9 != (int32_t **)0x0) && (*(int32_t *)ppiVar9 != 0)) {
                        if ((int32_t *)((uint64_t)(*(char *)0x180778038 != '\0') + 2) < ppiVar8[8]) {
                            bVar14 = true;
                            ppiVar9 = ppiVar10;
                            goto code_r0x0001800c81a7;
                        }
                        ppiVar10 = (int32_t **)0x1;
                        uVar6 = 2;
                        goto code_r0x0001800c81e7;
                    }
                    break;
                }
                if ((int32_t **)*ppiVar11 == (int32_t **)piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar9;
                ppiVar9 = (int32_t **)((int64_t)ppiVar9 + 1);
            } while (ppiVar9 <= (int32_t **)(piVar3[1] + -1));
        }
        bVar14 = false;
        ppiVar9 = (int32_t **)0x1;
code_r0x0001800c81a7:
        uVar6 = (int64_t)ppiVar9 + 2;
        if (!bVar14) {
            piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
            uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
            uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
        }
code_r0x0001800c81e7:
        piVar13 = (int32_t *)0x0;
        if (ppiVar8[8] != (int32_t *)0x0) {
            do {
                fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(ppiVar8[7] + (int64_t)piVar13 * 2));
                iVar2 = var_58h;
                if ((var_58h == 0) && ((char)ppiVar10 == '\0')) {
                    iVar2 = 1;
                }
                piVar13 = (int32_t *)((int64_t)piVar13 + 1);
                uVar7 = iVar2 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ iVar2 + uVar6;
            } while (piVar13 < ppiVar8[8]);
        }
        *(uint64_t *)arg2 = uVar6;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x18078269c) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        uVar6 = *piVar3 + 1U & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar6 ^ *piVar3 + 1U;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782730) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
        uVar6 = *piVar3 + *piVar12 & 0x8080808080808080;
        uVar6 = (uVar6 ^ *piVar3 + *piVar12 | uVar6 - (uVar6 >> 7)) + 1;
        uVar7 = uVar6 & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
        goto code_r0x0001800c83b3;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826a0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 == (int32_t **)0x0) {
        ppiVar8 = ppiVar10;
        if (iVar1 == *(int32_t *)0x180782758) {
            ppiVar8 = (int32_t **)arg3;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782768) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                var_58h = 0;
                var_50h = -1;
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar2, (int64_t)&var_58h);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782668) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[6]);
                iVar4 = fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar4, iVar2);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782708) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
code_r0x0001800c869f:
                fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078270c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[4]);
                piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[6]);
                iVar2 = *piVar3;
                iVar4 = *piVar12;
                uVar6 = iVar2 + iVar4 & 0x8080808080808080;
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, (int64_t)ppiVar8[8]);
                uVar7 = (uVar6 - (uVar6 >> 7) | uVar6 ^ iVar2 + iVar4) + *piVar3;
                uVar6 = uVar7 & 0x8080808080808080;
                uVar7 = (uVar7 ^ uVar6 | uVar6 - (uVar6 >> 7)) + 2;
                uVar6 = uVar7 & 0x8080808080808080;
                *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar7 ^ uVar6;
                goto code_r0x0001800c83b3;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078275c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 == (int32_t **)0x0) {
                ppiVar8 = ppiVar10;
                if (iVar1 == *(int32_t *)0x180782674) {
                    ppiVar8 = (int32_t **)arg3;
                }
                if (ppiVar8 != (int32_t **)0x0) goto code_r0x0001800c869f;
                *(undefined8 *)arg2 = 0;
                goto code_r0x0001800c83b3;
            }
            piVar12 = (int64_t *)ppiVar8[6];
            uVar6 = 3;
            piVar3 = piVar12 + (int64_t)ppiVar8[7];
            for (; piVar12 != piVar3; piVar12 = piVar12 + 1) {
                piVar5 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, *piVar12);
                uVar7 = *piVar5 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar5 + uVar6;
            }
        } else {
            uVar6 = 10;
            if (ppiVar8[5] != (int32_t *)0x0) {
                do {
                    piVar13 = ppiVar8[4];
                    iVar2 = *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 2);
                    if (iVar2 != 0) {
                        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, iVar2);
                        uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                        uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
                    }
                    piVar3 = (int64_t *)
                             fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 4));
                    ppiVar10 = (int32_t **)((int64_t)ppiVar10 + 1);
                    uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                    uVar6 = (uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6) + 1;
                    uVar7 = uVar6 & 0x8080808080808080;
                    uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
                } while (ppiVar10 < ppiVar8[5]);
            }
        }
    } else {
        uVar6 = 10;
    }
    *(uint64_t *)arg2 = uVar6;
code_r0x0001800c83b3:
    *(undefined8 *)(arg2 + 8) = 0;
    return arg2;
code_r0x0001800c7f4b:
    uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
    ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
    if ((int32_t **)(piVar3[1] + -1) < ppiVar8) goto code_r0x0001800c7fee;
    goto code_r0x0001800c7f30;
}

// ============================================================
// Function: FUN_1800c82bd
// Address: 0x1800c82bd
// Size: 284 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c7ec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int32_t **ppiVar8;
    int32_t **ppiVar9;
    int32_t **ppiVar10;
    int32_t **ppiVar11;
    int64_t *piVar12;
    int32_t *piVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    ppiVar10 = (int32_t **)0x0;
    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 != '\0')) {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
                if (*piVar12 == arg3) {
                    ppiVar8 = (int32_t **)(piVar12 + 1);
                    if (piVar12 == (int64_t *)0x0) {
                        ppiVar8 = ppiVar10;
                    }
                    bVar14 = ppiVar8 == (int32_t **)0x0;
                    goto code_r0x0001800c7fe8;
                }
                if (*piVar12 == piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
                ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
            } while (ppiVar8 <= (int32_t **)(piVar3[1] + -1));
        }
    } else {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
code_r0x0001800c7f30:
            uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
            piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
            if (*piVar12 == arg3) {
                ppiVar8 = (int32_t **)(piVar12 + 1);
                if (piVar12 == (int64_t *)0x0) {
                    ppiVar8 = ppiVar10;
                }
                if (ppiVar8 != (int32_t **)0x0) {
                    bVar14 = *(int32_t *)ppiVar8 == 0;
code_r0x0001800c7fe8:
                    if (!bVar14) goto code_r0x0001800c86bb;
                }
            } else if (*piVar12 != piVar3[3]) goto code_r0x0001800c7f4b;
        }
    }
code_r0x0001800c7fee:
    iVar1 = *(int32_t *)(arg3 + 8);
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826c0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
        return arg2;
    }
    if ((((iVar1 == *(int32_t *)0x180782670) || (iVar1 == *(int32_t *)0x1807826cc)) ||
        (iVar1 == *(int32_t *)0x1807826b4)) ||
       ((iVar1 == *(int32_t *)0x18078273c || (iVar1 == *(int32_t *)0x18078271c)))) {
code_r0x0001800c86bb:
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0xffffffffffffffff;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782728) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        iVar2 = func_0x0001800ac7f0(arg1 + 0x18, ppiVar8 + 4);
        ppiVar8 = (int32_t **)(iVar2 + 8);
        if (iVar2 == 0) {
            ppiVar8 = ppiVar10;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        *(int32_t **)(arg2 + 8) = *ppiVar8;
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x180782738) {
        *(undefined8 *)arg2 = 1;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x1807826b8) {
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)arg2 = 3;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782740) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = *(int64_t **)(arg1 + 8);
        if ((piVar3[2] != 0) && (ppiVar8 != (int32_t **)piVar3[3])) {
            uVar6 = ((uint64_t)ppiVar8 >> 5 ^ (uint64_t)ppiVar8) >> 4;
            ppiVar9 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                ppiVar11 = (int32_t **)(uVar6 * 0x10 + *piVar3);
                if ((int32_t **)*ppiVar11 == ppiVar8) {
                    ppiVar9 = ppiVar11 + 1;
                    if (ppiVar11 == (int32_t **)0x0) {
                        ppiVar9 = ppiVar10;
                    }
                    if ((ppiVar9 != (int32_t **)0x0) && (*(int32_t *)ppiVar9 != 0)) {
                        if ((int32_t *)((uint64_t)(*(char *)0x180778038 != '\0') + 2) < ppiVar8[8]) {
                            bVar14 = true;
                            ppiVar9 = ppiVar10;
                            goto code_r0x0001800c81a7;
                        }
                        ppiVar10 = (int32_t **)0x1;
                        uVar6 = 2;
                        goto code_r0x0001800c81e7;
                    }
                    break;
                }
                if ((int32_t **)*ppiVar11 == (int32_t **)piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar9;
                ppiVar9 = (int32_t **)((int64_t)ppiVar9 + 1);
            } while (ppiVar9 <= (int32_t **)(piVar3[1] + -1));
        }
        bVar14 = false;
        ppiVar9 = (int32_t **)0x1;
code_r0x0001800c81a7:
        uVar6 = (int64_t)ppiVar9 + 2;
        if (!bVar14) {
            piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
            uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
            uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
        }
code_r0x0001800c81e7:
        piVar13 = (int32_t *)0x0;
        if (ppiVar8[8] != (int32_t *)0x0) {
            do {
                fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(ppiVar8[7] + (int64_t)piVar13 * 2));
                iVar2 = var_58h;
                if ((var_58h == 0) && ((char)ppiVar10 == '\0')) {
                    iVar2 = 1;
                }
                piVar13 = (int32_t *)((int64_t)piVar13 + 1);
                uVar7 = iVar2 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ iVar2 + uVar6;
            } while (piVar13 < ppiVar8[8]);
        }
        *(uint64_t *)arg2 = uVar6;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x18078269c) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        uVar6 = *piVar3 + 1U & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar6 ^ *piVar3 + 1U;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782730) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
        uVar6 = *piVar3 + *piVar12 & 0x8080808080808080;
        uVar6 = (uVar6 ^ *piVar3 + *piVar12 | uVar6 - (uVar6 >> 7)) + 1;
        uVar7 = uVar6 & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
        goto code_r0x0001800c83b3;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826a0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 == (int32_t **)0x0) {
        ppiVar8 = ppiVar10;
        if (iVar1 == *(int32_t *)0x180782758) {
            ppiVar8 = (int32_t **)arg3;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782768) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                var_58h = 0;
                var_50h = -1;
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar2, (int64_t)&var_58h);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782668) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[6]);
                iVar4 = fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar4, iVar2);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782708) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
code_r0x0001800c869f:
                fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078270c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[4]);
                piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[6]);
                iVar2 = *piVar3;
                iVar4 = *piVar12;
                uVar6 = iVar2 + iVar4 & 0x8080808080808080;
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, (int64_t)ppiVar8[8]);
                uVar7 = (uVar6 - (uVar6 >> 7) | uVar6 ^ iVar2 + iVar4) + *piVar3;
                uVar6 = uVar7 & 0x8080808080808080;
                uVar7 = (uVar7 ^ uVar6 | uVar6 - (uVar6 >> 7)) + 2;
                uVar6 = uVar7 & 0x8080808080808080;
                *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar7 ^ uVar6;
                goto code_r0x0001800c83b3;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078275c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 == (int32_t **)0x0) {
                ppiVar8 = ppiVar10;
                if (iVar1 == *(int32_t *)0x180782674) {
                    ppiVar8 = (int32_t **)arg3;
                }
                if (ppiVar8 != (int32_t **)0x0) goto code_r0x0001800c869f;
                *(undefined8 *)arg2 = 0;
                goto code_r0x0001800c83b3;
            }
            piVar12 = (int64_t *)ppiVar8[6];
            uVar6 = 3;
            piVar3 = piVar12 + (int64_t)ppiVar8[7];
            for (; piVar12 != piVar3; piVar12 = piVar12 + 1) {
                piVar5 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, *piVar12);
                uVar7 = *piVar5 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar5 + uVar6;
            }
        } else {
            uVar6 = 10;
            if (ppiVar8[5] != (int32_t *)0x0) {
                do {
                    piVar13 = ppiVar8[4];
                    iVar2 = *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 2);
                    if (iVar2 != 0) {
                        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, iVar2);
                        uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                        uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
                    }
                    piVar3 = (int64_t *)
                             fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 4));
                    ppiVar10 = (int32_t **)((int64_t)ppiVar10 + 1);
                    uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                    uVar6 = (uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6) + 1;
                    uVar7 = uVar6 & 0x8080808080808080;
                    uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
                } while (ppiVar10 < ppiVar8[5]);
            }
        }
    } else {
        uVar6 = 10;
    }
    *(uint64_t *)arg2 = uVar6;
code_r0x0001800c83b3:
    *(undefined8 *)(arg2 + 8) = 0;
    return arg2;
code_r0x0001800c7f4b:
    uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
    ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
    if ((int32_t **)(piVar3[1] + -1) < ppiVar8) goto code_r0x0001800c7fee;
    goto code_r0x0001800c7f30;
}

// ============================================================
// Function: FUN_1800c83d9
// Address: 0x1800c83d9
// Size: 738 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c7ec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int32_t **ppiVar8;
    int32_t **ppiVar9;
    int32_t **ppiVar10;
    int32_t **ppiVar11;
    int64_t *piVar12;
    int32_t *piVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    ppiVar10 = (int32_t **)0x0;
    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 != '\0')) {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
                if (*piVar12 == arg3) {
                    ppiVar8 = (int32_t **)(piVar12 + 1);
                    if (piVar12 == (int64_t *)0x0) {
                        ppiVar8 = ppiVar10;
                    }
                    bVar14 = ppiVar8 == (int32_t **)0x0;
                    goto code_r0x0001800c7fe8;
                }
                if (*piVar12 == piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
                ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
            } while (ppiVar8 <= (int32_t **)(piVar3[1] + -1));
        }
    } else {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
code_r0x0001800c7f30:
            uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
            piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
            if (*piVar12 == arg3) {
                ppiVar8 = (int32_t **)(piVar12 + 1);
                if (piVar12 == (int64_t *)0x0) {
                    ppiVar8 = ppiVar10;
                }
                if (ppiVar8 != (int32_t **)0x0) {
                    bVar14 = *(int32_t *)ppiVar8 == 0;
code_r0x0001800c7fe8:
                    if (!bVar14) goto code_r0x0001800c86bb;
                }
            } else if (*piVar12 != piVar3[3]) goto code_r0x0001800c7f4b;
        }
    }
code_r0x0001800c7fee:
    iVar1 = *(int32_t *)(arg3 + 8);
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826c0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
        return arg2;
    }
    if ((((iVar1 == *(int32_t *)0x180782670) || (iVar1 == *(int32_t *)0x1807826cc)) ||
        (iVar1 == *(int32_t *)0x1807826b4)) ||
       ((iVar1 == *(int32_t *)0x18078273c || (iVar1 == *(int32_t *)0x18078271c)))) {
code_r0x0001800c86bb:
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0xffffffffffffffff;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782728) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        iVar2 = func_0x0001800ac7f0(arg1 + 0x18, ppiVar8 + 4);
        ppiVar8 = (int32_t **)(iVar2 + 8);
        if (iVar2 == 0) {
            ppiVar8 = ppiVar10;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        *(int32_t **)(arg2 + 8) = *ppiVar8;
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x180782738) {
        *(undefined8 *)arg2 = 1;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x1807826b8) {
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)arg2 = 3;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782740) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = *(int64_t **)(arg1 + 8);
        if ((piVar3[2] != 0) && (ppiVar8 != (int32_t **)piVar3[3])) {
            uVar6 = ((uint64_t)ppiVar8 >> 5 ^ (uint64_t)ppiVar8) >> 4;
            ppiVar9 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                ppiVar11 = (int32_t **)(uVar6 * 0x10 + *piVar3);
                if ((int32_t **)*ppiVar11 == ppiVar8) {
                    ppiVar9 = ppiVar11 + 1;
                    if (ppiVar11 == (int32_t **)0x0) {
                        ppiVar9 = ppiVar10;
                    }
                    if ((ppiVar9 != (int32_t **)0x0) && (*(int32_t *)ppiVar9 != 0)) {
                        if ((int32_t *)((uint64_t)(*(char *)0x180778038 != '\0') + 2) < ppiVar8[8]) {
                            bVar14 = true;
                            ppiVar9 = ppiVar10;
                            goto code_r0x0001800c81a7;
                        }
                        ppiVar10 = (int32_t **)0x1;
                        uVar6 = 2;
                        goto code_r0x0001800c81e7;
                    }
                    break;
                }
                if ((int32_t **)*ppiVar11 == (int32_t **)piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar9;
                ppiVar9 = (int32_t **)((int64_t)ppiVar9 + 1);
            } while (ppiVar9 <= (int32_t **)(piVar3[1] + -1));
        }
        bVar14 = false;
        ppiVar9 = (int32_t **)0x1;
code_r0x0001800c81a7:
        uVar6 = (int64_t)ppiVar9 + 2;
        if (!bVar14) {
            piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
            uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
            uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
        }
code_r0x0001800c81e7:
        piVar13 = (int32_t *)0x0;
        if (ppiVar8[8] != (int32_t *)0x0) {
            do {
                fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(ppiVar8[7] + (int64_t)piVar13 * 2));
                iVar2 = var_58h;
                if ((var_58h == 0) && ((char)ppiVar10 == '\0')) {
                    iVar2 = 1;
                }
                piVar13 = (int32_t *)((int64_t)piVar13 + 1);
                uVar7 = iVar2 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ iVar2 + uVar6;
            } while (piVar13 < ppiVar8[8]);
        }
        *(uint64_t *)arg2 = uVar6;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x18078269c) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        uVar6 = *piVar3 + 1U & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar6 ^ *piVar3 + 1U;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782730) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
        uVar6 = *piVar3 + *piVar12 & 0x8080808080808080;
        uVar6 = (uVar6 ^ *piVar3 + *piVar12 | uVar6 - (uVar6 >> 7)) + 1;
        uVar7 = uVar6 & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
        goto code_r0x0001800c83b3;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826a0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 == (int32_t **)0x0) {
        ppiVar8 = ppiVar10;
        if (iVar1 == *(int32_t *)0x180782758) {
            ppiVar8 = (int32_t **)arg3;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782768) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                var_58h = 0;
                var_50h = -1;
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar2, (int64_t)&var_58h);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782668) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[6]);
                iVar4 = fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar4, iVar2);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782708) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
code_r0x0001800c869f:
                fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078270c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[4]);
                piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[6]);
                iVar2 = *piVar3;
                iVar4 = *piVar12;
                uVar6 = iVar2 + iVar4 & 0x8080808080808080;
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, (int64_t)ppiVar8[8]);
                uVar7 = (uVar6 - (uVar6 >> 7) | uVar6 ^ iVar2 + iVar4) + *piVar3;
                uVar6 = uVar7 & 0x8080808080808080;
                uVar7 = (uVar7 ^ uVar6 | uVar6 - (uVar6 >> 7)) + 2;
                uVar6 = uVar7 & 0x8080808080808080;
                *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar7 ^ uVar6;
                goto code_r0x0001800c83b3;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078275c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 == (int32_t **)0x0) {
                ppiVar8 = ppiVar10;
                if (iVar1 == *(int32_t *)0x180782674) {
                    ppiVar8 = (int32_t **)arg3;
                }
                if (ppiVar8 != (int32_t **)0x0) goto code_r0x0001800c869f;
                *(undefined8 *)arg2 = 0;
                goto code_r0x0001800c83b3;
            }
            piVar12 = (int64_t *)ppiVar8[6];
            uVar6 = 3;
            piVar3 = piVar12 + (int64_t)ppiVar8[7];
            for (; piVar12 != piVar3; piVar12 = piVar12 + 1) {
                piVar5 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, *piVar12);
                uVar7 = *piVar5 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar5 + uVar6;
            }
        } else {
            uVar6 = 10;
            if (ppiVar8[5] != (int32_t *)0x0) {
                do {
                    piVar13 = ppiVar8[4];
                    iVar2 = *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 2);
                    if (iVar2 != 0) {
                        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, iVar2);
                        uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                        uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
                    }
                    piVar3 = (int64_t *)
                             fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 4));
                    ppiVar10 = (int32_t **)((int64_t)ppiVar10 + 1);
                    uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                    uVar6 = (uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6) + 1;
                    uVar7 = uVar6 & 0x8080808080808080;
                    uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
                } while (ppiVar10 < ppiVar8[5]);
            }
        }
    } else {
        uVar6 = 10;
    }
    *(uint64_t *)arg2 = uVar6;
code_r0x0001800c83b3:
    *(undefined8 *)(arg2 + 8) = 0;
    return arg2;
code_r0x0001800c7f4b:
    uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
    ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
    if ((int32_t **)(piVar3[1] + -1) < ppiVar8) goto code_r0x0001800c7fee;
    goto code_r0x0001800c7f30;
}

// ============================================================
// Function: FUN_1800c86bb
// Address: 0x1800c86bb
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800c7ec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int32_t **ppiVar8;
    int32_t **ppiVar9;
    int32_t **ppiVar10;
    int32_t **ppiVar11;
    int64_t *piVar12;
    int32_t *piVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    ppiVar10 = (int32_t **)0x0;
    if ((*(char *)0x180778018 == '\0') || (*(char *)0x180777ff8 != '\0')) {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
                if (*piVar12 == arg3) {
                    ppiVar8 = (int32_t **)(piVar12 + 1);
                    if (piVar12 == (int64_t *)0x0) {
                        ppiVar8 = ppiVar10;
                    }
                    bVar14 = ppiVar8 == (int32_t **)0x0;
                    goto code_r0x0001800c7fe8;
                }
                if (*piVar12 == piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
                ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
            } while (ppiVar8 <= (int32_t **)(piVar3[1] + -1));
        }
    } else {
        piVar3 = *(int64_t **)(arg1 + 0x10);
        if ((piVar3[2] != 0) && (arg3 != piVar3[3])) {
            uVar6 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            ppiVar8 = ppiVar10;
code_r0x0001800c7f30:
            uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
            piVar12 = (int64_t *)(uVar6 * 0x20 + *piVar3);
            if (*piVar12 == arg3) {
                ppiVar8 = (int32_t **)(piVar12 + 1);
                if (piVar12 == (int64_t *)0x0) {
                    ppiVar8 = ppiVar10;
                }
                if (ppiVar8 != (int32_t **)0x0) {
                    bVar14 = *(int32_t *)ppiVar8 == 0;
code_r0x0001800c7fe8:
                    if (!bVar14) goto code_r0x0001800c86bb;
                }
            } else if (*piVar12 != piVar3[3]) goto code_r0x0001800c7f4b;
        }
    }
code_r0x0001800c7fee:
    iVar1 = *(int32_t *)(arg3 + 8);
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826c0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
        return arg2;
    }
    if ((((iVar1 == *(int32_t *)0x180782670) || (iVar1 == *(int32_t *)0x1807826cc)) ||
        (iVar1 == *(int32_t *)0x1807826b4)) ||
       ((iVar1 == *(int32_t *)0x18078273c || (iVar1 == *(int32_t *)0x18078271c)))) {
code_r0x0001800c86bb:
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0xffffffffffffffff;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782728) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        iVar2 = func_0x0001800ac7f0(arg1 + 0x18, ppiVar8 + 4);
        ppiVar8 = (int32_t **)(iVar2 + 8);
        if (iVar2 == 0) {
            ppiVar8 = ppiVar10;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            *(undefined8 *)arg2 = 0;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        *(int32_t **)(arg2 + 8) = *ppiVar8;
        *(undefined8 *)arg2 = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x180782738) {
        *(undefined8 *)arg2 = 1;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    if (iVar1 == *(int32_t *)0x1807826b8) {
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)arg2 = 3;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782740) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = *(int64_t **)(arg1 + 8);
        if ((piVar3[2] != 0) && (ppiVar8 != (int32_t **)piVar3[3])) {
            uVar6 = ((uint64_t)ppiVar8 >> 5 ^ (uint64_t)ppiVar8) >> 4;
            ppiVar9 = ppiVar10;
            do {
                uVar6 = uVar6 & (uint64_t)(int32_t **)(piVar3[1] + -1);
                ppiVar11 = (int32_t **)(uVar6 * 0x10 + *piVar3);
                if ((int32_t **)*ppiVar11 == ppiVar8) {
                    ppiVar9 = ppiVar11 + 1;
                    if (ppiVar11 == (int32_t **)0x0) {
                        ppiVar9 = ppiVar10;
                    }
                    if ((ppiVar9 != (int32_t **)0x0) && (*(int32_t *)ppiVar9 != 0)) {
                        if ((int32_t *)((uint64_t)(*(char *)0x180778038 != '\0') + 2) < ppiVar8[8]) {
                            bVar14 = true;
                            ppiVar9 = ppiVar10;
                            goto code_r0x0001800c81a7;
                        }
                        ppiVar10 = (int32_t **)0x1;
                        uVar6 = 2;
                        goto code_r0x0001800c81e7;
                    }
                    break;
                }
                if ((int32_t **)*ppiVar11 == (int32_t **)piVar3[3]) break;
                uVar6 = uVar6 + 1 + (int64_t)ppiVar9;
                ppiVar9 = (int32_t **)((int64_t)ppiVar9 + 1);
            } while (ppiVar9 <= (int32_t **)(piVar3[1] + -1));
        }
        bVar14 = false;
        ppiVar9 = (int32_t **)0x1;
code_r0x0001800c81a7:
        uVar6 = (int64_t)ppiVar9 + 2;
        if (!bVar14) {
            piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
            uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
            uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
        }
code_r0x0001800c81e7:
        piVar13 = (int32_t *)0x0;
        if (ppiVar8[8] != (int32_t *)0x0) {
            do {
                fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(ppiVar8[7] + (int64_t)piVar13 * 2));
                iVar2 = var_58h;
                if ((var_58h == 0) && ((char)ppiVar10 == '\0')) {
                    iVar2 = 1;
                }
                piVar13 = (int32_t *)((int64_t)piVar13 + 1);
                uVar7 = iVar2 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ iVar2 + uVar6;
            } while (piVar13 < ppiVar8[8]);
        }
        *(uint64_t *)arg2 = uVar6;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x18078269c) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        uVar6 = *piVar3 + 1U & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar6 ^ *piVar3 + 1U;
        return arg2;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x180782730) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 != (int32_t **)0x0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[4]);
        piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
        uVar6 = *piVar3 + *piVar12 & 0x8080808080808080;
        uVar6 = (uVar6 ^ *piVar3 + *piVar12 | uVar6 - (uVar6 >> 7)) + 1;
        uVar7 = uVar6 & 0x8080808080808080;
        *(uint64_t *)arg2 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
        goto code_r0x0001800c83b3;
    }
    ppiVar8 = ppiVar10;
    if (iVar1 == *(int32_t *)0x1807826a0) {
        ppiVar8 = (int32_t **)arg3;
    }
    if (ppiVar8 == (int32_t **)0x0) {
        ppiVar8 = ppiVar10;
        if (iVar1 == *(int32_t *)0x180782758) {
            ppiVar8 = (int32_t **)arg3;
        }
        if (ppiVar8 == (int32_t **)0x0) {
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782768) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                var_58h = 0;
                var_50h = -1;
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar2, (int64_t)&var_58h);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782668) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                iVar2 = fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[6]);
                iVar4 = fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[5]);
                fcn.1800c7e30(arg2, iVar4, iVar2);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x180782708) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
code_r0x0001800c869f:
                fcn.1800c7ec0(arg1, arg2, (int64_t)ppiVar8[4]);
                return arg2;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078270c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 != (int32_t **)0x0) {
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, (int64_t)ppiVar8[4]);
                piVar12 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_58h, (int64_t)ppiVar8[6]);
                iVar2 = *piVar3;
                iVar4 = *piVar12;
                uVar6 = iVar2 + iVar4 & 0x8080808080808080;
                piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, (int64_t)ppiVar8[8]);
                uVar7 = (uVar6 - (uVar6 >> 7) | uVar6 ^ iVar2 + iVar4) + *piVar3;
                uVar6 = uVar7 & 0x8080808080808080;
                uVar7 = (uVar7 ^ uVar6 | uVar6 - (uVar6 >> 7)) + 2;
                uVar6 = uVar7 & 0x8080808080808080;
                *(uint64_t *)arg2 = uVar6 - (uVar6 >> 7) | uVar7 ^ uVar6;
                goto code_r0x0001800c83b3;
            }
            ppiVar8 = ppiVar10;
            if (iVar1 == *(int32_t *)0x18078275c) {
                ppiVar8 = (int32_t **)arg3;
            }
            if (ppiVar8 == (int32_t **)0x0) {
                ppiVar8 = ppiVar10;
                if (iVar1 == *(int32_t *)0x180782674) {
                    ppiVar8 = (int32_t **)arg3;
                }
                if (ppiVar8 != (int32_t **)0x0) goto code_r0x0001800c869f;
                *(undefined8 *)arg2 = 0;
                goto code_r0x0001800c83b3;
            }
            piVar12 = (int64_t *)ppiVar8[6];
            uVar6 = 3;
            piVar3 = piVar12 + (int64_t)ppiVar8[7];
            for (; piVar12 != piVar3; piVar12 = piVar12 + 1) {
                piVar5 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_38h, *piVar12);
                uVar7 = *piVar5 + uVar6 & 0x8080808080808080;
                uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar5 + uVar6;
            }
        } else {
            uVar6 = 10;
            if (ppiVar8[5] != (int32_t *)0x0) {
                do {
                    piVar13 = ppiVar8[4];
                    iVar2 = *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 2);
                    if (iVar2 != 0) {
                        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_48h, iVar2);
                        uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                        uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6;
                    }
                    piVar3 = (int64_t *)
                             fcn.1800c7ec0(arg1, (int64_t)&var_58h, *(int64_t *)(piVar13 + (int64_t)ppiVar10 * 6 + 4));
                    ppiVar10 = (int32_t **)((int64_t)ppiVar10 + 1);
                    uVar7 = *piVar3 + uVar6 & 0x8080808080808080;
                    uVar6 = (uVar7 - (uVar7 >> 7) | uVar7 ^ *piVar3 + uVar6) + 1;
                    uVar7 = uVar6 & 0x8080808080808080;
                    uVar6 = uVar7 - (uVar7 >> 7) | uVar7 ^ uVar6;
                } while (ppiVar10 < ppiVar8[5]);
            }
        }
    } else {
        uVar6 = 10;
    }
    *(uint64_t *)arg2 = uVar6;
code_r0x0001800c83b3:
    *(undefined8 *)(arg2 + 8) = 0;
    return arg2;
code_r0x0001800c7f4b:
    uVar6 = uVar6 + 1 + (int64_t)ppiVar8;
    ppiVar8 = (int32_t **)((int64_t)ppiVar8 + 1);
    if ((int32_t **)(piVar3[1] + -1) < ppiVar8) goto code_r0x0001800c7fee;
    goto code_r0x0001800c7f30;
}

// ============================================================
// Function: FUN_1800c86e0
// Address: 0x1800c86e0
// Size: 264 bytes
// ============================================================
void fcn.1800c86e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x48) = 0;
    (***(code ***)arg2)(arg2, arg1);
    uVar5 = *(int64_t *)arg3 + *(int64_t *)(arg1 + 0x40);
    uVar3 = uVar5 & 0x8080808080808080;
    uVar5 = uVar3 - (uVar3 >> 7) | uVar5;
    iVar2 = 0x7f;
    if ((int32_t)arg4 < 0x7f) {
        iVar2 = (int32_t)arg4;
    }
    uVar4 = (uVar5 & 0x7f007f007f007f) * (int64_t)iVar2;
    uVar5 = (uVar5 >> 8 & 0x7f007f007f007f) * (int64_t)iVar2;
    uVar3 = uVar4 + 0x7f807f807f807f80 >> 8 & 0x80008000800080 | uVar5 + 0x7f807f807f807f80 & 0x8000800080008000;
    uVar3 = (uVar4 & 0x7f007f007f007f | uVar3 - (uVar3 >> 7) | (uVar5 & 0x7f007f007f007f) << 8) + iVar1;
    uVar5 = uVar3 & 0x8080808080808080;
    *(uint64_t *)(arg1 + 0x40) = uVar5 - (uVar5 >> 7) | uVar5 ^ uVar3;
    *(undefined8 *)(arg1 + 0x48) = 0;
    return;
}

// ============================================================
// Function: FUN_1800c87f0
// Address: 0x1800c87f0
// Size: 84 bytes
// ============================================================
int64_t fcn.1800c87f0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t var_18h;
    
    piVar1 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_18h, arg2);
    uVar3 = *piVar1 + *(int64_t *)(arg1 + 0x40);
    *(undefined8 *)(arg1 + 0x48) = 0;
    uVar2 = uVar3 & 0x8080808080808080;
    *(uint64_t *)(arg1 + 0x40) = uVar2 - (uVar2 >> 7) | uVar3 ^ uVar2;
    return (uVar2 >> 0xf) << 8;
}

// ============================================================
// Function: FUN_1800c8850
// Address: 0x1800c8850
// Size: 374 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800c8850(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_58h)
{
    char cVar1;
    uint32_t uVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStackY_20;
    
    piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_28h, *(int64_t *)(arg2 + 0x30));
    uVar5 = *(int64_t *)(arg1 + 0x40) + *piVar3;
    *(undefined8 *)(arg1 + 0x48) = 0;
    uVar4 = uVar5 & 0x8080808080808080;
    *(uint64_t *)(arg1 + 0x40) = uVar4 - (uVar4 >> 7) | uVar5 ^ uVar4;
    piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_28h, *(int64_t *)(arg2 + 0x38));
    uVar5 = *(int64_t *)(arg1 + 0x40) + *piVar3;
    *(undefined8 *)(arg1 + 0x48) = 0;
    uVar4 = uVar5 & 0x8080808080808080;
    *(uint64_t *)(arg1 + 0x40) = uVar4 - (uVar4 >> 7) | uVar5 ^ uVar4;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        piVar3 = (int64_t *)fcn.1800c7ec0(arg1, (int64_t)&var_28h, *(int64_t *)(arg2 + 0x40));
        uVar5 = *(int64_t *)(arg1 + 0x40) + *piVar3;
        *(undefined8 *)(arg1 + 0x48) = 0;
        uVar4 = uVar5 & 0x8080808080808080;
        *(uint64_t *)(arg1 + 0x40) = uVar4 - (uVar4 >> 7) | uVar5 ^ uVar4;
    }
    var_8h = 0x3ff0000000000000;
    uVar2 = 0xffffffff;
    cVar1 = func_0x0001800c9060(arg1, *(undefined8 *)(arg2 + 0x30), &var_18h);
    if (((cVar1 != '\0') && (cVar1 = func_0x0001800c9060(arg1, *(undefined8 *)(arg2 + 0x38), &var_10h), cVar1 != '\0'))
       && ((*(int64_t *)(arg2 + 0x40) == 0 ||
           (cVar1 = func_0x0001800c9060(arg1, *(int64_t *)(arg2 + 0x40), &var_8h), cVar1 != '\0')))) {
        uVar2 = func_0x0001800c9560(var_18h, var_10h);
    }
    var_28h = 1;
    uStackY_20 = 0;
    if ((int32_t)uVar2 < 0) {
        uVar2 = 3;
    }
    uVar4 = fcn.1800c86e0(arg1, *(int64_t *)(arg2 + 0x48), (int64_t)&var_28h, (uint64_t)uVar2, unaff_RSI, unaff_RBP);
    return uVar4 & 0xffffffffffffff00;
}

