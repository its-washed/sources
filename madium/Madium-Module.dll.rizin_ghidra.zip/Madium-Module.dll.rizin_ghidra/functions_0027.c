// Chunk 27 - 50 functions

// ============================================================
// Function: FUN_1800532b0
// Address: 0x1800532b0
// Size: 70 bytes
// ============================================================
undefined8 fcn.1800532b0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar3 + 0xc) == 9) && (iVar1 = *piVar3, *(char *)(iVar1 + 3) == '|')) &&
       (iVar1 != -0x10)) {
        *(undefined *)(iVar1 + 0x3d) = 1;
        return 0;
    }
    fcn.1800883d0(arg1, 1, 0x180624010);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_180053300
// Address: 0x180053300
// Size: 389 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180053300(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar15 = piVar8;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar15 + 0xc) != 9) || (iVar1 = *piVar15, *(char *)(iVar1 + 3) != '|')) ||
       (piVar15 = (int64_t *)(iVar1 + 0x10), piVar15 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624010);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    piVar11 = piVar8 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8 + 2) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x0001800536b5;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar11 + 0x18 != 0) {
        piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        piVar8 = piVar12;
        if (*(int64_t **)(arg1 + 0x40) <= piVar12) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 != *(int64_t **)0x180782430) &&
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 6 || (*(int32_t *)((int64_t)piVar8 + 0xc) == 3)))) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar12) {
                piVar12 = *(int64_t **)0x180782430;
            }
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = (int64_t *)0x0;
            }
            iVar2 = *piVar12;
            if (iVar2 != 0) {
                iVar7 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar7 == 0x5f879bcf) {
                    uVar9 = func_0x000180088040(arg1, *(undefined8 *)(iVar1 + 0x28));
                    func_0x000180498030(uVar9, *piVar15, *(undefined8 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == 0x78793741) {
                    func_0x0001800867f0(arg1, *piVar15, *(undefined8 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == -0x301a3c57) {
                    func_0x000180086fd0(arg1, *(undefined4 *)(iVar1 + 0x28), 0);
                    uVar14 = 0;
                    if (*(int64_t *)(iVar1 + 0x28) != 0) {
                        do {
                            func_0x0001800865e0(arg1, *(undefined *)(uVar14 + *piVar15));
                            iVar2 = *(int64_t *)(arg1 + 0x40);
                            if (*(char *)(*(int64_t *)(iVar2 + -0x20) + 4) != '\0') {
                                func_0x000180092f10(arg1);
                                pcVar4 = (code *)swi(3);
                                uVar9 = (*pcVar4)();
                                return uVar9;
                            }
                            uVar13 = (int32_t)uVar14 + 1;
                            uVar14 = (uint64_t)uVar13;
                            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar2 + -0x20), uVar13);
                            uVar16 = *(undefined4 *)(iVar2 + -0xc);
                            uVar5 = *(undefined4 *)(iVar2 + -8);
                            uVar6 = *(undefined4 *)(iVar2 + -4);
                            *puVar10 = *(undefined4 *)(iVar2 + -0x10);
                            puVar10[1] = uVar16;
                            puVar10[2] = uVar5;
                            puVar10[3] = uVar6;
                            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                                iVar2 = *(int64_t *)(iVar2 + -0x20);
                                if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
                                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                                    iVar3 = *(int64_t *)(arg1 + 0x20);
                                    if (*(char *)(iVar3 + 0x59) == '\x02') {
                                        func_0x000180094420();
                                    } else {
                                        *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                                        *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                                        *(int64_t *)(iVar3 + 0x18) = iVar2;
                                    }
                                }
                            }
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        } while ((uint64_t)uVar13 < *(uint64_t *)(iVar1 + 0x28));
                    }
                    return 1;
                }
                if (iVar7 == 0x235ce5cd) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x30));
                    return 1;
                }
                if (iVar7 == 0x4d97b695) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x34));
                    return 1;
                }
                if (iVar7 == -0x48e6d56a) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x38));
                    return 1;
                }
                if (iVar7 == 0x70002f) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == 0x47ecaf93) {
                    if ((undefined *)*piVar15 != *(undefined **)(iVar1 + 0x18)) {
                        func_0x0001800865e0(arg1, *(undefined *)*piVar15);
                        return 1;
                    }
                    func_0x0001800865e0(arg1, 0);
                    return 1;
                }
                if (iVar7 == 0x6062919d) {
                    uVar16 = func_0x000180018f70();
                    func_0x00018001afc0(uVar16, arg1, 0x1800530f0, 0x180623fc0);
                    return 1;
                }
                if (iVar7 == 0x1049846d) {
                    uVar16 = func_0x000180018f70();
                    func_0x00018001afc0(uVar16, arg1, fcn.1800532b0, 0x180623fc8);
                    return 1;
                }
            }
        }
        fcn.180088560(arg1, 0x180624040, *piVar11 + 0x18);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
code_r0x0001800536b5:
    func_0x000180088470(arg1, 2, 6);
    pcVar4 = (code *)swi(3);
    uVar9 = (*pcVar4)();
    return uVar9;
}

// ============================================================
// Function: FUN_180053485
// Address: 0x180053485
// Size: 208 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180053300(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar15 = piVar8;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar15 + 0xc) != 9) || (iVar1 = *piVar15, *(char *)(iVar1 + 3) != '|')) ||
       (piVar15 = (int64_t *)(iVar1 + 0x10), piVar15 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624010);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    piVar11 = piVar8 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8 + 2) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x0001800536b5;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar11 + 0x18 != 0) {
        piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        piVar8 = piVar12;
        if (*(int64_t **)(arg1 + 0x40) <= piVar12) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 != *(int64_t **)0x180782430) &&
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 6 || (*(int32_t *)((int64_t)piVar8 + 0xc) == 3)))) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar12) {
                piVar12 = *(int64_t **)0x180782430;
            }
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = (int64_t *)0x0;
            }
            iVar2 = *piVar12;
            if (iVar2 != 0) {
                iVar7 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar7 == 0x5f879bcf) {
                    uVar9 = func_0x000180088040(arg1, *(undefined8 *)(iVar1 + 0x28));
                    func_0x000180498030(uVar9, *piVar15, *(undefined8 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == 0x78793741) {
                    func_0x0001800867f0(arg1, *piVar15, *(undefined8 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == -0x301a3c57) {
                    func_0x000180086fd0(arg1, *(undefined4 *)(iVar1 + 0x28), 0);
                    uVar14 = 0;
                    if (*(int64_t *)(iVar1 + 0x28) != 0) {
                        do {
                            func_0x0001800865e0(arg1, *(undefined *)(uVar14 + *piVar15));
                            iVar2 = *(int64_t *)(arg1 + 0x40);
                            if (*(char *)(*(int64_t *)(iVar2 + -0x20) + 4) != '\0') {
                                func_0x000180092f10(arg1);
                                pcVar4 = (code *)swi(3);
                                uVar9 = (*pcVar4)();
                                return uVar9;
                            }
                            uVar13 = (int32_t)uVar14 + 1;
                            uVar14 = (uint64_t)uVar13;
                            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar2 + -0x20), uVar13);
                            uVar16 = *(undefined4 *)(iVar2 + -0xc);
                            uVar5 = *(undefined4 *)(iVar2 + -8);
                            uVar6 = *(undefined4 *)(iVar2 + -4);
                            *puVar10 = *(undefined4 *)(iVar2 + -0x10);
                            puVar10[1] = uVar16;
                            puVar10[2] = uVar5;
                            puVar10[3] = uVar6;
                            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                                iVar2 = *(int64_t *)(iVar2 + -0x20);
                                if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
                                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                                    iVar3 = *(int64_t *)(arg1 + 0x20);
                                    if (*(char *)(iVar3 + 0x59) == '\x02') {
                                        func_0x000180094420();
                                    } else {
                                        *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                                        *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                                        *(int64_t *)(iVar3 + 0x18) = iVar2;
                                    }
                                }
                            }
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        } while ((uint64_t)uVar13 < *(uint64_t *)(iVar1 + 0x28));
                    }
                    return 1;
                }
                if (iVar7 == 0x235ce5cd) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x30));
                    return 1;
                }
                if (iVar7 == 0x4d97b695) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x34));
                    return 1;
                }
                if (iVar7 == -0x48e6d56a) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x38));
                    return 1;
                }
                if (iVar7 == 0x70002f) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == 0x47ecaf93) {
                    if ((undefined *)*piVar15 != *(undefined **)(iVar1 + 0x18)) {
                        func_0x0001800865e0(arg1, *(undefined *)*piVar15);
                        return 1;
                    }
                    func_0x0001800865e0(arg1, 0);
                    return 1;
                }
                if (iVar7 == 0x6062919d) {
                    uVar16 = func_0x000180018f70();
                    func_0x00018001afc0(uVar16, arg1, 0x1800530f0, 0x180623fc0);
                    return 1;
                }
                if (iVar7 == 0x1049846d) {
                    uVar16 = func_0x000180018f70();
                    func_0x00018001afc0(uVar16, arg1, fcn.1800532b0, 0x180623fc8);
                    return 1;
                }
            }
        }
        fcn.180088560(arg1, 0x180624040, *piVar11 + 0x18);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
code_r0x0001800536b5:
    func_0x000180088470(arg1, 2, 6);
    pcVar4 = (code *)swi(3);
    uVar9 = (*pcVar4)();
    return uVar9;
}

// ============================================================
// Function: FUN_180053555
// Address: 0x180053555
// Size: 372 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180053300(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar15 = piVar8;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar15 + 0xc) != 9) || (iVar1 = *piVar15, *(char *)(iVar1 + 3) != '|')) ||
       (piVar15 = (int64_t *)(iVar1 + 0x10), piVar15 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624010);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    piVar11 = piVar8 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8 + 2) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x0001800536b5;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar11 + 0x18 != 0) {
        piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        piVar8 = piVar12;
        if (*(int64_t **)(arg1 + 0x40) <= piVar12) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 != *(int64_t **)0x180782430) &&
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 6 || (*(int32_t *)((int64_t)piVar8 + 0xc) == 3)))) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar12) {
                piVar12 = *(int64_t **)0x180782430;
            }
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = (int64_t *)0x0;
            }
            iVar2 = *piVar12;
            if (iVar2 != 0) {
                iVar7 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar7 == 0x5f879bcf) {
                    uVar9 = func_0x000180088040(arg1, *(undefined8 *)(iVar1 + 0x28));
                    func_0x000180498030(uVar9, *piVar15, *(undefined8 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == 0x78793741) {
                    func_0x0001800867f0(arg1, *piVar15, *(undefined8 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == -0x301a3c57) {
                    func_0x000180086fd0(arg1, *(undefined4 *)(iVar1 + 0x28), 0);
                    uVar14 = 0;
                    if (*(int64_t *)(iVar1 + 0x28) != 0) {
                        do {
                            func_0x0001800865e0(arg1, *(undefined *)(uVar14 + *piVar15));
                            iVar2 = *(int64_t *)(arg1 + 0x40);
                            if (*(char *)(*(int64_t *)(iVar2 + -0x20) + 4) != '\0') {
                                func_0x000180092f10(arg1);
                                pcVar4 = (code *)swi(3);
                                uVar9 = (*pcVar4)();
                                return uVar9;
                            }
                            uVar13 = (int32_t)uVar14 + 1;
                            uVar14 = (uint64_t)uVar13;
                            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar2 + -0x20), uVar13);
                            uVar16 = *(undefined4 *)(iVar2 + -0xc);
                            uVar5 = *(undefined4 *)(iVar2 + -8);
                            uVar6 = *(undefined4 *)(iVar2 + -4);
                            *puVar10 = *(undefined4 *)(iVar2 + -0x10);
                            puVar10[1] = uVar16;
                            puVar10[2] = uVar5;
                            puVar10[3] = uVar6;
                            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                                iVar2 = *(int64_t *)(iVar2 + -0x20);
                                if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
                                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                                    iVar3 = *(int64_t *)(arg1 + 0x20);
                                    if (*(char *)(iVar3 + 0x59) == '\x02') {
                                        func_0x000180094420();
                                    } else {
                                        *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                                        *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                                        *(int64_t *)(iVar3 + 0x18) = iVar2;
                                    }
                                }
                            }
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        } while ((uint64_t)uVar13 < *(uint64_t *)(iVar1 + 0x28));
                    }
                    return 1;
                }
                if (iVar7 == 0x235ce5cd) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x30));
                    return 1;
                }
                if (iVar7 == 0x4d97b695) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x34));
                    return 1;
                }
                if (iVar7 == -0x48e6d56a) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x38));
                    return 1;
                }
                if (iVar7 == 0x70002f) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == 0x47ecaf93) {
                    if ((undefined *)*piVar15 != *(undefined **)(iVar1 + 0x18)) {
                        func_0x0001800865e0(arg1, *(undefined *)*piVar15);
                        return 1;
                    }
                    func_0x0001800865e0(arg1, 0);
                    return 1;
                }
                if (iVar7 == 0x6062919d) {
                    uVar16 = func_0x000180018f70();
                    func_0x00018001afc0(uVar16, arg1, 0x1800530f0, 0x180623fc0);
                    return 1;
                }
                if (iVar7 == 0x1049846d) {
                    uVar16 = func_0x000180018f70();
                    func_0x00018001afc0(uVar16, arg1, fcn.1800532b0, 0x180623fc8);
                    return 1;
                }
            }
        }
        fcn.180088560(arg1, 0x180624040, *piVar11 + 0x18);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
code_r0x0001800536b5:
    func_0x000180088470(arg1, 2, 6);
    pcVar4 = (code *)swi(3);
    uVar9 = (*pcVar4)();
    return uVar9;
}

// ============================================================
// Function: FUN_1800536c9
// Address: 0x1800536c9
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180053300(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    undefined4 *puVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar15 = piVar8;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar15 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar15 + 0xc) != 9) || (iVar1 = *piVar15, *(char *)(iVar1 + 3) != '|')) ||
       (piVar15 = (int64_t *)(iVar1 + 0x10), piVar15 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624010);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    piVar11 = piVar8 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8 + 2) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x0001800536b5;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar11 + 0x18 != 0) {
        piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        piVar8 = piVar12;
        if (*(int64_t **)(arg1 + 0x40) <= piVar12) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 != *(int64_t **)0x180782430) &&
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 6 || (*(int32_t *)((int64_t)piVar8 + 0xc) == 3)))) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar12) {
                piVar12 = *(int64_t **)0x180782430;
            }
            if (piVar12 == *(int64_t **)0x180782430) {
                piVar12 = (int64_t *)0x0;
            }
            iVar2 = *piVar12;
            if (iVar2 != 0) {
                iVar7 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar7 == 0x5f879bcf) {
                    uVar9 = func_0x000180088040(arg1, *(undefined8 *)(iVar1 + 0x28));
                    func_0x000180498030(uVar9, *piVar15, *(undefined8 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == 0x78793741) {
                    func_0x0001800867f0(arg1, *piVar15, *(undefined8 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == -0x301a3c57) {
                    func_0x000180086fd0(arg1, *(undefined4 *)(iVar1 + 0x28), 0);
                    uVar14 = 0;
                    if (*(int64_t *)(iVar1 + 0x28) != 0) {
                        do {
                            func_0x0001800865e0(arg1, *(undefined *)(uVar14 + *piVar15));
                            iVar2 = *(int64_t *)(arg1 + 0x40);
                            if (*(char *)(*(int64_t *)(iVar2 + -0x20) + 4) != '\0') {
                                func_0x000180092f10(arg1);
                                pcVar4 = (code *)swi(3);
                                uVar9 = (*pcVar4)();
                                return uVar9;
                            }
                            uVar13 = (int32_t)uVar14 + 1;
                            uVar14 = (uint64_t)uVar13;
                            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar2 + -0x20), uVar13);
                            uVar16 = *(undefined4 *)(iVar2 + -0xc);
                            uVar5 = *(undefined4 *)(iVar2 + -8);
                            uVar6 = *(undefined4 *)(iVar2 + -4);
                            *puVar10 = *(undefined4 *)(iVar2 + -0x10);
                            puVar10[1] = uVar16;
                            puVar10[2] = uVar5;
                            puVar10[3] = uVar6;
                            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                                iVar2 = *(int64_t *)(iVar2 + -0x20);
                                if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
                                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                                    iVar3 = *(int64_t *)(arg1 + 0x20);
                                    if (*(char *)(iVar3 + 0x59) == '\x02') {
                                        func_0x000180094420();
                                    } else {
                                        *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                                        *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                                        *(int64_t *)(iVar3 + 0x18) = iVar2;
                                    }
                                }
                            }
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        } while ((uint64_t)uVar13 < *(uint64_t *)(iVar1 + 0x28));
                    }
                    return 1;
                }
                if (iVar7 == 0x235ce5cd) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x30));
                    return 1;
                }
                if (iVar7 == 0x4d97b695) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x34));
                    return 1;
                }
                if (iVar7 == -0x48e6d56a) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x38));
                    return 1;
                }
                if (iVar7 == 0x70002f) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x28));
                    return 1;
                }
                if (iVar7 == 0x47ecaf93) {
                    if ((undefined *)*piVar15 != *(undefined **)(iVar1 + 0x18)) {
                        func_0x0001800865e0(arg1, *(undefined *)*piVar15);
                        return 1;
                    }
                    func_0x0001800865e0(arg1, 0);
                    return 1;
                }
                if (iVar7 == 0x6062919d) {
                    uVar16 = func_0x000180018f70();
                    func_0x00018001afc0(uVar16, arg1, 0x1800530f0, 0x180623fc0);
                    return 1;
                }
                if (iVar7 == 0x1049846d) {
                    uVar16 = func_0x000180018f70();
                    func_0x00018001afc0(uVar16, arg1, fcn.1800532b0, 0x180623fc8);
                    return 1;
                }
            }
        }
        fcn.180088560(arg1, 0x180624040, *piVar11 + 0x18);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
code_r0x0001800536b5:
    func_0x000180088470(arg1, 2, 6);
    pcVar4 = (code *)swi(3);
    uVar9 = (*pcVar4)();
    return uVar9;
}

// ============================================================
// Function: FUN_1800536d0
// Address: 0x1800536d0
// Size: 142 bytes
// ============================================================
undefined8 fcn.1800536d0(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int32_t iVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    uint64_t *puVar12;
    uint64_t uVar13;
    undefined8 uStack_80;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar5 + 0xc) != 9) || (*(char *)(*piVar5 + 3) != '|')) || (*piVar5 == -0x10)) {
        fcn.1800883d0(arg1, 1, 0x180624010);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    iVar1 = *(int64_t *)(arg1 + 8);
    if (iVar1 == 0) {
        fcn.180088560(arg1, 0x180624070);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    iVar7 = *(int32_t *)(iVar1 + 0x10) + 0x10 + (int32_t)iVar1;
    if (iVar7 != 0x6062919d) {
        if (iVar7 != 0x1049846d) {
            fcn.180088560(arg1, 0x180624040, iVar1 + 0x18);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if (((*(int32_t *)((int64_t)piVar5 + 0xc) == 9) && (iVar1 = *piVar5, *(char *)(iVar1 + 3) == '|')) &&
           (iVar1 != -0x10)) {
            *(undefined *)(iVar1 + 0x3d) = 1;
            return 0;
        }
        fcn.1800883d0(arg1, 1, 0x180624010);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    puVar9 = auStack_78;
    puVar10 = auStack_78;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar5 + 0xc) == 9) && (iVar1 = *piVar5, *(char *)(iVar1 + 3) == '|')) &&
       (puVar12 = (uint64_t *)(iVar1 + 0x10), puVar12 != (uint64_t *)0x0)) {
        func_0x000180052d70(&var_58h, arg1, 2);
        uVar13 = var_50h - var_58h;
        uVar8 = *puVar12;
        uVar6 = *(int64_t *)(iVar1 + 0x20) - uVar8;
        if (uVar6 < uVar13) {
            if (0x7fffffffffffffff < uVar13) {
                func_0x000180010010();
                goto code_r0x000180053295;
            }
            uVar11 = 0x7fffffffffffffff;
            if ((uVar6 <= 0x7fffffffffffffff - (uVar6 >> 1)) && (uVar11 = uVar6 + (uVar6 >> 1), uVar11 < uVar13)) {
                uVar11 = uVar13;
            }
            if (uVar8 != 0) {
                uVar6 = uVar8;
                puVar9 = auStack_78;
                if (0xfff < *(int64_t *)(iVar1 + 0x20) - uVar8) {
                    uVar6 = *(uint64_t *)(uVar8 - 8);
                    uVar8 = (uVar8 - uVar6) - 8;
                    puVar9 = auStack_78;
                    if (0x1f < uVar8) {
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        uVar6 = uVar8;
                        puVar9 = auStack_70;
                    }
                }
                *(undefined8 *)(puVar9 + -8) = 0x1800531d0;
                func_0x000180459c3c(uVar6);
                *puVar12 = 0;
                *(undefined8 *)(iVar1 + 0x18) = 0;
                *(undefined8 *)(iVar1 + 0x20) = 0;
            }
            *(undefined8 *)(puVar9 + -8) = 0x1800531e8;
            func_0x000180054ef0(puVar12, uVar11);
            uVar8 = *puVar12;
            *(undefined8 *)(puVar9 + -8) = 0x1800531f9;
            func_0x000180498030(uVar8, var_58h, uVar13);
            iVar3 = uVar8 + uVar13;
            puVar10 = puVar9;
        } else {
            uVar6 = *(int64_t *)(iVar1 + 0x18) - uVar8;
            iVar3 = var_58h;
            if (uVar6 < uVar13) {
                func_0x000180498030(uVar8, var_58h, uVar6);
                uVar8 = *(uint64_t *)(iVar1 + 0x18);
                uVar13 = uVar13 - uVar6;
                iVar3 = uVar6 + var_58h;
            }
            func_0x000180498030(uVar8, iVar3, uVar13);
            iVar3 = uVar13 + uVar8;
        }
        *(int64_t *)(iVar1 + 0x18) = iVar3;
        *(int64_t *)(iVar1 + 0x28) = var_50h - var_58h;
        *(undefined *)(iVar1 + 0x3c) = 1;
        if (var_58h != 0) {
            uVar8 = var_58h;
            if (0xfff < (uint64_t)(*(int64_t *)(puVar10 + 0x30) - var_58h)) {
                uVar8 = *(uint64_t *)(var_58h + -8);
                uVar6 = (var_58h - uVar8) - 8;
                if (0x1f < uVar6) {
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    puVar10 = puVar10 + 8;
                    uVar8 = uVar6;
                }
            }
            *(undefined8 *)(puVar10 + -8) = 0x18005327e;
            func_0x000180459c3c(uVar8);
        }
        return 0;
    }
code_r0x000180053295:
    fcn.1800883d0();
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_180053760
// Address: 0x180053760
// Size: 32 bytes
// ============================================================
undefined8 fcn.180053760(undefined8 param_1)
{
    fcn.1800867f0(param_1, 0x180624010, 0xc);
    return 1;
}

// ============================================================
// Function: FUN_180053780
// Address: 0x180053780
// Size: 90 bytes
// ============================================================
void fcn.180053780(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar1 = *(int64_t *)arg2;
    if (iVar1 != 0) {
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg2 + 0x10) - iVar1)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800537c7;
        func_0x000180459c3c(iVar3);
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)(arg2 + 8) = 0;
        *(undefined8 *)(arg2 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800537e0
// Address: 0x1800537e0
// Size: 2705 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_117h

void fcn.1800537e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_70h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
                  int64_t arg_b0h)
{
    int64_t **ppiVar1;
    uint64_t *puVar2;
    uint8_t uVar3;
    uint64_t uVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    uint32_t uVar10;
    int32_t iVar11;
    char *pcVar12;
    int64_t *piVar13;
    int64_t iVar14;
    uint64_t uVar15;
    undefined8 *puVar16;
    undefined4 *puVar17;
    undefined4 *puVar18;
    int64_t iVar19;
    int32_t iVar20;
    int32_t iVar21;
    int32_t iVar22;
    undefined *puVar23;
    undefined *puVar24;
    undefined *puVar25;
    undefined *puVar26;
    int64_t *piVar27;
    uint64_t uVar28;
    undefined4 uVar29;
    undefined4 uVar30;
    uint64_t uVar31;
    int64_t *unaff_R14;
    uint64_t uVar32;
    undefined auVar33 [16];
    undefined auVar34 [16];
    char in_stack_00000028;
    undefined8 in_stack_00000030;
    undefined in_stack_00000038;
    undefined4 in_stack_00000040;
    int64_t in_stack_00000048;
    undefined8 uStack_170;
    undefined auStack_168 [8];
    undefined auStack_160 [24];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    char var_118h;
    char var_117h;
    int64_t var_114h;
    int32_t var_10ch;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    undefined8 uStack_e8;
    uint64_t uStack_e0;
    undefined auStack_d8 [16];
    uint64_t uStack_c8;
    int64_t iStack_c0;
    undefined auStack_b8 [16];
    int64_t iStack_a8;
    undefined4 uStack_a0;
    int64_t iStack_98;
    undefined auStack_90 [16];
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar30 = (undefined4)arg4;
    uVar29 = (undefined4)arg3;
    var_114h._0_4_ = 0;
    puVar26 = auStack_168;
    if ((arg2 == 0) || (puVar26 = auStack_168, *(int64_t **)arg2 == (int64_t *)0x0)) goto code_r0x0001800541c9;
    uVar10 = (**(code **)(**(int64_t **)arg2 + 0x10))();
    uVar28 = (uint64_t)uVar10;
    pcVar12 = (char *)(**(code **)(**(int64_t **)arg2 + 8))();
    puVar26 = auStack_168;
    if ((uVar10 == 0) || (puVar26 = auStack_168, *pcVar12 == -0x7d)) goto code_r0x0001800541c9;
    uVar31 = 0;
    var_f8h = 0;
    uStack_c8 = 0;
    auStack_d8 = ZEXT816(0);
    piVar13 = (int64_t *)func_0x000180008740();
    iVar19 = *(int64_t *)(*piVar13 + 0x10);
    _var_f0h = ZEXT816(0);
    uVar32 = 0;
    uStack_e0 = 0;
    if (uVar28 == 0) {
        var_100h = 0;
        unaff_R14 = (int64_t *)0x0;
code_r0x000180053923:
        auVar33 = _var_f0h;
        uVar32 = var_100h;
        puVar25 = auStack_168;
        puVar26 = auStack_168;
        puVar24 = auStack_168;
        uVar28 = *(uint64_t *)(*(int64_t *)(iVar19 + 0x20) + 0x1d8);
        if (*(int64_t *)(uVar28 + 0x30) - *(int64_t *)(uVar28 + 0x40) < 0x31) {
            iVar11 = *(int32_t *)(uVar28 + 0x60);
            iVar22 = (int32_t)(int32_t *)(uVar28 + 0x60);
            iVar21 = iVar11 - iVar22;
            if (iVar11 - iVar22 < 3) {
                iVar21 = iVar21 + 3;
            } else {
                iVar21 = iVar21 * 2;
            }
            func_0x000180093240(uVar28, iVar21, 0);
        }
        uVar15 = *(int64_t *)(uVar28 + 0x40) + 0x30;
        if (**(uint64_t **)(uVar28 + 0x18) < uVar15) {
            **(uint64_t **)(uVar28 + 0x18) = uVar15;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(uVar28 + 0x18) < *(int64_t *)(uVar28 + 0x40) + 0x10U))
           && (iVar11 = func_0x000180085510(uVar28, 1), iVar11 == 0)) {
code_r0x000180054253:
            func_0x000180099450(uVar28, 0x18063d8d0);
            fcn.180087960(uVar28);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        puVar16 = *(undefined8 **)(uVar28 + 0x40);
        *puVar16 = 0x1807824b8;
        *(undefined4 *)(puVar16 + 1) = 0;
        *(undefined4 *)((int64_t)puVar16 + 0xc) = 2;
        *(int64_t *)(uVar28 + 0x40) = *(int64_t *)(uVar28 + 0x40) + 0x10;
        if ((*(uint8_t *)(uVar28 + 1) & 4) != 0) {
            *(uint8_t *)(uVar28 + 1) = *(uint8_t *)(uVar28 + 1) & 0xfb;
            *(undefined8 *)(uVar28 + 0x48) = *(undefined8 *)(*(int64_t *)(uVar28 + 0x20) + 0x18);
            *(uint64_t *)(*(int64_t *)(uVar28 + 0x20) + 0x18) = uVar28;
        }
        puVar16 = (undefined8 *)fcn.180085370(uVar28, 0xffffd8f0);
        iVar19 = *(int64_t *)(uVar28 + 0x40);
        puVar17 = (undefined4 *)func_0x0001800a0ea0(*puVar16, iVar19 + -0x10);
        uVar6 = puVar17[1];
        uVar7 = puVar17[2];
        uVar8 = puVar17[3];
        *(undefined4 *)(iVar19 + -0x10) = *puVar17;
        *(undefined4 *)(iVar19 + -0xc) = uVar6;
        *(undefined4 *)(iVar19 + -8) = uVar7;
        *(undefined4 *)(iVar19 + -4) = uVar8;
        puVar16 = (undefined8 *)(*(int64_t *)(uVar28 + 0x40) + -0x10);
        if ((puVar16 == *(undefined8 **)0x180782430) || (*(int32_t *)(*(int64_t *)(uVar28 + 0x40) + -4) != 7)) {
            *(undefined8 **)(uVar28 + 0x40) = puVar16;
code_r0x000180054151:
            puVar25 = auStack_168;
            if (unaff_R14 != (int64_t *)0x0) {
                uVar32 = uVar32 - (int64_t)unaff_R14;
                puVar25 = auStack_168;
                if (0xfff < uVar32) {
                    ppiVar1 = (int64_t **)(unaff_R14 + -1);
                    unaff_R14 = (int64_t *)((int64_t)unaff_R14 + (-8 - (int64_t)*ppiVar1));
                    puVar23 = auStack_168;
                    if ((int64_t *)0x1f < unaff_R14) goto code_r0x000180054179;
                    uVar32 = uVar32 + 0x27;
                    unaff_R14 = *ppiVar1;
                    puVar25 = auStack_168;
                }
                goto code_r0x000180054183;
            }
            goto code_r0x00018005418b;
        }
        var_108h._0_4_ = func_0x0001800a1110(*puVar16);
        if ((int32_t)var_108h == 0) {
            *(int64_t *)(uVar28 + 0x40) = *(int64_t *)(uVar28 + 0x40) + -0x10;
            goto code_r0x000180054151;
        }
        var_118h = '\0';
        var_114h._4_4_ = 1;
        iVar19 = uVar32;
        if (0 < (int32_t)var_108h) {
            do {
                iVar11 = var_114h._4_4_;
                if (*(int64_t *)(uVar28 + 0x30) - *(int64_t *)(uVar28 + 0x40) < 0x31) {
                    iVar21 = *(int32_t *)(uVar28 + 0x60);
                    iVar20 = (int32_t)(int32_t *)(uVar28 + 0x60);
                    iVar22 = iVar21 - iVar20;
                    if (iVar21 - iVar20 < 3) {
                        iVar22 = iVar22 + 3;
                    } else {
                        iVar22 = iVar22 * 2;
                    }
                    func_0x000180093240(uVar28, iVar22, 0);
                }
                if (**(uint64_t **)(uVar28 + 0x18) < *(int64_t *)(uVar28 + 0x40) + 0x30U) {
                    **(uint64_t **)(uVar28 + 0x18) = *(int64_t *)(uVar28 + 0x40) + 0x30;
                }
                if ((*(uint8_t *)(uVar28 + 1) & 4) != 0) {
                    *(uint8_t *)(uVar28 + 1) = *(uint8_t *)(uVar28 + 1) & 0xfb;
                    *(undefined8 *)(uVar28 + 0x48) = *(undefined8 *)(*(int64_t *)(uVar28 + 0x20) + 0x18);
                    *(uint64_t *)(*(int64_t *)(uVar28 + 0x20) + 0x18) = uVar28;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(uVar28 + 0x18) < *(int64_t *)(uVar28 + 0x40) + 0x10U)) &&
                   (iVar21 = func_0x000180085510(uVar28, 1), iVar21 == 0)) goto code_r0x000180054253;
                puVar17 = *(undefined4 **)(uVar28 + 0x40);
                puVar18 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar17 + -4), iVar11);
                uVar6 = puVar18[1];
                uVar7 = puVar18[2];
                uVar8 = puVar18[3];
                *puVar17 = *puVar18;
                puVar17[1] = uVar6;
                puVar17[2] = uVar7;
                puVar17[3] = uVar8;
                puVar16 = *(undefined8 **)(uVar28 + 0x40);
                *(undefined8 **)(uVar28 + 0x40) = puVar16 + 2;
                if ((puVar16 != *(undefined8 **)0x180782430) && (*(int32_t *)((int64_t)puVar16 + 0xc) == 8)) {
                    piVar13 = (int64_t *)func_0x000180087f70(uVar28, 0x30, 0x7c);
                    uVar31 = iVar19 - (int64_t)unaff_R14;
                    *piVar13 = 0;
                    piVar13[1] = 0;
                    piVar13[2] = 0;
                    if (uVar31 != 0) {
                        if (uVar31 < 0x8000000000000000) {
                            func_0x000180054ef0(piVar13, uVar31);
                            iVar19 = *piVar13;
                            func_0x000180498030(iVar19, unaff_R14, uVar31);
                            piVar13[1] = uVar31 + iVar19;
                            goto code_r0x000180053b92;
                        }
code_r0x000180054241:
                        func_0x000180010010();
                        goto code_r0x000180054247;
                    }
code_r0x000180053b92:
                    piVar27 = (int64_t *)0x0;
                    piVar13[3] = uVar31;
                    *(undefined2 *)((int64_t)piVar13 + 0x2c) = 0;
                    *(undefined4 *)(piVar13 + 4) = uVar29;
                    *(undefined4 *)((int64_t)piVar13 + 0x24) = uVar30;
                    *(uint32_t *)(piVar13 + 5) = (uint32_t)(in_stack_00000028 != '\0');
                    iVar11 = func_0x0001800885b0(uVar28, 0x180624010);
                    if (iVar11 != 0) {
                        var_148h = 0;
                        func_0x0001800869f0(uVar28, fcn.180053300, 0, 0);
                        func_0x000180087370(uVar28, 0xfffffffe, 0x1805aae90);
                        var_148h = 0;
                        func_0x0001800869f0(uVar28, fcn.1800536d0, 0, 0);
                        func_0x000180087370(uVar28, 0xfffffffe, 0x1806203d0);
                        var_148h = 0;
                        func_0x0001800869f0(uVar28, fcn.180053760, 0, 0);
                        func_0x000180087370(uVar28, 0xfffffffe, 0x180622440);
                        fcn.1800867f0(uVar28, 0x180624010, 0xc);
                        func_0x000180087370(uVar28, 0xfffffffe, 0x180622470);
                        fcn.1800867f0(uVar28, 0x180622458, 0x17);
                        func_0x000180087370(uVar28, 0xfffffffe, 0x1806224a0);
                        *(undefined *)(*(int64_t *)(*(int64_t *)(uVar28 + 0x40) + -0x10) + 4) = 1;
                    }
                    func_0x000180087650(uVar28, 0xfffffffe);
                    iStack_a8 = *(int64_t *)(uVar28 + 0x40);
                    piVar13 = piVar27;
                    if ((*(int32_t *)(iStack_a8 + -4) == 9) && (*(char *)(*(int64_t *)(iStack_a8 + -0x10) + 3) == '|'))
                    {
                        piVar13 = (int64_t *)(*(int64_t *)(iStack_a8 + -0x10) + 0x10);
                    }
                    iStack_a8 = iStack_a8 + -0x20;
                    uStack_a0 = 0;
                    var_148h = 0;
                    var_10ch = func_0x000180094080(uVar28);
                    var_117h = *(char *)((int64_t)piVar13 + 0x2d);
                    uVar3 = *(uint8_t *)((int64_t)piVar13 + 0x2c);
                    uVar31 = (uint64_t)uVar3;
                    if (uVar3 == 0) {
                        auStack_90 = ZEXT816(0);
                        piVar13 = &iStack_98;
                        var_114h._0_4_ = (uint32_t)var_114h | 2;
code_r0x000180053ddc:
                        uVar4 = piVar13[2];
                        piVar13[2] = 0;
                        iVar19 = piVar13[1];
                        piVar13[1] = 0;
                        *piVar13 = 0;
                        if ((((uint32_t)var_114h & 2) == 0) ||
                           (var_114h._0_4_ = (uint32_t)var_114h & 0xfffffffd, iStack_98 == 0)) {
code_r0x000180053e41:
                            if ((((uint32_t)var_114h & 1) != 0) &&
                               (var_114h._0_4_ = (uint32_t)var_114h & 0xfffffffe, iStack_c0 != 0)) {
                                uVar15 = auStack_b8._8_8_ - iStack_c0;
                                iVar14 = iStack_c0;
                                if (0xfff < uVar15) {
                                    if (0x1f < (iStack_c0 - *(int64_t *)(iStack_c0 + -8)) - 8U)
                                    goto code_r0x000180053f6a;
                                    uVar15 = uVar15 + 0x27;
                                    iVar14 = *(int64_t *)(iStack_c0 + -8);
                                }
                                func_0x000180459c3c(iVar14, uVar15);
                            }
                            piVar13 = piVar27;
                            uVar15 = uVar4;
                            if (var_10ch == 0) {
                                puVar23 = auStack_168;
                                if (var_117h != '\0') goto code_r0x000180053f71;
                                if (uVar3 != 0) {
                                    if (unaff_R14 != (int64_t *)0x0) {
                                        uVar32 = uVar32 - (int64_t)unaff_R14;
                                        if (0xfff < uVar32) {
                                            ppiVar1 = (int64_t **)(unaff_R14 + -1);
                                            unaff_R14 = (int64_t *)((int64_t)unaff_R14 + (-8 - (int64_t)*ppiVar1));
                                            if ((int64_t *)0x1f < unaff_R14) goto code_r0x000180053f6a;
                                            uVar32 = uVar32 + 0x27;
                                            unaff_R14 = *ppiVar1;
                                        }
                                        func_0x000180459c3c(unaff_R14, uVar32);
                                    }
                                    uStack_e8 = iVar19;
                                    var_f0h = (int64_t)piVar27;
                                    piVar13 = (int64_t *)0x0;
                                    uVar15 = 0;
                                    var_118h = '\x01';
                                    unaff_R14 = piVar27;
                                    uVar32 = uVar4;
                                    var_100h = iVar19;
                                    uStack_e0 = uVar4;
                                }
                            } else {
                                *(int64_t *)(uVar28 + 0x40) = *(int64_t *)(uVar28 + 0x40) + -0x10;
                            }
                            if (piVar13 != (int64_t *)0x0) {
                                uVar15 = uVar15 - (int64_t)piVar13;
                                if (uVar15 < 0x1000) {
                                    func_0x000180459c3c(piVar13, uVar15);
                                } else {
                                    piVar27 = (int64_t *)((int64_t)piVar13 + (-8 - piVar13[-1]));
                                    puVar23 = auStack_168;
                                    if ((int64_t *)0x1f < piVar27) goto code_r0x000180053f9e;
                                    func_0x000180459c3c(piVar13[-1], uVar15 + 0x27);
                                }
                            }
                            goto code_r0x000180053f4a;
                        }
                        uVar15 = auStack_90._8_8_ - iStack_98;
                        iVar14 = iStack_98;
                        if (uVar15 < 0x1000) {
code_r0x000180053e38:
                            func_0x000180459c3c(iVar14, uVar15);
                            goto code_r0x000180053e41;
                        }
                        if ((iStack_98 - *(int64_t *)(iStack_98 + -8)) - 8U < 0x20) {
                            uVar15 = uVar15 + 0x27;
                            iVar14 = *(int64_t *)(iStack_98 + -8);
                            goto code_r0x000180053e38;
                        }
code_r0x000180053f6a:
                        pcVar5 = (code *)swi(0x29);
                        (*pcVar5)(5);
                        puVar23 = auStack_160;
code_r0x000180053f71:
                        *(int64_t *)(uVar28 + 0x40) = *(int64_t *)(uVar28 + 0x40) + -0x10;
                        puVar24 = puVar23;
                        if (piVar27 != (int64_t *)0x0) {
                            uVar15 = uVar4 - (int64_t)piVar27;
                            if (0xfff < uVar15) {
                                ppiVar1 = (int64_t **)(piVar27 + -1);
                                piVar27 = (int64_t *)((int64_t)piVar27 + (-8 - (int64_t)*ppiVar1));
                                if ((int64_t *)0x1f < piVar27) goto code_r0x000180053f9e;
                                uVar15 = uVar15 + 0x27;
                                piVar27 = *ppiVar1;
                            }
                            goto code_r0x000180053fa8;
                        }
                    } else {
                        auStack_b8 = ZEXT816(0);
                        uVar15 = piVar13[1] - *piVar13;
                        piVar27 = (int64_t *)0x0;
                        if (uVar15 == 0) {
code_r0x000180053dbc:
                            piVar13 = &iStack_c0;
                            var_114h._0_4_ = (uint32_t)var_114h | 1;
                            goto code_r0x000180053ddc;
                        }
                        if (0x7fffffffffffffff < uVar15) goto code_r0x000180054241;
                        if (uVar15 < 0x1000) {
                            piVar27 = (int64_t *)func_0x000180459890(uVar15);
code_r0x000180053d95:
                            auStack_b8._8_8_ = (int64_t)piVar27 + uVar15;
                            iVar19 = *piVar13;
                            iVar14 = piVar13[1];
                            func_0x000180498030(piVar27);
                            auStack_b8._0_8_ = (int64_t)piVar27 + (iVar14 - iVar19);
                            goto code_r0x000180053dbc;
                        }
                        if (uVar15 + 0x27 <= uVar15) {
                            func_0x000180004720();
                            pcVar5 = (code *)swi(3);
                            (*pcVar5)();
                            return;
                        }
                        iVar19 = func_0x000180459890();
                        puVar23 = auStack_168;
                        if (iVar19 != 0) {
                            piVar27 = (int64_t *)(iVar19 + 0x27U & 0xffffffffffffffe0);
                            piVar27[-1] = iVar19;
                            goto code_r0x000180053d95;
                        }
code_r0x000180053f9e:
                        pcVar5 = (code *)swi(0x29);
                        (*pcVar5)(5);
                        puVar23 = puVar23 + 8;
code_r0x000180053fa8:
                        *(undefined8 *)(puVar23 + -8) = 0x180053fb0;
                        func_0x000180459c3c(piVar27, uVar15);
                        puVar24 = puVar23;
                    }
                    if (unaff_R14 != (int64_t *)0x0) {
                        uVar32 = uVar32 - (int64_t)unaff_R14;
                        if (0xfff < uVar32) {
                            ppiVar1 = (int64_t **)(unaff_R14 + -1);
                            unaff_R14 = (int64_t *)((int64_t)unaff_R14 + (-8 - (int64_t)*ppiVar1));
                            puVar23 = puVar24;
                            if ((int64_t *)0x1f < unaff_R14) goto code_r0x000180054179;
                            uVar32 = uVar32 + 0x27;
                            unaff_R14 = *ppiVar1;
                        }
                        *(undefined8 *)(puVar24 + -8) = 0x180053fe8;
                        func_0x000180459c3c(unaff_R14, uVar32);
                    }
                    uVar31 = *(uint64_t *)(puVar24 + 0x70);
                    uVar28 = auStack_d8._0_8_;
                    goto code_r0x000180054102;
                }
                *(undefined8 **)(uVar28 + 0x40) = puVar16;
code_r0x000180053f4a:
                var_114h._4_4_ = var_114h._4_4_ + 1;
                iVar19 = var_100h;
                uVar31 = var_f8h;
                auVar33 = _var_f0h;
            } while (var_114h._4_4_ <= (int32_t)var_108h);
        }
        cVar9 = var_118h;
        *(int64_t *)(uVar28 + 0x40) = *(int64_t *)(uVar28 + 0x40) + -0x10;
        auVar34 = ZEXT816(0);
        if (var_118h != '\0') {
            uStack_c8 = uStack_e0;
            unaff_R14 = (int64_t *)0x0;
            uVar32 = 0;
            uVar31 = uStack_e0;
            auVar34 = auVar33;
            auStack_d8 = auVar33;
        }
        if (unaff_R14 != (int64_t *)0x0) {
            uVar32 = uVar32 - (int64_t)unaff_R14;
            if (0xfff < uVar32) {
                ppiVar1 = (int64_t **)(unaff_R14 + -1);
                unaff_R14 = (int64_t *)((int64_t)unaff_R14 + (-8 - (int64_t)*ppiVar1));
                puVar23 = auStack_168;
                if ((int64_t *)0x1f < unaff_R14) goto code_r0x000180054179;
                uVar32 = uVar32 + 0x27;
                unaff_R14 = *ppiVar1;
            }
            func_0x000180459c3c(unaff_R14, uVar32);
        }
        if (cVar9 == '\0') goto code_r0x00018005418b;
        uVar28 = auVar34._0_8_;
        if (uVar28 == auVar34._8_8_) goto code_r0x00018005418f;
        iVar19 = *(int64_t *)arg2;
        *(uint64_t *)(iVar19 + 0x10) = uVar28;
        iVar11 = auVar34._8_4_ - auVar34._0_4_;
        *(int32_t *)(iVar19 + 0x30) = iVar11;
        *(int32_t *)(iVar19 + 0x34) = iVar11;
        *(undefined *)(iVar19 + 0x3e) = 0;
        var_128h = in_stack_00000048;
        var_148h = CONCAT71(var_148h._1_7_, in_stack_00000028);
        (**(code **)0x180782148)(arg1, arg2, uVar29, uVar30);
        *(undefined8 *)(iVar19 + 0x10) = 0;
        *(undefined4 *)(iVar19 + 0x34) = 0;
        *(undefined *)(iVar19 + 0x3e) = 0;
code_r0x000180054102:
        if (uVar28 == 0) {
            return;
        }
        uVar31 = uVar31 - uVar28;
        if (uVar31 < 0x1000) {
            *(undefined8 *)(puVar24 + -8) = 0x180054148;
            func_0x000180459c3c(uVar28, uVar31);
            return;
        }
        iVar19 = *(int64_t *)(uVar28 - 8);
        uVar28 = (uVar28 - iVar19) - 8;
        if (uVar28 < 0x20) {
            *(undefined8 *)(puVar24 + -8) = 0x180054138;
            func_0x000180459c3c(iVar19, uVar31 + 0x27);
            return;
        }
code_r0x0001800541b7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar26 = puVar24 + 8;
    } else {
        if (0x7fffffffffffffff < uVar28) {
code_r0x000180054247:
            func_0x000180010010();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        if (uVar28 < 0x1000) {
            unaff_R14 = (int64_t *)func_0x000180459890(uVar28);
code_r0x0001800538dd:
            var_f0h = (int64_t)unaff_R14;
            uVar32 = uVar28 + (int64_t)unaff_R14;
            uStack_e0 = uVar32;
            func_0x000180498030(unaff_R14, pcVar12, uVar28);
            uStack_e8 = uVar32;
            var_100h = uVar32;
            goto code_r0x000180053923;
        }
        if (uVar28 + 0x27 <= uVar28) {
            func_0x000180004720();
            goto code_r0x000180054253;
        }
        iVar14 = func_0x000180459890();
        puVar23 = auStack_168;
        if (iVar14 != 0) {
            unaff_R14 = (int64_t *)(iVar14 + 0x27U & 0xffffffffffffffe0);
            unaff_R14[-1] = iVar14;
            goto code_r0x0001800538dd;
        }
code_r0x000180054179:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar25 = puVar23 + 8;
code_r0x000180054183:
        *(undefined8 *)(puVar25 + -8) = 0x18005418b;
        func_0x000180459c3c(unaff_R14, uVar32);
code_r0x00018005418b:
        puVar26 = puVar25;
        uVar28 = auStack_d8._0_8_;
code_r0x00018005418f:
        if (uVar28 == 0) goto code_r0x0001800541c9;
        uVar31 = uVar31 - uVar28;
        if (0xfff < uVar31) {
            puVar2 = (uint64_t *)(uVar28 - 8);
            uVar28 = (uVar28 - *puVar2) - 8;
            puVar24 = puVar26;
            if (0x1f < uVar28) goto code_r0x0001800541b7;
            uVar31 = uVar31 + 0x27;
            uVar28 = *puVar2;
        }
    }
    *(undefined8 *)(puVar26 + -8) = 0x1800541c9;
    func_0x000180459c3c(uVar28, uVar31);
code_r0x0001800541c9:
    *(int64_t *)(puVar26 + 0x40) = in_stack_00000048;
    *(undefined4 *)(puVar26 + 0x38) = in_stack_00000040;
    puVar26[0x30] = in_stack_00000038;
    *(undefined8 *)(puVar26 + 0x28) = in_stack_00000030;
    puVar26[0x20] = in_stack_00000028;
    *(undefined8 *)(puVar26 + -8) = 0x18005421d;
    (**(code **)0x180782148)(arg1, arg2, uVar29, uVar30);
    return;
}

// ============================================================
// Function: FUN_180054280
// Address: 0x180054280
// Size: 619 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_117h

void fcn.180054280(int64_t arg1, int64_t arg_a0h, int64_t arg_b0h)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    int64_t **ppiVar14;
    int64_t *piVar15;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
    func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaf20);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar10 = *(undefined4 **)(arg1 + 0x40);
    puVar2 = puVar10;
    while (puVar10 + -8 < puVar2) {
        *puVar2 = puVar2[-4];
        puVar2[1] = puVar2[-3];
        puVar2[2] = puVar2[-2];
        puVar2[3] = puVar2[-1];
        puVar2 = puVar2 + -4;
    }
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    uVar4 = puVar2[1];
    uVar5 = puVar2[2];
    uVar6 = puVar2[3];
    puVar10[-8] = *puVar2;
    puVar10[-7] = uVar4;
    puVar10[-6] = uVar5;
    puVar10[-5] = uVar6;
    fcn.1800867f0(arg1, 0x180624020, 0xd);
    var_38h = *(int64_t *)(arg1 + 0x40) + -0x30;
    var_30h._0_4_ = 1;
    iVar9 = func_0x000180094080(arg1, 0x180087890, &var_38h, var_38h - *(int64_t *)(arg1 + 0x38), 0);
    ppiVar14 = (int64_t **)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (iVar9 == 0) {
        iVar9 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
        if (iVar9 == 9) {
            piVar15 = *ppiVar14 + 2;
        } else if (iVar9 == 2) {
            piVar15 = *ppiVar14;
        } else {
            piVar15 = (int64_t *)0x0;
        }
        if (piVar15[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar15[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_38h = *piVar15;
        piVar15 = (int64_t *)piVar15[1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        piVar3 = **(int64_t ***)(var_38h + 0x138);
        puVar10 = *(undefined4 **)0x1807824c0;
        *(int64_t **)0x180782138 = piVar3;
        if (*(undefined4 **)0x1807824c0 == (undefined4 *)0x0) {
            puVar2 = (undefined4 *)*piVar3;
            puVar10 = (undefined4 *)(*(code *)0x699dcc)(0, 0x410, 0x3000, 4);
            iVar11 = 8;
            puVar7 = puVar10;
            puVar8 = puVar2;
            *(undefined4 **)0x1807824c0 = puVar10;
            do {
                puVar13 = puVar8;
                puVar12 = puVar7;
                uVar4 = puVar13[1];
                uVar5 = puVar13[2];
                uVar6 = puVar13[3];
                *puVar12 = *puVar13;
                puVar12[1] = uVar4;
                puVar12[2] = uVar5;
                puVar12[3] = uVar6;
                uVar4 = puVar13[5];
                uVar5 = puVar13[6];
                uVar6 = puVar13[7];
                puVar12[4] = puVar13[4];
                puVar12[5] = uVar4;
                puVar12[6] = uVar5;
                puVar12[7] = uVar6;
                uVar4 = puVar13[9];
                uVar5 = puVar13[10];
                uVar6 = puVar13[0xb];
                puVar12[8] = puVar13[8];
                puVar12[9] = uVar4;
                puVar12[10] = uVar5;
                puVar12[0xb] = uVar6;
                uVar4 = puVar13[0xd];
                uVar5 = puVar13[0xe];
                uVar6 = puVar13[0xf];
                puVar12[0xc] = puVar13[0xc];
                puVar12[0xd] = uVar4;
                puVar12[0xe] = uVar5;
                puVar12[0xf] = uVar6;
                uVar4 = puVar13[0x11];
                uVar5 = puVar13[0x12];
                uVar6 = puVar13[0x13];
                puVar12[0x10] = puVar13[0x10];
                puVar12[0x11] = uVar4;
                puVar12[0x12] = uVar5;
                puVar12[0x13] = uVar6;
                uVar4 = puVar13[0x15];
                uVar5 = puVar13[0x16];
                uVar6 = puVar13[0x17];
                puVar12[0x14] = puVar13[0x14];
                puVar12[0x15] = uVar4;
                puVar12[0x16] = uVar5;
                puVar12[0x17] = uVar6;
                uVar4 = puVar13[0x19];
                uVar5 = puVar13[0x1a];
                uVar6 = puVar13[0x1b];
                puVar12[0x18] = puVar13[0x18];
                puVar12[0x19] = uVar4;
                puVar12[0x1a] = uVar5;
                puVar12[0x1b] = uVar6;
                uVar4 = puVar13[0x1d];
                uVar5 = puVar13[0x1e];
                uVar6 = puVar13[0x1f];
                puVar12[0x1c] = puVar13[0x1c];
                puVar12[0x1d] = uVar4;
                puVar12[0x1e] = uVar5;
                puVar12[0x1f] = uVar6;
                iVar11 = iVar11 + -1;
                puVar7 = puVar12 + 0x20;
                puVar8 = puVar13 + 0x20;
            } while (iVar11 != 0);
            uVar4 = puVar13[0x21];
            uVar5 = puVar13[0x22];
            uVar6 = puVar13[0x23];
            puVar12[0x20] = puVar13[0x20];
            puVar12[0x21] = uVar4;
            puVar12[0x22] = uVar5;
            puVar12[0x23] = uVar6;
            *(undefined8 *)0x180782148 = *(undefined8 *)(puVar2 + 0x28);
            *(undefined8 *)0x180782140 = *(undefined8 *)(puVar2 + 0x2c);
        }
        if (*(undefined8 **)0x180782150 == (undefined8 *)0x0) {
            *(undefined8 **)0x180782150 = (undefined8 *)func_0x00018046d050(0x30);
            **(undefined8 **)0x180782150 = 0xffffffffffffffff;
            (*(undefined8 **)0x180782150)[1] = 0xffffffffffffffff;
            *(undefined (*) [16])(*(undefined8 **)0x180782150 + 2) = ZEXT816(0);
            *(undefined (*) [16])((int64_t)*(undefined8 **)0x180782150 + 0x1c) = ZEXT816(0);
            *(undefined2 *)(*(undefined8 **)0x180782150 + 2) = 2;
            *(undefined4 *)((int64_t)*(undefined8 **)0x180782150 + 0x2c) = 0xffff0000;
            puVar10 = *(undefined4 **)0x1807824c0;
        }
        *(code **)(puVar10 + 0x28) = fcn.1800537e0;
        *piVar3 = (int64_t)puVar10;
        if (piVar15 != (int64_t *)0x0) {
            LOCK();
            piVar3 = piVar15 + 1;
            iVar9 = *(int32_t *)piVar3;
            *(int32_t *)piVar3 = *(int32_t *)piVar3 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                (**(code **)*piVar15)(piVar15);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar15 + 0xc);
                iVar9 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)(*piVar15 + 8))(piVar15);
                }
            }
        }
        return;
    }
    *(int64_t ***)(arg1 + 0x40) = ppiVar14;
    return;
}

// ============================================================
// Function: FUN_1800544f0
// Address: 0x1800544f0
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800544f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000070;
    int64_t in_stack_00000080;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000070, in_stack_00000080);
    puVar9 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar9 = *(undefined8 **)0x180782430;
    }
    if ((puVar9 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar9 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x31) {
        iVar15 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar15 * 2;
        if (iVar15 < 3) {
            iVar8 = iVar15 + 3;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    puVar9 = *(undefined8 **)0x180782430;
    uVar10 = *(int64_t *)(iVar1 + 0x40) + 0x30;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar10) {
        **(uint64_t **)(iVar1 + 0x18) = uVar10;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), puVar9 = *(undefined8 **)0x180782430, iVar8 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    puVar11 = *(undefined8 **)(iVar1 + 0x40);
    *puVar11 = 0x1807824b8;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar11 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*puVar11, iVar2 + -0x10);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar12;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    puVar11 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((puVar11 == puVar9) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(undefined8 **)(iVar1 + 0x40) = puVar11;
    } else {
        iVar8 = func_0x0001800a1110(*puVar11);
        if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
            *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
            *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
        }
        puVar11 = *(undefined8 **)(iVar1 + 0x40);
        puVar17 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar17 = puVar9;
        }
        if (puVar17 == puVar9) {
            puVar17 = (undefined8 *)0x0;
        }
        *puVar11 = *puVar17;
        *(undefined4 *)((int64_t)puVar11 + 0xc) = 8;
        if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
            iVar16 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
            iVar15 = iVar16 * 2;
            if (iVar16 < 1) {
                iVar15 = iVar16 + 1;
            }
            func_0x000180093240(iVar1, iVar15, 0);
        }
        puVar12 = *(undefined4 **)(iVar1 + 0x40);
        *(undefined4 **)(iVar1 + 0x40) = puVar12 + 4;
        if (*(char *)(*(int64_t *)(puVar12 + -4) + 4) != '\0') {
            func_0x000180092f10(iVar1);
            pcVar4 = (code *)swi(3);
            uVar14 = (*pcVar4)();
            return uVar14;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar12 + -4), iVar8 + 1);
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *puVar13 = *puVar12;
        puVar13[1] = uVar5;
        puVar13[2] = uVar6;
        puVar13[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
            iVar2 = *(int64_t *)(puVar12 + -4);
            if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(iVar1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
        }
        *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x20;
    }
    return 0;
}

// ============================================================
// Function: FUN_180054534
// Address: 0x180054534
// Size: 272 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800544f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000070;
    int64_t in_stack_00000080;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000070, in_stack_00000080);
    puVar9 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar9 = *(undefined8 **)0x180782430;
    }
    if ((puVar9 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar9 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x31) {
        iVar15 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar15 * 2;
        if (iVar15 < 3) {
            iVar8 = iVar15 + 3;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    puVar9 = *(undefined8 **)0x180782430;
    uVar10 = *(int64_t *)(iVar1 + 0x40) + 0x30;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar10) {
        **(uint64_t **)(iVar1 + 0x18) = uVar10;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), puVar9 = *(undefined8 **)0x180782430, iVar8 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    puVar11 = *(undefined8 **)(iVar1 + 0x40);
    *puVar11 = 0x1807824b8;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar11 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*puVar11, iVar2 + -0x10);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar12;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    puVar11 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((puVar11 == puVar9) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(undefined8 **)(iVar1 + 0x40) = puVar11;
    } else {
        iVar8 = func_0x0001800a1110(*puVar11);
        if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
            *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
            *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
        }
        puVar11 = *(undefined8 **)(iVar1 + 0x40);
        puVar17 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar17 = puVar9;
        }
        if (puVar17 == puVar9) {
            puVar17 = (undefined8 *)0x0;
        }
        *puVar11 = *puVar17;
        *(undefined4 *)((int64_t)puVar11 + 0xc) = 8;
        if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
            iVar16 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
            iVar15 = iVar16 * 2;
            if (iVar16 < 1) {
                iVar15 = iVar16 + 1;
            }
            func_0x000180093240(iVar1, iVar15, 0);
        }
        puVar12 = *(undefined4 **)(iVar1 + 0x40);
        *(undefined4 **)(iVar1 + 0x40) = puVar12 + 4;
        if (*(char *)(*(int64_t *)(puVar12 + -4) + 4) != '\0') {
            func_0x000180092f10(iVar1);
            pcVar4 = (code *)swi(3);
            uVar14 = (*pcVar4)();
            return uVar14;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar12 + -4), iVar8 + 1);
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *puVar13 = *puVar12;
        puVar13[1] = uVar5;
        puVar13[2] = uVar6;
        puVar13[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
            iVar2 = *(int64_t *)(puVar12 + -4);
            if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(iVar1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
        }
        *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x20;
    }
    return 0;
}

// ============================================================
// Function: FUN_180054644
// Address: 0x180054644
// Size: 252 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800544f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000070;
    int64_t in_stack_00000080;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000070, in_stack_00000080);
    puVar9 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar9 = *(undefined8 **)0x180782430;
    }
    if ((puVar9 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar9 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x31) {
        iVar15 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar15 * 2;
        if (iVar15 < 3) {
            iVar8 = iVar15 + 3;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    puVar9 = *(undefined8 **)0x180782430;
    uVar10 = *(int64_t *)(iVar1 + 0x40) + 0x30;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar10) {
        **(uint64_t **)(iVar1 + 0x18) = uVar10;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), puVar9 = *(undefined8 **)0x180782430, iVar8 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    puVar11 = *(undefined8 **)(iVar1 + 0x40);
    *puVar11 = 0x1807824b8;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar11 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*puVar11, iVar2 + -0x10);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar12;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    puVar11 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((puVar11 == puVar9) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(undefined8 **)(iVar1 + 0x40) = puVar11;
    } else {
        iVar8 = func_0x0001800a1110(*puVar11);
        if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
            *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
            *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
        }
        puVar11 = *(undefined8 **)(iVar1 + 0x40);
        puVar17 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar17 = puVar9;
        }
        if (puVar17 == puVar9) {
            puVar17 = (undefined8 *)0x0;
        }
        *puVar11 = *puVar17;
        *(undefined4 *)((int64_t)puVar11 + 0xc) = 8;
        if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
            iVar16 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
            iVar15 = iVar16 * 2;
            if (iVar16 < 1) {
                iVar15 = iVar16 + 1;
            }
            func_0x000180093240(iVar1, iVar15, 0);
        }
        puVar12 = *(undefined4 **)(iVar1 + 0x40);
        *(undefined4 **)(iVar1 + 0x40) = puVar12 + 4;
        if (*(char *)(*(int64_t *)(puVar12 + -4) + 4) != '\0') {
            func_0x000180092f10(iVar1);
            pcVar4 = (code *)swi(3);
            uVar14 = (*pcVar4)();
            return uVar14;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar12 + -4), iVar8 + 1);
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *puVar13 = *puVar12;
        puVar13[1] = uVar5;
        puVar13[2] = uVar6;
        puVar13[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
            iVar2 = *(int64_t *)(puVar12 + -4);
            if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(iVar1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
        }
        *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x20;
    }
    return 0;
}

// ============================================================
// Function: FUN_180054740
// Address: 0x180054740
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800544f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000070;
    int64_t in_stack_00000080;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000070, in_stack_00000080);
    puVar9 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar9 = *(undefined8 **)0x180782430;
    }
    if ((puVar9 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar9 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x31) {
        iVar15 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar15 * 2;
        if (iVar15 < 3) {
            iVar8 = iVar15 + 3;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    puVar9 = *(undefined8 **)0x180782430;
    uVar10 = *(int64_t *)(iVar1 + 0x40) + 0x30;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar10) {
        **(uint64_t **)(iVar1 + 0x18) = uVar10;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), puVar9 = *(undefined8 **)0x180782430, iVar8 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    puVar11 = *(undefined8 **)(iVar1 + 0x40);
    *puVar11 = 0x1807824b8;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar11 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*puVar11, iVar2 + -0x10);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar12;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    puVar11 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((puVar11 == puVar9) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(undefined8 **)(iVar1 + 0x40) = puVar11;
    } else {
        iVar8 = func_0x0001800a1110(*puVar11);
        if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
            *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
            *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
        }
        puVar11 = *(undefined8 **)(iVar1 + 0x40);
        puVar17 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar17 = puVar9;
        }
        if (puVar17 == puVar9) {
            puVar17 = (undefined8 *)0x0;
        }
        *puVar11 = *puVar17;
        *(undefined4 *)((int64_t)puVar11 + 0xc) = 8;
        if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
            iVar16 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
            iVar15 = iVar16 * 2;
            if (iVar16 < 1) {
                iVar15 = iVar16 + 1;
            }
            func_0x000180093240(iVar1, iVar15, 0);
        }
        puVar12 = *(undefined4 **)(iVar1 + 0x40);
        *(undefined4 **)(iVar1 + 0x40) = puVar12 + 4;
        if (*(char *)(*(int64_t *)(puVar12 + -4) + 4) != '\0') {
            func_0x000180092f10(iVar1);
            pcVar4 = (code *)swi(3);
            uVar14 = (*pcVar4)();
            return uVar14;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar12 + -4), iVar8 + 1);
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *puVar13 = *puVar12;
        puVar13[1] = uVar5;
        puVar13[2] = uVar6;
        puVar13[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
            iVar2 = *(int64_t *)(puVar12 + -4);
            if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(iVar1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
        }
        *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x20;
    }
    return 0;
}

// ============================================================
// Function: FUN_180054755
// Address: 0x180054755
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800544f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000070;
    int64_t in_stack_00000080;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000070, in_stack_00000080);
    puVar9 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar9 = *(undefined8 **)0x180782430;
    }
    if ((puVar9 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar9 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x31) {
        iVar15 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar15 * 2;
        if (iVar15 < 3) {
            iVar8 = iVar15 + 3;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    puVar9 = *(undefined8 **)0x180782430;
    uVar10 = *(int64_t *)(iVar1 + 0x40) + 0x30;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar10) {
        **(uint64_t **)(iVar1 + 0x18) = uVar10;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), puVar9 = *(undefined8 **)0x180782430, iVar8 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    puVar11 = *(undefined8 **)(iVar1 + 0x40);
    *puVar11 = 0x1807824b8;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar11 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*puVar11, iVar2 + -0x10);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar12;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    puVar11 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((puVar11 == puVar9) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(undefined8 **)(iVar1 + 0x40) = puVar11;
    } else {
        iVar8 = func_0x0001800a1110(*puVar11);
        if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
            *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
            *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
        }
        puVar11 = *(undefined8 **)(iVar1 + 0x40);
        puVar17 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar17 = puVar9;
        }
        if (puVar17 == puVar9) {
            puVar17 = (undefined8 *)0x0;
        }
        *puVar11 = *puVar17;
        *(undefined4 *)((int64_t)puVar11 + 0xc) = 8;
        if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
            iVar16 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
            iVar15 = iVar16 * 2;
            if (iVar16 < 1) {
                iVar15 = iVar16 + 1;
            }
            func_0x000180093240(iVar1, iVar15, 0);
        }
        puVar12 = *(undefined4 **)(iVar1 + 0x40);
        *(undefined4 **)(iVar1 + 0x40) = puVar12 + 4;
        if (*(char *)(*(int64_t *)(puVar12 + -4) + 4) != '\0') {
            func_0x000180092f10(iVar1);
            pcVar4 = (code *)swi(3);
            uVar14 = (*pcVar4)();
            return uVar14;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar12 + -4), iVar8 + 1);
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *puVar13 = *puVar12;
        puVar13[1] = uVar5;
        puVar13[2] = uVar6;
        puVar13[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
            iVar2 = *(int64_t *)(puVar12 + -4);
            if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(iVar1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
        }
        *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x20;
    }
    return 0;
}

// ============================================================
// Function: FUN_18005475d
// Address: 0x18005475d
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800544f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000070;
    int64_t in_stack_00000080;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000070, in_stack_00000080);
    puVar9 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar9 = *(undefined8 **)0x180782430;
    }
    if ((puVar9 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar9 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x31) {
        iVar15 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar15 * 2;
        if (iVar15 < 3) {
            iVar8 = iVar15 + 3;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    puVar9 = *(undefined8 **)0x180782430;
    uVar10 = *(int64_t *)(iVar1 + 0x40) + 0x30;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar10) {
        **(uint64_t **)(iVar1 + 0x18) = uVar10;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), puVar9 = *(undefined8 **)0x180782430, iVar8 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    puVar11 = *(undefined8 **)(iVar1 + 0x40);
    *puVar11 = 0x1807824b8;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar11 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*puVar11, iVar2 + -0x10);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar12;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    puVar11 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((puVar11 == puVar9) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(undefined8 **)(iVar1 + 0x40) = puVar11;
    } else {
        iVar8 = func_0x0001800a1110(*puVar11);
        if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
            *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
            *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
        }
        puVar11 = *(undefined8 **)(iVar1 + 0x40);
        puVar17 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar17 = puVar9;
        }
        if (puVar17 == puVar9) {
            puVar17 = (undefined8 *)0x0;
        }
        *puVar11 = *puVar17;
        *(undefined4 *)((int64_t)puVar11 + 0xc) = 8;
        if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
            iVar16 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
            iVar15 = iVar16 * 2;
            if (iVar16 < 1) {
                iVar15 = iVar16 + 1;
            }
            func_0x000180093240(iVar1, iVar15, 0);
        }
        puVar12 = *(undefined4 **)(iVar1 + 0x40);
        *(undefined4 **)(iVar1 + 0x40) = puVar12 + 4;
        if (*(char *)(*(int64_t *)(puVar12 + -4) + 4) != '\0') {
            func_0x000180092f10(iVar1);
            pcVar4 = (code *)swi(3);
            uVar14 = (*pcVar4)();
            return uVar14;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar12 + -4), iVar8 + 1);
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *puVar13 = *puVar12;
        puVar13[1] = uVar5;
        puVar13[2] = uVar6;
        puVar13[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
            iVar2 = *(int64_t *)(puVar12 + -4);
            if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(iVar1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
        }
        *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x20;
    }
    return 0;
}

// ============================================================
// Function: FUN_180054771
// Address: 0x180054771
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800544f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000070;
    int64_t in_stack_00000080;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000070, in_stack_00000080);
    puVar9 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar9 = *(undefined8 **)0x180782430;
    }
    if ((puVar9 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar9 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x31) {
        iVar15 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar15 * 2;
        if (iVar15 < 3) {
            iVar8 = iVar15 + 3;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    puVar9 = *(undefined8 **)0x180782430;
    uVar10 = *(int64_t *)(iVar1 + 0x40) + 0x30;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar10) {
        **(uint64_t **)(iVar1 + 0x18) = uVar10;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), puVar9 = *(undefined8 **)0x180782430, iVar8 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    puVar11 = *(undefined8 **)(iVar1 + 0x40);
    *puVar11 = 0x1807824b8;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar11 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*puVar11, iVar2 + -0x10);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar12;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    puVar11 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((puVar11 == puVar9) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(undefined8 **)(iVar1 + 0x40) = puVar11;
    } else {
        iVar8 = func_0x0001800a1110(*puVar11);
        if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
            *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
            *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
        }
        puVar11 = *(undefined8 **)(iVar1 + 0x40);
        puVar17 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar17 = puVar9;
        }
        if (puVar17 == puVar9) {
            puVar17 = (undefined8 *)0x0;
        }
        *puVar11 = *puVar17;
        *(undefined4 *)((int64_t)puVar11 + 0xc) = 8;
        if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
            iVar16 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
            iVar15 = iVar16 * 2;
            if (iVar16 < 1) {
                iVar15 = iVar16 + 1;
            }
            func_0x000180093240(iVar1, iVar15, 0);
        }
        puVar12 = *(undefined4 **)(iVar1 + 0x40);
        *(undefined4 **)(iVar1 + 0x40) = puVar12 + 4;
        if (*(char *)(*(int64_t *)(puVar12 + -4) + 4) != '\0') {
            func_0x000180092f10(iVar1);
            pcVar4 = (code *)swi(3);
            uVar14 = (*pcVar4)();
            return uVar14;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar12 + -4), iVar8 + 1);
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *puVar13 = *puVar12;
        puVar13[1] = uVar5;
        puVar13[2] = uVar6;
        puVar13[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
            iVar2 = *(int64_t *)(puVar12 + -4);
            if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(iVar1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
        }
        *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x20;
    }
    return 0;
}

// ============================================================
// Function: FUN_180054789
// Address: 0x180054789
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800544f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined8 uVar14;
    int32_t iVar15;
    int32_t iVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000070;
    int64_t in_stack_00000080;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000070, in_stack_00000080);
    puVar9 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar9 = *(undefined8 **)0x180782430;
    }
    if ((puVar9 == *(undefined8 **)0x180782430) || (*(int32_t *)((int64_t)puVar9 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x31) {
        iVar15 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar15 * 2;
        if (iVar15 < 3) {
            iVar8 = iVar15 + 3;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    puVar9 = *(undefined8 **)0x180782430;
    uVar10 = *(int64_t *)(iVar1 + 0x40) + 0x30;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar10) {
        **(uint64_t **)(iVar1 + 0x18) = uVar10;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), puVar9 = *(undefined8 **)0x180782430, iVar8 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar14 = (*pcVar4)();
        return uVar14;
    }
    puVar11 = *(undefined8 **)(iVar1 + 0x40);
    *puVar11 = 0x1807824b8;
    *(undefined4 *)(puVar11 + 1) = 0;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar11 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar12 = (undefined4 *)func_0x0001800a0ea0(*puVar11, iVar2 + -0x10);
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar12;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    puVar11 = (undefined8 *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((puVar11 == puVar9) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(undefined8 **)(iVar1 + 0x40) = puVar11;
    } else {
        iVar8 = func_0x0001800a1110(*puVar11);
        if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
            *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
            *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
        }
        puVar11 = *(undefined8 **)(iVar1 + 0x40);
        puVar17 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar17 = puVar9;
        }
        if (puVar17 == puVar9) {
            puVar17 = (undefined8 *)0x0;
        }
        *puVar11 = *puVar17;
        *(undefined4 *)((int64_t)puVar11 + 0xc) = 8;
        if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
            iVar16 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
            iVar15 = iVar16 * 2;
            if (iVar16 < 1) {
                iVar15 = iVar16 + 1;
            }
            func_0x000180093240(iVar1, iVar15, 0);
        }
        puVar12 = *(undefined4 **)(iVar1 + 0x40);
        *(undefined4 **)(iVar1 + 0x40) = puVar12 + 4;
        if (*(char *)(*(int64_t *)(puVar12 + -4) + 4) != '\0') {
            func_0x000180092f10(iVar1);
            pcVar4 = (code *)swi(3);
            uVar14 = (*pcVar4)();
            return uVar14;
        }
        puVar13 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar12 + -4), iVar8 + 1);
        uVar5 = puVar12[1];
        uVar6 = puVar12[2];
        uVar7 = puVar12[3];
        *puVar13 = *puVar12;
        puVar13[1] = uVar5;
        puVar13[2] = uVar6;
        puVar13[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
            iVar2 = *(int64_t *)(puVar12 + -4);
            if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(iVar1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
        }
        *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x20;
    }
    return 0;
}

// ============================================================
// Function: FUN_180054790
// Address: 0x180054790
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180054790(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined4 *puVar13;
    int64_t *piVar14;
    undefined4 *puVar15;
    undefined8 uVar16;
    int32_t iVar17;
    int64_t *piVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000060;
    int64_t in_stack_00000070;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000060, in_stack_00000070);
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x21) {
        iVar17 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar17 * 2;
        if (iVar17 < 2) {
            iVar8 = iVar17 + 2;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    piVar10 = *(int64_t **)0x180782430;
    uVar11 = *(int64_t *)(iVar1 + 0x40) + 0x20;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar11) {
        **(uint64_t **)(iVar1 + 0x18) = uVar11;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar8 == 0))
    goto code_r0x000180054bab;
    puVar12 = *(undefined8 **)(iVar1 + 0x40);
    *puVar12 = 0x1807824b8;
    *(undefined4 *)(puVar12 + 1) = 0;
    *(undefined4 *)((int64_t)puVar12 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar12 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar13 = (undefined4 *)func_0x0001800a0ea0(*puVar12, iVar2 + -0x10);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar13;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    piVar14 = (int64_t *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((piVar14 == piVar10) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(int64_t **)(iVar1 + 0x40) = piVar14;
        return 0;
    }
    iVar17 = func_0x0001800a1110();
    iVar8 = 1;
    piVar14 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar14 = piVar10;
    }
    if (piVar14 == piVar10) {
        piVar14 = (int64_t *)0x0;
    }
    iVar2 = *piVar14;
    if (0 < iVar17) {
        do {
            if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U))
               && (iVar9 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar9 == 0))
            goto code_r0x000180054bab;
            puVar13 = *(undefined4 **)(iVar1 + 0x40);
            puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8);
            uVar5 = puVar15[1];
            uVar6 = puVar15[2];
            uVar7 = puVar15[3];
            *puVar13 = *puVar15;
            puVar13[1] = uVar5;
            puVar13[2] = uVar6;
            puVar13[3] = uVar7;
            piVar14 = *(int64_t **)(iVar1 + 0x40);
            *(int64_t **)(iVar1 + 0x40) = piVar14 + 2;
            if ((piVar14 == piVar10) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
                *(int64_t **)(iVar1 + 0x40) = piVar14;
            } else {
                piVar18 = piVar14;
                if (piVar14 == piVar10) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar3 = *piVar18;
                *(int64_t **)(iVar1 + 0x40) = piVar14;
                if (iVar3 == iVar2) goto joined_r0x0001800549bf;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar17);
    }
code_r0x000180054b6f:
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    return 0;
joined_r0x0001800549bf:
    if (iVar17 <= iVar8) goto code_r0x000180054ac5;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar9 = func_0x000180085510(iVar1, 1), iVar9 == 0)) goto code_r0x000180054bab;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8 + 1);
    uVar5 = puVar15[1];
    uVar6 = puVar15[2];
    uVar7 = puVar15[3];
    *puVar13 = *puVar15;
    puVar13[1] = uVar5;
    puVar13[2] = uVar6;
    puVar13[3] = uVar7;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') goto code_r0x000180054bc3;
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar8);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    piVar14 = *(int64_t **)(iVar1 + 0x40);
    iVar8 = iVar8 + 1;
    goto joined_r0x0001800549bf;
code_r0x000180054ac5:
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(iVar1 + 0x18) < piVar14 + 2)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), iVar8 == 0)) {
code_r0x000180054bab:
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    *(undefined4 *)(*(int64_t *)(iVar1 + 0x40) + 0xc) = 0;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') {
code_r0x000180054bc3:
        func_0x000180092f10(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar17);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    goto code_r0x000180054b6f;
}

// ============================================================
// Function: FUN_1800547cd
// Address: 0x1800547cd
// Size: 964 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180054790(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined4 *puVar13;
    int64_t *piVar14;
    undefined4 *puVar15;
    undefined8 uVar16;
    int32_t iVar17;
    int64_t *piVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000060;
    int64_t in_stack_00000070;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000060, in_stack_00000070);
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x21) {
        iVar17 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar17 * 2;
        if (iVar17 < 2) {
            iVar8 = iVar17 + 2;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    piVar10 = *(int64_t **)0x180782430;
    uVar11 = *(int64_t *)(iVar1 + 0x40) + 0x20;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar11) {
        **(uint64_t **)(iVar1 + 0x18) = uVar11;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar8 == 0))
    goto code_r0x000180054bab;
    puVar12 = *(undefined8 **)(iVar1 + 0x40);
    *puVar12 = 0x1807824b8;
    *(undefined4 *)(puVar12 + 1) = 0;
    *(undefined4 *)((int64_t)puVar12 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar12 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar13 = (undefined4 *)func_0x0001800a0ea0(*puVar12, iVar2 + -0x10);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar13;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    piVar14 = (int64_t *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((piVar14 == piVar10) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(int64_t **)(iVar1 + 0x40) = piVar14;
        return 0;
    }
    iVar17 = func_0x0001800a1110();
    iVar8 = 1;
    piVar14 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar14 = piVar10;
    }
    if (piVar14 == piVar10) {
        piVar14 = (int64_t *)0x0;
    }
    iVar2 = *piVar14;
    if (0 < iVar17) {
        do {
            if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U))
               && (iVar9 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar9 == 0))
            goto code_r0x000180054bab;
            puVar13 = *(undefined4 **)(iVar1 + 0x40);
            puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8);
            uVar5 = puVar15[1];
            uVar6 = puVar15[2];
            uVar7 = puVar15[3];
            *puVar13 = *puVar15;
            puVar13[1] = uVar5;
            puVar13[2] = uVar6;
            puVar13[3] = uVar7;
            piVar14 = *(int64_t **)(iVar1 + 0x40);
            *(int64_t **)(iVar1 + 0x40) = piVar14 + 2;
            if ((piVar14 == piVar10) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
                *(int64_t **)(iVar1 + 0x40) = piVar14;
            } else {
                piVar18 = piVar14;
                if (piVar14 == piVar10) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar3 = *piVar18;
                *(int64_t **)(iVar1 + 0x40) = piVar14;
                if (iVar3 == iVar2) goto joined_r0x0001800549bf;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar17);
    }
code_r0x000180054b6f:
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    return 0;
joined_r0x0001800549bf:
    if (iVar17 <= iVar8) goto code_r0x000180054ac5;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar9 = func_0x000180085510(iVar1, 1), iVar9 == 0)) goto code_r0x000180054bab;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8 + 1);
    uVar5 = puVar15[1];
    uVar6 = puVar15[2];
    uVar7 = puVar15[3];
    *puVar13 = *puVar15;
    puVar13[1] = uVar5;
    puVar13[2] = uVar6;
    puVar13[3] = uVar7;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') goto code_r0x000180054bc3;
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar8);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    piVar14 = *(int64_t **)(iVar1 + 0x40);
    iVar8 = iVar8 + 1;
    goto joined_r0x0001800549bf;
code_r0x000180054ac5:
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(iVar1 + 0x18) < piVar14 + 2)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), iVar8 == 0)) {
code_r0x000180054bab:
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    *(undefined4 *)(*(int64_t *)(iVar1 + 0x40) + 0xc) = 0;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') {
code_r0x000180054bc3:
        func_0x000180092f10(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar17);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    goto code_r0x000180054b6f;
}

// ============================================================
// Function: FUN_180054b91
// Address: 0x180054b91
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180054790(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined4 *puVar13;
    int64_t *piVar14;
    undefined4 *puVar15;
    undefined8 uVar16;
    int32_t iVar17;
    int64_t *piVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000060;
    int64_t in_stack_00000070;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000060, in_stack_00000070);
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x21) {
        iVar17 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar17 * 2;
        if (iVar17 < 2) {
            iVar8 = iVar17 + 2;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    piVar10 = *(int64_t **)0x180782430;
    uVar11 = *(int64_t *)(iVar1 + 0x40) + 0x20;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar11) {
        **(uint64_t **)(iVar1 + 0x18) = uVar11;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar8 == 0))
    goto code_r0x000180054bab;
    puVar12 = *(undefined8 **)(iVar1 + 0x40);
    *puVar12 = 0x1807824b8;
    *(undefined4 *)(puVar12 + 1) = 0;
    *(undefined4 *)((int64_t)puVar12 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar12 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar13 = (undefined4 *)func_0x0001800a0ea0(*puVar12, iVar2 + -0x10);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar13;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    piVar14 = (int64_t *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((piVar14 == piVar10) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(int64_t **)(iVar1 + 0x40) = piVar14;
        return 0;
    }
    iVar17 = func_0x0001800a1110();
    iVar8 = 1;
    piVar14 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar14 = piVar10;
    }
    if (piVar14 == piVar10) {
        piVar14 = (int64_t *)0x0;
    }
    iVar2 = *piVar14;
    if (0 < iVar17) {
        do {
            if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U))
               && (iVar9 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar9 == 0))
            goto code_r0x000180054bab;
            puVar13 = *(undefined4 **)(iVar1 + 0x40);
            puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8);
            uVar5 = puVar15[1];
            uVar6 = puVar15[2];
            uVar7 = puVar15[3];
            *puVar13 = *puVar15;
            puVar13[1] = uVar5;
            puVar13[2] = uVar6;
            puVar13[3] = uVar7;
            piVar14 = *(int64_t **)(iVar1 + 0x40);
            *(int64_t **)(iVar1 + 0x40) = piVar14 + 2;
            if ((piVar14 == piVar10) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
                *(int64_t **)(iVar1 + 0x40) = piVar14;
            } else {
                piVar18 = piVar14;
                if (piVar14 == piVar10) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar3 = *piVar18;
                *(int64_t **)(iVar1 + 0x40) = piVar14;
                if (iVar3 == iVar2) goto joined_r0x0001800549bf;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar17);
    }
code_r0x000180054b6f:
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    return 0;
joined_r0x0001800549bf:
    if (iVar17 <= iVar8) goto code_r0x000180054ac5;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar9 = func_0x000180085510(iVar1, 1), iVar9 == 0)) goto code_r0x000180054bab;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8 + 1);
    uVar5 = puVar15[1];
    uVar6 = puVar15[2];
    uVar7 = puVar15[3];
    *puVar13 = *puVar15;
    puVar13[1] = uVar5;
    puVar13[2] = uVar6;
    puVar13[3] = uVar7;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') goto code_r0x000180054bc3;
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar8);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    piVar14 = *(int64_t **)(iVar1 + 0x40);
    iVar8 = iVar8 + 1;
    goto joined_r0x0001800549bf;
code_r0x000180054ac5:
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(iVar1 + 0x18) < piVar14 + 2)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), iVar8 == 0)) {
code_r0x000180054bab:
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    *(undefined4 *)(*(int64_t *)(iVar1 + 0x40) + 0xc) = 0;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') {
code_r0x000180054bc3:
        func_0x000180092f10(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar17);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    goto code_r0x000180054b6f;
}

// ============================================================
// Function: FUN_180054b97
// Address: 0x180054b97
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180054790(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined4 *puVar13;
    int64_t *piVar14;
    undefined4 *puVar15;
    undefined8 uVar16;
    int32_t iVar17;
    int64_t *piVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000060;
    int64_t in_stack_00000070;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000060, in_stack_00000070);
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x21) {
        iVar17 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar17 * 2;
        if (iVar17 < 2) {
            iVar8 = iVar17 + 2;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    piVar10 = *(int64_t **)0x180782430;
    uVar11 = *(int64_t *)(iVar1 + 0x40) + 0x20;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar11) {
        **(uint64_t **)(iVar1 + 0x18) = uVar11;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar8 == 0))
    goto code_r0x000180054bab;
    puVar12 = *(undefined8 **)(iVar1 + 0x40);
    *puVar12 = 0x1807824b8;
    *(undefined4 *)(puVar12 + 1) = 0;
    *(undefined4 *)((int64_t)puVar12 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar12 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar13 = (undefined4 *)func_0x0001800a0ea0(*puVar12, iVar2 + -0x10);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar13;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    piVar14 = (int64_t *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((piVar14 == piVar10) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(int64_t **)(iVar1 + 0x40) = piVar14;
        return 0;
    }
    iVar17 = func_0x0001800a1110();
    iVar8 = 1;
    piVar14 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar14 = piVar10;
    }
    if (piVar14 == piVar10) {
        piVar14 = (int64_t *)0x0;
    }
    iVar2 = *piVar14;
    if (0 < iVar17) {
        do {
            if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U))
               && (iVar9 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar9 == 0))
            goto code_r0x000180054bab;
            puVar13 = *(undefined4 **)(iVar1 + 0x40);
            puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8);
            uVar5 = puVar15[1];
            uVar6 = puVar15[2];
            uVar7 = puVar15[3];
            *puVar13 = *puVar15;
            puVar13[1] = uVar5;
            puVar13[2] = uVar6;
            puVar13[3] = uVar7;
            piVar14 = *(int64_t **)(iVar1 + 0x40);
            *(int64_t **)(iVar1 + 0x40) = piVar14 + 2;
            if ((piVar14 == piVar10) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
                *(int64_t **)(iVar1 + 0x40) = piVar14;
            } else {
                piVar18 = piVar14;
                if (piVar14 == piVar10) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar3 = *piVar18;
                *(int64_t **)(iVar1 + 0x40) = piVar14;
                if (iVar3 == iVar2) goto joined_r0x0001800549bf;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar17);
    }
code_r0x000180054b6f:
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    return 0;
joined_r0x0001800549bf:
    if (iVar17 <= iVar8) goto code_r0x000180054ac5;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar9 = func_0x000180085510(iVar1, 1), iVar9 == 0)) goto code_r0x000180054bab;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8 + 1);
    uVar5 = puVar15[1];
    uVar6 = puVar15[2];
    uVar7 = puVar15[3];
    *puVar13 = *puVar15;
    puVar13[1] = uVar5;
    puVar13[2] = uVar6;
    puVar13[3] = uVar7;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') goto code_r0x000180054bc3;
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar8);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    piVar14 = *(int64_t **)(iVar1 + 0x40);
    iVar8 = iVar8 + 1;
    goto joined_r0x0001800549bf;
code_r0x000180054ac5:
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(iVar1 + 0x18) < piVar14 + 2)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), iVar8 == 0)) {
code_r0x000180054bab:
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    *(undefined4 *)(*(int64_t *)(iVar1 + 0x40) + 0xc) = 0;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') {
code_r0x000180054bc3:
        func_0x000180092f10(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar17);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    goto code_r0x000180054b6f;
}

// ============================================================
// Function: FUN_180054bab
// Address: 0x180054bab
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180054790(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    undefined4 *puVar13;
    int64_t *piVar14;
    undefined4 *puVar15;
    undefined8 uVar16;
    int32_t iVar17;
    int64_t *piVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000060;
    int64_t in_stack_00000070;
    
    func_0x000180052f60();
    fcn.180054280(arg1, in_stack_00000060, in_stack_00000070);
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
        func_0x000180088470(arg1, 1, 8);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8);
    if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x21) {
        iVar17 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
        iVar8 = iVar17 * 2;
        if (iVar17 < 2) {
            iVar8 = iVar17 + 2;
        }
        func_0x000180093240(iVar1, iVar8, 0);
    }
    piVar10 = *(int64_t **)0x180782430;
    uVar11 = *(int64_t *)(iVar1 + 0x40) + 0x20;
    if (**(uint64_t **)(iVar1 + 0x18) < uVar11) {
        **(uint64_t **)(iVar1 + 0x18) = uVar11;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar8 == 0))
    goto code_r0x000180054bab;
    puVar12 = *(undefined8 **)(iVar1 + 0x40);
    *puVar12 = 0x1807824b8;
    *(undefined4 *)(puVar12 + 1) = 0;
    *(undefined4 *)((int64_t)puVar12 + 0xc) = 2;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    puVar12 = (undefined8 *)fcn.180085370(iVar1, 0xffffd8f0);
    iVar2 = *(int64_t *)(iVar1 + 0x40);
    puVar13 = (undefined4 *)func_0x0001800a0ea0(*puVar12, iVar2 + -0x10);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar13;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    piVar14 = (int64_t *)(*(int64_t *)(iVar1 + 0x40) - 0x10);
    if ((piVar14 == piVar10) || (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4) != 7)) {
        *(int64_t **)(iVar1 + 0x40) = piVar14;
        return 0;
    }
    iVar17 = func_0x0001800a1110();
    iVar8 = 1;
    piVar14 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar14 = piVar10;
    }
    if (piVar14 == piVar10) {
        piVar14 = (int64_t *)0x0;
    }
    iVar2 = *piVar14;
    if (0 < iVar17) {
        do {
            if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U))
               && (iVar9 = func_0x000180085510(iVar1, 1), piVar10 = *(int64_t **)0x180782430, iVar9 == 0))
            goto code_r0x000180054bab;
            puVar13 = *(undefined4 **)(iVar1 + 0x40);
            puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8);
            uVar5 = puVar15[1];
            uVar6 = puVar15[2];
            uVar7 = puVar15[3];
            *puVar13 = *puVar15;
            puVar13[1] = uVar5;
            puVar13[2] = uVar6;
            puVar13[3] = uVar7;
            piVar14 = *(int64_t **)(iVar1 + 0x40);
            *(int64_t **)(iVar1 + 0x40) = piVar14 + 2;
            if ((piVar14 == piVar10) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
                *(int64_t **)(iVar1 + 0x40) = piVar14;
            } else {
                piVar18 = piVar14;
                if (piVar14 == piVar10) {
                    piVar18 = (int64_t *)0x0;
                }
                iVar3 = *piVar18;
                *(int64_t **)(iVar1 + 0x40) = piVar14;
                if (iVar3 == iVar2) goto joined_r0x0001800549bf;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar17);
    }
code_r0x000180054b6f:
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    return 0;
joined_r0x0001800549bf:
    if (iVar17 <= iVar8) goto code_r0x000180054ac5;
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar9 = func_0x000180085510(iVar1, 1), iVar9 == 0)) goto code_r0x000180054bab;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    puVar15 = (undefined4 *)func_0x0001800a0d50(*(undefined8 *)(puVar13 + -4), iVar8 + 1);
    uVar5 = puVar15[1];
    uVar6 = puVar15[2];
    uVar7 = puVar15[3];
    *puVar13 = *puVar15;
    puVar13[1] = uVar5;
    puVar13[2] = uVar6;
    puVar13[3] = uVar7;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') goto code_r0x000180054bc3;
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar8);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    piVar14 = *(int64_t **)(iVar1 + 0x40);
    iVar8 = iVar8 + 1;
    goto joined_r0x0001800549bf;
code_r0x000180054ac5:
    if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(iVar1 + 0x18) < piVar14 + 2)) &&
       (iVar8 = func_0x000180085510(iVar1, 1), iVar8 == 0)) {
code_r0x000180054bab:
        func_0x000180099450(iVar1, 0x18063d8d0);
        fcn.180087960(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    *(undefined4 *)(*(int64_t *)(iVar1 + 0x40) + 0xc) = 0;
    puVar13 = *(undefined4 **)(iVar1 + 0x40);
    *(undefined4 **)(iVar1 + 0x40) = puVar13 + 4;
    if (*(char *)(*(int64_t *)(puVar13 + -4) + 4) != '\0') {
code_r0x000180054bc3:
        func_0x000180092f10(iVar1);
        pcVar4 = (code *)swi(3);
        uVar16 = (*pcVar4)();
        return uVar16;
    }
    puVar15 = (undefined4 *)func_0x0001800a1010(iVar1, *(int64_t *)(puVar13 + -4), iVar17);
    uVar5 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *puVar15 = *puVar13;
    puVar15[1] = uVar5;
    puVar15[2] = uVar6;
    puVar15[3] = uVar7;
    if (5 < *(int32_t *)(*(int64_t *)(iVar1 + 0x40) + -4)) {
        iVar2 = *(int64_t *)(puVar13 + -4);
        if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar1 + 0x40) + -0x10) + 1) & 3) != 0)) {
            iVar3 = *(int64_t *)(iVar1 + 0x20);
            if (*(char *)(iVar3 + 0x59) == '\x02') {
                func_0x000180094420();
            } else {
                *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                *(int64_t *)(iVar3 + 0x18) = iVar2;
            }
        }
    }
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    goto code_r0x000180054b6f;
}

// ============================================================
// Function: FUN_180054bd0
// Address: 0x180054bd0
// Size: 354 bytes
// ============================================================
undefined8 fcn.180054bd0(int64_t arg1, int64_t arg_68h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    int64_t unaff_retaddr;
    int64_t in_stack_00000010;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t iStack_38;
    
    func_0x000180052f60();
    fcn.180054280(arg1, unaff_retaddr, in_stack_00000010);
    uVar2 = 1;
    func_0x000180052d70(&var_48h, arg1, 1);
    if (var_48h != var_40h) {
        uVar4 = *(int64_t *)(arg1 + 0x28) + 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        uVar3 = 2;
        if ((uVar4 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar4 + 0xc))) {
            uVar2 = func_0x000180088860(arg1, 2);
        }
        uVar4 = *(int64_t *)(arg1 + 0x28) + 0x20;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar4 + 0xc))) {
            uVar3 = func_0x000180088860(arg1, 3);
        }
        uVar4 = *(int64_t *)(arg1 + 0x28) + 0x30;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar4 + 0xc) < 1)) {
            var_70h._0_1_ = 0;
        } else {
            var_70h._0_1_ = func_0x000180088860(arg1, 4);
        }
        var_58h._0_4_ = 0;
        var_60h._0_1_ = 1;
        var_68h = *(int64_t *)0x180782150;
        var_78h._0_4_ = uVar3;
        (**(code **)0x180782140)(*(undefined8 *)0x180782138, var_48h, (int32_t)var_40h - (int32_t)var_48h, uVar2);
    }
    if (var_48h != 0) {
        uVar4 = var_48h;
        puVar6 = auStack_98;
        if (0xfff < (uint64_t)(iStack_38 - var_48h)) {
            uVar4 = *(uint64_t *)(var_48h + -8);
            uVar5 = (var_48h - uVar4) - 8;
            puVar6 = auStack_98;
            if (0x1f < uVar5) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                uVar4 = uVar5;
                puVar6 = auStack_90;
            }
        }
        *(undefined8 *)(puVar6 + -8) = 0x180054d25;
        func_0x000180459c3c(uVar4);
    }
    return 0;
}

// ============================================================
// Function: FUN_180054d40
// Address: 0x180054d40
// Size: 294 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180054dc5: Changing call to branch
// WARNING: Possible PIC construction at 0x000180054e04: Changing call to branch
// WARNING: Possible PIC construction at 0x000180054e43: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180054e09)
// WARNING: Removing unreachable block (ram,0x000180054dca)
// WARNING: Removing unreachable block (ram,0x000180054e48)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180054d40(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_20h;
    undefined auStack_98 [32];
    undefined8 uStack_78;
    undefined4 uStack_6c;
    uint64_t uStack_68;
    int64_t iStack_58;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    *(code **)(*(int64_t *)(arg2 + 0x20) + 0x3810) = fcn.180053780;
    func_0x000180023f30(arg2, 0x1807824b8, 2);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    func_0x000180018f70();
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.1800544f0, 0x180624030, 0);
    uStack_68 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    iVar4 = (int32_t)(iVar1 - iVar2 >> 4);
    iStack_58 = arg2;
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar5 = fcn.180085370();
        } else {
            uVar5 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar5 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
    }
    piVar6 = (int64_t *)(arg2 + 0x40);
    uVar3 = func_0x000180498cd0(0x180624030);
    uStack_78 = func_0x00018009a8e0(arg2, 0x180624030, uVar3);
    uStack_6c = 6;
    func_0x0001800a8680(arg2, uVar5, &uStack_78, *piVar6 + -0x10);
    *piVar6 = *piVar6 + -0x10;
    func_0x000180459870(uStack_68 ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_180054e70
// Address: 0x180054e70
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180054e70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    uVar3 = arg3 - arg2;
    if (uVar3 != 0) {
        if (0x7fffffffffffffff < uVar3) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
        fcn.180054ef0(arg1, uVar3);
        iVar2 = *(int64_t *)arg1;
        fcn.180498030(iVar2, arg2, uVar3);
        *(uint64_t *)(arg1 + 8) = iVar2 + uVar3;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180054eac
// Address: 0x180054eac
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180054e70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    uVar3 = arg3 - arg2;
    if (uVar3 != 0) {
        if (0x7fffffffffffffff < uVar3) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
        fcn.180054ef0(arg1, uVar3);
        iVar2 = *(int64_t *)arg1;
        fcn.180498030(iVar2, arg2, uVar3);
        *(uint64_t *)(arg1 + 8) = iVar2 + uVar3;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180054ed4
// Address: 0x180054ed4
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180054e70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    uVar3 = arg3 - arg2;
    if (uVar3 != 0) {
        if (0x7fffffffffffffff < uVar3) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
        fcn.180054ef0(arg1, uVar3);
        iVar2 = *(int64_t *)arg1;
        fcn.180498030(iVar2, arg2, uVar3);
        *(uint64_t *)(arg1 + 8) = iVar2 + uVar3;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180054ef0
// Address: 0x180054ef0
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180054ef0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    if (arg2 == 0) {
        uVar3 = 0;
    } else if ((uint64_t)arg2 < 0x1000) {
        uVar3 = func_0x000180459890(arg2);
    } else {
        if (arg2 + 0x27U <= (uint64_t)arg2) {
            func_0x000180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        iVar2 = func_0x000180459890();
        iVar4 = iVar2;
        if (iVar2 == 0) {
            iVar4 = 5;
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)();
        }
        uVar3 = iVar2 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar3 - 8) = iVar4;
    }
    *(uint64_t *)arg1 = uVar3;
    *(uint64_t *)(arg1 + 8) = uVar3;
    *(uint64_t *)(arg1 + 0x10) = uVar3 + arg2;
    return;
}

// ============================================================
// Function: FUN_180054f70
// Address: 0x180054f70
// Size: 106 bytes
// ============================================================
undefined8 fcn.180054f70(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t in_stack_00000010;
    
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar3 = fcn.180085510(in_stack_00000010);
        if (iVar3 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
    }
    puVar1 = *(undefined4 **)(arg1 + 0x40);
    *puVar1 = 0;
    puVar1[3] = 1;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180054fe0
// Address: 0x180054fe0
// Size: 317 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180054fe0(int64_t arg1, int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    undefined *puVar5;
    int64_t iVar6;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    puVar5 = auStack_58;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar4 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar4 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x000180055109;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar4 = *(int64_t **)0x180782430;
        }
    }
    iVar6 = *piVar4 + 0x18;
    if (iVar6 != 0) {
        _var_38h = ZEXT816(0);
        var_28h = 0;
        var_20h = 0;
        uVar3 = func_0x000180498cd0(iVar6);
        func_0x000180004830(&var_38h, iVar6, uVar3);
        func_0x000180074b10(&var_38h);
        if (0xf < (uint64_t)var_20h) {
            iVar6 = var_38h;
            puVar5 = auStack_58;
            if ((0xfff < var_20h + 1U) &&
               (iVar6 = *(int64_t *)(var_38h + -8), puVar5 = auStack_58, 0x1f < (var_38h - iVar6) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar6 = (*pcVar1)(5);
                puVar5 = auStack_50;
            }
            *(undefined8 *)(puVar5 + -8) = 0x1800550ef;
            func_0x000180459c3c(iVar6);
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800550fe;
        func_0x000180459870(*(uint64_t *)(puVar5 + 0x40) ^ (uint64_t)puVar5);
        return;
    }
code_r0x000180055109:
    func_0x000180088470(arg1, 1, 6);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180055120
// Address: 0x180055120
// Size: 467 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ah
// WARNING: [rz-ghidra] Detected overlap for variable var_49h

void fcn.180055120(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t var_10h;
    undefined8 uStack_80;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    uint64_t uStack_10;
    
    puVar7 = auStack_78;
    uStack_10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800552df;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar6 + 0x18;
    if (iVar8 != 0) {
        var_40h = 7;
        var_38h = 0xf;
        _var_50h = ZEXT716(0x205d4f464e495b);
        uVar3 = func_0x000180498cd0(iVar8);
        puVar4 = (undefined4 *)func_0x00018000d970(&var_50h, iVar8, uVar3);
        var_30h._0_4_ = *puVar4;
        var_30h._4_4_ = puVar4[1];
        uStack_28 = puVar4[2];
        uStack_24 = puVar4[3];
        var_20h._0_4_ = puVar4[4];
        var_20h._4_4_ = puVar4[5];
        var_18h._0_4_ = puVar4[6];
        var_18h._4_4_ = puVar4[7];
        *(undefined8 *)(puVar4 + 4) = 0;
        *(undefined8 *)(puVar4 + 6) = 0xf;
        *(undefined *)puVar4 = 0;
        func_0x000180074b10(&var_30h);
        if (0xf < CONCAT44(var_18h._4_4_, (undefined4)var_18h)) {
            iVar5 = CONCAT44(var_30h._4_4_, (undefined4)var_30h);
            iVar8 = iVar5;
            puVar7 = auStack_78;
            if ((0xfff < CONCAT44(var_18h._4_4_, (undefined4)var_18h) + 1) &&
               (iVar8 = *(int64_t *)(iVar5 + -8), puVar7 = auStack_78, 0x1f < (iVar5 - iVar8) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar7 = auStack_70;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18005527f;
            func_0x000180459c3c(iVar8);
        }
        if (0xf < *(uint64_t *)(puVar7 + 0x40)) {
            iVar8 = *(int64_t *)(puVar7 + 0x28);
            iVar5 = iVar8;
            if ((0xfff < *(uint64_t *)(puVar7 + 0x40) + 1) &&
               (iVar5 = *(int64_t *)(iVar8 + -8), 0x1f < (iVar8 - iVar5) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar5 = (*pcVar1)(5);
                puVar7 = puVar7 + 8;
            }
            *(undefined8 *)(puVar7 + -8) = 0x1800552c2;
            func_0x000180459c3c(iVar5);
        }
        *(undefined8 *)(puVar7 + -8) = 0x1800552d1;
        func_0x000180459870(*(uint64_t *)(puVar7 + 0x68) ^ (uint64_t)puVar7);
        return;
    }
code_r0x0001800552df:
    func_0x000180088470(arg1, 1, 6);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180055300
// Address: 0x180055300
// Size: 467 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ah
// WARNING: [rz-ghidra] Detected overlap for variable var_49h

void fcn.180055300(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t var_10h;
    undefined8 uStack_80;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    uint64_t uStack_10;
    
    puVar7 = auStack_78;
    uStack_10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800554bf;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar6 + 0x18;
    if (iVar8 != 0) {
        var_40h = 7;
        var_38h = 0xf;
        _var_50h = ZEXT716(0x205d4e5241575b);
        uVar3 = func_0x000180498cd0(iVar8);
        puVar4 = (undefined4 *)func_0x00018000d970(&var_50h, iVar8, uVar3);
        var_30h._0_4_ = *puVar4;
        var_30h._4_4_ = puVar4[1];
        uStack_28 = puVar4[2];
        uStack_24 = puVar4[3];
        var_20h._0_4_ = puVar4[4];
        var_20h._4_4_ = puVar4[5];
        var_18h._0_4_ = puVar4[6];
        var_18h._4_4_ = puVar4[7];
        *(undefined8 *)(puVar4 + 4) = 0;
        *(undefined8 *)(puVar4 + 6) = 0xf;
        *(undefined *)puVar4 = 0;
        func_0x000180074b10(&var_30h);
        if (0xf < CONCAT44(var_18h._4_4_, (undefined4)var_18h)) {
            iVar5 = CONCAT44(var_30h._4_4_, (undefined4)var_30h);
            iVar8 = iVar5;
            puVar7 = auStack_78;
            if ((0xfff < CONCAT44(var_18h._4_4_, (undefined4)var_18h) + 1) &&
               (iVar8 = *(int64_t *)(iVar5 + -8), puVar7 = auStack_78, 0x1f < (iVar5 - iVar8) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar7 = auStack_70;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18005545f;
            func_0x000180459c3c(iVar8);
        }
        if (0xf < *(uint64_t *)(puVar7 + 0x40)) {
            iVar8 = *(int64_t *)(puVar7 + 0x28);
            iVar5 = iVar8;
            if ((0xfff < *(uint64_t *)(puVar7 + 0x40) + 1) &&
               (iVar5 = *(int64_t *)(iVar8 + -8), 0x1f < (iVar8 - iVar5) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar5 = (*pcVar1)(5);
                puVar7 = puVar7 + 8;
            }
            *(undefined8 *)(puVar7 + -8) = 0x1800554a2;
            func_0x000180459c3c(iVar5);
        }
        *(undefined8 *)(puVar7 + -8) = 0x1800554b1;
        func_0x000180459870(*(uint64_t *)(puVar7 + 0x68) ^ (uint64_t)puVar7);
        return;
    }
code_r0x0001800554bf:
    func_0x000180088470(arg1, 1, 6);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800554e0
// Address: 0x1800554e0
// Size: 446 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800554e0(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t var_10h;
    undefined8 uStack_80;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    int64_t var_20h;
    int64_t var_18h;
    uint64_t uStack_10;
    
    puVar7 = auStack_78;
    uStack_10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018005568a;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar6 + 0x18;
    if (iVar8 != 0) {
        var_40h = 8;
        var_38h = 0xf;
        var_50h = 0x205d524f5252455b;
        var_48h = 0;
        uVar3 = func_0x000180498cd0(iVar8);
        puVar4 = (undefined4 *)func_0x00018000d970(&var_50h, iVar8, uVar3);
        var_30h._0_4_ = *puVar4;
        var_30h._4_4_ = puVar4[1];
        uStack_28 = puVar4[2];
        uStack_24 = puVar4[3];
        var_20h._0_4_ = puVar4[4];
        var_20h._4_4_ = puVar4[5];
        var_18h._0_4_ = puVar4[6];
        var_18h._4_4_ = puVar4[7];
        *(undefined8 *)(puVar4 + 4) = 0;
        *(undefined8 *)(puVar4 + 6) = 0xf;
        *(undefined *)puVar4 = 0;
        func_0x000180074b10(&var_30h);
        if (0xf < CONCAT44(var_18h._4_4_, (undefined4)var_18h)) {
            iVar5 = CONCAT44(var_30h._4_4_, (undefined4)var_30h);
            iVar8 = iVar5;
            puVar7 = auStack_78;
            if ((0xfff < CONCAT44(var_18h._4_4_, (undefined4)var_18h) + 1) &&
               (iVar8 = *(int64_t *)(iVar5 + -8), puVar7 = auStack_78, 0x1f < (iVar5 - iVar8) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar7 = auStack_70;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18005562a;
            func_0x000180459c3c(iVar8);
        }
        if (0xf < *(uint64_t *)(puVar7 + 0x40)) {
            iVar8 = *(int64_t *)(puVar7 + 0x28);
            iVar5 = iVar8;
            if ((0xfff < *(uint64_t *)(puVar7 + 0x40) + 1) &&
               (iVar5 = *(int64_t *)(iVar8 + -8), 0x1f < (iVar8 - iVar5) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar5 = (*pcVar1)(5);
                puVar7 = puVar7 + 8;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18005566d;
            func_0x000180459c3c(iVar5);
        }
        *(undefined8 *)(puVar7 + -8) = 0x18005567c;
        func_0x000180459870(*(uint64_t *)(puVar7 + 0x68) ^ (uint64_t)puVar7);
        return;
    }
code_r0x00018005568a:
    func_0x000180088470(arg1, 1, 6);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800556a0
// Address: 0x1800556a0
// Size: 32 bytes
// ============================================================
undefined8 fcn.1800556a0(undefined8 param_1)
{
    fcn.1800867f0(param_1, 0x180624130, 0x10);
    return 1;
}

// ============================================================
// Function: FUN_1800556c0
// Address: 0x1800556c0
// Size: 1653 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018005570c: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005574a: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055788: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800557c6: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055804: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055842: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055880: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800558be: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800558fc: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055937: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055975: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800559b3: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800559ee: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055a29: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055a64: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055a9f: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055ada: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055b15: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055b50: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055b8b: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055bc6: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055c01: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055c3c: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055c77: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055cb2: Changing call to branch
// WARNING: Possible PIC construction at 0x000180055ced: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180055cb7)
// WARNING: Removing unreachable block (ram,0x000180055c7c)
// WARNING: Removing unreachable block (ram,0x000180055c41)
// WARNING: Removing unreachable block (ram,0x000180055c06)
// WARNING: Removing unreachable block (ram,0x000180055bcb)
// WARNING: Removing unreachable block (ram,0x000180055b90)
// WARNING: Removing unreachable block (ram,0x000180055b55)
// WARNING: Removing unreachable block (ram,0x000180055b1a)
// WARNING: Removing unreachable block (ram,0x000180055adf)
// WARNING: Removing unreachable block (ram,0x000180055aa4)
// WARNING: Removing unreachable block (ram,0x000180055a69)
// WARNING: Removing unreachable block (ram,0x000180055a2e)
// WARNING: Removing unreachable block (ram,0x0001800559f3)
// WARNING: Removing unreachable block (ram,0x0001800559b8)
// WARNING: Removing unreachable block (ram,0x00018005597a)
// WARNING: Removing unreachable block (ram,0x00018005593c)
// WARNING: Removing unreachable block (ram,0x000180055901)
// WARNING: Removing unreachable block (ram,0x0001800558c3)
// WARNING: Removing unreachable block (ram,0x000180055885)
// WARNING: Removing unreachable block (ram,0x000180055847)
// WARNING: Removing unreachable block (ram,0x000180055809)
// WARNING: Removing unreachable block (ram,0x0001800557cb)
// WARNING: Removing unreachable block (ram,0x00018005578d)
// WARNING: Removing unreachable block (ram,0x00018005574f)
// WARNING: Removing unreachable block (ram,0x000180055711)
// WARNING: Removing unreachable block (ram,0x000180055cf2)

void fcn.1800556c0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    undefined auStack_b8 [32];
    undefined8 uStack_98;
    undefined4 uStack_8c;
    uint64_t uStack_88;
    int64_t iStack_78;
    int64_t iStack_70;
    undefined8 uStack_68;
    undefined8 uStack_60;
    int64_t iStack_40;
    int64_t var_38h;
    
    uStack_60 = 0x1800556d1;
    func_0x000180018f70();
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    var_38h = 0;
    uStack_60 = 0x1800556f9;
    func_0x0001800869f0(arg2, 0x180005d40, 0x180624148, 0);
    iStack_78 = iVar1 - iVar2 >> 4;
    uStack_60 = 0x180055711;
    uStack_68 = 0;
    uStack_88 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    iVar4 = (int32_t)iStack_78;
    iStack_70 = arg2;
    iStack_40 = iVar2;
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar5 = fcn.180085370();
        } else {
            uVar5 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar5 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
    }
    piVar6 = (int64_t *)(arg2 + 0x40);
    uVar3 = func_0x000180498cd0(0x180624148);
    uStack_98 = func_0x00018009a8e0(arg2, 0x180624148, uVar3);
    uStack_8c = 6;
    func_0x0001800a8680(arg2, uVar5, &uStack_98, *piVar6 + -0x10);
    *piVar6 = *piVar6 + -0x10;
    func_0x000180459870(uStack_88 ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_180055d40
// Address: 0x180055d40
// Size: 1263 bytes
// ============================================================
void fcn.180055d40(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t uVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    uint64_t uVar5;
    code *pcVar6;
    undefined auVar7 [16];
    char cVar8;
    int16_t iVar9;
    int32_t iVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t *piVar13;
    undefined4 *puVar14;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined *puVar17;
    undefined *puVar18;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 uVar19;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar17 = auStack_e8;
    puVar18 = auStack_e8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    piVar13 = (int64_t *)0x0;
    ppiVar12 = *(int64_t ***)(arg1 + 0x28);
    ppiVar3 = *(int64_t ***)(arg1 + 0x40);
    ppiVar11 = ppiVar12;
    if (ppiVar3 <= ppiVar12) {
        ppiVar11 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar11 + 0xc) != 9) ||
        (*(uint8_t *)((int64_t)*ppiVar11 + 3) != *(uint32_t *)0x1807823dc)) ||
       (*ppiVar11 == (int64_t *)0xfffffffffffffff0)) {
        func_0x000180088380(arg1, 1, 0x1806217c8);
code_r0x00018005621a:
        func_0x000180088380(arg1, 2, 0x1806242e0);
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    ppiVar11 = ppiVar12 + 2;
    if (ppiVar3 <= ppiVar12 + 2) {
        ppiVar11 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar11 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar11 + 0xc) != 6)) {
        func_0x000180088470(arg1, 2, 6);
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    if (ppiVar3 <= ppiVar12) {
        ppiVar12 = *(int64_t ***)0x180782430;
    }
    if (*(int32_t *)((int64_t)ppiVar12 + 0xc) == 9) {
        piVar16 = *ppiVar12 + 2;
    } else {
        piVar16 = piVar13;
        if (*(int32_t *)((int64_t)ppiVar12 + 0xc) == 2) {
            piVar16 = *ppiVar12;
        }
    }
    if (piVar16[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar16[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar4 = *piVar16;
    piVar16 = (int64_t *)piVar16[1];
    ppiVar12 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar12) {
        ppiVar12 = *(int64_t ***)0x180782430;
    }
    var_b8h = iVar4;
    var_b0h = (int64_t)piVar16;
    if (*(int32_t *)((int64_t)ppiVar12 + 0xc) == 6) {
        piVar15 = *ppiVar12;
        iVar9 = *(int16_t *)((int64_t)piVar15 + 6);
        piVar13 = piVar15 + 3;
        if (iVar9 == -0x8000) {
            pcVar6 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x530);
            if (pcVar6 == (code *)0x0) {
                iVar9 = -1;
            } else {
                iVar9 = (*pcVar6)(arg1, piVar13, *(undefined4 *)((int64_t)piVar15 + 0x14));
            }
            *(int16_t *)((int64_t)piVar15 + 6) = iVar9;
        }
        if (iVar9 < 0) goto code_r0x00018005621a;
    }
    piVar13 = (int64_t *)func_0x00018001b140(*(undefined8 *)(iVar4 + 0x18), piVar13);
    if (piVar13 == (int64_t *)0x0) {
        func_0x000180086510(arg1);
        puVar18 = auStack_e8;
        if (piVar16 != (int64_t *)0x0) {
            LOCK();
            piVar13 = piVar16 + 1;
            iVar10 = *(int32_t *)piVar13;
            *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
            UNLOCK();
            puVar18 = auStack_e8;
            if (iVar10 == 1) {
                (**(code **)*piVar16)(piVar16);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
                iVar10 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                puVar18 = auStack_e8;
                if (iVar10 == 1) {
                    (**(code **)(*piVar16 + 8))(piVar16);
                    puVar18 = auStack_e8;
                }
            }
        }
        goto code_r0x000180055ecd;
    }
    cVar8 = (**(code **)(*piVar13 + 0x10))(piVar13);
    if (cVar8 == '\0') {
        iVar10 = *(int32_t *)(piVar13[0xd] + 0x30);
        if (iVar10 == 0x1d) {
            var_a8h._0_4_ = 0;
            piVar15 = (int64_t *)piVar13[0x12];
            if (((piVar15 != (int64_t *)0x0) && (*piVar15 != 0)) &&
               (pcVar6 = *(code **)(*piVar15 + 0x18), pcVar6 != (code *)0x0)) {
                (*pcVar6)(piVar15, &var_a8h, iVar4);
            }
            func_0x0001800865e0(arg1, (undefined4)var_a8h);
        } else if (iVar10 == 0x1e) {
            var_80h = 0;
            var_78h = 0xf;
            stack0xffffffffffffff71 = SUB1615(ZEXT816(0), 1);
            auVar7[15] = 0;
            auVar7._0_15_ = stack0xffffffffffffff71;
            _var_90h = auVar7 << 8;
            (**(code **)(*piVar13 + 0xc0))(piVar13, &var_90h, iVar4);
            piVar15 = &var_90h;
            if (0xf < (uint64_t)var_78h) {
                piVar15 = (int64_t *)var_90h;
            }
            fcn.1800867f0(arg1, piVar15, var_80h);
            func_0x0001800588c0(&var_90h);
            puVar18 = auStack_e8;
        } else if (iVar10 == 0x3f) {
            piVar15 = (int64_t *)piVar13[0x12];
            if (((piVar15 != (int64_t *)0x0) && (*piVar15 != 0)) &&
               (pcVar6 = *(code **)(*piVar15 + 0x18), pcVar6 != (code *)0x0)) {
                (*pcVar6)(piVar15, &var_98h, iVar4);
            }
            piVar15 = (int64_t *)(var_98h + 0x10);
            if (0xf < *(uint64_t *)(var_98h + 0x28)) {
                piVar15 = (int64_t *)*piVar15;
            }
            fcn.1800867f0(arg1, piVar15, *(undefined8 *)(var_98h + 0x20));
            puVar18 = auStack_e8;
        } else if (iVar10 == 0x49) {
            piVar15 = (int64_t *)piVar13[0x13];
            uVar19 = extraout_XMM0_Da;
            if (((piVar15 != (int64_t *)0x0) && (*piVar15 != 0)) &&
               (pcVar6 = *(code **)(*piVar15 + 0x18), pcVar6 != (code *)0x0)) {
                uVar19 = (*pcVar6)(piVar15, &var_a8h, iVar4);
            }
            func_0x000180056230(uVar19, &var_70h, &var_a8h);
            piVar15 = &var_70h;
            if (0xf < (uint64_t)var_58h) {
                piVar15 = (int64_t *)var_70h;
            }
            fcn.1800867f0(arg1, piVar15, var_60h);
            puVar18 = auStack_e8;
            if (0xf < (uint64_t)var_58h) {
                if (0xfff < var_58h + 1U) {
                    if ((var_70h - *(int64_t *)(var_70h + -8)) - 8U < 0x20) {
                        func_0x000180459c3c(*(int64_t *)(var_70h + -8), var_58h + 0x28);
                        puVar18 = auStack_e8;
                        goto code_r0x0001800561a1;
                    }
                    pcVar6 = (code *)swi(0x29);
                    var_70h = (*pcVar6)(5);
                    puVar17 = auStack_e0;
                }
                *(undefined8 *)(puVar17 + -8) = 0x1800560be;
                func_0x000180459c3c(var_70h);
                puVar18 = puVar17;
            }
        } else {
            func_0x000180013530();
            iVar4 = *(int64_t *)(arg1 + 0x50);
            uVar19 = *(undefined4 *)(iVar4 + 0x88);
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) | 0x40;
            *(undefined4 *)(iVar4 + 0x88) = 8;
            *(undefined8 *)(iVar4 + 0x78) = 0x203fffffffffff3f;
            puVar14 = (undefined4 *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
            if (puVar14 != (undefined4 *)0x0) {
                uVar5 = *(uint64_t *)(iVar4 + 0x78);
                *puVar14 = 8;
                *(uint64_t *)(puVar14 + 10) = uVar5 | 0x200000000000003f;
                *(int64_t *)(puVar14 + 6) = arg1;
            }
            uVar2 = *(uint32_t *)((int64_t)piVar13 + 0x8c);
            *(uint32_t *)((int64_t)piVar13 + 0x8c) = uVar2 | 0x10;
            var_c8h = 0;
            func_0x0001800869f0(arg1, *(undefined8 *)0x180781ef8, 0, 0);
            func_0x000180085bf0(arg1, 1);
            func_0x000180085bf0(arg1, 2);
            iVar10 = func_0x0001800878a0(arg1, 2, 1);
            if (iVar10 != 0) {
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
            }
            if ((uVar2 >> 4 & 1) == 0) {
                *(uint32_t *)((int64_t)piVar13 + 0x8c) = *(uint32_t *)((int64_t)piVar13 + 0x8c) & 0xffffffef;
            }
            func_0x000180013740(extraout_XMM0_Da_00, arg1, uVar19);
            puVar18 = auStack_e8;
        }
    } else {
        func_0x000180086510(arg1);
        puVar18 = auStack_e8;
    }
code_r0x0001800561a1:
    uVar2 = *(uint32_t *)((int64_t)piVar13 + 0x8c);
    *(undefined8 *)(puVar18 + -8) = 0x1800561ba;
    func_0x000180086b20(arg1, ~(uint8_t)(uVar2 >> 4) & 1);
    if (piVar16 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar16 + 1;
        iVar10 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar10 == 1) {
            pcVar6 = *(code **)*piVar16;
            *(undefined8 *)(puVar18 + -8) = 0x1800561d4;
            (*pcVar6)(piVar16);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
            iVar10 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar10 == 1) {
                pcVar6 = *(code **)(*piVar16 + 8);
                *(undefined8 *)(puVar18 + -8) = 0x1800561e7;
                (*pcVar6)(piVar16);
            }
        }
    }
code_r0x000180055ecd:
    *(undefined8 *)(puVar18 + -8) = 0x180055ed9;
    func_0x000180459870(var_50h ^ (uint64_t)puVar18);
    return;
}

// ============================================================
// Function: FUN_180056230
// Address: 0x180056230
// Size: 735 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180056230(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    undefined uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    undefined4 uStack_24;
    
    iVar5 = 0;
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    func_0x00018000b240(arg2, 0x20, arg3, in_R9, 1);
    var_30h._0_4_ = *(undefined4 *)arg3;
    var_30h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_28 = *(undefined4 *)(arg3 + 8);
    uStack_24 = *(undefined4 *)(arg3 + 0xc);
    do {
        uVar2 = *(uint32_t *)((int64_t)&var_30h + iVar5 * 4);
        uVar1 = *(undefined *)((uint64_t)(uVar2 & 0xf) + 0x180624310);
        uVar3 = *(uint64_t *)(arg2 + 0x10);
        if (uVar3 < *(uint64_t *)(arg2 + 0x18)) {
            *(uint64_t *)(arg2 + 0x10) = uVar3 + 1;
            iVar4 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar4 = *(int64_t *)arg2;
            }
            *(undefined *)(uVar3 + iVar4) = uVar1;
            *(undefined *)(uVar3 + 1 + iVar4) = 0;
        } else {
            func_0x00018000f010(arg2, 1, arg2 & 0xff);
        }
        uVar1 = *(undefined *)((uint64_t)(uVar2 >> 4 & 0xf) + 0x180624310);
        uVar3 = *(uint64_t *)(arg2 + 0x10);
        if (uVar3 < *(uint64_t *)(arg2 + 0x18)) {
            *(uint64_t *)(arg2 + 0x10) = uVar3 + 1;
            iVar4 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar4 = *(int64_t *)arg2;
            }
            *(undefined *)(uVar3 + iVar4) = uVar1;
            *(undefined *)(uVar3 + 1 + iVar4) = 0;
        } else {
            func_0x00018000f010(arg2, 1, arg2 & 0xff);
        }
        uVar1 = *(undefined *)((uint64_t)(uVar2 >> 8 & 0xf) + 0x180624310);
        uVar3 = *(uint64_t *)(arg2 + 0x10);
        if (uVar3 < *(uint64_t *)(arg2 + 0x18)) {
            *(uint64_t *)(arg2 + 0x10) = uVar3 + 1;
            iVar4 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar4 = *(int64_t *)arg2;
            }
            *(undefined *)(uVar3 + iVar4) = uVar1;
            *(undefined *)(uVar3 + 1 + iVar4) = 0;
        } else {
            func_0x00018000f010(arg2, 1, arg2 & 0xff);
        }
        uVar1 = *(undefined *)((uint64_t)(uVar2 >> 0xc & 0xf) + 0x180624310);
        uVar3 = *(uint64_t *)(arg2 + 0x10);
        if (uVar3 < *(uint64_t *)(arg2 + 0x18)) {
            *(uint64_t *)(arg2 + 0x10) = uVar3 + 1;
            iVar4 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar4 = *(int64_t *)arg2;
            }
            *(undefined *)(uVar3 + iVar4) = uVar1;
            *(undefined *)(uVar3 + 1 + iVar4) = 0;
        } else {
            func_0x00018000f010(arg2, 1, arg2 & 0xff);
        }
        uVar1 = *(undefined *)((uint64_t)(uVar2 >> 0x10 & 0xf) + 0x180624310);
        uVar3 = *(uint64_t *)(arg2 + 0x10);
        if (uVar3 < *(uint64_t *)(arg2 + 0x18)) {
            *(uint64_t *)(arg2 + 0x10) = uVar3 + 1;
            iVar4 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar4 = *(int64_t *)arg2;
            }
            *(undefined *)(uVar3 + iVar4) = uVar1;
            *(undefined *)(uVar3 + 1 + iVar4) = 0;
        } else {
            func_0x00018000f010(arg2, 1, arg2 & 0xff);
        }
        uVar1 = *(undefined *)((uint64_t)(uVar2 >> 0x14 & 0xf) + 0x180624310);
        uVar3 = *(uint64_t *)(arg2 + 0x10);
        if (uVar3 < *(uint64_t *)(arg2 + 0x18)) {
            *(uint64_t *)(arg2 + 0x10) = uVar3 + 1;
            iVar4 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar4 = *(int64_t *)arg2;
            }
            *(undefined *)(uVar3 + iVar4) = uVar1;
            *(undefined *)(uVar3 + 1 + iVar4) = 0;
        } else {
            func_0x00018000f010(arg2, 1, arg2 & 0xff);
        }
        uVar1 = *(undefined *)((uint64_t)(uVar2 >> 0x18 & 0xf) + 0x180624310);
        uVar3 = *(uint64_t *)(arg2 + 0x10);
        if (uVar3 < *(uint64_t *)(arg2 + 0x18)) {
            *(uint64_t *)(arg2 + 0x10) = uVar3 + 1;
            iVar4 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar4 = *(int64_t *)arg2;
            }
            *(undefined *)(uVar3 + iVar4) = uVar1;
            *(undefined *)(uVar3 + 1 + iVar4) = 0;
        } else {
            func_0x00018000f010(arg2, 1, arg2 & 0xff);
        }
        uVar1 = *(undefined *)((uint64_t)(uVar2 >> 0x1c) + 0x180624310);
        uVar3 = *(uint64_t *)(arg2 + 0x10);
        if (uVar3 < *(uint64_t *)(arg2 + 0x18)) {
            *(uint64_t *)(arg2 + 0x10) = uVar3 + 1;
            if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                *(undefined *)(uVar3 + arg2) = uVar1;
                *(undefined *)(uVar3 + 1 + arg2) = 0;
            } else {
                iVar4 = *(int64_t *)arg2;
                *(undefined *)(uVar3 + iVar4) = uVar1;
                *(undefined *)(uVar3 + 1 + iVar4) = 0;
            }
        } else {
            func_0x00018000f010(arg2, 1, arg2 & 0xff);
        }
        iVar5 = iVar5 + 1;
    } while (iVar5 != 4);
    return arg2;
}

// ============================================================
// Function: FUN_180056510
// Address: 0x180056510
// Size: 906 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h

undefined8 fcn.180056510(int64_t arg1, int64_t arg_78h, int64_t arg_88h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    code *pcVar6;
    char cVar7;
    int16_t iVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    
    ppiVar10 = *(int64_t ***)(arg1 + 0x28);
    ppiVar3 = *(int64_t ***)(arg1 + 0x40);
    ppiVar9 = ppiVar10;
    if (ppiVar3 <= ppiVar10) {
        ppiVar9 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar9 + 0xc) != 9) ||
        (*(uint8_t *)((int64_t)*ppiVar9 + 3) != *(uint32_t *)0x1807823dc)) ||
       (*ppiVar9 == (int64_t *)0xfffffffffffffff0)) goto code_r0x000180056834;
    ppiVar9 = ppiVar10 + 2;
    if (ppiVar3 <= ppiVar10 + 2) {
        ppiVar9 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar9 != *(int64_t ***)0x180782430) && (*(int32_t *)((int64_t)ppiVar9 + 0xc) == 6)) {
        ppiVar9 = ppiVar10 + 4;
        if (ppiVar3 <= ppiVar10 + 4) {
            ppiVar9 = *(int64_t ***)0x180782430;
        }
        if ((ppiVar9 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar9 + 0xc) == -1))
        goto code_r0x000180056884;
        func_0x000180018f70();
        if (*(char *)(*(int64_t *)(*(int64_t *)(arg1 + 0x50) + 0x98) + 0x118) == '\0') {
            ppiVar10 = *(int64_t ***)(arg1 + 0x28);
            if (*(int64_t ***)(arg1 + 0x40) <= *(int64_t ***)(arg1 + 0x28)) {
                ppiVar10 = *(int64_t ***)0x180782430;
            }
            if (*(int32_t *)((int64_t)ppiVar10 + 0xc) == 9) {
                piVar15 = *ppiVar10 + 2;
            } else if (*(int32_t *)((int64_t)ppiVar10 + 0xc) == 2) {
                piVar15 = *ppiVar10;
            } else {
                piVar15 = (int64_t *)0x0;
            }
            if (piVar15[1] != 0) {
                LOCK();
                piVar1 = (int32_t *)(piVar15[1] + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            iVar17 = *piVar15;
            piVar15 = (int64_t *)piVar15[1];
            ppiVar10 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t ***)(arg1 + 0x40) <= ppiVar10) {
                ppiVar10 = *(int64_t ***)0x180782430;
            }
            if (*(int32_t *)((int64_t)ppiVar10 + 0xc) == 6) {
                piVar4 = *ppiVar10;
                iVar8 = *(int16_t *)((int64_t)piVar4 + 6);
                piVar11 = piVar4 + 3;
                if (iVar8 == -0x8000) {
                    pcVar6 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x530);
                    if (pcVar6 == (code *)0x0) {
                        iVar8 = -1;
                    } else {
                        iVar8 = (*pcVar6)(arg1, piVar11, *(undefined4 *)((int64_t)piVar4 + 0x14));
                    }
                    *(int16_t *)((int64_t)piVar4 + 6) = iVar8;
                }
                if (iVar8 < 0) goto code_r0x00018005681f;
            } else {
                piVar11 = (int64_t *)0x0;
            }
            piVar11 = (int64_t *)func_0x00018001b140(*(undefined8 *)(iVar17 + 0x18), piVar11);
            if (piVar11 == (int64_t *)0x0) {
                if (piVar15 != (int64_t *)0x0) {
                    LOCK();
                    piVar11 = piVar15 + 1;
                    iVar2 = *(int32_t *)piVar11;
                    *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
                    UNLOCK();
                    if (iVar2 == 1) {
                        (**(code **)*piVar15)(piVar15);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar15 + 0xc);
                        iVar2 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar2 == 1) {
                            (**(code **)(*piVar15 + 8))(piVar15);
                        }
                    }
                }
                return 0;
            }
            cVar7 = (**(code **)(*piVar11 + 8))(piVar11);
            if (cVar7 == '\0') {
                func_0x000180013530();
                iVar17 = *(int64_t *)(arg1 + 0x50);
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) | 0x40;
                *(undefined4 *)(iVar17 + 0x88) = 8;
                *(undefined8 *)(iVar17 + 0x78) = 0x203fffffffffff3f;
                puVar12 = (undefined4 *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
                if (puVar12 != (undefined4 *)0x0) {
                    uVar5 = *(uint64_t *)(iVar17 + 0x78);
                    *puVar12 = 8;
                    *(uint64_t *)(puVar12 + 10) = uVar5 | 0x200000000000003f;
                    *(int64_t *)(puVar12 + 6) = arg1;
                }
                uVar16 = *(uint32_t *)((int64_t)piVar11 + 0x8c);
                *(uint32_t *)((int64_t)piVar11 + 0x8c) = uVar16 | 0x10;
                func_0x0001800869f0(arg1, *(undefined8 *)0x180781f00, 0, 0, 0);
                func_0x000180085bf0(arg1, 1);
                func_0x000180085bf0(arg1, 2);
                func_0x000180085bf0(arg1, 3);
                func_0x0001800878a0(arg1, 3, 0);
                uVar16 = uVar16 & 0x10;
                if (uVar16 == 0) {
                    *(uint32_t *)((int64_t)piVar11 + 0x8c) = *(uint32_t *)((int64_t)piVar11 + 0x8c) & 0xffffffef;
                }
                func_0x000180013740();
                func_0x000180086b20(arg1, uVar16 == 0);
                if (piVar15 != (int64_t *)0x0) {
                    LOCK();
                    piVar11 = piVar15 + 1;
                    iVar2 = *(int32_t *)piVar11;
                    *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
                    UNLOCK();
                    if (iVar2 == 1) {
                        (**(code **)*piVar15)(piVar15);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar15 + 0xc);
                        iVar2 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar2 == 1) {
                            (**(code **)(*piVar15 + 8))(piVar15);
                        }
                    }
                }
                return 1;
            }
        } else {
            iVar13 = fcn.180088300(arg1);
            iVar17 = 0x1806203e8;
            if (iVar13 != 0) {
                iVar17 = iVar13;
            }
            fcn.180088560(arg1, 0x1806203f8, iVar17);
        }
        func_0x000180088380(arg1, 2, 0x1806242f8);
code_r0x000180056884:
        fcn.180088560(arg1, 0x18063da20, 3);
        pcVar6 = (code *)swi(3);
        uVar14 = (*pcVar6)();
        return uVar14;
    }
    func_0x000180088470(arg1, 2, 6);
code_r0x00018005681f:
    func_0x000180088380(arg1, 2, 0x1806242e0);
code_r0x000180056834:
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar6 = (code *)swi(3);
    uVar14 = (*pcVar6)();
    return uVar14;
}

// ============================================================
// Function: FUN_1800568a0
// Address: 0x1800568a0
// Size: 1077 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Detected overlap for variable var_bh
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh

undefined8 fcn.1800568a0(int64_t arg1)
{
    int32_t *piVar1;
    undefined (**ppauVar2) [16];
    uint64_t uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    code *pcVar6;
    undefined auVar7 [16];
    int16_t iVar8;
    int32_t iVar9;
    undefined (**ppauVar10) [16];
    undefined (**ppauVar11) [16];
    uint64_t uVar12;
    int64_t iVar13;
    undefined8 uVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    undefined (*pauVar17) [16];
    undefined *puVar18;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t in_stack_ffffffffffffff90;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    ppauVar11 = *(undefined (***) [16])(arg1 + 0x28);
    ppauVar2 = *(undefined (***) [16])(arg1 + 0x40);
    ppauVar10 = ppauVar11;
    if (ppauVar2 <= ppauVar11) {
        ppauVar10 = *(undefined (***) [16])0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppauVar10 + 0xc) == 9) && ((uint8_t)(**ppauVar10)[3] == *(uint32_t *)0x1807823dc)) &&
       (*ppauVar10 != (undefined (*) [16])0xfffffffffffffff0)) {
        ppauVar10 = ppauVar11 + 2;
        if (ppauVar2 <= ppauVar11 + 2) {
            ppauVar10 = *(undefined (***) [16])0x180782430;
        }
        if ((ppauVar10 != *(undefined (***) [16])0x180782430) && (*(int32_t *)((int64_t)ppauVar10 + 0xc) == 6)) {
            if (ppauVar2 <= ppauVar11) {
                ppauVar11 = *(undefined (***) [16])0x180782430;
            }
            if (*(int32_t *)((int64_t)ppauVar11 + 0xc) == 9) {
                pauVar17 = *ppauVar11 + 1;
            } else if (*(int32_t *)((int64_t)ppauVar11 + 0xc) == 2) {
                pauVar17 = *ppauVar11;
            } else {
                pauVar17 = (undefined (*) [16])0x0;
            }
            if (*(int64_t *)(*pauVar17 + 8) != 0) {
                LOCK();
                piVar1 = (int32_t *)(*(int64_t *)(*pauVar17 + 8) + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            uVar3 = *(uint64_t *)*pauVar17;
            piVar4 = *(int64_t **)(*pauVar17 + 8);
            auVar7 = *pauVar17;
            ppauVar11 = (undefined (**) [16])(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(undefined (***) [16])(arg1 + 0x40) <= ppauVar11) {
                ppauVar11 = *(undefined (***) [16])0x180782430;
            }
            if (*(int32_t *)((int64_t)ppauVar11 + 0xc) == 6) {
                pauVar17 = *ppauVar11;
                iVar8 = *(int16_t *)(*pauVar17 + 6);
                puVar18 = pauVar17[1] + 8;
                if (iVar8 == -0x8000) {
                    pcVar6 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x530);
                    if (pcVar6 == (code *)0x0) {
                        iVar8 = -1;
                    } else {
                        iVar8 = (*pcVar6)(arg1, puVar18, *(undefined4 *)(pauVar17[1] + 4), pcVar6, uVar3, piVar4);
                    }
                    *(int16_t *)(*pauVar17 + 6) = iVar8;
                }
                if (iVar8 < 0) goto code_r0x000180056c93;
            } else {
                puVar18 = (undefined *)0x0;
            }
            uVar12 = func_0x00018001b140(*(undefined8 *)(uVar3 + 0x18), puVar18);
            if (uVar12 == 0) {
                if (((*(char *)0x180777010 != (char)uVar12) &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar9 = fcn.180085510(in_stack_ffffffffffffff90), iVar9 == 0)) goto code_r0x000180056cbd;
                puVar5 = *(undefined4 **)(arg1 + 0x40);
                *puVar5 = 0;
                puVar5[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
code_r0x000180056bfa:
                if (piVar4 != (int64_t *)0x0) {
                    LOCK();
                    piVar16 = piVar4 + 1;
                    iVar9 = *(int32_t *)piVar16;
                    *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)*piVar4)(piVar4);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                        iVar9 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar9 == 1) {
                            (**(code **)(*piVar4 + 8))(piVar4);
                        }
                    }
                }
            } else {
                var_60h = 0;
                piVar16 = (int64_t *)var_60h;
                _var_68h = ZEXT816(0);
                if (piVar4 != (int64_t *)0x0) {
                    LOCK();
                    *(int32_t *)((int64_t)piVar4 + 0xc) = *(int32_t *)((int64_t)piVar4 + 0xc) + 1;
                    UNLOCK();
                    piVar16 = piVar4;
                    _var_68h = auVar7;
                }
                uVar15 = (int64_t)uVar3 >> 0x30 & 0xff;
                var_58h = ((((((((uVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar3 >> 8 & 0xffU) *
                                0x100000001b3 ^ (int64_t)uVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                              (int64_t)uVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar3 >> 0x20 & 0xffU) *
                             0x100000001b3 ^ (int64_t)uVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^ uVar15) * 0x100000001b3 ^
                          (int64_t)uVar3 >> 0x38 & 0xffU) * 0x100000001b3;
                iVar13 = func_0x00018001bae0(uVar15, &var_78h, &var_68h);
                iVar19 = *(int64_t *)0x180782008;
                if (*(int64_t *)(iVar13 + 8) != 0) {
                    iVar19 = *(int64_t *)(iVar13 + 8);
                }
                if (piVar16 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar16 + 8))(piVar16);
                    }
                }
                if (iVar19 != *(int64_t *)0x180782008) {
                    piVar16 = (int64_t *)
                              ((((((((((uVar12 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ uVar12 >> 8 & 0xff) *
                                      0x100000001b3 ^ uVar12 >> 0x10 & 0xff) * 0x100000001b3 ^ uVar12 >> 0x18 & 0xff) *
                                    0x100000001b3 ^ uVar12 >> 0x20 & 0xff) * 0x100000001b3 ^ uVar12 >> 0x28 & 0xff) *
                                  0x100000001b3 ^ uVar12 >> 0x30 & 0xff) * 0x100000001b3 ^ uVar12 >> 0x38) *
                                0x100000001b3 & *(uint64_t *)(iVar19 + 0x58)) * 0x10 + *(int64_t *)(iVar19 + 0x40));
                    iVar13 = piVar16[1];
                    if (iVar13 == *(int64_t *)(iVar19 + 0x30)) {
code_r0x000180056be1:
                        iVar13 = 0;
                    } else {
                        uVar3 = *(uint64_t *)(iVar13 + 0x10);
                        while (uVar12 != uVar3) {
                            if (iVar13 == *piVar16) goto code_r0x000180056be1;
                            iVar13 = *(int64_t *)(iVar13 + 8);
                            uVar3 = *(uint64_t *)(iVar13 + 0x10);
                        }
                    }
                    if ((iVar13 != 0) && (iVar13 != *(int64_t *)(iVar19 + 0x30))) {
                        func_0x000180086b20(arg1, *(undefined *)(iVar13 + 0x18));
                        goto code_r0x000180056bfa;
                    }
                }
                func_0x000180086b20(arg1, *(uint32_t *)(uVar12 + 0x8c) >> 4 & 1);
                if (piVar4 != (int64_t *)0x0) {
                    LOCK();
                    piVar16 = piVar4 + 1;
                    iVar9 = *(int32_t *)piVar16;
                    *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)*piVar4)(piVar4);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                        iVar9 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar9 == 1) {
                            (**(code **)(*piVar4 + 8))(piVar4);
                        }
                    }
                }
            }
            return 1;
        }
        func_0x000180088470(arg1, 2, 6);
code_r0x000180056c93:
        func_0x000180088380(arg1, 2, 0x1806242e0);
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
code_r0x000180056cbd:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar6 = (code *)swi(3);
    uVar14 = (*pcVar6)();
    return uVar14;
}

// ============================================================
// Function: FUN_180056ce0
// Address: 0x180056ce0
// Size: 1497 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180056ce0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t uVar2;
    undefined (**ppauVar3) [16];
    uint64_t uVar4;
    int64_t *piVar5;
    undefined4 *puVar6;
    code *pcVar7;
    undefined auVar8 [16];
    int16_t iVar9;
    int32_t iVar10;
    undefined (**ppauVar11) [16];
    undefined (**ppauVar12) [16];
    int64_t iVar13;
    undefined *puVar14;
    undefined8 uVar15;
    uint64_t uVar16;
    int64_t **ppiVar17;
    undefined uVar18;
    int64_t **ppiVar19;
    int64_t **ppiVar20;
    undefined (*pauVar21) [16];
    int64_t *piVar22;
    int64_t iVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t in_stack_ffffffffffffffa0;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    ppauVar12 = *(undefined (***) [16])(arg1 + 0x28);
    ppauVar3 = *(undefined (***) [16])(arg1 + 0x40);
    ppauVar11 = ppauVar12;
    if (ppauVar3 <= ppauVar12) {
        ppauVar11 = *(undefined (***) [16])0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppauVar11 + 0xc) != 9) || ((uint8_t)(**ppauVar11)[3] != *(uint32_t *)0x1807823dc)) ||
       (*ppauVar11 == (undefined (*) [16])0xfffffffffffffff0)) goto code_r0x000180057252;
    ppauVar11 = ppauVar12 + 2;
    if (ppauVar3 <= ppauVar12 + 2) {
        ppauVar11 = *(undefined (***) [16])0x180782430;
    }
    if ((ppauVar11 != *(undefined (***) [16])0x180782430) && (*(int32_t *)((int64_t)ppauVar11 + 0xc) == 6)) {
        ppauVar11 = ppauVar12 + 4;
        if (ppauVar3 <= ppauVar12 + 4) {
            ppauVar11 = *(undefined (***) [16])0x180782430;
        }
        if ((ppauVar11 == *(undefined (***) [16])0x180782430) || (*(int32_t *)((int64_t)ppauVar11 + 0xc) != 1))
        goto code_r0x0001800572a5;
        func_0x000180018f70();
        if (*(char *)(*(int64_t *)(*(int64_t *)(arg1 + 0x50) + 0x98) + 0x118) == '\0') {
            ppauVar12 = *(undefined (***) [16])(arg1 + 0x28);
            if (*(undefined (***) [16])(arg1 + 0x40) <= *(undefined (***) [16])(arg1 + 0x28)) {
                ppauVar12 = *(undefined (***) [16])0x180782430;
            }
            if (*(int32_t *)((int64_t)ppauVar12 + 0xc) == 9) {
                pauVar21 = *ppauVar12 + 1;
            } else if (*(int32_t *)((int64_t)ppauVar12 + 0xc) == 2) {
                pauVar21 = *ppauVar12;
            } else {
                pauVar21 = (undefined (*) [16])0x0;
            }
            if (*(int64_t *)(*pauVar21 + 8) != 0) {
                LOCK();
                piVar1 = (int32_t *)(*(int64_t *)(*pauVar21 + 8) + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            uVar4 = *(uint64_t *)*pauVar21;
            piVar5 = *(int64_t **)(*pauVar21 + 8);
            auVar8 = *pauVar21;
            ppauVar12 = (undefined (**) [16])(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(undefined (***) [16])(arg1 + 0x40) <= ppauVar12) {
                ppauVar12 = *(undefined (***) [16])0x180782430;
            }
            if (*(int32_t *)((int64_t)ppauVar12 + 0xc) == 6) {
                pauVar21 = *ppauVar12;
                iVar9 = *(int16_t *)(*pauVar21 + 6);
                puVar14 = pauVar21[1] + 8;
                if (iVar9 == -0x8000) {
                    pcVar7 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x530);
                    if (pcVar7 == (code *)0x0) {
                        iVar9 = -1;
                    } else {
                        iVar9 = (*pcVar7)(arg1, puVar14, *(undefined4 *)(pauVar21[1] + 4), pcVar7, uVar4, piVar5);
                    }
                    *(int16_t *)(*pauVar21 + 6) = iVar9;
                }
                if (iVar9 < 0) goto code_r0x00018005723d;
            } else {
                puVar14 = (undefined *)0x0;
            }
            var_10h = func_0x00018001b140(*(undefined8 *)(uVar4 + 0x18), puVar14);
            if (var_10h != 0) {
                uVar2 = *(uint32_t *)(var_10h + 0x8c);
                ppiVar19 = (int64_t **)**(int64_t ***)0x180782008;
                ppiVar17 = *(int64_t ***)0x180782008;
                if (ppiVar19 != *(int64_t ***)0x180782008) {
                    do {
                        iVar13 = *(int64_t *)0x180782018;
                        if ((ppiVar19[3] == (int64_t *)0x0) || (*(int32_t *)(ppiVar19[3] + 1) == 0)) {
                            uVar16 = (uint64_t)ppiVar19[4] & *(uint64_t *)0x180782030;
                            ppiVar20 = *(int64_t ***)(*(int64_t *)0x180782018 + uVar16 * 0x10);
                            if (*(int64_t ***)(*(int64_t *)0x180782018 + 8 + uVar16 * 0x10) == ppiVar19) {
                                if (ppiVar20 == ppiVar19) {
                                    *(int64_t ***)(*(int64_t *)0x180782018 + uVar16 * 0x10) = ppiVar17;
                                    *(int64_t ***)(iVar13 + 8 + uVar16 * 0x10) = ppiVar17;
                                } else {
                                    *(int64_t **)(*(int64_t *)0x180782018 + 8 + uVar16 * 0x10) = ppiVar19[1];
                                }
                            } else if (ppiVar20 == ppiVar19) {
                                *(int64_t **)(*(int64_t *)0x180782018 + uVar16 * 0x10) = *ppiVar19;
                            }
                            ppiVar20 = (int64_t **)*ppiVar19;
                            *(int64_t *)0x180782010 = *(int64_t *)0x180782010 + -1;
                            *ppiVar19[1] = (int64_t)ppiVar20;
                            ppiVar20[1] = ppiVar19[1];
                            func_0x00018000ace0(ppiVar19 + 8);
                            func_0x00018001c440(ppiVar19 + 6);
                            piVar22 = ppiVar19[3];
                            if (piVar22 != (int64_t *)0x0) {
                                LOCK();
                                piVar1 = (int32_t *)((int64_t)piVar22 + 0xc);
                                iVar10 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar10 == 1) {
                                    (**(code **)(*piVar22 + 8))();
                                }
                            }
                            func_0x000180459c3c(ppiVar19, 0x68);
                            ppiVar17 = *(int64_t ***)0x180782008;
                        } else {
                            ppiVar20 = (int64_t **)*ppiVar19;
                        }
                        ppiVar19 = ppiVar20;
                    } while (ppiVar20 != ppiVar17);
                }
                var_50h = 0;
                piVar22 = (int64_t *)var_50h;
                _var_58h = ZEXT816(0);
                if (piVar5 != (int64_t *)0x0) {
                    LOCK();
                    *(int32_t *)((int64_t)piVar5 + 0xc) = *(int32_t *)((int64_t)piVar5 + 0xc) + 1;
                    UNLOCK();
                    piVar22 = piVar5;
                    _var_58h = auVar8;
                }
                uVar16 = (int64_t)uVar4 >> 0x38 & 0xff;
                iVar23 = ((((((((uVar4 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar4 >> 8 & 0xffU) *
                               0x100000001b3 ^ (int64_t)uVar4 >> 0x10 & 0xffU) * 0x100000001b3 ^
                             (int64_t)uVar4 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar4 >> 0x20 & 0xffU) *
                            0x100000001b3 ^ (int64_t)uVar4 >> 0x28 & 0xffU) * 0x100000001b3 ^
                          (int64_t)uVar4 >> 0x30 & 0xffU) * 0x100000001b3 ^ uVar16) * 0x100000001b3;
                var_48h = iVar23;
                iVar13 = func_0x00018001bae0(uVar16, &var_68h, &var_58h, iVar23);
                ppiVar19 = *(int64_t ***)0x180782008;
                ppiVar17 = *(int64_t ***)0x180782008;
                if (*(int64_t ***)(iVar13 + 8) != (int64_t **)0x0) {
                    ppiVar17 = *(int64_t ***)(iVar13 + 8);
                }
                if (piVar22 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar22 + 0xc);
                    iVar10 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar10 == 1) {
                        (**(code **)(*piVar22 + 8))(piVar22);
                    }
                }
                if (ppiVar17 == ppiVar19) {
                    var_58h = 0;
                    var_50h = 0;
                    if (piVar5 != (int64_t *)0x0) {
                        LOCK();
                        *(int32_t *)((int64_t)piVar5 + 0xc) = *(int32_t *)((int64_t)piVar5 + 0xc) + 1;
                        UNLOCK();
                        var_58h = uVar4;
                        var_50h = (int64_t)piVar5;
                    }
                    var_48h = iVar23;
                    uVar15 = func_0x000180058400(0, &var_58h);
                    func_0x00018001c190(uVar15);
                    if (var_50h != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(var_50h + 0xc);
                        iVar10 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar10 == 1) {
                            (**(code **)(*(int64_t *)var_50h + 8))();
                        }
                    }
                }
                ppauVar12 = (undefined (**) [16])(*(int64_t *)(arg1 + 0x28) + 0x20);
                if (*(undefined (***) [16])(arg1 + 0x40) <= ppauVar12) {
                    ppauVar12 = *(undefined (***) [16])0x180782430;
                }
                iVar10 = *(int32_t *)((int64_t)ppauVar12 + 0xc);
                if ((iVar10 == 0) || ((iVar10 == 1 && (*(int32_t *)ppauVar12 == 0)))) {
                    uVar18 = 0;
                } else {
                    uVar18 = 1;
                }
                var_58h = 0;
                var_50h = 0;
                if (piVar5 != (int64_t *)0x0) {
                    LOCK();
                    *(int32_t *)((int64_t)piVar5 + 0xc) = *(int32_t *)((int64_t)piVar5 + 0xc) + 1;
                    UNLOCK();
                    var_58h = uVar4;
                    var_50h = (int64_t)piVar5;
                }
                var_48h = iVar23;
                uVar15 = func_0x000180058400(iVar10, &var_58h);
                puVar14 = (undefined *)func_0x00018001b5e0(uVar15, &var_10h);
                *puVar14 = uVar18;
                if (var_50h != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(var_50h + 0xc);
                    iVar10 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar10 == 1) {
                        (**(code **)(*(int64_t *)var_50h + 8))();
                    }
                }
                func_0x000180086b20(arg1, uVar2 >> 4 & 1);
                if (piVar5 != (int64_t *)0x0) {
                    LOCK();
                    piVar22 = piVar5 + 1;
                    iVar10 = *(int32_t *)piVar22;
                    *(int32_t *)piVar22 = *(int32_t *)piVar22 + -1;
                    UNLOCK();
                    if (iVar10 == 1) {
                        (**(code **)*piVar5)(piVar5);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                        iVar10 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar10 == 1) {
                            (**(code **)(*piVar5 + 8))(piVar5);
                        }
                    }
                }
                return 1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar10 = fcn.180085510(in_stack_ffffffffffffffa0), iVar10 != 0)) {
                puVar6 = *(undefined4 **)(arg1 + 0x40);
                *puVar6 = 0;
                puVar6[3] = 1;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                if (piVar5 == (int64_t *)0x0) {
                    return 1;
                }
                LOCK();
                piVar22 = piVar5 + 1;
                iVar10 = *(int32_t *)piVar22;
                *(int32_t *)piVar22 = *(int32_t *)piVar22 + -1;
                UNLOCK();
                if (iVar10 != 1) {
                    return 1;
                }
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar10 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar10 != 1) {
                    return 1;
                }
                (**(code **)(*piVar5 + 8))(piVar5);
                return 1;
            }
        } else {
            iVar23 = fcn.180088300(arg1);
            iVar13 = 0x1806203e8;
            if (iVar23 != 0) {
                iVar13 = iVar23;
            }
            fcn.180088560(arg1, 0x1806203f8, iVar13);
        }
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
code_r0x0001800572a5:
        func_0x000180088470(arg1, 3, 1);
        pcVar7 = (code *)swi(3);
        uVar15 = (*pcVar7)();
        return uVar15;
    }
    func_0x000180088470(arg1, 2, 6);
code_r0x00018005723d:
    func_0x000180088380(arg1, 2, 0x1806242e0);
code_r0x000180057252:
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar7 = (code *)swi(3);
    uVar15 = (*pcVar7)();
    return uVar15;
}

// ============================================================
// Function: FUN_1800572c0
// Address: 0x1800572c0
// Size: 591 bytes
// ============================================================
undefined8 fcn.1800572c0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t **ppiVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t **ppiVar11;
    int64_t *piVar12;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    
    ppiVar11 = *(int64_t ***)(arg1 + 0x28);
    ppiVar7 = ppiVar11;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar11) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar7 + 0xc) == 9) &&
        (*(uint8_t *)((int64_t)*ppiVar7 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*ppiVar7 != (int64_t *)0xfffffffffffffff0)) {
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar11) {
            ppiVar11 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar11 + 0xc) == 9) {
            piVar12 = *ppiVar11 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar11 + 0xc) == 2) {
            piVar12 = *ppiVar11;
        } else {
            piVar12 = (int64_t *)0x0;
        }
        if (piVar12[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar12[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar2 = *piVar12;
        piVar12 = (int64_t *)piVar12[1];
        var_40h = iVar2;
        var_38h = (int64_t)piVar12;
        for (iVar8 = *(int64_t *)(iVar2 + 0x18); iVar8 != 0; iVar8 = *(int64_t *)(iVar8 + 0x230)) {
            piVar10 = *(int64_t **)(iVar8 + 8);
            piVar4 = piVar10 + 2;
            if (0xf < (uint64_t)piVar10[3]) {
                piVar10 = (int64_t *)*piVar10;
            }
            if ((*piVar4 == 8) && (iVar6 = func_0x000180497f30(piVar10, 0x180623b90, 8), iVar6 == 0)) {
                iVar8 = func_0x00018001b140(*(undefined8 *)(iVar2 + 0x18), 0x180624358);
                if (iVar8 == 0) {
                    if (((*(char *)0x180777010 != '\0') &&
                        (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                       (iVar6 = fcn.180085510(in_stack_ffffffffffffffd0), iVar6 == 0)) {
                        fcn.180099450(arg1, 0x18063d8d0);
                        fcn.180087960(arg1);
                        pcVar5 = (code *)swi(3);
                        uVar9 = (*pcVar5)();
                        return uVar9;
                    }
                    puVar3 = *(undefined4 **)(arg1 + 0x40);
                    *puVar3 = 0;
                    puVar3[3] = 1;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    if (piVar12 != (int64_t *)0x0) {
                        LOCK();
                        piVar4 = piVar12 + 1;
                        iVar6 = *(int32_t *)piVar4;
                        *(int32_t *)piVar4 = *(int32_t *)piVar4 + -1;
                        UNLOCK();
                        if (iVar6 == 1) {
                            (**(code **)*piVar12)(piVar12);
                            LOCK();
                            piVar1 = (int32_t *)((int64_t)piVar12 + 0xc);
                            iVar6 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar6 == 1) {
                                (**(code **)(*piVar12 + 8))(piVar12);
                                return 1;
                            }
                        }
                    }
                } else {
                    var_48h._0_4_ = 0;
                    piVar4 = *(int64_t **)(iVar8 + 0x90);
                    if (((piVar4 != (int64_t *)0x0) && (*piVar4 != 0)) &&
                       (pcVar5 = *(code **)(*piVar4 + 0x18), pcVar5 != (code *)0x0)) {
                        (*pcVar5)(piVar4, &var_48h, iVar2);
                    }
                    func_0x000180086b20(arg1, 3 < (int32_t)var_48h);
                    if (piVar12 != (int64_t *)0x0) {
                        LOCK();
                        piVar4 = piVar12 + 1;
                        iVar6 = *(int32_t *)piVar4;
                        *(int32_t *)piVar4 = *(int32_t *)piVar4 + -1;
                        UNLOCK();
                        if (iVar6 == 1) {
                            (**(code **)*piVar12)(piVar12);
                            LOCK();
                            piVar1 = (int32_t *)((int64_t)piVar12 + 0xc);
                            iVar6 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar6 == 1) {
                                (**(code **)(*piVar12 + 8))(piVar12);
                            }
                        }
                    }
                }
                return 1;
            }
        }
        func_0x000180088380(arg1, 1, 0x180623be8);
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar5 = (code *)swi(3);
    uVar9 = (*pcVar5)();
    return uVar9;
}

// ============================================================
// Function: FUN_180057510
// Address: 0x180057510
// Size: 1354 bytes
// ============================================================
void fcn.180057510(int64_t arg1)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    undefined auVar5 [16];
    char cVar6;
    int32_t iVar7;
    int64_t **ppiVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    uint64_t uVar12;
    int32_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    undefined *puVar18;
    undefined *puVar19;
    undefined8 *puVar20;
    int64_t iVar21;
    int32_t iVar22;
    int64_t iVar23;
    undefined4 extraout_XMM0_Da;
    undefined auStack_108 [8];
    undefined auStack_100 [24];
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar18 = auStack_108;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_108;
    ppiVar14 = *(int64_t ***)(arg1 + 0x28);
    ppiVar8 = ppiVar14;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar14) {
        ppiVar8 = *(int64_t ***)0x180782430;
    }
    puVar19 = auStack_108;
    if (((*(int32_t *)((int64_t)ppiVar8 + 0xc) == 9) &&
        (puVar19 = auStack_108, *(uint8_t *)((int64_t)*ppiVar8 + 3) == *(uint32_t *)0x1807823dc)) &&
       (puVar19 = auStack_108, *ppiVar8 != (int64_t *)0xfffffffffffffff0)) {
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar14) {
            ppiVar14 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar14 + 0xc) == 9) {
            piVar9 = *ppiVar14 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar14 + 0xc) == 2) {
            piVar9 = *ppiVar14;
        } else {
            piVar9 = (int64_t *)0x0;
        }
        if (piVar9[1] != 0) {
            LOCK();
            piVar13 = (int32_t *)(piVar9[1] + 8);
            *piVar13 = *piVar13 + 1;
            UNLOCK();
        }
        iVar23 = *piVar9;
        piVar9 = (int64_t *)piVar9[1];
        iVar17 = *(int64_t *)(iVar23 + 0x18);
        var_c0h = iVar23;
        var_b8h = (int64_t)piVar9;
        if (iVar17 != 0) {
            iVar21 = *(int64_t *)(iVar17 + 0x28);
            uVar15 = *(uint64_t *)(iVar17 + 0x30);
            var_d0h = uVar15;
            var_c8h = iVar21;
            func_0x000180086fd0(arg1, 0, 0);
            iVar22 = 0;
            if (uVar15 != 0) {
                do {
                    if (((*(int32_t *)((int64_t)(iVar22 << 4) + 8 + iVar21) == 0) &&
                        (piVar16 = *(int64_t **)((iVar22 << 4) + iVar21),
                        (*(uint32_t *)((int64_t)piVar16 + 0x8c) >> 4 & 1) == 0)) &&
                       (cVar6 = (**(code **)(*piVar16 + 0x10))(piVar16), cVar6 == '\0')) {
                        puVar20 = (undefined8 *)piVar16[1];
                        if (0xf < (uint64_t)puVar20[3]) {
                            puVar20 = (undefined8 *)*puVar20;
                        }
                        if (puVar20 == (undefined8 *)0x0) {
                            func_0x000180086510(arg1);
                        } else {
                            uVar11 = func_0x000180498cd0(puVar20);
                            fcn.1800867f0(arg1, puVar20, uVar11);
                        }
                        iVar1 = *(int32_t *)(piVar16[0xd] + 0x30);
                        if (iVar1 == 0x1d) {
                            var_d8h._0_4_ = 0;
                            piVar16 = (int64_t *)piVar16[0x12];
                            if (((piVar16 == (int64_t *)0x0) || (*piVar16 == 0)) ||
                               (pcVar4 = *(code **)(*piVar16 + 0x18), pcVar4 == (code *)0x0)) {
                                func_0x0001800865e0(arg1, 0);
                            } else {
                                (*pcVar4)(piVar16, &var_d8h, iVar23);
                                func_0x0001800865e0(arg1, (undefined4)var_d8h);
                            }
                        } else if (iVar1 == 0x1e) {
                            var_98h = 0;
                            var_90h = 0xf;
                            stack0xffffffffffffff59 = SUB1615(ZEXT816(0), 1);
                            auVar5[15] = 0;
                            auVar5._0_15_ = stack0xffffffffffffff59;
                            _var_a8h = auVar5 << 8;
                            (**(code **)(*piVar16 + 0xc0))(piVar16, &var_a8h, iVar23);
                            piVar16 = &var_a8h;
                            if (0xf < (uint64_t)var_90h) {
                                piVar16 = (int64_t *)var_a8h;
                            }
                            fcn.1800867f0(arg1, piVar16, var_98h);
                            func_0x0001800588c0(&var_a8h);
                        } else if (iVar1 == 0x3e) {
                            piVar16 = (int64_t *)piVar16[0x12];
                            if (((piVar16 != (int64_t *)0x0) && (*piVar16 != 0)) &&
                               (pcVar4 = *(code **)(*piVar16 + 0x18), pcVar4 != (code *)0x0)) {
                                (*pcVar4)(piVar16, &var_b0h, iVar23);
                            }
                            piVar16 = (int64_t *)(var_b0h + 0x10);
                            if (0xf < *(uint64_t *)(var_b0h + 0x28)) {
                                piVar16 = (int64_t *)*piVar16;
                            }
                            fcn.1800867f0(arg1, piVar16, *(undefined8 *)(var_b0h + 0x20));
                        } else if (iVar1 == 0x48) {
                            piVar16 = (int64_t *)piVar16[0x13];
                            if (((piVar16 != (int64_t *)0x0) && (*piVar16 != 0)) &&
                               (pcVar4 = *(code **)(*piVar16 + 0x18), pcVar4 != (code *)0x0)) {
                                (*pcVar4)(piVar16, &var_68h, iVar23);
                            }
                            fcn.180056230(piVar16, (int64_t)&var_88h, (int64_t)&var_68h);
                            piVar16 = &var_88h;
                            if (0xf < (uint64_t)var_70h) {
                                piVar16 = (int64_t *)var_88h;
                            }
                            fcn.1800867f0(arg1, piVar16, var_78h);
                            if (0xf < (uint64_t)var_70h) {
                                uVar12 = var_70h + 1;
                                iVar17 = var_88h;
                                if (0xfff < uVar12) {
                                    iVar17 = *(int64_t *)(var_88h + -8);
                                    if (0x1f < (var_88h - iVar17) - 8U) {
                                        pcVar4 = (code *)swi(0x29);
                                        (*pcVar4)(5);
                                        puVar18 = auStack_100;
                                        goto code_r0x000180057a38;
                                    }
                                    uVar12 = var_70h + 0x28;
                                }
                                func_0x000180459c3c(iVar17, uVar12);
                            }
                        } else {
                            func_0x000180013530();
                            iVar23 = *(int64_t *)(arg1 + 0x50);
                            iVar1 = *(int32_t *)(iVar23 + 0x88);
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) | 0x40;
                            *(undefined4 *)(iVar23 + 0x88) = 8;
                            *(undefined8 *)(iVar23 + 0x78) = 0x203fffffffffff3f;
                            puVar10 = (undefined4 *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
                            if (puVar10 != (undefined4 *)0x0) {
                                uVar15 = *(uint64_t *)(iVar23 + 0x78);
                                *puVar10 = 8;
                                *(uint64_t *)(puVar10 + 10) = uVar15 | 0x200000000000003f;
                                *(int64_t *)(puVar10 + 6) = arg1;
                            }
                            uVar2 = *(uint32_t *)((int64_t)piVar16 + 0x8c);
                            *(uint32_t *)((int64_t)piVar16 + 0x8c) = uVar2 | 0x10;
                            var_e8h = 0;
                            func_0x0001800869f0(arg1, *(undefined8 *)0x180781ef8, 0, 0);
                            func_0x000180085bf0(arg1, 1);
                            puVar20 = (undefined8 *)piVar16[1];
                            if (0xf < (uint64_t)puVar20[3]) {
                                puVar20 = (undefined8 *)*puVar20;
                            }
                            if (puVar20 == (undefined8 *)0x0) {
                                func_0x000180086510(arg1);
                            } else {
                                uVar11 = func_0x000180498cd0(puVar20);
                                fcn.1800867f0(arg1, puVar20, uVar11);
                            }
                            iVar7 = func_0x0001800878a0(arg1, 2, 1);
                            if (iVar7 != 0) {
                                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                            }
                            if ((uVar2 >> 4 & 1) == 0) {
                                *(uint32_t *)((int64_t)piVar16 + 0x8c) =
                                     *(uint32_t *)((int64_t)piVar16 + 0x8c) & 0xffffffef;
                            }
                            iVar17 = *(int64_t *)(arg1 + 0x50);
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) | 0x40;
                            *(int32_t *)(iVar17 + 0x88) = iVar1;
                            uVar12 = func_0x000180013610(extraout_XMM0_Da, iVar1);
                            if (((iVar1 - 2U & 0xfffffffc) != 0) || (uVar15 = 0x103fffffffffff00, iVar1 == 3)) {
                                uVar15 = 0x3fffffffffff00;
                            }
                            *(uint64_t *)(iVar17 + 0x78) = uVar15 | uVar12;
                            piVar13 = (int32_t *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
                            iVar23 = var_c0h;
                            uVar15 = var_d0h;
                            if (piVar13 != (int32_t *)0x0) {
                                uVar3 = *(uint64_t *)(iVar17 + 0x78);
                                *piVar13 = iVar1;
                                *(uint64_t *)(piVar13 + 10) = uVar3 & 0xffffffffffffffc0 | uVar12;
                                *(int64_t *)(piVar13 + 6) = arg1;
                            }
                        }
                        func_0x0001800a8680(arg1, *(int64_t *)(arg1 + 0x40) + -0x30);
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
                        iVar21 = var_c8h;
                    }
                    iVar22 = iVar22 + 1;
                } while ((uint64_t)(int64_t)iVar22 < uVar15);
            }
            if (piVar9 != (int64_t *)0x0) {
                LOCK();
                piVar16 = piVar9 + 1;
                iVar22 = *(int32_t *)piVar16;
                *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                UNLOCK();
                if (iVar22 == 1) {
                    (**(code **)*piVar9)(piVar9);
                    LOCK();
                    piVar13 = (int32_t *)((int64_t)piVar9 + 0xc);
                    iVar22 = *piVar13;
                    *piVar13 = *piVar13 + -1;
                    UNLOCK();
                    if (iVar22 == 1) {
                        (**(code **)(*piVar9 + 8))(piVar9);
                    }
                }
            }
            func_0x000180459870(var_58h ^ (uint64_t)auStack_108);
            return;
        }
code_r0x000180057a38:
        *(undefined8 *)(puVar18 + -8) = 0x180057a44;
        fcn.180088560();
        puVar19 = puVar18;
    }
    *(undefined8 *)(puVar19 + -8) = 0x180057a59;
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_180057a60
// Address: 0x180057a60
// Size: 1354 bytes
// ============================================================
void fcn.180057a60(int64_t arg1)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    undefined auVar5 [16];
    char cVar6;
    int32_t iVar7;
    int64_t **ppiVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    uint64_t uVar12;
    int32_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    undefined *puVar18;
    undefined *puVar19;
    undefined8 *puVar20;
    int64_t iVar21;
    int32_t iVar22;
    int64_t iVar23;
    undefined4 extraout_XMM0_Da;
    undefined auStack_108 [8];
    undefined auStack_100 [24];
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar18 = auStack_108;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_108;
    ppiVar14 = *(int64_t ***)(arg1 + 0x28);
    ppiVar8 = ppiVar14;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar14) {
        ppiVar8 = *(int64_t ***)0x180782430;
    }
    puVar19 = auStack_108;
    if (((*(int32_t *)((int64_t)ppiVar8 + 0xc) == 9) &&
        (puVar19 = auStack_108, *(uint8_t *)((int64_t)*ppiVar8 + 3) == *(uint32_t *)0x1807823dc)) &&
       (puVar19 = auStack_108, *ppiVar8 != (int64_t *)0xfffffffffffffff0)) {
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar14) {
            ppiVar14 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar14 + 0xc) == 9) {
            piVar9 = *ppiVar14 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar14 + 0xc) == 2) {
            piVar9 = *ppiVar14;
        } else {
            piVar9 = (int64_t *)0x0;
        }
        if (piVar9[1] != 0) {
            LOCK();
            piVar13 = (int32_t *)(piVar9[1] + 8);
            *piVar13 = *piVar13 + 1;
            UNLOCK();
        }
        iVar23 = *piVar9;
        piVar9 = (int64_t *)piVar9[1];
        iVar17 = *(int64_t *)(iVar23 + 0x18);
        var_c0h = iVar23;
        var_b8h = (int64_t)piVar9;
        if (iVar17 != 0) {
            iVar21 = *(int64_t *)(iVar17 + 0x28);
            uVar15 = *(uint64_t *)(iVar17 + 0x30);
            var_d0h = uVar15;
            var_c8h = iVar21;
            func_0x000180086fd0(arg1, 0, 0);
            iVar22 = 0;
            if (uVar15 != 0) {
                do {
                    if (((*(int32_t *)((int64_t)(iVar22 << 4) + 8 + iVar21) == 0) &&
                        (piVar16 = *(int64_t **)((iVar22 << 4) + iVar21),
                        (*(uint32_t *)((int64_t)piVar16 + 0x8c) >> 4 & 1) != 0)) &&
                       (cVar6 = (**(code **)(*piVar16 + 0x10))(piVar16), cVar6 == '\0')) {
                        puVar20 = (undefined8 *)piVar16[1];
                        if (0xf < (uint64_t)puVar20[3]) {
                            puVar20 = (undefined8 *)*puVar20;
                        }
                        if (puVar20 == (undefined8 *)0x0) {
                            func_0x000180086510(arg1);
                        } else {
                            uVar11 = func_0x000180498cd0(puVar20);
                            fcn.1800867f0(arg1, puVar20, uVar11);
                        }
                        iVar1 = *(int32_t *)(piVar16[0xd] + 0x30);
                        if (iVar1 == 0x1d) {
                            var_d8h._0_4_ = 0;
                            piVar16 = (int64_t *)piVar16[0x12];
                            if (((piVar16 == (int64_t *)0x0) || (*piVar16 == 0)) ||
                               (pcVar4 = *(code **)(*piVar16 + 0x18), pcVar4 == (code *)0x0)) {
                                func_0x0001800865e0(arg1, 0);
                            } else {
                                (*pcVar4)(piVar16, &var_d8h, iVar23);
                                func_0x0001800865e0(arg1, (undefined4)var_d8h);
                            }
                        } else if (iVar1 == 0x1e) {
                            var_98h = 0;
                            var_90h = 0xf;
                            stack0xffffffffffffff59 = SUB1615(ZEXT816(0), 1);
                            auVar5[15] = 0;
                            auVar5._0_15_ = stack0xffffffffffffff59;
                            _var_a8h = auVar5 << 8;
                            (**(code **)(*piVar16 + 0xc0))(piVar16, &var_a8h, iVar23);
                            piVar16 = &var_a8h;
                            if (0xf < (uint64_t)var_90h) {
                                piVar16 = (int64_t *)var_a8h;
                            }
                            fcn.1800867f0(arg1, piVar16, var_98h);
                            func_0x0001800588c0(&var_a8h);
                        } else if (iVar1 == 0x3e) {
                            piVar16 = (int64_t *)piVar16[0x12];
                            if (((piVar16 != (int64_t *)0x0) && (*piVar16 != 0)) &&
                               (pcVar4 = *(code **)(*piVar16 + 0x18), pcVar4 != (code *)0x0)) {
                                (*pcVar4)(piVar16, &var_b0h, iVar23);
                            }
                            piVar16 = (int64_t *)(var_b0h + 0x10);
                            if (0xf < *(uint64_t *)(var_b0h + 0x28)) {
                                piVar16 = (int64_t *)*piVar16;
                            }
                            fcn.1800867f0(arg1, piVar16, *(undefined8 *)(var_b0h + 0x20));
                        } else if (iVar1 == 0x48) {
                            piVar16 = (int64_t *)piVar16[0x13];
                            if (((piVar16 != (int64_t *)0x0) && (*piVar16 != 0)) &&
                               (pcVar4 = *(code **)(*piVar16 + 0x18), pcVar4 != (code *)0x0)) {
                                (*pcVar4)(piVar16, &var_68h, iVar23);
                            }
                            fcn.180056230(piVar16, (int64_t)&var_88h, (int64_t)&var_68h);
                            piVar16 = &var_88h;
                            if (0xf < (uint64_t)var_70h) {
                                piVar16 = (int64_t *)var_88h;
                            }
                            fcn.1800867f0(arg1, piVar16, var_78h);
                            if (0xf < (uint64_t)var_70h) {
                                uVar12 = var_70h + 1;
                                iVar17 = var_88h;
                                if (0xfff < uVar12) {
                                    iVar17 = *(int64_t *)(var_88h + -8);
                                    if (0x1f < (var_88h - iVar17) - 8U) {
                                        pcVar4 = (code *)swi(0x29);
                                        (*pcVar4)(5);
                                        puVar18 = auStack_100;
                                        goto code_r0x000180057f88;
                                    }
                                    uVar12 = var_70h + 0x28;
                                }
                                func_0x000180459c3c(iVar17, uVar12);
                            }
                        } else {
                            func_0x000180013530();
                            iVar23 = *(int64_t *)(arg1 + 0x50);
                            iVar1 = *(int32_t *)(iVar23 + 0x88);
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) | 0x40;
                            *(undefined4 *)(iVar23 + 0x88) = 8;
                            *(undefined8 *)(iVar23 + 0x78) = 0x203fffffffffff3f;
                            puVar10 = (undefined4 *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
                            if (puVar10 != (undefined4 *)0x0) {
                                uVar15 = *(uint64_t *)(iVar23 + 0x78);
                                *puVar10 = 8;
                                *(uint64_t *)(puVar10 + 10) = uVar15 | 0x200000000000003f;
                                *(int64_t *)(puVar10 + 6) = arg1;
                            }
                            uVar2 = *(uint32_t *)((int64_t)piVar16 + 0x8c);
                            *(uint32_t *)((int64_t)piVar16 + 0x8c) = uVar2 | 0x10;
                            var_e8h = 0;
                            func_0x0001800869f0(arg1, *(undefined8 *)0x180781ef8, 0, 0);
                            func_0x000180085bf0(arg1, 1);
                            puVar20 = (undefined8 *)piVar16[1];
                            if (0xf < (uint64_t)puVar20[3]) {
                                puVar20 = (undefined8 *)*puVar20;
                            }
                            if (puVar20 == (undefined8 *)0x0) {
                                func_0x000180086510(arg1);
                            } else {
                                uVar11 = func_0x000180498cd0(puVar20);
                                fcn.1800867f0(arg1, puVar20, uVar11);
                            }
                            iVar7 = func_0x0001800878a0(arg1, 2, 1);
                            if (iVar7 != 0) {
                                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                            }
                            if ((uVar2 >> 4 & 1) == 0) {
                                *(uint32_t *)((int64_t)piVar16 + 0x8c) =
                                     *(uint32_t *)((int64_t)piVar16 + 0x8c) & 0xffffffef;
                            }
                            iVar17 = *(int64_t *)(arg1 + 0x50);
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) | 0x40;
                            *(int32_t *)(iVar17 + 0x88) = iVar1;
                            uVar12 = func_0x000180013610(extraout_XMM0_Da, iVar1);
                            if (((iVar1 - 2U & 0xfffffffc) != 0) || (uVar15 = 0x103fffffffffff00, iVar1 == 3)) {
                                uVar15 = 0x3fffffffffff00;
                            }
                            *(uint64_t *)(iVar17 + 0x78) = uVar15 | uVar12;
                            piVar13 = (int32_t *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
                            iVar23 = var_c0h;
                            uVar15 = var_d0h;
                            if (piVar13 != (int32_t *)0x0) {
                                uVar3 = *(uint64_t *)(iVar17 + 0x78);
                                *piVar13 = iVar1;
                                *(uint64_t *)(piVar13 + 10) = uVar3 & 0xffffffffffffffc0 | uVar12;
                                *(int64_t *)(piVar13 + 6) = arg1;
                            }
                        }
                        func_0x0001800a8680(arg1, *(int64_t *)(arg1 + 0x40) + -0x30);
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
                        iVar21 = var_c8h;
                    }
                    iVar22 = iVar22 + 1;
                } while ((uint64_t)(int64_t)iVar22 < uVar15);
            }
            if (piVar9 != (int64_t *)0x0) {
                LOCK();
                piVar16 = piVar9 + 1;
                iVar22 = *(int32_t *)piVar16;
                *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                UNLOCK();
                if (iVar22 == 1) {
                    (**(code **)*piVar9)(piVar9);
                    LOCK();
                    piVar13 = (int32_t *)((int64_t)piVar9 + 0xc);
                    iVar22 = *piVar13;
                    *piVar13 = *piVar13 + -1;
                    UNLOCK();
                    if (iVar22 == 1) {
                        (**(code **)(*piVar9 + 8))(piVar9);
                    }
                }
            }
            func_0x000180459870(var_58h ^ (uint64_t)auStack_108);
            return;
        }
code_r0x000180057f88:
        *(undefined8 *)(puVar18 + -8) = 0x180057f94;
        fcn.180088560();
        puVar19 = puVar18;
    }
    *(undefined8 *)(puVar19 + -8) = 0x180057fa9;
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_180057fb0
// Address: 0x180057fb0
// Size: 29 bytes
// ============================================================
undefined8 fcn.180057fb0(int64_t arg1)
{
    fcn.1800865e0(arg1, *(undefined4 *)(*(int64_t *)(arg1 + 0x50) + 0x88));
    return 1;
}

// ============================================================
// Function: FUN_180057fd0
// Address: 0x180057fd0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180057fd0(int64_t arg1)
{
    int64_t var_8h;
    
    fcn.180088860(arg1, 1);
    fcn.180013530();
    fcn.180013740();
    return 0;
}

// ============================================================
// Function: FUN_180058010
// Address: 0x180058010
// Size: 878 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_8ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Detected overlap for variable var_bh
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_dh
// WARNING: [rz-ghidra] Detected overlap for variable var_eh
// WARNING: [rz-ghidra] Detected overlap for variable var_fh

void fcn.180058010(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    func_0x000180018f70();
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_78h = 0;
    func_0x0001800869f0(arg2, fcn.180055d40, 0x180624328, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624328);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_78h = 0;
    func_0x0001800869f0(arg2, fcn.180056510, 0x180624340, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624340);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_78h = 0;
    func_0x0001800869f0(arg2, fcn.1800568a0, 0x1806243b0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x1806243b0);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_78h = 0;
    func_0x0001800869f0(arg2, fcn.180056ce0, 0x1806243c0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x1806243c0);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_78h = 0;
    func_0x0001800869f0(arg2, fcn.1800572c0, 0x180624388, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624388);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_78h = 0;
    func_0x0001800869f0(arg2, fcn.180057510, 0x180624398, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624398);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_78h = 0;
    func_0x0001800869f0(arg2, fcn.180057a60, 0x1806243f8, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x1806243f8);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_78h = 0;
    func_0x0001800869f0(arg2, 0x180005d40, 0x180624408, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624408);
    var_68h = 0x1806243d0;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_60h = 0x1806243e8;
    var_78h = 0;
    var_58h = 0x180624448;
    func_0x0001800869f0(arg2, fcn.180057fb0, 0x180624460, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180624460);
    piVar4 = &var_68h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180624460);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_50h);
    var_50h = 0x180624420;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_48h = 0x180624438;
    var_78h = 0;
    var_40h = 0x180624478;
    func_0x0001800869f0(arg2, fcn.180057fd0, 0x180624490, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180624490);
    piVar4 = &var_50h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180624490);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_38h);
    func_0x000180459870(var_38h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_180058380
// Address: 0x180058380
// Size: 99 bytes
// ============================================================
void fcn.180058380(void)
{
    int64_t in_stack_00000008;
    int64_t var_10h;
    
    if (*(int64_t *)0x180782010 != 0) {
        fcn.18001bbf0(in_stack_00000008);
        *(int64_t *)*(int64_t *)0x180782008 = *(int64_t *)0x180782008;
        *(int64_t *)(*(int64_t *)0x180782008 + 8) = *(int64_t *)0x180782008;
        var_10h = *(int64_t *)0x180782008;
        *(int64_t *)0x180782010 = 0;
        fcn.18000d540(*(undefined8 *)0x180782018, *(undefined8 *)0x180782020, &var_10h);
    }
    return;
}

// ============================================================
// Function: FUN_180058400
// Address: 0x180058400
// Size: 1207 bytes
// ============================================================
undefined8 * fcn.180058400(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    undefined8 *puVar6;
    int64_t **ppiVar7;
    undefined8 *puVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    code *pcVar13;
    uint64_t uVar14;
    undefined8 *puVar15;
    int64_t iVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    int64_t *piVar21;
    float fVar22;
    undefined4 uVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    uVar19 = *(uint64_t *)(arg2 + 0x10);
    func_0x00018001bae0(arg1, &var_68h, arg2, uVar19);
    puVar15 = (undefined8 *)CONCAT44(var_60h._4_4_, (undefined4)var_60h);
    if (puVar15 != (undefined8 *)0x0) goto code_r0x000180058888;
    if (*(int64_t *)0x180782010 == 0x276276276276276) {
code_r0x0001800588aa:
        fcn.1804546d4(0x180620428);
        pcVar13 = (code *)swi(3);
        puVar15 = (undefined8 *)(*pcVar13)();
        return puVar15;
    }
    var_58h = 0x180782008;
    var_50h = 0;
    puVar15 = (undefined8 *)fcn.180459890(0x68);
    puVar15[2] = 0;
    puVar15[3] = 0;
    puVar15[2] = *(undefined8 *)arg2;
    puVar15[3] = *(undefined8 *)(arg2 + 8);
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    puVar15[4] = *(undefined8 *)(arg2 + 0x10);
    *(undefined4 *)(puVar15 + 5) = 0;
    puVar15[6] = 0;
    puVar15[7] = 0;
    var_50h = (int64_t)puVar15;
    iVar16 = fcn.180459890(0x20);
    *(int64_t *)iVar16 = iVar16;
    *(int64_t *)(iVar16 + 8) = iVar16;
    puVar15[6] = iVar16;
    puVar15[8] = 0;
    puVar15[9] = 0;
    puVar15[10] = 0;
    puVar15[0xb] = 7;
    puVar15[0xc] = 8;
    *(undefined4 *)(puVar15 + 5) = 0x3f800000;
    func_0x00018000f7e0(puVar15 + 8, 0x10, puVar15[6]);
    uVar14 = *(uint64_t *)0x180782038;
    uVar17 = *(int64_t *)0x180782010 + 1;
    if ((int64_t)uVar17 < 0) {
        fVar22 = (float)(uVar17 >> 1 | (uint64_t)((uint32_t)uVar17 & 1));
        fVar22 = fVar22 + fVar22;
    } else {
        fVar22 = (float)uVar17;
    }
    if ((int64_t)*(uint64_t *)0x180782038 < 0) {
        fVar24 = (float)(*(uint64_t *)0x180782038 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x180782038 & 1));
        fVar24 = fVar24 + fVar24;
    } else {
        fVar24 = (float)*(uint64_t *)0x180782038;
    }
    if (*(float *)0x180782000 < fVar22 / fVar24) {
        fVar22 = (float)func_0x000180471c90(fVar22 / *(float *)0x180782000);
        puVar11 = *(undefined8 **)0x180782008;
        iVar16 = 0;
        if ((9.223372e+18 <= fVar22) && (fVar22 = fVar22 - 9.223372e+18, fVar22 < 9.223372e+18)) {
            iVar16 = -0x8000000000000000;
        }
        uVar17 = 8;
        if (8 < (uint64_t)((int64_t)fVar22 + iVar16)) {
            uVar17 = (int64_t)fVar22 + iVar16;
        }
        uVar20 = uVar14;
        if ((uVar14 < uVar17) && ((0x1ff < uVar14 || (uVar20 = uVar14 * 8, uVar14 * 8 < uVar17)))) {
            uVar20 = uVar17;
        }
        for (iVar16 = 0x3f; 0xfffffffffffffffU >> iVar16 == 0; iVar16 = iVar16 + -1) {
        }
        if ((uint64_t)(1LL << ((uint8_t)iVar16 & 0x3f)) < uVar20) {
            fcn.1804546d4(0x180620448);
            goto code_r0x0001800588aa;
        }
        uVar17 = uVar20 - 1 | 1;
        iVar16 = 0x3f;
        if (uVar17 != 0) {
            for (; uVar17 >> iVar16 == 0; iVar16 = iVar16 + -1) {
            }
        }
        uVar17 = 1LL << ((char)iVar16 + 1U & 0x3f);
        uVar23 = func_0x00018000f7e0(0x180782018, uVar17 * 2, *(undefined8 **)0x180782008);
        *(uint64_t *)0x180782030 = uVar17 - 1;
        *(uint64_t *)0x180782038 = uVar17;
        puVar12 = (undefined8 *)**(undefined8 **)0x180782008;
        iVar16 = *(int64_t *)0x180782018;
joined_r0x000180058654:
        *(int64_t *)0x180782018 = iVar16;
        if (puVar12 != puVar11) {
            puVar3 = (undefined8 *)*puVar12;
            uVar17 = puVar12[4] & *(uint64_t *)0x180782030;
            if (*(undefined8 **)(iVar16 + uVar17 * 0x10) == puVar11) {
                *(undefined8 **)(iVar16 + uVar17 * 0x10) = puVar12;
code_r0x0001800587e0:
                *(undefined8 **)(iVar16 + 8 + uVar17 * 0x10) = puVar12;
                puVar12 = puVar3;
                iVar16 = *(int64_t *)0x180782018;
            } else {
                piVar21 = *(int64_t **)(iVar16 + 8 + uVar17 * 0x10);
                piVar4 = (int64_t *)piVar21[3];
                if (piVar4 == (int64_t *)0x0) {
code_r0x0001800586b9:
                    piVar4 = (int64_t *)puVar12[3];
                    if (piVar4 != (int64_t *)0x0) {
                        LOCK();
                        *(int32_t *)((int64_t)piVar4 + 0xcU) = *(int32_t *)((int64_t)piVar4 + 0xcU) + 1;
                        UNLOCK();
                        piVar5 = (int64_t *)piVar21[3];
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                        iVar2 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar2 == 1) {
                            uVar23 = (**(code **)(*piVar4 + 8))();
                        }
                        if (piVar5 < piVar4) goto code_r0x0001800586f0;
                    }
                    puVar6 = (undefined8 *)*piVar21;
                    if (puVar6 != puVar12) {
                        puVar8 = (undefined8 *)puVar12[1];
                        *puVar8 = puVar3;
                        puVar9 = (undefined8 *)puVar3[1];
                        *puVar9 = puVar6;
                        puVar10 = (undefined8 *)puVar6[1];
                        *puVar10 = puVar12;
                        puVar6[1] = puVar9;
                        puVar3[1] = puVar8;
                        puVar12[1] = puVar10;
                    }
                    goto code_r0x0001800587e0;
                }
                LOCK();
                *(int32_t *)((int64_t)piVar4 + 0xcU) = *(int32_t *)((int64_t)piVar4 + 0xcU) + 1;
                UNLOCK();
                piVar5 = (int64_t *)puVar12[3];
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    uVar23 = (**(code **)(*piVar4 + 8))();
                }
                if (piVar4 <= piVar5) goto code_r0x0001800586b9;
code_r0x0001800586f0:
                if (*(int64_t **)(iVar16 + uVar17 * 0x10) != piVar21) {
                    do {
                        piVar21 = (int64_t *)piVar21[1];
                        piVar4 = (int64_t *)piVar21[3];
                        if (piVar4 == (int64_t *)0x0) {
code_r0x000180058733:
                            piVar4 = (int64_t *)puVar12[3];
                            if (piVar4 != (int64_t *)0x0) {
                                LOCK();
                                *(int32_t *)((int64_t)piVar4 + 0xcU) = *(int32_t *)((int64_t)piVar4 + 0xcU) + 1;
                                UNLOCK();
                                piVar5 = (int64_t *)piVar21[3];
                                LOCK();
                                piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                                iVar2 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar2 == 1) {
                                    uVar23 = (**(code **)(*piVar4 + 8))();
                                }
                                if (piVar5 < piVar4) goto code_r0x000180058762;
                            }
                            iVar16 = *piVar21;
                            puVar6 = (undefined8 *)puVar12[1];
                            *puVar6 = puVar3;
                            piVar21 = (int64_t *)puVar3[1];
                            *piVar21 = iVar16;
                            puVar8 = *(undefined8 **)(iVar16 + 8);
                            *puVar8 = puVar12;
                            *(int64_t **)(iVar16 + 8) = piVar21;
                            puVar3[1] = puVar6;
                            puVar12[1] = puVar8;
                            puVar12 = puVar3;
                            iVar16 = *(int64_t *)0x180782018;
                            goto joined_r0x000180058654;
                        }
                        LOCK();
                        *(int32_t *)((int64_t)piVar4 + 0xcU) = *(int32_t *)((int64_t)piVar4 + 0xcU) + 1;
                        UNLOCK();
                        piVar5 = (int64_t *)puVar12[3];
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                        iVar2 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar2 == 1) {
                            uVar23 = (**(code **)(*piVar4 + 8))();
                        }
                        if (piVar4 <= piVar5) goto code_r0x000180058733;
code_r0x000180058762:
                    } while (*(int64_t **)(iVar16 + uVar17 * 0x10) != piVar21);
                }
                puVar6 = (undefined8 *)puVar12[1];
                *puVar6 = puVar3;
                ppiVar7 = (int64_t **)puVar3[1];
                *ppiVar7 = piVar21;
                puVar8 = (undefined8 *)piVar21[1];
                *puVar8 = puVar12;
                piVar21[1] = (int64_t)ppiVar7;
                puVar3[1] = puVar6;
                puVar12[1] = puVar8;
                *(undefined8 **)(iVar16 + uVar17 * 0x10) = puVar12;
                puVar12 = puVar3;
                iVar16 = *(int64_t *)0x180782018;
            }
            goto joined_r0x000180058654;
        }
        puVar18 = (undefined4 *)func_0x00018001bae0(uVar23, &var_58h, puVar15 + 2, uVar19);
        var_68h._0_4_ = *puVar18;
        var_68h._4_4_ = puVar18[1];
    }
    puVar3 = (undefined8 *)CONCAT44(var_68h._4_4_, (undefined4)var_68h);
    puVar11 = (undefined8 *)puVar3[1];
    *(int64_t *)0x180782010 = *(int64_t *)0x180782010 + 1;
    *puVar15 = puVar3;
    puVar15[1] = puVar11;
    *puVar11 = puVar15;
    puVar3[1] = puVar15;
    iVar16 = *(int64_t *)0x180782018;
    uVar19 = *(uint64_t *)0x180782030 & uVar19;
    puVar12 = *(undefined8 **)(*(int64_t *)0x180782018 + uVar19 * 0x10);
    if (puVar12 == *(undefined8 **)0x180782008) {
        *(undefined8 **)(*(int64_t *)0x180782018 + uVar19 * 0x10) = puVar15;
    } else {
        if (puVar12 == puVar3) {
            *(undefined8 **)(*(int64_t *)0x180782018 + uVar19 * 0x10) = puVar15;
            goto code_r0x000180058888;
        }
        if (*(undefined8 **)(*(int64_t *)0x180782018 + 8 + uVar19 * 0x10) != puVar11) goto code_r0x000180058888;
    }
    *(undefined8 **)(iVar16 + 8 + uVar19 * 0x10) = puVar15;
code_r0x000180058888:
    return puVar15 + 5;
}

// ============================================================
// Function: FUN_1800588c0
// Address: 0x1800588c0
// Size: 95 bytes
// ============================================================
void fcn.1800588c0(int64_t arg1)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar4 = auStack_28;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar2 = iVar3 - *(int64_t *)(iVar3 + -8), iVar3 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28,
           0x1f < iVar2 - 8U)) {
            iVar3 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180058905;
        (**(code **)0x1807825c8)(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

