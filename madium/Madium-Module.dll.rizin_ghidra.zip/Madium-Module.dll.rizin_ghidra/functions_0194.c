// Chunk 194 - 50 functions

// ============================================================
// Function: FUN_18025cc9a
// Address: 0x18025cc9a
// Size: 316 bytes
// ============================================================
uint64_t fcn.18025cc9a(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int32_t *unaff_RBX;
    int64_t iVar5;
    int64_t var_20h;
    
    if (unaff_RBX == (int32_t *)0x0) {
code_r0x00018025cdc3:
        uVar4 = func_0x0001802149b0();
        return uVar4;
    }
    if (((*unaff_RBX == 0x100) && (*(int64_t *)(unaff_RBX + 0xc) != 0)) &&
       (iVar1 = *(int64_t *)(unaff_RBX + 10), iVar1 != 0)) {
        iVar5 = 0x1805aadb1;
        if (*(int64_t *)(iVar1 + 0x10) != 0) {
            iVar5 = *(int64_t *)(iVar1 + 0x10);
        }
        if (*(int64_t *)(iVar1 + 0xb8) != 0) {
            func_0x000180229b10();
            uVar2 = (**(code **)(iVar1 + 0xb8))(*(undefined8 *)(unaff_RBX + 0xc));
            if (((int32_t)uVar2 < 1) && (iVar3 = func_0x000180229970(), iVar3 == 0)) {
                func_0x000180229480();
                func_0x0001802295a0(0x1804e67d8, 0x1e2, 0x1804e6870);
                func_0x0001802296d0(6, 0xea, 0x1804e6888, *(undefined8 *)(iVar1 + 8), iVar5);
            }
            func_0x000180229900();
            return (uint64_t)uVar2;
        }
        func_0x000180229480();
        func_0x0001802295a0(0x1804e67d8, 0x1da, 0x1804e6870);
        func_0x0001802296d0(6, 0xed, 0x1804e6888, *(undefined8 *)(iVar1 + 8), iVar5);
    } else if (((*(uint8_t *)(unaff_RBX + 0x28) & 1) == 0) ||
              (iVar3 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1e) + 0xf8))(), iVar3 != 0)) {
        unaff_RBX[0x28] = unaff_RBX[0x28] & 0xfffffffe;
        goto code_r0x00018025cdc3;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025cdd6
// Address: 0x18025cdd6
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_40h

uint64_t fcn.18025cc9a(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int32_t *unaff_RBX;
    int64_t iVar5;
    int64_t var_20h;
    
    if (unaff_RBX == (int32_t *)0x0) {
code_r0x00018025cdc3:
        uVar4 = func_0x0001802149b0();
        return uVar4;
    }
    if (((*unaff_RBX == 0x100) && (*(int64_t *)(unaff_RBX + 0xc) != 0)) &&
       (iVar1 = *(int64_t *)(unaff_RBX + 10), iVar1 != 0)) {
        iVar5 = 0x1805aadb1;
        if (*(int64_t *)(iVar1 + 0x10) != 0) {
            iVar5 = *(int64_t *)(iVar1 + 0x10);
        }
        if (*(int64_t *)(iVar1 + 0xb8) != 0) {
            func_0x000180229b10();
            uVar2 = (**(code **)(iVar1 + 0xb8))(*(undefined8 *)(unaff_RBX + 0xc));
            if (((int32_t)uVar2 < 1) && (iVar3 = func_0x000180229970(), iVar3 == 0)) {
                func_0x000180229480();
                func_0x0001802295a0(0x1804e67d8, 0x1e2, 0x1804e6870);
                func_0x0001802296d0(6, 0xea, 0x1804e6888, *(undefined8 *)(iVar1 + 8), iVar5);
            }
            func_0x000180229900();
            return (uint64_t)uVar2;
        }
        func_0x000180229480();
        func_0x0001802295a0(0x1804e67d8, 0x1da, 0x1804e6870);
        func_0x0001802296d0(6, 0xed, 0x1804e6888, *(undefined8 *)(iVar1 + 8), iVar5);
    } else if (((*(uint8_t *)(unaff_RBX + 0x28) & 1) == 0) ||
              (iVar3 = (**(code **)(*(int64_t *)(unaff_RBX + 0x1e) + 0xf8))(), iVar3 != 0)) {
        unaff_RBX[0x28] = unaff_RBX[0x28] & 0xfffffffe;
        goto code_r0x00018025cdc3;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025cdf0
// Address: 0x18025cdf0
// Size: 2359 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5fh
// WARNING: [rz-ghidra] Detected overlap for variable var_5bh
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h

void fcn.18025cdf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_130h)
{
    uint32_t *puVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined4 *puVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    undefined8 uVar12;
    code *pcVar13;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t *in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_c0h;
    int64_t var_a8h;
    int64_t var_97h;
    int64_t var_87h;
    int64_t var_77h;
    int64_t var_67h;
    undefined4 var_5fh;
    undefined2 var_5bh;
    undefined var_59h;
    int64_t var_58h;
    undefined8 uStack_48;
    int32_t iStack_10;
    int64_t var_ch;
    
    uStack_48 = 0x18025ce0c;
    iVar7 = func_0x00018045a350();
    iVar8 = arg_28h;
    iVar7 = -iVar7;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar7);
    iVar10 = 0;
    *(int64_t *)(&stack0x00000000 + iVar7) = arg_30h;
    iVar9 = arg_38h;
    var_c0h = arg_38h;
    *(int64_t *)((int64_t)&var_10h + iVar7) = arg_40h;
    *(undefined4 *)((int64_t)&var_ch + iVar7) = (undefined4)arg_48h;
    *(int64_t *)((int64_t)&var_20h + iVar7) = arg_50h;
    var_67h = 0;
    var_5fh = 0;
    var_5bh = 0;
    var_59h = 0;
    *(int64_t *)((int64_t)&arg_28h + iVar7) = in_R8;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = in_RDX;
    *(undefined8 *)((int64_t)&var_ch + iVar7 + 4) = 0;
    var_a8h._0_1_ = 0;
    unique0x10000321 = ZEXT816(0);
    *(undefined8 *)((int64_t)&iStackX_8 + iVar7) = 0;
    _var_97h = ZEXT816(0);
    *(undefined4 *)((int64_t)&iStack_10 + iVar7) = 1;
    _var_87h = ZEXT816(0);
    _var_77h = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cead;
    iVar5 = func_0x000180215910();
    if (iVar5 == 0) goto code_r0x00018025d157;
    if (in_RCX[5] == 0) {
        *(undefined4 *)((int64_t)&iStack_10 + iVar7) = 0;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cedd;
            iVar8 = func_0x000180259210(iVar8, *(undefined8 *)((int64_t)&var_10h + iVar7), 
                                        *(undefined8 *)(&stack0x00000000 + iVar7));
        } else {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025ceec;
            iVar8 = func_0x0001802591a0(*(undefined8 *)((int64_t)&var_10h + iVar7), iVar9);
        }
        in_RCX[5] = iVar8;
        if (iVar8 == 0) goto code_r0x00018025d157;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cf06;
    func_0x00018020f580(in_RCX, 0x800);
    piVar2 = (int32_t *)in_RCX[5];
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cf0f;
    func_0x000180229b10();
    if (*(int64_t *)(piVar2 + 8) == 0) {
code_r0x00018025d0e5:
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d0ea;
        func_0x0001802299d0();
        uVar11 = *(undefined8 *)((int64_t)&var_ch + iVar7 + 4);
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d0f4;
        func_0x000180257a00(uVar11);
        *(undefined8 *)((int64_t)&var_ch + iVar7 + 4) = 0;
        if ((in_R8 == 0) && (in_R9 != (int64_t *)0x0)) {
            uVar11 = *(undefined8 *)(piVar2 + 2);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d112;
            in_R8 = func_0x00018022e3d0(uVar11, in_R9);
        }
        if (*(int64_t *)(in_RCX[5] + 0x78) == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d12b;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d143;
            func_0x0001802295a0(0x1804e67d8, 0x131, 0x1804e67f0);
            uVar11 = 0x96;
        } else {
            if (((*(uint8_t *)(*(int64_t *)(in_RCX[5] + 0x78) + 4) & 4) != 0) || (in_R8 != 0)) {
code_r0x00018025d5e8:
                puVar4 = (undefined4 *)in_RCX[5];
                iVar8 = *(int64_t *)(puVar4 + 0x1e);
                if (*(int32_t *)((int64_t)&var_ch + iVar7) == 0) {
                    pcVar13 = *(code **)(iVar8 + 0x70);
                    if (pcVar13 == (code *)0x0) {
                        if (*(int64_t *)(iVar8 + 0xd0) == 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d680;
                            iVar5 = func_0x000180247f40();
                            goto code_r0x00018025d680;
                        }
                        *puVar4 = 0x10;
                        in_RCX[6] = 0x18025d730;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d64f;
                        iVar5 = (*pcVar13)(puVar4, in_RCX);
                        if (iVar5 < 1) goto code_r0x00018025d157;
                        *(undefined4 *)in_RCX[5] = 0x80;
                    }
                } else {
                    pcVar13 = *(code **)(iVar8 + 0x80);
                    if (pcVar13 == (code *)0x0) {
                        if (*(int64_t *)(iVar8 + 0xd8) == 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d63e;
                            iVar5 = func_0x000180248150();
code_r0x00018025d680:
                            if (iVar5 < 1) goto code_r0x00018025d157;
                        } else {
                            *puVar4 = 0x20;
                            in_RCX[6] = 0x18025d730;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d609;
                        iVar5 = (*pcVar13)(puVar4, in_RCX);
                        if (iVar5 < 1) goto code_r0x00018025d157;
                        *(undefined4 *)in_RCX[5] = 0x100;
                    }
                }
                iVar8 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d694;
                iVar5 = func_0x0001802593f0(iVar8, in_R8);
                if (iVar5 < 1) goto code_r0x00018025d157;
                if (*(int64_t **)((int64_t)&arg_30h + iVar7) != (int64_t *)0x0) {
                    **(int64_t **)((int64_t)&arg_30h + iVar7) = in_RCX[5];
                }
                if ((*(uint8_t *)(*(int64_t *)(in_RCX[5] + 0x78) + 4) & 4) != 0) goto code_r0x00018025d157;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d6d4;
                iVar5 = func_0x000180214880(in_RCX, in_R8, var_c0h);
                if (iVar5 == 0) goto code_r0x00018025d157;
                *(uint32_t *)(in_RCX[5] + 0xa0) = *(uint32_t *)(in_RCX[5] + 0xa0) & 0xfffffffe;
                if (*(int64_t *)(*(int64_t *)(in_RCX[5] + 0x78) + 0xf8) != 0) {
                    puVar1 = (uint32_t *)(in_RCX[5] + 0xa0);
                    *puVar1 = *puVar1 | 1;
                }
code_r0x00018025d6ff:
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d707;
                func_0x00018025a1d0(piVar2);
code_r0x00018025d709:
                uVar11 = *(undefined8 *)((int64_t)&var_ch + iVar7 + 4);
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d713;
                func_0x000180257a00(uVar11);
                goto code_r0x00018025d157;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d5a1;
            iVar5 = func_0x00018022f3e0(*(undefined8 *)((int64_t)&var_10h + iVar7), (int64_t)&iStack_10 + iVar7);
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d5ae;
                uVar11 = func_0x00018022ccf0(*(undefined4 *)((int64_t)&iStack_10 + iVar7));
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d5b6;
                in_R8 = func_0x00018022e160(uVar11);
                if (in_R8 != 0) goto code_r0x00018025d5e8;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d5c3;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d5db;
            func_0x0001802295a0(0x1804e67d8, 0x13e, 0x1804e67f0);
            uVar11 = 0x9e;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d155;
        func_0x0001802296d0(6, uVar11, 0);
    } else {
        iVar5 = *(int32_t *)((int64_t)&iStack_10 + iVar7);
        iVar8 = iVar10;
        if (iVar5 != 0) {
            if (*(int64_t *)((int64_t)&var_10h + iVar7) == 0) {
                iVar5 = 0x80;
                if (*(int32_t *)((int64_t)&var_ch + iVar7) != 0) {
                    iVar5 = 0x100;
                }
                iVar8 = 0;
                if (((*piVar2 == iVar5) && (iVar8 = *(int64_t *)(piVar2 + 10), iVar8 != 0)) &&
                   (*(int64_t *)(piVar2 + 0xc) != 0)) {
                    iVar5 = *(int32_t *)((int64_t)&iStack_10 + iVar7);
                    goto code_r0x00018025cf5b;
                }
            }
            iVar5 = 0;
            *(undefined4 *)((int64_t)&iStack_10 + iVar7) = 0;
        }
code_r0x00018025cf5b:
        if (*(int64_t *)(&stack0x00000000 + iVar7) == 0) {
            *(undefined8 *)(&stack0x00000000 + iVar7) = *(undefined8 *)(piVar2 + 4);
        }
        if (*(int64_t *)(piVar2 + 0x22) == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cf79;
            func_0x000180229900();
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cf7e;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cf96;
            func_0x0001802295a0(0x1804e67d8, 0x58, 0x1804e67f0);
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cfa8;
            func_0x0001802296d0(6, 0x9a, 0);
        } else if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cfbd;
            func_0x000180259930(piVar2);
            if ((*(int64_t *)(*(int64_t *)(piVar2 + 0x22) + 0x60) == 0) ||
               (*(int64_t *)(*(int64_t *)(piVar2 + 0x22) + 0x60) == *(int64_t *)(piVar2 + 8))) {
                uVar11 = *(undefined8 *)(piVar2 + 8);
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d01a;
                iVar9 = func_0x00018029f2b0(uVar11, 0xc);
                *(int64_t *)((int64_t)&var_18h + iVar7) = iVar9;
                if (iVar9 == 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d029;
                    func_0x000180229900();
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d02e;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d046;
                    func_0x0001802295a0(0x1804e67d8, 0x71, 0x1804e67f0);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d058;
                    func_0x0001802296d0(6, 0x86, 0);
                } else {
                    iVar5 = 1;
                    *(undefined8 *)((int64_t)&iStackX_8 + iVar7) = 0;
                    iVar9 = 0;
                    while (iVar9 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d089;
                        func_0x0001802481d0(iVar8);
                        uVar11 = *(undefined8 *)((int64_t)&var_ch + iVar7 + 4);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d093;
                        func_0x000180257a00(uVar11);
                        if (iVar5 == 1) {
                            uVar11 = *(undefined8 *)(piVar2 + 4);
                            uVar12 = *(undefined8 *)(piVar2 + 2);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d189;
                            iVar8 = func_0x000180248180(uVar12, *(undefined8 *)((int64_t)&var_18h + iVar7), uVar11);
                            if (iVar8 != 0) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d199;
                                iVar10 = func_0x00018021eaf0(iVar8);
                                goto code_r0x00018025d19c;
                            }
                        } else {
                            if (iVar5 == 2) {
                                uVar11 = *(undefined8 *)(piVar2 + 8);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d0bb;
                                iVar10 = func_0x0001801dd170(uVar11);
                                uVar11 = *(undefined8 *)(piVar2 + 4);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d0cf;
                                iVar8 = func_0x000180248990(iVar10, *(undefined8 *)((int64_t)&var_18h + iVar7), uVar11);
                                if (iVar8 == 0) {
                                    in_R8 = *(int64_t *)((int64_t)&arg_28h + iVar7);
                                    goto code_r0x00018025d0e5;
                                }
                            } else if (iVar8 == 0) goto code_r0x00018025d1f4;
code_r0x00018025d19c:
                            uVar11 = *(undefined8 *)(piVar2 + 8);
                            uVar12 = *(undefined8 *)(piVar2 + 4);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d1a9;
                            uVar11 = func_0x0001801dd6c0(uVar11);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d1b7;
                            iVar9 = func_0x000180257b60(iVar10, uVar11, uVar12);
                            *(int64_t *)((int64_t)&var_ch + iVar7 + 4) = iVar9;
                            if (iVar9 != 0) {
                                uVar11 = *(undefined8 *)(piVar2 + 4);
                                uVar12 = *(undefined8 *)(piVar2 + 2);
                                uVar3 = *(undefined8 *)(piVar2 + 0x22);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d1dd;
                                uVar11 = func_0x000180230ea0(uVar3, uVar12, (int64_t)&var_ch + iVar7 + 4, uVar11);
                                *(undefined8 *)((int64_t)&iStackX_8 + iVar7) = uVar11;
                                if (*(int64_t *)((int64_t)&var_ch + iVar7 + 4) != 0) goto code_r0x00018025d1f4;
                            }
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d1f4;
                            func_0x000180257a00(iVar9);
                        }
code_r0x00018025d1f4:
                        iVar5 = iVar5 + 1;
                        if (2 < iVar5) {
                            if (*(int64_t *)((int64_t)&iStackX_8 + iVar7) == 0) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d211;
                                func_0x0001802481d0(iVar8);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d216;
                                func_0x000180229900();
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d21b;
                                func_0x000180229480();
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d233;
                                func_0x0001802295a0(0x1804e67d8, 0xbc, 0x1804e67f0);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d245;
                                func_0x0001802296d0(6, 0x86, 0);
                                goto code_r0x00018025d56d;
                            }
                            break;
                        }
                        iVar9 = *(int64_t *)((int64_t)&iStackX_8 + iVar7);
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d252;
                    func_0x0001802299d0();
                    iVar5 = *(int32_t *)((int64_t)&var_ch + iVar7);
                    *(int64_t *)(piVar2 + 10) = iVar8;
                    iVar6 = 0x80;
                    if (iVar5 != 0) {
                        iVar6 = 0x100;
                    }
                    *piVar2 = iVar6;
                    uVar11 = *(undefined8 *)(iVar8 + 0x18);
                    pcVar13 = *(code **)(iVar8 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d277;
                    uVar12 = func_0x00018027e810(uVar11);
                    uVar11 = *(undefined8 *)(&stack0x00000000 + iVar7);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d284;
                    iVar9 = (*pcVar13)(uVar12, uVar11);
                    *(int64_t *)(piVar2 + 0xc) = iVar9;
                    if (iVar9 != 0) {
                        in_R8 = *(int64_t *)((int64_t)&arg_28h + iVar7);
                        iVar5 = *(int32_t *)((int64_t)&iStack_10 + iVar7);
                        goto code_r0x00018025d301;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d296;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d2ae;
                    func_0x0001802295a0(0x1804e67d8, 0xca, 0x1804e67f0);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d2c0;
                    func_0x0001802296d0(6, 0x86, 0);
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cfd8;
                func_0x000180229900();
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cfdd;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025cff5;
                func_0x0001802295a0(0x1804e67d8, 0x6a, 0x1804e67f0);
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d007;
                func_0x0001802296d0(6, 0xc0103, 0);
            }
        } else {
            if ((in_R9 == (int64_t *)0x0) && (in_R8 == 0)) {
                iVar9 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d2da;
                in_R9 = (int64_t *)func_0x00018020f750(iVar9);
                if (in_R9 != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d2f1;
                    iVar5 = func_0x000180498f10(in_R9, 0x1804d5e84);
                    if (iVar5 == 0) {
                        in_R9 = (int64_t *)0x0;
                    }
                }
                iVar5 = *(int32_t *)((int64_t)&iStack_10 + iVar7);
            }
            uVar11 = *(undefined8 *)(&stack0x00000000 + iVar7);
code_r0x00018025d301:
            if (*(int32_t ***)((int64_t)&arg_30h + iVar7) != (int32_t **)0x0) {
                **(int32_t ***)((int64_t)&arg_30h + iVar7) = piVar2;
            }
            if (in_R8 == 0) {
                if (in_R9 == (int64_t *)0x0) {
                    if (iVar5 == 0) {
                        uVar12 = *(undefined8 *)((int64_t)&var_ch + iVar7 + 4);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d382;
                        iVar5 = func_0x00018029ee90(uVar12, *(undefined8 *)((int64_t)&iStackX_8 + iVar7), &var_a8h, 0x50
                                                   );
                        if (0 < iVar5) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d396;
                            iVar5 = func_0x000180498f10(&var_a8h, 0x1804d5e84);
                            if (iVar5 != 0) {
                                in_R9 = &var_a8h;
                                goto code_r0x00018025d3a6;
                            }
                            in_R9 = (int64_t *)0x0;
                        }
                    }
                } else {
code_r0x00018025d3a6:
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d3b6;
                    func_0x000180215840(in_RCX, 1, 0);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d3bb;
                    func_0x000180229b10();
                    uVar12 = *(undefined8 *)(piVar2 + 2);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d3ca;
                    iVar9 = func_0x000180215540(uVar12, in_R9, uVar11);
                    in_RCX[8] = iVar9;
                    if (iVar9 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d445;
                        iVar9 = func_0x00018022e160(in_R9);
                        in_RCX[1] = iVar9;
                        *in_RCX = iVar9;
                        if (iVar9 == 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d456;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d45b;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d473;
                            func_0x0001802295a0(0x1804e67d8, 0xf7, 0x1804e67f0);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d485;
                            func_0x0001802296d0(6, 0x86, 0);
                            goto code_r0x00018025d56d;
                        }
                    } else {
                        *in_RCX = iVar9;
                        in_RCX[1] = iVar9;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d3df;
                    func_0x0001802299d0();
                }
            } else {
                *in_RCX = in_R8;
                if (in_R9 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d327;
                    in_R9 = (int64_t *)func_0x00018020f750(in_R8);
                    if (in_R9 != (int64_t *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d342;
                        iVar5 = func_0x000180498f10(in_R9, 0x1804d5e84);
                        if (iVar5 == 0) {
                            in_R9 = (int64_t *)0x0;
                        }
                    }
                }
            }
            iVar9 = 0x1805aadb1;
            if (*(int64_t *)(iVar8 + 0x10) != 0) {
                iVar9 = *(int64_t *)(iVar8 + 0x10);
            }
            if (*(int32_t *)((int64_t)&var_ch + iVar7) == 0) {
                pcVar13 = *(code **)(iVar8 + 0x90);
                if (pcVar13 != (code *)0x0) goto code_r0x00018025d4c7;
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d49e;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d4b6;
                func_0x0001802295a0(0x1804e67d8, 0x10a, 0x1804e67f0);
                uVar12 = 0x1804e6820;
                uVar11 = 0xed;
            } else {
                pcVar13 = *(code **)(iVar8 + 0xb0);
                if (pcVar13 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d414;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d42c;
                    func_0x0001802295a0(0x1804e67d8, 0x102, 0x1804e67f0);
                    uVar12 = 0x1804e6800;
                    uVar11 = 0xed;
                } else {
code_r0x00018025d4c7:
                    uVar11 = *(undefined8 *)(piVar2 + 0xc);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d4da;
                    iVar5 = (*pcVar13)(uVar11, in_R9, *(undefined8 *)((int64_t)&iStackX_8 + iVar7), 
                                       *(undefined8 *)((int64_t)&var_20h + iVar7));
                    if (0 < iVar5) goto code_r0x00018025d6ff;
                    if (in_R9 != (int64_t *)0x0) goto code_r0x00018025d709;
                    if (in_R8 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d4f7;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d50f;
                        func_0x0001802295a0(0x1804e67d8, 0x119, 0x1804e67f0);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d521;
                        func_0x0001802296d0(6, 0x9e, 0);
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d526;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d53e;
                    func_0x0001802295a0(0x1804e67d8, 0x11a, 0x1804e67f0);
                    uVar12 = 0x1804e6820;
                    uVar11 = 0xea;
                    if (*(int32_t *)((int64_t)&var_ch + iVar7) != 0) {
                        uVar12 = 0x1804e6800;
                    }
                }
            }
            uVar3 = *(undefined8 *)(iVar8 + 8);
            *(int64_t *)(&stack0xffffffffffffffe0 + iVar7) = iVar9;
            *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d56d;
            func_0x0001802296d0(6, uVar11, uVar12, uVar3);
        }
code_r0x00018025d56d:
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d575;
        func_0x000180259930(piVar2);
        *piVar2 = 0;
        uVar11 = *(undefined8 *)((int64_t)&var_ch + iVar7 + 4);
        *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d582;
        func_0x000180257a00(uVar11);
    }
code_r0x00018025d157:
    *(undefined8 *)((int64_t)&uStack_48 + iVar7) = 0x18025d163;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar7));
    return;
}

// ============================================================
// Function: FUN_18025d730
// Address: 0x18025d730
// Size: 67 bytes
// ============================================================
undefined8 fcn.18025d730(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025d73a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025d742;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025d75a;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025d76c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18025d780
// Address: 0x18025d780
// Size: 95 bytes
// ============================================================
undefined8 fcn.18025d780(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025d78a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((in_RCX != 0) && (*(int32_t **)(in_RCX + 0x78) != (int32_t *)0x0)) &&
        (iVar1 = **(int32_t **)(in_RCX + 0x78), iVar1 != 6)) && (iVar1 != 0x390)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = in_RDX;
    *(undefined4 *)((int64_t)&var_20h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025d7da;
    uVar3 = fcn.180258740(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    return uVar3;
}

// ============================================================
// Function: FUN_18025d7e0
// Address: 0x18025d7e0
// Size: 92 bytes
// ============================================================
undefined8 fcn.18025d7e0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025d7ea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((in_RCX != 0) && (*(int32_t **)(in_RCX + 0x78) != (int32_t *)0x0)) &&
        (iVar1 = **(int32_t **)(in_RCX + 0x78), iVar1 != 6)) && (iVar1 != 0x390)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = in_RDX;
    *(undefined4 *)((int64_t)&var_20h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025d837;
    uVar3 = fcn.180258740(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    return uVar3;
}

// ============================================================
// Function: FUN_18025d840
// Address: 0x18025d840
// Size: 95 bytes
// ============================================================
undefined8 fcn.18025d840(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025d84a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((in_RCX != 0) && (*(int32_t **)(in_RCX + 0x78) != (int32_t *)0x0)) &&
        (iVar1 = **(int32_t **)(in_RCX + 0x78), iVar1 != 6)) && (iVar1 != 0x390)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = in_RDX;
    *(undefined4 *)((int64_t)&var_20h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025d89a;
    uVar3 = fcn.180258740(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    return uVar3;
}

// ============================================================
// Function: FUN_18025d8a0
// Address: 0x18025d8a0
// Size: 323 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18025d8a0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined4 *puVar7;
    uint32_t *in_RCX;
    int64_t in_RDX;
    int64_t iVar8;
    int32_t in_R8D;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025d8ba;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_RCX == (uint32_t *)0x0) || ((*in_RCX & 0x600) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025d99b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025d9b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025d9c5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
        uVar6 = 0xfffffffe;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025d8ea;
        iVar4 = func_0x0001802590b0(extraout_XMM0_Da, 0x1804a9778);
        if (iVar4 == 0) {
            uVar6 = 0xffffffff;
        } else {
            iVar8 = in_RDX;
            if ((in_RDX == 0) && (iVar8 = 0x1805aadb1, in_R8D != 0)) {
                iVar8 = in_RDX;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025d921;
            puVar7 = (undefined4 *)
                     func_0x000180229c70((int64_t)&iStackX_20 + iVar5 + -8, 0x1804e6a00, iVar8, (int64_t)in_R8D);
            uVar1 = puVar7[1];
            uVar2 = puVar7[2];
            uVar3 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000050 + iVar5) = uVar2;
            *(undefined4 *)(&stack0x00000054 + iVar5) = uVar3;
            uVar1 = puVar7[5];
            uVar2 = puVar7[6];
            uVar3 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000060 + iVar5) = uVar2;
            *(undefined4 *)(&stack0x00000064 + iVar5) = uVar3;
            *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025d947;
            puVar7 = (undefined4 *)func_0x000180229ba0((int64_t)&iStackX_20 + iVar5 + -8);
            uVar1 = puVar7[1];
            uVar2 = puVar7[2];
            uVar3 = puVar7[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar7;
            *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000078 + iVar5) = uVar2;
            *(undefined4 *)(&stack0x0000007c + iVar5) = uVar3;
            uVar1 = puVar7[5];
            uVar2 = puVar7[6];
            uVar3 = puVar7[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar7[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000088 + iVar5) = uVar2;
            *(undefined4 *)(&stack0x0000008c + iVar5) = uVar3;
            *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025d976;
            uVar6 = func_0x000180259dc0(in_RCX, (int64_t)&arg_48h + iVar5);
            if (0 < (int32_t)uVar6) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025d98f;
                func_0x000180224990(in_RDX, 0x1804e6980, 0x4be);
                uVar6 = 1;
            }
        }
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18025d9f0
// Address: 0x18025d9f0
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18025d9f0(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025da00;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025da18;
        in_RDX = fcn.1802551a0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        if (in_RDX == 0) {
            return 0;
        }
    }
    *(int64_t *)((int64_t)&var_20h + iVar2) = in_RDX;
    *(undefined4 *)((int64_t)&var_18h + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025da56;
    iVar1 = fcn.180258740(*(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
    if ((*(int64_t *)(in_RCX + 0x20) == 0) && (iVar1 < 1)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025da6b;
        fcn.180255290(in_RDX);
    }
    return iVar1;
}

// ============================================================
// Function: FUN_18025da80
// Address: 0x18025da80
// Size: 276 bytes
// ============================================================
undefined8
fcn.18025da80(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    uint8_t *in_RCX;
    int32_t in_EDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025da8c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(int64_t *)((int64_t)&arg_a8h + iVar5) = (int64_t)in_EDX;
    if ((in_RCX != (uint8_t *)0x0) && ((*in_RCX & 6) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dabb;
        iVar4 = fcn.1802590b0(extraout_XMM0_Da, 0x1804a9778);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dace;
            iVar4 = fcn.1802590b0(in_RCX, 0x1804af1e0);
            if (iVar4 == 0) {
                return 0xffffffff;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025daf9;
        puVar6 = (undefined4 *)fcn.180229cc0((int64_t)&iStackX_20 + iVar5 + -8, 0x1804bb3dc, (int64_t)&arg_a8h + iVar5);
        uVar1 = puVar6[1];
        uVar2 = puVar6[2];
        uVar3 = puVar6[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar6;
        *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000050 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x00000054 + iVar5) = uVar3;
        uVar1 = puVar6[5];
        uVar2 = puVar6[6];
        uVar3 = puVar6[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar6[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000060 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x00000064 + iVar5) = uVar3;
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar6 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025db1f;
        puVar6 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar5 + -8);
        uVar1 = puVar6[1];
        uVar2 = puVar6[2];
        uVar3 = puVar6[3];
        *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar6;
        *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000078 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x0000007c + iVar5) = uVar3;
        uVar1 = puVar6[5];
        uVar2 = puVar6[6];
        uVar3 = puVar6[7];
        *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar6[4];
        *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000088 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x0000008c + iVar5) = uVar3;
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar6 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025db4e;
        uVar7 = fcn.180259dc0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
        return uVar7;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025db5c;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025db74;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025db86;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18025dba0
// Address: 0x18025dba0
// Size: 276 bytes
// ============================================================
undefined8
fcn.18025dba0(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    uint8_t *in_RCX;
    int32_t in_EDX;
    undefined4 extraout_XMM0_Da;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025dbac;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(int64_t *)((int64_t)&arg_a8h + iVar5) = (int64_t)in_EDX;
    if ((in_RCX != (uint8_t *)0x0) && ((*in_RCX & 6) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dbdb;
        iVar4 = fcn.1802590b0(extraout_XMM0_Da, 0x1804a9778);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dbee;
            iVar4 = fcn.1802590b0(in_RCX, 0x1804af1e0);
            if (iVar4 == 0) {
                return 0xffffffff;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dc19;
        puVar6 = (undefined4 *)fcn.180229cc0((int64_t)&iStackX_20 + iVar5 + -8, 0x1804e6a8c, (int64_t)&arg_a8h + iVar5);
        uVar1 = puVar6[1];
        uVar2 = puVar6[2];
        uVar3 = puVar6[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar6;
        *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000050 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x00000054 + iVar5) = uVar3;
        uVar1 = puVar6[5];
        uVar2 = puVar6[6];
        uVar3 = puVar6[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar6[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000060 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x00000064 + iVar5) = uVar3;
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar6 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dc3f;
        puVar6 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar5 + -8);
        uVar1 = puVar6[1];
        uVar2 = puVar6[2];
        uVar3 = puVar6[3];
        *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar6;
        *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000078 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x0000007c + iVar5) = uVar3;
        uVar1 = puVar6[5];
        uVar2 = puVar6[6];
        uVar3 = puVar6[7];
        *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar6[4];
        *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000088 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x0000008c + iVar5) = uVar3;
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar6 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dc6e;
        uVar7 = fcn.180259dc0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
        return uVar7;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dc7c;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dc94;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dca6;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18025dcc0
// Address: 0x18025dcc0
// Size: 95 bytes
// ============================================================
undefined8 fcn.18025dcc0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025dcca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((in_RCX != 0) && (*(int32_t **)(in_RCX + 0x78) != (int32_t *)0x0)) &&
        (iVar1 = **(int32_t **)(in_RCX + 0x78), iVar1 != 6)) && (iVar1 != 0x390)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = in_RDX;
    *(undefined4 *)((int64_t)&var_20h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025dd1a;
    uVar3 = fcn.180258740(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    return uVar3;
}

// ============================================================
// Function: FUN_18025dd20
// Address: 0x18025dd20
// Size: 92 bytes
// ============================================================
undefined8 fcn.18025dd20(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined4 in_EDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025dd2a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((in_RCX != 0) && (*(int32_t **)(in_RCX + 0x78) != (int32_t *)0x0)) &&
        (iVar1 = **(int32_t **)(in_RCX + 0x78), iVar1 != 6)) && (iVar1 != 0x390)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar2) = in_EDX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025dd77;
    uVar3 = fcn.180258740(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    return uVar3;
}

// ============================================================
// Function: FUN_18025dd80
// Address: 0x18025dd80
// Size: 249 bytes
// ============================================================
undefined8
fcn.18025dd80(uint8_t *placeholder_0, int64_t arg2, int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_80h, int64_t arg_90h, int64_t arg_b0h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025dd8f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((placeholder_0 != (uint8_t *)0x0) && ((*placeholder_0 & 6) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025ddb3;
        iVar4 = fcn.1802590b0(extraout_XMM0_Da, 0x1804af1e0);
        if (iVar4 == 0) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025ddde;
        puVar6 = (undefined4 *)fcn.180229bc0((int64_t)&iStackX_20 + iVar5 + -8, 0x1804e6a38, (int64_t)&arg_b0h + iVar5);
        uVar1 = puVar6[1];
        uVar2 = puVar6[2];
        uVar3 = puVar6[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar6;
        *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000050 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x00000054 + iVar5) = uVar3;
        uVar1 = puVar6[5];
        uVar2 = puVar6[6];
        uVar3 = puVar6[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar6[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000060 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x00000064 + iVar5) = uVar3;
        *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar6 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025de04;
        puVar6 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar5 + -8);
        uVar1 = puVar6[1];
        uVar2 = puVar6[2];
        uVar3 = puVar6[3];
        *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar6;
        *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000078 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x0000007c + iVar5) = uVar3;
        uVar1 = puVar6[5];
        uVar2 = puVar6[6];
        uVar3 = puVar6[7];
        *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar6[4];
        *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000088 + iVar5) = uVar2;
        *(undefined4 *)(&stack0x0000008c + iVar5) = uVar3;
        *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar6 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025de33;
        uVar7 = fcn.180259dc0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
        return uVar7;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025de41;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025de59;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025de6b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18025de80
// Address: 0x18025de80
// Size: 95 bytes
// ============================================================
undefined8 fcn.18025de80(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined4 in_EDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025de8a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((in_RCX != 0) && (*(int32_t **)(in_RCX + 0x78) != (int32_t *)0x0)) &&
        (iVar1 = **(int32_t **)(in_RCX + 0x78), iVar1 != 6)) && (iVar1 != 0x390)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar2) = in_EDX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025deda;
    uVar3 = fcn.180258740(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
    return uVar3;
}

// ============================================================
// Function: FUN_18025def0
// Address: 0x18025def0
// Size: 262 bytes
// ============================================================
void fcn.18025def0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18025df04;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0xa0);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            if ((*(int64_t *)(arg1 + 0x18) != 0) &&
               (pcVar3 = *(code **)(*(int64_t *)(arg1 + 0x18) + 0x40), pcVar3 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df34;
                (*pcVar3)();
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df3d;
            fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df51;
            fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5));
            uVar4 = *(undefined8 *)(arg1 + 200);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df5d;
            fcn.1802227d0(uVar4);
            uVar4 = *(undefined8 *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df66;
            fcn.180255290(uVar4);
            uVar4 = *(undefined8 *)(arg1 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df6f;
            fcn.180255290(uVar4);
            uVar4 = *(undefined8 *)(arg1 + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df78;
            fcn.180254e90(uVar4);
            uVar4 = *(undefined8 *)(arg1 + 0x40);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df81;
            fcn.180254e90(uVar4);
            uVar4 = *(undefined8 *)(arg1 + 0x48);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df8a;
            fcn.180254e90(uVar4);
            uVar4 = *(undefined8 *)(arg1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df93;
            fcn.180254e90(uVar4);
            uVar4 = *(undefined8 *)(arg1 + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025df9c;
            fcn.180254e90(uVar4);
            uVar4 = *(undefined8 *)(arg1 + 0x60);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dfa5;
            fcn.180254e90(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dfb1;
            fcn.1802b2800(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000048 + iVar5));
            uVar4 = *(undefined8 *)(arg1 + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dfc4;
            fcn.180222290(uVar4, 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dfd3;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000050 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dfdb;
            fcn.1802d3ad0(arg1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025dff0;
            fcn.180224990(arg1, 0x1804e6980, 0xbe);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18025e0a0
// Address: 0x18025e0a0
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18025e0a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    uint32_t uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 *puVar8;
    uint64_t uVar9;
    undefined8 *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025e0b9;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar4 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e0d1;
    iVar1 = fcn.180222010(uVar4);
    uVar6 = 0;
    iVar7 = 0;
    if (0 < iVar1) {
        iVar7 = iVar1;
    }
    if (iVar7 == 0) {
        uVar4 = 0;
    } else {
        if (((in_RDX != 0) || (in_R8 != (undefined8 *)0x0)) && (0 < iVar7)) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            if (in_RDX == 0) {
                uVar9 = uVar6;
                if (0 < (int64_t)iVar7) {
                    do {
                        uVar4 = *(undefined8 *)(in_RCX + 0x88);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e15e;
                        iVar3 = func_0x000180222340(uVar4, uVar6);
                        if (in_R8 != (undefined8 *)0x0) {
                            in_R8[uVar9] = *(undefined8 *)(iVar3 + 0x10);
                        }
                        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
                        uVar9 = uVar9 + 1;
                    } while ((int64_t)uVar9 < (int64_t)iVar7);
                }
            } else {
                puVar8 = in_R8;
                do {
                    uVar4 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e11e;
                    iVar3 = func_0x000180222340(uVar4, uVar6);
                    *(undefined8 *)((int64_t)puVar8 + (in_RDX - (int64_t)in_R8)) = *(undefined8 *)(iVar3 + 8);
                    if (in_R8 != (undefined8 *)0x0) {
                        *puVar8 = *(undefined8 *)(iVar3 + 0x10);
                    }
                    uVar5 = (int32_t)uVar6 + 1;
                    uVar6 = (uint64_t)uVar5;
                    puVar8 = puVar8 + 1;
                } while ((int32_t)uVar5 < iVar7);
            }
        }
        uVar4 = 1;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_18025e0fb
// Address: 0x18025e0fb
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18025e0a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    uint32_t uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 *puVar8;
    uint64_t uVar9;
    undefined8 *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025e0b9;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar4 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e0d1;
    iVar1 = fcn.180222010(uVar4);
    uVar6 = 0;
    iVar7 = 0;
    if (0 < iVar1) {
        iVar7 = iVar1;
    }
    if (iVar7 == 0) {
        uVar4 = 0;
    } else {
        if (((in_RDX != 0) || (in_R8 != (undefined8 *)0x0)) && (0 < iVar7)) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            if (in_RDX == 0) {
                uVar9 = uVar6;
                if (0 < (int64_t)iVar7) {
                    do {
                        uVar4 = *(undefined8 *)(in_RCX + 0x88);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e15e;
                        iVar3 = func_0x000180222340(uVar4, uVar6);
                        if (in_R8 != (undefined8 *)0x0) {
                            in_R8[uVar9] = *(undefined8 *)(iVar3 + 0x10);
                        }
                        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
                        uVar9 = uVar9 + 1;
                    } while ((int64_t)uVar9 < (int64_t)iVar7);
                }
            } else {
                puVar8 = in_R8;
                do {
                    uVar4 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e11e;
                    iVar3 = func_0x000180222340(uVar4, uVar6);
                    *(undefined8 *)((int64_t)puVar8 + (in_RDX - (int64_t)in_R8)) = *(undefined8 *)(iVar3 + 8);
                    if (in_R8 != (undefined8 *)0x0) {
                        *puVar8 = *(undefined8 *)(iVar3 + 0x10);
                    }
                    uVar5 = (int32_t)uVar6 + 1;
                    uVar6 = (uint64_t)uVar5;
                    puVar8 = puVar8 + 1;
                } while ((int32_t)uVar5 < iVar7);
            }
        }
        uVar4 = 1;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_18025e17a
// Address: 0x18025e17a
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18025e0a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    uint32_t uVar5;
    uint64_t uVar6;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 *puVar8;
    uint64_t uVar9;
    undefined8 *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025e0b9;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar4 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e0d1;
    iVar1 = fcn.180222010(uVar4);
    uVar6 = 0;
    iVar7 = 0;
    if (0 < iVar1) {
        iVar7 = iVar1;
    }
    if (iVar7 == 0) {
        uVar4 = 0;
    } else {
        if (((in_RDX != 0) || (in_R8 != (undefined8 *)0x0)) && (0 < iVar7)) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            if (in_RDX == 0) {
                uVar9 = uVar6;
                if (0 < (int64_t)iVar7) {
                    do {
                        uVar4 = *(undefined8 *)(in_RCX + 0x88);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e15e;
                        iVar3 = func_0x000180222340(uVar4, uVar6);
                        if (in_R8 != (undefined8 *)0x0) {
                            in_R8[uVar9] = *(undefined8 *)(iVar3 + 0x10);
                        }
                        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
                        uVar9 = uVar9 + 1;
                    } while ((int64_t)uVar9 < (int64_t)iVar7);
                }
            } else {
                puVar8 = in_R8;
                do {
                    uVar4 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18025e11e;
                    iVar3 = func_0x000180222340(uVar4, uVar6);
                    *(undefined8 *)((int64_t)puVar8 + (in_RDX - (int64_t)in_R8)) = *(undefined8 *)(iVar3 + 8);
                    if (in_R8 != (undefined8 *)0x0) {
                        *puVar8 = *(undefined8 *)(iVar3 + 0x10);
                    }
                    uVar5 = (int32_t)uVar6 + 1;
                    uVar6 = (uint64_t)uVar5;
                    puVar8 = puVar8 + 1;
                } while ((int32_t)uVar5 < iVar7);
            }
        }
        uVar4 = 1;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_18025e1a0
// Address: 0x18025e1a0
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18025e1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025e1b6;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025e1cb;
    iVar2 = fcn.180222010(uVar1);
    uVar6 = 0;
    iVar5 = 0;
    if (0 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        if (0 < iVar5) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            uVar7 = uVar6;
            do {
                uVar1 = *(undefined8 *)(in_RCX + 0x88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025e20e;
                puVar4 = (undefined8 *)fcn.180222340(uVar1, uVar7);
                uVar7 = (uint64_t)((int32_t)uVar7 + 1);
                *(undefined8 *)(in_RDX + uVar6 * 8) = *puVar4;
                uVar6 = uVar6 + 1;
            } while ((int64_t)uVar6 < (int64_t)iVar5);
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025e1f7
// Address: 0x18025e1f7
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18025e1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025e1b6;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025e1cb;
    iVar2 = fcn.180222010(uVar1);
    uVar6 = 0;
    iVar5 = 0;
    if (0 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        if (0 < iVar5) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            uVar7 = uVar6;
            do {
                uVar1 = *(undefined8 *)(in_RCX + 0x88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025e20e;
                puVar4 = (undefined8 *)fcn.180222340(uVar1, uVar7);
                uVar7 = (uint64_t)((int32_t)uVar7 + 1);
                *(undefined8 *)(in_RDX + uVar6 * 8) = *puVar4;
                uVar6 = uVar6 + 1;
            } while ((int64_t)uVar6 < (int64_t)iVar5);
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025e224
// Address: 0x18025e224
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18025e1a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025e1b6;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(in_RCX + 0x88);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025e1cb;
    iVar2 = fcn.180222010(uVar1);
    uVar6 = 0;
    iVar5 = 0;
    if (0 < iVar2) {
        iVar5 = iVar2;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
        if (0 < iVar5) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            uVar7 = uVar6;
            do {
                uVar1 = *(undefined8 *)(in_RCX + 0x88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025e20e;
                puVar4 = (undefined8 *)fcn.180222340(uVar1, uVar7);
                uVar7 = (uint64_t)((int32_t)uVar7 + 1);
                *(undefined8 *)(in_RDX + uVar6 * 8) = *puVar4;
                uVar6 = uVar6 + 1;
            } while ((int64_t)uVar6 < (int64_t)iVar5);
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025e250
// Address: 0x18025e250
// Size: 29 bytes
// ============================================================
undefined8 fcn.18025e250(int64_t arg_30h, int64_t arg_50h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX = in_RCX + 0x90;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1802241e0;
    iVar3 = fcn.18045a350();
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + (iVar4 - iVar3)) = 0x1802241f6;
        iVar2 = fcn.180222010();
        if (in_EDX < iVar2) {
            piVar1 = *(int32_t **)(in_RCX + 8);
            if (((piVar1 != (int32_t *)0x0) && (-1 < in_EDX)) && (in_EDX < *piVar1)) {
                return *(undefined8 *)(*(int64_t *)(piVar1 + 2) + (int64_t)in_EDX * 8);
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18025e270
// Address: 0x18025e270
// Size: 39 bytes
// ============================================================
int32_t fcn.18025e270(int64_t param_1)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025e27a;
    iVar4 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 0x88);
    *(undefined8 *)((int64_t)&uStack_8 - iVar4) = 0x18025e289;
    iVar2 = fcn.180222010(uVar1);
    iVar3 = 0;
    if (0 < iVar2) {
        iVar3 = iVar2;
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18025e2a0
// Address: 0x18025e2a0
// Size: 26 bytes
// ============================================================
int64_t fcn.18025e2a0(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar9;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18025ef55;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef75;
    iVar6 = func_0x000180224d60(0xd8, 0x1804e6980, 0x4e);
    if (iVar6 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef86;
    iVar7 = func_0x000180222800();
    *(int64_t *)(iVar6 + 200) = iVar7;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef97;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efaf;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efc1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
        uVar9 = 0x56;
        goto code_r0x00018025f123;
    }
    *(undefined4 *)(iVar6 + 0xa0) = 1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efdb;
    iVar7 = func_0x0001802d3ab0();
    *(int64_t *)(iVar6 + 0xc0) = iVar7;
    if (iVar7 != 0) {
        *(undefined8 *)(iVar6 + 8) = uVar9;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025eff0;
        iVar7 = func_0x0001802d36c0();
        *(int64_t *)(iVar6 + 0x18) = iVar7;
        *(uint32_t *)(iVar6 + 0xa4) = *(uint32_t *)(iVar7 + 0x48) & 0xfffffbff;
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f14f;
            iVar8 = func_0x0001802d3c40();
            *(int64_t *)(iVar6 + 0x20) = iVar8;
            if (iVar8 != 0) goto code_r0x00018025f15b;
code_r0x00018025f182:
            *(uint32_t *)(iVar6 + 0xa4) = *(uint32_t *)(*(int64_t *)(iVar6 + 0x18) + 0x48) & 0xfffffbff;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1a7;
            iVar3 = func_0x000180224430(9, iVar6, iVar6 + 0x90);
            if (iVar3 == 0) goto code_r0x00018025f049;
            pcVar2 = *(code **)(*(int64_t *)(iVar6 + 0x18) + 0x38);
            if (pcVar2 == (code *)0x0) {
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1c1;
            iVar3 = (*pcVar2)(iVar6);
            if (iVar3 != 0) {
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1ca;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1e2;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f012;
            iVar3 = func_0x00018026b010(iVar8);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f01f;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            } else {
                *(int64_t *)(iVar6 + 0x20) = iVar8;
code_r0x00018025f15b:
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + 0x20 + -0x20) = 0x18025f163;
                iVar8 = func_0x0001801dd6c0(iVar8);
                *(int64_t *)(iVar6 + 0x18) = iVar8;
                if (iVar8 != 0) goto code_r0x00018025f182;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + 0x20 + -0x20) = 0x18025f171;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f037;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f049;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
    }
code_r0x00018025f049:
    LOCK();
    piVar1 = (int32_t *)(iVar6 + 0xa0);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (1 < iVar3) {
        return 0;
    }
    if ((*(int64_t *)(iVar6 + 0x18) != 0) &&
       (pcVar2 = *(code **)(*(int64_t *)(iVar6 + 0x18) + 0x40), pcVar2 != (code *)0x0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f076;
        (*pcVar2)(iVar6);
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f07f;
    fcn.18026aee0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f093;
    fcn.180223fb0(*(int64_t *)(&stack0x000000c0 + iVar5 + iVar4), *(int64_t *)(&stack0x00000128 + iVar5 + iVar4));
    uVar9 = *(undefined8 *)(iVar6 + 200);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f09f;
    fcn.1802227d0(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x28);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0a8;
    fcn.180255290(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0b1;
    fcn.180255290(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x38);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0ba;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x40);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0c3;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x48);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0cc;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x50);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0d5;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0de;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x60);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0e7;
    fcn.180254e90(uVar9);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0f3;
    fcn.1802b2800(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
    uVar9 = *(undefined8 *)(iVar6 + 0x88);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f106;
    fcn.180222290(uVar9, 0x180196ec0);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f115;
    fcn.180222050(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f11d;
    fcn.1802d3ad0(iVar6);
    uVar9 = 0xbe;
code_r0x00018025f123:
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f132;
    fcn.180224990(iVar6, 0x1804e6980, uVar9);
    return 0;
}

// ============================================================
// Function: FUN_18025e2c0
// Address: 0x18025e2c0
// Size: 24 bytes
// ============================================================
int64_t fcn.18025e2c0(int64_t param_1)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar8;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18025ef55;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef75;
    iVar6 = func_0x000180224d60(0xd8, 0x1804e6980, 0x4e);
    if (iVar6 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef86;
    iVar7 = func_0x000180222800();
    *(int64_t *)(iVar6 + 200) = iVar7;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef97;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efaf;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efc1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
        uVar8 = 0x56;
        goto code_r0x00018025f123;
    }
    *(undefined4 *)(iVar6 + 0xa0) = 1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efdb;
    iVar7 = func_0x0001802d3ab0();
    *(int64_t *)(iVar6 + 0xc0) = iVar7;
    if (iVar7 != 0) {
        *(undefined8 *)(iVar6 + 8) = uVar8;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025eff0;
        iVar7 = func_0x0001802d36c0();
        *(int64_t *)(iVar6 + 0x18) = iVar7;
        *(uint32_t *)(iVar6 + 0xa4) = *(uint32_t *)(iVar7 + 0x48) & 0xfffffbff;
        if (param_1 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f14f;
            param_1 = func_0x0001802d3c40();
            *(int64_t *)(iVar6 + 0x20) = param_1;
            if (param_1 != 0) goto code_r0x00018025f15b;
code_r0x00018025f182:
            *(uint32_t *)(iVar6 + 0xa4) = *(uint32_t *)(*(int64_t *)(iVar6 + 0x18) + 0x48) & 0xfffffbff;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1a7;
            iVar3 = func_0x000180224430(9, iVar6, iVar6 + 0x90);
            if (iVar3 == 0) goto code_r0x00018025f049;
            pcVar2 = *(code **)(*(int64_t *)(iVar6 + 0x18) + 0x38);
            if (pcVar2 == (code *)0x0) {
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1c1;
            iVar3 = (*pcVar2)(iVar6);
            if (iVar3 != 0) {
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1ca;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1e2;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), *(int64_t *)(&stack0x00000070 + iVar5 + iVar4)
                         );
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f012;
            iVar3 = func_0x00018026b010(param_1);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f01f;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            } else {
                *(int64_t *)(iVar6 + 0x20) = param_1;
code_r0x00018025f15b:
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + 0x20 + -0x20) = 0x18025f163;
                iVar7 = func_0x0001801dd6c0(param_1);
                *(int64_t *)(iVar6 + 0x18) = iVar7;
                if (iVar7 != 0) goto code_r0x00018025f182;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + 0x20 + -0x20) = 0x18025f171;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f037;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), *(int64_t *)(&stack0x00000070 + iVar5 + iVar4)
                         );
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f049;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
    }
code_r0x00018025f049:
    LOCK();
    piVar1 = (int32_t *)(iVar6 + 0xa0);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (1 < iVar3) {
        return 0;
    }
    if ((*(int64_t *)(iVar6 + 0x18) != 0) &&
       (pcVar2 = *(code **)(*(int64_t *)(iVar6 + 0x18) + 0x40), pcVar2 != (code *)0x0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f076;
        (*pcVar2)(iVar6);
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f07f;
    fcn.18026aee0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f093;
    fcn.180223fb0(*(int64_t *)(&stack0x000000c0 + iVar5 + iVar4), *(int64_t *)(&stack0x00000128 + iVar5 + iVar4));
    uVar8 = *(undefined8 *)(iVar6 + 200);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f09f;
    fcn.1802227d0(uVar8);
    uVar8 = *(undefined8 *)(iVar6 + 0x28);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0a8;
    fcn.180255290(uVar8);
    uVar8 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0b1;
    fcn.180255290(uVar8);
    uVar8 = *(undefined8 *)(iVar6 + 0x38);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0ba;
    fcn.180254e90(uVar8);
    uVar8 = *(undefined8 *)(iVar6 + 0x40);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0c3;
    fcn.180254e90(uVar8);
    uVar8 = *(undefined8 *)(iVar6 + 0x48);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0cc;
    fcn.180254e90(uVar8);
    uVar8 = *(undefined8 *)(iVar6 + 0x50);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0d5;
    fcn.180254e90(uVar8);
    uVar8 = *(undefined8 *)(iVar6 + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0de;
    fcn.180254e90(uVar8);
    uVar8 = *(undefined8 *)(iVar6 + 0x60);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0e7;
    fcn.180254e90(uVar8);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0f3;
    fcn.1802b2800(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
    uVar8 = *(undefined8 *)(iVar6 + 0x88);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f106;
    fcn.180222290(uVar8, 0x180196ec0);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f115;
    fcn.180222050(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f11d;
    fcn.1802d3ad0(iVar6);
    uVar8 = 0xbe;
code_r0x00018025f123:
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f132;
    fcn.180224990(iVar6, 0x1804e6980, uVar8);
    return 0;
}

// ============================================================
// Function: FUN_18025e2e0
// Address: 0x18025e2e0
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined2 fcn.18025e2e0(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined2 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025e2f0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025e2ff;
    uVar3 = func_0x000180255500(uVar1);
    if (*(int32_t *)(in_RCX + 0x10) == 1) {
        uVar1 = *(undefined8 *)(in_RCX + 0x88);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025e313;
        iVar4 = fcn.180222010(uVar1);
        if (0 < iVar4) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025e320;
            iVar5 = func_0x0001802d3e20(uVar3);
            if (iVar4 + 2 <= iVar5) goto code_r0x00018025e334;
        }
        return 0;
    }
code_r0x00018025e334:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025e33b;
    uVar2 = func_0x00018025e5e0(uVar3);
    return uVar2;
}

// ============================================================
// Function: FUN_18025e350
// Address: 0x18025e350
// Size: 204 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18025e350(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025e36a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((((*(int64_t *)(in_RCX + 0x50) == 0) && (in_RDX == 0)) || ((*(int64_t *)(in_RCX + 0x58) == 0 && (in_R8 == 0))))
       || ((*(int64_t *)(in_RCX + 0x60) == 0 && (in_R9 == 0)))) {
        uVar2 = 0;
    } else {
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e3ad;
            fcn.180254e90();
            *(int64_t *)(in_RCX + 0x50) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e3be;
            func_0x000180255830(in_RDX, 4);
        }
        if (in_R8 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e3cc;
            fcn.180254e90(uVar2);
            *(int64_t *)(in_RCX + 0x58) = in_R8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e3dd;
            func_0x000180255830(in_R8, 4);
        }
        if (in_R9 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x60);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e3eb;
            fcn.180254e90(uVar2);
            *(int64_t *)(in_RCX + 0x60) = in_R9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e3fc;
            func_0x000180255830(in_R9, 4);
        }
        *(int32_t *)(in_RCX + 0xd0) = *(int32_t *)(in_RCX + 0xd0) + 1;
        uVar2 = 1;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_18025e420
// Address: 0x18025e420
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18025e420(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025e435;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((*(int64_t *)(in_RCX + 0x40) != 0) || (in_RDX != 0)) && ((*(int64_t *)(in_RCX + 0x48) != 0 || (in_R8 != 0)))) {
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025e477;
            fcn.180254e90();
            *(int64_t *)(in_RCX + 0x40) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025e488;
            func_0x000180255830(in_RDX, 4);
        }
        if (in_R8 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025e496;
            fcn.180254e90(uVar1);
            *(int64_t *)(in_RCX + 0x48) = in_R8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025e4a7;
            func_0x000180255830(in_R8, 4);
        }
        *(int32_t *)(in_RCX + 0xd0) = *(int32_t *)(in_RCX + 0xd0) + 1;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025e4d0
// Address: 0x18025e4d0
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18025e4d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025e4ea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (((*(int64_t *)(in_RCX + 0x28) == 0) && (in_RDX == 0)) || ((*(int64_t *)(in_RCX + 0x30) == 0 && (in_R8 == 0)))) {
        uVar2 = 0;
    } else {
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e521;
            fcn.180255290();
            *(int64_t *)(in_RCX + 0x28) = in_RDX;
        }
        if (in_R8 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e533;
            fcn.180255290(uVar2);
            *(int64_t *)(in_RCX + 0x30) = in_R8;
        }
        if (in_R9 != 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x38);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e545;
            fcn.180254e90(uVar2);
            *(int64_t *)(in_RCX + 0x38) = in_R9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025e556;
            func_0x000180255830(in_R9, 4);
        }
        *(int32_t *)(in_RCX + 0xd0) = *(int32_t *)(in_RCX + 0xd0) + 1;
        uVar2 = 1;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_18025e580
// Address: 0x18025e580
// Size: 29 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling

bool fcn.18025e580(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 auStackX_18 [2];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    in_RCX = in_RCX + 0x90;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6) = 0x180224465;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *(int64_t *)(in_RCX + 8);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18022447e;
        iVar5 = fcn.180221f20();
        *(int64_t *)(in_RCX + 8) = iVar5;
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18022448c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar4 + iVar6));
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x1802244a4;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar4 + iVar6), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar6), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar6), 
                          *(int64_t *)(&stack0x00000070 + iVar4 + iVar6));
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x1802244b6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar6));
            return false;
        }
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x1802244d5;
    iVar2 = fcn.180222010(iVar5);
    while( true ) {
        if (in_EDX < iVar2) {
            uVar1 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224503;
            iVar5 = fcn.1802221b0(uVar1, in_EDX, in_R8);
            if (iVar5 != in_R8) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18022450d;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar6));
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224525;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar6), 
                              *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar6));
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224537;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar6));
            }
            return iVar5 == in_R8;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x1802244eb;
        iVar3 = fcn.180222110(*(int64_t *)((int64_t)&arg_50h + iVar4 + iVar6), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000068 + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar6), 
                              *(int64_t *)(&stack0x00000078 + iVar4 + iVar6));
        if (iVar3 == 0) break;
        iVar2 = iVar2 + 1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224540;
    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), *(int64_t *)(&stack0x00000048 + iVar4 + iVar6));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x180224558;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar6), *(int64_t *)(&stack0x00000048 + iVar4 + iVar6), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar6), 
                  *(int64_t *)(&stack0x00000070 + iVar4 + iVar6));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar6) = 0x18022456a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar6));
    return false;
}

// ============================================================
// Function: FUN_18025e5e0
// Address: 0x18025e5e0
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint16_t fcn.18025e5e0(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint16_t uVar4;
    uint64_t uVar5;
    uint16_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    int64_t var_8h;
    
    iVar2 = (int32_t)arg1;
    if (iVar2 < 0x1801) {
        if (iVar2 == 0x1800) {
            return 0xb0;
        }
        if (iVar2 == 0x800) {
            return 0x70;
        }
        if (iVar2 == 0xc00) {
            return 0x80;
        }
        if (iVar2 == 0x1000) {
            return 0x98;
        }
        if (iVar2 < 8) {
            return 0;
        }
    } else {
        if (iVar2 == 0x1e00) {
            return 0xc0;
        }
        if (iVar2 == 0x2000) {
            return 200;
        }
        if (iVar2 == 0x3c00) {
            return 0x100;
        }
        if (0xa7e78 < iVar2) {
            return 0x4b0;
        }
        if (0x1e00 < iVar2) {
            uVar6 = 0x100;
            if (0x3c00 < iVar2) {
                uVar6 = 0x4b0;
            }
            goto code_r0x00018025e682;
        }
    }
    uVar6 = 0xc0;
code_r0x00018025e682:
    uVar7 = 0;
    uVar8 = uVar7;
    for (uVar5 = (int64_t)iVar2 * 0x2c5c8; 0x7ffff < uVar5; uVar5 = uVar5 >> 1) {
        uVar8 = (uint64_t)((int32_t)uVar8 + 0x40000);
    }
    uVar10 = 0x20000;
    do {
        uVar1 = uVar5 * uVar5 >> 0x12;
        uVar9 = (uint64_t)((int32_t)uVar8 + uVar10);
        if (uVar1 < 0x80000) {
            uVar9 = uVar8;
        }
        uVar5 = uVar5 * uVar5 >> 0x13;
        if (uVar1 < 0x80000) {
            uVar5 = uVar1;
        }
        uVar10 = uVar10 >> 1;
        uVar8 = uVar9;
    } while (uVar10 != 0);
    iVar3 = 0x3f;
    uVar5 = (uVar9 << 0x12) / 0x5c551;
    uVar5 = (uVar5 * (int64_t)iVar2 * 0x2c5c8 >> 0x12) * uVar5 >> 0x12;
    do {
        uVar9 = uVar7 * 2;
        uVar1 = uVar5 >> ((uint8_t)iVar3 & 0x3f);
        uVar8 = (uVar9 + 1) * uVar7 * 6 + 1;
        if (uVar8 <= uVar1) {
            uVar5 = uVar5 - (uVar8 << ((uint8_t)iVar3 & 0x3f));
        }
        uVar7 = uVar9 + 1;
        if (uVar1 < uVar8) {
            uVar7 = uVar9;
        }
        iVar3 = iVar3 + -3;
    } while (-1 < iVar3);
    uVar4 = (int16_t)(((uVar7 * 0x7b126000 >> 0x12) - 0x12c28f) / 0x2c5c8) + 4U & 0xfff8;
    if (uVar4 <= uVar6) {
        uVar6 = uVar4;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18025e68f
// Address: 0x18025e68f
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint16_t fcn.18025e5e0(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint16_t uVar4;
    uint64_t uVar5;
    uint16_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    int64_t var_8h;
    
    iVar2 = (int32_t)arg1;
    if (iVar2 < 0x1801) {
        if (iVar2 == 0x1800) {
            return 0xb0;
        }
        if (iVar2 == 0x800) {
            return 0x70;
        }
        if (iVar2 == 0xc00) {
            return 0x80;
        }
        if (iVar2 == 0x1000) {
            return 0x98;
        }
        if (iVar2 < 8) {
            return 0;
        }
    } else {
        if (iVar2 == 0x1e00) {
            return 0xc0;
        }
        if (iVar2 == 0x2000) {
            return 200;
        }
        if (iVar2 == 0x3c00) {
            return 0x100;
        }
        if (0xa7e78 < iVar2) {
            return 0x4b0;
        }
        if (0x1e00 < iVar2) {
            uVar6 = 0x100;
            if (0x3c00 < iVar2) {
                uVar6 = 0x4b0;
            }
            goto code_r0x00018025e682;
        }
    }
    uVar6 = 0xc0;
code_r0x00018025e682:
    uVar7 = 0;
    uVar8 = uVar7;
    for (uVar5 = (int64_t)iVar2 * 0x2c5c8; 0x7ffff < uVar5; uVar5 = uVar5 >> 1) {
        uVar8 = (uint64_t)((int32_t)uVar8 + 0x40000);
    }
    uVar10 = 0x20000;
    do {
        uVar1 = uVar5 * uVar5 >> 0x12;
        uVar9 = (uint64_t)((int32_t)uVar8 + uVar10);
        if (uVar1 < 0x80000) {
            uVar9 = uVar8;
        }
        uVar5 = uVar5 * uVar5 >> 0x13;
        if (uVar1 < 0x80000) {
            uVar5 = uVar1;
        }
        uVar10 = uVar10 >> 1;
        uVar8 = uVar9;
    } while (uVar10 != 0);
    iVar3 = 0x3f;
    uVar5 = (uVar9 << 0x12) / 0x5c551;
    uVar5 = (uVar5 * (int64_t)iVar2 * 0x2c5c8 >> 0x12) * uVar5 >> 0x12;
    do {
        uVar9 = uVar7 * 2;
        uVar1 = uVar5 >> ((uint8_t)iVar3 & 0x3f);
        uVar8 = (uVar9 + 1) * uVar7 * 6 + 1;
        if (uVar8 <= uVar1) {
            uVar5 = uVar5 - (uVar8 << ((uint8_t)iVar3 & 0x3f));
        }
        uVar7 = uVar9 + 1;
        if (uVar1 < uVar8) {
            uVar7 = uVar9;
        }
        iVar3 = iVar3 + -3;
    } while (-1 < iVar3);
    uVar4 = (int16_t)(((uVar7 * 0x7b126000 >> 0x12) - 0x12c28f) / 0x2c5c8) + 4U & 0xfff8;
    if (uVar4 <= uVar6) {
        uVar6 = uVar4;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18025e79e
// Address: 0x18025e79e
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint16_t fcn.18025e5e0(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint16_t uVar4;
    uint64_t uVar5;
    uint16_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    int64_t var_8h;
    
    iVar2 = (int32_t)arg1;
    if (iVar2 < 0x1801) {
        if (iVar2 == 0x1800) {
            return 0xb0;
        }
        if (iVar2 == 0x800) {
            return 0x70;
        }
        if (iVar2 == 0xc00) {
            return 0x80;
        }
        if (iVar2 == 0x1000) {
            return 0x98;
        }
        if (iVar2 < 8) {
            return 0;
        }
    } else {
        if (iVar2 == 0x1e00) {
            return 0xc0;
        }
        if (iVar2 == 0x2000) {
            return 200;
        }
        if (iVar2 == 0x3c00) {
            return 0x100;
        }
        if (0xa7e78 < iVar2) {
            return 0x4b0;
        }
        if (0x1e00 < iVar2) {
            uVar6 = 0x100;
            if (0x3c00 < iVar2) {
                uVar6 = 0x4b0;
            }
            goto code_r0x00018025e682;
        }
    }
    uVar6 = 0xc0;
code_r0x00018025e682:
    uVar7 = 0;
    uVar8 = uVar7;
    for (uVar5 = (int64_t)iVar2 * 0x2c5c8; 0x7ffff < uVar5; uVar5 = uVar5 >> 1) {
        uVar8 = (uint64_t)((int32_t)uVar8 + 0x40000);
    }
    uVar10 = 0x20000;
    do {
        uVar1 = uVar5 * uVar5 >> 0x12;
        uVar9 = (uint64_t)((int32_t)uVar8 + uVar10);
        if (uVar1 < 0x80000) {
            uVar9 = uVar8;
        }
        uVar5 = uVar5 * uVar5 >> 0x13;
        if (uVar1 < 0x80000) {
            uVar5 = uVar1;
        }
        uVar10 = uVar10 >> 1;
        uVar8 = uVar9;
    } while (uVar10 != 0);
    iVar3 = 0x3f;
    uVar5 = (uVar9 << 0x12) / 0x5c551;
    uVar5 = (uVar5 * (int64_t)iVar2 * 0x2c5c8 >> 0x12) * uVar5 >> 0x12;
    do {
        uVar9 = uVar7 * 2;
        uVar1 = uVar5 >> ((uint8_t)iVar3 & 0x3f);
        uVar8 = (uVar9 + 1) * uVar7 * 6 + 1;
        if (uVar8 <= uVar1) {
            uVar5 = uVar5 - (uVar8 << ((uint8_t)iVar3 & 0x3f));
        }
        uVar7 = uVar9 + 1;
        if (uVar1 < uVar8) {
            uVar7 = uVar9;
        }
        iVar3 = iVar3 + -3;
    } while (-1 < iVar3);
    uVar4 = (int16_t)(((uVar7 * 0x7b126000 >> 0x12) - 0x12c28f) / 0x2c5c8) + 4U & 0xfff8;
    if (uVar4 <= uVar6) {
        uVar6 = uVar4;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18025e7c0
// Address: 0x18025e7c0
// Size: 77 bytes
// ============================================================
undefined4 fcn.18025e7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined8 unaff_R12;
    int32_t iVar11;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_30;
    
    uStack_30 = 0x18025e7d2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7df;
    iVar4 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7e7;
    iVar5 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7ef;
    iVar6 = fcn.180221f20();
    uVar10 = 0;
    if (((iVar4 != 0) && (uVar10 = uVar9, iVar5 != 0)) && (iVar6 != 0)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        if ((in_RCX != 0) && (*(int64_t *)(in_RCX + 0x40) != 0)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e83a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e846;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e852;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e85e;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e86a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            uVar8 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e876;
            iVar1 = fcn.180222010(uVar8);
            iVar11 = 0;
            iVar2 = 0;
            if (0 < iVar1) {
                iVar2 = iVar1;
            }
            if (0 < iVar2) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e89f;
                    fcn.180222340(uVar8, iVar11);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8ad;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8b9;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8c5;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar2);
            }
        }
        if (*(int64_t *)(in_RCX + 0x28) == 0) {
            iVar2 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8e5;
            iVar2 = func_0x000180255500();
        }
        if (*(int64_t *)(in_RCX + 0x38) == 0) {
            iVar1 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8fa;
            iVar1 = func_0x000180255500();
        }
        uVar10 = 0;
        if (iVar1 <= iVar2) {
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e90d;
            iVar1 = fcn.180222010(iVar5);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e91b;
                    iVar7 = fcn.180222340(iVar5, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e92e;
                        uVar8 = fcn.180222340(iVar5, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e936;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e949;
                    iVar1 = fcn.180222010(iVar5);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e957;
            iVar1 = fcn.180222010(iVar4);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e96a;
                    iVar7 = fcn.180222340(iVar4, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e97d;
                        uVar8 = fcn.180222340(iVar4, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e985;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e994;
                    iVar1 = fcn.180222010(iVar4);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9a2;
            iVar1 = fcn.180222010(iVar6);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9b0;
                    iVar7 = fcn.180222340(iVar6, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9c3;
                        uVar8 = fcn.180222340(iVar6, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9cb;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9da;
                    iVar1 = fcn.180222010(iVar6);
                } while (iVar11 < iVar1);
            }
            uVar10 = 1;
        }
    }
code_r0x00018025e9ed:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9f5;
    func_0x000180221d50(iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9fd;
    func_0x000180221d50(iVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025ea05;
    func_0x000180221d50(iVar6);
    return uVar10;
}

// ============================================================
// Function: FUN_18025e80d
// Address: 0x18025e80d
// Size: 35 bytes
// ============================================================
undefined4 fcn.18025e7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined8 unaff_R12;
    int32_t iVar11;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_30;
    
    uStack_30 = 0x18025e7d2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7df;
    iVar4 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7e7;
    iVar5 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7ef;
    iVar6 = fcn.180221f20();
    uVar10 = 0;
    if (((iVar4 != 0) && (uVar10 = uVar9, iVar5 != 0)) && (iVar6 != 0)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        if ((in_RCX != 0) && (*(int64_t *)(in_RCX + 0x40) != 0)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e83a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e846;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e852;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e85e;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e86a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            uVar8 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e876;
            iVar1 = fcn.180222010(uVar8);
            iVar11 = 0;
            iVar2 = 0;
            if (0 < iVar1) {
                iVar2 = iVar1;
            }
            if (0 < iVar2) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e89f;
                    fcn.180222340(uVar8, iVar11);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8ad;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8b9;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8c5;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar2);
            }
        }
        if (*(int64_t *)(in_RCX + 0x28) == 0) {
            iVar2 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8e5;
            iVar2 = func_0x000180255500();
        }
        if (*(int64_t *)(in_RCX + 0x38) == 0) {
            iVar1 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8fa;
            iVar1 = func_0x000180255500();
        }
        uVar10 = 0;
        if (iVar1 <= iVar2) {
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e90d;
            iVar1 = fcn.180222010(iVar5);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e91b;
                    iVar7 = fcn.180222340(iVar5, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e92e;
                        uVar8 = fcn.180222340(iVar5, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e936;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e949;
                    iVar1 = fcn.180222010(iVar5);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e957;
            iVar1 = fcn.180222010(iVar4);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e96a;
                    iVar7 = fcn.180222340(iVar4, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e97d;
                        uVar8 = fcn.180222340(iVar4, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e985;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e994;
                    iVar1 = fcn.180222010(iVar4);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9a2;
            iVar1 = fcn.180222010(iVar6);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9b0;
                    iVar7 = fcn.180222340(iVar6, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9c3;
                        uVar8 = fcn.180222340(iVar6, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9cb;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9da;
                    iVar1 = fcn.180222010(iVar6);
                } while (iVar11 < iVar1);
            }
            uVar10 = 1;
        }
    }
code_r0x00018025e9ed:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9f5;
    func_0x000180221d50(iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9fd;
    func_0x000180221d50(iVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025ea05;
    func_0x000180221d50(iVar6);
    return uVar10;
}

// ============================================================
// Function: FUN_18025e830
// Address: 0x18025e830
// Size: 162 bytes
// ============================================================
undefined4 fcn.18025e7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined8 unaff_R12;
    int32_t iVar11;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_30;
    
    uStack_30 = 0x18025e7d2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7df;
    iVar4 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7e7;
    iVar5 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7ef;
    iVar6 = fcn.180221f20();
    uVar10 = 0;
    if (((iVar4 != 0) && (uVar10 = uVar9, iVar5 != 0)) && (iVar6 != 0)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        if ((in_RCX != 0) && (*(int64_t *)(in_RCX + 0x40) != 0)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e83a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e846;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e852;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e85e;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e86a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            uVar8 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e876;
            iVar1 = fcn.180222010(uVar8);
            iVar11 = 0;
            iVar2 = 0;
            if (0 < iVar1) {
                iVar2 = iVar1;
            }
            if (0 < iVar2) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e89f;
                    fcn.180222340(uVar8, iVar11);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8ad;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8b9;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8c5;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar2);
            }
        }
        if (*(int64_t *)(in_RCX + 0x28) == 0) {
            iVar2 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8e5;
            iVar2 = func_0x000180255500();
        }
        if (*(int64_t *)(in_RCX + 0x38) == 0) {
            iVar1 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8fa;
            iVar1 = func_0x000180255500();
        }
        uVar10 = 0;
        if (iVar1 <= iVar2) {
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e90d;
            iVar1 = fcn.180222010(iVar5);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e91b;
                    iVar7 = fcn.180222340(iVar5, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e92e;
                        uVar8 = fcn.180222340(iVar5, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e936;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e949;
                    iVar1 = fcn.180222010(iVar5);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e957;
            iVar1 = fcn.180222010(iVar4);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e96a;
                    iVar7 = fcn.180222340(iVar4, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e97d;
                        uVar8 = fcn.180222340(iVar4, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e985;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e994;
                    iVar1 = fcn.180222010(iVar4);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9a2;
            iVar1 = fcn.180222010(iVar6);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9b0;
                    iVar7 = fcn.180222340(iVar6, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9c3;
                        uVar8 = fcn.180222340(iVar6, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9cb;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9da;
                    iVar1 = fcn.180222010(iVar6);
                } while (iVar11 < iVar1);
            }
            uVar10 = 1;
        }
    }
code_r0x00018025e9ed:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9f5;
    func_0x000180221d50(iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9fd;
    func_0x000180221d50(iVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025ea05;
    func_0x000180221d50(iVar6);
    return uVar10;
}

// ============================================================
// Function: FUN_18025e8d2
// Address: 0x18025e8d2
// Size: 283 bytes
// ============================================================
undefined4 fcn.18025e7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined8 unaff_R12;
    int32_t iVar11;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_30;
    
    uStack_30 = 0x18025e7d2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7df;
    iVar4 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7e7;
    iVar5 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7ef;
    iVar6 = fcn.180221f20();
    uVar10 = 0;
    if (((iVar4 != 0) && (uVar10 = uVar9, iVar5 != 0)) && (iVar6 != 0)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        if ((in_RCX != 0) && (*(int64_t *)(in_RCX + 0x40) != 0)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e83a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e846;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e852;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e85e;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e86a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            uVar8 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e876;
            iVar1 = fcn.180222010(uVar8);
            iVar11 = 0;
            iVar2 = 0;
            if (0 < iVar1) {
                iVar2 = iVar1;
            }
            if (0 < iVar2) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e89f;
                    fcn.180222340(uVar8, iVar11);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8ad;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8b9;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8c5;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar2);
            }
        }
        if (*(int64_t *)(in_RCX + 0x28) == 0) {
            iVar2 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8e5;
            iVar2 = func_0x000180255500();
        }
        if (*(int64_t *)(in_RCX + 0x38) == 0) {
            iVar1 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8fa;
            iVar1 = func_0x000180255500();
        }
        uVar10 = 0;
        if (iVar1 <= iVar2) {
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e90d;
            iVar1 = fcn.180222010(iVar5);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e91b;
                    iVar7 = fcn.180222340(iVar5, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e92e;
                        uVar8 = fcn.180222340(iVar5, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e936;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e949;
                    iVar1 = fcn.180222010(iVar5);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e957;
            iVar1 = fcn.180222010(iVar4);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e96a;
                    iVar7 = fcn.180222340(iVar4, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e97d;
                        uVar8 = fcn.180222340(iVar4, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e985;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e994;
                    iVar1 = fcn.180222010(iVar4);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9a2;
            iVar1 = fcn.180222010(iVar6);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9b0;
                    iVar7 = fcn.180222340(iVar6, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9c3;
                        uVar8 = fcn.180222340(iVar6, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9cb;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9da;
                    iVar1 = fcn.180222010(iVar6);
                } while (iVar11 < iVar1);
            }
            uVar10 = 1;
        }
    }
code_r0x00018025e9ed:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9f5;
    func_0x000180221d50(iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9fd;
    func_0x000180221d50(iVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025ea05;
    func_0x000180221d50(iVar6);
    return uVar10;
}

// ============================================================
// Function: FUN_18025e9ed
// Address: 0x18025e9ed
// Size: 38 bytes
// ============================================================
undefined4 fcn.18025e7c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined8 unaff_R12;
    int32_t iVar11;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_30;
    
    uStack_30 = 0x18025e7d2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar9 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7df;
    iVar4 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7e7;
    iVar5 = fcn.180221f20();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e7ef;
    iVar6 = fcn.180221f20();
    uVar10 = 0;
    if (((iVar4 != 0) && (uVar10 = uVar9, iVar5 != 0)) && (iVar6 != 0)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R15;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        if ((in_RCX != 0) && (*(int64_t *)(in_RCX + 0x40) != 0)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e83a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e846;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e852;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e85e;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e86a;
            fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3));
            uVar8 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e876;
            iVar1 = fcn.180222010(uVar8);
            iVar11 = 0;
            iVar2 = 0;
            if (0 < iVar1) {
                iVar2 = iVar1;
            }
            if (0 < iVar2) {
                do {
                    uVar8 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e89f;
                    fcn.180222340(uVar8, iVar11);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8ad;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8b9;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8c5;
                    fcn.180222110(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
                    iVar11 = iVar11 + 1;
                } while (iVar11 < iVar2);
            }
        }
        if (*(int64_t *)(in_RCX + 0x28) == 0) {
            iVar2 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8e5;
            iVar2 = func_0x000180255500();
        }
        if (*(int64_t *)(in_RCX + 0x38) == 0) {
            iVar1 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e8fa;
            iVar1 = func_0x000180255500();
        }
        uVar10 = 0;
        if (iVar1 <= iVar2) {
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e90d;
            iVar1 = fcn.180222010(iVar5);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e91b;
                    iVar7 = fcn.180222340(iVar5, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e92e;
                        uVar8 = fcn.180222340(iVar5, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e936;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e949;
                    iVar1 = fcn.180222010(iVar5);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e957;
            iVar1 = fcn.180222010(iVar4);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e96a;
                    iVar7 = fcn.180222340(iVar4, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e97d;
                        uVar8 = fcn.180222340(iVar4, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e985;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e994;
                    iVar1 = fcn.180222010(iVar4);
                } while (iVar11 < iVar1);
            }
            iVar11 = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9a2;
            iVar1 = fcn.180222010(iVar6);
            if (0 < iVar1) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9b0;
                    iVar7 = fcn.180222340(iVar6, iVar11);
                    if (iVar7 == 0) {
                        iVar1 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9c3;
                        uVar8 = fcn.180222340(iVar6, iVar11);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9cb;
                        iVar1 = func_0x000180255500(uVar8);
                    }
                    uVar10 = uVar9;
                    if (iVar2 < iVar1) goto code_r0x00018025e9ed;
                    iVar11 = iVar11 + 1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9da;
                    iVar1 = fcn.180222010(iVar6);
                } while (iVar11 < iVar1);
            }
            uVar10 = 1;
        }
    }
code_r0x00018025e9ed:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9f5;
    func_0x000180221d50(iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025e9fd;
    func_0x000180221d50(iVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18025ea05;
    func_0x000180221d50(iVar6);
    return uVar10;
}

// ============================================================
// Function: FUN_18025ea20
// Address: 0x18025ea20
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18025ea20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int32_t iVar5;
    undefined8 unaff_R12;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025ea34;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea78;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea84;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea90;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea9c;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaa8;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            uVar1 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eab4;
            iVar2 = fcn.180222010(uVar1);
            iVar4 = 0;
            iVar5 = 0;
            if (0 < iVar2) {
                iVar5 = iVar2;
            }
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
                do {
                    uVar1 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eade;
                    fcn.180222340(uVar1, iVar4);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaec;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaf8;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eb04;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    iVar4 = iVar4 + 1;
                } while (iVar4 < iVar5);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025ea66
// Address: 0x18025ea66
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18025ea20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int32_t iVar5;
    undefined8 unaff_R12;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025ea34;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea78;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea84;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea90;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea9c;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaa8;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            uVar1 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eab4;
            iVar2 = fcn.180222010(uVar1);
            iVar4 = 0;
            iVar5 = 0;
            if (0 < iVar2) {
                iVar5 = iVar2;
            }
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
                do {
                    uVar1 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eade;
                    fcn.180222340(uVar1, iVar4);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaec;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaf8;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eb04;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    iVar4 = iVar4 + 1;
                } while (iVar4 < iVar5);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025eac4
// Address: 0x18025eac4
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18025ea20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int32_t iVar5;
    undefined8 unaff_R12;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025ea34;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea78;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea84;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea90;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea9c;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaa8;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            uVar1 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eab4;
            iVar2 = fcn.180222010(uVar1);
            iVar4 = 0;
            iVar5 = 0;
            if (0 < iVar2) {
                iVar5 = iVar2;
            }
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
                do {
                    uVar1 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eade;
                    fcn.180222340(uVar1, iVar4);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaec;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaf8;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eb04;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    iVar4 = iVar4 + 1;
                } while (iVar4 < iVar5);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025eb10
// Address: 0x18025eb10
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18025ea20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int32_t iVar5;
    undefined8 unaff_R12;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025ea34;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea78;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea84;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea90;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea9c;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaa8;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            uVar1 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eab4;
            iVar2 = fcn.180222010(uVar1);
            iVar4 = 0;
            iVar5 = 0;
            if (0 < iVar2) {
                iVar5 = iVar2;
            }
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
                do {
                    uVar1 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eade;
                    fcn.180222340(uVar1, iVar4);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaec;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaf8;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eb04;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    iVar4 = iVar4 + 1;
                } while (iVar4 < iVar5);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025eb1a
// Address: 0x18025eb1a
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.18025ea20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int32_t iVar5;
    undefined8 unaff_R12;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025ea34;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_R12;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea78;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea84;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea90;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025ea9c;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaa8;
            fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                          *(int64_t *)((int64_t)&arg_40h + iVar3));
            uVar1 = *(undefined8 *)(in_RCX + 0x88);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eab4;
            iVar2 = fcn.180222010(uVar1);
            iVar4 = 0;
            iVar5 = 0;
            if (0 < iVar2) {
                iVar5 = iVar2;
            }
            if (0 < iVar5) {
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
                do {
                    uVar1 = *(undefined8 *)(in_RCX + 0x88);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eade;
                    fcn.180222340(uVar1, iVar4);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaec;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eaf8;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18025eb04;
                    fcn.180222110(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar3));
                    iVar4 = iVar4 + 1;
                } while (iVar4 < iVar5);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025eb40
// Address: 0x18025eb40
// Size: 27 bytes
// ============================================================
int64_t fcn.18025eb40(undefined8 param_1)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar9;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar8 = 0;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18025ef55;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef75;
    iVar6 = fcn.180224d60(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000068 + iVar5 + iVar4)
                         );
    if (iVar6 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef86;
    iVar7 = func_0x000180222800();
    *(int64_t *)(iVar6 + 200) = iVar7;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef97;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efaf;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efc1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
        uVar9 = 0x56;
        goto code_r0x00018025f123;
    }
    *(undefined4 *)(iVar6 + 0xa0) = 1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efdb;
    iVar7 = func_0x0001802d3ab0();
    *(int64_t *)(iVar6 + 0xc0) = iVar7;
    if (iVar7 != 0) {
        *(undefined8 *)(iVar6 + 8) = param_1;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025eff0;
        iVar7 = func_0x0001802d36c0();
        *(int64_t *)(iVar6 + 0x18) = iVar7;
        *(uint32_t *)(iVar6 + 0xa4) = *(uint32_t *)(iVar7 + 0x48) & 0xfffffbff;
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f14f;
            iVar8 = func_0x0001802d3c40();
            *(int64_t *)(iVar6 + 0x20) = iVar8;
            if (iVar8 != 0) goto code_r0x00018025f15b;
code_r0x00018025f182:
            *(uint32_t *)(iVar6 + 0xa4) = *(uint32_t *)(*(int64_t *)(iVar6 + 0x18) + 0x48) & 0xfffffbff;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1a7;
            iVar3 = func_0x000180224430(9, iVar6, iVar6 + 0x90);
            if (iVar3 == 0) goto code_r0x00018025f049;
            pcVar2 = *(code **)(*(int64_t *)(iVar6 + 0x18) + 0x38);
            if (pcVar2 == (code *)0x0) {
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1c1;
            iVar3 = (*pcVar2)(iVar6);
            if (iVar3 != 0) {
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1ca;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1e2;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), *(int64_t *)(&stack0x00000070 + iVar5 + iVar4)
                         );
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f012;
            iVar3 = func_0x00018026b010(iVar8);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f01f;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            } else {
                *(int64_t *)(iVar6 + 0x20) = iVar8;
code_r0x00018025f15b:
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + 0x20 + -0x20) = 0x18025f163;
                iVar8 = func_0x0001801dd6c0(iVar8);
                *(int64_t *)(iVar6 + 0x18) = iVar8;
                if (iVar8 != 0) goto code_r0x00018025f182;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + 0x20 + -0x20) = 0x18025f171;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f037;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), *(int64_t *)(&stack0x00000070 + iVar5 + iVar4)
                         );
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f049;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
    }
code_r0x00018025f049:
    LOCK();
    piVar1 = (int32_t *)(iVar6 + 0xa0);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (1 < iVar3) {
        return 0;
    }
    if ((*(int64_t *)(iVar6 + 0x18) != 0) &&
       (pcVar2 = *(code **)(*(int64_t *)(iVar6 + 0x18) + 0x40), pcVar2 != (code *)0x0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f076;
        (*pcVar2)(iVar6);
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f07f;
    fcn.18026aee0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f093;
    fcn.180223fb0(*(int64_t *)(&stack0x000000c0 + iVar5 + iVar4), *(int64_t *)(&stack0x00000128 + iVar5 + iVar4));
    uVar9 = *(undefined8 *)(iVar6 + 200);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f09f;
    fcn.1802227d0(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x28);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0a8;
    fcn.180255290(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0b1;
    fcn.180255290(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x38);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0ba;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x40);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0c3;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x48);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0cc;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x50);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0d5;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0de;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x60);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0e7;
    fcn.180254e90(uVar9);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0f3;
    fcn.1802b2800(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
    uVar9 = *(undefined8 *)(iVar6 + 0x88);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f106;
    fcn.180222290(uVar9, 0x180196ec0);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f115;
    fcn.180222050(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f11d;
    fcn.1802d3ad0(iVar6);
    uVar9 = 0xbe;
code_r0x00018025f123:
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f132;
    fcn.180224990(iVar6, 0x1804e6980, uVar9);
    return 0;
}

// ============================================================
// Function: FUN_18025eb60
// Address: 0x18025eb60
// Size: 908 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18025eb60(int64_t arg4, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t aiStackX_10 [2];
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_40 = 0x18025eb7f;
    var_20h = arg4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (((in_RDX != 0) && (in_R8 != 0)) && (arg4 != 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ebb1;
        iVar1 = fcn.180222010(in_RDX);
        if (1 < iVar1) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ebca;
            iVar4 = fcn.180222340(in_RDX, 1);
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ebd7;
            iVar5 = fcn.180222340(in_RDX, 0);
            if (((*(int64_t *)(in_RCX + 0x40) != 0) || (iVar5 != 0)) &&
               ((*(int64_t *)(in_RCX + 0x48) != 0 || (iVar4 != 0)))) {
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec06;
                    fcn.180254e90();
                    *(int64_t *)(in_RCX + 0x40) = iVar5;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec17;
                    func_0x000180255830(iVar5, 4);
                }
                if (iVar4 != 0) {
                    uVar7 = *(undefined8 *)(in_RCX + 0x48);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec25;
                    fcn.180254e90(uVar7);
                    *(int64_t *)(in_RCX + 0x48) = iVar4;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec36;
                    func_0x000180255830(iVar4, 4);
                }
                *(int32_t *)(in_RCX + 0xd0) = *(int32_t *)(in_RCX + 0xd0) + 1;
                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec46;
                func_0x000180221890(in_RDX, 0);
                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec50;
                func_0x000180221890(in_RDX, 0);
                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec58;
                iVar2 = fcn.180222010(in_R8);
                if (iVar1 == iVar2) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec69;
                    iVar2 = fcn.180222010(arg4);
                    if (iVar1 == iVar2 + 1) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec7e;
                        iVar4 = fcn.180222340(arg4, 0);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec8e;
                        iVar5 = fcn.180222340(in_R8, 1);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ec9b;
                        iVar6 = fcn.180222340(in_R8, 0);
                        if ((*(int64_t *)(in_RCX + 0x50) == 0) && (iVar6 == 0)) {
                            return 0;
                        }
                        if ((*(int64_t *)(in_RCX + 0x58) == 0) && (iVar5 == 0)) {
                            return 0;
                        }
                        if ((*(int64_t *)(in_RCX + 0x60) == 0) && (iVar4 == 0)) {
                            return 0;
                        }
                        if (iVar6 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ecda;
                            fcn.180254e90();
                            *(int64_t *)(in_RCX + 0x50) = iVar6;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025eceb;
                            func_0x000180255830(iVar6, 4);
                        }
                        if (iVar5 != 0) {
                            uVar7 = *(undefined8 *)(in_RCX + 0x58);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ecf9;
                            fcn.180254e90(uVar7);
                            *(int64_t *)(in_RCX + 0x58) = iVar5;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ed0a;
                            func_0x000180255830(iVar5, 4);
                        }
                        if (iVar4 != 0) {
                            uVar7 = *(undefined8 *)(in_RCX + 0x60);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ed18;
                            fcn.180254e90(uVar7);
                            *(int64_t *)(in_RCX + 0x60) = iVar4;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ed29;
                            func_0x000180255830(iVar4, 4);
                        }
                        *(int32_t *)(in_RCX + 0xd0) = *(int32_t *)(in_RCX + 0xd0) + 1;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ed39;
                        func_0x000180221890(in_R8, 0);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ed43;
                        func_0x000180221890(in_R8, 0);
                        arg4 = *(int64_t *)((int64_t)&arg_50h + iVar3);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ed55;
                        func_0x000180221890(arg4, 0);
                    }
                }
                iVar4 = *(int64_t *)(in_RCX + 0x88);
                *(int64_t *)((int64_t)&var_10h + iVar3) = iVar4;
                if (iVar1 < 3) {
code_r0x00018025eeb0:
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025eec4;
                        fcn.180222290(iVar4, 0x180196ec0);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025eed3;
                        fcn.180222050(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                    }
                    *(int32_t *)(in_RCX + 0xd0) = *(int32_t *)(in_RCX + 0xd0) + 1;
                    *(uint32_t *)(in_RCX + 0x10) = (uint32_t)(2 < iVar1);
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ed75;
                uVar7 = func_0x000180221f60(0, iVar1);
                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ed84;
                iVar4 = fcn.180222290(uVar7, 0x180196ec0);
                *(int64_t *)((int64_t)&var_18h + iVar3) = iVar4;
                if (iVar4 != 0) {
                    *(undefined4 *)((int64_t)&arg_40h + iVar3) = 2;
                    do {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025eda8;
                        iVar4 = func_0x000180222020(in_RDX);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025edb3;
                        iVar5 = func_0x000180222020(in_R8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025edbe;
                        iVar6 = func_0x000180222020(arg4);
                        if (((iVar4 == 0) || (iVar5 == 0)) || (iVar6 == 0)) goto code_r0x00018025ee79;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025edf3;
                        piVar8 = (int64_t *)
                                 fcn.180224d60(*(int64_t *)((int64_t)&var_10h + iVar3), 
                                               *(int64_t *)((int64_t)aiStackX_10 + iVar3));
                        if (piVar8 == (int64_t *)0x0) goto code_r0x00018025ee79;
                        *piVar8 = iVar4;
                        piVar8[1] = iVar5;
                        piVar8[2] = iVar6;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ee13;
                        func_0x000180255830(iVar4, 4);
                        iVar4 = piVar8[1];
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ee21;
                        func_0x000180255830(iVar4, 4);
                        iVar4 = piVar8[2];
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ee2f;
                        func_0x000180255830(iVar4, 4);
                        uVar7 = *(undefined8 *)((int64_t)&var_18h + iVar3);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ee3f;
                        fcn.180222110(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)aiStackX_10 + iVar3)
                                      , *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), 
                                      *(int64_t *)((int64_t)&var_20h + iVar3));
                        arg4 = *(int64_t *)((int64_t)&arg_50h + iVar3);
                        iVar2 = *(int32_t *)((int64_t)&arg_40h + iVar3) + 1;
                        *(int32_t *)((int64_t)&arg_40h + iVar3) = iVar2;
                    } while (iVar2 < iVar1);
                    *(undefined8 *)(in_RCX + 0x88) = uVar7;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ee69;
                    iVar2 = func_0x0001802d3d30(in_RCX);
                    iVar4 = *(int64_t *)((int64_t)&var_10h + iVar3);
                    if (iVar2 != 0) goto code_r0x00018025eeb0;
                    *(int64_t *)(in_RCX + 0x88) = iVar4;
code_r0x00018025ee79:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ee8a;
                    fcn.180222290(*(undefined8 *)((int64_t)&var_18h + iVar3), 0x180196ec0);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18025ee99;
                    fcn.180222050(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3)
                                  , *(int64_t *)((int64_t)&var_20h + iVar3));
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18025ef00
// Address: 0x18025ef00
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18025ef00(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025ef10;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025ef25;
    fcn.1802b2800(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)(in_RCX + 0x80) = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_18025ef40
// Address: 0x18025ef40
// Size: 703 bytes
// ============================================================
int64_t fcn.18025e2a0(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar9;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18025ef55;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef75;
    iVar6 = fcn.180224d60(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000068 + iVar5 + iVar4)
                         );
    if (iVar6 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef86;
    iVar7 = func_0x000180222800();
    *(int64_t *)(iVar6 + 200) = iVar7;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025ef97;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efaf;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efc1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
        uVar9 = 0x56;
        goto code_r0x00018025f123;
    }
    *(undefined4 *)(iVar6 + 0xa0) = 1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025efdb;
    iVar7 = func_0x0001802d3ab0();
    *(int64_t *)(iVar6 + 0xc0) = iVar7;
    if (iVar7 != 0) {
        *(undefined8 *)(iVar6 + 8) = uVar9;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025eff0;
        iVar7 = func_0x0001802d36c0();
        *(int64_t *)(iVar6 + 0x18) = iVar7;
        *(uint32_t *)(iVar6 + 0xa4) = *(uint32_t *)(iVar7 + 0x48) & 0xfffffbff;
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f14f;
            iVar8 = func_0x0001802d3c40();
            *(int64_t *)(iVar6 + 0x20) = iVar8;
            if (iVar8 != 0) goto code_r0x00018025f15b;
code_r0x00018025f182:
            *(uint32_t *)(iVar6 + 0xa4) = *(uint32_t *)(*(int64_t *)(iVar6 + 0x18) + 0x48) & 0xfffffbff;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1a7;
            iVar3 = func_0x000180224430(9, iVar6, iVar6 + 0x90);
            if (iVar3 == 0) goto code_r0x00018025f049;
            pcVar2 = *(code **)(*(int64_t *)(iVar6 + 0x18) + 0x38);
            if (pcVar2 == (code *)0x0) {
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1c1;
            iVar3 = (*pcVar2)(iVar6);
            if (iVar3 != 0) {
                return iVar6;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1ca;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f1e2;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        } else {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f012;
            iVar3 = func_0x00018026b010(iVar8);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f01f;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            } else {
                *(int64_t *)(iVar6 + 0x20) = iVar8;
code_r0x00018025f15b:
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + 0x20 + -0x20) = 0x18025f163;
                iVar8 = func_0x0001801dd6c0(iVar8);
                *(int64_t *)(iVar6 + 0x18) = iVar8;
                if (iVar8 != 0) goto code_r0x00018025f182;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + 0x20 + -0x20) = 0x18025f171;
                fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f037;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f049;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
    }
code_r0x00018025f049:
    LOCK();
    piVar1 = (int32_t *)(iVar6 + 0xa0);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (1 < iVar3) {
        return 0;
    }
    if ((*(int64_t *)(iVar6 + 0x18) != 0) &&
       (pcVar2 = *(code **)(*(int64_t *)(iVar6 + 0x18) + 0x40), pcVar2 != (code *)0x0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f076;
        (*pcVar2)(iVar6);
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f07f;
    fcn.18026aee0(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f093;
    fcn.180223fb0(*(int64_t *)(&stack0x000000c0 + iVar5 + iVar4), *(int64_t *)(&stack0x00000128 + iVar5 + iVar4));
    uVar9 = *(undefined8 *)(iVar6 + 200);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f09f;
    fcn.1802227d0(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x28);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0a8;
    fcn.180255290(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x30);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0b1;
    fcn.180255290(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x38);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0ba;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x40);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0c3;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x48);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0cc;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x50);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0d5;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x58);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0de;
    fcn.180254e90(uVar9);
    uVar9 = *(undefined8 *)(iVar6 + 0x60);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0e7;
    fcn.180254e90(uVar9);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f0f3;
    fcn.1802b2800(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
    uVar9 = *(undefined8 *)(iVar6 + 0x88);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f106;
    fcn.180222290(uVar9, 0x180196ec0);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f115;
    fcn.180222050(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f11d;
    fcn.1802d3ad0(iVar6);
    uVar9 = 0xbe;
code_r0x00018025f123:
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18025f132;
    fcn.180224990(iVar6, 0x1804e6980, uVar9);
    return 0;
}

// ============================================================
// Function: FUN_18025f200
// Address: 0x18025f200
// Size: 70 bytes
// ============================================================
void fcn.18025f200(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025f20a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x18025f330;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180248230;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x18025f390;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025f241;
    fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x000000b0 + iVar1), *(int64_t *)(&stack0x000000b8 + iVar1), 
                  *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18025f250
// Address: 0x18025f250
// Size: 94 bytes
// ============================================================
void fcn.18025f250(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18025f260;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        puVar1 = (undefined8 *)(arg1 + 0x20);
        iVar2 = *(int32_t *)puVar1;
        *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025f28b;
            fcn.180224990(uVar3, 0x1804e6a98, 0x28);
            uVar3 = *(undefined8 *)arg1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025f293;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025f2a8;
            fcn.180224990(arg1, 0x1804e6a98, 0x2b);
        }
    }
    return;
}

