// Chunk 93 - 50 functions

// ============================================================
// Function: FUN_180139d40
// Address: 0x180139d40
// Size: 34 bytes
// ============================================================
char fcn.180139d40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_208h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    char cVar20;
    int32_t iVar21;
    bool bVar22;
    float fVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar11 = (int32_t)arg2;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar18 = *(int64_t *)(iVar2 + 0x15e0);
    iVar9 = 0x1fbc;
    if (*(int32_t *)(iVar2 + 0x1fb8) != iVar11) {
        iVar9 = 0x1f78;
    }
    uVar1 = *(uint32_t *)(iVar9 + iVar2);
    if (((uint32_t)arg_28h >> 0xc & 1) == 0) {
        uVar1 = *(uint32_t *)(iVar9 + iVar2);
    }
    uVar7 = (uint32_t)arg_28h | 0x440000;
    if ((uVar1 >> 0x11 & 1) == 0) {
        uVar7 = (uint32_t)arg_28h;
    }
    uVar16 = uVar7 | 1;
    if ((uVar7 & 7) != 0) {
        uVar16 = uVar7;
    }
    if ((uVar16 & 0x3f0) == 0) {
        uVar7 = 0x20;
        if ((uVar1 & 8) != 0) {
            uVar7 = 0x10;
        }
        uVar16 = uVar7 | uVar16;
    }
    iVar9 = *(int64_t *)(iVar2 + 0x15e8);
    if ((((uVar16 >> 0xb & 1) == 0) || (iVar9 == 0)) || (*(int64_t *)(iVar9 + 0x428) != *(int64_t *)(iVar18 + 0x428))) {
        bVar22 = false;
    } else {
        bVar22 = true;
        *(int64_t *)(iVar2 + 0x15e8) = iVar18;
    }
    cVar20 = '\0';
    cVar4 = func_0x0001800fa440(arg1, arg2 & 0xffffffff);
    if (*(char *)(iVar2 + 0x2400) != '\0') {
        if ((((uVar16 >> 9 & 1) != 0) && ((*(uint8_t *)(iVar2 + 0x2404) & 4) == 0)) &&
           (cVar5 = func_0x0001800fa150(0x80), iVar3 = *(int64_t *)0x180781f28, cVar5 != '\0')) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar11;
            *(undefined *)(iVar3 + 0x1650) = 0;
            if ((iVar11 != 0) && (*(int32_t *)(iVar3 + 0x1640) != iVar11)) {
                *(undefined8 *)(iVar3 + 0x1648) = 0;
            }
            cVar4 = '\x01';
            if ((*(float *)(iVar2 + 0x1648) - *(float *)(iVar2 + 0x48) <= 0.7) && (0.7 <= *(float *)(iVar2 + 0x1648))) {
                *(int32_t *)(iVar2 + 0x2490) = iVar11;
                cVar20 = '\x01';
                func_0x00018010e050(iVar18, 0);
                cVar4 = '\x01';
            }
        }
        if ((*(int32_t *)(iVar2 + 0x2488) == iVar11) && ((*(uint32_t *)(iVar2 + 0x247c) & 0x2000) != 0)) {
            cVar4 = '\x01';
        }
    }
    iVar17 = 1;
    iVar8 = 1;
    if (bVar22) {
        *(int64_t *)(iVar2 + 0x15e8) = iVar9;
    }
    iVar19 = iVar11;
    if ((uVar16 >> 0x15 & 1) != 0) {
        iVar19 = 0;
    }
    if (cVar4 != '\0') {
        iVar14 = -1;
        iVar15 = -1;
        iVar21 = -1;
        if ((uVar16 & 1) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            iVar15 = iVar14;
            iVar8 = iVar17;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbac))) &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xbac) == 0.0)) {
                iVar8 = 1;
                cVar5 = func_0x000180109b10(0x290);
                iVar15 = -1;
                if (cVar5 != '\0') {
                    iVar15 = 0;
                }
            }
            if (*(char *)(iVar9 + 0xb6e) != '\0') {
                cVar5 = func_0x000180109b10(0x290, iVar19);
                iVar21 = -1;
                if (cVar5 != '\0') {
                    iVar21 = 0;
                }
            }
        }
        if ((uVar16 & 2) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x121) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb0))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb0) == 0.0 &&
                ((cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb6f) != '\0') && (cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if ((uVar16 & 4) != 0) {
            iVar8 = 2;
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x122) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb4))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb4) == 0.0 &&
                ((iVar8 = 2, cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb70) != '\0') && (cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if (((uVar16 >> 0x10 & 1) == 0) ||
           (((*(char *)(iVar2 + 0x138) == '\0' && (*(char *)(iVar2 + 0x139) == '\0')) &&
            (*(char *)(iVar2 + 0x13a) == '\0')))) {
            if ((iVar15 == -1) || (*(int32_t *)(iVar2 + 0x1654) == iVar11)) {
                if ((char)uVar16 < '\0') goto code_r0x00018013a1a2;
            } else {
                if ((uVar16 >> 0x14 & 1) == 0) {
                    func_0x000180109bc0(iVar15 + 0x290, arg2 & 0xffffffff);
                }
                uVar13 = (undefined)iVar15;
                if ((uVar16 & 0x60) != 0) {
                    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a116;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a116:
                if (((uVar16 & 0x10) != 0) ||
                   (((uVar16 >> 8 & 1) != 0 && (*(int16_t *)(iVar2 + 0xb5a + (int64_t)iVar15 * 2) == 2)))) {
                    cVar20 = '\x01';
                    iVar9 = iVar18;
                    if ((uVar16 >> 0x11 & 1) != 0) {
                        iVar9 = 0;
                    }
                    uVar10 = 0;
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        uVar10 = arg2 & 0xffffffff;
                    }
                    func_0x0001800f9f30(uVar10, iVar9);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a17f;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a17f:
                if ((char)uVar16 < '\0') {
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    }
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
code_r0x00018013a1a2:
                    if (iVar21 != -1) {
                        if (((uVar1 & 8) == 0) ||
                           (*(float *)(iVar2 + 0xbc0 + (int64_t)iVar21 * 4) < *(float *)(iVar2 + 0xa8))) {
                            cVar20 = '\x01';
                        }
                        if ((uVar16 >> 0x12 & 1) == 0) {
                            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (((((*(int32_t *)(iVar2 + 0x1654) != iVar11) || ((uVar1 & 8) == 0)) ||
                 (iVar9 = (int64_t)*(char *)(iVar2 + 0x1667), *(float *)(iVar2 + 0xbac + iVar9 * 4) <= 0.0)) ||
                ((*(char *)(iVar9 + 0x120 + *(int64_t *)0x180781f28) == '\0' ||
                 (fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0xbac + iVar9 * 4), fVar23 < 0.0)))) ||
               (((fVar23 != 0.0 &&
                 ((fVar23 <= *(float *)(*(int64_t *)0x180781f28 + 0xa8) ||
                  (iVar8 = func_0x000180107850(fVar23 - *(float *)(*(int64_t *)0x180781f28 + 0x48), iVar9, 
                                               *(float *)(*(int64_t *)0x180781f28 + 0xa8), 
                                               *(undefined4 *)(*(int64_t *)0x180781f28 + 0xac)), iVar8 < 1)))) ||
                (cVar5 = func_0x000180109b10((int32_t)iVar9 + 0x290, iVar19), cVar5 == '\0'))))
            goto code_r0x00018013a286;
            cVar20 = '\x01';
        } else {
code_r0x00018013a286:
            if (cVar20 == '\0') goto code_r0x00018013a2ad;
        }
        if (*(char *)(iVar2 + 0x7e) != '\0') {
            *(undefined *)(iVar2 + 0x21cc) = 0;
        }
    }
code_r0x00018013a2ad:
    if ((uVar1 & 0x40) != 0) goto code_r0x00018013a3aa;
    if ((((*(int32_t *)(iVar2 + 0x21d0) == iVar11) && (*(char *)(iVar2 + 0x21cc) != '\0')) &&
        (*(char *)(iVar2 + 0x21cd) != '\0')) && ((uVar16 >> 0x13 & 1) == 0)) {
        cVar4 = '\x01';
    }
    if (*(int32_t *)(iVar2 + 0x21f0) != iVar11) goto code_r0x00018013a3aa;
    bVar22 = *(int32_t *)(iVar2 + 0x21f4) == iVar11;
    if ((!bVar22) && ((uVar1 & 8) != 0)) {
        iVar9 = 0x914;
        if (*(char *)(iVar2 + 0x79) != '\0') {
            iVar9 = 0x8f4;
        }
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x204);
        if (*(float *)(*(int64_t *)0x180781f28 + 0x204) <= *(float *)(*(int64_t *)0x180781f28 + 0x214)) {
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x214);
        }
        if (fVar23 <= *(float *)(iVar9 + *(int64_t *)0x180781f28)) {
            fVar23 = *(float *)(iVar9 + *(int64_t *)0x180781f28);
        }
        iVar8 = func_0x000180107850(fVar23 - *(float *)(iVar2 + 0x48), 0x8f4, *(undefined4 *)(iVar2 + 0xa8), 
                                    *(undefined4 *)(iVar2 + 0xac));
        bVar22 = 0 < iVar8;
    }
    if ((*(int32_t *)(iVar2 + 0x21ec) != iVar11) && (!bVar22)) goto code_r0x00018013a3aa;
    cVar20 = '\x01';
    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
    *(undefined4 *)(iVar2 + 0x1674) = *(undefined4 *)(iVar2 + 0x2228);
    if ((uVar16 >> 0x12 & 1) == 0) {
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) {
            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
            goto code_r0x00018013a39a;
        }
    } else {
code_r0x00018013a39a:
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) goto code_r0x00018013a3aa;
    }
    *(undefined *)(iVar2 + 0x1666) = 1;
code_r0x00018013a3aa:
    uVar13 = 0;
    if (*(int32_t *)(iVar2 + 0x1654) == iVar11) {
        if (*(int32_t *)(iVar2 + 0x1674) == 1) {
            if (*(char *)(iVar2 + 0x1660) != '\0') {
                fVar23 = *(float *)arg1;
                *(float *)(iVar2 + 0x1670) = *(float *)(iVar2 + 0x11c) - *(float *)(arg1 + 4);
                *(float *)(iVar2 + 0x166c) = *(float *)(iVar2 + 0x118) - fVar23;
            }
            cVar5 = *(char *)(iVar2 + 0x1667);
            iVar18 = (int64_t)cVar5;
            if (cVar5 == -1) {
                func_0x0001800f9f30(0, 0);
            } else if ((*(char *)(iVar18 + 0x120 + *(int64_t *)0x180781f28) == '\0') ||
                      (cVar5 = func_0x000180109b10(cVar5 + 0x290, iVar19), cVar5 == '\0')) {
                if ((((cVar4 != '\0') && ((uVar16 & 0x20) != 0)) || ((uVar16 & 0x40) != 0)) &&
                   (*(char *)(iVar2 + 0x2400) == '\0')) {
                    if ((((uVar16 >> 8 & 1) == 0) || (*(char *)(iVar18 + 0xb6e + iVar2) == '\0')) ||
                       (*(int16_t *)(iVar2 + 0xb64 + iVar18 * 2) != 2)) {
                        bVar22 = false;
                    } else {
                        bVar22 = true;
                    }
                    if (((uVar1 & 8) == 0) || (*(float *)(iVar2 + 0xbc0 + iVar18 * 4) < *(float *)(iVar2 + 0xa8))) {
                        cVar5 = '\0';
                    } else {
                        cVar5 = '\x01';
                    }
                    cVar6 = func_0x000180109b10((int32_t)iVar18 + 0x290, iVar19);
                    if (((!bVar22) && (cVar5 == '\0')) && (cVar6 != '\0')) {
                        cVar20 = '\x01';
                    }
                }
                func_0x0001800f9f30(0, 0);
            } else {
                uVar13 = 1;
            }
            if (((uVar16 >> 0x12 & 1) == 0) && (*(char *)(iVar2 + 0x7e) != '\0')) {
                *(undefined *)(iVar2 + 0x21cc) = 0;
            }
        } else if (*(int32_t *)(iVar2 + 0x1674) - 2U < 2) {
            if (*(int32_t *)(iVar2 + 0x21f0) == iVar11) {
                uVar13 = 1;
            } else {
                func_0x0001800f9f30(0, 0);
            }
        }
        if (cVar20 != '\0') {
            *(undefined *)(iVar2 + 0x1663) = 1;
        }
    }
    if ((*(int32_t *)(iVar2 + 0x2210) == iVar11) && ((uVar1 & 0x40) == 0)) {
        cVar4 = '\x01';
    }
    if (arg3 != 0) {
        *(char *)arg3 = cVar4;
    }
    if (arg4 != 0) {
        *(undefined *)arg4 = uVar13;
    }
    return cVar20;
}

// ============================================================
// Function: FUN_180139d62
// Address: 0x180139d62
// Size: 479 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

char fcn.180139d40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_208h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    char cVar20;
    int32_t iVar21;
    bool bVar22;
    float fVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar11 = (int32_t)arg2;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar18 = *(int64_t *)(iVar2 + 0x15e0);
    iVar9 = 0x1fbc;
    if (*(int32_t *)(iVar2 + 0x1fb8) != iVar11) {
        iVar9 = 0x1f78;
    }
    uVar1 = *(uint32_t *)(iVar9 + iVar2);
    if (((uint32_t)arg_28h >> 0xc & 1) == 0) {
        uVar1 = *(uint32_t *)(iVar9 + iVar2);
    }
    uVar7 = (uint32_t)arg_28h | 0x440000;
    if ((uVar1 >> 0x11 & 1) == 0) {
        uVar7 = (uint32_t)arg_28h;
    }
    uVar16 = uVar7 | 1;
    if ((uVar7 & 7) != 0) {
        uVar16 = uVar7;
    }
    if ((uVar16 & 0x3f0) == 0) {
        uVar7 = 0x20;
        if ((uVar1 & 8) != 0) {
            uVar7 = 0x10;
        }
        uVar16 = uVar7 | uVar16;
    }
    iVar9 = *(int64_t *)(iVar2 + 0x15e8);
    if ((((uVar16 >> 0xb & 1) == 0) || (iVar9 == 0)) || (*(int64_t *)(iVar9 + 0x428) != *(int64_t *)(iVar18 + 0x428))) {
        bVar22 = false;
    } else {
        bVar22 = true;
        *(int64_t *)(iVar2 + 0x15e8) = iVar18;
    }
    cVar20 = '\0';
    cVar4 = func_0x0001800fa440(arg1, arg2 & 0xffffffff);
    if (*(char *)(iVar2 + 0x2400) != '\0') {
        if ((((uVar16 >> 9 & 1) != 0) && ((*(uint8_t *)(iVar2 + 0x2404) & 4) == 0)) &&
           (cVar5 = func_0x0001800fa150(0x80), iVar3 = *(int64_t *)0x180781f28, cVar5 != '\0')) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar11;
            *(undefined *)(iVar3 + 0x1650) = 0;
            if ((iVar11 != 0) && (*(int32_t *)(iVar3 + 0x1640) != iVar11)) {
                *(undefined8 *)(iVar3 + 0x1648) = 0;
            }
            cVar4 = '\x01';
            if ((*(float *)(iVar2 + 0x1648) - *(float *)(iVar2 + 0x48) <= 0.7) && (0.7 <= *(float *)(iVar2 + 0x1648))) {
                *(int32_t *)(iVar2 + 0x2490) = iVar11;
                cVar20 = '\x01';
                func_0x00018010e050(iVar18, 0);
                cVar4 = '\x01';
            }
        }
        if ((*(int32_t *)(iVar2 + 0x2488) == iVar11) && ((*(uint32_t *)(iVar2 + 0x247c) & 0x2000) != 0)) {
            cVar4 = '\x01';
        }
    }
    iVar17 = 1;
    iVar8 = 1;
    if (bVar22) {
        *(int64_t *)(iVar2 + 0x15e8) = iVar9;
    }
    iVar19 = iVar11;
    if ((uVar16 >> 0x15 & 1) != 0) {
        iVar19 = 0;
    }
    if (cVar4 != '\0') {
        iVar14 = -1;
        iVar15 = -1;
        iVar21 = -1;
        if ((uVar16 & 1) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            iVar15 = iVar14;
            iVar8 = iVar17;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbac))) &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xbac) == 0.0)) {
                iVar8 = 1;
                cVar5 = func_0x000180109b10(0x290);
                iVar15 = -1;
                if (cVar5 != '\0') {
                    iVar15 = 0;
                }
            }
            if (*(char *)(iVar9 + 0xb6e) != '\0') {
                cVar5 = func_0x000180109b10(0x290, iVar19);
                iVar21 = -1;
                if (cVar5 != '\0') {
                    iVar21 = 0;
                }
            }
        }
        if ((uVar16 & 2) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x121) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb0))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb0) == 0.0 &&
                ((cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb6f) != '\0') && (cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if ((uVar16 & 4) != 0) {
            iVar8 = 2;
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x122) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb4))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb4) == 0.0 &&
                ((iVar8 = 2, cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb70) != '\0') && (cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if (((uVar16 >> 0x10 & 1) == 0) ||
           (((*(char *)(iVar2 + 0x138) == '\0' && (*(char *)(iVar2 + 0x139) == '\0')) &&
            (*(char *)(iVar2 + 0x13a) == '\0')))) {
            if ((iVar15 == -1) || (*(int32_t *)(iVar2 + 0x1654) == iVar11)) {
                if ((char)uVar16 < '\0') goto code_r0x00018013a1a2;
            } else {
                if ((uVar16 >> 0x14 & 1) == 0) {
                    func_0x000180109bc0(iVar15 + 0x290, arg2 & 0xffffffff);
                }
                uVar13 = (undefined)iVar15;
                if ((uVar16 & 0x60) != 0) {
                    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a116;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a116:
                if (((uVar16 & 0x10) != 0) ||
                   (((uVar16 >> 8 & 1) != 0 && (*(int16_t *)(iVar2 + 0xb5a + (int64_t)iVar15 * 2) == 2)))) {
                    cVar20 = '\x01';
                    iVar9 = iVar18;
                    if ((uVar16 >> 0x11 & 1) != 0) {
                        iVar9 = 0;
                    }
                    uVar10 = 0;
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        uVar10 = arg2 & 0xffffffff;
                    }
                    func_0x0001800f9f30(uVar10, iVar9);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a17f;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a17f:
                if ((char)uVar16 < '\0') {
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    }
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
code_r0x00018013a1a2:
                    if (iVar21 != -1) {
                        if (((uVar1 & 8) == 0) ||
                           (*(float *)(iVar2 + 0xbc0 + (int64_t)iVar21 * 4) < *(float *)(iVar2 + 0xa8))) {
                            cVar20 = '\x01';
                        }
                        if ((uVar16 >> 0x12 & 1) == 0) {
                            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (((((*(int32_t *)(iVar2 + 0x1654) != iVar11) || ((uVar1 & 8) == 0)) ||
                 (iVar9 = (int64_t)*(char *)(iVar2 + 0x1667), *(float *)(iVar2 + 0xbac + iVar9 * 4) <= 0.0)) ||
                ((*(char *)(iVar9 + 0x120 + *(int64_t *)0x180781f28) == '\0' ||
                 (fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0xbac + iVar9 * 4), fVar23 < 0.0)))) ||
               (((fVar23 != 0.0 &&
                 ((fVar23 <= *(float *)(*(int64_t *)0x180781f28 + 0xa8) ||
                  (iVar8 = func_0x000180107850(fVar23 - *(float *)(*(int64_t *)0x180781f28 + 0x48), iVar9, 
                                               *(float *)(*(int64_t *)0x180781f28 + 0xa8), 
                                               *(undefined4 *)(*(int64_t *)0x180781f28 + 0xac)), iVar8 < 1)))) ||
                (cVar5 = func_0x000180109b10((int32_t)iVar9 + 0x290, iVar19), cVar5 == '\0'))))
            goto code_r0x00018013a286;
            cVar20 = '\x01';
        } else {
code_r0x00018013a286:
            if (cVar20 == '\0') goto code_r0x00018013a2ad;
        }
        if (*(char *)(iVar2 + 0x7e) != '\0') {
            *(undefined *)(iVar2 + 0x21cc) = 0;
        }
    }
code_r0x00018013a2ad:
    if ((uVar1 & 0x40) != 0) goto code_r0x00018013a3aa;
    if ((((*(int32_t *)(iVar2 + 0x21d0) == iVar11) && (*(char *)(iVar2 + 0x21cc) != '\0')) &&
        (*(char *)(iVar2 + 0x21cd) != '\0')) && ((uVar16 >> 0x13 & 1) == 0)) {
        cVar4 = '\x01';
    }
    if (*(int32_t *)(iVar2 + 0x21f0) != iVar11) goto code_r0x00018013a3aa;
    bVar22 = *(int32_t *)(iVar2 + 0x21f4) == iVar11;
    if ((!bVar22) && ((uVar1 & 8) != 0)) {
        iVar9 = 0x914;
        if (*(char *)(iVar2 + 0x79) != '\0') {
            iVar9 = 0x8f4;
        }
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x204);
        if (*(float *)(*(int64_t *)0x180781f28 + 0x204) <= *(float *)(*(int64_t *)0x180781f28 + 0x214)) {
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x214);
        }
        if (fVar23 <= *(float *)(iVar9 + *(int64_t *)0x180781f28)) {
            fVar23 = *(float *)(iVar9 + *(int64_t *)0x180781f28);
        }
        iVar8 = func_0x000180107850(fVar23 - *(float *)(iVar2 + 0x48), 0x8f4, *(undefined4 *)(iVar2 + 0xa8), 
                                    *(undefined4 *)(iVar2 + 0xac));
        bVar22 = 0 < iVar8;
    }
    if ((*(int32_t *)(iVar2 + 0x21ec) != iVar11) && (!bVar22)) goto code_r0x00018013a3aa;
    cVar20 = '\x01';
    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
    *(undefined4 *)(iVar2 + 0x1674) = *(undefined4 *)(iVar2 + 0x2228);
    if ((uVar16 >> 0x12 & 1) == 0) {
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) {
            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
            goto code_r0x00018013a39a;
        }
    } else {
code_r0x00018013a39a:
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) goto code_r0x00018013a3aa;
    }
    *(undefined *)(iVar2 + 0x1666) = 1;
code_r0x00018013a3aa:
    uVar13 = 0;
    if (*(int32_t *)(iVar2 + 0x1654) == iVar11) {
        if (*(int32_t *)(iVar2 + 0x1674) == 1) {
            if (*(char *)(iVar2 + 0x1660) != '\0') {
                fVar23 = *(float *)arg1;
                *(float *)(iVar2 + 0x1670) = *(float *)(iVar2 + 0x11c) - *(float *)(arg1 + 4);
                *(float *)(iVar2 + 0x166c) = *(float *)(iVar2 + 0x118) - fVar23;
            }
            cVar5 = *(char *)(iVar2 + 0x1667);
            iVar18 = (int64_t)cVar5;
            if (cVar5 == -1) {
                func_0x0001800f9f30(0, 0);
            } else if ((*(char *)(iVar18 + 0x120 + *(int64_t *)0x180781f28) == '\0') ||
                      (cVar5 = func_0x000180109b10(cVar5 + 0x290, iVar19), cVar5 == '\0')) {
                if ((((cVar4 != '\0') && ((uVar16 & 0x20) != 0)) || ((uVar16 & 0x40) != 0)) &&
                   (*(char *)(iVar2 + 0x2400) == '\0')) {
                    if ((((uVar16 >> 8 & 1) == 0) || (*(char *)(iVar18 + 0xb6e + iVar2) == '\0')) ||
                       (*(int16_t *)(iVar2 + 0xb64 + iVar18 * 2) != 2)) {
                        bVar22 = false;
                    } else {
                        bVar22 = true;
                    }
                    if (((uVar1 & 8) == 0) || (*(float *)(iVar2 + 0xbc0 + iVar18 * 4) < *(float *)(iVar2 + 0xa8))) {
                        cVar5 = '\0';
                    } else {
                        cVar5 = '\x01';
                    }
                    cVar6 = func_0x000180109b10((int32_t)iVar18 + 0x290, iVar19);
                    if (((!bVar22) && (cVar5 == '\0')) && (cVar6 != '\0')) {
                        cVar20 = '\x01';
                    }
                }
                func_0x0001800f9f30(0, 0);
            } else {
                uVar13 = 1;
            }
            if (((uVar16 >> 0x12 & 1) == 0) && (*(char *)(iVar2 + 0x7e) != '\0')) {
                *(undefined *)(iVar2 + 0x21cc) = 0;
            }
        } else if (*(int32_t *)(iVar2 + 0x1674) - 2U < 2) {
            if (*(int32_t *)(iVar2 + 0x21f0) == iVar11) {
                uVar13 = 1;
            } else {
                func_0x0001800f9f30(0, 0);
            }
        }
        if (cVar20 != '\0') {
            *(undefined *)(iVar2 + 0x1663) = 1;
        }
    }
    if ((*(int32_t *)(iVar2 + 0x2210) == iVar11) && ((uVar1 & 0x40) == 0)) {
        cVar4 = '\x01';
    }
    if (arg3 != 0) {
        *(char *)arg3 = cVar4;
    }
    if (arg4 != 0) {
        *(undefined *)arg4 = uVar13;
    }
    return cVar20;
}

// ============================================================
// Function: FUN_180139f41
// Address: 0x180139f41
// Size: 876 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

char fcn.180139d40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_208h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    char cVar20;
    int32_t iVar21;
    bool bVar22;
    float fVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar11 = (int32_t)arg2;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar18 = *(int64_t *)(iVar2 + 0x15e0);
    iVar9 = 0x1fbc;
    if (*(int32_t *)(iVar2 + 0x1fb8) != iVar11) {
        iVar9 = 0x1f78;
    }
    uVar1 = *(uint32_t *)(iVar9 + iVar2);
    if (((uint32_t)arg_28h >> 0xc & 1) == 0) {
        uVar1 = *(uint32_t *)(iVar9 + iVar2);
    }
    uVar7 = (uint32_t)arg_28h | 0x440000;
    if ((uVar1 >> 0x11 & 1) == 0) {
        uVar7 = (uint32_t)arg_28h;
    }
    uVar16 = uVar7 | 1;
    if ((uVar7 & 7) != 0) {
        uVar16 = uVar7;
    }
    if ((uVar16 & 0x3f0) == 0) {
        uVar7 = 0x20;
        if ((uVar1 & 8) != 0) {
            uVar7 = 0x10;
        }
        uVar16 = uVar7 | uVar16;
    }
    iVar9 = *(int64_t *)(iVar2 + 0x15e8);
    if ((((uVar16 >> 0xb & 1) == 0) || (iVar9 == 0)) || (*(int64_t *)(iVar9 + 0x428) != *(int64_t *)(iVar18 + 0x428))) {
        bVar22 = false;
    } else {
        bVar22 = true;
        *(int64_t *)(iVar2 + 0x15e8) = iVar18;
    }
    cVar20 = '\0';
    cVar4 = func_0x0001800fa440(arg1, arg2 & 0xffffffff);
    if (*(char *)(iVar2 + 0x2400) != '\0') {
        if ((((uVar16 >> 9 & 1) != 0) && ((*(uint8_t *)(iVar2 + 0x2404) & 4) == 0)) &&
           (cVar5 = func_0x0001800fa150(0x80), iVar3 = *(int64_t *)0x180781f28, cVar5 != '\0')) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar11;
            *(undefined *)(iVar3 + 0x1650) = 0;
            if ((iVar11 != 0) && (*(int32_t *)(iVar3 + 0x1640) != iVar11)) {
                *(undefined8 *)(iVar3 + 0x1648) = 0;
            }
            cVar4 = '\x01';
            if ((*(float *)(iVar2 + 0x1648) - *(float *)(iVar2 + 0x48) <= 0.7) && (0.7 <= *(float *)(iVar2 + 0x1648))) {
                *(int32_t *)(iVar2 + 0x2490) = iVar11;
                cVar20 = '\x01';
                func_0x00018010e050(iVar18, 0);
                cVar4 = '\x01';
            }
        }
        if ((*(int32_t *)(iVar2 + 0x2488) == iVar11) && ((*(uint32_t *)(iVar2 + 0x247c) & 0x2000) != 0)) {
            cVar4 = '\x01';
        }
    }
    iVar17 = 1;
    iVar8 = 1;
    if (bVar22) {
        *(int64_t *)(iVar2 + 0x15e8) = iVar9;
    }
    iVar19 = iVar11;
    if ((uVar16 >> 0x15 & 1) != 0) {
        iVar19 = 0;
    }
    if (cVar4 != '\0') {
        iVar14 = -1;
        iVar15 = -1;
        iVar21 = -1;
        if ((uVar16 & 1) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            iVar15 = iVar14;
            iVar8 = iVar17;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbac))) &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xbac) == 0.0)) {
                iVar8 = 1;
                cVar5 = func_0x000180109b10(0x290);
                iVar15 = -1;
                if (cVar5 != '\0') {
                    iVar15 = 0;
                }
            }
            if (*(char *)(iVar9 + 0xb6e) != '\0') {
                cVar5 = func_0x000180109b10(0x290, iVar19);
                iVar21 = -1;
                if (cVar5 != '\0') {
                    iVar21 = 0;
                }
            }
        }
        if ((uVar16 & 2) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x121) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb0))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb0) == 0.0 &&
                ((cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb6f) != '\0') && (cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if ((uVar16 & 4) != 0) {
            iVar8 = 2;
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x122) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb4))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb4) == 0.0 &&
                ((iVar8 = 2, cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb70) != '\0') && (cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if (((uVar16 >> 0x10 & 1) == 0) ||
           (((*(char *)(iVar2 + 0x138) == '\0' && (*(char *)(iVar2 + 0x139) == '\0')) &&
            (*(char *)(iVar2 + 0x13a) == '\0')))) {
            if ((iVar15 == -1) || (*(int32_t *)(iVar2 + 0x1654) == iVar11)) {
                if ((char)uVar16 < '\0') goto code_r0x00018013a1a2;
            } else {
                if ((uVar16 >> 0x14 & 1) == 0) {
                    func_0x000180109bc0(iVar15 + 0x290, arg2 & 0xffffffff);
                }
                uVar13 = (undefined)iVar15;
                if ((uVar16 & 0x60) != 0) {
                    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a116;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a116:
                if (((uVar16 & 0x10) != 0) ||
                   (((uVar16 >> 8 & 1) != 0 && (*(int16_t *)(iVar2 + 0xb5a + (int64_t)iVar15 * 2) == 2)))) {
                    cVar20 = '\x01';
                    iVar9 = iVar18;
                    if ((uVar16 >> 0x11 & 1) != 0) {
                        iVar9 = 0;
                    }
                    uVar10 = 0;
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        uVar10 = arg2 & 0xffffffff;
                    }
                    func_0x0001800f9f30(uVar10, iVar9);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a17f;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a17f:
                if ((char)uVar16 < '\0') {
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    }
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
code_r0x00018013a1a2:
                    if (iVar21 != -1) {
                        if (((uVar1 & 8) == 0) ||
                           (*(float *)(iVar2 + 0xbc0 + (int64_t)iVar21 * 4) < *(float *)(iVar2 + 0xa8))) {
                            cVar20 = '\x01';
                        }
                        if ((uVar16 >> 0x12 & 1) == 0) {
                            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (((((*(int32_t *)(iVar2 + 0x1654) != iVar11) || ((uVar1 & 8) == 0)) ||
                 (iVar9 = (int64_t)*(char *)(iVar2 + 0x1667), *(float *)(iVar2 + 0xbac + iVar9 * 4) <= 0.0)) ||
                ((*(char *)(iVar9 + 0x120 + *(int64_t *)0x180781f28) == '\0' ||
                 (fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0xbac + iVar9 * 4), fVar23 < 0.0)))) ||
               (((fVar23 != 0.0 &&
                 ((fVar23 <= *(float *)(*(int64_t *)0x180781f28 + 0xa8) ||
                  (iVar8 = func_0x000180107850(fVar23 - *(float *)(*(int64_t *)0x180781f28 + 0x48), iVar9, 
                                               *(float *)(*(int64_t *)0x180781f28 + 0xa8), 
                                               *(undefined4 *)(*(int64_t *)0x180781f28 + 0xac)), iVar8 < 1)))) ||
                (cVar5 = func_0x000180109b10((int32_t)iVar9 + 0x290, iVar19), cVar5 == '\0'))))
            goto code_r0x00018013a286;
            cVar20 = '\x01';
        } else {
code_r0x00018013a286:
            if (cVar20 == '\0') goto code_r0x00018013a2ad;
        }
        if (*(char *)(iVar2 + 0x7e) != '\0') {
            *(undefined *)(iVar2 + 0x21cc) = 0;
        }
    }
code_r0x00018013a2ad:
    if ((uVar1 & 0x40) != 0) goto code_r0x00018013a3aa;
    if ((((*(int32_t *)(iVar2 + 0x21d0) == iVar11) && (*(char *)(iVar2 + 0x21cc) != '\0')) &&
        (*(char *)(iVar2 + 0x21cd) != '\0')) && ((uVar16 >> 0x13 & 1) == 0)) {
        cVar4 = '\x01';
    }
    if (*(int32_t *)(iVar2 + 0x21f0) != iVar11) goto code_r0x00018013a3aa;
    bVar22 = *(int32_t *)(iVar2 + 0x21f4) == iVar11;
    if ((!bVar22) && ((uVar1 & 8) != 0)) {
        iVar9 = 0x914;
        if (*(char *)(iVar2 + 0x79) != '\0') {
            iVar9 = 0x8f4;
        }
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x204);
        if (*(float *)(*(int64_t *)0x180781f28 + 0x204) <= *(float *)(*(int64_t *)0x180781f28 + 0x214)) {
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x214);
        }
        if (fVar23 <= *(float *)(iVar9 + *(int64_t *)0x180781f28)) {
            fVar23 = *(float *)(iVar9 + *(int64_t *)0x180781f28);
        }
        iVar8 = func_0x000180107850(fVar23 - *(float *)(iVar2 + 0x48), 0x8f4, *(undefined4 *)(iVar2 + 0xa8), 
                                    *(undefined4 *)(iVar2 + 0xac));
        bVar22 = 0 < iVar8;
    }
    if ((*(int32_t *)(iVar2 + 0x21ec) != iVar11) && (!bVar22)) goto code_r0x00018013a3aa;
    cVar20 = '\x01';
    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
    *(undefined4 *)(iVar2 + 0x1674) = *(undefined4 *)(iVar2 + 0x2228);
    if ((uVar16 >> 0x12 & 1) == 0) {
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) {
            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
            goto code_r0x00018013a39a;
        }
    } else {
code_r0x00018013a39a:
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) goto code_r0x00018013a3aa;
    }
    *(undefined *)(iVar2 + 0x1666) = 1;
code_r0x00018013a3aa:
    uVar13 = 0;
    if (*(int32_t *)(iVar2 + 0x1654) == iVar11) {
        if (*(int32_t *)(iVar2 + 0x1674) == 1) {
            if (*(char *)(iVar2 + 0x1660) != '\0') {
                fVar23 = *(float *)arg1;
                *(float *)(iVar2 + 0x1670) = *(float *)(iVar2 + 0x11c) - *(float *)(arg1 + 4);
                *(float *)(iVar2 + 0x166c) = *(float *)(iVar2 + 0x118) - fVar23;
            }
            cVar5 = *(char *)(iVar2 + 0x1667);
            iVar18 = (int64_t)cVar5;
            if (cVar5 == -1) {
                func_0x0001800f9f30(0, 0);
            } else if ((*(char *)(iVar18 + 0x120 + *(int64_t *)0x180781f28) == '\0') ||
                      (cVar5 = func_0x000180109b10(cVar5 + 0x290, iVar19), cVar5 == '\0')) {
                if ((((cVar4 != '\0') && ((uVar16 & 0x20) != 0)) || ((uVar16 & 0x40) != 0)) &&
                   (*(char *)(iVar2 + 0x2400) == '\0')) {
                    if ((((uVar16 >> 8 & 1) == 0) || (*(char *)(iVar18 + 0xb6e + iVar2) == '\0')) ||
                       (*(int16_t *)(iVar2 + 0xb64 + iVar18 * 2) != 2)) {
                        bVar22 = false;
                    } else {
                        bVar22 = true;
                    }
                    if (((uVar1 & 8) == 0) || (*(float *)(iVar2 + 0xbc0 + iVar18 * 4) < *(float *)(iVar2 + 0xa8))) {
                        cVar5 = '\0';
                    } else {
                        cVar5 = '\x01';
                    }
                    cVar6 = func_0x000180109b10((int32_t)iVar18 + 0x290, iVar19);
                    if (((!bVar22) && (cVar5 == '\0')) && (cVar6 != '\0')) {
                        cVar20 = '\x01';
                    }
                }
                func_0x0001800f9f30(0, 0);
            } else {
                uVar13 = 1;
            }
            if (((uVar16 >> 0x12 & 1) == 0) && (*(char *)(iVar2 + 0x7e) != '\0')) {
                *(undefined *)(iVar2 + 0x21cc) = 0;
            }
        } else if (*(int32_t *)(iVar2 + 0x1674) - 2U < 2) {
            if (*(int32_t *)(iVar2 + 0x21f0) == iVar11) {
                uVar13 = 1;
            } else {
                func_0x0001800f9f30(0, 0);
            }
        }
        if (cVar20 != '\0') {
            *(undefined *)(iVar2 + 0x1663) = 1;
        }
    }
    if ((*(int32_t *)(iVar2 + 0x2210) == iVar11) && ((uVar1 & 0x40) == 0)) {
        cVar4 = '\x01';
    }
    if (arg3 != 0) {
        *(char *)arg3 = cVar4;
    }
    if (arg4 != 0) {
        *(undefined *)arg4 = uVar13;
    }
    return cVar20;
}

// ============================================================
// Function: FUN_18013a2ad
// Address: 0x18013a2ad
// Size: 696 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

char fcn.180139d40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_208h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    char cVar20;
    int32_t iVar21;
    bool bVar22;
    float fVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar11 = (int32_t)arg2;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar18 = *(int64_t *)(iVar2 + 0x15e0);
    iVar9 = 0x1fbc;
    if (*(int32_t *)(iVar2 + 0x1fb8) != iVar11) {
        iVar9 = 0x1f78;
    }
    uVar1 = *(uint32_t *)(iVar9 + iVar2);
    if (((uint32_t)arg_28h >> 0xc & 1) == 0) {
        uVar1 = *(uint32_t *)(iVar9 + iVar2);
    }
    uVar7 = (uint32_t)arg_28h | 0x440000;
    if ((uVar1 >> 0x11 & 1) == 0) {
        uVar7 = (uint32_t)arg_28h;
    }
    uVar16 = uVar7 | 1;
    if ((uVar7 & 7) != 0) {
        uVar16 = uVar7;
    }
    if ((uVar16 & 0x3f0) == 0) {
        uVar7 = 0x20;
        if ((uVar1 & 8) != 0) {
            uVar7 = 0x10;
        }
        uVar16 = uVar7 | uVar16;
    }
    iVar9 = *(int64_t *)(iVar2 + 0x15e8);
    if ((((uVar16 >> 0xb & 1) == 0) || (iVar9 == 0)) || (*(int64_t *)(iVar9 + 0x428) != *(int64_t *)(iVar18 + 0x428))) {
        bVar22 = false;
    } else {
        bVar22 = true;
        *(int64_t *)(iVar2 + 0x15e8) = iVar18;
    }
    cVar20 = '\0';
    cVar4 = func_0x0001800fa440(arg1, arg2 & 0xffffffff);
    if (*(char *)(iVar2 + 0x2400) != '\0') {
        if ((((uVar16 >> 9 & 1) != 0) && ((*(uint8_t *)(iVar2 + 0x2404) & 4) == 0)) &&
           (cVar5 = func_0x0001800fa150(0x80), iVar3 = *(int64_t *)0x180781f28, cVar5 != '\0')) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar11;
            *(undefined *)(iVar3 + 0x1650) = 0;
            if ((iVar11 != 0) && (*(int32_t *)(iVar3 + 0x1640) != iVar11)) {
                *(undefined8 *)(iVar3 + 0x1648) = 0;
            }
            cVar4 = '\x01';
            if ((*(float *)(iVar2 + 0x1648) - *(float *)(iVar2 + 0x48) <= 0.7) && (0.7 <= *(float *)(iVar2 + 0x1648))) {
                *(int32_t *)(iVar2 + 0x2490) = iVar11;
                cVar20 = '\x01';
                func_0x00018010e050(iVar18, 0);
                cVar4 = '\x01';
            }
        }
        if ((*(int32_t *)(iVar2 + 0x2488) == iVar11) && ((*(uint32_t *)(iVar2 + 0x247c) & 0x2000) != 0)) {
            cVar4 = '\x01';
        }
    }
    iVar17 = 1;
    iVar8 = 1;
    if (bVar22) {
        *(int64_t *)(iVar2 + 0x15e8) = iVar9;
    }
    iVar19 = iVar11;
    if ((uVar16 >> 0x15 & 1) != 0) {
        iVar19 = 0;
    }
    if (cVar4 != '\0') {
        iVar14 = -1;
        iVar15 = -1;
        iVar21 = -1;
        if ((uVar16 & 1) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            iVar15 = iVar14;
            iVar8 = iVar17;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbac))) &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xbac) == 0.0)) {
                iVar8 = 1;
                cVar5 = func_0x000180109b10(0x290);
                iVar15 = -1;
                if (cVar5 != '\0') {
                    iVar15 = 0;
                }
            }
            if (*(char *)(iVar9 + 0xb6e) != '\0') {
                cVar5 = func_0x000180109b10(0x290, iVar19);
                iVar21 = -1;
                if (cVar5 != '\0') {
                    iVar21 = 0;
                }
            }
        }
        if ((uVar16 & 2) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x121) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb0))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb0) == 0.0 &&
                ((cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb6f) != '\0') && (cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if ((uVar16 & 4) != 0) {
            iVar8 = 2;
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x122) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb4))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb4) == 0.0 &&
                ((iVar8 = 2, cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb70) != '\0') && (cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if (((uVar16 >> 0x10 & 1) == 0) ||
           (((*(char *)(iVar2 + 0x138) == '\0' && (*(char *)(iVar2 + 0x139) == '\0')) &&
            (*(char *)(iVar2 + 0x13a) == '\0')))) {
            if ((iVar15 == -1) || (*(int32_t *)(iVar2 + 0x1654) == iVar11)) {
                if ((char)uVar16 < '\0') goto code_r0x00018013a1a2;
            } else {
                if ((uVar16 >> 0x14 & 1) == 0) {
                    func_0x000180109bc0(iVar15 + 0x290, arg2 & 0xffffffff);
                }
                uVar13 = (undefined)iVar15;
                if ((uVar16 & 0x60) != 0) {
                    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a116;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a116:
                if (((uVar16 & 0x10) != 0) ||
                   (((uVar16 >> 8 & 1) != 0 && (*(int16_t *)(iVar2 + 0xb5a + (int64_t)iVar15 * 2) == 2)))) {
                    cVar20 = '\x01';
                    iVar9 = iVar18;
                    if ((uVar16 >> 0x11 & 1) != 0) {
                        iVar9 = 0;
                    }
                    uVar10 = 0;
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        uVar10 = arg2 & 0xffffffff;
                    }
                    func_0x0001800f9f30(uVar10, iVar9);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a17f;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a17f:
                if ((char)uVar16 < '\0') {
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    }
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
code_r0x00018013a1a2:
                    if (iVar21 != -1) {
                        if (((uVar1 & 8) == 0) ||
                           (*(float *)(iVar2 + 0xbc0 + (int64_t)iVar21 * 4) < *(float *)(iVar2 + 0xa8))) {
                            cVar20 = '\x01';
                        }
                        if ((uVar16 >> 0x12 & 1) == 0) {
                            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (((((*(int32_t *)(iVar2 + 0x1654) != iVar11) || ((uVar1 & 8) == 0)) ||
                 (iVar9 = (int64_t)*(char *)(iVar2 + 0x1667), *(float *)(iVar2 + 0xbac + iVar9 * 4) <= 0.0)) ||
                ((*(char *)(iVar9 + 0x120 + *(int64_t *)0x180781f28) == '\0' ||
                 (fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0xbac + iVar9 * 4), fVar23 < 0.0)))) ||
               (((fVar23 != 0.0 &&
                 ((fVar23 <= *(float *)(*(int64_t *)0x180781f28 + 0xa8) ||
                  (iVar8 = func_0x000180107850(fVar23 - *(float *)(*(int64_t *)0x180781f28 + 0x48), iVar9, 
                                               *(float *)(*(int64_t *)0x180781f28 + 0xa8), 
                                               *(undefined4 *)(*(int64_t *)0x180781f28 + 0xac)), iVar8 < 1)))) ||
                (cVar5 = func_0x000180109b10((int32_t)iVar9 + 0x290, iVar19), cVar5 == '\0'))))
            goto code_r0x00018013a286;
            cVar20 = '\x01';
        } else {
code_r0x00018013a286:
            if (cVar20 == '\0') goto code_r0x00018013a2ad;
        }
        if (*(char *)(iVar2 + 0x7e) != '\0') {
            *(undefined *)(iVar2 + 0x21cc) = 0;
        }
    }
code_r0x00018013a2ad:
    if ((uVar1 & 0x40) != 0) goto code_r0x00018013a3aa;
    if ((((*(int32_t *)(iVar2 + 0x21d0) == iVar11) && (*(char *)(iVar2 + 0x21cc) != '\0')) &&
        (*(char *)(iVar2 + 0x21cd) != '\0')) && ((uVar16 >> 0x13 & 1) == 0)) {
        cVar4 = '\x01';
    }
    if (*(int32_t *)(iVar2 + 0x21f0) != iVar11) goto code_r0x00018013a3aa;
    bVar22 = *(int32_t *)(iVar2 + 0x21f4) == iVar11;
    if ((!bVar22) && ((uVar1 & 8) != 0)) {
        iVar9 = 0x914;
        if (*(char *)(iVar2 + 0x79) != '\0') {
            iVar9 = 0x8f4;
        }
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x204);
        if (*(float *)(*(int64_t *)0x180781f28 + 0x204) <= *(float *)(*(int64_t *)0x180781f28 + 0x214)) {
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x214);
        }
        if (fVar23 <= *(float *)(iVar9 + *(int64_t *)0x180781f28)) {
            fVar23 = *(float *)(iVar9 + *(int64_t *)0x180781f28);
        }
        iVar8 = func_0x000180107850(fVar23 - *(float *)(iVar2 + 0x48), 0x8f4, *(undefined4 *)(iVar2 + 0xa8), 
                                    *(undefined4 *)(iVar2 + 0xac));
        bVar22 = 0 < iVar8;
    }
    if ((*(int32_t *)(iVar2 + 0x21ec) != iVar11) && (!bVar22)) goto code_r0x00018013a3aa;
    cVar20 = '\x01';
    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
    *(undefined4 *)(iVar2 + 0x1674) = *(undefined4 *)(iVar2 + 0x2228);
    if ((uVar16 >> 0x12 & 1) == 0) {
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) {
            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
            goto code_r0x00018013a39a;
        }
    } else {
code_r0x00018013a39a:
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) goto code_r0x00018013a3aa;
    }
    *(undefined *)(iVar2 + 0x1666) = 1;
code_r0x00018013a3aa:
    uVar13 = 0;
    if (*(int32_t *)(iVar2 + 0x1654) == iVar11) {
        if (*(int32_t *)(iVar2 + 0x1674) == 1) {
            if (*(char *)(iVar2 + 0x1660) != '\0') {
                fVar23 = *(float *)arg1;
                *(float *)(iVar2 + 0x1670) = *(float *)(iVar2 + 0x11c) - *(float *)(arg1 + 4);
                *(float *)(iVar2 + 0x166c) = *(float *)(iVar2 + 0x118) - fVar23;
            }
            cVar5 = *(char *)(iVar2 + 0x1667);
            iVar18 = (int64_t)cVar5;
            if (cVar5 == -1) {
                func_0x0001800f9f30(0, 0);
            } else if ((*(char *)(iVar18 + 0x120 + *(int64_t *)0x180781f28) == '\0') ||
                      (cVar5 = func_0x000180109b10(cVar5 + 0x290, iVar19), cVar5 == '\0')) {
                if ((((cVar4 != '\0') && ((uVar16 & 0x20) != 0)) || ((uVar16 & 0x40) != 0)) &&
                   (*(char *)(iVar2 + 0x2400) == '\0')) {
                    if ((((uVar16 >> 8 & 1) == 0) || (*(char *)(iVar18 + 0xb6e + iVar2) == '\0')) ||
                       (*(int16_t *)(iVar2 + 0xb64 + iVar18 * 2) != 2)) {
                        bVar22 = false;
                    } else {
                        bVar22 = true;
                    }
                    if (((uVar1 & 8) == 0) || (*(float *)(iVar2 + 0xbc0 + iVar18 * 4) < *(float *)(iVar2 + 0xa8))) {
                        cVar5 = '\0';
                    } else {
                        cVar5 = '\x01';
                    }
                    cVar6 = func_0x000180109b10((int32_t)iVar18 + 0x290, iVar19);
                    if (((!bVar22) && (cVar5 == '\0')) && (cVar6 != '\0')) {
                        cVar20 = '\x01';
                    }
                }
                func_0x0001800f9f30(0, 0);
            } else {
                uVar13 = 1;
            }
            if (((uVar16 >> 0x12 & 1) == 0) && (*(char *)(iVar2 + 0x7e) != '\0')) {
                *(undefined *)(iVar2 + 0x21cc) = 0;
            }
        } else if (*(int32_t *)(iVar2 + 0x1674) - 2U < 2) {
            if (*(int32_t *)(iVar2 + 0x21f0) == iVar11) {
                uVar13 = 1;
            } else {
                func_0x0001800f9f30(0, 0);
            }
        }
        if (cVar20 != '\0') {
            *(undefined *)(iVar2 + 0x1663) = 1;
        }
    }
    if ((*(int32_t *)(iVar2 + 0x2210) == iVar11) && ((uVar1 & 0x40) == 0)) {
        cVar4 = '\x01';
    }
    if (arg3 != 0) {
        *(char *)arg3 = cVar4;
    }
    if (arg4 != 0) {
        *(undefined *)arg4 = uVar13;
    }
    return cVar20;
}

// ============================================================
// Function: FUN_18013a565
// Address: 0x18013a565
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

char fcn.180139d40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_208h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    char cVar20;
    int32_t iVar21;
    bool bVar22;
    float fVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar11 = (int32_t)arg2;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar18 = *(int64_t *)(iVar2 + 0x15e0);
    iVar9 = 0x1fbc;
    if (*(int32_t *)(iVar2 + 0x1fb8) != iVar11) {
        iVar9 = 0x1f78;
    }
    uVar1 = *(uint32_t *)(iVar9 + iVar2);
    if (((uint32_t)arg_28h >> 0xc & 1) == 0) {
        uVar1 = *(uint32_t *)(iVar9 + iVar2);
    }
    uVar7 = (uint32_t)arg_28h | 0x440000;
    if ((uVar1 >> 0x11 & 1) == 0) {
        uVar7 = (uint32_t)arg_28h;
    }
    uVar16 = uVar7 | 1;
    if ((uVar7 & 7) != 0) {
        uVar16 = uVar7;
    }
    if ((uVar16 & 0x3f0) == 0) {
        uVar7 = 0x20;
        if ((uVar1 & 8) != 0) {
            uVar7 = 0x10;
        }
        uVar16 = uVar7 | uVar16;
    }
    iVar9 = *(int64_t *)(iVar2 + 0x15e8);
    if ((((uVar16 >> 0xb & 1) == 0) || (iVar9 == 0)) || (*(int64_t *)(iVar9 + 0x428) != *(int64_t *)(iVar18 + 0x428))) {
        bVar22 = false;
    } else {
        bVar22 = true;
        *(int64_t *)(iVar2 + 0x15e8) = iVar18;
    }
    cVar20 = '\0';
    cVar4 = func_0x0001800fa440(arg1, arg2 & 0xffffffff);
    if (*(char *)(iVar2 + 0x2400) != '\0') {
        if ((((uVar16 >> 9 & 1) != 0) && ((*(uint8_t *)(iVar2 + 0x2404) & 4) == 0)) &&
           (cVar5 = func_0x0001800fa150(0x80), iVar3 = *(int64_t *)0x180781f28, cVar5 != '\0')) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar11;
            *(undefined *)(iVar3 + 0x1650) = 0;
            if ((iVar11 != 0) && (*(int32_t *)(iVar3 + 0x1640) != iVar11)) {
                *(undefined8 *)(iVar3 + 0x1648) = 0;
            }
            cVar4 = '\x01';
            if ((*(float *)(iVar2 + 0x1648) - *(float *)(iVar2 + 0x48) <= 0.7) && (0.7 <= *(float *)(iVar2 + 0x1648))) {
                *(int32_t *)(iVar2 + 0x2490) = iVar11;
                cVar20 = '\x01';
                func_0x00018010e050(iVar18, 0);
                cVar4 = '\x01';
            }
        }
        if ((*(int32_t *)(iVar2 + 0x2488) == iVar11) && ((*(uint32_t *)(iVar2 + 0x247c) & 0x2000) != 0)) {
            cVar4 = '\x01';
        }
    }
    iVar17 = 1;
    iVar8 = 1;
    if (bVar22) {
        *(int64_t *)(iVar2 + 0x15e8) = iVar9;
    }
    iVar19 = iVar11;
    if ((uVar16 >> 0x15 & 1) != 0) {
        iVar19 = 0;
    }
    if (cVar4 != '\0') {
        iVar14 = -1;
        iVar15 = -1;
        iVar21 = -1;
        if ((uVar16 & 1) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            iVar15 = iVar14;
            iVar8 = iVar17;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbac))) &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xbac) == 0.0)) {
                iVar8 = 1;
                cVar5 = func_0x000180109b10(0x290);
                iVar15 = -1;
                if (cVar5 != '\0') {
                    iVar15 = 0;
                }
            }
            if (*(char *)(iVar9 + 0xb6e) != '\0') {
                cVar5 = func_0x000180109b10(0x290, iVar19);
                iVar21 = -1;
                if (cVar5 != '\0') {
                    iVar21 = 0;
                }
            }
        }
        if ((uVar16 & 2) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x121) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb0))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb0) == 0.0 &&
                ((cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb6f) != '\0') && (cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if ((uVar16 & 4) != 0) {
            iVar8 = 2;
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x122) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb4))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb4) == 0.0 &&
                ((iVar8 = 2, cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb70) != '\0') && (cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if (((uVar16 >> 0x10 & 1) == 0) ||
           (((*(char *)(iVar2 + 0x138) == '\0' && (*(char *)(iVar2 + 0x139) == '\0')) &&
            (*(char *)(iVar2 + 0x13a) == '\0')))) {
            if ((iVar15 == -1) || (*(int32_t *)(iVar2 + 0x1654) == iVar11)) {
                if ((char)uVar16 < '\0') goto code_r0x00018013a1a2;
            } else {
                if ((uVar16 >> 0x14 & 1) == 0) {
                    func_0x000180109bc0(iVar15 + 0x290, arg2 & 0xffffffff);
                }
                uVar13 = (undefined)iVar15;
                if ((uVar16 & 0x60) != 0) {
                    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a116;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a116:
                if (((uVar16 & 0x10) != 0) ||
                   (((uVar16 >> 8 & 1) != 0 && (*(int16_t *)(iVar2 + 0xb5a + (int64_t)iVar15 * 2) == 2)))) {
                    cVar20 = '\x01';
                    iVar9 = iVar18;
                    if ((uVar16 >> 0x11 & 1) != 0) {
                        iVar9 = 0;
                    }
                    uVar10 = 0;
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        uVar10 = arg2 & 0xffffffff;
                    }
                    func_0x0001800f9f30(uVar10, iVar9);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a17f;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a17f:
                if ((char)uVar16 < '\0') {
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    }
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
code_r0x00018013a1a2:
                    if (iVar21 != -1) {
                        if (((uVar1 & 8) == 0) ||
                           (*(float *)(iVar2 + 0xbc0 + (int64_t)iVar21 * 4) < *(float *)(iVar2 + 0xa8))) {
                            cVar20 = '\x01';
                        }
                        if ((uVar16 >> 0x12 & 1) == 0) {
                            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (((((*(int32_t *)(iVar2 + 0x1654) != iVar11) || ((uVar1 & 8) == 0)) ||
                 (iVar9 = (int64_t)*(char *)(iVar2 + 0x1667), *(float *)(iVar2 + 0xbac + iVar9 * 4) <= 0.0)) ||
                ((*(char *)(iVar9 + 0x120 + *(int64_t *)0x180781f28) == '\0' ||
                 (fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0xbac + iVar9 * 4), fVar23 < 0.0)))) ||
               (((fVar23 != 0.0 &&
                 ((fVar23 <= *(float *)(*(int64_t *)0x180781f28 + 0xa8) ||
                  (iVar8 = func_0x000180107850(fVar23 - *(float *)(*(int64_t *)0x180781f28 + 0x48), iVar9, 
                                               *(float *)(*(int64_t *)0x180781f28 + 0xa8), 
                                               *(undefined4 *)(*(int64_t *)0x180781f28 + 0xac)), iVar8 < 1)))) ||
                (cVar5 = func_0x000180109b10((int32_t)iVar9 + 0x290, iVar19), cVar5 == '\0'))))
            goto code_r0x00018013a286;
            cVar20 = '\x01';
        } else {
code_r0x00018013a286:
            if (cVar20 == '\0') goto code_r0x00018013a2ad;
        }
        if (*(char *)(iVar2 + 0x7e) != '\0') {
            *(undefined *)(iVar2 + 0x21cc) = 0;
        }
    }
code_r0x00018013a2ad:
    if ((uVar1 & 0x40) != 0) goto code_r0x00018013a3aa;
    if ((((*(int32_t *)(iVar2 + 0x21d0) == iVar11) && (*(char *)(iVar2 + 0x21cc) != '\0')) &&
        (*(char *)(iVar2 + 0x21cd) != '\0')) && ((uVar16 >> 0x13 & 1) == 0)) {
        cVar4 = '\x01';
    }
    if (*(int32_t *)(iVar2 + 0x21f0) != iVar11) goto code_r0x00018013a3aa;
    bVar22 = *(int32_t *)(iVar2 + 0x21f4) == iVar11;
    if ((!bVar22) && ((uVar1 & 8) != 0)) {
        iVar9 = 0x914;
        if (*(char *)(iVar2 + 0x79) != '\0') {
            iVar9 = 0x8f4;
        }
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x204);
        if (*(float *)(*(int64_t *)0x180781f28 + 0x204) <= *(float *)(*(int64_t *)0x180781f28 + 0x214)) {
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x214);
        }
        if (fVar23 <= *(float *)(iVar9 + *(int64_t *)0x180781f28)) {
            fVar23 = *(float *)(iVar9 + *(int64_t *)0x180781f28);
        }
        iVar8 = func_0x000180107850(fVar23 - *(float *)(iVar2 + 0x48), 0x8f4, *(undefined4 *)(iVar2 + 0xa8), 
                                    *(undefined4 *)(iVar2 + 0xac));
        bVar22 = 0 < iVar8;
    }
    if ((*(int32_t *)(iVar2 + 0x21ec) != iVar11) && (!bVar22)) goto code_r0x00018013a3aa;
    cVar20 = '\x01';
    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
    *(undefined4 *)(iVar2 + 0x1674) = *(undefined4 *)(iVar2 + 0x2228);
    if ((uVar16 >> 0x12 & 1) == 0) {
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) {
            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
            goto code_r0x00018013a39a;
        }
    } else {
code_r0x00018013a39a:
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) goto code_r0x00018013a3aa;
    }
    *(undefined *)(iVar2 + 0x1666) = 1;
code_r0x00018013a3aa:
    uVar13 = 0;
    if (*(int32_t *)(iVar2 + 0x1654) == iVar11) {
        if (*(int32_t *)(iVar2 + 0x1674) == 1) {
            if (*(char *)(iVar2 + 0x1660) != '\0') {
                fVar23 = *(float *)arg1;
                *(float *)(iVar2 + 0x1670) = *(float *)(iVar2 + 0x11c) - *(float *)(arg1 + 4);
                *(float *)(iVar2 + 0x166c) = *(float *)(iVar2 + 0x118) - fVar23;
            }
            cVar5 = *(char *)(iVar2 + 0x1667);
            iVar18 = (int64_t)cVar5;
            if (cVar5 == -1) {
                func_0x0001800f9f30(0, 0);
            } else if ((*(char *)(iVar18 + 0x120 + *(int64_t *)0x180781f28) == '\0') ||
                      (cVar5 = func_0x000180109b10(cVar5 + 0x290, iVar19), cVar5 == '\0')) {
                if ((((cVar4 != '\0') && ((uVar16 & 0x20) != 0)) || ((uVar16 & 0x40) != 0)) &&
                   (*(char *)(iVar2 + 0x2400) == '\0')) {
                    if ((((uVar16 >> 8 & 1) == 0) || (*(char *)(iVar18 + 0xb6e + iVar2) == '\0')) ||
                       (*(int16_t *)(iVar2 + 0xb64 + iVar18 * 2) != 2)) {
                        bVar22 = false;
                    } else {
                        bVar22 = true;
                    }
                    if (((uVar1 & 8) == 0) || (*(float *)(iVar2 + 0xbc0 + iVar18 * 4) < *(float *)(iVar2 + 0xa8))) {
                        cVar5 = '\0';
                    } else {
                        cVar5 = '\x01';
                    }
                    cVar6 = func_0x000180109b10((int32_t)iVar18 + 0x290, iVar19);
                    if (((!bVar22) && (cVar5 == '\0')) && (cVar6 != '\0')) {
                        cVar20 = '\x01';
                    }
                }
                func_0x0001800f9f30(0, 0);
            } else {
                uVar13 = 1;
            }
            if (((uVar16 >> 0x12 & 1) == 0) && (*(char *)(iVar2 + 0x7e) != '\0')) {
                *(undefined *)(iVar2 + 0x21cc) = 0;
            }
        } else if (*(int32_t *)(iVar2 + 0x1674) - 2U < 2) {
            if (*(int32_t *)(iVar2 + 0x21f0) == iVar11) {
                uVar13 = 1;
            } else {
                func_0x0001800f9f30(0, 0);
            }
        }
        if (cVar20 != '\0') {
            *(undefined *)(iVar2 + 0x1663) = 1;
        }
    }
    if ((*(int32_t *)(iVar2 + 0x2210) == iVar11) && ((uVar1 & 0x40) == 0)) {
        cVar4 = '\x01';
    }
    if (arg3 != 0) {
        *(char *)arg3 = cVar4;
    }
    if (arg4 != 0) {
        *(undefined *)arg4 = uVar13;
    }
    return cVar20;
}

// ============================================================
// Function: FUN_18013a597
// Address: 0x18013a597
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

char fcn.180139d40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_208h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    undefined8 uVar12;
    undefined uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t iVar18;
    int32_t iVar19;
    char cVar20;
    int32_t iVar21;
    bool bVar22;
    float fVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar11 = (int32_t)arg2;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar18 = *(int64_t *)(iVar2 + 0x15e0);
    iVar9 = 0x1fbc;
    if (*(int32_t *)(iVar2 + 0x1fb8) != iVar11) {
        iVar9 = 0x1f78;
    }
    uVar1 = *(uint32_t *)(iVar9 + iVar2);
    if (((uint32_t)arg_28h >> 0xc & 1) == 0) {
        uVar1 = *(uint32_t *)(iVar9 + iVar2);
    }
    uVar7 = (uint32_t)arg_28h | 0x440000;
    if ((uVar1 >> 0x11 & 1) == 0) {
        uVar7 = (uint32_t)arg_28h;
    }
    uVar16 = uVar7 | 1;
    if ((uVar7 & 7) != 0) {
        uVar16 = uVar7;
    }
    if ((uVar16 & 0x3f0) == 0) {
        uVar7 = 0x20;
        if ((uVar1 & 8) != 0) {
            uVar7 = 0x10;
        }
        uVar16 = uVar7 | uVar16;
    }
    iVar9 = *(int64_t *)(iVar2 + 0x15e8);
    if ((((uVar16 >> 0xb & 1) == 0) || (iVar9 == 0)) || (*(int64_t *)(iVar9 + 0x428) != *(int64_t *)(iVar18 + 0x428))) {
        bVar22 = false;
    } else {
        bVar22 = true;
        *(int64_t *)(iVar2 + 0x15e8) = iVar18;
    }
    cVar20 = '\0';
    cVar4 = func_0x0001800fa440(arg1, arg2 & 0xffffffff);
    if (*(char *)(iVar2 + 0x2400) != '\0') {
        if ((((uVar16 >> 9 & 1) != 0) && ((*(uint8_t *)(iVar2 + 0x2404) & 4) == 0)) &&
           (cVar5 = func_0x0001800fa150(0x80), iVar3 = *(int64_t *)0x180781f28, cVar5 != '\0')) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) = iVar11;
            *(undefined *)(iVar3 + 0x1650) = 0;
            if ((iVar11 != 0) && (*(int32_t *)(iVar3 + 0x1640) != iVar11)) {
                *(undefined8 *)(iVar3 + 0x1648) = 0;
            }
            cVar4 = '\x01';
            if ((*(float *)(iVar2 + 0x1648) - *(float *)(iVar2 + 0x48) <= 0.7) && (0.7 <= *(float *)(iVar2 + 0x1648))) {
                *(int32_t *)(iVar2 + 0x2490) = iVar11;
                cVar20 = '\x01';
                func_0x00018010e050(iVar18, 0);
                cVar4 = '\x01';
            }
        }
        if ((*(int32_t *)(iVar2 + 0x2488) == iVar11) && ((*(uint32_t *)(iVar2 + 0x247c) & 0x2000) != 0)) {
            cVar4 = '\x01';
        }
    }
    iVar17 = 1;
    iVar8 = 1;
    if (bVar22) {
        *(int64_t *)(iVar2 + 0x15e8) = iVar9;
    }
    iVar19 = iVar11;
    if ((uVar16 >> 0x15 & 1) != 0) {
        iVar19 = 0;
    }
    if (cVar4 != '\0') {
        iVar14 = -1;
        iVar15 = -1;
        iVar21 = -1;
        if ((uVar16 & 1) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            iVar15 = iVar14;
            iVar8 = iVar17;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbac))) &&
               (*(float *)(*(int64_t *)0x180781f28 + 0xbac) == 0.0)) {
                iVar8 = 1;
                cVar5 = func_0x000180109b10(0x290);
                iVar15 = -1;
                if (cVar5 != '\0') {
                    iVar15 = 0;
                }
            }
            if (*(char *)(iVar9 + 0xb6e) != '\0') {
                cVar5 = func_0x000180109b10(0x290, iVar19);
                iVar21 = -1;
                if (cVar5 != '\0') {
                    iVar21 = 0;
                }
            }
        }
        if ((uVar16 & 2) != 0) {
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x121) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb0))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb0) == 0.0 &&
                ((cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb6f) != '\0') && (cVar5 = func_0x000180109b10(0x291, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if ((uVar16 & 4) != 0) {
            iVar8 = 2;
            iVar9 = *(int64_t *)0x180781f28;
            if (((*(char *)(*(int64_t *)0x180781f28 + 0x122) != '\0') &&
                (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbb4))) &&
               ((*(float *)(*(int64_t *)0x180781f28 + 0xbb4) == 0.0 &&
                ((iVar8 = 2, cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0' && (iVar15 == -1)))))) {
                iVar15 = iVar8;
            }
            if (((*(char *)(iVar9 + 0xb70) != '\0') && (cVar5 = func_0x000180109b10(0x292, iVar19), cVar5 != '\0')) &&
               (iVar21 == -1)) {
                iVar21 = iVar8;
            }
        }
        if (((uVar16 >> 0x10 & 1) == 0) ||
           (((*(char *)(iVar2 + 0x138) == '\0' && (*(char *)(iVar2 + 0x139) == '\0')) &&
            (*(char *)(iVar2 + 0x13a) == '\0')))) {
            if ((iVar15 == -1) || (*(int32_t *)(iVar2 + 0x1654) == iVar11)) {
                if ((char)uVar16 < '\0') goto code_r0x00018013a1a2;
            } else {
                if ((uVar16 >> 0x14 & 1) == 0) {
                    func_0x000180109bc0(iVar15 + 0x290, arg2 & 0xffffffff);
                }
                uVar13 = (undefined)iVar15;
                if ((uVar16 & 0x60) != 0) {
                    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a116;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a116:
                if (((uVar16 & 0x10) != 0) ||
                   (((uVar16 >> 8 & 1) != 0 && (*(int16_t *)(iVar2 + 0xb5a + (int64_t)iVar15 * 2) == 2)))) {
                    cVar20 = '\x01';
                    iVar9 = iVar18;
                    if ((uVar16 >> 0x11 & 1) != 0) {
                        iVar9 = 0;
                    }
                    uVar10 = 0;
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        uVar10 = arg2 & 0xffffffff;
                    }
                    func_0x0001800f9f30(uVar10, iVar9);
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
                    if ((uVar16 >> 0x12 & 1) == 0) {
                        func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        uVar12 = 0;
                    } else {
                        if ((uVar16 >> 0x16 & 1) != 0) goto code_r0x00018013a17f;
                        uVar12 = 1;
                    }
                    func_0x00018010e050(iVar18, uVar12);
                }
code_r0x00018013a17f:
                if ((char)uVar16 < '\0') {
                    if ((uVar16 >> 0x11 & 1) == 0) {
                        func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
                    }
                    *(undefined *)(iVar2 + 0x1667) = uVar13;
code_r0x00018013a1a2:
                    if (iVar21 != -1) {
                        if (((uVar1 & 8) == 0) ||
                           (*(float *)(iVar2 + 0xbc0 + (int64_t)iVar21 * 4) < *(float *)(iVar2 + 0xa8))) {
                            cVar20 = '\x01';
                        }
                        if ((uVar16 >> 0x12 & 1) == 0) {
                            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if (((((*(int32_t *)(iVar2 + 0x1654) != iVar11) || ((uVar1 & 8) == 0)) ||
                 (iVar9 = (int64_t)*(char *)(iVar2 + 0x1667), *(float *)(iVar2 + 0xbac + iVar9 * 4) <= 0.0)) ||
                ((*(char *)(iVar9 + 0x120 + *(int64_t *)0x180781f28) == '\0' ||
                 (fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0xbac + iVar9 * 4), fVar23 < 0.0)))) ||
               (((fVar23 != 0.0 &&
                 ((fVar23 <= *(float *)(*(int64_t *)0x180781f28 + 0xa8) ||
                  (iVar8 = func_0x000180107850(fVar23 - *(float *)(*(int64_t *)0x180781f28 + 0x48), iVar9, 
                                               *(float *)(*(int64_t *)0x180781f28 + 0xa8), 
                                               *(undefined4 *)(*(int64_t *)0x180781f28 + 0xac)), iVar8 < 1)))) ||
                (cVar5 = func_0x000180109b10((int32_t)iVar9 + 0x290, iVar19), cVar5 == '\0'))))
            goto code_r0x00018013a286;
            cVar20 = '\x01';
        } else {
code_r0x00018013a286:
            if (cVar20 == '\0') goto code_r0x00018013a2ad;
        }
        if (*(char *)(iVar2 + 0x7e) != '\0') {
            *(undefined *)(iVar2 + 0x21cc) = 0;
        }
    }
code_r0x00018013a2ad:
    if ((uVar1 & 0x40) != 0) goto code_r0x00018013a3aa;
    if ((((*(int32_t *)(iVar2 + 0x21d0) == iVar11) && (*(char *)(iVar2 + 0x21cc) != '\0')) &&
        (*(char *)(iVar2 + 0x21cd) != '\0')) && ((uVar16 >> 0x13 & 1) == 0)) {
        cVar4 = '\x01';
    }
    if (*(int32_t *)(iVar2 + 0x21f0) != iVar11) goto code_r0x00018013a3aa;
    bVar22 = *(int32_t *)(iVar2 + 0x21f4) == iVar11;
    if ((!bVar22) && ((uVar1 & 8) != 0)) {
        iVar9 = 0x914;
        if (*(char *)(iVar2 + 0x79) != '\0') {
            iVar9 = 0x8f4;
        }
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x204);
        if (*(float *)(*(int64_t *)0x180781f28 + 0x204) <= *(float *)(*(int64_t *)0x180781f28 + 0x214)) {
            fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x214);
        }
        if (fVar23 <= *(float *)(iVar9 + *(int64_t *)0x180781f28)) {
            fVar23 = *(float *)(iVar9 + *(int64_t *)0x180781f28);
        }
        iVar8 = func_0x000180107850(fVar23 - *(float *)(iVar2 + 0x48), 0x8f4, *(undefined4 *)(iVar2 + 0xa8), 
                                    *(undefined4 *)(iVar2 + 0xac));
        bVar22 = 0 < iVar8;
    }
    if ((*(int32_t *)(iVar2 + 0x21ec) != iVar11) && (!bVar22)) goto code_r0x00018013a3aa;
    cVar20 = '\x01';
    func_0x0001800f9f30(arg2 & 0xffffffff, iVar18);
    *(undefined4 *)(iVar2 + 0x1674) = *(undefined4 *)(iVar2 + 0x2228);
    if ((uVar16 >> 0x12 & 1) == 0) {
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) {
            func_0x00018010e4a0(arg2 & 0xffffffff, iVar18);
            goto code_r0x00018013a39a;
        }
    } else {
code_r0x00018013a39a:
        if ((*(uint8_t *)(iVar2 + 0x21f8) & 0x10) == 0) goto code_r0x00018013a3aa;
    }
    *(undefined *)(iVar2 + 0x1666) = 1;
code_r0x00018013a3aa:
    uVar13 = 0;
    if (*(int32_t *)(iVar2 + 0x1654) == iVar11) {
        if (*(int32_t *)(iVar2 + 0x1674) == 1) {
            if (*(char *)(iVar2 + 0x1660) != '\0') {
                fVar23 = *(float *)arg1;
                *(float *)(iVar2 + 0x1670) = *(float *)(iVar2 + 0x11c) - *(float *)(arg1 + 4);
                *(float *)(iVar2 + 0x166c) = *(float *)(iVar2 + 0x118) - fVar23;
            }
            cVar5 = *(char *)(iVar2 + 0x1667);
            iVar18 = (int64_t)cVar5;
            if (cVar5 == -1) {
                func_0x0001800f9f30(0, 0);
            } else if ((*(char *)(iVar18 + 0x120 + *(int64_t *)0x180781f28) == '\0') ||
                      (cVar5 = func_0x000180109b10(cVar5 + 0x290, iVar19), cVar5 == '\0')) {
                if ((((cVar4 != '\0') && ((uVar16 & 0x20) != 0)) || ((uVar16 & 0x40) != 0)) &&
                   (*(char *)(iVar2 + 0x2400) == '\0')) {
                    if ((((uVar16 >> 8 & 1) == 0) || (*(char *)(iVar18 + 0xb6e + iVar2) == '\0')) ||
                       (*(int16_t *)(iVar2 + 0xb64 + iVar18 * 2) != 2)) {
                        bVar22 = false;
                    } else {
                        bVar22 = true;
                    }
                    if (((uVar1 & 8) == 0) || (*(float *)(iVar2 + 0xbc0 + iVar18 * 4) < *(float *)(iVar2 + 0xa8))) {
                        cVar5 = '\0';
                    } else {
                        cVar5 = '\x01';
                    }
                    cVar6 = func_0x000180109b10((int32_t)iVar18 + 0x290, iVar19);
                    if (((!bVar22) && (cVar5 == '\0')) && (cVar6 != '\0')) {
                        cVar20 = '\x01';
                    }
                }
                func_0x0001800f9f30(0, 0);
            } else {
                uVar13 = 1;
            }
            if (((uVar16 >> 0x12 & 1) == 0) && (*(char *)(iVar2 + 0x7e) != '\0')) {
                *(undefined *)(iVar2 + 0x21cc) = 0;
            }
        } else if (*(int32_t *)(iVar2 + 0x1674) - 2U < 2) {
            if (*(int32_t *)(iVar2 + 0x21f0) == iVar11) {
                uVar13 = 1;
            } else {
                func_0x0001800f9f30(0, 0);
            }
        }
        if (cVar20 != '\0') {
            *(undefined *)(iVar2 + 0x1663) = 1;
        }
    }
    if ((*(int32_t *)(iVar2 + 0x2210) == iVar11) && ((uVar1 & 0x40) == 0)) {
        cVar4 = '\x01';
    }
    if (arg3 != 0) {
        *(char *)arg3 = cVar4;
    }
    if (arg4 != 0) {
        *(undefined *)arg4 = uVar13;
    }
    return cVar20;
}

// ============================================================
// Function: FUN_18013a5c0
// Address: 0x18013a5c0
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_39h
// WARNING: Variable defined which should be unmapped: var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_25h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013a5c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char *pcVar1;
    float *pfVar2;
    int64_t iVar3;
    uint8_t uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    char *pcVar9;
    char acStackX_20 [8];
    int64_t in_stack_00000118;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    char acStack_a8 [8];
    float fStack_a0;
    float fStack_9c;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    float fStack_88;
    float fStack_84;
    float fStack_80;
    float fStack_7c;
    float fStack_78;
    float fStack_74;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_39h;
    int64_t var_21h;
    
    iVar3 = *(int64_t *)0x180781f28;
    uVar7 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar7 + 0x10b) = 1;
    iVar8 = *(int64_t *)(iVar3 + 0x15e0);
    if (*(char *)(iVar8 + 0x10e) == '\0') {
        uVar5 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                              (*(int64_t *)(iVar8 + 0x150) + -4 +
                                              (int64_t)*(int32_t *)(iVar8 + 0x148) * 4));
        pcVar9 = (char *)arg1;
        if (arg1 != -1) {
            while (*pcVar9 != '\0') {
                pcVar1 = pcVar9 + 1;
                if (((*pcVar9 == '#') && (*pcVar1 == '#')) || (pcVar9 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
                break;
            }
        }
        var_c8h = CONCAT44(var_c8h._4_4_, 0xbf800000);
        func_0x0001800fe0a0(&fStack_98, arg1, pcVar9, 0, var_c8h);
        fStack_80 = *(float *)(iVar8 + 0x158);
        fStack_7c = *(float *)(iVar8 + 0x15c);
        if (((uint32_t)arg3 >> 0xf & 1) != 0) {
            if (*(float *)(iVar3 + 0xde0) < *(float *)(iVar8 + 400)) {
                fStack_7c = (*(float *)(iVar8 + 400) - *(float *)(iVar3 + 0xde0)) + fStack_7c;
            }
        }
        func_0x00018010be90(&fStack_a0, *(undefined8 *)arg2, 
                            *(float *)(iVar3 + 0xddc) + *(float *)(iVar3 + 0xddc) + fStack_98, 
                            *(float *)(iVar3 + 0xde0) + *(float *)(iVar3 + 0xde0) + fStack_94);
        fStack_78 = fStack_80 + fStack_a0;
        fStack_74 = fStack_7c + fStack_9c;
        func_0x00018010bbf0(&fStack_a0, *(undefined4 *)(iVar3 + 0xde0));
        uVar7 = func_0x00018010b530(&fStack_80, uVar5, 0, 0);
        if ((char)uVar7 != '\0') {
            var_c8h = CONCAT44(var_c8h._4_4_, (uint32_t)arg3);
            uVar4 = fcn.180139d40((int64_t)&fStack_80, (uint64_t)uVar5, (int64_t)acStackX_20, (int64_t)acStack_a8, 
                                  var_c8h, in_stack_00000118);
            if ((acStack_a8[0] == '\0') || (acStackX_20[0] == '\0')) {
                iVar8 = (uint64_t)(acStackX_20[0] != '\0') + 0x15;
            } else {
                iVar8 = 0x17;
            }
            pfVar2 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar8 + 0x14) * 0x10);
            fStack_90 = *pfVar2;
            fStack_8c = pfVar2[1];
            fStack_88 = pfVar2[2];
            fStack_84 = pfVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            func_0x0001800f7d00(&fStack_80, uVar5, 0);
            uVar6 = func_0x0001800f5fa0(&fStack_90);
            var_c8h = CONCAT44(var_c8h._4_4_, *(undefined4 *)(iVar3 + 0xde4));
            func_0x0001800f7a00(CONCAT44(fStack_7c, fStack_80), CONCAT44(fStack_74, fStack_78), uVar6, 1, var_c8h);
            iVar8 = *(int64_t *)0x180781f28;
            if (*(char *)(iVar3 + 0x29f8) != '\0') {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1805ab2b8;
                *(undefined8 *)(iVar8 + 0x2a28) = 0x18063e184;
            }
            fStack_a0 = fStack_78 - *(float *)(iVar3 + 0xddc);
            fStack_90 = *(float *)(iVar3 + 0xddc) + fStack_80;
            fStack_9c = fStack_74 - *(float *)(iVar3 + 0xde0);
            fStack_8c = *(float *)(iVar3 + 0xde0) + fStack_7c;
            func_0x0001800f7200(&fStack_90, &fStack_a0, arg1, pcVar9, &fStack_98, iVar3 + 0xe80, &fStack_80);
            return (uint64_t)uVar4;
        }
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18013a61c
// Address: 0x18013a61c
// Size: 293 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_39h
// WARNING: Variable defined which should be unmapped: var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_25h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013a5c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char *pcVar1;
    float *pfVar2;
    int64_t iVar3;
    uint8_t uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    char *pcVar9;
    char acStackX_20 [8];
    int64_t in_stack_00000118;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    char acStack_a8 [8];
    float fStack_a0;
    float fStack_9c;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    float fStack_88;
    float fStack_84;
    float fStack_80;
    float fStack_7c;
    float fStack_78;
    float fStack_74;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_39h;
    int64_t var_21h;
    
    iVar3 = *(int64_t *)0x180781f28;
    uVar7 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar7 + 0x10b) = 1;
    iVar8 = *(int64_t *)(iVar3 + 0x15e0);
    if (*(char *)(iVar8 + 0x10e) == '\0') {
        uVar5 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                              (*(int64_t *)(iVar8 + 0x150) + -4 +
                                              (int64_t)*(int32_t *)(iVar8 + 0x148) * 4));
        pcVar9 = (char *)arg1;
        if (arg1 != -1) {
            while (*pcVar9 != '\0') {
                pcVar1 = pcVar9 + 1;
                if (((*pcVar9 == '#') && (*pcVar1 == '#')) || (pcVar9 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
                break;
            }
        }
        var_c8h = CONCAT44(var_c8h._4_4_, 0xbf800000);
        func_0x0001800fe0a0(&fStack_98, arg1, pcVar9, 0, var_c8h);
        fStack_80 = *(float *)(iVar8 + 0x158);
        fStack_7c = *(float *)(iVar8 + 0x15c);
        if (((uint32_t)arg3 >> 0xf & 1) != 0) {
            if (*(float *)(iVar3 + 0xde0) < *(float *)(iVar8 + 400)) {
                fStack_7c = (*(float *)(iVar8 + 400) - *(float *)(iVar3 + 0xde0)) + fStack_7c;
            }
        }
        func_0x00018010be90(&fStack_a0, *(undefined8 *)arg2, 
                            *(float *)(iVar3 + 0xddc) + *(float *)(iVar3 + 0xddc) + fStack_98, 
                            *(float *)(iVar3 + 0xde0) + *(float *)(iVar3 + 0xde0) + fStack_94);
        fStack_78 = fStack_80 + fStack_a0;
        fStack_74 = fStack_7c + fStack_9c;
        func_0x00018010bbf0(&fStack_a0, *(undefined4 *)(iVar3 + 0xde0));
        uVar7 = func_0x00018010b530(&fStack_80, uVar5, 0, 0);
        if ((char)uVar7 != '\0') {
            var_c8h = CONCAT44(var_c8h._4_4_, (uint32_t)arg3);
            uVar4 = fcn.180139d40((int64_t)&fStack_80, (uint64_t)uVar5, (int64_t)acStackX_20, (int64_t)acStack_a8, 
                                  var_c8h, in_stack_00000118);
            if ((acStack_a8[0] == '\0') || (acStackX_20[0] == '\0')) {
                iVar8 = (uint64_t)(acStackX_20[0] != '\0') + 0x15;
            } else {
                iVar8 = 0x17;
            }
            pfVar2 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar8 + 0x14) * 0x10);
            fStack_90 = *pfVar2;
            fStack_8c = pfVar2[1];
            fStack_88 = pfVar2[2];
            fStack_84 = pfVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            func_0x0001800f7d00(&fStack_80, uVar5, 0);
            uVar6 = func_0x0001800f5fa0(&fStack_90);
            var_c8h = CONCAT44(var_c8h._4_4_, *(undefined4 *)(iVar3 + 0xde4));
            func_0x0001800f7a00(CONCAT44(fStack_7c, fStack_80), CONCAT44(fStack_74, fStack_78), uVar6, 1, var_c8h);
            iVar8 = *(int64_t *)0x180781f28;
            if (*(char *)(iVar3 + 0x29f8) != '\0') {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1805ab2b8;
                *(undefined8 *)(iVar8 + 0x2a28) = 0x18063e184;
            }
            fStack_a0 = fStack_78 - *(float *)(iVar3 + 0xddc);
            fStack_90 = *(float *)(iVar3 + 0xddc) + fStack_80;
            fStack_9c = fStack_74 - *(float *)(iVar3 + 0xde0);
            fStack_8c = *(float *)(iVar3 + 0xde0) + fStack_7c;
            func_0x0001800f7200(&fStack_90, &fStack_a0, arg1, pcVar9, &fStack_98, iVar3 + 0xe80, &fStack_80);
            return (uint64_t)uVar4;
        }
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18013a741
// Address: 0x18013a741
// Size: 345 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_39h
// WARNING: Variable defined which should be unmapped: var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_1dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_25h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013a5c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char *pcVar1;
    float *pfVar2;
    int64_t iVar3;
    uint8_t uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    char *pcVar9;
    char acStackX_20 [8];
    int64_t in_stack_00000118;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    char acStack_a8 [8];
    float fStack_a0;
    float fStack_9c;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    float fStack_88;
    float fStack_84;
    float fStack_80;
    float fStack_7c;
    float fStack_78;
    float fStack_74;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_39h;
    int64_t var_21h;
    
    iVar3 = *(int64_t *)0x180781f28;
    uVar7 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar7 + 0x10b) = 1;
    iVar8 = *(int64_t *)(iVar3 + 0x15e0);
    if (*(char *)(iVar8 + 0x10e) == '\0') {
        uVar5 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                              (*(int64_t *)(iVar8 + 0x150) + -4 +
                                              (int64_t)*(int32_t *)(iVar8 + 0x148) * 4));
        pcVar9 = (char *)arg1;
        if (arg1 != -1) {
            while (*pcVar9 != '\0') {
                pcVar1 = pcVar9 + 1;
                if (((*pcVar9 == '#') && (*pcVar1 == '#')) || (pcVar9 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
                break;
            }
        }
        var_c8h = CONCAT44(var_c8h._4_4_, 0xbf800000);
        func_0x0001800fe0a0(&fStack_98, arg1, pcVar9, 0, var_c8h);
        fStack_80 = *(float *)(iVar8 + 0x158);
        fStack_7c = *(float *)(iVar8 + 0x15c);
        if (((uint32_t)arg3 >> 0xf & 1) != 0) {
            if (*(float *)(iVar3 + 0xde0) < *(float *)(iVar8 + 400)) {
                fStack_7c = (*(float *)(iVar8 + 400) - *(float *)(iVar3 + 0xde0)) + fStack_7c;
            }
        }
        func_0x00018010be90(&fStack_a0, *(undefined8 *)arg2, 
                            *(float *)(iVar3 + 0xddc) + *(float *)(iVar3 + 0xddc) + fStack_98, 
                            *(float *)(iVar3 + 0xde0) + *(float *)(iVar3 + 0xde0) + fStack_94);
        fStack_78 = fStack_80 + fStack_a0;
        fStack_74 = fStack_7c + fStack_9c;
        func_0x00018010bbf0(&fStack_a0, *(undefined4 *)(iVar3 + 0xde0));
        uVar7 = func_0x00018010b530(&fStack_80, uVar5, 0, 0);
        if ((char)uVar7 != '\0') {
            var_c8h = CONCAT44(var_c8h._4_4_, (uint32_t)arg3);
            uVar4 = fcn.180139d40((int64_t)&fStack_80, (uint64_t)uVar5, (int64_t)acStackX_20, (int64_t)acStack_a8, 
                                  var_c8h, in_stack_00000118);
            if ((acStack_a8[0] == '\0') || (acStackX_20[0] == '\0')) {
                iVar8 = (uint64_t)(acStackX_20[0] != '\0') + 0x15;
            } else {
                iVar8 = 0x17;
            }
            pfVar2 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar8 + 0x14) * 0x10);
            fStack_90 = *pfVar2;
            fStack_8c = pfVar2[1];
            fStack_88 = pfVar2[2];
            fStack_84 = pfVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            func_0x0001800f7d00(&fStack_80, uVar5, 0);
            uVar6 = func_0x0001800f5fa0(&fStack_90);
            var_c8h = CONCAT44(var_c8h._4_4_, *(undefined4 *)(iVar3 + 0xde4));
            func_0x0001800f7a00(CONCAT44(fStack_7c, fStack_80), CONCAT44(fStack_74, fStack_78), uVar6, 1, var_c8h);
            iVar8 = *(int64_t *)0x180781f28;
            if (*(char *)(iVar3 + 0x29f8) != '\0') {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x1805ab2b8;
                *(undefined8 *)(iVar8 + 0x2a28) = 0x18063e184;
            }
            fStack_a0 = fStack_78 - *(float *)(iVar3 + 0xddc);
            fStack_90 = *(float *)(iVar3 + 0xddc) + fStack_80;
            fStack_9c = fStack_74 - *(float *)(iVar3 + 0xde0);
            fStack_8c = *(float *)(iVar3 + 0xde0) + fStack_7c;
            func_0x0001800f7200(&fStack_90, &fStack_a0, arg1, pcVar9, &fStack_98, iVar3 + 0xe80, &fStack_80);
            return (uint64_t)uVar4;
        }
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18013a8a0
// Address: 0x18013a8a0
// Size: 335 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013a8a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint8_t uVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    float fVar5;
    float fVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_000001b8;
    int64_t var_28h;
    float fStack_18;
    int64_t var_14h;
    int64_t var_ch;
    
    iVar1 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (undefined4)arg3;
    uVar4 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar4 + 0x10b) = 1;
    iVar1 = *(int64_t *)(iVar1 + 0x15e0);
    if (*(char *)(iVar1 + 0x10e) == '\0') {
        fVar6 = *(float *)(arg2 + 4);
        if (fVar6 == 0.0) {
            fVar6 = -1.175494e-38;
        }
        fVar5 = -1.175494e-38;
        if (*(float *)arg2 != 0.0) {
            fVar5 = *(float *)arg2;
        }
        var_8h = arg1;
        func_0x00018010be90(&var_20h, CONCAT44(fVar6, fVar5), 0, 0);
        uVar3 = func_0x0001800f5a90(0x180645cd8, 0, 
                                    *(undefined4 *)
                                     (*(int64_t *)(iVar1 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar1 + 0x148) * 4));
        fStack_18 = *(float *)(iVar1 + 0x158);
        var_ch._0_4_ = var_20h._4_4_ + *(float *)(iVar1 + 0x15c);
        var_14h._0_4_ = *(undefined4 *)(iVar1 + 0x15c);
        var_14h._4_4_ = fStack_18 + (float)var_20h;
        func_0x00018010bbf0(&var_20h, 0xbf800000);
        uVar4 = func_0x00018010b530(&fStack_18, uVar3, 0, 2);
        if ((char)uVar4 != '\0') {
            uVar2 = fcn.180139d40((int64_t)&fStack_18, (uint64_t)uVar3, (int64_t)&var_8h, (int64_t)&var_18h, 
                                  (uint64_t)var_28h._4_4_ << 0x20, in_stack_000001b8);
            func_0x0001800f7d00(&fStack_18, uVar3, 0);
            return (uint64_t)uVar2;
        }
    }
    return uVar4 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18013a9f0
// Address: 0x18013a9f0
// Size: 247 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_dh
// WARNING: Variable defined which should be unmapped: var_1dh
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013a9f0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint8_t uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    undefined4 auStackX_20 [2];
    int64_t in_stack_00000128;
    int64_t var_b8h;
    char acStack_a8 [8];
    undefined8 uStack_a0;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    float fStack_7c;
    undefined4 uStack_78;
    undefined4 uStack_74;
    undefined4 uStack_70;
    float fStack_6c;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_2dh;
    int64_t var_1dh;
    int64_t var_dh;
    
    iVar3 = *(int64_t *)0x180781f28;
    auStackX_20[0] = (undefined4)arg4;
    uVar7 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar7 + 0x10b) = 1;
    iVar2 = *(int64_t *)(iVar3 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        uStack_a0 = arg3;
        uVar5 = func_0x0001800f5a90(placeholder_0, 0, 
                                    *(undefined4 *)
                                     (*(int64_t *)(iVar2 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar2 + 0x148) * 4));
        fStack_98 = *(float *)(iVar2 + 0x158);
        fVar11 = uStack_a0._4_4_;
        fStack_8c = uStack_a0._4_4_ + *(float *)(iVar2 + 0x15c);
        fStack_90 = fStack_98 + (float)arg3;
        fStack_94 = *(float *)(iVar2 + 0x15c);
        fVar9 = *(float *)(iVar3 + 0xde0);
        if (uStack_a0._4_4_ < fVar9 + fVar9 + *(float *)(iVar3 + 0x12f8)) {
            fVar9 = -1.0;
        }
        func_0x00018010bbf0(&uStack_a0, fVar9);
        uVar7 = func_0x00018010b530(&fStack_98, uVar5, 0, 0);
        if ((char)uVar7 != '\0') {
            uVar4 = fcn.180139d40((int64_t)&fStack_98, (uint64_t)uVar5, (int64_t)auStackX_20, (int64_t)acStack_a8, 
                                  CONCAT44(var_b8h._4_4_, 0x10), in_stack_00000128);
            if ((acStack_a8[0] == '\0') || ((char)auStackX_20[0] == '\0')) {
                iVar8 = (uint64_t)((char)auStackX_20[0] != '\0') + 0x15;
            } else {
                iVar8 = 0x17;
            }
            puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar8 + 0x14) * 0x10);
            uStack_88 = *puVar1;
            uStack_84 = puVar1[1];
            uStack_80 = puVar1[2];
            fStack_7c = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            uStack_78 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
            uStack_74 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
            uStack_70 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
            fStack_6c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            func_0x0001800f7d00(&fStack_98, uVar5, 0);
            uVar6 = func_0x0001800f5fa0(&uStack_88);
            func_0x0001800f7a00(CONCAT44(fStack_94, fStack_98), CONCAT44(fStack_8c, fStack_90), uVar6, 1, 
                                *(undefined4 *)(iVar3 + 0xde4));
            fVar10 = ((float)arg3 - *(float *)(iVar3 + 0x12f8)) * 0.5;
            fVar11 = (fVar11 - *(float *)(iVar3 + 0x12f8)) * 0.5;
            fVar9 = 0.0;
            if (0.0 <= fVar10) {
                fVar9 = fVar10;
            }
            fVar10 = 0.0;
            if (0.0 <= fVar11) {
                fVar10 = fVar11;
            }
            fVar9 = fVar9 + fStack_98;
            fVar10 = fVar10 + fStack_94;
            uVar6 = func_0x0001800f5fa0(&uStack_78);
            func_0x0001801301a0(*(undefined8 *)(iVar2 + 800), CONCAT44(fVar10, fVar9), uVar6, arg2 & 0xffffffff, 
                                0x3f800000);
            return (uint64_t)uVar4;
        }
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18013aae7
// Address: 0x18013aae7
// Size: 355 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_dh
// WARNING: Variable defined which should be unmapped: var_1dh
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013a9f0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint8_t uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    undefined4 auStackX_20 [2];
    int64_t in_stack_00000128;
    int64_t var_b8h;
    char acStack_a8 [8];
    undefined8 uStack_a0;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    float fStack_7c;
    undefined4 uStack_78;
    undefined4 uStack_74;
    undefined4 uStack_70;
    float fStack_6c;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_2dh;
    int64_t var_1dh;
    int64_t var_dh;
    
    iVar3 = *(int64_t *)0x180781f28;
    auStackX_20[0] = (undefined4)arg4;
    uVar7 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar7 + 0x10b) = 1;
    iVar2 = *(int64_t *)(iVar3 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        uStack_a0 = arg3;
        uVar5 = func_0x0001800f5a90(placeholder_0, 0, 
                                    *(undefined4 *)
                                     (*(int64_t *)(iVar2 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar2 + 0x148) * 4));
        fStack_98 = *(float *)(iVar2 + 0x158);
        fVar11 = uStack_a0._4_4_;
        fStack_8c = uStack_a0._4_4_ + *(float *)(iVar2 + 0x15c);
        fStack_90 = fStack_98 + (float)arg3;
        fStack_94 = *(float *)(iVar2 + 0x15c);
        fVar9 = *(float *)(iVar3 + 0xde0);
        if (uStack_a0._4_4_ < fVar9 + fVar9 + *(float *)(iVar3 + 0x12f8)) {
            fVar9 = -1.0;
        }
        func_0x00018010bbf0(&uStack_a0, fVar9);
        uVar7 = func_0x00018010b530(&fStack_98, uVar5, 0, 0);
        if ((char)uVar7 != '\0') {
            uVar4 = fcn.180139d40((int64_t)&fStack_98, (uint64_t)uVar5, (int64_t)auStackX_20, (int64_t)acStack_a8, 
                                  CONCAT44(var_b8h._4_4_, 0x10), in_stack_00000128);
            if ((acStack_a8[0] == '\0') || ((char)auStackX_20[0] == '\0')) {
                iVar8 = (uint64_t)((char)auStackX_20[0] != '\0') + 0x15;
            } else {
                iVar8 = 0x17;
            }
            puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar8 + 0x14) * 0x10);
            uStack_88 = *puVar1;
            uStack_84 = puVar1[1];
            uStack_80 = puVar1[2];
            fStack_7c = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            uStack_78 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
            uStack_74 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
            uStack_70 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
            fStack_6c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            func_0x0001800f7d00(&fStack_98, uVar5, 0);
            uVar6 = func_0x0001800f5fa0(&uStack_88);
            func_0x0001800f7a00(CONCAT44(fStack_94, fStack_98), CONCAT44(fStack_8c, fStack_90), uVar6, 1, 
                                *(undefined4 *)(iVar3 + 0xde4));
            fVar10 = ((float)arg3 - *(float *)(iVar3 + 0x12f8)) * 0.5;
            fVar11 = (fVar11 - *(float *)(iVar3 + 0x12f8)) * 0.5;
            fVar9 = 0.0;
            if (0.0 <= fVar10) {
                fVar9 = fVar10;
            }
            fVar10 = 0.0;
            if (0.0 <= fVar11) {
                fVar10 = fVar11;
            }
            fVar9 = fVar9 + fStack_98;
            fVar10 = fVar10 + fStack_94;
            uVar6 = func_0x0001800f5fa0(&uStack_78);
            func_0x0001801301a0(*(undefined8 *)(iVar2 + 800), CONCAT44(fVar10, fVar9), uVar6, arg2 & 0xffffffff, 
                                0x3f800000);
            return (uint64_t)uVar4;
        }
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18013ac4a
// Address: 0x18013ac4a
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_dh
// WARNING: Variable defined which should be unmapped: var_1dh
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013a9f0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint8_t uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    undefined4 auStackX_20 [2];
    int64_t in_stack_00000128;
    int64_t var_b8h;
    char acStack_a8 [8];
    undefined8 uStack_a0;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    float fStack_7c;
    undefined4 uStack_78;
    undefined4 uStack_74;
    undefined4 uStack_70;
    float fStack_6c;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_2dh;
    int64_t var_1dh;
    int64_t var_dh;
    
    iVar3 = *(int64_t *)0x180781f28;
    auStackX_20[0] = (undefined4)arg4;
    uVar7 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar7 + 0x10b) = 1;
    iVar2 = *(int64_t *)(iVar3 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        uStack_a0 = arg3;
        uVar5 = func_0x0001800f5a90(placeholder_0, 0, 
                                    *(undefined4 *)
                                     (*(int64_t *)(iVar2 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar2 + 0x148) * 4));
        fStack_98 = *(float *)(iVar2 + 0x158);
        fVar11 = uStack_a0._4_4_;
        fStack_8c = uStack_a0._4_4_ + *(float *)(iVar2 + 0x15c);
        fStack_90 = fStack_98 + (float)arg3;
        fStack_94 = *(float *)(iVar2 + 0x15c);
        fVar9 = *(float *)(iVar3 + 0xde0);
        if (uStack_a0._4_4_ < fVar9 + fVar9 + *(float *)(iVar3 + 0x12f8)) {
            fVar9 = -1.0;
        }
        func_0x00018010bbf0(&uStack_a0, fVar9);
        uVar7 = func_0x00018010b530(&fStack_98, uVar5, 0, 0);
        if ((char)uVar7 != '\0') {
            uVar4 = fcn.180139d40((int64_t)&fStack_98, (uint64_t)uVar5, (int64_t)auStackX_20, (int64_t)acStack_a8, 
                                  CONCAT44(var_b8h._4_4_, 0x10), in_stack_00000128);
            if ((acStack_a8[0] == '\0') || ((char)auStackX_20[0] == '\0')) {
                iVar8 = (uint64_t)((char)auStackX_20[0] != '\0') + 0x15;
            } else {
                iVar8 = 0x17;
            }
            puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar8 + 0x14) * 0x10);
            uStack_88 = *puVar1;
            uStack_84 = puVar1[1];
            uStack_80 = puVar1[2];
            fStack_7c = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            uStack_78 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
            uStack_74 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
            uStack_70 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
            fStack_6c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            func_0x0001800f7d00(&fStack_98, uVar5, 0);
            uVar6 = func_0x0001800f5fa0(&uStack_88);
            func_0x0001800f7a00(CONCAT44(fStack_94, fStack_98), CONCAT44(fStack_8c, fStack_90), uVar6, 1, 
                                *(undefined4 *)(iVar3 + 0xde4));
            fVar10 = ((float)arg3 - *(float *)(iVar3 + 0x12f8)) * 0.5;
            fVar11 = (fVar11 - *(float *)(iVar3 + 0x12f8)) * 0.5;
            fVar9 = 0.0;
            if (0.0 <= fVar10) {
                fVar9 = fVar10;
            }
            fVar10 = 0.0;
            if (0.0 <= fVar11) {
                fVar10 = fVar11;
            }
            fVar9 = fVar9 + fStack_98;
            fVar10 = fVar10 + fStack_94;
            uVar6 = func_0x0001800f5fa0(&uStack_78);
            func_0x0001801301a0(*(undefined8 *)(iVar2 + 800), CONCAT44(fVar10, fVar9), uVar6, arg2 & 0xffffffff, 
                                0x3f800000);
            return (uint64_t)uVar4;
        }
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18013ac70
// Address: 0x18013ac70
// Size: 380 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_1dh
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013ac70(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    char acStackX_10 [8];
    char acStackX_18 [8];
    float fStackX_20;
    float fStackX_24;
    int64_t in_stack_00000128;
    int64_t var_b8h;
    int64_t var_b0h;
    float fStack_a8;
    float fStack_a4;
    float fStack_a0;
    float fStack_9c;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    float fStack_7c;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_39h;
    int64_t var_1dh;
    
    iVar3 = *(int64_t *)0x180781f28;
    fVar8 = *(float *)arg2;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    fVar9 = *(float *)(arg2 + 4);
    fVar10 = fVar8 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    fVar12 = fVar9 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    fStack_98 = fVar8;
    fStack_94 = fVar9;
    fStack_90 = fVar10;
    fStack_8c = fVar12;
    if (((*(float *)(iVar2 + 0x274) - *(float *)(iVar2 + 0x26c)) *
        (*(float *)(iVar2 + 0x270) - *(float *)(iVar2 + 0x268))) / ((fVar10 - fVar8) * (fVar12 - fVar9)) < 1.5) {
        fStack_90 = (float)(int32_t)((fVar10 - fVar8) * -0.25);
        fStack_98 = fVar8 - fStack_90;
        fStack_90 = fStack_90 + fVar10;
        fStack_8c = (float)(int32_t)((fVar12 - fVar9) * -0.25);
        fStack_94 = fVar9 - fStack_8c;
        fStack_8c = fStack_8c + fVar12;
    }
    fStack_a8 = fVar8;
    fStack_a4 = fVar9;
    fStack_a0 = fVar10;
    fStack_9c = fVar12;
    cVar4 = func_0x00018010b530(&fStack_98, arg1 & 0xffffffffU, 0, 0);
    uVar6 = fcn.180139d40((int64_t)&fStack_98, arg1 & 0xffffffff, (int64_t)acStackX_18, (int64_t)acStackX_10, 
                          (uint64_t)var_b8h._4_4_ << 0x20, in_stack_00000128);
    if (cVar4 != '\0') {
        iVar7 = 0x2a0;
        if (acStackX_10[0] != '\0') {
            iVar7 = 0x2b0;
        }
        puVar1 = (undefined4 *)(iVar7 + 0xd90 + *(int64_t *)0x180781f28);
        uStack_88 = *puVar1;
        uStack_84 = puVar1[1];
        uStack_80 = puVar1[2];
        fStack_7c = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        if (acStackX_18[0] != '\0') {
            uVar5 = func_0x0001800f5fa0(&uStack_88);
            func_0x000180126550(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStack_a0, uVar5, 0, 0);
        }
        func_0x0001800f7d00(&fStack_a8, arg1 & 0xffffffffU, 2);
        uStack_88 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        uStack_84 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_80 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        fStack_7c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = func_0x0001800f5fa0(&uStack_88);
        fVar10 = (fVar10 + fVar8) * 0.5 - 0.5;
        fVar8 = *(float *)(iVar3 + 0x12f8) * 0.5 * 0.7071 - 1.0;
        fVar13 = (fVar12 + fVar9) * 0.5 - 0.5;
        fVar12 = (float)(int32_t)*(float *)(iVar3 + 0x12c4);
        fVar11 = fVar10 + fVar8;
        fVar10 = fVar10 + (float)((uint32_t)fVar8 ^ 0x80000000);
        fVar9 = fVar13 + (float)((uint32_t)fVar8 ^ 0x80000000);
        fVar13 = fVar13 + fVar8;
        fStackX_20 = fVar10;
        fStackX_24 = fVar9;
        fStack_a8 = fVar11;
        fStack_a4 = fVar13;
        func_0x000180126300(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStackX_20, uVar5, fVar12);
        fStackX_20 = fVar10;
        fStackX_24 = fVar13;
        fStack_a8 = fVar11;
        fStack_a4 = fVar9;
        func_0x000180126300(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStackX_20, uVar5, fVar12);
        uVar6 = uVar6 & 0xff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18013adec
// Address: 0x18013adec
// Size: 400 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_1dh
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013ac70(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    char acStackX_10 [8];
    char acStackX_18 [8];
    float fStackX_20;
    float fStackX_24;
    int64_t in_stack_00000128;
    int64_t var_b8h;
    int64_t var_b0h;
    float fStack_a8;
    float fStack_a4;
    float fStack_a0;
    float fStack_9c;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    float fStack_7c;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_39h;
    int64_t var_1dh;
    
    iVar3 = *(int64_t *)0x180781f28;
    fVar8 = *(float *)arg2;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    fVar9 = *(float *)(arg2 + 4);
    fVar10 = fVar8 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    fVar12 = fVar9 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    fStack_98 = fVar8;
    fStack_94 = fVar9;
    fStack_90 = fVar10;
    fStack_8c = fVar12;
    if (((*(float *)(iVar2 + 0x274) - *(float *)(iVar2 + 0x26c)) *
        (*(float *)(iVar2 + 0x270) - *(float *)(iVar2 + 0x268))) / ((fVar10 - fVar8) * (fVar12 - fVar9)) < 1.5) {
        fStack_90 = (float)(int32_t)((fVar10 - fVar8) * -0.25);
        fStack_98 = fVar8 - fStack_90;
        fStack_90 = fStack_90 + fVar10;
        fStack_8c = (float)(int32_t)((fVar12 - fVar9) * -0.25);
        fStack_94 = fVar9 - fStack_8c;
        fStack_8c = fStack_8c + fVar12;
    }
    fStack_a8 = fVar8;
    fStack_a4 = fVar9;
    fStack_a0 = fVar10;
    fStack_9c = fVar12;
    cVar4 = func_0x00018010b530(&fStack_98, arg1 & 0xffffffffU, 0, 0);
    uVar6 = fcn.180139d40((int64_t)&fStack_98, arg1 & 0xffffffff, (int64_t)acStackX_18, (int64_t)acStackX_10, 
                          (uint64_t)var_b8h._4_4_ << 0x20, in_stack_00000128);
    if (cVar4 != '\0') {
        iVar7 = 0x2a0;
        if (acStackX_10[0] != '\0') {
            iVar7 = 0x2b0;
        }
        puVar1 = (undefined4 *)(iVar7 + 0xd90 + *(int64_t *)0x180781f28);
        uStack_88 = *puVar1;
        uStack_84 = puVar1[1];
        uStack_80 = puVar1[2];
        fStack_7c = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        if (acStackX_18[0] != '\0') {
            uVar5 = func_0x0001800f5fa0(&uStack_88);
            func_0x000180126550(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStack_a0, uVar5, 0, 0);
        }
        func_0x0001800f7d00(&fStack_a8, arg1 & 0xffffffffU, 2);
        uStack_88 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        uStack_84 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_80 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        fStack_7c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = func_0x0001800f5fa0(&uStack_88);
        fVar10 = (fVar10 + fVar8) * 0.5 - 0.5;
        fVar8 = *(float *)(iVar3 + 0x12f8) * 0.5 * 0.7071 - 1.0;
        fVar13 = (fVar12 + fVar9) * 0.5 - 0.5;
        fVar12 = (float)(int32_t)*(float *)(iVar3 + 0x12c4);
        fVar11 = fVar10 + fVar8;
        fVar10 = fVar10 + (float)((uint32_t)fVar8 ^ 0x80000000);
        fVar9 = fVar13 + (float)((uint32_t)fVar8 ^ 0x80000000);
        fVar13 = fVar13 + fVar8;
        fStackX_20 = fVar10;
        fStackX_24 = fVar9;
        fStack_a8 = fVar11;
        fStack_a4 = fVar13;
        func_0x000180126300(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStackX_20, uVar5, fVar12);
        fStackX_20 = fVar10;
        fStackX_24 = fVar13;
        fStack_a8 = fVar11;
        fStack_a4 = fVar9;
        func_0x000180126300(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStackX_20, uVar5, fVar12);
        uVar6 = uVar6 & 0xff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18013af7c
// Address: 0x18013af7c
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_1dh
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013ac70(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    char acStackX_10 [8];
    char acStackX_18 [8];
    float fStackX_20;
    float fStackX_24;
    int64_t in_stack_00000128;
    int64_t var_b8h;
    int64_t var_b0h;
    float fStack_a8;
    float fStack_a4;
    float fStack_a0;
    float fStack_9c;
    float fStack_98;
    float fStack_94;
    float fStack_90;
    float fStack_8c;
    undefined4 uStack_88;
    undefined4 uStack_84;
    undefined4 uStack_80;
    float fStack_7c;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_39h;
    int64_t var_1dh;
    
    iVar3 = *(int64_t *)0x180781f28;
    fVar8 = *(float *)arg2;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    fVar9 = *(float *)(arg2 + 4);
    fVar10 = fVar8 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    fVar12 = fVar9 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    fStack_98 = fVar8;
    fStack_94 = fVar9;
    fStack_90 = fVar10;
    fStack_8c = fVar12;
    if (((*(float *)(iVar2 + 0x274) - *(float *)(iVar2 + 0x26c)) *
        (*(float *)(iVar2 + 0x270) - *(float *)(iVar2 + 0x268))) / ((fVar10 - fVar8) * (fVar12 - fVar9)) < 1.5) {
        fStack_90 = (float)(int32_t)((fVar10 - fVar8) * -0.25);
        fStack_98 = fVar8 - fStack_90;
        fStack_90 = fStack_90 + fVar10;
        fStack_8c = (float)(int32_t)((fVar12 - fVar9) * -0.25);
        fStack_94 = fVar9 - fStack_8c;
        fStack_8c = fStack_8c + fVar12;
    }
    fStack_a8 = fVar8;
    fStack_a4 = fVar9;
    fStack_a0 = fVar10;
    fStack_9c = fVar12;
    cVar4 = func_0x00018010b530(&fStack_98, arg1 & 0xffffffffU, 0, 0);
    uVar6 = fcn.180139d40((int64_t)&fStack_98, arg1 & 0xffffffff, (int64_t)acStackX_18, (int64_t)acStackX_10, 
                          (uint64_t)var_b8h._4_4_ << 0x20, in_stack_00000128);
    if (cVar4 != '\0') {
        iVar7 = 0x2a0;
        if (acStackX_10[0] != '\0') {
            iVar7 = 0x2b0;
        }
        puVar1 = (undefined4 *)(iVar7 + 0xd90 + *(int64_t *)0x180781f28);
        uStack_88 = *puVar1;
        uStack_84 = puVar1[1];
        uStack_80 = puVar1[2];
        fStack_7c = (float)puVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        if (acStackX_18[0] != '\0') {
            uVar5 = func_0x0001800f5fa0(&uStack_88);
            func_0x000180126550(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStack_a0, uVar5, 0, 0);
        }
        func_0x0001800f7d00(&fStack_a8, arg1 & 0xffffffffU, 2);
        uStack_88 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        uStack_84 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_80 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        fStack_7c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = func_0x0001800f5fa0(&uStack_88);
        fVar10 = (fVar10 + fVar8) * 0.5 - 0.5;
        fVar8 = *(float *)(iVar3 + 0x12f8) * 0.5 * 0.7071 - 1.0;
        fVar13 = (fVar12 + fVar9) * 0.5 - 0.5;
        fVar12 = (float)(int32_t)*(float *)(iVar3 + 0x12c4);
        fVar11 = fVar10 + fVar8;
        fVar10 = fVar10 + (float)((uint32_t)fVar8 ^ 0x80000000);
        fVar9 = fVar13 + (float)((uint32_t)fVar8 ^ 0x80000000);
        fVar13 = fVar13 + fVar8;
        fStackX_20 = fVar10;
        fStackX_24 = fVar9;
        fStack_a8 = fVar11;
        fStack_a4 = fVar13;
        func_0x000180126300(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStackX_20, uVar5, fVar12);
        fStackX_20 = fVar10;
        fStackX_24 = fVar13;
        fStack_a8 = fVar11;
        fStack_a4 = fVar9;
        func_0x000180126300(*(undefined8 *)(iVar2 + 800), &fStack_a8, &fStackX_20, uVar5, fVar12);
        uVar6 = uVar6 & 0xff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_18013afb0
// Address: 0x18013afb0
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013afb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    float fVar2;
    int64_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    char cVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    undefined8 uVar12;
    char cVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t in_stack_00000118;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined4 uStack_a8;
    float var_a4h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)0x180781f28;
    var_a0h = *(int64_t *)arg2;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    var_98h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)arg2;
    var_98h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)(arg2 + 4);
    cVar7 = func_0x00018010b530(&var_a0h, arg1 & 0xffffffff, 0, 0);
    uVar10 = fcn.180139d40((int64_t)&var_a0h, arg1 & 0xffffffff, (int64_t)&var_10h, (int64_t)&var_20h, 
                           (uint64_t)var_c8h._4_4_ << 0x20, in_stack_00000118);
    if (cVar7 != '\0') {
        if (((char)var_20h == '\0') || ((char)var_10h == '\0')) {
            iVar11 = (uint64_t)((char)var_10h != '\0') + 0x15;
        } else {
            iVar11 = 0x17;
        }
        fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar11 + 0x14) * 0x10);
        var_b0h._0_4_ = (float)*puVar1;
        var_b0h._4_4_ = (float)puVar1[1];
        uStack_a8 = puVar1[2];
        var_a4h = (float)puVar1[3] * fVar2;
        iVar11 = *(int64_t *)0x180781f28;
        cVar7 = (char)var_10h;
        cVar13 = (char)var_20h;
        uVar8 = func_0x0001800f5fa0(&var_b0h);
        var_b0h._0_4_ = *(float *)(iVar11 + 0xed0);
        var_b0h._4_4_ = *(float *)(iVar11 + 0xed4);
        uStack_a8 = *(undefined4 *)(iVar11 + 0xed8);
        var_a4h = *(float *)(iVar11 + 0xedc) * fVar2;
        uVar9 = func_0x0001800f5fa0(&var_b0h);
        if ((cVar7 != '\0') || (cVar13 != '\0')) {
            func_0x000180126550(*(undefined8 *)(iVar3 + 800), &var_a0h, &var_98h, uVar8, 0, 0);
        }
        func_0x0001800f7d00(&var_a0h, arg1 & 0xffffffff, 2);
        if (arg3 == 0) {
            uVar12 = 3;
            if (*(char *)(iVar3 + 0x10c) != '\0') {
                uVar12 = 1;
            }
            func_0x0001801301a0(*(undefined8 *)(iVar3 + 800), var_a0h, uVar9, uVar12, 0x3f800000);
        } else {
            fVar5 = (float)var_a0h;
            uVar12 = *(undefined8 *)(iVar3 + 800);
            fVar6 = var_a0h._4_4_;
            fVar2 = *(float *)(iVar4 + 0x12f8);
            var_b8h._0_4_ = fVar2 * 0.8 + (float)var_a0h;
            var_b0h._0_4_ = fVar2 * 0.2 + (float)var_a0h;
            var_b8h._4_4_ = fVar2 * 0.3 + var_a0h._4_4_;
            var_b0h._4_4_ = fVar2 * 0.15 + var_a0h._4_4_;
            func_0x000180126550(uVar12, &var_b0h, &var_b8h, uVar9, 0, 0);
            func_0x0001801305d0(uVar12, CONCAT44(fVar2 * 0.85 + fVar6, fVar2 * 0.5 + fVar5), 
                                CONCAT44(fVar2 * 0.4, fVar2 * 0.3));
        }
        if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
            (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) &&
           (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) {
            if (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc)) {
                func_0x0001800faaf0(iVar3, arg3, 1);
            }
        }
        uVar10 = uVar10 & 0xff;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18013b048
// Address: 0x18013b048
// Size: 247 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013afb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    float fVar2;
    int64_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    char cVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    undefined8 uVar12;
    char cVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t in_stack_00000118;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined4 uStack_a8;
    float var_a4h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)0x180781f28;
    var_a0h = *(int64_t *)arg2;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    var_98h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)arg2;
    var_98h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)(arg2 + 4);
    cVar7 = func_0x00018010b530(&var_a0h, arg1 & 0xffffffff, 0, 0);
    uVar10 = fcn.180139d40((int64_t)&var_a0h, arg1 & 0xffffffff, (int64_t)&var_10h, (int64_t)&var_20h, 
                           (uint64_t)var_c8h._4_4_ << 0x20, in_stack_00000118);
    if (cVar7 != '\0') {
        if (((char)var_20h == '\0') || ((char)var_10h == '\0')) {
            iVar11 = (uint64_t)((char)var_10h != '\0') + 0x15;
        } else {
            iVar11 = 0x17;
        }
        fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar11 + 0x14) * 0x10);
        var_b0h._0_4_ = (float)*puVar1;
        var_b0h._4_4_ = (float)puVar1[1];
        uStack_a8 = puVar1[2];
        var_a4h = (float)puVar1[3] * fVar2;
        iVar11 = *(int64_t *)0x180781f28;
        cVar7 = (char)var_10h;
        cVar13 = (char)var_20h;
        uVar8 = func_0x0001800f5fa0(&var_b0h);
        var_b0h._0_4_ = *(float *)(iVar11 + 0xed0);
        var_b0h._4_4_ = *(float *)(iVar11 + 0xed4);
        uStack_a8 = *(undefined4 *)(iVar11 + 0xed8);
        var_a4h = *(float *)(iVar11 + 0xedc) * fVar2;
        uVar9 = func_0x0001800f5fa0(&var_b0h);
        if ((cVar7 != '\0') || (cVar13 != '\0')) {
            func_0x000180126550(*(undefined8 *)(iVar3 + 800), &var_a0h, &var_98h, uVar8, 0, 0);
        }
        func_0x0001800f7d00(&var_a0h, arg1 & 0xffffffff, 2);
        if (arg3 == 0) {
            uVar12 = 3;
            if (*(char *)(iVar3 + 0x10c) != '\0') {
                uVar12 = 1;
            }
            func_0x0001801301a0(*(undefined8 *)(iVar3 + 800), var_a0h, uVar9, uVar12, 0x3f800000);
        } else {
            fVar5 = (float)var_a0h;
            uVar12 = *(undefined8 *)(iVar3 + 800);
            fVar6 = var_a0h._4_4_;
            fVar2 = *(float *)(iVar4 + 0x12f8);
            var_b8h._0_4_ = fVar2 * 0.8 + (float)var_a0h;
            var_b0h._0_4_ = fVar2 * 0.2 + (float)var_a0h;
            var_b8h._4_4_ = fVar2 * 0.3 + var_a0h._4_4_;
            var_b0h._4_4_ = fVar2 * 0.15 + var_a0h._4_4_;
            func_0x000180126550(uVar12, &var_b0h, &var_b8h, uVar9, 0, 0);
            func_0x0001801305d0(uVar12, CONCAT44(fVar2 * 0.85 + fVar6, fVar2 * 0.5 + fVar5), 
                                CONCAT44(fVar2 * 0.4, fVar2 * 0.3));
        }
        if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
            (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) &&
           (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) {
            if (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc)) {
                func_0x0001800faaf0(iVar3, arg3, 1);
            }
        }
        uVar10 = uVar10 & 0xff;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18013b13f
// Address: 0x18013b13f
// Size: 250 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013afb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    float fVar2;
    int64_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    char cVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    undefined8 uVar12;
    char cVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t in_stack_00000118;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined4 uStack_a8;
    float var_a4h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)0x180781f28;
    var_a0h = *(int64_t *)arg2;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    var_98h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)arg2;
    var_98h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)(arg2 + 4);
    cVar7 = func_0x00018010b530(&var_a0h, arg1 & 0xffffffff, 0, 0);
    uVar10 = fcn.180139d40((int64_t)&var_a0h, arg1 & 0xffffffff, (int64_t)&var_10h, (int64_t)&var_20h, 
                           (uint64_t)var_c8h._4_4_ << 0x20, in_stack_00000118);
    if (cVar7 != '\0') {
        if (((char)var_20h == '\0') || ((char)var_10h == '\0')) {
            iVar11 = (uint64_t)((char)var_10h != '\0') + 0x15;
        } else {
            iVar11 = 0x17;
        }
        fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar11 + 0x14) * 0x10);
        var_b0h._0_4_ = (float)*puVar1;
        var_b0h._4_4_ = (float)puVar1[1];
        uStack_a8 = puVar1[2];
        var_a4h = (float)puVar1[3] * fVar2;
        iVar11 = *(int64_t *)0x180781f28;
        cVar7 = (char)var_10h;
        cVar13 = (char)var_20h;
        uVar8 = func_0x0001800f5fa0(&var_b0h);
        var_b0h._0_4_ = *(float *)(iVar11 + 0xed0);
        var_b0h._4_4_ = *(float *)(iVar11 + 0xed4);
        uStack_a8 = *(undefined4 *)(iVar11 + 0xed8);
        var_a4h = *(float *)(iVar11 + 0xedc) * fVar2;
        uVar9 = func_0x0001800f5fa0(&var_b0h);
        if ((cVar7 != '\0') || (cVar13 != '\0')) {
            func_0x000180126550(*(undefined8 *)(iVar3 + 800), &var_a0h, &var_98h, uVar8, 0, 0);
        }
        func_0x0001800f7d00(&var_a0h, arg1 & 0xffffffff, 2);
        if (arg3 == 0) {
            uVar12 = 3;
            if (*(char *)(iVar3 + 0x10c) != '\0') {
                uVar12 = 1;
            }
            func_0x0001801301a0(*(undefined8 *)(iVar3 + 800), var_a0h, uVar9, uVar12, 0x3f800000);
        } else {
            fVar5 = (float)var_a0h;
            uVar12 = *(undefined8 *)(iVar3 + 800);
            fVar6 = var_a0h._4_4_;
            fVar2 = *(float *)(iVar4 + 0x12f8);
            var_b8h._0_4_ = fVar2 * 0.8 + (float)var_a0h;
            var_b0h._0_4_ = fVar2 * 0.2 + (float)var_a0h;
            var_b8h._4_4_ = fVar2 * 0.3 + var_a0h._4_4_;
            var_b0h._4_4_ = fVar2 * 0.15 + var_a0h._4_4_;
            func_0x000180126550(uVar12, &var_b0h, &var_b8h, uVar9, 0, 0);
            func_0x0001801305d0(uVar12, CONCAT44(fVar2 * 0.85 + fVar6, fVar2 * 0.5 + fVar5), 
                                CONCAT44(fVar2 * 0.4, fVar2 * 0.3));
        }
        if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
            (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) &&
           (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) {
            if (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc)) {
                func_0x0001800faaf0(iVar3, arg3, 1);
            }
        }
        uVar10 = uVar10 & 0xff;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18013b239
// Address: 0x18013b239
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013afb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    float fVar2;
    int64_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    char cVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    undefined8 uVar12;
    char cVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t in_stack_00000118;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined4 uStack_a8;
    float var_a4h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)0x180781f28;
    var_a0h = *(int64_t *)arg2;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    var_98h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)arg2;
    var_98h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)(arg2 + 4);
    cVar7 = func_0x00018010b530(&var_a0h, arg1 & 0xffffffff, 0, 0);
    uVar10 = fcn.180139d40((int64_t)&var_a0h, arg1 & 0xffffffff, (int64_t)&var_10h, (int64_t)&var_20h, 
                           (uint64_t)var_c8h._4_4_ << 0x20, in_stack_00000118);
    if (cVar7 != '\0') {
        if (((char)var_20h == '\0') || ((char)var_10h == '\0')) {
            iVar11 = (uint64_t)((char)var_10h != '\0') + 0x15;
        } else {
            iVar11 = 0x17;
        }
        fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar11 + 0x14) * 0x10);
        var_b0h._0_4_ = (float)*puVar1;
        var_b0h._4_4_ = (float)puVar1[1];
        uStack_a8 = puVar1[2];
        var_a4h = (float)puVar1[3] * fVar2;
        iVar11 = *(int64_t *)0x180781f28;
        cVar7 = (char)var_10h;
        cVar13 = (char)var_20h;
        uVar8 = func_0x0001800f5fa0(&var_b0h);
        var_b0h._0_4_ = *(float *)(iVar11 + 0xed0);
        var_b0h._4_4_ = *(float *)(iVar11 + 0xed4);
        uStack_a8 = *(undefined4 *)(iVar11 + 0xed8);
        var_a4h = *(float *)(iVar11 + 0xedc) * fVar2;
        uVar9 = func_0x0001800f5fa0(&var_b0h);
        if ((cVar7 != '\0') || (cVar13 != '\0')) {
            func_0x000180126550(*(undefined8 *)(iVar3 + 800), &var_a0h, &var_98h, uVar8, 0, 0);
        }
        func_0x0001800f7d00(&var_a0h, arg1 & 0xffffffff, 2);
        if (arg3 == 0) {
            uVar12 = 3;
            if (*(char *)(iVar3 + 0x10c) != '\0') {
                uVar12 = 1;
            }
            func_0x0001801301a0(*(undefined8 *)(iVar3 + 800), var_a0h, uVar9, uVar12, 0x3f800000);
        } else {
            fVar5 = (float)var_a0h;
            uVar12 = *(undefined8 *)(iVar3 + 800);
            fVar6 = var_a0h._4_4_;
            fVar2 = *(float *)(iVar4 + 0x12f8);
            var_b8h._0_4_ = fVar2 * 0.8 + (float)var_a0h;
            var_b0h._0_4_ = fVar2 * 0.2 + (float)var_a0h;
            var_b8h._4_4_ = fVar2 * 0.3 + var_a0h._4_4_;
            var_b0h._4_4_ = fVar2 * 0.15 + var_a0h._4_4_;
            func_0x000180126550(uVar12, &var_b0h, &var_b8h, uVar9, 0, 0);
            func_0x0001801305d0(uVar12, CONCAT44(fVar2 * 0.85 + fVar6, fVar2 * 0.5 + fVar5), 
                                CONCAT44(fVar2 * 0.4, fVar2 * 0.3));
        }
        if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
            (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) &&
           (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) {
            if (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc)) {
                func_0x0001800faaf0(iVar3, arg3, 1);
            }
        }
        uVar10 = uVar10 & 0xff;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18013b297
// Address: 0x18013b297
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_ach
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013afb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    float fVar2;
    int64_t iVar3;
    int64_t iVar4;
    float fVar5;
    float fVar6;
    char cVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    uint64_t uVar10;
    int64_t iVar11;
    undefined8 uVar12;
    char cVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t in_stack_00000118;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined4 uStack_a8;
    float var_a4h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)0x180781f28;
    var_a0h = *(int64_t *)arg2;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    var_98h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)arg2;
    var_98h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) + *(float *)(arg2 + 4);
    cVar7 = func_0x00018010b530(&var_a0h, arg1 & 0xffffffff, 0, 0);
    uVar10 = fcn.180139d40((int64_t)&var_a0h, arg1 & 0xffffffff, (int64_t)&var_10h, (int64_t)&var_20h, 
                           (uint64_t)var_c8h._4_4_ << 0x20, in_stack_00000118);
    if (cVar7 != '\0') {
        if (((char)var_20h == '\0') || ((char)var_10h == '\0')) {
            iVar11 = (uint64_t)((char)var_10h != '\0') + 0x15;
        } else {
            iVar11 = 0x17;
        }
        fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar11 + 0x14) * 0x10);
        var_b0h._0_4_ = (float)*puVar1;
        var_b0h._4_4_ = (float)puVar1[1];
        uStack_a8 = puVar1[2];
        var_a4h = (float)puVar1[3] * fVar2;
        iVar11 = *(int64_t *)0x180781f28;
        cVar7 = (char)var_10h;
        cVar13 = (char)var_20h;
        uVar8 = func_0x0001800f5fa0(&var_b0h);
        var_b0h._0_4_ = *(float *)(iVar11 + 0xed0);
        var_b0h._4_4_ = *(float *)(iVar11 + 0xed4);
        uStack_a8 = *(undefined4 *)(iVar11 + 0xed8);
        var_a4h = *(float *)(iVar11 + 0xedc) * fVar2;
        uVar9 = func_0x0001800f5fa0(&var_b0h);
        if ((cVar7 != '\0') || (cVar13 != '\0')) {
            func_0x000180126550(*(undefined8 *)(iVar3 + 800), &var_a0h, &var_98h, uVar8, 0, 0);
        }
        func_0x0001800f7d00(&var_a0h, arg1 & 0xffffffff, 2);
        if (arg3 == 0) {
            uVar12 = 3;
            if (*(char *)(iVar3 + 0x10c) != '\0') {
                uVar12 = 1;
            }
            func_0x0001801301a0(*(undefined8 *)(iVar3 + 800), var_a0h, uVar9, uVar12, 0x3f800000);
        } else {
            fVar5 = (float)var_a0h;
            uVar12 = *(undefined8 *)(iVar3 + 800);
            fVar6 = var_a0h._4_4_;
            fVar2 = *(float *)(iVar4 + 0x12f8);
            var_b8h._0_4_ = fVar2 * 0.8 + (float)var_a0h;
            var_b0h._0_4_ = fVar2 * 0.2 + (float)var_a0h;
            var_b8h._4_4_ = fVar2 * 0.3 + var_a0h._4_4_;
            var_b0h._4_4_ = fVar2 * 0.15 + var_a0h._4_4_;
            func_0x000180126550(uVar12, &var_b0h, &var_b8h, uVar9, 0, 0);
            func_0x0001801305d0(uVar12, CONCAT44(fVar2 * 0.85 + fVar6, fVar2 * 0.5 + fVar5), 
                                CONCAT44(fVar2 * 0.4, fVar2 * 0.3));
        }
        if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
            (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) &&
           (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) {
            if (*(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4) <=
                *(float *)(*(int64_t *)0x180781f28 + 0xbfc)) {
                func_0x0001800faaf0(iVar3, arg3, 1);
            }
        }
        uVar10 = uVar10 & 0xff;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18013b2f0
// Address: 0x18013b2f0
// Size: 305 bytes
// ============================================================
int64_t fcn.18013b2f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar2 = *(float *)(arg2 + 0xfc + ((int64_t)(int32_t)arg3 ^ 1U) * 4);
    fVar6 = (float)(int32_t)(*(float *)(arg2 + 0x9c) * 0.5 + 0.5);
    if ((*(uint32_t *)(arg2 + 0x14) >> 10 & 1) == 0) {
        fVar5 = fVar6;
        if ((*(uint32_t *)(arg2 + 0x14) & 1) == 0) {
            fVar5 = 0.0;
        }
    } else {
        fVar5 = (float)(int32_t)(*(float *)(*(int64_t *)0x180781f28 + 0xde8) * 0.5 + 0.5);
    }
    if ((int32_t)arg3 != 0) {
        fVar4 = *(float *)(arg2 + 0x60);
        fVar1 = *(float *)(arg2 + 0x284);
        fVar3 = (fVar4 + *(float *)(arg2 + 0x68)) - fVar6;
        *(float *)(arg1 + 4) = *(float *)(arg2 + 0x27c) + fVar5;
        *(float *)(arg1 + 8) = fVar3;
        fVar3 = fVar3 - fVar2;
        if (fVar4 <= fVar3) {
            fVar4 = fVar3;
        }
        *(float *)arg1 = fVar4;
        *(float *)(arg1 + 0xc) = fVar1 - fVar6;
        return arg1;
    }
    fVar5 = *(float *)(arg2 + 100);
    fVar4 = *(float *)(arg2 + 0x280);
    fVar1 = *(float *)(arg2 + 0x6c);
    fVar3 = fVar6 + fVar5;
    *(float *)arg1 = fVar6 + *(float *)(arg2 + 0x278);
    fVar5 = (fVar5 + fVar1) - fVar6;
    *(float *)(arg1 + 8) = fVar4 - fVar6;
    fVar2 = fVar5 - fVar2;
    if (fVar3 <= fVar2) {
        fVar3 = fVar2;
    }
    *(float *)(arg1 + 4) = fVar3;
    *(float *)(arg1 + 0xc) = fVar5;
    return arg1;
}

// ============================================================
// Function: FUN_18013b430
// Address: 0x18013b430
// Size: 428 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.18013b430(int64_t arg1)
{
    float fVar1;
    int64_t arg2;
    bool bVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    int64_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    undefined8 uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    float fStack_18;
    float var_14h;
    int64_t var_10h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar12 = (int64_t)(int32_t)arg1;
    uVar9 = 0x180645a58;
    arg2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if ((int32_t)arg1 == 0) {
        uVar9 = 0x180645a78;
    }
    uVar7 = func_0x0001800f5a90(uVar9, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
    uVar14 = (uint64_t)uVar7;
    iVar11 = arg2;
    fcn.18013b2f0((int64_t)&fStack_18, arg2, arg1 & 0xffffffff);
    if ((*(uint8_t *)(arg2 + 0x495) & 1) != 0) {
        iVar11 = *(int64_t *)(*(int64_t *)(arg2 + 0x4c0) + 0x98);
    }
    fVar1 = *(float *)(iVar6 + 0xdb0);
    bVar2 = fVar1 + *(float *)(iVar11 + 0x60) < fStack_18;
    bVar3 = (float)var_10h < (*(float *)(iVar11 + 0x60) + *(float *)(iVar11 + 0x68)) - fVar1;
    bVar4 = fVar1 + *(float *)(iVar11 + 100) < var_14h;
    bVar5 = var_10h._4_4_ < (*(float *)(iVar11 + 100) + *(float *)(iVar11 + 0x6c)) - fVar1;
    if ((bVar4) || (bVar2)) {
        uVar7 = 0x100;
        if (!bVar4) goto code_r0x00018013b51d;
code_r0x00018013b52a:
        uVar13 = 0;
    } else {
        uVar7 = 0x110;
code_r0x00018013b51d:
        if (bVar3) goto code_r0x00018013b52a;
        uVar13 = 0x20;
    }
    if ((bVar5) || (bVar2)) {
        uVar8 = 0;
        if (!bVar5) goto code_r0x00018013b542;
    } else {
        uVar8 = 0x40;
code_r0x00018013b542:
        if (!bVar3) {
            uVar10 = 0x80;
            goto code_r0x00018013b550;
        }
    }
    uVar10 = 0;
code_r0x00018013b550:
    fVar1 = *(float *)(arg2 + 0x90 + iVar12 * 4);
    iStackX_10 = (int64_t)*(float *)(arg2 + 0xd4 + iVar12 * 4);
    func_0x00018013b5e0(&fStack_18, uVar14 & 0xffffffff, arg1 & 0xffffffff, &iStackX_10, 
                        (int64_t)(*(float *)(arg2 + 0x280 + iVar12 * 4) - *(float *)(arg2 + 0x278 + iVar12 * 4)), 
                        (int64_t)(fVar1 + fVar1 + *(float *)(arg2 + 0x78 + iVar12 * 4)), uVar10 | uVar8 | uVar13 | uVar7
                       );
    *(float *)(arg2 + 0xd4 + iVar12 * 4) = (float)iStackX_10;
    return;
}

// ============================================================
// Function: FUN_18013b5e0
// Address: 0x18013b5e0
// Size: 420 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_147h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013b5e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h)
{
    float *pfVar1;
    int16_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    int64_t var_8h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined4 in_stack_00000038;
    int64_t in_stack_00000088;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    float var_130h;
    float var_12ch;
    float var_128h;
    int64_t var_124h;
    float var_11ch;
    float var_118h [2];
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [4];
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    undefined4 uStack_e8;
    undefined4 uStack_e4;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg3;
    var_138h = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    puVar7 = (undefined *)*(BADSPACEBASE **)0x20;
    if (*(char *)(var_138h + 0x10e) != '\0') {
code_r0x00018013bc9a:
        return (uint64_t)puVar7 & 0xffffffffffffff00;
    }
    fVar15 = *(float *)(arg1 + 8) - *(float *)arg1;
    if ((fVar15 <= 0.0) || (fVar17 = *(float *)(arg1 + 0xc) - *(float *)(arg1 + 4), fVar17 <= 0.0))
    goto code_r0x00018013bc9a;
    fVar22 = 1.0;
    if ((iVar10 == 1) && (fVar17 < fVar15)) {
        fVar13 = fVar15 + fVar15;
        if (fVar13 <= 1.0) {
            fVar13 = 1.0;
        }
        fVar13 = fVar17 / fVar13;
        if (0.0 <= fVar13) {
            fVar22 = 1.0;
            if (fVar13 <= 1.0) {
                fVar22 = fVar13;
            }
        } else {
            fVar22 = 0.0;
        }
        if (fVar22 <= 0.0) goto code_r0x00018013bc9a;
    }
    if (fVar17 <= fVar15) {
        fVar15 = fVar17;
    }
    fVar17 = *(float *)(*(int64_t *)0x180781f28 + 0xe1c);
    if (fVar15 * 0.5 <= *(float *)(*(int64_t *)0x180781f28 + 0xe1c)) {
        fVar17 = fVar15 * 0.5;
    }
    puVar7 = (undefined *)CONCAT44((int32_t)((uint64_t)&stack0x00000000 >> 0x20), (int32_t)fVar17);
    fVar17 = (float)((uint32_t)(float)(int32_t)fVar17 ^ 0x80000000);
    fVar21 = *(float *)(arg1 + 0xc) + fVar17;
    fVar23 = *(float *)(arg1 + 4) - fVar17;
    fVar13 = *(float *)(arg1 + 8) + fVar17;
    fVar17 = *(float *)arg1 - fVar17;
    var_108h._4_4_ = fVar21;
    var_110h._4_4_ = fVar23;
    var_108h._0_4_ = fVar13;
    var_110h._0_4_ = fVar17;
    fVar15 = fVar21 - fVar23;
    if (iVar10 == 0) {
        fVar15 = fVar13 - fVar17;
    }
    if (fVar15 < 1.0) goto code_r0x00018013bc9a;
    var_118h[1] = fVar21 - fVar23;
    iVar11 = in_stack_00000028;
    if (in_stack_00000028 <= in_stack_00000030) {
        iVar11 = in_stack_00000030;
    }
    uVar12 = (uint64_t)iVar10;
    iVar9 = 1;
    if (0 < iVar11) {
        iVar9 = iVar11;
    }
    var_118h[0] = fVar13 - fVar17;
    fVar20 = var_118h[uVar12];
    if (*(float *)(*(int64_t *)0x180781f28 + 0xe20) <= var_118h[uVar12]) {
        fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    }
    var_118h[0] = (float)in_stack_00000028;
    fVar18 = ((float)in_stack_00000028 / (float)iVar9) * fVar15;
    if ((fVar20 <= fVar18) && (fVar20 = fVar15, fVar18 <= fVar15)) {
        fVar20 = fVar18;
    }
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xdb0);
    uStack_f0 = *(undefined4 *)arg1;
    uStack_ec = *(undefined4 *)(arg1 + 4);
    uStack_e8 = *(undefined4 *)(arg1 + 8);
    uStack_e4 = *(undefined4 *)(arg1 + 0xc);
    iVar11 = *(int64_t *)(var_138h + 0x418);
    var_100h[0] = *(float *)(iVar11 + 0x60);
    var_100h[1] = *(float *)(iVar11 + 100);
    iVar9 = *(int64_t *)(var_138h + 0x48);
    var_100h[2] = *(float *)(iVar11 + 0x60) + *(float *)(iVar11 + 0x68);
    var_100h[3] = *(float *)(iVar11 + 100) + *(float *)(iVar11 + 0x6c);
    var_124h._0_4_ = *(float *)(iVar9 + 0xc);
    var_128h = *(float *)(iVar9 + 8);
    uVar8 = uVar12 ^ 1;
    var_11ch = *(float *)(iVar9 + 0xc) + *(float *)(iVar9 + 0x14);
    var_124h._4_4_ = *(float *)(iVar9 + 8) + *(float *)(iVar9 + 0x10);
    fVar19 = var_100h[uVar8];
    if (((fVar19 == (&var_128h)[uVar8]) && (fVar19 < var_100h[uVar8 + 4])) && (var_100h[uVar8 + 4] - fVar18 <= fVar19))
    {
        var_100h[uVar8 + 4] = fVar19;
    }
    fVar19 = var_100h[uVar8 + 2];
    if (((fVar19 == *(float *)((int64_t)&var_124h + uVar8 * 4 + 4)) && (var_100h[uVar8 + 6] < fVar19)) &&
       (fVar19 <= var_100h[uVar8 + 6] + fVar18)) {
        var_100h[uVar8 + 6] = fVar19;
    }
    var_148h._0_1_ = 0;
    var_148h._1_1_ = '\0';
    var_140h._0_4_ = (float)(int32_t)fVar20;
    func_0x00018010b530(arg1, arg2 & 0xffffffff, 0, 2);
    fcn.180139d40((int64_t)(var_100h + 4), arg2 & 0xffffffff, (int64_t)&var_148h + 1, (int64_t)&var_148h, 
                  CONCAT44(var_158h._4_4_, 0x40000), in_stack_00000088);
    iVar11 = in_stack_00000030 - in_stack_00000028;
    if (iVar11 < 2) {
        iVar11 = 1;
    }
    var_148h._4_4_ = (float)iVar11;
    fVar18 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    if (0.0 <= fVar18) {
        fVar19 = 1.0;
        if (fVar18 <= 1.0) {
            fVar19 = fVar18;
        }
    } else {
        fVar19 = 0.0;
    }
    fVar20 = fVar15 - (float)(int32_t)fVar20;
    fVar18 = (fVar20 * fVar19) / fVar15;
    if ((((uint8_t)var_148h == 0) || (fVar22 < 1.0)) || (fVar19 = (float)var_140h / fVar15, 1.0 <= fVar19))
    goto code_r0x00018013bb2a;
    fVar14 = (*(float *)(iVar3 + 0x118 + uVar12 * 4) - *(float *)((int64_t)&var_110h + uVar12 * 4)) / fVar15;
    if (0.0 <= fVar14) {
        fVar16 = 1.0;
        if (fVar14 <= 1.0) {
            fVar16 = fVar14;
        }
    } else {
        fVar16 = 0.0;
    }
    if (fVar18 <= fVar16) {
        uVar5 = (uint32_t)(fVar19 + fVar18 < fVar16);
    } else {
        uVar5 = 0xffffffff;
    }
    if (*(char *)(iVar3 + 0x1660) != '\0') {
        if (((*(char *)(iVar3 + 0x95) == '\0') || (*(char *)(iVar3 + 0x139) != '\0')) || (uVar5 == 0)) {
            *(undefined2 *)(iVar3 + 0x27fe) = 0;
            if ((uVar5 == 0) && (*(char *)(iVar3 + 0x139) == '\0')) {
                *(float *)(iVar3 + 0x2800) = (fVar16 - fVar18) - fVar19 * 0.5;
                goto code_r0x00018013ba66;
            }
        } else {
            *(int16_t *)(iVar3 + 0x27fe) = (int16_t)uVar5;
        }
        *(undefined4 *)(iVar3 + 0x2800) = 0;
    }
code_r0x00018013ba66:
    iVar2 = *(int16_t *)(iVar3 + 0x27fe);
    if (iVar2 == 0) {
        fVar18 = ((fVar16 - *(float *)(iVar3 + 0x2800)) - fVar19 * 0.5) / (1.0 - fVar19);
        if (0.0 <= fVar18) {
            fVar19 = 1.0;
            if (fVar18 <= 1.0) {
                fVar19 = fVar18;
            }
        } else {
            fVar19 = 0.0;
        }
        *(int64_t *)arg4 = (int64_t)(fVar19 * var_148h._4_4_);
    } else {
        cVar4 = func_0x000180107ff0(0, 1, 0);
        if ((cVar4 != '\0') && (uVar5 == (int32_t)iVar2)) {
            if ((float)(int32_t)iVar2 <= 0.0) {
                fVar18 = -1.0;
            } else {
                fVar18 = 1.0;
            }
            iVar9 = (int64_t)(var_118h[0] * fVar18) + *(int64_t *)arg4;
            if (iVar9 < 0) {
                iVar9 = 0;
            } else if (iVar11 < iVar9) {
                iVar9 = iVar11;
            }
            *(int64_t *)arg4 = iVar9;
        }
    }
    fVar19 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    fVar18 = 0.0;
    if ((0.0 <= fVar19) && (fVar18 = 1.0, fVar19 <= 1.0)) {
        fVar18 = fVar19;
    }
    fVar18 = (fVar20 * fVar18) / fVar15;
code_r0x00018013bb2a:
    var_128h = *(float *)(*(int64_t *)0x180781f28 + 0xfb0);
    var_124h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb4);
    var_124h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb8);
    fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_11ch = *(float *)(*(int64_t *)0x180781f28 + 0xfbc) * fVar15;
    iVar11 = *(int64_t *)0x180781f28;
    uVar5 = func_0x0001800f5fa0(&var_128h);
    uVar12 = (uint64_t)uVar5;
    if ((uint8_t)var_148h == 0) {
        iVar9 = (uint64_t)(var_148h._1_1_ != '\0') + 0xf;
    } else {
        iVar9 = 0x11;
    }
    pfVar1 = (float *)(iVar11 + (iVar9 + 0xed) * 0x10);
    var_128h = *pfVar1;
    var_124h._0_4_ = pfVar1[1];
    var_124h._4_4_ = pfVar1[2];
    var_11ch = pfVar1[3] * fVar15 * fVar22;
    uVar6 = func_0x0001800f5fa0(&var_128h);
    iVar11 = var_138h;
    func_0x000180126550(*(undefined8 *)(var_138h + 800), arg1, arg1 + 8, uVar12 & 0xffffffff, 
                        *(undefined4 *)(var_138h + 0x98), in_stack_00000038);
    if (iVar10 == 0) {
        fVar17 = (fVar13 - fVar17) * fVar18 + fVar17;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar13 = fVar17 + (float)var_140h;
    } else {
        fVar23 = (fVar21 - fVar23) * fVar18 + fVar23;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar21 = fVar23 + (float)var_140h;
    }
    var_130h = fVar13;
    var_12ch = fVar21;
    func_0x000180126550(*(undefined8 *)(iVar11 + 800), &var_138h, &var_130h, uVar6, *(undefined4 *)(iVar3 + 0xe18), 0);
    return (uint64_t)(uint8_t)var_148h;
}

// ============================================================
// Function: FUN_18013b784
// Address: 0x18013b784
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_147h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013b5e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h)
{
    float *pfVar1;
    int16_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    int64_t var_8h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined4 in_stack_00000038;
    int64_t in_stack_00000088;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    float var_130h;
    float var_12ch;
    float var_128h;
    int64_t var_124h;
    float var_11ch;
    float var_118h [2];
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [4];
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    undefined4 uStack_e8;
    undefined4 uStack_e4;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg3;
    var_138h = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    puVar7 = (undefined *)*(BADSPACEBASE **)0x20;
    if (*(char *)(var_138h + 0x10e) != '\0') {
code_r0x00018013bc9a:
        return (uint64_t)puVar7 & 0xffffffffffffff00;
    }
    fVar15 = *(float *)(arg1 + 8) - *(float *)arg1;
    if ((fVar15 <= 0.0) || (fVar17 = *(float *)(arg1 + 0xc) - *(float *)(arg1 + 4), fVar17 <= 0.0))
    goto code_r0x00018013bc9a;
    fVar22 = 1.0;
    if ((iVar10 == 1) && (fVar17 < fVar15)) {
        fVar13 = fVar15 + fVar15;
        if (fVar13 <= 1.0) {
            fVar13 = 1.0;
        }
        fVar13 = fVar17 / fVar13;
        if (0.0 <= fVar13) {
            fVar22 = 1.0;
            if (fVar13 <= 1.0) {
                fVar22 = fVar13;
            }
        } else {
            fVar22 = 0.0;
        }
        if (fVar22 <= 0.0) goto code_r0x00018013bc9a;
    }
    if (fVar17 <= fVar15) {
        fVar15 = fVar17;
    }
    fVar17 = *(float *)(*(int64_t *)0x180781f28 + 0xe1c);
    if (fVar15 * 0.5 <= *(float *)(*(int64_t *)0x180781f28 + 0xe1c)) {
        fVar17 = fVar15 * 0.5;
    }
    puVar7 = (undefined *)CONCAT44((int32_t)((uint64_t)&stack0x00000000 >> 0x20), (int32_t)fVar17);
    fVar17 = (float)((uint32_t)(float)(int32_t)fVar17 ^ 0x80000000);
    fVar21 = *(float *)(arg1 + 0xc) + fVar17;
    fVar23 = *(float *)(arg1 + 4) - fVar17;
    fVar13 = *(float *)(arg1 + 8) + fVar17;
    fVar17 = *(float *)arg1 - fVar17;
    var_108h._4_4_ = fVar21;
    var_110h._4_4_ = fVar23;
    var_108h._0_4_ = fVar13;
    var_110h._0_4_ = fVar17;
    fVar15 = fVar21 - fVar23;
    if (iVar10 == 0) {
        fVar15 = fVar13 - fVar17;
    }
    if (fVar15 < 1.0) goto code_r0x00018013bc9a;
    var_118h[1] = fVar21 - fVar23;
    iVar11 = in_stack_00000028;
    if (in_stack_00000028 <= in_stack_00000030) {
        iVar11 = in_stack_00000030;
    }
    uVar12 = (uint64_t)iVar10;
    iVar9 = 1;
    if (0 < iVar11) {
        iVar9 = iVar11;
    }
    var_118h[0] = fVar13 - fVar17;
    fVar20 = var_118h[uVar12];
    if (*(float *)(*(int64_t *)0x180781f28 + 0xe20) <= var_118h[uVar12]) {
        fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    }
    var_118h[0] = (float)in_stack_00000028;
    fVar18 = ((float)in_stack_00000028 / (float)iVar9) * fVar15;
    if ((fVar20 <= fVar18) && (fVar20 = fVar15, fVar18 <= fVar15)) {
        fVar20 = fVar18;
    }
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xdb0);
    uStack_f0 = *(undefined4 *)arg1;
    uStack_ec = *(undefined4 *)(arg1 + 4);
    uStack_e8 = *(undefined4 *)(arg1 + 8);
    uStack_e4 = *(undefined4 *)(arg1 + 0xc);
    iVar11 = *(int64_t *)(var_138h + 0x418);
    var_100h[0] = *(float *)(iVar11 + 0x60);
    var_100h[1] = *(float *)(iVar11 + 100);
    iVar9 = *(int64_t *)(var_138h + 0x48);
    var_100h[2] = *(float *)(iVar11 + 0x60) + *(float *)(iVar11 + 0x68);
    var_100h[3] = *(float *)(iVar11 + 100) + *(float *)(iVar11 + 0x6c);
    var_124h._0_4_ = *(float *)(iVar9 + 0xc);
    var_128h = *(float *)(iVar9 + 8);
    uVar8 = uVar12 ^ 1;
    var_11ch = *(float *)(iVar9 + 0xc) + *(float *)(iVar9 + 0x14);
    var_124h._4_4_ = *(float *)(iVar9 + 8) + *(float *)(iVar9 + 0x10);
    fVar19 = var_100h[uVar8];
    if (((fVar19 == (&var_128h)[uVar8]) && (fVar19 < var_100h[uVar8 + 4])) && (var_100h[uVar8 + 4] - fVar18 <= fVar19))
    {
        var_100h[uVar8 + 4] = fVar19;
    }
    fVar19 = var_100h[uVar8 + 2];
    if (((fVar19 == *(float *)((int64_t)&var_124h + uVar8 * 4 + 4)) && (var_100h[uVar8 + 6] < fVar19)) &&
       (fVar19 <= var_100h[uVar8 + 6] + fVar18)) {
        var_100h[uVar8 + 6] = fVar19;
    }
    var_148h._0_1_ = 0;
    var_148h._1_1_ = '\0';
    var_140h._0_4_ = (float)(int32_t)fVar20;
    func_0x00018010b530(arg1, arg2 & 0xffffffff, 0, 2);
    fcn.180139d40((int64_t)(var_100h + 4), arg2 & 0xffffffff, (int64_t)&var_148h + 1, (int64_t)&var_148h, 
                  CONCAT44(var_158h._4_4_, 0x40000), in_stack_00000088);
    iVar11 = in_stack_00000030 - in_stack_00000028;
    if (iVar11 < 2) {
        iVar11 = 1;
    }
    var_148h._4_4_ = (float)iVar11;
    fVar18 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    if (0.0 <= fVar18) {
        fVar19 = 1.0;
        if (fVar18 <= 1.0) {
            fVar19 = fVar18;
        }
    } else {
        fVar19 = 0.0;
    }
    fVar20 = fVar15 - (float)(int32_t)fVar20;
    fVar18 = (fVar20 * fVar19) / fVar15;
    if ((((uint8_t)var_148h == 0) || (fVar22 < 1.0)) || (fVar19 = (float)var_140h / fVar15, 1.0 <= fVar19))
    goto code_r0x00018013bb2a;
    fVar14 = (*(float *)(iVar3 + 0x118 + uVar12 * 4) - *(float *)((int64_t)&var_110h + uVar12 * 4)) / fVar15;
    if (0.0 <= fVar14) {
        fVar16 = 1.0;
        if (fVar14 <= 1.0) {
            fVar16 = fVar14;
        }
    } else {
        fVar16 = 0.0;
    }
    if (fVar18 <= fVar16) {
        uVar5 = (uint32_t)(fVar19 + fVar18 < fVar16);
    } else {
        uVar5 = 0xffffffff;
    }
    if (*(char *)(iVar3 + 0x1660) != '\0') {
        if (((*(char *)(iVar3 + 0x95) == '\0') || (*(char *)(iVar3 + 0x139) != '\0')) || (uVar5 == 0)) {
            *(undefined2 *)(iVar3 + 0x27fe) = 0;
            if ((uVar5 == 0) && (*(char *)(iVar3 + 0x139) == '\0')) {
                *(float *)(iVar3 + 0x2800) = (fVar16 - fVar18) - fVar19 * 0.5;
                goto code_r0x00018013ba66;
            }
        } else {
            *(int16_t *)(iVar3 + 0x27fe) = (int16_t)uVar5;
        }
        *(undefined4 *)(iVar3 + 0x2800) = 0;
    }
code_r0x00018013ba66:
    iVar2 = *(int16_t *)(iVar3 + 0x27fe);
    if (iVar2 == 0) {
        fVar18 = ((fVar16 - *(float *)(iVar3 + 0x2800)) - fVar19 * 0.5) / (1.0 - fVar19);
        if (0.0 <= fVar18) {
            fVar19 = 1.0;
            if (fVar18 <= 1.0) {
                fVar19 = fVar18;
            }
        } else {
            fVar19 = 0.0;
        }
        *(int64_t *)arg4 = (int64_t)(fVar19 * var_148h._4_4_);
    } else {
        cVar4 = func_0x000180107ff0(0, 1, 0);
        if ((cVar4 != '\0') && (uVar5 == (int32_t)iVar2)) {
            if ((float)(int32_t)iVar2 <= 0.0) {
                fVar18 = -1.0;
            } else {
                fVar18 = 1.0;
            }
            iVar9 = (int64_t)(var_118h[0] * fVar18) + *(int64_t *)arg4;
            if (iVar9 < 0) {
                iVar9 = 0;
            } else if (iVar11 < iVar9) {
                iVar9 = iVar11;
            }
            *(int64_t *)arg4 = iVar9;
        }
    }
    fVar19 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    fVar18 = 0.0;
    if ((0.0 <= fVar19) && (fVar18 = 1.0, fVar19 <= 1.0)) {
        fVar18 = fVar19;
    }
    fVar18 = (fVar20 * fVar18) / fVar15;
code_r0x00018013bb2a:
    var_128h = *(float *)(*(int64_t *)0x180781f28 + 0xfb0);
    var_124h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb4);
    var_124h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb8);
    fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_11ch = *(float *)(*(int64_t *)0x180781f28 + 0xfbc) * fVar15;
    iVar11 = *(int64_t *)0x180781f28;
    uVar5 = func_0x0001800f5fa0(&var_128h);
    uVar12 = (uint64_t)uVar5;
    if ((uint8_t)var_148h == 0) {
        iVar9 = (uint64_t)(var_148h._1_1_ != '\0') + 0xf;
    } else {
        iVar9 = 0x11;
    }
    pfVar1 = (float *)(iVar11 + (iVar9 + 0xed) * 0x10);
    var_128h = *pfVar1;
    var_124h._0_4_ = pfVar1[1];
    var_124h._4_4_ = pfVar1[2];
    var_11ch = pfVar1[3] * fVar15 * fVar22;
    uVar6 = func_0x0001800f5fa0(&var_128h);
    iVar11 = var_138h;
    func_0x000180126550(*(undefined8 *)(var_138h + 800), arg1, arg1 + 8, uVar12 & 0xffffffff, 
                        *(undefined4 *)(var_138h + 0x98), in_stack_00000038);
    if (iVar10 == 0) {
        fVar17 = (fVar13 - fVar17) * fVar18 + fVar17;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar13 = fVar17 + (float)var_140h;
    } else {
        fVar23 = (fVar21 - fVar23) * fVar18 + fVar23;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar21 = fVar23 + (float)var_140h;
    }
    var_130h = fVar13;
    var_12ch = fVar21;
    func_0x000180126550(*(undefined8 *)(iVar11 + 800), &var_138h, &var_130h, uVar6, *(undefined4 *)(iVar3 + 0xe18), 0);
    return (uint64_t)(uint8_t)var_148h;
}

// ============================================================
// Function: FUN_18013b79b
// Address: 0x18013b79b
// Size: 982 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_147h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013b5e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h)
{
    float *pfVar1;
    int16_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    int64_t var_8h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined4 in_stack_00000038;
    int64_t in_stack_00000088;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    float var_130h;
    float var_12ch;
    float var_128h;
    int64_t var_124h;
    float var_11ch;
    float var_118h [2];
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [4];
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    undefined4 uStack_e8;
    undefined4 uStack_e4;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg3;
    var_138h = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    puVar7 = (undefined *)*(BADSPACEBASE **)0x20;
    if (*(char *)(var_138h + 0x10e) != '\0') {
code_r0x00018013bc9a:
        return (uint64_t)puVar7 & 0xffffffffffffff00;
    }
    fVar15 = *(float *)(arg1 + 8) - *(float *)arg1;
    if ((fVar15 <= 0.0) || (fVar17 = *(float *)(arg1 + 0xc) - *(float *)(arg1 + 4), fVar17 <= 0.0))
    goto code_r0x00018013bc9a;
    fVar22 = 1.0;
    if ((iVar10 == 1) && (fVar17 < fVar15)) {
        fVar13 = fVar15 + fVar15;
        if (fVar13 <= 1.0) {
            fVar13 = 1.0;
        }
        fVar13 = fVar17 / fVar13;
        if (0.0 <= fVar13) {
            fVar22 = 1.0;
            if (fVar13 <= 1.0) {
                fVar22 = fVar13;
            }
        } else {
            fVar22 = 0.0;
        }
        if (fVar22 <= 0.0) goto code_r0x00018013bc9a;
    }
    if (fVar17 <= fVar15) {
        fVar15 = fVar17;
    }
    fVar17 = *(float *)(*(int64_t *)0x180781f28 + 0xe1c);
    if (fVar15 * 0.5 <= *(float *)(*(int64_t *)0x180781f28 + 0xe1c)) {
        fVar17 = fVar15 * 0.5;
    }
    puVar7 = (undefined *)CONCAT44((int32_t)((uint64_t)&stack0x00000000 >> 0x20), (int32_t)fVar17);
    fVar17 = (float)((uint32_t)(float)(int32_t)fVar17 ^ 0x80000000);
    fVar21 = *(float *)(arg1 + 0xc) + fVar17;
    fVar23 = *(float *)(arg1 + 4) - fVar17;
    fVar13 = *(float *)(arg1 + 8) + fVar17;
    fVar17 = *(float *)arg1 - fVar17;
    var_108h._4_4_ = fVar21;
    var_110h._4_4_ = fVar23;
    var_108h._0_4_ = fVar13;
    var_110h._0_4_ = fVar17;
    fVar15 = fVar21 - fVar23;
    if (iVar10 == 0) {
        fVar15 = fVar13 - fVar17;
    }
    if (fVar15 < 1.0) goto code_r0x00018013bc9a;
    var_118h[1] = fVar21 - fVar23;
    iVar11 = in_stack_00000028;
    if (in_stack_00000028 <= in_stack_00000030) {
        iVar11 = in_stack_00000030;
    }
    uVar12 = (uint64_t)iVar10;
    iVar9 = 1;
    if (0 < iVar11) {
        iVar9 = iVar11;
    }
    var_118h[0] = fVar13 - fVar17;
    fVar20 = var_118h[uVar12];
    if (*(float *)(*(int64_t *)0x180781f28 + 0xe20) <= var_118h[uVar12]) {
        fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    }
    var_118h[0] = (float)in_stack_00000028;
    fVar18 = ((float)in_stack_00000028 / (float)iVar9) * fVar15;
    if ((fVar20 <= fVar18) && (fVar20 = fVar15, fVar18 <= fVar15)) {
        fVar20 = fVar18;
    }
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xdb0);
    uStack_f0 = *(undefined4 *)arg1;
    uStack_ec = *(undefined4 *)(arg1 + 4);
    uStack_e8 = *(undefined4 *)(arg1 + 8);
    uStack_e4 = *(undefined4 *)(arg1 + 0xc);
    iVar11 = *(int64_t *)(var_138h + 0x418);
    var_100h[0] = *(float *)(iVar11 + 0x60);
    var_100h[1] = *(float *)(iVar11 + 100);
    iVar9 = *(int64_t *)(var_138h + 0x48);
    var_100h[2] = *(float *)(iVar11 + 0x60) + *(float *)(iVar11 + 0x68);
    var_100h[3] = *(float *)(iVar11 + 100) + *(float *)(iVar11 + 0x6c);
    var_124h._0_4_ = *(float *)(iVar9 + 0xc);
    var_128h = *(float *)(iVar9 + 8);
    uVar8 = uVar12 ^ 1;
    var_11ch = *(float *)(iVar9 + 0xc) + *(float *)(iVar9 + 0x14);
    var_124h._4_4_ = *(float *)(iVar9 + 8) + *(float *)(iVar9 + 0x10);
    fVar19 = var_100h[uVar8];
    if (((fVar19 == (&var_128h)[uVar8]) && (fVar19 < var_100h[uVar8 + 4])) && (var_100h[uVar8 + 4] - fVar18 <= fVar19))
    {
        var_100h[uVar8 + 4] = fVar19;
    }
    fVar19 = var_100h[uVar8 + 2];
    if (((fVar19 == *(float *)((int64_t)&var_124h + uVar8 * 4 + 4)) && (var_100h[uVar8 + 6] < fVar19)) &&
       (fVar19 <= var_100h[uVar8 + 6] + fVar18)) {
        var_100h[uVar8 + 6] = fVar19;
    }
    var_148h._0_1_ = 0;
    var_148h._1_1_ = '\0';
    var_140h._0_4_ = (float)(int32_t)fVar20;
    func_0x00018010b530(arg1, arg2 & 0xffffffff, 0, 2);
    fcn.180139d40((int64_t)(var_100h + 4), arg2 & 0xffffffff, (int64_t)&var_148h + 1, (int64_t)&var_148h, 
                  CONCAT44(var_158h._4_4_, 0x40000), in_stack_00000088);
    iVar11 = in_stack_00000030 - in_stack_00000028;
    if (iVar11 < 2) {
        iVar11 = 1;
    }
    var_148h._4_4_ = (float)iVar11;
    fVar18 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    if (0.0 <= fVar18) {
        fVar19 = 1.0;
        if (fVar18 <= 1.0) {
            fVar19 = fVar18;
        }
    } else {
        fVar19 = 0.0;
    }
    fVar20 = fVar15 - (float)(int32_t)fVar20;
    fVar18 = (fVar20 * fVar19) / fVar15;
    if ((((uint8_t)var_148h == 0) || (fVar22 < 1.0)) || (fVar19 = (float)var_140h / fVar15, 1.0 <= fVar19))
    goto code_r0x00018013bb2a;
    fVar14 = (*(float *)(iVar3 + 0x118 + uVar12 * 4) - *(float *)((int64_t)&var_110h + uVar12 * 4)) / fVar15;
    if (0.0 <= fVar14) {
        fVar16 = 1.0;
        if (fVar14 <= 1.0) {
            fVar16 = fVar14;
        }
    } else {
        fVar16 = 0.0;
    }
    if (fVar18 <= fVar16) {
        uVar5 = (uint32_t)(fVar19 + fVar18 < fVar16);
    } else {
        uVar5 = 0xffffffff;
    }
    if (*(char *)(iVar3 + 0x1660) != '\0') {
        if (((*(char *)(iVar3 + 0x95) == '\0') || (*(char *)(iVar3 + 0x139) != '\0')) || (uVar5 == 0)) {
            *(undefined2 *)(iVar3 + 0x27fe) = 0;
            if ((uVar5 == 0) && (*(char *)(iVar3 + 0x139) == '\0')) {
                *(float *)(iVar3 + 0x2800) = (fVar16 - fVar18) - fVar19 * 0.5;
                goto code_r0x00018013ba66;
            }
        } else {
            *(int16_t *)(iVar3 + 0x27fe) = (int16_t)uVar5;
        }
        *(undefined4 *)(iVar3 + 0x2800) = 0;
    }
code_r0x00018013ba66:
    iVar2 = *(int16_t *)(iVar3 + 0x27fe);
    if (iVar2 == 0) {
        fVar18 = ((fVar16 - *(float *)(iVar3 + 0x2800)) - fVar19 * 0.5) / (1.0 - fVar19);
        if (0.0 <= fVar18) {
            fVar19 = 1.0;
            if (fVar18 <= 1.0) {
                fVar19 = fVar18;
            }
        } else {
            fVar19 = 0.0;
        }
        *(int64_t *)arg4 = (int64_t)(fVar19 * var_148h._4_4_);
    } else {
        cVar4 = func_0x000180107ff0(0, 1, 0);
        if ((cVar4 != '\0') && (uVar5 == (int32_t)iVar2)) {
            if ((float)(int32_t)iVar2 <= 0.0) {
                fVar18 = -1.0;
            } else {
                fVar18 = 1.0;
            }
            iVar9 = (int64_t)(var_118h[0] * fVar18) + *(int64_t *)arg4;
            if (iVar9 < 0) {
                iVar9 = 0;
            } else if (iVar11 < iVar9) {
                iVar9 = iVar11;
            }
            *(int64_t *)arg4 = iVar9;
        }
    }
    fVar19 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    fVar18 = 0.0;
    if ((0.0 <= fVar19) && (fVar18 = 1.0, fVar19 <= 1.0)) {
        fVar18 = fVar19;
    }
    fVar18 = (fVar20 * fVar18) / fVar15;
code_r0x00018013bb2a:
    var_128h = *(float *)(*(int64_t *)0x180781f28 + 0xfb0);
    var_124h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb4);
    var_124h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb8);
    fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_11ch = *(float *)(*(int64_t *)0x180781f28 + 0xfbc) * fVar15;
    iVar11 = *(int64_t *)0x180781f28;
    uVar5 = func_0x0001800f5fa0(&var_128h);
    uVar12 = (uint64_t)uVar5;
    if ((uint8_t)var_148h == 0) {
        iVar9 = (uint64_t)(var_148h._1_1_ != '\0') + 0xf;
    } else {
        iVar9 = 0x11;
    }
    pfVar1 = (float *)(iVar11 + (iVar9 + 0xed) * 0x10);
    var_128h = *pfVar1;
    var_124h._0_4_ = pfVar1[1];
    var_124h._4_4_ = pfVar1[2];
    var_11ch = pfVar1[3] * fVar15 * fVar22;
    uVar6 = func_0x0001800f5fa0(&var_128h);
    iVar11 = var_138h;
    func_0x000180126550(*(undefined8 *)(var_138h + 800), arg1, arg1 + 8, uVar12 & 0xffffffff, 
                        *(undefined4 *)(var_138h + 0x98), in_stack_00000038);
    if (iVar10 == 0) {
        fVar17 = (fVar13 - fVar17) * fVar18 + fVar17;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar13 = fVar17 + (float)var_140h;
    } else {
        fVar23 = (fVar21 - fVar23) * fVar18 + fVar23;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar21 = fVar23 + (float)var_140h;
    }
    var_130h = fVar13;
    var_12ch = fVar21;
    func_0x000180126550(*(undefined8 *)(iVar11 + 800), &var_138h, &var_130h, uVar6, *(undefined4 *)(iVar3 + 0xe18), 0);
    return (uint64_t)(uint8_t)var_148h;
}

// ============================================================
// Function: FUN_18013bb71
// Address: 0x18013bb71
// Size: 297 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_147h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013b5e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h)
{
    float *pfVar1;
    int16_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    int64_t var_8h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined4 in_stack_00000038;
    int64_t in_stack_00000088;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    float var_130h;
    float var_12ch;
    float var_128h;
    int64_t var_124h;
    float var_11ch;
    float var_118h [2];
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [4];
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    undefined4 uStack_e8;
    undefined4 uStack_e4;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg3;
    var_138h = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    puVar7 = (undefined *)*(BADSPACEBASE **)0x20;
    if (*(char *)(var_138h + 0x10e) != '\0') {
code_r0x00018013bc9a:
        return (uint64_t)puVar7 & 0xffffffffffffff00;
    }
    fVar15 = *(float *)(arg1 + 8) - *(float *)arg1;
    if ((fVar15 <= 0.0) || (fVar17 = *(float *)(arg1 + 0xc) - *(float *)(arg1 + 4), fVar17 <= 0.0))
    goto code_r0x00018013bc9a;
    fVar22 = 1.0;
    if ((iVar10 == 1) && (fVar17 < fVar15)) {
        fVar13 = fVar15 + fVar15;
        if (fVar13 <= 1.0) {
            fVar13 = 1.0;
        }
        fVar13 = fVar17 / fVar13;
        if (0.0 <= fVar13) {
            fVar22 = 1.0;
            if (fVar13 <= 1.0) {
                fVar22 = fVar13;
            }
        } else {
            fVar22 = 0.0;
        }
        if (fVar22 <= 0.0) goto code_r0x00018013bc9a;
    }
    if (fVar17 <= fVar15) {
        fVar15 = fVar17;
    }
    fVar17 = *(float *)(*(int64_t *)0x180781f28 + 0xe1c);
    if (fVar15 * 0.5 <= *(float *)(*(int64_t *)0x180781f28 + 0xe1c)) {
        fVar17 = fVar15 * 0.5;
    }
    puVar7 = (undefined *)CONCAT44((int32_t)((uint64_t)&stack0x00000000 >> 0x20), (int32_t)fVar17);
    fVar17 = (float)((uint32_t)(float)(int32_t)fVar17 ^ 0x80000000);
    fVar21 = *(float *)(arg1 + 0xc) + fVar17;
    fVar23 = *(float *)(arg1 + 4) - fVar17;
    fVar13 = *(float *)(arg1 + 8) + fVar17;
    fVar17 = *(float *)arg1 - fVar17;
    var_108h._4_4_ = fVar21;
    var_110h._4_4_ = fVar23;
    var_108h._0_4_ = fVar13;
    var_110h._0_4_ = fVar17;
    fVar15 = fVar21 - fVar23;
    if (iVar10 == 0) {
        fVar15 = fVar13 - fVar17;
    }
    if (fVar15 < 1.0) goto code_r0x00018013bc9a;
    var_118h[1] = fVar21 - fVar23;
    iVar11 = in_stack_00000028;
    if (in_stack_00000028 <= in_stack_00000030) {
        iVar11 = in_stack_00000030;
    }
    uVar12 = (uint64_t)iVar10;
    iVar9 = 1;
    if (0 < iVar11) {
        iVar9 = iVar11;
    }
    var_118h[0] = fVar13 - fVar17;
    fVar20 = var_118h[uVar12];
    if (*(float *)(*(int64_t *)0x180781f28 + 0xe20) <= var_118h[uVar12]) {
        fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    }
    var_118h[0] = (float)in_stack_00000028;
    fVar18 = ((float)in_stack_00000028 / (float)iVar9) * fVar15;
    if ((fVar20 <= fVar18) && (fVar20 = fVar15, fVar18 <= fVar15)) {
        fVar20 = fVar18;
    }
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xdb0);
    uStack_f0 = *(undefined4 *)arg1;
    uStack_ec = *(undefined4 *)(arg1 + 4);
    uStack_e8 = *(undefined4 *)(arg1 + 8);
    uStack_e4 = *(undefined4 *)(arg1 + 0xc);
    iVar11 = *(int64_t *)(var_138h + 0x418);
    var_100h[0] = *(float *)(iVar11 + 0x60);
    var_100h[1] = *(float *)(iVar11 + 100);
    iVar9 = *(int64_t *)(var_138h + 0x48);
    var_100h[2] = *(float *)(iVar11 + 0x60) + *(float *)(iVar11 + 0x68);
    var_100h[3] = *(float *)(iVar11 + 100) + *(float *)(iVar11 + 0x6c);
    var_124h._0_4_ = *(float *)(iVar9 + 0xc);
    var_128h = *(float *)(iVar9 + 8);
    uVar8 = uVar12 ^ 1;
    var_11ch = *(float *)(iVar9 + 0xc) + *(float *)(iVar9 + 0x14);
    var_124h._4_4_ = *(float *)(iVar9 + 8) + *(float *)(iVar9 + 0x10);
    fVar19 = var_100h[uVar8];
    if (((fVar19 == (&var_128h)[uVar8]) && (fVar19 < var_100h[uVar8 + 4])) && (var_100h[uVar8 + 4] - fVar18 <= fVar19))
    {
        var_100h[uVar8 + 4] = fVar19;
    }
    fVar19 = var_100h[uVar8 + 2];
    if (((fVar19 == *(float *)((int64_t)&var_124h + uVar8 * 4 + 4)) && (var_100h[uVar8 + 6] < fVar19)) &&
       (fVar19 <= var_100h[uVar8 + 6] + fVar18)) {
        var_100h[uVar8 + 6] = fVar19;
    }
    var_148h._0_1_ = 0;
    var_148h._1_1_ = '\0';
    var_140h._0_4_ = (float)(int32_t)fVar20;
    func_0x00018010b530(arg1, arg2 & 0xffffffff, 0, 2);
    fcn.180139d40((int64_t)(var_100h + 4), arg2 & 0xffffffff, (int64_t)&var_148h + 1, (int64_t)&var_148h, 
                  CONCAT44(var_158h._4_4_, 0x40000), in_stack_00000088);
    iVar11 = in_stack_00000030 - in_stack_00000028;
    if (iVar11 < 2) {
        iVar11 = 1;
    }
    var_148h._4_4_ = (float)iVar11;
    fVar18 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    if (0.0 <= fVar18) {
        fVar19 = 1.0;
        if (fVar18 <= 1.0) {
            fVar19 = fVar18;
        }
    } else {
        fVar19 = 0.0;
    }
    fVar20 = fVar15 - (float)(int32_t)fVar20;
    fVar18 = (fVar20 * fVar19) / fVar15;
    if ((((uint8_t)var_148h == 0) || (fVar22 < 1.0)) || (fVar19 = (float)var_140h / fVar15, 1.0 <= fVar19))
    goto code_r0x00018013bb2a;
    fVar14 = (*(float *)(iVar3 + 0x118 + uVar12 * 4) - *(float *)((int64_t)&var_110h + uVar12 * 4)) / fVar15;
    if (0.0 <= fVar14) {
        fVar16 = 1.0;
        if (fVar14 <= 1.0) {
            fVar16 = fVar14;
        }
    } else {
        fVar16 = 0.0;
    }
    if (fVar18 <= fVar16) {
        uVar5 = (uint32_t)(fVar19 + fVar18 < fVar16);
    } else {
        uVar5 = 0xffffffff;
    }
    if (*(char *)(iVar3 + 0x1660) != '\0') {
        if (((*(char *)(iVar3 + 0x95) == '\0') || (*(char *)(iVar3 + 0x139) != '\0')) || (uVar5 == 0)) {
            *(undefined2 *)(iVar3 + 0x27fe) = 0;
            if ((uVar5 == 0) && (*(char *)(iVar3 + 0x139) == '\0')) {
                *(float *)(iVar3 + 0x2800) = (fVar16 - fVar18) - fVar19 * 0.5;
                goto code_r0x00018013ba66;
            }
        } else {
            *(int16_t *)(iVar3 + 0x27fe) = (int16_t)uVar5;
        }
        *(undefined4 *)(iVar3 + 0x2800) = 0;
    }
code_r0x00018013ba66:
    iVar2 = *(int16_t *)(iVar3 + 0x27fe);
    if (iVar2 == 0) {
        fVar18 = ((fVar16 - *(float *)(iVar3 + 0x2800)) - fVar19 * 0.5) / (1.0 - fVar19);
        if (0.0 <= fVar18) {
            fVar19 = 1.0;
            if (fVar18 <= 1.0) {
                fVar19 = fVar18;
            }
        } else {
            fVar19 = 0.0;
        }
        *(int64_t *)arg4 = (int64_t)(fVar19 * var_148h._4_4_);
    } else {
        cVar4 = func_0x000180107ff0(0, 1, 0);
        if ((cVar4 != '\0') && (uVar5 == (int32_t)iVar2)) {
            if ((float)(int32_t)iVar2 <= 0.0) {
                fVar18 = -1.0;
            } else {
                fVar18 = 1.0;
            }
            iVar9 = (int64_t)(var_118h[0] * fVar18) + *(int64_t *)arg4;
            if (iVar9 < 0) {
                iVar9 = 0;
            } else if (iVar11 < iVar9) {
                iVar9 = iVar11;
            }
            *(int64_t *)arg4 = iVar9;
        }
    }
    fVar19 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    fVar18 = 0.0;
    if ((0.0 <= fVar19) && (fVar18 = 1.0, fVar19 <= 1.0)) {
        fVar18 = fVar19;
    }
    fVar18 = (fVar20 * fVar18) / fVar15;
code_r0x00018013bb2a:
    var_128h = *(float *)(*(int64_t *)0x180781f28 + 0xfb0);
    var_124h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb4);
    var_124h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb8);
    fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_11ch = *(float *)(*(int64_t *)0x180781f28 + 0xfbc) * fVar15;
    iVar11 = *(int64_t *)0x180781f28;
    uVar5 = func_0x0001800f5fa0(&var_128h);
    uVar12 = (uint64_t)uVar5;
    if ((uint8_t)var_148h == 0) {
        iVar9 = (uint64_t)(var_148h._1_1_ != '\0') + 0xf;
    } else {
        iVar9 = 0x11;
    }
    pfVar1 = (float *)(iVar11 + (iVar9 + 0xed) * 0x10);
    var_128h = *pfVar1;
    var_124h._0_4_ = pfVar1[1];
    var_124h._4_4_ = pfVar1[2];
    var_11ch = pfVar1[3] * fVar15 * fVar22;
    uVar6 = func_0x0001800f5fa0(&var_128h);
    iVar11 = var_138h;
    func_0x000180126550(*(undefined8 *)(var_138h + 800), arg1, arg1 + 8, uVar12 & 0xffffffff, 
                        *(undefined4 *)(var_138h + 0x98), in_stack_00000038);
    if (iVar10 == 0) {
        fVar17 = (fVar13 - fVar17) * fVar18 + fVar17;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar13 = fVar17 + (float)var_140h;
    } else {
        fVar23 = (fVar21 - fVar23) * fVar18 + fVar23;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar21 = fVar23 + (float)var_140h;
    }
    var_130h = fVar13;
    var_12ch = fVar21;
    func_0x000180126550(*(undefined8 *)(iVar11 + 800), &var_138h, &var_130h, uVar6, *(undefined4 *)(iVar3 + 0xe18), 0);
    return (uint64_t)(uint8_t)var_148h;
}

// ============================================================
// Function: FUN_18013bc9a
// Address: 0x18013bc9a
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_147h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013b5e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h)
{
    float *pfVar1;
    int16_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    int64_t var_8h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    undefined4 in_stack_00000038;
    int64_t in_stack_00000088;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    float var_130h;
    float var_12ch;
    float var_128h;
    int64_t var_124h;
    float var_11ch;
    float var_118h [2];
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [4];
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    undefined4 uStack_e8;
    undefined4 uStack_e4;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg3;
    var_138h = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    puVar7 = (undefined *)*(BADSPACEBASE **)0x20;
    if (*(char *)(var_138h + 0x10e) != '\0') {
code_r0x00018013bc9a:
        return (uint64_t)puVar7 & 0xffffffffffffff00;
    }
    fVar15 = *(float *)(arg1 + 8) - *(float *)arg1;
    if ((fVar15 <= 0.0) || (fVar17 = *(float *)(arg1 + 0xc) - *(float *)(arg1 + 4), fVar17 <= 0.0))
    goto code_r0x00018013bc9a;
    fVar22 = 1.0;
    if ((iVar10 == 1) && (fVar17 < fVar15)) {
        fVar13 = fVar15 + fVar15;
        if (fVar13 <= 1.0) {
            fVar13 = 1.0;
        }
        fVar13 = fVar17 / fVar13;
        if (0.0 <= fVar13) {
            fVar22 = 1.0;
            if (fVar13 <= 1.0) {
                fVar22 = fVar13;
            }
        } else {
            fVar22 = 0.0;
        }
        if (fVar22 <= 0.0) goto code_r0x00018013bc9a;
    }
    if (fVar17 <= fVar15) {
        fVar15 = fVar17;
    }
    fVar17 = *(float *)(*(int64_t *)0x180781f28 + 0xe1c);
    if (fVar15 * 0.5 <= *(float *)(*(int64_t *)0x180781f28 + 0xe1c)) {
        fVar17 = fVar15 * 0.5;
    }
    puVar7 = (undefined *)CONCAT44((int32_t)((uint64_t)&stack0x00000000 >> 0x20), (int32_t)fVar17);
    fVar17 = (float)((uint32_t)(float)(int32_t)fVar17 ^ 0x80000000);
    fVar21 = *(float *)(arg1 + 0xc) + fVar17;
    fVar23 = *(float *)(arg1 + 4) - fVar17;
    fVar13 = *(float *)(arg1 + 8) + fVar17;
    fVar17 = *(float *)arg1 - fVar17;
    var_108h._4_4_ = fVar21;
    var_110h._4_4_ = fVar23;
    var_108h._0_4_ = fVar13;
    var_110h._0_4_ = fVar17;
    fVar15 = fVar21 - fVar23;
    if (iVar10 == 0) {
        fVar15 = fVar13 - fVar17;
    }
    if (fVar15 < 1.0) goto code_r0x00018013bc9a;
    var_118h[1] = fVar21 - fVar23;
    iVar11 = in_stack_00000028;
    if (in_stack_00000028 <= in_stack_00000030) {
        iVar11 = in_stack_00000030;
    }
    uVar12 = (uint64_t)iVar10;
    iVar9 = 1;
    if (0 < iVar11) {
        iVar9 = iVar11;
    }
    var_118h[0] = fVar13 - fVar17;
    fVar20 = var_118h[uVar12];
    if (*(float *)(*(int64_t *)0x180781f28 + 0xe20) <= var_118h[uVar12]) {
        fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
    }
    var_118h[0] = (float)in_stack_00000028;
    fVar18 = ((float)in_stack_00000028 / (float)iVar9) * fVar15;
    if ((fVar20 <= fVar18) && (fVar20 = fVar15, fVar18 <= fVar15)) {
        fVar20 = fVar18;
    }
    fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xdb0);
    uStack_f0 = *(undefined4 *)arg1;
    uStack_ec = *(undefined4 *)(arg1 + 4);
    uStack_e8 = *(undefined4 *)(arg1 + 8);
    uStack_e4 = *(undefined4 *)(arg1 + 0xc);
    iVar11 = *(int64_t *)(var_138h + 0x418);
    var_100h[0] = *(float *)(iVar11 + 0x60);
    var_100h[1] = *(float *)(iVar11 + 100);
    iVar9 = *(int64_t *)(var_138h + 0x48);
    var_100h[2] = *(float *)(iVar11 + 0x60) + *(float *)(iVar11 + 0x68);
    var_100h[3] = *(float *)(iVar11 + 100) + *(float *)(iVar11 + 0x6c);
    var_124h._0_4_ = *(float *)(iVar9 + 0xc);
    var_128h = *(float *)(iVar9 + 8);
    uVar8 = uVar12 ^ 1;
    var_11ch = *(float *)(iVar9 + 0xc) + *(float *)(iVar9 + 0x14);
    var_124h._4_4_ = *(float *)(iVar9 + 8) + *(float *)(iVar9 + 0x10);
    fVar19 = var_100h[uVar8];
    if (((fVar19 == (&var_128h)[uVar8]) && (fVar19 < var_100h[uVar8 + 4])) && (var_100h[uVar8 + 4] - fVar18 <= fVar19))
    {
        var_100h[uVar8 + 4] = fVar19;
    }
    fVar19 = var_100h[uVar8 + 2];
    if (((fVar19 == *(float *)((int64_t)&var_124h + uVar8 * 4 + 4)) && (var_100h[uVar8 + 6] < fVar19)) &&
       (fVar19 <= var_100h[uVar8 + 6] + fVar18)) {
        var_100h[uVar8 + 6] = fVar19;
    }
    var_148h._0_1_ = 0;
    var_148h._1_1_ = '\0';
    var_140h._0_4_ = (float)(int32_t)fVar20;
    func_0x00018010b530(arg1, arg2 & 0xffffffff, 0, 2);
    fcn.180139d40((int64_t)(var_100h + 4), arg2 & 0xffffffff, (int64_t)&var_148h + 1, (int64_t)&var_148h, 
                  CONCAT44(var_158h._4_4_, 0x40000), in_stack_00000088);
    iVar11 = in_stack_00000030 - in_stack_00000028;
    if (iVar11 < 2) {
        iVar11 = 1;
    }
    var_148h._4_4_ = (float)iVar11;
    fVar18 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    if (0.0 <= fVar18) {
        fVar19 = 1.0;
        if (fVar18 <= 1.0) {
            fVar19 = fVar18;
        }
    } else {
        fVar19 = 0.0;
    }
    fVar20 = fVar15 - (float)(int32_t)fVar20;
    fVar18 = (fVar20 * fVar19) / fVar15;
    if ((((uint8_t)var_148h == 0) || (fVar22 < 1.0)) || (fVar19 = (float)var_140h / fVar15, 1.0 <= fVar19))
    goto code_r0x00018013bb2a;
    fVar14 = (*(float *)(iVar3 + 0x118 + uVar12 * 4) - *(float *)((int64_t)&var_110h + uVar12 * 4)) / fVar15;
    if (0.0 <= fVar14) {
        fVar16 = 1.0;
        if (fVar14 <= 1.0) {
            fVar16 = fVar14;
        }
    } else {
        fVar16 = 0.0;
    }
    if (fVar18 <= fVar16) {
        uVar5 = (uint32_t)(fVar19 + fVar18 < fVar16);
    } else {
        uVar5 = 0xffffffff;
    }
    if (*(char *)(iVar3 + 0x1660) != '\0') {
        if (((*(char *)(iVar3 + 0x95) == '\0') || (*(char *)(iVar3 + 0x139) != '\0')) || (uVar5 == 0)) {
            *(undefined2 *)(iVar3 + 0x27fe) = 0;
            if ((uVar5 == 0) && (*(char *)(iVar3 + 0x139) == '\0')) {
                *(float *)(iVar3 + 0x2800) = (fVar16 - fVar18) - fVar19 * 0.5;
                goto code_r0x00018013ba66;
            }
        } else {
            *(int16_t *)(iVar3 + 0x27fe) = (int16_t)uVar5;
        }
        *(undefined4 *)(iVar3 + 0x2800) = 0;
    }
code_r0x00018013ba66:
    iVar2 = *(int16_t *)(iVar3 + 0x27fe);
    if (iVar2 == 0) {
        fVar18 = ((fVar16 - *(float *)(iVar3 + 0x2800)) - fVar19 * 0.5) / (1.0 - fVar19);
        if (0.0 <= fVar18) {
            fVar19 = 1.0;
            if (fVar18 <= 1.0) {
                fVar19 = fVar18;
            }
        } else {
            fVar19 = 0.0;
        }
        *(int64_t *)arg4 = (int64_t)(fVar19 * var_148h._4_4_);
    } else {
        cVar4 = func_0x000180107ff0(0, 1, 0);
        if ((cVar4 != '\0') && (uVar5 == (int32_t)iVar2)) {
            if ((float)(int32_t)iVar2 <= 0.0) {
                fVar18 = -1.0;
            } else {
                fVar18 = 1.0;
            }
            iVar9 = (int64_t)(var_118h[0] * fVar18) + *(int64_t *)arg4;
            if (iVar9 < 0) {
                iVar9 = 0;
            } else if (iVar11 < iVar9) {
                iVar9 = iVar11;
            }
            *(int64_t *)arg4 = iVar9;
        }
    }
    fVar19 = (float)*(int64_t *)arg4 / var_148h._4_4_;
    fVar18 = 0.0;
    if ((0.0 <= fVar19) && (fVar18 = 1.0, fVar19 <= 1.0)) {
        fVar18 = fVar19;
    }
    fVar18 = (fVar20 * fVar18) / fVar15;
code_r0x00018013bb2a:
    var_128h = *(float *)(*(int64_t *)0x180781f28 + 0xfb0);
    var_124h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb4);
    var_124h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xfb8);
    fVar15 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_11ch = *(float *)(*(int64_t *)0x180781f28 + 0xfbc) * fVar15;
    iVar11 = *(int64_t *)0x180781f28;
    uVar5 = func_0x0001800f5fa0(&var_128h);
    uVar12 = (uint64_t)uVar5;
    if ((uint8_t)var_148h == 0) {
        iVar9 = (uint64_t)(var_148h._1_1_ != '\0') + 0xf;
    } else {
        iVar9 = 0x11;
    }
    pfVar1 = (float *)(iVar11 + (iVar9 + 0xed) * 0x10);
    var_128h = *pfVar1;
    var_124h._0_4_ = pfVar1[1];
    var_124h._4_4_ = pfVar1[2];
    var_11ch = pfVar1[3] * fVar15 * fVar22;
    uVar6 = func_0x0001800f5fa0(&var_128h);
    iVar11 = var_138h;
    func_0x000180126550(*(undefined8 *)(var_138h + 800), arg1, arg1 + 8, uVar12 & 0xffffffff, 
                        *(undefined4 *)(var_138h + 0x98), in_stack_00000038);
    if (iVar10 == 0) {
        fVar17 = (fVar13 - fVar17) * fVar18 + fVar17;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar13 = fVar17 + (float)var_140h;
    } else {
        fVar23 = (fVar21 - fVar23) * fVar18 + fVar23;
        var_138h = CONCAT44(fVar23, fVar17);
        fVar21 = fVar23 + (float)var_140h;
    }
    var_130h = fVar13;
    var_12ch = fVar21;
    func_0x000180126550(*(undefined8 *)(iVar11 + 800), &var_138h, &var_130h, uVar6, *(undefined4 *)(iVar3 + 0xe18), 0);
    return (uint64_t)(uint8_t)var_148h;
}

// ============================================================
// Function: FUN_18013bcf0
// Address: 0x18013bcf0
// Size: 644 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_7dh
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_79h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013bcf0(int64_t arg1, int64_t arg2)
{
    float *pfVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    float fVar7;
    undefined uVar8;
    uint32_t uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    char *pcVar22;
    char *pcVar23;
    char cVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined4 uStackX_18;
    float fStackX_1c;
    undefined8 uStackX_20;
    int64_t in_stack_000000e8;
    int64_t var_f8h;
    int64_t var_f0h;
    char var_e8h;
    char var_e7h;
    int64_t var_e6h;
    float fStack_dc;
    float fStack_d8;
    float fStack_d4;
    float fStack_d0;
    float fStack_cc;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_69h;
    int64_t var_5dh;
    int64_t var_38h;
    
    iVar5 = *(int64_t *)0x180781f28;
    uVar13 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar13 + 0x10b) = 1;
    iVar17 = *(int64_t *)(iVar5 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
code_r0x00018013c390:
        return uVar13 & 0xffffffffffffff00;
    }
    uVar9 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                          (*(int64_t *)(iVar17 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar17 + 0x148) * 4
                                          ));
    pcVar23 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar23 != '\0') {
            pcVar21 = pcVar23 + 1;
            if (((*pcVar23 == '#') && (*pcVar21 == '#')) || (pcVar23 = pcVar21, pcVar21 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_f8h = CONCAT44(var_f8h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&uStackX_18, arg1, pcVar23, 0, var_f8h);
    fVar7 = uStackX_18;
    fVar27 = *(float *)(iVar5 + 0xde0);
    fVar2 = *(float *)(undefined8 *)(iVar17 + 0x158);
    fVar3 = *(float *)(iVar17 + 0x15c);
    uVar6 = *(undefined8 *)(iVar17 + 0x158);
    fVar26 = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
             *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (uStackX_18 <= 0.0) {
        uStackX_18 = 0.0;
    } else {
        uStackX_18 = uStackX_18 + *(float *)(iVar5 + 0xdf4);
    }
    fStack_bc = fVar3 + fVar27 + fVar27 + fStackX_1c;
    fStack_c0 = fVar26 + uStackX_18 + fVar2;
    fStackX_1c = fStack_bc - fVar3;
    uStackX_18 = fStack_c0 - fVar2;
    fStack_c8 = fVar2;
    fStack_c4 = fVar3;
    func_0x00018010bbf0(&uStackX_18, fVar27);
    uVar13 = func_0x00018010b530(&fStack_c8, uVar9, 0, 0);
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x400000;
    var_e6h._0_1_ = (char)uVar13;
    if ((char)var_e6h == '\0') {
        if ((((uVar18 == 0) || (*(char *)(iVar5 + 0x25b8) == '\0')) ||
            ((*(float *)(iVar5 + 0x25c8) <= fStack_c4 ||
             ((fStack_bc < *(float *)(iVar5 + 0x25c0) || fStack_bc == *(float *)(iVar5 + 0x25c0) ||
              (*(float *)(iVar5 + 0x25c4) <= fStack_c8)))))) ||
           (fStack_c0 < *(float *)(iVar5 + 0x25bc) || fStack_c0 == *(float *)(iVar5 + 0x25bc)))
        goto code_r0x00018013c390;
        uStackX_18._0_1_ = *(char *)arg2;
    } else {
        cVar24 = *(char *)arg2;
        uStackX_18._0_1_ = cVar24;
        if (uVar18 == 0) {
            var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
            uStackX_18._0_1_ =
                 fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                               in_stack_000000e8);
            if ((uint8_t)uStackX_18 != 0) {
                cVar24 = cVar24 == '\0';
            }
            goto code_r0x00018013bf74;
        }
    }
    func_0x0001801475c0(uVar9, &uStackX_18, 0);
    var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
    uVar8 = fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                          in_stack_000000e8);
    uStackX_20 = CONCAT71(uStackX_20._1_7_, uVar8);
    func_0x0001801476e0(uVar9, &uStackX_18, &uStackX_20);
    cVar24 = (uint8_t)uStackX_18;
    uStackX_18._0_1_ = (uint8_t)uStackX_20;
code_r0x00018013bf74:
    if (*(char *)arg2 != cVar24) {
        *(char *)arg2 = cVar24;
        uStackX_18._0_1_ = 1;
        func_0x0001800fa060(uVar9);
    }
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x1000;
    fVar27 = fVar2 + fVar26;
    if ((char)var_e6h != '\0') {
        func_0x0001800f7d00(&fStack_c8, uVar9, 0);
        uVar11 = *(undefined4 *)(iVar5 + 0xde4);
        if ((var_e7h == '\0') || (var_e8h == '\0')) {
            iVar14 = (uint64_t)(var_e8h != '\0') + 7;
        } else {
            iVar14 = 9;
        }
        pfVar1 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar14 + 0x14) * 0x10);
        fStack_d8 = *pfVar1;
        fStack_d4 = pfVar1[1];
        fStack_d0 = pfVar1[2];
        fStack_cc = pfVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar10 = func_0x0001800f5fa0(&fStack_d8);
        var_f8h = CONCAT44(var_f8h._4_4_, uVar11);
        func_0x0001800f7a00(uVar6, CONCAT44(fVar3 + fVar26, fVar27), uVar10, 1, var_f8h);
        fStack_d8 = *(float *)(*(int64_t *)0x180781f28 + 0xff0);
        fStack_d4 = *(float *)(*(int64_t *)0x180781f28 + 0xff4);
        fStack_d0 = *(float *)(*(int64_t *)0x180781f28 + 0xff8);
        fStack_cc = *(float *)(*(int64_t *)0x180781f28 + 0xffc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar11 = func_0x0001800f5fa0(&fStack_d8);
        if (uVar18 == 0) {
            if (*(char *)arg2 != '\0') {
                fVar25 = 1.0;
                if (1.0 <= (float)(int32_t)(fVar26 / 6.0)) {
                    fVar25 = (float)(int32_t)(fVar26 / 6.0);
                }
                func_0x0001801303d0(*(undefined8 *)(iVar17 + 800), CONCAT44(fVar3 + fVar25, fVar2 + fVar25), uVar11, 
                                    fVar26 - (fVar25 + fVar25));
            }
        } else {
            fVar25 = 1.0;
            if (1.0 <= (float)(int32_t)(fVar26 / 3.6)) {
                fVar25 = (float)(int32_t)(fVar26 / 3.6);
            }
            fStack_d4 = fVar3 + fVar25;
            fStack_d8 = fVar2 + fVar25;
            var_f8h = CONCAT44(var_f8h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
            uStackX_20 = CONCAT44((fVar3 + fVar26) - fVar25, fVar27 - fVar25);
            func_0x000180126550(*(undefined8 *)(iVar17 + 800), &fStack_d8, &uStackX_20, uVar11, var_f8h, 0);
        }
    }
    iVar17 = *(int64_t *)0x180781f28;
    *(float *)0x1320 = fVar27 + *(float *)(iVar5 + 0xdf4);
    fStack_dc = fVar3 + *(float *)(iVar5 + 0xde0);
    if (*(char *)(iVar5 + 0x29f8) != '\0') {
        if (uVar18 == 0) {
            pcVar21 = "[ ]";
            if (*(char *)arg2 != '\0') {
                pcVar21 = "[x]";
            }
        } else {
            pcVar21 = "[~]";
        }
        uStackX_20 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar22 = pcVar21;
        if (pcVar21 != (char *)0xffffffffffffffff) {
            while (*pcVar22 != '\0') {
                pcVar20 = pcVar22 + 1;
                if (((*pcVar22 == '#') && (*pcVar20 == '#')) ||
                   (pcVar22 = pcVar20, pcVar20 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar27 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar27 = *(float *)(iVar17 + 0xdf0);
        }
        fVar2 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = fStack_dc;
        if (fVar27 + fVar2 + 1.0 < fStack_dc) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar5 != 0) {
            iVar15 = func_0x000180498cd0(iVar5);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar5, iVar15 + iVar5);
        }
        iVar12 = *(int32_t *)(iVar17 + 0x2a34);
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        if (iVar4 < iVar12) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar4;
            iVar12 = iVar4;
        }
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar21, 10, (int64_t)pcVar22 - (int64_t)pcVar21);
            pcVar20 = pcVar22;
            if (pcVar16 != (char *)0x0) {
                pcVar20 = pcVar16;
            }
            if ((pcVar21 == pcVar20) && (pcVar20 == pcVar22)) break;
            iVar19 = (iVar4 - iVar12) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar20 - (int32_t)pcVar21, pcVar21);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar20 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar20 == pcVar22) break;
            pcVar21 = pcVar20 + 1;
        }
        if (iVar14 != 0) {
            iVar17 = func_0x000180498cd0(iVar14);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar14, iVar17 + iVar14);
        }
    }
    if (((char)var_e6h != '\0') && (0.0 < fVar7)) {
        func_0x0001800f6cb0(CONCAT44(fStack_dc, stack0xffffffffffffff20), arg1, pcVar23, 0);
    }
    return (uint64_t)(uint8_t)uStackX_18;
}

// ============================================================
// Function: FUN_18013bf74
// Address: 0x18013bf74
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_7dh
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_79h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013bcf0(int64_t arg1, int64_t arg2)
{
    float *pfVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    float fVar7;
    undefined uVar8;
    uint32_t uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    char *pcVar22;
    char *pcVar23;
    char cVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined4 uStackX_18;
    float fStackX_1c;
    undefined8 uStackX_20;
    int64_t in_stack_000000e8;
    int64_t var_f8h;
    int64_t var_f0h;
    char var_e8h;
    char var_e7h;
    int64_t var_e6h;
    float fStack_dc;
    float fStack_d8;
    float fStack_d4;
    float fStack_d0;
    float fStack_cc;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_69h;
    int64_t var_5dh;
    int64_t var_38h;
    
    iVar5 = *(int64_t *)0x180781f28;
    uVar13 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar13 + 0x10b) = 1;
    iVar17 = *(int64_t *)(iVar5 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
code_r0x00018013c390:
        return uVar13 & 0xffffffffffffff00;
    }
    uVar9 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                          (*(int64_t *)(iVar17 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar17 + 0x148) * 4
                                          ));
    pcVar23 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar23 != '\0') {
            pcVar21 = pcVar23 + 1;
            if (((*pcVar23 == '#') && (*pcVar21 == '#')) || (pcVar23 = pcVar21, pcVar21 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_f8h = CONCAT44(var_f8h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&uStackX_18, arg1, pcVar23, 0, var_f8h);
    fVar7 = uStackX_18;
    fVar27 = *(float *)(iVar5 + 0xde0);
    fVar2 = *(float *)(undefined8 *)(iVar17 + 0x158);
    fVar3 = *(float *)(iVar17 + 0x15c);
    uVar6 = *(undefined8 *)(iVar17 + 0x158);
    fVar26 = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
             *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (uStackX_18 <= 0.0) {
        uStackX_18 = 0.0;
    } else {
        uStackX_18 = uStackX_18 + *(float *)(iVar5 + 0xdf4);
    }
    fStack_bc = fVar3 + fVar27 + fVar27 + fStackX_1c;
    fStack_c0 = fVar26 + uStackX_18 + fVar2;
    fStackX_1c = fStack_bc - fVar3;
    uStackX_18 = fStack_c0 - fVar2;
    fStack_c8 = fVar2;
    fStack_c4 = fVar3;
    func_0x00018010bbf0(&uStackX_18, fVar27);
    uVar13 = func_0x00018010b530(&fStack_c8, uVar9, 0, 0);
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x400000;
    var_e6h._0_1_ = (char)uVar13;
    if ((char)var_e6h == '\0') {
        if ((((uVar18 == 0) || (*(char *)(iVar5 + 0x25b8) == '\0')) ||
            ((*(float *)(iVar5 + 0x25c8) <= fStack_c4 ||
             ((fStack_bc < *(float *)(iVar5 + 0x25c0) || fStack_bc == *(float *)(iVar5 + 0x25c0) ||
              (*(float *)(iVar5 + 0x25c4) <= fStack_c8)))))) ||
           (fStack_c0 < *(float *)(iVar5 + 0x25bc) || fStack_c0 == *(float *)(iVar5 + 0x25bc)))
        goto code_r0x00018013c390;
        uStackX_18._0_1_ = *(char *)arg2;
    } else {
        cVar24 = *(char *)arg2;
        uStackX_18._0_1_ = cVar24;
        if (uVar18 == 0) {
            var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
            uStackX_18._0_1_ =
                 fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                               in_stack_000000e8);
            if ((uint8_t)uStackX_18 != 0) {
                cVar24 = cVar24 == '\0';
            }
            goto code_r0x00018013bf74;
        }
    }
    func_0x0001801475c0(uVar9, &uStackX_18, 0);
    var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
    uVar8 = fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                          in_stack_000000e8);
    uStackX_20 = CONCAT71(uStackX_20._1_7_, uVar8);
    func_0x0001801476e0(uVar9, &uStackX_18, &uStackX_20);
    cVar24 = (uint8_t)uStackX_18;
    uStackX_18._0_1_ = (uint8_t)uStackX_20;
code_r0x00018013bf74:
    if (*(char *)arg2 != cVar24) {
        *(char *)arg2 = cVar24;
        uStackX_18._0_1_ = 1;
        func_0x0001800fa060(uVar9);
    }
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x1000;
    fVar27 = fVar2 + fVar26;
    if ((char)var_e6h != '\0') {
        func_0x0001800f7d00(&fStack_c8, uVar9, 0);
        uVar11 = *(undefined4 *)(iVar5 + 0xde4);
        if ((var_e7h == '\0') || (var_e8h == '\0')) {
            iVar14 = (uint64_t)(var_e8h != '\0') + 7;
        } else {
            iVar14 = 9;
        }
        pfVar1 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar14 + 0x14) * 0x10);
        fStack_d8 = *pfVar1;
        fStack_d4 = pfVar1[1];
        fStack_d0 = pfVar1[2];
        fStack_cc = pfVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar10 = func_0x0001800f5fa0(&fStack_d8);
        var_f8h = CONCAT44(var_f8h._4_4_, uVar11);
        func_0x0001800f7a00(uVar6, CONCAT44(fVar3 + fVar26, fVar27), uVar10, 1, var_f8h);
        fStack_d8 = *(float *)(*(int64_t *)0x180781f28 + 0xff0);
        fStack_d4 = *(float *)(*(int64_t *)0x180781f28 + 0xff4);
        fStack_d0 = *(float *)(*(int64_t *)0x180781f28 + 0xff8);
        fStack_cc = *(float *)(*(int64_t *)0x180781f28 + 0xffc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar11 = func_0x0001800f5fa0(&fStack_d8);
        if (uVar18 == 0) {
            if (*(char *)arg2 != '\0') {
                fVar25 = 1.0;
                if (1.0 <= (float)(int32_t)(fVar26 / 6.0)) {
                    fVar25 = (float)(int32_t)(fVar26 / 6.0);
                }
                func_0x0001801303d0(*(undefined8 *)(iVar17 + 800), CONCAT44(fVar3 + fVar25, fVar2 + fVar25), uVar11, 
                                    fVar26 - (fVar25 + fVar25));
            }
        } else {
            fVar25 = 1.0;
            if (1.0 <= (float)(int32_t)(fVar26 / 3.6)) {
                fVar25 = (float)(int32_t)(fVar26 / 3.6);
            }
            fStack_d4 = fVar3 + fVar25;
            fStack_d8 = fVar2 + fVar25;
            var_f8h = CONCAT44(var_f8h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
            uStackX_20 = CONCAT44((fVar3 + fVar26) - fVar25, fVar27 - fVar25);
            func_0x000180126550(*(undefined8 *)(iVar17 + 800), &fStack_d8, &uStackX_20, uVar11, var_f8h, 0);
        }
    }
    iVar17 = *(int64_t *)0x180781f28;
    *(float *)0x1320 = fVar27 + *(float *)(iVar5 + 0xdf4);
    fStack_dc = fVar3 + *(float *)(iVar5 + 0xde0);
    if (*(char *)(iVar5 + 0x29f8) != '\0') {
        if (uVar18 == 0) {
            pcVar21 = "[ ]";
            if (*(char *)arg2 != '\0') {
                pcVar21 = "[x]";
            }
        } else {
            pcVar21 = "[~]";
        }
        uStackX_20 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar22 = pcVar21;
        if (pcVar21 != (char *)0xffffffffffffffff) {
            while (*pcVar22 != '\0') {
                pcVar20 = pcVar22 + 1;
                if (((*pcVar22 == '#') && (*pcVar20 == '#')) ||
                   (pcVar22 = pcVar20, pcVar20 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar27 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar27 = *(float *)(iVar17 + 0xdf0);
        }
        fVar2 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = fStack_dc;
        if (fVar27 + fVar2 + 1.0 < fStack_dc) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar5 != 0) {
            iVar15 = func_0x000180498cd0(iVar5);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar5, iVar15 + iVar5);
        }
        iVar12 = *(int32_t *)(iVar17 + 0x2a34);
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        if (iVar4 < iVar12) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar4;
            iVar12 = iVar4;
        }
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar21, 10, (int64_t)pcVar22 - (int64_t)pcVar21);
            pcVar20 = pcVar22;
            if (pcVar16 != (char *)0x0) {
                pcVar20 = pcVar16;
            }
            if ((pcVar21 == pcVar20) && (pcVar20 == pcVar22)) break;
            iVar19 = (iVar4 - iVar12) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar20 - (int32_t)pcVar21, pcVar21);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar20 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar20 == pcVar22) break;
            pcVar21 = pcVar20 + 1;
        }
        if (iVar14 != 0) {
            iVar17 = func_0x000180498cd0(iVar14);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar14, iVar17 + iVar14);
        }
    }
    if (((char)var_e6h != '\0') && (0.0 < fVar7)) {
        func_0x0001800f6cb0(CONCAT44(fStack_dc, stack0xffffffffffffff20), arg1, pcVar23, 0);
    }
    return (uint64_t)(uint8_t)uStackX_18;
}

// ============================================================
// Function: FUN_18013bfc5
// Address: 0x18013bfc5
// Size: 219 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_7dh
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_79h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013bcf0(int64_t arg1, int64_t arg2)
{
    float *pfVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    float fVar7;
    undefined uVar8;
    uint32_t uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    char *pcVar22;
    char *pcVar23;
    char cVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined4 uStackX_18;
    float fStackX_1c;
    undefined8 uStackX_20;
    int64_t in_stack_000000e8;
    int64_t var_f8h;
    int64_t var_f0h;
    char var_e8h;
    char var_e7h;
    int64_t var_e6h;
    float fStack_dc;
    float fStack_d8;
    float fStack_d4;
    float fStack_d0;
    float fStack_cc;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_69h;
    int64_t var_5dh;
    int64_t var_38h;
    
    iVar5 = *(int64_t *)0x180781f28;
    uVar13 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar13 + 0x10b) = 1;
    iVar17 = *(int64_t *)(iVar5 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
code_r0x00018013c390:
        return uVar13 & 0xffffffffffffff00;
    }
    uVar9 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                          (*(int64_t *)(iVar17 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar17 + 0x148) * 4
                                          ));
    pcVar23 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar23 != '\0') {
            pcVar21 = pcVar23 + 1;
            if (((*pcVar23 == '#') && (*pcVar21 == '#')) || (pcVar23 = pcVar21, pcVar21 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_f8h = CONCAT44(var_f8h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&uStackX_18, arg1, pcVar23, 0, var_f8h);
    fVar7 = uStackX_18;
    fVar27 = *(float *)(iVar5 + 0xde0);
    fVar2 = *(float *)(undefined8 *)(iVar17 + 0x158);
    fVar3 = *(float *)(iVar17 + 0x15c);
    uVar6 = *(undefined8 *)(iVar17 + 0x158);
    fVar26 = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
             *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (uStackX_18 <= 0.0) {
        uStackX_18 = 0.0;
    } else {
        uStackX_18 = uStackX_18 + *(float *)(iVar5 + 0xdf4);
    }
    fStack_bc = fVar3 + fVar27 + fVar27 + fStackX_1c;
    fStack_c0 = fVar26 + uStackX_18 + fVar2;
    fStackX_1c = fStack_bc - fVar3;
    uStackX_18 = fStack_c0 - fVar2;
    fStack_c8 = fVar2;
    fStack_c4 = fVar3;
    func_0x00018010bbf0(&uStackX_18, fVar27);
    uVar13 = func_0x00018010b530(&fStack_c8, uVar9, 0, 0);
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x400000;
    var_e6h._0_1_ = (char)uVar13;
    if ((char)var_e6h == '\0') {
        if ((((uVar18 == 0) || (*(char *)(iVar5 + 0x25b8) == '\0')) ||
            ((*(float *)(iVar5 + 0x25c8) <= fStack_c4 ||
             ((fStack_bc < *(float *)(iVar5 + 0x25c0) || fStack_bc == *(float *)(iVar5 + 0x25c0) ||
              (*(float *)(iVar5 + 0x25c4) <= fStack_c8)))))) ||
           (fStack_c0 < *(float *)(iVar5 + 0x25bc) || fStack_c0 == *(float *)(iVar5 + 0x25bc)))
        goto code_r0x00018013c390;
        uStackX_18._0_1_ = *(char *)arg2;
    } else {
        cVar24 = *(char *)arg2;
        uStackX_18._0_1_ = cVar24;
        if (uVar18 == 0) {
            var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
            uStackX_18._0_1_ =
                 fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                               in_stack_000000e8);
            if ((uint8_t)uStackX_18 != 0) {
                cVar24 = cVar24 == '\0';
            }
            goto code_r0x00018013bf74;
        }
    }
    func_0x0001801475c0(uVar9, &uStackX_18, 0);
    var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
    uVar8 = fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                          in_stack_000000e8);
    uStackX_20 = CONCAT71(uStackX_20._1_7_, uVar8);
    func_0x0001801476e0(uVar9, &uStackX_18, &uStackX_20);
    cVar24 = (uint8_t)uStackX_18;
    uStackX_18._0_1_ = (uint8_t)uStackX_20;
code_r0x00018013bf74:
    if (*(char *)arg2 != cVar24) {
        *(char *)arg2 = cVar24;
        uStackX_18._0_1_ = 1;
        func_0x0001800fa060(uVar9);
    }
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x1000;
    fVar27 = fVar2 + fVar26;
    if ((char)var_e6h != '\0') {
        func_0x0001800f7d00(&fStack_c8, uVar9, 0);
        uVar11 = *(undefined4 *)(iVar5 + 0xde4);
        if ((var_e7h == '\0') || (var_e8h == '\0')) {
            iVar14 = (uint64_t)(var_e8h != '\0') + 7;
        } else {
            iVar14 = 9;
        }
        pfVar1 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar14 + 0x14) * 0x10);
        fStack_d8 = *pfVar1;
        fStack_d4 = pfVar1[1];
        fStack_d0 = pfVar1[2];
        fStack_cc = pfVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar10 = func_0x0001800f5fa0(&fStack_d8);
        var_f8h = CONCAT44(var_f8h._4_4_, uVar11);
        func_0x0001800f7a00(uVar6, CONCAT44(fVar3 + fVar26, fVar27), uVar10, 1, var_f8h);
        fStack_d8 = *(float *)(*(int64_t *)0x180781f28 + 0xff0);
        fStack_d4 = *(float *)(*(int64_t *)0x180781f28 + 0xff4);
        fStack_d0 = *(float *)(*(int64_t *)0x180781f28 + 0xff8);
        fStack_cc = *(float *)(*(int64_t *)0x180781f28 + 0xffc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar11 = func_0x0001800f5fa0(&fStack_d8);
        if (uVar18 == 0) {
            if (*(char *)arg2 != '\0') {
                fVar25 = 1.0;
                if (1.0 <= (float)(int32_t)(fVar26 / 6.0)) {
                    fVar25 = (float)(int32_t)(fVar26 / 6.0);
                }
                func_0x0001801303d0(*(undefined8 *)(iVar17 + 800), CONCAT44(fVar3 + fVar25, fVar2 + fVar25), uVar11, 
                                    fVar26 - (fVar25 + fVar25));
            }
        } else {
            fVar25 = 1.0;
            if (1.0 <= (float)(int32_t)(fVar26 / 3.6)) {
                fVar25 = (float)(int32_t)(fVar26 / 3.6);
            }
            fStack_d4 = fVar3 + fVar25;
            fStack_d8 = fVar2 + fVar25;
            var_f8h = CONCAT44(var_f8h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
            uStackX_20 = CONCAT44((fVar3 + fVar26) - fVar25, fVar27 - fVar25);
            func_0x000180126550(*(undefined8 *)(iVar17 + 800), &fStack_d8, &uStackX_20, uVar11, var_f8h, 0);
        }
    }
    iVar17 = *(int64_t *)0x180781f28;
    *(float *)0x1320 = fVar27 + *(float *)(iVar5 + 0xdf4);
    fStack_dc = fVar3 + *(float *)(iVar5 + 0xde0);
    if (*(char *)(iVar5 + 0x29f8) != '\0') {
        if (uVar18 == 0) {
            pcVar21 = "[ ]";
            if (*(char *)arg2 != '\0') {
                pcVar21 = "[x]";
            }
        } else {
            pcVar21 = "[~]";
        }
        uStackX_20 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar22 = pcVar21;
        if (pcVar21 != (char *)0xffffffffffffffff) {
            while (*pcVar22 != '\0') {
                pcVar20 = pcVar22 + 1;
                if (((*pcVar22 == '#') && (*pcVar20 == '#')) ||
                   (pcVar22 = pcVar20, pcVar20 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar27 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar27 = *(float *)(iVar17 + 0xdf0);
        }
        fVar2 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = fStack_dc;
        if (fVar27 + fVar2 + 1.0 < fStack_dc) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar5 != 0) {
            iVar15 = func_0x000180498cd0(iVar5);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar5, iVar15 + iVar5);
        }
        iVar12 = *(int32_t *)(iVar17 + 0x2a34);
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        if (iVar4 < iVar12) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar4;
            iVar12 = iVar4;
        }
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar21, 10, (int64_t)pcVar22 - (int64_t)pcVar21);
            pcVar20 = pcVar22;
            if (pcVar16 != (char *)0x0) {
                pcVar20 = pcVar16;
            }
            if ((pcVar21 == pcVar20) && (pcVar20 == pcVar22)) break;
            iVar19 = (iVar4 - iVar12) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar20 - (int32_t)pcVar21, pcVar21);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar20 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar20 == pcVar22) break;
            pcVar21 = pcVar20 + 1;
        }
        if (iVar14 != 0) {
            iVar17 = func_0x000180498cd0(iVar14);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar14, iVar17 + iVar14);
        }
    }
    if (((char)var_e6h != '\0') && (0.0 < fVar7)) {
        func_0x0001800f6cb0(CONCAT44(fStack_dc, stack0xffffffffffffff20), arg1, pcVar23, 0);
    }
    return (uint64_t)(uint8_t)uStackX_18;
}

// ============================================================
// Function: FUN_18013c0a0
// Address: 0x18013c0a0
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_7dh
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_79h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013bcf0(int64_t arg1, int64_t arg2)
{
    float *pfVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    float fVar7;
    undefined uVar8;
    uint32_t uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    char *pcVar22;
    char *pcVar23;
    char cVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined4 uStackX_18;
    float fStackX_1c;
    undefined8 uStackX_20;
    int64_t in_stack_000000e8;
    int64_t var_f8h;
    int64_t var_f0h;
    char var_e8h;
    char var_e7h;
    int64_t var_e6h;
    float fStack_dc;
    float fStack_d8;
    float fStack_d4;
    float fStack_d0;
    float fStack_cc;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_69h;
    int64_t var_5dh;
    int64_t var_38h;
    
    iVar5 = *(int64_t *)0x180781f28;
    uVar13 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar13 + 0x10b) = 1;
    iVar17 = *(int64_t *)(iVar5 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
code_r0x00018013c390:
        return uVar13 & 0xffffffffffffff00;
    }
    uVar9 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                          (*(int64_t *)(iVar17 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar17 + 0x148) * 4
                                          ));
    pcVar23 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar23 != '\0') {
            pcVar21 = pcVar23 + 1;
            if (((*pcVar23 == '#') && (*pcVar21 == '#')) || (pcVar23 = pcVar21, pcVar21 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_f8h = CONCAT44(var_f8h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&uStackX_18, arg1, pcVar23, 0, var_f8h);
    fVar7 = uStackX_18;
    fVar27 = *(float *)(iVar5 + 0xde0);
    fVar2 = *(float *)(undefined8 *)(iVar17 + 0x158);
    fVar3 = *(float *)(iVar17 + 0x15c);
    uVar6 = *(undefined8 *)(iVar17 + 0x158);
    fVar26 = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
             *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (uStackX_18 <= 0.0) {
        uStackX_18 = 0.0;
    } else {
        uStackX_18 = uStackX_18 + *(float *)(iVar5 + 0xdf4);
    }
    fStack_bc = fVar3 + fVar27 + fVar27 + fStackX_1c;
    fStack_c0 = fVar26 + uStackX_18 + fVar2;
    fStackX_1c = fStack_bc - fVar3;
    uStackX_18 = fStack_c0 - fVar2;
    fStack_c8 = fVar2;
    fStack_c4 = fVar3;
    func_0x00018010bbf0(&uStackX_18, fVar27);
    uVar13 = func_0x00018010b530(&fStack_c8, uVar9, 0, 0);
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x400000;
    var_e6h._0_1_ = (char)uVar13;
    if ((char)var_e6h == '\0') {
        if ((((uVar18 == 0) || (*(char *)(iVar5 + 0x25b8) == '\0')) ||
            ((*(float *)(iVar5 + 0x25c8) <= fStack_c4 ||
             ((fStack_bc < *(float *)(iVar5 + 0x25c0) || fStack_bc == *(float *)(iVar5 + 0x25c0) ||
              (*(float *)(iVar5 + 0x25c4) <= fStack_c8)))))) ||
           (fStack_c0 < *(float *)(iVar5 + 0x25bc) || fStack_c0 == *(float *)(iVar5 + 0x25bc)))
        goto code_r0x00018013c390;
        uStackX_18._0_1_ = *(char *)arg2;
    } else {
        cVar24 = *(char *)arg2;
        uStackX_18._0_1_ = cVar24;
        if (uVar18 == 0) {
            var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
            uStackX_18._0_1_ =
                 fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                               in_stack_000000e8);
            if ((uint8_t)uStackX_18 != 0) {
                cVar24 = cVar24 == '\0';
            }
            goto code_r0x00018013bf74;
        }
    }
    func_0x0001801475c0(uVar9, &uStackX_18, 0);
    var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
    uVar8 = fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                          in_stack_000000e8);
    uStackX_20 = CONCAT71(uStackX_20._1_7_, uVar8);
    func_0x0001801476e0(uVar9, &uStackX_18, &uStackX_20);
    cVar24 = (uint8_t)uStackX_18;
    uStackX_18._0_1_ = (uint8_t)uStackX_20;
code_r0x00018013bf74:
    if (*(char *)arg2 != cVar24) {
        *(char *)arg2 = cVar24;
        uStackX_18._0_1_ = 1;
        func_0x0001800fa060(uVar9);
    }
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x1000;
    fVar27 = fVar2 + fVar26;
    if ((char)var_e6h != '\0') {
        func_0x0001800f7d00(&fStack_c8, uVar9, 0);
        uVar11 = *(undefined4 *)(iVar5 + 0xde4);
        if ((var_e7h == '\0') || (var_e8h == '\0')) {
            iVar14 = (uint64_t)(var_e8h != '\0') + 7;
        } else {
            iVar14 = 9;
        }
        pfVar1 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar14 + 0x14) * 0x10);
        fStack_d8 = *pfVar1;
        fStack_d4 = pfVar1[1];
        fStack_d0 = pfVar1[2];
        fStack_cc = pfVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar10 = func_0x0001800f5fa0(&fStack_d8);
        var_f8h = CONCAT44(var_f8h._4_4_, uVar11);
        func_0x0001800f7a00(uVar6, CONCAT44(fVar3 + fVar26, fVar27), uVar10, 1, var_f8h);
        fStack_d8 = *(float *)(*(int64_t *)0x180781f28 + 0xff0);
        fStack_d4 = *(float *)(*(int64_t *)0x180781f28 + 0xff4);
        fStack_d0 = *(float *)(*(int64_t *)0x180781f28 + 0xff8);
        fStack_cc = *(float *)(*(int64_t *)0x180781f28 + 0xffc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar11 = func_0x0001800f5fa0(&fStack_d8);
        if (uVar18 == 0) {
            if (*(char *)arg2 != '\0') {
                fVar25 = 1.0;
                if (1.0 <= (float)(int32_t)(fVar26 / 6.0)) {
                    fVar25 = (float)(int32_t)(fVar26 / 6.0);
                }
                func_0x0001801303d0(*(undefined8 *)(iVar17 + 800), CONCAT44(fVar3 + fVar25, fVar2 + fVar25), uVar11, 
                                    fVar26 - (fVar25 + fVar25));
            }
        } else {
            fVar25 = 1.0;
            if (1.0 <= (float)(int32_t)(fVar26 / 3.6)) {
                fVar25 = (float)(int32_t)(fVar26 / 3.6);
            }
            fStack_d4 = fVar3 + fVar25;
            fStack_d8 = fVar2 + fVar25;
            var_f8h = CONCAT44(var_f8h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
            uStackX_20 = CONCAT44((fVar3 + fVar26) - fVar25, fVar27 - fVar25);
            func_0x000180126550(*(undefined8 *)(iVar17 + 800), &fStack_d8, &uStackX_20, uVar11, var_f8h, 0);
        }
    }
    iVar17 = *(int64_t *)0x180781f28;
    *(float *)0x1320 = fVar27 + *(float *)(iVar5 + 0xdf4);
    fStack_dc = fVar3 + *(float *)(iVar5 + 0xde0);
    if (*(char *)(iVar5 + 0x29f8) != '\0') {
        if (uVar18 == 0) {
            pcVar21 = "[ ]";
            if (*(char *)arg2 != '\0') {
                pcVar21 = "[x]";
            }
        } else {
            pcVar21 = "[~]";
        }
        uStackX_20 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar22 = pcVar21;
        if (pcVar21 != (char *)0xffffffffffffffff) {
            while (*pcVar22 != '\0') {
                pcVar20 = pcVar22 + 1;
                if (((*pcVar22 == '#') && (*pcVar20 == '#')) ||
                   (pcVar22 = pcVar20, pcVar20 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar27 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar27 = *(float *)(iVar17 + 0xdf0);
        }
        fVar2 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = fStack_dc;
        if (fVar27 + fVar2 + 1.0 < fStack_dc) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar5 != 0) {
            iVar15 = func_0x000180498cd0(iVar5);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar5, iVar15 + iVar5);
        }
        iVar12 = *(int32_t *)(iVar17 + 0x2a34);
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        if (iVar4 < iVar12) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar4;
            iVar12 = iVar4;
        }
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar21, 10, (int64_t)pcVar22 - (int64_t)pcVar21);
            pcVar20 = pcVar22;
            if (pcVar16 != (char *)0x0) {
                pcVar20 = pcVar16;
            }
            if ((pcVar21 == pcVar20) && (pcVar20 == pcVar22)) break;
            iVar19 = (iVar4 - iVar12) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar20 - (int32_t)pcVar21, pcVar21);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar20 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar20 == pcVar22) break;
            pcVar21 = pcVar20 + 1;
        }
        if (iVar14 != 0) {
            iVar17 = func_0x000180498cd0(iVar14);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar14, iVar17 + iVar14);
        }
    }
    if (((char)var_e6h != '\0') && (0.0 < fVar7)) {
        func_0x0001800f6cb0(CONCAT44(fStack_dc, stack0xffffffffffffff20), arg1, pcVar23, 0);
    }
    return (uint64_t)(uint8_t)uStackX_18;
}

// ============================================================
// Function: FUN_18013c1ad
// Address: 0x18013c1ad
// Size: 537 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_7dh
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_79h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Detected overlap for variable var_75h
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3a0h because it doesn't fit into ProtoModel

uint64_t fcn.18013bcf0(int64_t arg1, int64_t arg2)
{
    float *pfVar1;
    float fVar2;
    float fVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    float fVar7;
    undefined uVar8;
    uint32_t uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    char *pcVar22;
    char *pcVar23;
    char cVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined4 uStackX_18;
    float fStackX_1c;
    undefined8 uStackX_20;
    int64_t in_stack_000000e8;
    int64_t var_f8h;
    int64_t var_f0h;
    char var_e8h;
    char var_e7h;
    int64_t var_e6h;
    float fStack_dc;
    float fStack_d8;
    float fStack_d4;
    float fStack_d0;
    float fStack_cc;
    float fStack_c8;
    float fStack_c4;
    float fStack_c0;
    float fStack_bc;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_69h;
    int64_t var_5dh;
    int64_t var_38h;
    
    iVar5 = *(int64_t *)0x180781f28;
    uVar13 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar13 + 0x10b) = 1;
    iVar17 = *(int64_t *)(iVar5 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
code_r0x00018013c390:
        return uVar13 & 0xffffffffffffff00;
    }
    uVar9 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                          (*(int64_t *)(iVar17 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar17 + 0x148) * 4
                                          ));
    pcVar23 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar23 != '\0') {
            pcVar21 = pcVar23 + 1;
            if (((*pcVar23 == '#') && (*pcVar21 == '#')) || (pcVar23 = pcVar21, pcVar21 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_f8h = CONCAT44(var_f8h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&uStackX_18, arg1, pcVar23, 0, var_f8h);
    fVar7 = uStackX_18;
    fVar27 = *(float *)(iVar5 + 0xde0);
    fVar2 = *(float *)(undefined8 *)(iVar17 + 0x158);
    fVar3 = *(float *)(iVar17 + 0x15c);
    uVar6 = *(undefined8 *)(iVar17 + 0x158);
    fVar26 = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
             *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if (uStackX_18 <= 0.0) {
        uStackX_18 = 0.0;
    } else {
        uStackX_18 = uStackX_18 + *(float *)(iVar5 + 0xdf4);
    }
    fStack_bc = fVar3 + fVar27 + fVar27 + fStackX_1c;
    fStack_c0 = fVar26 + uStackX_18 + fVar2;
    fStackX_1c = fStack_bc - fVar3;
    uStackX_18 = fStack_c0 - fVar2;
    fStack_c8 = fVar2;
    fStack_c4 = fVar3;
    func_0x00018010bbf0(&uStackX_18, fVar27);
    uVar13 = func_0x00018010b530(&fStack_c8, uVar9, 0, 0);
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x400000;
    var_e6h._0_1_ = (char)uVar13;
    if ((char)var_e6h == '\0') {
        if ((((uVar18 == 0) || (*(char *)(iVar5 + 0x25b8) == '\0')) ||
            ((*(float *)(iVar5 + 0x25c8) <= fStack_c4 ||
             ((fStack_bc < *(float *)(iVar5 + 0x25c0) || fStack_bc == *(float *)(iVar5 + 0x25c0) ||
              (*(float *)(iVar5 + 0x25c4) <= fStack_c8)))))) ||
           (fStack_c0 < *(float *)(iVar5 + 0x25bc) || fStack_c0 == *(float *)(iVar5 + 0x25bc)))
        goto code_r0x00018013c390;
        uStackX_18._0_1_ = *(char *)arg2;
    } else {
        cVar24 = *(char *)arg2;
        uStackX_18._0_1_ = cVar24;
        if (uVar18 == 0) {
            var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
            uStackX_18._0_1_ =
                 fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                               in_stack_000000e8);
            if ((uint8_t)uStackX_18 != 0) {
                cVar24 = cVar24 == '\0';
            }
            goto code_r0x00018013bf74;
        }
    }
    func_0x0001801475c0(uVar9, &uStackX_18, 0);
    var_f8h = (uint64_t)var_f8h._4_4_ << 0x20;
    uVar8 = fcn.180139d40((int64_t)&fStack_c8, (uint64_t)uVar9, (int64_t)&var_e8h, (int64_t)&var_e7h, var_f8h, 
                          in_stack_000000e8);
    uStackX_20 = CONCAT71(uStackX_20._1_7_, uVar8);
    func_0x0001801476e0(uVar9, &uStackX_18, &uStackX_20);
    cVar24 = (uint8_t)uStackX_18;
    uStackX_18._0_1_ = (uint8_t)uStackX_20;
code_r0x00018013bf74:
    if (*(char *)arg2 != cVar24) {
        *(char *)arg2 = cVar24;
        uStackX_18._0_1_ = 1;
        func_0x0001800fa060(uVar9);
    }
    uVar18 = *(uint32_t *)(iVar5 + 0x1fbc) & 0x1000;
    fVar27 = fVar2 + fVar26;
    if ((char)var_e6h != '\0') {
        func_0x0001800f7d00(&fStack_c8, uVar9, 0);
        uVar11 = *(undefined4 *)(iVar5 + 0xde4);
        if ((var_e7h == '\0') || (var_e8h == '\0')) {
            iVar14 = (uint64_t)(var_e8h != '\0') + 7;
        } else {
            iVar14 = 9;
        }
        pfVar1 = (float *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar14 + 0x14) * 0x10);
        fStack_d8 = *pfVar1;
        fStack_d4 = pfVar1[1];
        fStack_d0 = pfVar1[2];
        fStack_cc = pfVar1[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar10 = func_0x0001800f5fa0(&fStack_d8);
        var_f8h = CONCAT44(var_f8h._4_4_, uVar11);
        func_0x0001800f7a00(uVar6, CONCAT44(fVar3 + fVar26, fVar27), uVar10, 1, var_f8h);
        fStack_d8 = *(float *)(*(int64_t *)0x180781f28 + 0xff0);
        fStack_d4 = *(float *)(*(int64_t *)0x180781f28 + 0xff4);
        fStack_d0 = *(float *)(*(int64_t *)0x180781f28 + 0xff8);
        fStack_cc = *(float *)(*(int64_t *)0x180781f28 + 0xffc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar11 = func_0x0001800f5fa0(&fStack_d8);
        if (uVar18 == 0) {
            if (*(char *)arg2 != '\0') {
                fVar25 = 1.0;
                if (1.0 <= (float)(int32_t)(fVar26 / 6.0)) {
                    fVar25 = (float)(int32_t)(fVar26 / 6.0);
                }
                func_0x0001801303d0(*(undefined8 *)(iVar17 + 800), CONCAT44(fVar3 + fVar25, fVar2 + fVar25), uVar11, 
                                    fVar26 - (fVar25 + fVar25));
            }
        } else {
            fVar25 = 1.0;
            if (1.0 <= (float)(int32_t)(fVar26 / 3.6)) {
                fVar25 = (float)(int32_t)(fVar26 / 3.6);
            }
            fStack_d4 = fVar3 + fVar25;
            fStack_d8 = fVar2 + fVar25;
            var_f8h = CONCAT44(var_f8h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
            uStackX_20 = CONCAT44((fVar3 + fVar26) - fVar25, fVar27 - fVar25);
            func_0x000180126550(*(undefined8 *)(iVar17 + 800), &fStack_d8, &uStackX_20, uVar11, var_f8h, 0);
        }
    }
    iVar17 = *(int64_t *)0x180781f28;
    *(float *)0x1320 = fVar27 + *(float *)(iVar5 + 0xdf4);
    fStack_dc = fVar3 + *(float *)(iVar5 + 0xde0);
    if (*(char *)(iVar5 + 0x29f8) != '\0') {
        if (uVar18 == 0) {
            pcVar21 = "[ ]";
            if (*(char *)arg2 != '\0') {
                pcVar21 = "[x]";
            }
        } else {
            pcVar21 = "[~]";
        }
        uStackX_20 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar22 = pcVar21;
        if (pcVar21 != (char *)0xffffffffffffffff) {
            while (*pcVar22 != '\0') {
                pcVar20 = pcVar22 + 1;
                if (((*pcVar22 == '#') && (*pcVar20 == '#')) ||
                   (pcVar22 = pcVar20, pcVar20 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar27 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar27 = *(float *)(iVar17 + 0xdf0);
        }
        fVar2 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = fStack_dc;
        if (fVar27 + fVar2 + 1.0 < fStack_dc) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar5 != 0) {
            iVar15 = func_0x000180498cd0(iVar5);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar5, iVar15 + iVar5);
        }
        iVar12 = *(int32_t *)(iVar17 + 0x2a34);
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        if (iVar4 < iVar12) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar4;
            iVar12 = iVar4;
        }
        iVar4 = *(int32_t *)(uStackX_20 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar21, 10, (int64_t)pcVar22 - (int64_t)pcVar21);
            pcVar20 = pcVar22;
            if (pcVar16 != (char *)0x0) {
                pcVar20 = pcVar16;
            }
            if ((pcVar21 == pcVar20) && (pcVar20 == pcVar22)) break;
            iVar19 = (iVar4 - iVar12) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar20 - (int32_t)pcVar21, pcVar21);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar20 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar20 == pcVar22) break;
            pcVar21 = pcVar20 + 1;
        }
        if (iVar14 != 0) {
            iVar17 = func_0x000180498cd0(iVar14);
            func_0x000180112520((int64_t)&var_e6h + 6, iVar14, iVar17 + iVar14);
        }
    }
    if (((char)var_e6h != '\0') && (0.0 < fVar7)) {
        func_0x0001800f6cb0(CONCAT44(fStack_dc, stack0xffffffffffffff20), arg1, pcVar23, 0);
    }
    return (uint64_t)(uint8_t)uStackX_18;
}

// ============================================================
// Function: FUN_18013c3d0
// Address: 0x18013c3d0
// Size: 53 bytes
// ============================================================
void fcn.18013c3d0(int64_t arg1)
{
    undefined8 *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined8 uVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    char cVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) == '\0') {
        puVar1 = (undefined8 *)(iVar4 + 0x158);
        fVar2 = *(float *)puVar1;
        fVar3 = *(float *)(iVar4 + 0x15c);
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        uVar7 = *puVar1;
        fVar13 = fVar2 + *(float *)arg1;
        fVar12 = fVar3 + *(float *)(arg1 + 4);
        func_0x00018010bbf0(arg1, 0xbf800000);
        iVar11 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar4 = *(int64_t *)(iVar11 + 0x15e0);
        *(undefined4 *)(iVar11 + 0x1fb8) = 0;
        auVar5._8_4_ = fVar13;
        auVar5._0_8_ = uVar7;
        auVar5._12_4_ = fVar12;
        *(undefined (*) [16])(iVar11 + 0x1fc4) = auVar5;
        *(undefined4 *)(iVar11 + 0x1fc0) = 0;
        auVar6._8_4_ = fVar13;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar12;
        *(undefined (*) [16])(iVar11 + 0x1fd4) = auVar6;
        *(undefined8 *)(iVar11 + 0x1f80) = 0;
        unique0x10000062 = fVar13;
        var_58h = uVar9;
        unique0x10000066 = fVar12;
        if ((((fVar12 < *(float *)(iVar4 + 700) || fVar12 == *(float *)(iVar4 + 700)) ||
             (*(float *)(iVar4 + 0x2c4) <= fVar3)) ||
            (fVar13 < *(float *)(iVar4 + 0x2b8) || fVar13 == *(float *)(iVar4 + 0x2b8))) ||
           (*(float *)(iVar4 + 0x2c0) <= fVar2)) {
            if (*(char *)(iVar11 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar11 + 0x1fc0) = 0x100;
        }
        cVar10 = func_0x000180108120(&var_58h, &var_50h, 1);
        if (cVar10 != '\0') {
            *(uint32_t *)(iVar11 + 0x1fc0) = *(uint32_t *)(iVar11 + 0x1fc0) | 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18013c405
// Address: 0x18013c405
// Size: 188 bytes
// ============================================================
void fcn.18013c3d0(int64_t arg1)
{
    undefined8 *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined8 uVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    char cVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) == '\0') {
        puVar1 = (undefined8 *)(iVar4 + 0x158);
        fVar2 = *(float *)puVar1;
        fVar3 = *(float *)(iVar4 + 0x15c);
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        uVar7 = *puVar1;
        fVar13 = fVar2 + *(float *)arg1;
        fVar12 = fVar3 + *(float *)(arg1 + 4);
        func_0x00018010bbf0(arg1, 0xbf800000);
        iVar11 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar4 = *(int64_t *)(iVar11 + 0x15e0);
        *(undefined4 *)(iVar11 + 0x1fb8) = 0;
        auVar5._8_4_ = fVar13;
        auVar5._0_8_ = uVar7;
        auVar5._12_4_ = fVar12;
        *(undefined (*) [16])(iVar11 + 0x1fc4) = auVar5;
        *(undefined4 *)(iVar11 + 0x1fc0) = 0;
        auVar6._8_4_ = fVar13;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar12;
        *(undefined (*) [16])(iVar11 + 0x1fd4) = auVar6;
        *(undefined8 *)(iVar11 + 0x1f80) = 0;
        unique0x10000062 = fVar13;
        var_58h = uVar9;
        unique0x10000066 = fVar12;
        if ((((fVar12 < *(float *)(iVar4 + 700) || fVar12 == *(float *)(iVar4 + 700)) ||
             (*(float *)(iVar4 + 0x2c4) <= fVar3)) ||
            (fVar13 < *(float *)(iVar4 + 0x2b8) || fVar13 == *(float *)(iVar4 + 0x2b8))) ||
           (*(float *)(iVar4 + 0x2c0) <= fVar2)) {
            if (*(char *)(iVar11 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar11 + 0x1fc0) = 0x100;
        }
        cVar10 = func_0x000180108120(&var_58h, &var_50h, 1);
        if (cVar10 != '\0') {
            *(uint32_t *)(iVar11 + 0x1fc0) = *(uint32_t *)(iVar11 + 0x1fc0) | 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18013c4c1
// Address: 0x18013c4c1
// Size: 106 bytes
// ============================================================
void fcn.18013c3d0(int64_t arg1)
{
    undefined8 *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined8 uVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    char cVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) == '\0') {
        puVar1 = (undefined8 *)(iVar4 + 0x158);
        fVar2 = *(float *)puVar1;
        fVar3 = *(float *)(iVar4 + 0x15c);
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        uVar7 = *puVar1;
        fVar13 = fVar2 + *(float *)arg1;
        fVar12 = fVar3 + *(float *)(arg1 + 4);
        func_0x00018010bbf0(arg1, 0xbf800000);
        iVar11 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar4 = *(int64_t *)(iVar11 + 0x15e0);
        *(undefined4 *)(iVar11 + 0x1fb8) = 0;
        auVar5._8_4_ = fVar13;
        auVar5._0_8_ = uVar7;
        auVar5._12_4_ = fVar12;
        *(undefined (*) [16])(iVar11 + 0x1fc4) = auVar5;
        *(undefined4 *)(iVar11 + 0x1fc0) = 0;
        auVar6._8_4_ = fVar13;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar12;
        *(undefined (*) [16])(iVar11 + 0x1fd4) = auVar6;
        *(undefined8 *)(iVar11 + 0x1f80) = 0;
        unique0x10000062 = fVar13;
        var_58h = uVar9;
        unique0x10000066 = fVar12;
        if ((((fVar12 < *(float *)(iVar4 + 700) || fVar12 == *(float *)(iVar4 + 700)) ||
             (*(float *)(iVar4 + 0x2c4) <= fVar3)) ||
            (fVar13 < *(float *)(iVar4 + 0x2b8) || fVar13 == *(float *)(iVar4 + 0x2b8))) ||
           (*(float *)(iVar4 + 0x2c0) <= fVar2)) {
            if (*(char *)(iVar11 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar11 + 0x1fc0) = 0x100;
        }
        cVar10 = func_0x000180108120(&var_58h, &var_50h, 1);
        if (cVar10 != '\0') {
            *(uint32_t *)(iVar11 + 0x1fc0) = *(uint32_t *)(iVar11 + 0x1fc0) | 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18013c52b
// Address: 0x18013c52b
// Size: 5 bytes
// ============================================================
void fcn.18013c3d0(int64_t arg1)
{
    undefined8 *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined8 uVar7;
    undefined8 uVar8;
    undefined8 uVar9;
    char cVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) == '\0') {
        puVar1 = (undefined8 *)(iVar4 + 0x158);
        fVar2 = *(float *)puVar1;
        fVar3 = *(float *)(iVar4 + 0x15c);
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        uVar7 = *puVar1;
        fVar13 = fVar2 + *(float *)arg1;
        fVar12 = fVar3 + *(float *)(arg1 + 4);
        func_0x00018010bbf0(arg1, 0xbf800000);
        iVar11 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar4 = *(int64_t *)(iVar11 + 0x15e0);
        *(undefined4 *)(iVar11 + 0x1fb8) = 0;
        auVar5._8_4_ = fVar13;
        auVar5._0_8_ = uVar7;
        auVar5._12_4_ = fVar12;
        *(undefined (*) [16])(iVar11 + 0x1fc4) = auVar5;
        *(undefined4 *)(iVar11 + 0x1fc0) = 0;
        auVar6._8_4_ = fVar13;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar12;
        *(undefined (*) [16])(iVar11 + 0x1fd4) = auVar6;
        *(undefined8 *)(iVar11 + 0x1f80) = 0;
        unique0x10000062 = fVar13;
        var_58h = uVar9;
        unique0x10000066 = fVar12;
        if ((((fVar12 < *(float *)(iVar4 + 700) || fVar12 == *(float *)(iVar4 + 700)) ||
             (*(float *)(iVar4 + 0x2c4) <= fVar3)) ||
            (fVar13 < *(float *)(iVar4 + 0x2b8) || fVar13 == *(float *)(iVar4 + 0x2b8))) ||
           (*(float *)(iVar4 + 0x2c0) <= fVar2)) {
            if (*(char *)(iVar11 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar11 + 0x1fc0) = 0x100;
        }
        cVar10 = func_0x000180108120(&var_58h, &var_50h, 1);
        if (cVar10 != '\0') {
            *(uint32_t *)(iVar11 + 0x1fc0) = *(uint32_t *)(iVar11 + 0x1fc0) | 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18013c530
// Address: 0x18013c530
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013c566
// Address: 0x18013c566
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013c5b0
// Address: 0x18013c5b0
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013c609
// Address: 0x18013c609
// Size: 350 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013c767
// Address: 0x18013c767
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013c785
// Address: 0x18013c785
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013c793
// Address: 0x18013c793
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013c79d
// Address: 0x18013c79d
// Size: 418 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013c93f
// Address: 0x18013c93f
// Size: 438 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013caf5
// Address: 0x18013caf5
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013cb15
// Address: 0x18013cb15
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.18013c530(int64_t arg1, int64_t arg_68h)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    undefined8 uVar10;
    undefined auVar11 [12];
    char cVar12;
    undefined4 uVar13;
    int32_t iVar14;
    int64_t iVar15;
    char *pcVar16;
    int64_t iVar17;
    uint32_t uVar18;
    int32_t iVar19;
    char *pcVar20;
    char *pcVar21;
    int32_t iVar22;
    int64_t iVar23;
    char *pcVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_b8h;
    int64_t var_b0h;
    undefined var_a8h [4];
    int64_t var_a4h;
    float var_9ch;
    undefined4 var_98h;
    undefined4 uStack_94;
    undefined4 uStack_90;
    int64_t var_8ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    stack0xffffffffffffff60 = _var_a8h;
    iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar17 + 0x10e) != '\0') {
        return;
    }
    iVar22 = *(int32_t *)(iVar17 + 0x214);
    uVar18 = 2 - (iVar22 != 0);
    if (*(int64_t *)(iVar17 + 0x208) != 0) {
        bVar25 = iVar22 != 0;
        iVar22 = -iVar22;
        uVar18 = 6 - bVar25;
    }
    fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xe90);
    *(undefined *)(iVar17 + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar4 + 0x15e0);
    if (*(char *)(iVar3 + 0x10e) != '\0') {
        return;
    }
    if (fVar30 <= 1.0) {
        fVar30 = 1.0;
    }
    if ((uVar18 & 2) != 0) {
        puVar1 = (undefined8 *)(iVar3 + 0x158);
        fVar29 = *(float *)puVar1;
        fVar28 = fVar29 + fVar30;
        fVar27 = *(float *)(iVar3 + 0x15c);
        uVar10 = *puVar1;
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        var_8h._4_4_ = 0.0;
        fVar26 = fVar27 + *(float *)(iVar3 + 0x184);
        var_8h._0_4_ = fVar30;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        iVar23 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar17 = *(int64_t *)(iVar23 + 0x15e0);
        *(undefined4 *)(iVar23 + 0x1fb8) = 0;
        auVar6._8_4_ = fVar28;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fc4) = auVar6;
        *(undefined4 *)(iVar23 + 0x1fc0) = 0;
        auVar7._8_4_ = fVar28;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar26;
        *(undefined (*) [16])(iVar23 + 0x1fd4) = auVar7;
        *(undefined8 *)(iVar23 + 0x1f80) = 0;
        var_a4h._4_4_ = fVar28;
        _var_a8h = uVar10;
        var_9ch = fVar26;
        if ((((fVar26 < *(float *)(iVar17 + 700) || fVar26 == *(float *)(iVar17 + 700)) ||
             (*(float *)(iVar17 + 0x2c4) <= fVar27)) ||
            (fVar28 < *(float *)(iVar17 + 0x2b8) || fVar28 == *(float *)(iVar17 + 0x2b8))) ||
           (*(float *)(iVar17 + 0x2c0) <= fVar29)) {
            if (*(char *)(iVar23 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
        }
        cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
        }
        var_98h = *(undefined4 *)(iVar23 + 0x1080);
        uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
        uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
        var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
        uVar13 = func_0x0001800f5fa0(&var_98h);
        var_b8h = var_b8h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
        if (*(char *)(iVar4 + 0x29f8) == '\0') {
            return;
        }
        func_0x0001801124e0(0x180645ac0);
        return;
    }
    if ((uVar18 & 1) == 0) {
        return;
    }
    fVar29 = *(float *)(iVar3 + 0x158);
    fVar27 = *(float *)(iVar3 + 0x2a0);
    if ((uVar18 & 4) == 0) {
        var_10h = 0;
    } else {
        var_10h = *(int64_t *)(iVar3 + 0x208);
        if (var_10h != 0) {
            fVar29 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x19c);
            fVar27 = *(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68);
            func_0x000180138b90(uVar18, iVar17, iVar22);
        }
    }
    auVar11._4_8_ = stack0xffffffffffffff60;
    auVar11._0_4_ = *(float *)(iVar3 + 0x15c);
    _var_a8h = auVar11._0_8_ << 0x20;
    var_a4h._4_4_ = fVar27;
    var_a8h = (undefined  [4])fVar29;
    var_8h._0_4_ = 0.0;
    var_9ch = *(float *)(iVar3 + 0x15c) + fVar30;
    var_8h._4_4_ = fVar30;
    func_0x00018010bbf0(&var_8h, 0xbf800000);
    iVar23 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    uVar2 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(undefined (*) [4])(iVar23 + 0x1fc4) = var_a8h;
    *(float *)(iVar23 + 0x1fc8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fcc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fd0) = var_9ch;
    *(uint32_t *)(iVar23 + 0x1fbc) = uVar18 | uVar2;
    iVar17 = *(int64_t *)(iVar23 + 0x15e0);
    *(undefined (*) [4])(iVar23 + 0x1fd4) = var_a8h;
    *(float *)(iVar23 + 0x1fd8) = (float)var_a4h;
    *(float *)(iVar23 + 0x1fdc) = var_a4h._4_4_;
    *(float *)(iVar23 + 0x1fe0) = var_9ch;
    *(undefined4 *)(iVar23 + 0x1fc0) = 0;
    *(undefined8 *)(iVar23 + 0x1f80) = 0;
    if (((var_9ch < *(float *)(iVar17 + 700) || var_9ch == *(float *)(iVar17 + 700)) ||
        (*(float *)(iVar17 + 0x2c4) <= (float)var_a4h)) ||
       ((var_a4h._4_4_ < *(float *)(iVar17 + 0x2b8) || var_a4h._4_4_ == *(float *)(iVar17 + 0x2b8) ||
        (*(float *)(iVar17 + 0x2c0) <= (float)var_a8h)))) {
        if (*(char *)(iVar23 + 0x1652) == '\0') goto code_r0x00018013cb15;
    } else {
        *(undefined4 *)(iVar23 + 0x1fc0) = 0x100;
    }
    cVar12 = func_0x000180108120(var_a8h, (int64_t)&var_a4h + 4, 1);
    if (cVar12 != '\0') {
        *(uint32_t *)(iVar23 + 0x1fc0) = *(uint32_t *)(iVar23 + 0x1fc0) | 1;
    }
    var_98h = *(undefined4 *)(iVar23 + 0x1080);
    uStack_94 = *(undefined4 *)(iVar23 + 0x1084);
    uStack_90 = *(undefined4 *)(iVar23 + 0x1088);
    var_8ch._0_4_ = *(float *)(iVar23 + 0x108c) * *(float *)(iVar23 + 0xd9c);
    uVar13 = func_0x0001800f5fa0(&var_98h);
    var_b8h = var_b8h & 0xffffffff00000000;
    func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_a8h, (int64_t)&var_a4h + 4, uVar13, var_b8h, 0);
    iVar17 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar4 + 0x29f8) != '\0') {
        pcVar24 = "--------------------------------\n";
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar23 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar17 + 0x2a20) = 0;
        pcVar20 = "--------------------------------\n";
        do {
            if ((*pcVar20 == '\0') || ((pcVar21 = pcVar20 + 1, *pcVar20 == '#' && (*pcVar21 == '#')))) break;
            pcVar20 = pcVar21;
        } while (pcVar21 != (char *)0xffffffffffffffff);
        fVar30 = *(float *)(iVar17 + 0xde0);
        if (*(float *)(iVar17 + 0xde0) <= *(float *)(iVar17 + 0xdf0)) {
            fVar30 = *(float *)(iVar17 + 0xdf0);
        }
        fVar29 = *(float *)(iVar17 + 0x2a30);
        *(float *)(iVar17 + 0x2a30) = (float)var_a4h;
        if (fVar30 + fVar29 + 1.0 < (float)var_a4h) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar17 + 0x29f9) = 1;
        }
        if (iVar4 != 0) {
            iVar15 = func_0x000180498cd0(iVar4);
            func_0x000180112520(var_a8h, iVar4, iVar4 + iVar15);
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        iVar14 = *(int32_t *)(iVar17 + 0x2a34);
        if (iVar22 < iVar14) {
            *(int32_t *)(iVar17 + 0x2a34) = iVar22;
            iVar14 = iVar22;
        }
        iVar22 = *(int32_t *)(iVar5 + 0x1e0);
        while( true ) {
            pcVar16 = (char *)func_0x000180498a80(pcVar24, 10, (int64_t)pcVar20 - (int64_t)pcVar24);
            pcVar21 = pcVar20;
            if (pcVar16 != (char *)0x0) {
                pcVar21 = pcVar16;
            }
            if ((pcVar24 == pcVar21) && (pcVar21 == pcVar20)) break;
            iVar19 = (iVar22 - iVar14) * 4;
            if (*(char *)(iVar17 + 0x29f9) == '\0') {
                iVar19 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar19, 0x1805aadb1, (int32_t)pcVar21 - (int32_t)pcVar24, pcVar24);
            *(undefined *)(iVar17 + 0x29f9) = 0;
            if (*pcVar21 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar17 + 0x29f9) = 1;
            }
            if (pcVar21 == pcVar20) break;
            pcVar24 = pcVar21 + 1;
        }
        if (iVar23 != 0) {
            iVar17 = func_0x000180498cd0(iVar23);
            func_0x000180112520(var_a8h, iVar23, iVar17 + iVar23);
        }
    }
code_r0x00018013cb15:
    iVar17 = var_10h;
    if (var_10h != 0) {
        func_0x000180138c50();
        *(undefined4 *)(iVar17 + 0x1c) = *(undefined4 *)(iVar3 + 0x15c);
    }
    return;
}

// ============================================================
// Function: FUN_18013cb40
// Address: 0x18013cb40
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch

void fcn.18013cb40(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char *pcVar1;
    undefined8 *puVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined8 uVar10;
    undefined8 uVar11;
    undefined8 uVar12;
    int64_t iVar13;
    char cVar14;
    undefined4 uVar15;
    char *pcVar16;
    int64_t iVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fStackX_10;
    float fStackX_14;
    float fStackX_18;
    float fStackX_1c;
    float fStackX_20;
    float fStackX_24;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    undefined8 var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar13 = *(int64_t *)0x180781f28;
    var_e0h = var_e8h;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar6 = *(int64_t *)(iVar13 + 0x15e0);
    if (*(char *)(iVar6 + 0x10e) == '\0') {
        pcVar16 = (char *)arg1;
        if (arg1 != -1) {
            while (*pcVar16 != '\0') {
                pcVar1 = pcVar16 + 1;
                if (((*pcVar16 == '#') && (*pcVar1 == '#')) || (pcVar16 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
                break;
            }
        }
        var_108h = CONCAT44(var_108h._4_4_, 0xbf800000);
        func_0x0001800fe0a0(&fStackX_18, arg1, pcVar16, 0, var_108h);
        fVar20 = *(float *)(iVar13 + 0xea0);
        fVar19 = *(float *)(iVar6 + 0x15c);
        fVar3 = *(float *)(iVar13 + 0xe94);
        fStackX_10 = fVar20 + fVar20;
        var_e8h._4_4_ = *(float *)(iVar13 + 0xea4) + *(float *)(iVar13 + 0xea4) + fStackX_1c;
        puVar2 = (undefined8 *)(iVar6 + 0x158);
        fVar4 = *(float *)puVar2;
        uVar12 = *puVar2;
        uVar11 = *puVar2;
        uVar10 = *puVar2;
        fVar5 = *(float *)(iVar6 + 0x2a0);
        if (var_e8h._4_4_ <= fVar3) {
            var_e8h._4_4_ = fVar3;
        }
        fVar22 = var_e8h._4_4_ + fVar19;
        var_e8h._0_4_ = fStackX_18 + 0.0 + fStackX_10;
        fVar18 = *(float *)(iVar13 + 0xe9c);
        func_0x00018010bbf0(&var_e8h);
        iVar17 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar7 = *(int64_t *)(iVar17 + 0x15e0);
        *(undefined4 *)(iVar17 + 0x1fb8) = 0;
        auVar8._8_4_ = fVar5;
        auVar8._0_8_ = uVar10;
        auVar8._12_4_ = fVar22;
        *(undefined (*) [16])(iVar17 + 0x1fc4) = auVar8;
        *(undefined4 *)(iVar17 + 0x1fc0) = 0;
        auVar9._8_4_ = fVar5;
        auVar9._0_8_ = uVar11;
        auVar9._12_4_ = fVar22;
        *(undefined (*) [16])(iVar17 + 0x1fd4) = auVar9;
        *(undefined8 *)(iVar17 + 0x1f80) = 0;
        unique0x100000a1 = fVar5;
        var_e8h = uVar12;
        var_e0h._4_4_ = fVar22;
        if (((fVar22 < *(float *)(iVar7 + 700) || fVar22 == *(float *)(iVar7 + 700)) ||
            (*(float *)(iVar7 + 0x2c4) <= fVar19)) ||
           ((fVar5 < *(float *)(iVar7 + 0x2b8) || fVar5 == *(float *)(iVar7 + 0x2b8) ||
            (*(float *)(iVar7 + 0x2c0) <= fVar4)))) {
            if (*(char *)(iVar17 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar17 + 0x1fc0) = 0x100;
        }
        cVar14 = func_0x000180108120(&var_e8h, &var_e0h, 1);
        if (cVar14 != '\0') {
            *(uint32_t *)(iVar17 + 0x1fc0) = *(uint32_t *)(iVar17 + 0x1fc0) | 1;
        }
        fStackX_24 = (float)(int32_t)(((fVar22 - fVar19) - fStackX_1c) * fVar18 + 0.99999) + fVar19;
        fVar21 = (float)(int32_t)((fVar22 + fVar19) * 0.5 + 0.99999);
        fVar18 = (fVar5 - fVar4) - fStackX_10;
        fVar19 = 0.0;
        if (0.0 <= fVar18) {
            fVar19 = fVar18;
        }
        fVar19 = ((fVar19 - fStackX_18) - 0.0) * *(float *)(iVar13 + 0xe98);
        fStackX_20 = 0.0;
        if (0.0 <= fVar19) {
            fStackX_20 = fVar19;
        }
        fStackX_20 = fStackX_20 + fVar20 + fVar4;
        *(float *)(iVar6 + 0x160) = fStackX_20 + fStackX_18;
        var_e0h._4_4_ = *(float *)(iVar17 + 0x108c) * *(float *)(iVar17 + 0xd9c);
        _var_e8h = *(undefined (*) [12])(iVar17 + 0x1080);
        uVar15 = func_0x0001800f5fa0(&var_e8h);
        fStackX_14 = fVar21;
        if (fStackX_18 <= 0.0) {
            if (*(char *)(iVar13 + 0x29f8) != '\0') {
                func_0x0001801124e0(0x180645aac);
            }
            if (0.0 < fVar3) {
                var_108h = CONCAT44(var_108h._4_4_, fVar3);
                fStackX_10 = fVar5;
                fStackX_18 = fVar4;
                fStackX_1c = fVar21;
                func_0x000180126300(*(undefined8 *)(iVar6 + 800), &fStackX_18, &fStackX_10, uVar15, var_108h);
            }
        } else {
            fStackX_10 = fStackX_20 - *(float *)(iVar13 + 0xdec);
            fVar20 = fStackX_20 + fStackX_18 + 0.0 + *(float *)(iVar13 + 0xdec);
            if ((fVar4 < fStackX_10) && (0.0 < fVar3)) {
                var_e8h = CONCAT44(fVar21, fVar4);
                var_108h = CONCAT44(var_108h._4_4_, fVar3);
                func_0x000180126300(*(undefined8 *)(iVar6 + 800), &var_e8h, &fStackX_10, uVar15, var_108h);
                iVar17 = *(int64_t *)0x180781f28;
            }
            if ((fVar20 < fVar5) && (0.0 < fVar3)) {
                var_e8h = CONCAT44(fVar21, fVar20);
                var_108h = CONCAT44(var_108h._4_4_, fVar3);
                fStackX_10 = fVar5;
                fStackX_14 = fVar21;
                func_0x000180126300(*(undefined8 *)(iVar6 + 800), &var_e8h, &fStackX_10, uVar15, var_108h);
                iVar17 = *(int64_t *)0x180781f28;
            }
            if (*(char *)(iVar13 + 0x29f8) != '\0') {
                *(undefined8 *)(iVar17 + 0x2a28) = 0;
                *(undefined8 *)(iVar17 + 0x2a20) = 0x180645aac;
            }
            fStackX_14 = fVar22 + *(float *)(iVar13 + 0xdf0);
            fStackX_10 = fVar5;
            func_0x0001800f7480(*(undefined8 *)(iVar6 + 800), &fStackX_20, &fStackX_10, fVar5, arg1, pcVar16, 
                                &fStackX_18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18013cb7f
// Address: 0x18013cb7f
// Size: 516 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_100h
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch

void fcn.18013cb40(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    char *pcVar1;
    undefined8 *puVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined8 uVar10;
    undefined8 uVar11;
    undefined8 uVar12;
    int64_t iVar13;
    char cVar14;
    undefined4 uVar15;
    char *pcVar16;
    int64_t iVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fStackX_10;
    float fStackX_14;
    float fStackX_18;
    float fStackX_1c;
    float fStackX_20;
    float fStackX_24;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    undefined8 var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar13 = *(int64_t *)0x180781f28;
    var_e0h = var_e8h;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar6 = *(int64_t *)(iVar13 + 0x15e0);
    if (*(char *)(iVar6 + 0x10e) == '\0') {
        pcVar16 = (char *)arg1;
        if (arg1 != -1) {
            while (*pcVar16 != '\0') {
                pcVar1 = pcVar16 + 1;
                if (((*pcVar16 == '#') && (*pcVar1 == '#')) || (pcVar16 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
                break;
            }
        }
        var_108h = CONCAT44(var_108h._4_4_, 0xbf800000);
        func_0x0001800fe0a0(&fStackX_18, arg1, pcVar16, 0, var_108h);
        fVar20 = *(float *)(iVar13 + 0xea0);
        fVar19 = *(float *)(iVar6 + 0x15c);
        fVar3 = *(float *)(iVar13 + 0xe94);
        fStackX_10 = fVar20 + fVar20;
        var_e8h._4_4_ = *(float *)(iVar13 + 0xea4) + *(float *)(iVar13 + 0xea4) + fStackX_1c;
        puVar2 = (undefined8 *)(iVar6 + 0x158);
        fVar4 = *(float *)puVar2;
        uVar12 = *puVar2;
        uVar11 = *puVar2;
        uVar10 = *puVar2;
        fVar5 = *(float *)(iVar6 + 0x2a0);
        if (var_e8h._4_4_ <= fVar3) {
            var_e8h._4_4_ = fVar3;
        }
        fVar22 = var_e8h._4_4_ + fVar19;
        var_e8h._0_4_ = fStackX_18 + 0.0 + fStackX_10;
        fVar18 = *(float *)(iVar13 + 0xe9c);
        func_0x00018010bbf0(&var_e8h);
        iVar17 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) =
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
        iVar7 = *(int64_t *)(iVar17 + 0x15e0);
        *(undefined4 *)(iVar17 + 0x1fb8) = 0;
        auVar8._8_4_ = fVar5;
        auVar8._0_8_ = uVar10;
        auVar8._12_4_ = fVar22;
        *(undefined (*) [16])(iVar17 + 0x1fc4) = auVar8;
        *(undefined4 *)(iVar17 + 0x1fc0) = 0;
        auVar9._8_4_ = fVar5;
        auVar9._0_8_ = uVar11;
        auVar9._12_4_ = fVar22;
        *(undefined (*) [16])(iVar17 + 0x1fd4) = auVar9;
        *(undefined8 *)(iVar17 + 0x1f80) = 0;
        unique0x100000a1 = fVar5;
        var_e8h = uVar12;
        var_e0h._4_4_ = fVar22;
        if (((fVar22 < *(float *)(iVar7 + 700) || fVar22 == *(float *)(iVar7 + 700)) ||
            (*(float *)(iVar7 + 0x2c4) <= fVar19)) ||
           ((fVar5 < *(float *)(iVar7 + 0x2b8) || fVar5 == *(float *)(iVar7 + 0x2b8) ||
            (*(float *)(iVar7 + 0x2c0) <= fVar4)))) {
            if (*(char *)(iVar17 + 0x1652) == '\0') {
                return;
            }
        } else {
            *(undefined4 *)(iVar17 + 0x1fc0) = 0x100;
        }
        cVar14 = func_0x000180108120(&var_e8h, &var_e0h, 1);
        if (cVar14 != '\0') {
            *(uint32_t *)(iVar17 + 0x1fc0) = *(uint32_t *)(iVar17 + 0x1fc0) | 1;
        }
        fStackX_24 = (float)(int32_t)(((fVar22 - fVar19) - fStackX_1c) * fVar18 + 0.99999) + fVar19;
        fVar21 = (float)(int32_t)((fVar22 + fVar19) * 0.5 + 0.99999);
        fVar18 = (fVar5 - fVar4) - fStackX_10;
        fVar19 = 0.0;
        if (0.0 <= fVar18) {
            fVar19 = fVar18;
        }
        fVar19 = ((fVar19 - fStackX_18) - 0.0) * *(float *)(iVar13 + 0xe98);
        fStackX_20 = 0.0;
        if (0.0 <= fVar19) {
            fStackX_20 = fVar19;
        }
        fStackX_20 = fStackX_20 + fVar20 + fVar4;
        *(float *)(iVar6 + 0x160) = fStackX_20 + fStackX_18;
        var_e0h._4_4_ = *(float *)(iVar17 + 0x108c) * *(float *)(iVar17 + 0xd9c);
        _var_e8h = *(undefined (*) [12])(iVar17 + 0x1080);
        uVar15 = func_0x0001800f5fa0(&var_e8h);
        fStackX_14 = fVar21;
        if (fStackX_18 <= 0.0) {
            if (*(char *)(iVar13 + 0x29f8) != '\0') {
                func_0x0001801124e0(0x180645aac);
            }
            if (0.0 < fVar3) {
                var_108h = CONCAT44(var_108h._4_4_, fVar3);
                fStackX_10 = fVar5;
                fStackX_18 = fVar4;
                fStackX_1c = fVar21;
                func_0x000180126300(*(undefined8 *)(iVar6 + 800), &fStackX_18, &fStackX_10, uVar15, var_108h);
            }
        } else {
            fStackX_10 = fStackX_20 - *(float *)(iVar13 + 0xdec);
            fVar20 = fStackX_20 + fStackX_18 + 0.0 + *(float *)(iVar13 + 0xdec);
            if ((fVar4 < fStackX_10) && (0.0 < fVar3)) {
                var_e8h = CONCAT44(fVar21, fVar4);
                var_108h = CONCAT44(var_108h._4_4_, fVar3);
                func_0x000180126300(*(undefined8 *)(iVar6 + 800), &var_e8h, &fStackX_10, uVar15, var_108h);
                iVar17 = *(int64_t *)0x180781f28;
            }
            if ((fVar20 < fVar5) && (0.0 < fVar3)) {
                var_e8h = CONCAT44(fVar21, fVar20);
                var_108h = CONCAT44(var_108h._4_4_, fVar3);
                fStackX_10 = fVar5;
                fStackX_14 = fVar21;
                func_0x000180126300(*(undefined8 *)(iVar6 + 800), &var_e8h, &fStackX_10, uVar15, var_108h);
                iVar17 = *(int64_t *)0x180781f28;
            }
            if (*(char *)(iVar13 + 0x29f8) != '\0') {
                *(undefined8 *)(iVar17 + 0x2a28) = 0;
                *(undefined8 *)(iVar17 + 0x2a20) = 0x180645aac;
            }
            fStackX_14 = fVar22 + *(float *)(iVar13 + 0xdf0);
            fStackX_10 = fVar5;
            func_0x0001800f7480(*(undefined8 *)(iVar6 + 800), &fStackX_20, &fStackX_10, fVar5, arg1, pcVar16, 
                                &fStackX_18);
        }
    }
    return;
}

