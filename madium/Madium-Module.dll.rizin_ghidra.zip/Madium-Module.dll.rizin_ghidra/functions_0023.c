// Chunk 23 - 50 functions

// ============================================================
// Function: FUN_180041aa0
// Address: 0x180041aa0
// Size: 83 bytes
// ============================================================
bool fcn.180041aa0(int64_t arg1)
{
    int16_t *piVar1;
    int16_t *piVar2;
    int64_t iVar3;
    int16_t *piVar4;
    
    iVar3 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
    }
    piVar4 = (int16_t *)(iVar3 + *(int64_t *)(arg1 + 0x10) * 2);
    piVar1 = (int16_t *)func_0x000180006c10(iVar3, piVar4);
    for (piVar2 = piVar1; (piVar2 != piVar4 && ((*piVar2 == 0x5c || (*piVar2 == 0x2f)))); piVar2 = piVar2 + 1) {
    }
    return piVar2 != piVar1;
}

// ============================================================
// Function: FUN_180041b00
// Address: 0x180041b00
// Size: 651 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

int64_t fcn.180041b00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int16_t iVar1;
    code *pcVar2;
    undefined *puVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined2 *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_70;
    undefined auStack_68 [32];
    int64_t var_48h;
    
    puVar9 = auStack_68;
    iVar7 = *(int64_t *)(arg3 + 0x10);
    puVar12 = (uint32_t *)arg3;
    if (7 < *(uint64_t *)(arg3 + 0x18)) {
        puVar12 = *(uint32_t **)arg3;
    }
    if (((iVar7 == 0) ||
        (((var_48h = iVar7 * 2, 3 < var_48h && ((*puVar12 & 0xffffffdf) - 0x3a0041 < 0x1a)) ||
         (*(int16_t *)puVar12 == 0x5c)))) || (*(int16_t *)puVar12 == 0x2f)) {
        func_0x000180007340(arg1, arg2);
        func_0x000180006d80(arg1, arg3);
        return arg1;
    }
    iVar5 = *(int64_t *)(arg2 + 0x10);
    if (7 < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    iVar11 = iVar5 * 2;
    if (iVar5 != 2) goto code_r0x000180041c55;
    puVar9 = auStack_68;
    puVar3 = auStack_68;
    if (0x19 < (*(uint32_t *)arg2 & 0xffffffdf) - 0x3a0041) goto code_r0x000180041c5e;
code_r0x000180041bc1:
    iVar13 = 0;
    do {
        uVar10 = iVar13 + iVar5 + iVar7;
        *(undefined (*) [16])arg1 = ZEXT816(0);
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 7;
        *(undefined2 *)arg1 = 0;
        *(undefined4 *)(puVar9 + 0x80) = 1;
        if (uVar10 < 8) {
            *(uint64_t *)(arg1 + 0x10) = uVar10;
            goto code_r0x000180041cee;
        }
        if (0x7ffffffffffffffe < uVar10) goto code_r0x000180041d85;
        uVar4 = uVar10 | 7;
        if (uVar4 < 0x7fffffffffffffff) {
            if (uVar4 < 10) {
                uVar4 = 10;
            }
            if (0x7fffffffffffffff < uVar4 + 1) {
code_r0x000180041d7f:
                *(undefined8 *)(puVar9 + -8) = 0x180041d84;
                func_0x000180004720();
code_r0x000180041d85:
                *(undefined8 *)(puVar9 + -8) = 0x180041d8a;
                func_0x0001800047c0();
                pcVar2 = (code *)swi(3);
                iVar7 = (*pcVar2)();
                return iVar7;
            }
            uVar8 = (uVar4 + 1) * 2;
            if (uVar8 != 0) goto code_r0x000180041c24;
            puVar6 = (undefined2 *)0x0;
code_r0x000180041cc6:
            *(uint64_t *)(arg1 + 0x10) = uVar10;
            *(uint64_t *)(arg1 + 0x18) = uVar4;
            *puVar6 = *(undefined2 *)arg1;
            *(undefined2 **)arg1 = puVar6;
code_r0x000180041cee:
            iVar7 = arg1;
            if (7 < *(uint64_t *)(arg1 + 0x18)) {
                iVar7 = *(int64_t *)arg1;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180041d06;
            func_0x000180498030(iVar7, arg2);
            puVar6 = (undefined2 *)(*(int64_t *)(puVar9 + 0x88) + iVar7);
            if ((char)iVar13 != '\0') {
                *puVar6 = 0x5c;
                puVar6 = puVar6 + 1;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180041d2c;
            func_0x000180498030(puVar6, puVar12, *(undefined8 *)(puVar9 + 0x20));
            *(uint64_t *)(arg1 + 0x10) = uVar10;
            iVar7 = arg1;
            if (7 < *(uint64_t *)(arg1 + 0x18)) {
                iVar7 = *(int64_t *)arg1;
            }
            *(undefined2 *)(iVar7 + uVar10 * 2) = 0;
            return arg1;
        }
        uVar8 = 0xfffffffffffffffe;
        uVar4 = 0x7ffffffffffffffe;
code_r0x000180041c24:
        if (uVar8 < 0x1000) {
            *(undefined8 *)(puVar9 + -8) = 0x180041cc6;
            puVar6 = (undefined2 *)func_0x000180459890();
            goto code_r0x000180041cc6;
        }
        if (uVar8 + 0x27 <= uVar8) goto code_r0x000180041d7f;
        *(undefined8 *)(puVar9 + -8) = 0x180041c46;
        iVar5 = func_0x000180459890(uVar8 + 0x27);
        if (iVar5 != 0) {
            puVar6 = (undefined2 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(puVar6 + -4) = iVar5;
            goto code_r0x000180041cc6;
        }
        iVar5 = 5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar9 = puVar9 + 8;
code_r0x000180041c55:
        puVar3 = puVar9;
        if (iVar5 == 0) goto code_r0x000180041bc1;
code_r0x000180041c5e:
        puVar9 = puVar3;
        iVar1 = *(int16_t *)(iVar11 + -2 + arg2);
        if ((iVar1 == 0x5c) || (iVar1 == 0x2f)) goto code_r0x000180041bc1;
        iVar13 = 1;
    } while( true );
}

// ============================================================
// Function: FUN_180041d90
// Address: 0x180041d90
// Size: 174 bytes
// ============================================================
undefined8 fcn.180041d90(int64_t arg1)
{
    int16_t *piVar1;
    int16_t *piVar2;
    int16_t *piVar3;
    int16_t *piVar4;
    int64_t iVar5;
    bool bVar6;
    
    iVar5 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar5 = *(int64_t *)arg1;
    }
    piVar1 = (int16_t *)(iVar5 + *(int64_t *)(arg1 + 0x10) * 2);
    for (piVar2 = (int16_t *)func_0x000180006c10(iVar5, piVar1); piVar2 != piVar1; piVar2 = piVar2 + 1) {
        if ((*piVar2 != 0x5c) && (*piVar2 != 0x2f)) break;
    }
    do {
        piVar4 = piVar2;
        if (piVar2 == piVar1) {
            return 0;
        }
        do {
            if ((*piVar4 == 0x5c) || (*piVar4 == 0x2f)) break;
            piVar4 = piVar4 + 1;
        } while (piVar4 != piVar1);
        piVar3 = (int16_t *)func_0x000180006c10(piVar2);
        bVar6 = piVar3 != piVar2;
        piVar2 = piVar4;
        if (bVar6) {
            return 1;
        }
        for (; piVar2 != piVar1; piVar2 = piVar2 + 1) {
            if ((*piVar2 != 0x5c) && (*piVar2 != 0x2f)) break;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180041e50
// Address: 0x180041e50
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180041e50(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = *(undefined8 *)arg2;
    fcn.180007340(arg1 + 8, arg2 + 8);
    *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg2 + 0x28);
    return arg1;
}

// ============================================================
// Function: FUN_180041e90
// Address: 0x180041e90
// Size: 32 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180041e9d: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180041ea2)

void fcn.180041e90(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t iStack_38;
    undefined8 uStack_30;
    
    uStack_30 = 0x180041ea2;
    if (7 < *(uint64_t *)(arg1 + 0x50)) {
        iVar1 = *(int64_t *)(arg1 + 0x38);
        iVar3 = iVar1;
        puVar4 = auStack_58;
        iStack_38 = arg1;
        if ((0xfff < *(uint64_t *)(arg1 + 0x50) * 2 + 2) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_58, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_50;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18000dccd;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x48) = 0;
    *(undefined2 *)(int64_t *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x50) = 7;
    return;
}

// ============================================================
// Function: FUN_180041eb0
// Address: 0x180041eb0
// Size: 256 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180041eb0(int64_t arg1, int64_t arg2)
{
    int16_t *piVar1;
    int64_t iVar2;
    int16_t *piVar3;
    int16_t *piVar4;
    int64_t var_18h;
    undefined auStack_68 [40];
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    piVar4 = (int16_t *)arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        piVar4 = *(int16_t **)arg1;
    }
    piVar3 = piVar4 + *(int64_t *)(arg1 + 0x10);
    var_40h = arg2;
    piVar1 = (int16_t *)func_0x000180006c10(piVar4);
    if ((piVar4 == piVar1) && (piVar1 != piVar3)) {
        do {
            if ((*piVar1 != 0x5c) && (*piVar1 != 0x2f)) break;
            piVar1 = piVar1 + 1;
        } while (piVar1 != piVar3);
        if ((piVar4 == piVar1) && (piVar1 != piVar3)) {
            while (*piVar1 != 0x5c) {
                if ((*piVar1 == 0x2f) || (piVar1 = piVar1 + 1, piVar1 == piVar3)) break;
            }
        }
    }
    var_28h = 0;
    var_20h = 0;
    _var_38h = ZEXT816(0);
    func_0x00018000d380(&var_38h, piVar4, (int64_t)piVar1 - (int64_t)piVar4 >> 1);
    iVar2 = arg1;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        iVar2 = *(int64_t *)arg1;
    }
    *(int64_t *)arg2 = iVar2;
    *(undefined4 *)(arg2 + 8) = (undefined4)var_38h;
    *(undefined4 *)(arg2 + 0xc) = var_38h._4_4_;
    *(undefined4 *)(arg2 + 0x10) = uStack_30;
    *(undefined4 *)(arg2 + 0x14) = uStack_2c;
    *(undefined4 *)(arg2 + 0x18) = (undefined4)var_28h;
    *(undefined4 *)(arg2 + 0x1c) = var_28h._4_4_;
    *(undefined4 *)(arg2 + 0x20) = (undefined4)var_20h;
    *(undefined4 *)(arg2 + 0x24) = var_20h._4_4_;
    *(int64_t *)(arg2 + 0x28) = arg1;
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_180041fb0
// Address: 0x180041fb0
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_d8h

void fcn.180041fb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_a8h;
    int64_t var_18h;
    
    arg2 = *(int64_t *)arg2;
    fcn.1800047e0(&var_c8h, arg1);
    fcn.180007520(var_a8h);
    fcn.18045bae0(arg2);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180042010
// Address: 0x180042010
// Size: 1266 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180042010(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *piVar13;
    undefined2 *puVar14;
    undefined4 *puVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    undefined auStack_50 [24];
    int64_t var_38h;
    
    if (*(int64_t *)(arg2 + 0x10) == 0) {
        return 0;
    }
    if (7 < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    uVar5 = func_0x000180455448(&var_10h, arg2, 0x80, 0x2000000);
    uVar11 = (uint64_t)uVar5;
    if (uVar5 != 0) {
code_r0x000180042269:
        func_0x000180454cc0(CONCAT71(var_10h._1_7_, (undefined)var_10h));
        return uVar11;
    }
    iVar6 = 0;
    puVar1 = (uint64_t *)(arg1 + 0x10);
    uVar11 = *puVar1;
    uVar4 = (undefined)var_10h;
    if (uVar11 < 0x104) {
        uVar7 = 0x104 - uVar11;
        if (*(uint64_t *)(arg1 + 0x18) - uVar11 < uVar7) {
            var_38h._0_2_ = 0;
            func_0x0001800477b0(arg1, uVar7, (undefined)var_10h, uVar7);
            uVar4 = (undefined)var_10h;
        } else {
            *puVar1 = 0x104;
            iVar8 = arg1;
            if (7 < *(uint64_t *)(arg1 + 0x18)) {
                iVar8 = *(int64_t *)arg1;
            }
            puVar14 = (undefined2 *)(iVar8 + uVar11 * 2);
            if (uVar7 != 0) {
                for (; uVar7 != 0; uVar7 = uVar7 - 1) {
                    *puVar14 = 0;
                    puVar14 = puVar14 + 1;
                }
            }
            *(undefined2 *)(iVar8 + 0x208) = 0;
        }
    } else {
        *puVar1 = 0x104;
        iVar8 = arg1;
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            iVar8 = *(int64_t *)arg1;
        }
        *(undefined2 *)(iVar8 + 0x208) = 0;
    }
    do {
        while( true ) {
            uVar5 = *(uint32_t *)puVar1;
            iVar8 = arg1;
            if (7 < *(uint64_t *)(arg1 + 0x18)) {
                iVar8 = *(int64_t *)arg1;
            }
            uVar7 = func_0x0001804550d4(CONCAT71(var_10h._1_7_, (undefined)var_10h), iVar8, uVar5, iVar6);
            if ((uint32_t)uVar7 != 0) break;
            uVar11 = uVar7 >> 0x20;
            if (((int32_t)(uVar7 >> 0x20) != 3) || (iVar6 != 0)) {
                *puVar1 = 0;
                if (7 < *(uint64_t *)(arg1 + 0x18)) {
                    arg1 = *(int64_t *)arg1;
                }
                *(undefined2 *)arg1 = 0;
                goto code_r0x000180042269;
            }
            iVar6 = 2;
        }
        puVar10 = (undefined4 *)(uVar7 & 0xffffffff);
        puVar15 = (undefined4 *)*puVar1;
        if (puVar15 < puVar10) {
            uVar11 = (int64_t)puVar10 - (int64_t)puVar15;
            if (*(uint64_t *)(arg1 + 0x18) - (int64_t)puVar15 < uVar11) {
                var_38h._0_2_ = 0;
                func_0x0001800477b0(arg1, uVar11, uVar4, uVar11);
            } else {
                *puVar1 = (uint64_t)puVar10;
                iVar8 = arg1;
                if (7 < *(uint64_t *)(arg1 + 0x18)) {
                    iVar8 = *(int64_t *)arg1;
                }
                puVar15 = (undefined4 *)(iVar8 + (int64_t)puVar15 * 2);
                if (uVar11 != 0) {
                    for (; uVar11 != 0; uVar11 = uVar11 - 1) {
                        *(undefined2 *)puVar15 = 0;
                        puVar15 = (undefined4 *)((int64_t)puVar15 + 2);
                    }
                }
                *(undefined2 *)(iVar8 + (int64_t)puVar10 * 2) = 0;
            }
        } else {
            *puVar1 = (uint64_t)puVar10;
            iVar8 = arg1;
            if (7 < *(uint64_t *)(arg1 + 0x18)) {
                iVar8 = *(int64_t *)arg1;
            }
            *(undefined2 *)(iVar8 + (int64_t)puVar10 * 2) = 0;
        }
    } while (uVar5 <= (uint32_t)uVar7);
    func_0x000180454cc0(CONCAT71(var_10h._1_7_, (undefined)var_10h));
    if (iVar6 == 0) {
        iVar8 = arg1;
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            iVar8 = *(int64_t *)arg1;
        }
        if (5 < *puVar1) {
            iVar6 = func_0x000180005b70(iVar8, 0x1806230d8, 4);
            if ((iVar6 == 0) && ((*(uint32_t *)(iVar8 + 8) & 0xffffffdf) - 0x3a0041 < 0x1a)) {
                uVar11 = *puVar1;
                uVar7 = 4;
                if (uVar11 < 4) {
                    uVar7 = uVar11;
                }
                if (7 < *(uint64_t *)(arg1 + 0x18)) {
                    arg1 = *(int64_t *)arg1;
                }
                fcn.180498030(arg1, arg1 + uVar7 * 2, (uVar11 - uVar7) * 2 + 2);
                *puVar1 = uVar11 - uVar7;
                return 0;
            }
        }
        iVar8 = arg1;
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            iVar8 = *(int64_t *)arg1;
        }
        if (*(uint64_t *)(arg1 + 0x10) < 8) {
            return 0;
        }
        iVar6 = func_0x000180005b70(iVar8, 0x180623110, 8);
        if (iVar6 != 0) {
            return 0;
        }
        uVar11 = *(uint64_t *)(arg1 + 0x10);
        if (1 < uVar11) {
            uVar7 = 6;
            if (uVar11 - 2 < 6) {
                uVar7 = uVar11 - 2;
            }
            iVar8 = arg1;
            if (7 < *(uint64_t *)(arg1 + 0x18)) {
                iVar8 = *(int64_t *)arg1;
            }
            fcn.180498030(iVar8 + 4, iVar8 + 4 + uVar7 * 2, (uVar11 - uVar7) * 2 + -2);
            *(uint64_t *)(arg1 + 0x10) = uVar11 - uVar7;
            return 0;
        }
        func_0x00018000f930();
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    iVar8 = *(int64_t *)(arg1 + 0x10);
    uVar11 = *(uint64_t *)(arg1 + 0x18);
    if (0xd < uVar11 - iVar8) {
        *(int64_t *)(arg1 + 0x10) = iVar8 + 0xe;
        if (7 < uVar11) {
            arg1 = *(int64_t *)arg1;
        }
        if (((uint64_t)arg1 < 0x18062310c) && (0x1806230ef < (uint64_t)(arg1 + iVar8 * 2))) {
            if ((uint64_t)arg1 < 0x1806230f1) {
                iVar12 = 0;
            } else {
                iVar12 = (int64_t)(arg1 - 0x1806230f0U) >> 1;
            }
        } else {
            iVar12 = 0xe;
        }
        fcn.180498030(arg1 + 0x1c, arg1, iVar8 * 2 + 2);
        fcn.180498030(arg1, 0x1806230f0, iVar12 * 2);
        fcn.180498030(arg1 + iVar12 * 2, iVar12 * 2 + 0x18062310c, (0xe - iVar12) * 2);
        return 0;
    }
    uVar7 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar8 < 0xe) {
        fcn.1800047c0();
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    uVar9 = iVar8 + 0xeU | 7;
    if ((uVar9 < 0x7fffffffffffffff) && (uVar11 <= 0x7ffffffffffffffe - (uVar11 >> 1))) {
        uVar2 = uVar11 + (uVar11 >> 1);
        uVar7 = uVar9;
        if (uVar9 < uVar2) {
            uVar7 = uVar2;
        }
        if (0x7fffffffffffffff < uVar7 + 1) goto code_r0x0001800424f6;
        uVar9 = (uVar7 + 1) * 2;
        if (uVar9 != 0) goto code_r0x000180042412;
        puVar15 = (undefined4 *)0x0;
code_r0x00018004244b:
        *(uint64_t *)(arg1 + 0x10) = iVar8 + 0xeU;
        *(uint64_t *)(arg1 + 0x18) = uVar7;
        iVar8 = iVar8 * 2 + 2;
        if (uVar11 < 8) {
            *puVar15 = 0x5c005c;
            puVar15[1] = 0x5c003f;
            puVar15[2] = 0x4c0047;
            puVar15[3] = 0x42004f;
            puVar15[3] = 0x42004f;
            puVar15[4] = 0x4c0041;
            puVar15[5] = 0x4f0052;
            puVar15[6] = 0x54004f;
            fcn.180498030(puVar15 + 7, arg1, iVar8);
            goto code_r0x0001800424bc;
        }
        uVar7 = *(uint64_t *)arg1;
        *puVar15 = 0x5c005c;
        puVar15[1] = 0x5c003f;
        puVar15[2] = 0x4c0047;
        puVar15[3] = 0x42004f;
        puVar15[3] = 0x42004f;
        puVar15[4] = 0x4c0041;
        puVar15[5] = 0x4f0052;
        puVar15[6] = 0x54004f;
        fcn.180498030(puVar15 + 7, uVar7, iVar8);
        uVar9 = uVar7;
        piVar13 = &var_58h;
        if (0xfff < uVar11 * 2 + 2) {
            uVar9 = *(uint64_t *)(uVar7 - 8);
            uVar7 = (uVar7 - uVar9) - 8;
            piVar13 = &var_58h;
            if (0x1f < uVar7) goto code_r0x0001800424ad;
        }
    } else {
        uVar9 = 0xfffffffffffffffe;
code_r0x000180042412:
        if (uVar9 < 0x1000) {
            puVar15 = (undefined4 *)fcn.180459890();
            goto code_r0x00018004244b;
        }
        if (uVar9 + 0x27 <= uVar9) {
code_r0x0001800424f6:
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        iVar12 = fcn.180459890(uVar9 + 0x27);
        if (iVar12 != 0) {
            puVar15 = (undefined4 *)(iVar12 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(puVar15 + -2) = iVar12;
            goto code_r0x00018004244b;
        }
code_r0x0001800424ad:
        uVar9 = uVar7;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        piVar13 = (int64_t *)auStack_50;
    }
    *(undefined8 *)((int64_t)piVar13 + -8) = 0x1800424bc;
    func_0x000180459c3c(uVar9);
code_r0x0001800424bc:
    *(undefined4 **)arg1 = puVar15;
    return 0;
}

// ============================================================
// Function: FUN_180042510
// Address: 0x180042510
// Size: 927 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180042510(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t iVar2;
    uint32_t *puVar3;
    code *pcVar4;
    undefined auVar5 [16];
    undefined uVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint32_t *puVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined *puVar12;
    undefined *puVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    uint32_t *puVar16;
    int64_t *piVar17;
    bool bVar18;
    int64_t var_18h;
    undefined8 uStack_b0;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    undefined8 uStack_58;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar12 = auStack_a8;
    puVar13 = auStack_a8;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    puVar1 = (uint64_t *)(arg1 + 0x10);
    uVar11 = *puVar1;
    *(undefined8 *)(arg2 + 8) = 0x1806a45e0;
    var_70h = arg2;
    if (uVar11 == 0) {
        *(undefined4 *)arg2 = 3;
        var_70h._4_4_ = (undefined4)((uint64_t)arg2 >> 0x20);
        *(undefined4 *)(arg2 + 4) = var_70h._4_4_;
    } else {
        piVar17 = (int64_t *)0x0;
        *(undefined4 *)arg2 = 0;
        var_50h = 0;
        var_48h = 7;
        stack0xffffffffffffffa2 = SUB1614(ZEXT816(0), 2);
        auVar5._14_2_ = 0;
        auVar5._0_14_ = stack0xffffffffffffffa2;
        _var_60h = auVar5 << 0x10;
        uVar11 = *puVar1;
        if (uVar11 < 8) {
            piVar15 = (int64_t *)0x0;
            puVar13 = auStack_a8;
        } else {
            puVar13 = auStack_a8;
            if (0x7ffffffffffffffe < uVar11) {
code_r0x0001800428a9:
                *(undefined8 *)(puVar13 + -8) = 0x1800428ae;
                fcn.1800047c0();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar11 = uVar11 | 7;
            if (uVar11 < 0x7fffffffffffffff) goto code_r0x0001800425e1;
            uVar10 = 0xfffffffffffffffe;
            uVar11 = 0x7ffffffffffffffe;
            puVar12 = auStack_a8;
            do {
                if (uVar10 < 0x1000) {
                    *(undefined8 *)(puVar12 + -8) = 0x180042624;
                    piVar15 = (int64_t *)fcn.180459890();
                    break;
                }
                if (uVar10 + 0x27 <= uVar10) {
code_r0x0001800428a3:
                    *(undefined8 *)(puVar12 + -8) = 0x1800428a8;
                    fcn.180004720();
                    puVar13 = puVar12;
                    goto code_r0x0001800428a9;
                }
                *(undefined8 *)(puVar12 + -8) = 0x1800425d5;
                iVar8 = fcn.180459890(uVar10 + 0x27);
                if (iVar8 != 0) {
                    piVar15 = (int64_t *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                    piVar15[-1] = iVar8;
                    break;
                }
                pcVar4 = (code *)swi(0x29);
                uVar11 = (*pcVar4)(5);
                puVar12 = puVar12 + 8;
code_r0x0001800425e1:
                if (uVar11 < 10) {
                    uVar11 = 10;
                }
                if (0x7fffffffffffffff < uVar11 + 1) goto code_r0x0001800428a3;
                uVar10 = (uVar11 + 1) * 2;
                piVar15 = piVar17;
            } while (uVar10 != 0);
            *(undefined2 *)piVar15 = (undefined2)var_60h;
            var_60h = (int64_t)piVar15;
            puVar13 = puVar12;
            var_48h = uVar11;
        }
        iVar8 = var_48h;
        var_50h = 0;
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        puVar3 = (uint32_t *)(arg1 + *puVar1 * 2);
        *(undefined8 *)(puVar13 + -8) = 0x180042669;
        for (puVar9 = (uint32_t *)func_0x000180006c10(arg1, puVar3);
            (puVar9 != puVar3 && ((*(int16_t *)puVar9 == 0x5c || (*(int16_t *)puVar9 == 0x2f))));
            puVar9 = (uint32_t *)((int64_t)puVar9 + 2)) {
        }
        if ((((puVar9 != (uint32_t *)arg1) && (5 < (int64_t)((int64_t)puVar3 - (int64_t)puVar9 & 0xfffffffffffffffeU)))
            && ((*puVar9 & 0xffffffdf) - 0x3a0041 < 0x1a)) &&
           ((*(int16_t *)(puVar9 + 1) == 0x5c || (*(int16_t *)(puVar9 + 1) == 0x2f)))) {
            puVar9 = puVar9 + 1;
        }
        uVar11 = (int64_t)puVar9 - arg1 >> 1;
        if ((uint64_t)iVar8 < uVar11) {
            *(uint64_t *)(puVar13 + 0x20) = uVar11;
            uVar6 = (undefined)var_78h;
            *(undefined8 *)(puVar13 + -8) = 0x180042714;
            func_0x00018000e1f0(&var_60h, uVar11, uVar6, arg1);
        } else {
            piVar14 = &var_60h;
            if (7 < (uint64_t)iVar8) {
                piVar14 = piVar15;
            }
            var_50h = uVar11;
            *(undefined8 *)(puVar13 + -8) = 0x1800426f7;
            fcn.180498030(piVar14, arg1, uVar11 * 2);
            *(undefined2 *)((int64_t)piVar14 + uVar11 * 2) = 0;
        }
        puVar16 = puVar9;
        if (puVar9 == puVar3) {
            uVar7 = 0;
        } else {
code_r0x000180042724:
            do {
                if ((*(int16_t *)puVar9 == 0x5c) || (*(int16_t *)puVar9 == 0x2f)) {
                    puVar9 = (uint32_t *)((int64_t)puVar9 + 2);
                    if (puVar9 != puVar3) goto code_r0x000180042724;
                }
                for (; ((puVar9 != puVar3 && (*(int16_t *)puVar9 != 0x5c)) && (*(int16_t *)puVar9 != 0x2f));
                    puVar9 = (uint32_t *)((int64_t)puVar9 + 2)) {
                }
                uVar11 = (int64_t)puVar9 - (int64_t)puVar16 >> 1;
                if ((uint64_t)(var_48h - var_50h) < uVar11) {
                    *(uint64_t *)(puVar13 + 0x20) = uVar11;
                    *(undefined8 *)(puVar13 + -8) = 0x1800427b8;
                    func_0x00018000e1f0(&var_60h, uVar11, (undefined)var_78h, puVar16);
                } else {
                    iVar8 = uVar11 + var_50h;
                    piVar15 = &var_60h;
                    if (7 < (uint64_t)var_48h) {
                        piVar15 = (int64_t *)var_60h;
                    }
                    iVar2 = var_50h * 2;
                    var_50h = iVar8;
                    *(undefined8 *)(puVar13 + -8) = 0x18004279a;
                    fcn.180498030((int64_t)piVar15 + iVar2, puVar16, uVar11 * 2);
                    *(undefined2 *)((int64_t)piVar15 + iVar8 * 2) = 0;
                }
                piVar15 = &var_60h;
                if (7 < (uint64_t)var_48h) {
                    piVar15 = (int64_t *)var_60h;
                }
                *(undefined8 *)(puVar13 + -8) = 0x1800427cb;
                uVar11 = func_0x000180454f68(piVar15);
                uVar7 = (uint32_t)(uVar11 >> 0x20);
                if (uVar7 != 0) {
                    if (uVar7 < 0x41) {
                        if (((uVar7 != 0x40) && (uVar7 != 2)) && (uVar7 != 3)) {
                            bVar18 = uVar7 == 0x35;
code_r0x0001800427fd:
                            if (!bVar18) {
                                piVar17 = (int64_t *)(uVar11 >> 0x20);
                            }
                        }
                    } else if ((uVar7 != 0x7b) && (uVar7 != 0xa1)) {
                        bVar18 = uVar7 == 0x10b;
                        goto code_r0x0001800427fd;
                    }
                }
                puVar16 = puVar9;
            } while (puVar9 != puVar3);
            if ((uVar7 != 0) && ((uint32_t)piVar17 != 0)) {
                uVar7 = (uint32_t)piVar17;
            }
        }
        *(uint32_t *)var_70h = uVar7;
        *(undefined4 *)(var_70h + 4) = var_70h._4_4_;
        *(undefined8 *)(var_70h + 8) = 0x1806a45e0;
        if (7 < (uint64_t)var_48h) {
            iVar8 = var_60h;
            if ((0xfff < var_48h * 2 + 2U) && (iVar8 = *(int64_t *)(var_60h + -8), 0x1f < (var_60h - iVar8) - 8U)) {
                pcVar4 = (code *)swi(0x29);
                iVar8 = (*pcVar4)(5);
                puVar13 = puVar13 + 8;
            }
            *(undefined8 *)(puVar13 + -8) = 0x18004287c;
            func_0x000180459c3c(iVar8);
        }
    }
    uVar11 = var_40h ^ (uint64_t)puVar13;
    *(undefined8 *)(puVar13 + -8) = 0x18004288b;
    func_0x000180459870(uVar11);
    return;
}

// ============================================================
// Function: FUN_1800428b0
// Address: 0x1800428b0
// Size: 508 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.1800428b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    func_0x000180007fb0(&var_58h, arg1, arg2);
    uVar3 = var_58h._4_4_;
    uVar4 = *(uint32_t *)arg2;
    piVar9 = (int64_t *)var_50h;
    while (var_50h = (int64_t)piVar9, uVar4 == 0) {
        iVar6 = CONCAT44(var_58h._4_4_, (undefined4)var_58h);
        if (iVar6 == 0) goto code_r0x000180042a25;
        piVar9 = (int64_t *)(iVar6 + 0x20);
        func_0x000180007ac0(iVar6, &var_68h, 6);
        *(int32_t *)arg2 = (int32_t)var_60h;
        *(undefined4 *)(arg2 + 4) = uVar3;
        *(undefined8 *)(arg2 + 8) = 0x1806a45e0;
        if ((int32_t)var_60h != 0) goto code_r0x0001800429cc;
        if ((int32_t)var_68h == 3) {
            fcn.1800428b0((int64_t)piVar9, arg2, arg3);
        } else {
            if (7 < *(uint64_t *)(iVar6 + 0x38)) {
                piVar9 = (int64_t *)*piVar9;
            }
            uVar5 = func_0x0001804554a0(piVar9);
            *(int32_t *)arg2 = (int32_t)(uVar5 >> 0x20);
            *(undefined4 *)(arg2 + 4) = uVar3;
            *(undefined8 *)(arg2 + 8) = 0x1806a45e0;
            *(uint64_t *)arg3 = *(int64_t *)arg3 + (uVar5 & 0xff);
        }
        if (*(int32_t *)arg2 != 0) goto code_r0x0001800429cc;
        uVar4 = func_0x000180007c30(&var_58h);
        *(uint32_t *)arg2 = uVar4;
        *(undefined4 *)(arg2 + 4) = uVar3;
        *(undefined8 *)(arg2 + 8) = 0x1806a45e0;
        piVar9 = (int64_t *)var_50h;
    }
    if (*(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == *(int64_t *)0x1806a45e8) {
        if (uVar4 < 0x41) {
            if (((uVar4 != 0x40) && (uVar4 != 2)) && ((uVar4 != 3 && (uVar4 != 0x35)))) goto code_r0x0001800429cc;
        } else if (((uVar4 != 0x7b) && (uVar4 != 0xa1)) && (uVar4 != 0x10b)) goto code_r0x0001800429cc;
code_r0x000180042a25:
        if (piVar9 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar9 + 1;
            iVar8 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)*piVar9)(piVar9);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)(*piVar9 + 8))(piVar9);
                }
            }
        }
        iVar8 = 0;
        do {
            iVar6 = arg1;
            if (7 < *(uint64_t *)(arg1 + 0x18)) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar5 = func_0x0001804554a0(iVar6);
            *(uint64_t *)arg3 = *(int64_t *)arg3 + (uVar5 & 0xff);
            iVar7 = (int32_t)(uVar5 >> 0x20);
            *(int32_t *)arg2 = iVar7;
            *(undefined4 *)(arg2 + 4) = var_58h._4_4_;
            *(undefined8 *)(arg2 + 8) = 0x1806a45e0;
        } while (((iVar7 == 0x91) || (iVar7 == 5)) && (iVar8 = iVar8 + 1, iVar8 < 10));
    } else {
code_r0x0001800429cc:
        if (var_50h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_50h + 8);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (***(code ***)var_50h)(var_50h);
                LOCK();
                piVar1 = (int32_t *)(var_50h + 0xc);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)(*(int64_t *)var_50h + 8))(var_50h);
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180042ab0
// Address: 0x180042ab0
// Size: 3932 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h

void fcn.180042ab0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    int16_t iVar3;
    undefined4 *puVar4;
    uint32_t *puVar5;
    undefined (*pauVar6) [16];
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    int64_t *piVar14;
    char cVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t **ppiVar18;
    int64_t **ppiVar19;
    int64_t *piVar20;
    int16_t *piVar21;
    int64_t iVar22;
    int16_t *piVar23;
    int16_t *piVar24;
    int64_t **ppiVar25;
    undefined *puVar26;
    undefined8 *puVar27;
    int64_t iVar28;
    uint64_t uVar29;
    uint64_t uVar30;
    int16_t *piVar31;
    uint64_t uVar32;
    undefined *puVar33;
    undefined *puVar34;
    undefined *puVar35;
    int64_t **ppiVar36;
    int16_t *piVar37;
    int64_t **unaff_R12;
    undefined2 uVar38;
    int64_t *piVar39;
    uint64_t uVar40;
    int16_t *piVar41;
    bool bVar42;
    int64_t var_20h;
    undefined8 uStack_1c0;
    undefined auStack_1b8 [8];
    undefined auStack_1b0 [24];
    int64_t var_198h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_148h;
    undefined4 auStack_140 [2];
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    uint64_t uStack_b8;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar34 = auStack_1b8;
    puVar35 = auStack_1b8;
    puVar33 = auStack_1b8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1b8;
    uVar29 = 0;
    *(undefined4 *)arg3 = 0;
    *(undefined8 *)(arg3 + 8) = 0x1806a45e0;
    var_98h = 0;
    var_90h = 7;
    stack0xffffffffffffff5a = SUB1614(ZEXT816(0), 2);
    auVar11._14_2_ = 0;
    auVar11._0_14_ = stack0xffffffffffffff5a;
    _var_a8h = auVar11 << 0x10;
    var_170h = arg1;
    var_168h = arg1;
    var_158h = arg3;
    uVar16 = fcn.180042010((int64_t)&var_a8h, arg2);
    if (uVar16 == 0) {
        *(undefined4 *)arg1 = (undefined4)var_a8h;
        *(undefined4 *)(arg1 + 4) = var_a8h._4_4_;
        *(undefined4 *)(arg1 + 8) = uStack_a0;
        *(undefined4 *)(arg1 + 0xc) = uStack_9c;
        *(undefined4 *)(arg1 + 0x10) = (undefined4)var_98h;
        *(undefined4 *)(arg1 + 0x14) = var_98h._4_4_;
        *(undefined4 *)(arg1 + 0x18) = (undefined4)var_90h;
        *(undefined4 *)(arg1 + 0x1c) = var_90h._4_4_;
        puVar35 = auStack_1b8;
        goto code_r0x0001800438ab;
    }
    if (uVar16 < 0x41) {
        if (((uVar16 != 0x40) && (uVar16 != 2)) && (uVar16 != 3)) {
            bVar42 = uVar16 == 0x35;
code_r0x000180042b64:
            if (!bVar42) {
                *(uint32_t *)arg3 = uVar16;
                *(undefined4 *)(arg3 + 4) = var_158h._4_4_;
                *(undefined8 *)(arg3 + 8) = 0x1806a45e0;
                *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
                *(undefined (*) [16])arg1 = ZEXT816(0);
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined8 *)(arg1 + 0x18) = 7;
                *(undefined2 *)arg1 = 0;
code_r0x0001800439d4:
                if (7 < (uint64_t)var_90h) {
                    *(undefined8 *)(puVar35 + -8) = 0x1800439eb;
                    func_0x00018000f950(&var_a8h, var_a8h);
                }
                goto code_r0x0001800438ab;
            }
        }
    } else if ((uVar16 != 0x7b) && (uVar16 != 0xa1)) {
        bVar42 = uVar16 == 0x10b;
        goto code_r0x000180042b64;
    }
    piVar20 = (int64_t *)(arg2 + 0x10);
    piVar39 = (int64_t *)0x5c;
    if (*piVar20 == 0) {
        var_78h = 0;
        var_70h = 7;
        stack0xffffffffffffff7a = SUB1614(ZEXT816(0), 2);
        auVar12._14_2_ = 0;
        auVar12._0_14_ = stack0xffffffffffffff7a;
        _var_88h = auVar12 << 0x10;
    } else {
        if (7 < *(uint64_t *)(arg2 + 0x18)) {
            arg2 = *(int64_t *)arg2;
        }
        ppiVar36 = (int64_t **)(arg2 + *piVar20 * 2);
        var_178h = (int64_t)ppiVar36;
        ppiVar18 = (int64_t **)func_0x000180006c10(arg2, ppiVar36);
        _var_f8h = ZEXT816(0);
        var_e8h = 0;
        var_e0h = 0;
        if ((int64_t **)arg2 == ppiVar18) {
            var_e8h = 0;
            var_e0h = 7;
            auVar13._14_2_ = 0;
            auVar13._0_14_ = stack0xffffffffffffff0a;
            _var_f8h = auVar13 << 0x10;
        } else {
            func_0x00018000d380(&var_f8h, arg2, (int64_t)ppiVar18 - arg2 >> 1);
        }
        piVar20 = &var_f8h;
        if (7 < (uint64_t)var_e0h) {
            piVar20 = (int64_t *)var_f8h;
        }
        iVar22 = var_e8h * 2;
        piVar14 = &var_f8h;
        if (7 < (uint64_t)var_e0h) {
            piVar14 = (int64_t *)var_f8h;
        }
        for (; piVar14 != (int64_t *)((int64_t)piVar20 + iVar22); piVar14 = (int64_t *)((int64_t)piVar14 + 2)) {
            if (*(int16_t *)piVar14 == 0x2f) {
                *(int16_t *)piVar14 = 0x5c;
            }
        }
        var_128h = 0;
        var_120h._0_2_ = 0;
        var_120h._2_6_ = 0;
        var_118h = 0;
        var_180h = 0x13;
        ppiVar19 = (int64_t **)func_0x000180047650(0, &var_180h);
        fcn.180498030(ppiVar19, var_128h, CONCAT62(var_120h._2_6_, (undefined2)var_120h) - var_128h);
        if (var_128h != 0) {
            uVar32 = var_118h - var_128h & 0xfffffffffffffff0;
            iVar22 = var_128h;
            if (0xfff < uVar32) {
                iVar22 = *(int64_t *)(var_128h + -8);
                if (0x1f < (var_128h - iVar22) - 8U) {
code_r0x0001800430e9:
                    pcVar7 = (code *)swi(0x29);
                    (*pcVar7)(5);
                    puVar33 = auStack_1b0;
                    goto code_r0x0001800430f0;
                }
                uVar32 = uVar32 + 0x27;
            }
            func_0x000180459c3c(iVar22, uVar32);
        }
        iVar22 = var_e8h;
        var_128h = (int64_t)ppiVar19;
        var_120h._0_2_ = SUB82(ppiVar19, 0);
        var_120h._2_6_ = (unkbyte6)((uint64_t)ppiVar19 >> 0x10);
        var_118h = (int64_t)(ppiVar19 + 0x26);
        unaff_R12 = (int64_t **)0x0;
        var_188h._0_1_ = 0;
        if (ppiVar18 != ppiVar36) {
            if ((*(int16_t *)ppiVar18 == 0x5c) || (unaff_R12 = ppiVar19, *(int16_t *)ppiVar18 == 0x2f)) {
                unaff_R12 = (int64_t **)0x1;
                if ((uint64_t)var_e8h < (uint64_t)var_e0h) {
                    var_e8h = var_e8h + 1;
                    piVar20 = &var_f8h;
                    if (7 < (uint64_t)var_e0h) {
                        piVar20 = (int64_t *)var_f8h;
                    }
                    *(undefined4 *)((int64_t)piVar20 + iVar22 * 2) = 0x5c;
                } else {
                    func_0x00018000d650(&var_f8h, 1, 0, 0x5c);
                }
                do {
                    ppiVar18 = (int64_t **)((int64_t)ppiVar18 + 2);
                    if (ppiVar18 == ppiVar36) goto code_r0x000180042d68;
                } while ((*(int16_t *)ppiVar18 == 0x5c) || (*(int16_t *)ppiVar18 == 0x2f));
                var_188h._0_1_ = 1;
                if (ppiVar18 == ppiVar36) {
code_r0x000180042d68:
                    ppiVar19 = (int64_t **)CONCAT62(var_120h._2_6_, (undefined2)var_120h);
                    goto code_r0x000180043092;
                }
                unaff_R12 = (int64_t **)CONCAT62(var_120h._2_6_, (undefined2)var_120h);
            }
            do {
                uVar29 = 0;
                if ((*(int16_t *)ppiVar18 == 0x5c) || (arg2 = (int64_t)ppiVar18, *(int16_t *)ppiVar18 == 0x2f)) {
                    if (((int64_t **)var_128h == unaff_R12) || (ppiVar19 = unaff_R12, unaff_R12[-1] != (int64_t *)0x0))
                    {
                        if (unaff_R12 == (int64_t **)var_118h) {
                            iVar22 = (int64_t)unaff_R12 - var_128h >> 4;
                            if (iVar22 == 0xfffffffffffffff) goto code_r0x000180043a06;
                            uVar40 = (int64_t)unaff_R12 - var_128h;
                            ppiVar19 = (int64_t **)(iVar22 + 1);
                            uVar30 = var_118h - var_128h >> 4;
                            uVar32 = uVar30 >> 1;
                            if (0xfffffffffffffff - uVar32 < uVar30) {
                                arg2 = (int64_t)(int64_t **)0xfffffffffffffff;
                            } else {
                                arg2 = (int64_t)(int64_t **)(uVar32 + uVar30);
                                if ((int64_t **)(uVar32 + uVar30) < ppiVar19) {
                                    arg2 = (int64_t)ppiVar19;
                                }
                            }
                            var_180h = arg2;
                            piVar39 = (int64_t *)func_0x000180047650(uVar32, &var_180h);
                            ppiVar36 = (int64_t **)(uVar40 & 0xfffffffffffffff0);
                            *(undefined8 *)((int64_t)ppiVar36 + (int64_t)piVar39) = 0;
                            *(undefined8 *)((int64_t)(ppiVar36 + 1) + (int64_t)piVar39) = 0;
                            if (unaff_R12 == (int64_t **)CONCAT62(var_120h._2_6_, (undefined2)var_120h)) {
                                iVar22 = (int64_t)(int64_t **)CONCAT62(var_120h._2_6_, (undefined2)var_120h) - var_128h;
                                piVar20 = piVar39;
                                ppiVar25 = (int64_t **)var_128h;
                            } else {
                                fcn.180498030(piVar39, var_128h, (int64_t)unaff_R12 - var_128h);
                                iVar22 = CONCAT62(var_120h._2_6_, (undefined2)var_120h) - (int64_t)unaff_R12;
                                piVar20 = (int64_t *)((int64_t)(piVar39 + 2) + (int64_t)ppiVar36);
                                ppiVar25 = unaff_R12;
                            }
                            fcn.180498030(piVar20, ppiVar25, iVar22);
                            if (var_128h != 0) {
                                uVar32 = var_118h - var_128h & 0xfffffffffffffff0;
                                iVar22 = var_128h;
                                if (0xfff < uVar32) {
                                    iVar22 = *(int64_t *)(var_128h + -8);
                                    if (0x1f < (var_128h - iVar22) - 8U) goto code_r0x0001800430e9;
                                    uVar32 = uVar32 + 0x27;
                                }
                                func_0x000180459c3c(iVar22, uVar32);
                            }
                            var_128h = (int64_t)piVar39;
                            ppiVar19 = (int64_t **)(piVar39 + (int64_t)ppiVar19 * 2);
                            var_118h = (int64_t)(piVar39 + arg2 * 2);
                            ppiVar36 = (int64_t **)var_178h;
                        } else {
                            *unaff_R12 = (int64_t *)0x0;
                            unaff_R12[1] = (int64_t *)0x0;
                            ppiVar19 = (int64_t **)(CONCAT62(var_120h._2_6_, (undefined2)var_120h) + 0x10);
                        }
                        var_120h._0_2_ = SUB82(ppiVar19, 0);
                        var_120h._2_6_ = (unkbyte6)((uint64_t)ppiVar19 >> 0x10);
                    }
                    arg2 = (int64_t)ppiVar18 + 2;
                } else {
                    do {
                        arg2 = arg2 + 2;
                        if (((int64_t **)arg2 == ppiVar36) || (*(int16_t *)arg2 == 0x5c)) break;
                    } while (*(int16_t *)arg2 != 0x2f);
                    ppiVar19 = (int64_t **)(arg2 - (int64_t)ppiVar18 >> 1);
                    if (unaff_R12 == (int64_t **)var_118h) {
                        iVar22 = (int64_t)unaff_R12 - var_128h >> 4;
                        var_180h = (int64_t)unaff_R12;
                        if (iVar22 == 0xfffffffffffffff) {
code_r0x000180043a06:
                            func_0x000180010010();
                            pcVar7 = (code *)swi(3);
                            (*pcVar7)();
                            return;
                        }
                        uVar29 = var_118h - var_128h >> 4;
                        puVar34 = auStack_1b8;
                        if (0xfffffffffffffff - (uVar29 >> 1) < uVar29) goto code_r0x000180043a00;
                        uVar30 = iVar22 + 1;
                        uVar29 = (uVar29 >> 1) + uVar29;
                        uVar32 = uVar30;
                        if (uVar30 <= uVar29) {
                            uVar32 = uVar29;
                        }
                        puVar34 = auStack_1b8;
                        if (0xfffffffffffffff < uVar32) goto code_r0x000180043a00;
                        uVar29 = (int64_t)unaff_R12 - var_128h;
                        piVar39 = (int64_t *)(uVar32 * 0x10);
                        if (piVar39 == (int64_t *)0x0) {
                            ppiVar36 = (int64_t **)0x0;
                        } else if (piVar39 < (int64_t *)0x1000) {
                            ppiVar36 = (int64_t **)fcn.180459890(piVar39);
                        } else {
                            puVar34 = auStack_1b8;
                            if ((int64_t *)((int64_t)piVar39 + 0x27U) <= piVar39) goto code_r0x000180043a00;
                            piVar20 = (int64_t *)fcn.180459890();
                            unaff_R12 = ppiVar19;
                            if (piVar20 == (int64_t *)0x0) goto code_r0x0001800430e9;
                            ppiVar36 = (int64_t **)((int64_t)piVar20 + 0x27U & 0xffffffffffffffe0);
                            ppiVar36[-1] = piVar20;
                        }
                        uVar29 = uVar29 & 0xfffffffffffffff0;
                        *(int64_t ***)((int64_t)ppiVar36 + uVar29) = ppiVar18;
                        *(int64_t ***)((int64_t)ppiVar36 + uVar29 + 8) = ppiVar19;
                        iVar22 = CONCAT62(var_120h._2_6_, (undefined2)var_120h);
                        ppiVar25 = ppiVar36;
                        iVar28 = var_128h;
                        if (var_180h != iVar22) {
                            fcn.180498030(ppiVar36, var_128h, var_180h - var_128h);
                            iVar22 = CONCAT62(var_120h._2_6_, (undefined2)var_120h);
                            ppiVar25 = (int64_t **)(uVar29 + 0x10 + (int64_t)ppiVar36);
                            iVar28 = var_180h;
                        }
                        fcn.180498030(ppiVar25, iVar28, iVar22 - iVar28);
                        if (var_128h != 0) {
                            uVar32 = var_118h - var_128h & 0xfffffffffffffff0;
                            iVar22 = var_128h;
                            if (0xfff < uVar32) {
                                iVar22 = *(int64_t *)(var_128h + -8);
                                unaff_R12 = ppiVar19;
                                if (0x1f < (var_128h - iVar22) - 8U) goto code_r0x0001800430e9;
                                uVar32 = uVar32 + 0x27;
                            }
                            func_0x000180459c3c(iVar22, uVar32);
                        }
                        var_128h = (int64_t)ppiVar36;
                        ppiVar19 = ppiVar36 + uVar30 * 2;
                        var_118h = (int64_t)piVar39 + (int64_t)ppiVar36;
                        var_120h._0_2_ = SUB82(ppiVar19, 0);
                        var_120h._2_6_ = (unkbyte6)((uint64_t)ppiVar19 >> 0x10);
                        ppiVar36 = (int64_t **)var_178h;
                    } else {
                        *unaff_R12 = (int64_t *)ppiVar18;
                        unaff_R12[1] = (int64_t *)ppiVar19;
                        ppiVar19 = (int64_t **)(CONCAT62(var_120h._2_6_, (undefined2)var_120h) + 0x10);
                        var_120h._0_2_ = SUB82(ppiVar19, 0);
                        var_120h._2_6_ = (unkbyte6)((uint64_t)ppiVar19 >> 0x10);
                    }
                }
                ppiVar18 = (int64_t **)arg2;
                unaff_R12 = ppiVar19;
            } while ((int64_t **)arg2 != ppiVar36);
            unaff_R12 = (int64_t **)(uint64_t)(uint8_t)var_188h;
        }
code_r0x000180043092:
        uVar29 = 0;
        ppiVar25 = (int64_t **)var_128h;
        arg2 = var_128h;
        puVar34 = auStack_1b8;
        if ((int64_t **)var_128h != ppiVar19) {
            do {
                ppiVar18 = ppiVar25 + 2;
                piVar39 = *ppiVar25;
                ppiVar36 = (int64_t **)ppiVar25[1];
                if (ppiVar36 == (int64_t **)0x1) {
                    *(undefined8 *)(puVar33 + -8) = 0x1800430d3;
                    iVar17 = func_0x000180005b70(piVar39, 0x1806230ec, 1);
                    if (iVar17 != 0) goto code_r0x000180043152;
                    ppiVar19 = (int64_t **)CONCAT62(var_120h._2_6_, (undefined2)var_120h);
                    if (ppiVar18 == ppiVar19) break;
                } else {
code_r0x0001800430f0:
                    if (ppiVar36 == (int64_t **)0x2) {
                        *(undefined8 *)(puVar33 + -8) = 0x18004310b;
                        iVar17 = func_0x000180005b70(piVar39, 0x1806230e4, 2);
                        if (iVar17 != 0) goto code_r0x000180043152;
                        if (arg2 != var_128h) {
                            if (*(int64_t **)(arg2 + -0x18) == (int64_t *)0x2) {
                                piVar20 = *(int64_t **)(arg2 + -0x20);
                                *(undefined8 *)(puVar33 + -8) = 0x18004312a;
                                iVar17 = func_0x000180005b70(piVar20, 0x1806230e4);
                                if (iVar17 == 0) goto code_r0x00018004313d;
                            }
                            arg2 = arg2 + -0x20;
code_r0x000180043132:
                            ppiVar19 = (int64_t **)CONCAT62(var_120h._2_6_, (undefined2)var_120h);
                            if (ppiVar18 != ppiVar19) goto code_r0x00018004316d;
                            break;
                        }
code_r0x00018004313d:
                        if ((char)unaff_R12 != '\0') goto code_r0x000180043132;
                        *(int64_t **)arg2 = (int64_t *)0x1806230e4;
                        *(int64_t **)(arg2 + 8) = (int64_t *)0x2;
                        ppiVar25 = (int64_t **)arg2;
                    } else {
code_r0x000180043152:
                        *(int64_t **)arg2 = piVar39;
                        *(int64_t ***)(arg2 + 8) = ppiVar36;
                        ppiVar25 = (int64_t **)arg2;
                    }
                    arg2 = (int64_t)(ppiVar25 + 2);
                    ppiVar19 = (int64_t **)CONCAT62(var_120h._2_6_, (undefined2)var_120h);
                    if (ppiVar18 == ppiVar19) break;
                    arg2 = (int64_t)(ppiVar25 + 4);
                }
code_r0x00018004316d:
                ppiVar25 = ppiVar18 + 2;
            } while (ppiVar18 + 2 != ppiVar19);
            puVar34 = puVar33;
            if ((int64_t **)arg2 != ppiVar19) {
                var_120h._0_2_ = (undefined2)arg2;
                var_120h._2_6_ = (unkbyte6)((uint64_t)arg2 >> 0x10);
                ppiVar19 = (int64_t **)arg2;
            }
        }
        uVar32 = (int64_t)ppiVar19 - var_128h >> 4;
        if (((1 < uVar32) && (ppiVar19[-1] == (int64_t *)0x0)) && (ppiVar19[-3] == (int64_t *)0x2)) {
            piVar20 = ppiVar19[-4];
            *(undefined8 *)(puVar34 + -8) = 0x1800431c6;
            iVar17 = func_0x000180005b70(piVar20, 0x1806230e4);
            ppiVar19 = (int64_t **)CONCAT62(var_120h._2_6_, (undefined2)var_120h);
            if (iVar17 == 0) {
                ppiVar19 = ppiVar19 + -2;
                var_120h._0_2_ = SUB82(ppiVar19, 0);
                var_120h._2_6_ = (unkbyte6)((uint64_t)ppiVar19 >> 0x10);
            }
        }
        if ((int64_t **)var_128h != ppiVar19) {
            uVar1 = puVar34[0x30];
            uVar32 = (uint64_t)uVar1;
            uVar2 = puVar34[0x30];
            ppiVar18 = (int64_t **)(uint64_t)uVar2;
            ppiVar25 = (int64_t **)var_128h;
            do {
                piVar20 = ppiVar25[1];
                if (piVar20 == (int64_t *)0x0) {
                    if ((uint64_t)var_e8h < (uint64_t)var_e0h) {
                        piVar20 = &var_f8h;
                        if (7 < (uint64_t)var_e0h) {
                            piVar20 = (int64_t *)var_f8h;
                        }
                        iVar22 = var_e8h * 2;
                        var_e8h = var_e8h + 1;
                        *(undefined4 *)((int64_t)piVar20 + iVar22) = 0x5c;
                    } else {
                        *(undefined8 *)(puVar34 + -8) = 0x180043239;
                        func_0x00018000d650(&var_f8h, 1, uVar1, 0x5c);
                    }
                } else {
                    piVar39 = *ppiVar25;
                    if ((int64_t *)(var_e0h - var_e8h) < piVar20) {
                        *(int64_t **)(puVar34 + 0x20) = piVar20;
                        *(undefined8 *)(puVar34 + -8) = 0x18004328c;
                        func_0x00018000e1f0(&var_f8h, piVar20, uVar2);
                    } else {
                        iVar22 = (int64_t)piVar20 + var_e8h;
                        ppiVar36 = (int64_t **)&var_f8h;
                        if (7 < (uint64_t)var_e0h) {
                            ppiVar36 = (int64_t **)var_f8h;
                        }
                        iVar28 = var_e8h * 2;
                        *(undefined8 *)(puVar34 + -8) = 0x180043273;
                        var_e8h = iVar22;
                        fcn.180498030((int64_t)ppiVar36 + iVar28, piVar39, (int64_t)piVar20 * 2);
                        *(int16_t *)((int64_t)ppiVar36 + iVar22 * 2) = (int16_t)uVar29;
                    }
                }
                ppiVar25 = ppiVar25 + 2;
            } while (ppiVar25 != ppiVar19);
        }
        if (var_e8h == 0) {
            *(undefined8 *)(puVar34 + -8) = 0x1800432b6;
            func_0x00018000d7e0(&var_f8h, 0x1806230ec, 1);
        }
        _var_88h = _var_f8h;
        var_78h = var_e8h;
        var_70h = var_e0h;
        var_e0h = 7;
        var_f8h._0_2_ = (int16_t)uVar29;
        var_e8h = uVar29;
        if (var_128h != 0) {
            uVar30 = var_118h - var_128h & 0xfffffffffffffff0;
            iVar22 = var_128h;
            if (0xfff < uVar30) {
                iVar22 = *(int64_t *)(var_128h + -8);
                if (0x1f < (var_128h - iVar22) - 8U) {
                    pcVar7 = (code *)swi(0x29);
                    (*pcVar7)(5);
                    puVar34 = puVar34 + 8;
                    goto code_r0x0001800434b8;
                }
                uVar30 = uVar30 + 0x27;
            }
            *(undefined8 *)(puVar34 + -8) = 0x180043316;
            func_0x000180459c3c(iVar22, uVar30);
            var_128h = 0;
            var_120h._0_2_ = 0;
            var_120h._2_6_ = 0;
            var_118h = uVar29;
        }
        if (7 < (uint64_t)var_e0h) {
            uVar30 = var_e0h * 2 + 2;
            iVar22 = var_f8h;
            if (0xfff < uVar30) {
                iVar22 = *(int64_t *)(var_f8h + -8);
                if (0x1f < (var_f8h - iVar22) - 8U) {
code_r0x0001800434b8:
                    puVar26 = (undefined *)0x5;
                    pcVar7 = (code *)swi(0x29);
                    (*pcVar7)();
                    puVar35 = puVar34 + 8;
                    goto code_r0x0001800434bf;
                }
                uVar30 = var_e0h * 2 + 0x29;
            }
            *(undefined8 *)(puVar34 + -8) = 0x180043362;
            func_0x000180459c3c(iVar22, uVar30);
        }
    }
    piVar20 = &var_88h;
    if (7 < (uint64_t)var_70h) {
        piVar20 = (int64_t *)var_88h;
    }
    piVar23 = (int16_t *)((int64_t)piVar20 + var_78h * 2);
    *(undefined8 *)(puVar34 + -8) = 0x180043381;
    for (piVar21 = (int16_t *)func_0x000180006c10(piVar20);
        (piVar21 != piVar23 && ((*piVar21 == 0x5c || (*piVar21 == 0x2f)))); piVar21 = piVar21 + 1) {
    }
    *(undefined (*) [16])(puVar34 + 0x70) = ZEXT816(0);
    *(undefined8 *)(puVar34 + -8) = 0x1800433c4;
    var_138h = uVar29;
    var_130h = uVar29;
    func_0x00018000d380(puVar34 + 0x70, piVar20, (int64_t)piVar21 - (int64_t)piVar20 >> 1);
    piVar20 = &var_88h;
    if (7 < (uint64_t)var_70h) {
        piVar20 = (int64_t *)var_88h;
    }
    piVar23 = (int16_t *)((int64_t)piVar20 + var_78h * 2);
    *(undefined8 *)(puVar34 + -8) = 0x1800433e0;
    for (piVar21 = (int16_t *)func_0x000180006c10(); (piVar21 != piVar23 && ((*piVar21 == 0x5c || (*piVar21 == 0x2f))));
        piVar21 = piVar21 + 1) {
    }
    _var_68h = ZEXT816(0);
    *(undefined8 *)(puVar34 + -8) = 0x180043421;
    var_58h = uVar29;
    var_50h = uVar29;
    func_0x00018000d380(&var_68h, piVar21, (int64_t)piVar23 - (int64_t)piVar21 >> 1);
    puVar34[0x30] = 1;
    *(undefined8 *)(puVar34 + -8) = 0x180043434;
    fcn.180041eb0((int64_t)&var_68h, (int64_t)&var_d8h);
    piVar20 = &var_68h;
    if (7 < (uint64_t)var_50h) {
        piVar20 = (int64_t *)var_68h;
    }
    uVar32 = (int64_t)piVar20 + var_58h * 2;
    var_128h = uVar32;
    var_120h._2_6_ = SUB166(ZEXT816(0), 2);
    var_120h._2_6_ = 0;
    var_118h = 0;
    var_108h = 7;
    var_120h._0_2_ = (int16_t)uVar29;
    var_100h = (int64_t)&var_68h;
    puVar35 = puVar34;
    var_110h = uVar29;
    if (var_d8h != uVar32) {
        ppiVar18 = (int64_t **)(uint64_t)(uint8_t)puVar34[0x30];
        ppiVar36 = (int64_t **)(uint64_t)(uint8_t)puVar34[0x30];
code_r0x000180043483:
        *(undefined8 *)(puVar35 + -8) = 0x18004348c;
        cVar15 = func_0x0001800072b0(&var_d0h);
        puVar26 = puVar35 + 0x70;
        if (cVar15 == '\0') {
code_r0x0001800434bf:
            uVar29 = var_130h;
            if (7 < (uint64_t)var_130h) {
                puVar26 = *(undefined **)(puVar35 + 0x70);
            }
            *(undefined **)(puVar35 + 0x38) = puVar26;
            *(undefined **)(puVar35 + 0x48) = puVar26 + var_138h * 2;
            piVar20 = &var_d0h;
            if (7 < uStack_b8) {
                piVar20 = (int64_t *)var_d0h;
            }
            *(int64_t **)(puVar35 + 0x40) = piVar20;
            piVar21 = (int16_t *)(var_c0h * 2 + (int64_t)piVar20);
            *(undefined8 *)(puVar35 + -8) = 0x180043506;
            uVar30 = var_138h;
            iVar22 = func_0x000180006c10();
            *(undefined8 *)(puVar35 + -8) = 0x180043514;
            piVar23 = (int16_t *)func_0x000180006c10(piVar20, piVar21);
            if (*(int16_t **)(puVar35 + 0x40) == piVar23) {
code_r0x00018004355e:
                if ((piVar23 == piVar21) || ((*piVar23 != 0x5c && (*piVar23 != 0x2f)))) {
                    if (iVar22 == *(int64_t *)(puVar35 + 0x48)) {
                        if (5 < (int64_t)(iVar22 - *(int64_t *)(puVar35 + 0x38) & 0xfffffffffffffffeU)) {
                            ppiVar19 = ppiVar18;
                            if (uVar29 <= uVar30) goto code_r0x000180043604;
code_r0x0001800435e4:
                            var_138h = uVar30 + 1;
                            puVar27 = (undefined8 *)(puVar35 + 0x70);
                            if (7 < uVar29) {
                                puVar27 = (undefined8 *)*puVar27;
                            }
                            *(undefined4 *)((int64_t)puVar27 + uVar30 * 2) = 0x5c;
                        }
                    } else {
                        iVar3 = *(int16_t *)(*(int64_t *)(puVar35 + 0x48) + -2);
                        if ((iVar3 != 0x5c) && (iVar3 != 0x2f)) {
                            ppiVar19 = ppiVar36;
                            if (uVar30 < uVar29) goto code_r0x0001800435e4;
code_r0x000180043604:
                            *(undefined8 *)(puVar35 + -8) = 0x180043614;
                            func_0x00018000d650(puVar35 + 0x70, 1, (uint64_t)ppiVar19 & 0xff, 0x5c);
                        }
                    }
                } else {
                    uVar40 = iVar22 - *(int64_t *)(puVar35 + 0x38) >> 1;
                    if (uVar30 < uVar40) goto code_r0x0001800439fa;
                    var_138h = uVar40;
                    puVar34 = puVar35 + 0x70;
                    if (7 < uVar29) {
                        puVar34 = *(undefined **)(puVar35 + 0x70);
                    }
                    *(undefined2 *)(puVar34 + uVar40 * 2) = 0;
                }
                *(undefined8 *)(puVar35 + -8) = 0x18004362a;
                func_0x00018000d4b0(puVar35 + 0x70, piVar23, (int64_t)piVar21 - (int64_t)piVar23 >> 1);
            } else {
                *(undefined8 *)(puVar35 + -8) = 0x180043531;
                iVar17 = func_0x000180006d10(*(undefined8 *)(puVar35 + 0x38), iVar22, *(int16_t **)(puVar35 + 0x40), 
                                             piVar23);
                uVar30 = var_138h;
                uVar29 = var_130h;
                if (iVar17 == 0) goto code_r0x00018004355e;
                piVar20 = &var_d0h;
                if (7 < uStack_b8) {
                    piVar20 = (int64_t *)var_d0h;
                }
                *(undefined8 *)(puVar35 + -8) = 0x180043551;
                func_0x00018000d7e0(puVar35 + 0x70, piVar20, var_c0h);
            }
            uVar29 = 0;
        } else {
            piVar20 = &var_d0h;
            if (7 < uStack_b8) {
                piVar20 = (int64_t *)var_d0h;
            }
            *(undefined8 *)(puVar35 + -8) = 0x1800434ac;
            func_0x00018000d7e0(puVar26, piVar20, var_c0h);
        }
        uVar38 = (undefined2)uVar29;
        if (puVar35[0x30] != '\0') {
            piVar20 = &var_a8h;
            if (7 < (uint64_t)var_90h) {
                piVar20 = (int64_t *)var_a8h;
            }
            var_98h = uVar29;
            *(undefined2 *)piVar20 = uVar38;
            *(undefined8 *)(puVar35 + -8) = 0x18004365c;
            uVar16 = fcn.180042010((int64_t)&var_a8h, (int64_t)(puVar35 + 0x70));
            if (uVar16 == 0) {
                if (7 < (uint64_t)var_130h) {
                    uVar30 = var_130h * 2 + 2;
                    iVar22 = *(int64_t *)(puVar35 + 0x70);
                    iVar28 = iVar22;
                    if (0xfff < uVar30) {
                        iVar28 = *(int64_t *)(iVar22 + -8);
                        if (0x1f < (iVar22 - iVar28) - 8U) {
                            uVar16 = 5;
                            pcVar7 = (code *)swi(0x29);
                            (*pcVar7)();
                            puVar35 = puVar35 + 8;
code_r0x000180043917:
                            puVar5 = *(uint32_t **)(puVar35 + 0x60);
                            *puVar5 = uVar16;
                            puVar5[1] = *(uint32_t *)(puVar35 + 100);
                            *(undefined8 *)(puVar5 + 2) = 0x1806a45e0;
                            pauVar6 = *(undefined (**) [16])(puVar35 + 0x50);
                            pauVar6[1] = ZEXT816(0);
                            *pauVar6 = ZEXT816(0);
                            *(uint64_t *)pauVar6[1] = uVar29;
                            *(undefined8 *)(pauVar6[1] + 8) = 7;
                            *(undefined2 *)*pauVar6 = uVar38;
                            *(undefined8 *)(puVar35 + -8) = 0x180043958;
                            func_0x00018000dc80(&var_d0h);
                            if (7 < (uint64_t)var_50h) {
                                *(undefined8 *)(puVar35 + -8) = 0x180043970;
                                func_0x00018000f950(&var_68h, var_68h);
                            }
                            var_58h = uVar29;
                            var_50h = 7;
                            var_68h._0_2_ = uVar38;
                            if (7 < (uint64_t)var_130h) {
                                *(undefined8 *)(puVar35 + -8) = 0x18004399a;
                                func_0x00018000f950(puVar35 + 0x70, *(undefined8 *)(puVar35 + 0x70));
                            }
                            var_130h = 7;
                            var_138h = uVar29;
                            *(undefined2 *)(puVar35 + 0x70) = uVar38;
                            if (7 < (uint64_t)var_70h) {
                                *(undefined8 *)(puVar35 + -8) = 0x1800439c3;
                                func_0x00018000f950(&var_88h, var_88h);
                            }
                            var_70h = 7;
                            var_88h._0_2_ = uVar38;
                            var_78h = uVar29;
                            goto code_r0x0001800439d4;
                        }
                        uVar30 = var_130h * 2 + 0x29;
                    }
                    *(undefined8 *)(puVar35 + -8) = 0x1800436a3;
                    func_0x000180459c3c(iVar28, uVar30);
                }
                *(undefined4 *)(puVar35 + 0x70) = (undefined4)var_a8h;
                *(undefined4 *)(puVar35 + 0x74) = var_a8h._4_4_;
                *(undefined4 *)(puVar35 + 0x78) = uStack_a0;
                *(undefined4 *)(puVar35 + 0x7c) = uStack_9c;
                var_138h = var_98h;
                var_130h = var_90h;
                var_90h = 7;
                var_a8h._0_2_ = uVar38;
                var_98h = uVar29;
            } else {
                if (uVar16 < 0x41) {
                    if (((uVar16 != 0x40) && (uVar16 != 2)) && (uVar16 != 3)) {
                        bVar42 = uVar16 == 0x35;
code_r0x0001800436ea:
                        if (!bVar42) goto code_r0x000180043917;
                    }
                } else if ((uVar16 != 0x7b) && (uVar16 != 0xa1)) {
                    bVar42 = uVar16 == 0x10b;
                    goto code_r0x0001800436ea;
                }
                puVar35[0x30] = 0;
            }
        }
        iVar22 = var_b0h;
        if (7 < *(uint64_t *)(var_b0h + 0x18)) {
            iVar22 = *(int64_t *)var_b0h;
        }
        piVar23 = (int16_t *)(iVar22 + *(int64_t *)(var_b0h + 0x10) * 2);
        if (iVar22 == var_d8h) {
            piVar21 = (int16_t *)(var_d8h + var_c0h * 2);
            piVar41 = (int16_t *)var_b0h;
            if (7 < *(uint64_t *)(var_b0h + 0x18)) {
                piVar41 = *(int16_t **)var_b0h;
            }
            piVar31 = piVar41 + *(int64_t *)(var_b0h + 0x10);
            *(undefined8 *)(puVar35 + -8) = 0x180043740;
            var_d8h = (int64_t)piVar21;
            piVar24 = (int16_t *)func_0x000180006c10(piVar41);
            for (piVar37 = piVar24; (piVar37 != piVar31 && ((*piVar37 == 0x5c || (*piVar37 == 0x2f))));
                piVar37 = piVar37 + 1) {
            }
            piVar31 = (int16_t *)var_d8h;
            if ((piVar41 == piVar24) || (piVar24 == piVar37)) goto joined_r0x0001800437b0;
            *(undefined8 *)(puVar35 + -8) = 0x180043785;
            func_0x00018000d7e0(&var_d0h, piVar24, (int64_t)piVar37 - (int64_t)piVar24 >> 1);
        } else if (((*(int16_t *)var_d8h == 0x5c) || (*(int16_t *)var_d8h == 0x2f)) && (var_c0h == 0)) {
            var_d8h = var_d8h + 2;
        } else {
            var_d8h = var_d8h + var_c0h * 2;
            piVar21 = (int16_t *)var_d8h;
            piVar31 = (int16_t *)var_d8h;
joined_r0x0001800437b0:
            while (piVar41 = piVar21, piVar41 != piVar23) {
                if ((*piVar41 != 0x5c) && (piVar21 = piVar41, *piVar41 != 0x2f)) goto joined_r0x0001800438d8;
                var_d8h = (int64_t)(piVar41 + 1);
                piVar31 = piVar41;
                piVar21 = (int16_t *)var_d8h;
            }
            piVar20 = &var_d0h;
            if (7 < uStack_b8) {
                piVar20 = (int64_t *)var_d0h;
            }
            var_c0h = uVar29;
            *(undefined2 *)piVar20 = uVar38;
            var_d8h = (int64_t)piVar31;
        }
        goto code_r0x0001800437f5;
    }
code_r0x0001800437fe:
    *(undefined8 *)(puVar35 + -8) = 0x180043807;
    func_0x00018000dc80(&var_120h);
    *(undefined8 *)(puVar35 + -8) = 0x180043811;
    func_0x00018000dc80(&var_d0h);
    puVar4 = *(undefined4 **)(puVar35 + 0x50);
    uVar8 = *(undefined4 *)(puVar35 + 0x74);
    uVar9 = *(undefined4 *)(puVar35 + 0x78);
    uVar10 = *(undefined4 *)(puVar35 + 0x7c);
    *puVar4 = *(undefined4 *)(puVar35 + 0x70);
    puVar4[1] = uVar8;
    puVar4[2] = uVar9;
    puVar4[3] = uVar10;
    puVar4[4] = (undefined4)var_138h;
    puVar4[5] = var_138h._4_4_;
    puVar4[6] = (undefined4)var_130h;
    puVar4[7] = var_130h._4_4_;
    var_130h = 7;
    var_138h = uVar29;
    *(int16_t *)(puVar35 + 0x70) = (int16_t)uVar29;
    *(undefined8 *)(puVar35 + -8) = 0x180043841;
    func_0x00018000dc80(&var_68h);
    if (7 < (uint64_t)var_130h) {
        uVar32 = var_130h * 2 + 2;
        iVar22 = *(int64_t *)(puVar35 + 0x70);
        iVar28 = iVar22;
        if (0xfff < uVar32) {
            iVar28 = *(int64_t *)(iVar22 + -8);
            if (0x1f < (iVar22 - iVar28) - 8U) {
                pcVar7 = (code *)swi(0x29);
                (*pcVar7)(5);
                puVar35 = puVar35 + 8;
code_r0x0001800439fa:
                *(undefined8 *)(puVar35 + -8) = 0x1800439ff;
                func_0x00018000f930();
                puVar34 = puVar35;
code_r0x000180043a00:
                *(undefined8 *)(puVar34 + -8) = 0x180043a05;
                fcn.180004720();
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            uVar32 = var_130h * 2 + 0x29;
        }
        *(undefined8 *)(puVar35 + -8) = 0x180043883;
        func_0x000180459c3c(iVar28, uVar32);
    }
    var_130h = 7;
    var_138h = uVar29;
    *(int16_t *)(puVar35 + 0x70) = (int16_t)uVar29;
    *(undefined8 *)(puVar35 + -8) = 0x18004389e;
    func_0x00018000dc80(&var_88h);
    *(undefined8 *)(puVar35 + -8) = 0x1800438a8;
    func_0x00018000dc80(&var_a8h);
code_r0x0001800438ab:
    *(undefined8 *)(puVar35 + -8) = 0x1800438b7;
    func_0x000180459870(var_48h ^ (uint64_t)puVar35);
    return;
joined_r0x0001800438d8:
    for (; ((piVar21 != piVar23 && (*piVar21 != 0x5c)) && (*piVar21 != 0x2f)); piVar21 = piVar21 + 1) {
    }
    *(undefined8 *)(puVar35 + -8) = 0x18004390b;
    func_0x00018000d7e0(&var_d0h, piVar41, (int64_t)piVar21 - (int64_t)piVar41 >> 1);
code_r0x0001800437f5:
    if (var_d8h == uVar32) goto code_r0x0001800437fe;
    goto code_r0x000180043483;
}

// ============================================================
// Function: FUN_180043a10
// Address: 0x180043a10
// Size: 369 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180043a10(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined *puVar6;
    undefined in_R8B;
    int64_t var_18h;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar6 = auStack_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    var_58h._0_4_ = 0;
    piVar5 = *(int64_t **)(arg2 + 0x28);
    if (*(int64_t **)(arg2 + 0x40) <= *(int64_t **)(arg2 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    var_50h = arg1;
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
            *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
            *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
        }
        iVar2 = func_0x0001800a8360(arg2);
        if (iVar2 == 0) goto code_r0x000180043b6d;
        if (*(uint64_t *)(*(int64_t *)(arg2 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg2 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg2, 1);
        }
        piVar5 = *(int64_t **)(arg2 + 0x28);
        if (*(int64_t **)(arg2 + 0x40) <= *(int64_t **)(arg2 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar5 != -0x18) {
        func_0x0001800814c0();
        func_0x0001800818b0();
        puVar3 = (undefined8 *)func_0x0001800814c0();
        func_0x000180081a20(*puVar3, arg1, &var_48h, in_R8B);
        var_58h._0_4_ = 1;
        if (*(int64_t *)(arg1 + 0x10) != 0) {
            if (0xf < (uint64_t)var_30h) {
                iVar4 = var_48h;
                puVar6 = auStack_78;
                if ((0xfff < var_30h + 1U) &&
                   (iVar4 = *(int64_t *)(var_48h + -8), puVar6 = auStack_78, 0x1f < (var_48h - iVar4) - 8U)) {
                    pcVar1 = (code *)swi(0x29);
                    iVar4 = (*pcVar1)(5);
                    puVar6 = auStack_70;
                }
                *(undefined8 *)(puVar6 + -8) = 0x180043b38;
                func_0x000180459c3c(iVar4);
            }
            *(undefined8 *)(puVar6 + -8) = 0x180043b48;
            func_0x000180459870(*(uint64_t *)(puVar6 + 0x50) ^ (uint64_t)puVar6);
            return;
        }
        func_0x000180088380(arg2, 1, 0x180623150);
    }
code_r0x000180043b6d:
    func_0x000180088470(arg2, 1, 6);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180043ba0
// Address: 0x180043ba0
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180043ba0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t unaff_RDI;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.180043a10(arg1, arg2, unaff_RDI);
    fcn.1800814c0();
    iVar2 = fcn.180081ec0();
    if ((iVar2 - 2U & 0xfffffffd) == 0) {
        return arg1;
    }
    fcn.180088380(arg2, 1, 0x180623130, in_R9, 1);
    pcVar1 = (code *)swi(3);
    iVar3 = (*pcVar1)();
    return iVar3;
}

// ============================================================
// Function: FUN_180043c10
// Address: 0x180043c10
// Size: 303 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180043c10(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    char cVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStackY_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    fcn.180043a10((int64_t)&var_38h, arg1, var_38h);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x000180043d2b;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 != 0) {
        uVar2 = *(uint32_t *)(*piVar6 + 0x14);
        fcn.1800814c0();
        var_48h = iVar1;
        var_40h = (uint64_t)uVar2;
        cVar4 = func_0x000180082240();
        if (cVar4 != '\0') {
            fcn.18000dc80(&var_38h);
            fcn.180459870(uStack_18 ^ (uint64_t)auStackY_68);
            return;
        }
        fcn.180088380(arg1, 1, 0x180623130);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
code_r0x000180043d2b:
    func_0x000180088470(arg1, 2, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180043d40
// Address: 0x180043d40
// Size: 303 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180043d40(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    char cVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStackY_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_68;
    fcn.180043a10((int64_t)&var_38h, arg1, var_38h);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x000180043e5b;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 != 0) {
        uVar2 = *(uint32_t *)(*piVar6 + 0x14);
        fcn.1800814c0();
        var_48h = iVar1;
        var_40h = (uint64_t)uVar2;
        cVar4 = func_0x000180082240();
        if (cVar4 != '\0') {
            fcn.18000dc80(&var_38h);
            fcn.180459870(uStack_18 ^ (uint64_t)auStackY_68);
            return;
        }
        fcn.180088380(arg1, 1, 0x180623130);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
code_r0x000180043e5b:
    func_0x000180088470(arg1, 2, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180043e70
// Address: 0x180043e70
// Size: 189 bytes
// ============================================================
void fcn.180043e70(int64_t arg1)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    undefined auStack_78 [40];
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    fcn.180043ba0((int64_t)&var_30h, arg1);
    fcn.1800814c0();
    fcn.180081f50();
    piVar3 = &var_50h;
    if (0xf < (uint64_t)var_38h) {
        piVar3 = (int64_t *)var_50h;
    }
    fcn.1800867f0(arg1, piVar3, var_40h);
    if (0xf < (uint64_t)var_38h) {
        uVar4 = var_38h + 1;
        iVar2 = var_50h;
        if (0xfff < uVar4) {
            iVar2 = *(int64_t *)(var_50h + -8);
            if (0x1f < (var_50h - iVar2) - 8U) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            uVar4 = var_38h + 0x28;
        }
        fcn.180459c3c(iVar2, uVar4);
    }
    fcn.18000dc80(&var_30h);
    fcn.180459870(var_10h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_180043f30
// Address: 0x180043f30
// Size: 610 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.180043f30(int64_t arg1, int64_t arg_68h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    undefined *puVar8;
    int64_t var_10h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_20h;
    int64_t var_18h;
    
    puVar8 = auStack_98;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018004417e;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar6 == -0x18) {
code_r0x00018004417e:
        func_0x000180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    fcn.1800814c0();
    func_0x0001800818b0();
    puVar4 = (undefined8 *)fcn.1800814c0();
    func_0x000180081a20(*puVar4, &var_78h, &var_38h, 0);
    if (var_68h != 0) {
        fcn.1800814c0();
        piVar6 = &var_78h;
        if (7 < (uint64_t)var_60h) {
            piVar6 = (int64_t *)var_78h;
        }
        iVar2 = func_0x000180455104(piVar6, &var_58h, 6, 0xffffffff);
        if (iVar2 == 0) {
            iVar2 = 4;
            if (((uint32_t)var_48h >> 10 & 1) == 0) {
code_r0x00018004406a:
                iVar3 = ((uint32_t)var_48h >> 4 & 1) + 2;
            } else if (var_48h._4_4_ == -0x5ffffff4) {
                iVar3 = 4;
            } else {
                if (var_48h._4_4_ != -0x5ffffffd) goto code_r0x00018004406a;
                iVar3 = 10;
            }
            if (iVar3 == 4) {
                piVar6 = &var_78h;
                if (7 < (uint64_t)var_60h) {
                    piVar6 = (int64_t *)var_78h;
                }
                iVar3 = func_0x000180455104(piVar6, &var_58h, 3, 0xffffffff);
                if (iVar3 == 0) {
                    if (((uint32_t)var_48h >> 10 & 1) == 0) {
code_r0x0001800440ce:
                        iVar2 = ((uint32_t)var_48h >> 4 & 1) + 2;
                    } else if (var_48h._4_4_ != -0x5ffffff4) {
                        if (var_48h._4_4_ != -0x5ffffffd) goto code_r0x0001800440ce;
                        iVar2 = 10;
                    }
                    if (iVar2 != 3) goto code_r0x000180044142;
                }
            } else if ((iVar3 != 1) && (iVar3 == 2)) {
code_r0x000180044142:
                uVar7 = 1;
                goto code_r0x0001800440e0;
            }
        }
    }
    uVar7 = 0;
code_r0x0001800440e0:
    func_0x000180086b20(arg1, uVar7);
    fcn.18000dc80(&var_78h);
    if (0xf < (uint64_t)var_20h) {
        iVar5 = var_38h;
        puVar8 = auStack_98;
        if ((0xfff < var_20h + 1U) &&
           (iVar5 = *(int64_t *)(var_38h + -8), puVar8 = auStack_98, 0x1f < (var_38h - iVar5) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar5 = (*pcVar1)(5);
            puVar8 = auStack_90;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180044158;
        fcn.180459c3c(iVar5);
    }
    *(undefined8 *)(puVar8 + -8) = 0x18004416d;
    fcn.180459870(*(uint64_t *)(puVar8 + 0x80) ^ (uint64_t)puVar8);
    return;
}

// ============================================================
// Function: FUN_1800441a0
// Address: 0x1800441a0
// Size: 616 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.1800441a0(int64_t arg1, int64_t arg_68h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    undefined *puVar8;
    bool bVar9;
    int64_t var_10h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_20h;
    int64_t var_18h;
    
    puVar8 = auStack_98;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800443f4;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar6 == -0x18) {
code_r0x0001800443f4:
        func_0x000180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    fcn.1800814c0();
    func_0x0001800818b0();
    puVar4 = (undefined8 *)fcn.1800814c0();
    func_0x000180081a20(*puVar4, &var_78h, &var_38h, 0);
    if (var_68h != 0) {
        fcn.1800814c0();
        piVar6 = &var_78h;
        if (7 < (uint64_t)var_60h) {
            piVar6 = (int64_t *)var_78h;
        }
        iVar2 = func_0x000180455104(piVar6, &var_58h, 6, 0xffffffff);
        if (iVar2 == 0) {
            iVar2 = 4;
            if (((uint32_t)var_48h >> 10 & 1) == 0) {
code_r0x0001800442da:
                iVar3 = ((uint32_t)var_48h >> 4 & 1) + 2;
            } else if (var_48h._4_4_ == -0x5ffffff4) {
                iVar3 = 4;
            } else {
                if (var_48h._4_4_ != -0x5ffffffd) goto code_r0x0001800442da;
                iVar3 = 10;
            }
            if (iVar3 == 4) {
                piVar6 = &var_78h;
                if (7 < (uint64_t)var_60h) {
                    piVar6 = (int64_t *)var_78h;
                }
                iVar3 = func_0x000180455104(piVar6, &var_58h, 3, 0xffffffff);
                if (iVar3 != 0) goto code_r0x00018004435b;
                if (((uint32_t)var_48h >> 10 & 1) == 0) {
code_r0x000180044341:
                    iVar2 = ((uint32_t)var_48h >> 4 & 1) + 2;
                } else if (var_48h._4_4_ != -0x5ffffff4) {
                    if (var_48h._4_4_ == -0x5ffffffd) {
                        bVar9 = false;
                        goto code_r0x0001800443b6;
                    }
                    goto code_r0x000180044341;
                }
                bVar9 = iVar2 == 3;
            } else {
                if ((iVar3 == 1) || (iVar3 == 2)) goto code_r0x00018004435b;
                bVar9 = iVar3 == 3;
            }
code_r0x0001800443b6:
            if (bVar9) {
                uVar7 = 1;
                goto code_r0x00018004435d;
            }
        }
    }
code_r0x00018004435b:
    uVar7 = 0;
code_r0x00018004435d:
    func_0x000180086b20(arg1, uVar7);
    fcn.18000dc80(&var_78h);
    if (0xf < (uint64_t)var_20h) {
        iVar5 = var_38h;
        puVar8 = auStack_98;
        if ((0xfff < var_20h + 1U) &&
           (iVar5 = *(int64_t *)(var_38h + -8), puVar8 = auStack_98, 0x1f < (var_38h - iVar5) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar5 = (*pcVar1)(5);
            puVar8 = auStack_90;
        }
        *(undefined8 *)(puVar8 + -8) = 0x1800443ce;
        fcn.180459c3c(iVar5);
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800443e3;
    fcn.180459870(*(uint64_t *)(puVar8 + 0x80) ^ (uint64_t)puVar8);
    return;
}

// ============================================================
// Function: FUN_180044410
// Address: 0x180044410
// Size: 395 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180044410(int64_t arg1, int64_t arg_58h)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    int32_t extraout_var;
    char cVar4;
    int64_t *piVar5;
    uint32_t uVar6;
    int64_t var_10h;
    undefined auStackY_78 [32];
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb8;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_78;
    fcn.180043a10((int64_t)&var_58h, arg1, in_stack_ffffffffffffffb8);
    fcn.1800814c0();
    piVar5 = &var_58h;
    if (7 < (uint64_t)var_40h) {
        piVar5 = (int64_t *)var_58h;
    }
    iVar3 = func_0x000180455104(piVar5, &var_38h, 6, 0xffffffff);
    if (iVar3 != 0) goto code_r0x000180044526;
    uVar6 = 4;
    if (((uint32_t)var_28h >> 10 & 1) == 0) {
code_r0x0001800444a1:
        cVar2 = (((uint32_t)var_28h & 0x10) != 0) + '\x02';
        cVar4 = (((uint32_t)var_28h >> 4 & 1) != 0) + '\x02';
    } else if (var_28h._4_4_ == -0x5ffffff4) {
        cVar4 = '\x04';
        cVar2 = '\x04';
    } else {
        if (var_28h._4_4_ != -0x5ffffffd) goto code_r0x0001800444a1;
        cVar2 = '\n';
        cVar4 = '\n';
    }
    if (cVar2 == '\x04') {
        piVar5 = &var_58h;
        if (7 < (uint64_t)var_40h) {
            piVar5 = (int64_t *)var_58h;
        }
        iVar3 = func_0x000180455104(piVar5, &var_38h, 3, 0xffffffff);
        if (iVar3 != 0) goto code_r0x000180044526;
        if (((uint32_t)var_28h >> 10 & 1) == 0) {
code_r0x000180044516:
            uVar6 = ((uint32_t)var_28h & 0x10 | 0x20) >> 4;
        } else if (var_28h._4_4_ != -0x5ffffff4) {
            if (var_28h._4_4_ != -0x5ffffffd) goto code_r0x000180044516;
            uVar6 = 10;
        }
        if (uVar6 == 3) goto code_r0x000180044526;
    } else if ((cVar4 == '\x01') || (cVar4 != '\x02')) goto code_r0x000180044526;
    piVar5 = &var_58h;
    if (7 < (uint64_t)var_40h) {
        piVar5 = (int64_t *)var_58h;
    }
    func_0x0001804554a0(piVar5);
    if (extraout_var != 0) {
        fcn.180088380(arg1, 1, 0x180623180);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
code_r0x000180044526:
    fcn.18000dc80(&var_58h);
    fcn.180459870(var_18h ^ (uint64_t)auStackY_78);
    return;
}

// ============================================================
// Function: FUN_1800445a0
// Address: 0x1800445a0
// Size: 411 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800445a0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    uint32_t uVar6;
    bool bVar7;
    int64_t var_10h;
    undefined auStackY_78 [32];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_78;
    fcn.180043a10((int64_t)&var_38h, arg1, CONCAT44(var_48h._4_4_, (uint32_t)var_48h));
    fcn.1800814c0();
    piVar5 = &var_38h;
    if (7 < (uint64_t)var_20h) {
        piVar5 = (int64_t *)var_38h;
    }
    iVar3 = func_0x000180455104(piVar5, &var_58h, 6, 0xffffffff);
    if (iVar3 == 0) {
        uVar6 = 4;
        if (((uint32_t)var_48h >> 10 & 1) == 0) {
code_r0x000180044631:
            cVar2 = (((uint32_t)var_48h & 0x10) != 0) + '\x02';
            cVar4 = (((uint32_t)var_48h >> 4 & 1) != 0) + '\x02';
        } else if (var_48h._4_4_ == -0x5ffffff4) {
            cVar4 = '\x04';
            cVar2 = '\x04';
        } else {
            if (var_48h._4_4_ != -0x5ffffffd) goto code_r0x000180044631;
            cVar2 = '\n';
            cVar4 = '\n';
        }
        if (cVar2 == '\x04') {
            piVar5 = &var_38h;
            if (7 < (uint64_t)var_20h) {
                piVar5 = (int64_t *)var_38h;
            }
            iVar3 = func_0x000180455104(piVar5, &var_58h, 3, 0xffffffff);
            if (iVar3 != 0) goto code_r0x0001800446d5;
            if (((uint32_t)var_48h >> 10 & 1) == 0) {
code_r0x0001800446a5:
                uVar6 = ((uint32_t)var_48h & 0x10 | 0x20) >> 4;
            } else if (var_48h._4_4_ != -0x5ffffff4) {
                if (var_48h._4_4_ == -0x5ffffffd) {
                    bVar7 = false;
                    goto code_r0x0001800446d3;
                }
                goto code_r0x0001800446a5;
            }
            bVar7 = uVar6 == 3;
        } else {
            if ((cVar4 == '\x01') || (cVar4 == '\x02')) goto code_r0x0001800446d5;
            bVar7 = cVar4 == '\x03';
        }
code_r0x0001800446d3:
        if (bVar7) goto code_r0x0001800446ff;
    }
code_r0x0001800446d5:
    var_58h._0_4_ = 0;
    var_50h = 0x1806a45e0;
    fcn.180042510((int64_t)&var_38h, (int64_t)&var_58h);
    if ((int32_t)var_58h != 0) {
        fcn.180088380(arg1, 1, 0x180623160);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
code_r0x0001800446ff:
    fcn.18000dc80(&var_38h);
    fcn.180459870(var_18h ^ (uint64_t)auStackY_78);
    return;
}

// ============================================================
// Function: FUN_180044740
// Address: 0x180044740
// Size: 572 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180044740(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t extraout_var;
    uint64_t uVar5;
    char cVar6;
    int64_t *piVar7;
    undefined auStackY_a8 [32];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_a8;
    fcn.180043a10((int64_t)&var_70h, arg1, var_78h);
    fcn.1800814c0();
    piVar7 = &var_70h;
    if (7 < (uint64_t)var_58h) {
        piVar7 = (int64_t *)var_70h;
    }
    iVar3 = func_0x000180455104(piVar7, &var_50h, 6, 0xffffffff);
    if (iVar3 != 0) goto code_r0x000180044854;
    if (((uint32_t)var_40h >> 10 & 1) == 0) {
code_r0x0001800447d2:
        cVar2 = (((uint32_t)var_40h & 0x10) != 0) + '\x02';
        cVar6 = (((uint32_t)var_40h >> 4 & 1) != 0) + '\x02';
    } else if (var_40h._4_4_ == -0x5ffffff4) {
        cVar6 = '\x04';
        cVar2 = '\x04';
    } else {
        if (var_40h._4_4_ != -0x5ffffffd) goto code_r0x0001800447d2;
        cVar2 = '\n';
        cVar6 = '\n';
    }
    uVar4 = 4;
    if (cVar2 == '\x04') {
        piVar7 = &var_70h;
        if (7 < (uint64_t)var_58h) {
            piVar7 = (int64_t *)var_70h;
        }
        iVar3 = func_0x000180455104(piVar7, &var_50h, 3, 0xffffffff);
        if (iVar3 != 0) goto code_r0x000180044854;
        iVar3 = 10;
        if (((uint32_t)var_40h >> 10 & 1) == 0) {
code_r0x000180044843:
            uVar4 = ((uint32_t)var_40h & 0x10 | 0x20) >> 4;
        } else if (var_40h._4_4_ != -0x5ffffff4) {
            if (var_40h._4_4_ != -0x5ffffffd) goto code_r0x000180044843;
            uVar4 = 10;
        }
        if (uVar4 != 3) goto code_r0x000180044854;
    } else {
        if (((cVar6 == '\x01') || (cVar6 == '\x02')) || (cVar6 != '\x03')) goto code_r0x000180044854;
        iVar3 = 3;
    }
    var_88h._0_4_ = 0;
    var_80h = 0x1806a45e0;
    if (iVar3 == 10) {
        piVar7 = &var_70h;
        if (7 < (uint64_t)var_58h) {
            piVar7 = (int64_t *)var_70h;
        }
        func_0x0001804554a0(piVar7);
        var_80h = 0x1806a45e0;
        var_88h._0_4_ = extraout_var;
    } else {
        piVar7 = &var_70h;
        if (7 < (uint64_t)var_58h) {
            piVar7 = (int64_t *)var_70h;
        }
        uVar5 = func_0x0001804554a0(piVar7);
        var_78h = uVar5 & 0xff;
        var_88h._0_4_ = (int32_t)(uVar5 >> 0x20);
        var_80h = 0x1806a45e0;
        if ((int32_t)var_88h == 0x91) {
            fcn.1800428b0((int64_t)&var_70h, (int64_t)&var_88h, (int64_t)&var_78h);
        }
        if (((int32_t)var_88h == 0) && (var_78h == 0)) {
            var_88h._0_4_ = 2;
            var_80h = 0x1806a45d0;
            goto code_r0x000180044967;
        }
    }
    if ((int32_t)var_88h == 0) {
code_r0x000180044854:
        fcn.18000dc80(&var_70h);
        fcn.180459870(var_30h ^ (uint64_t)auStackY_a8);
        return;
    }
code_r0x000180044967:
    fcn.180088380(arg1, 1, 0x1806231b8);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180044980
// Address: 0x180044980
// Size: 6858 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_578h
// WARNING: [rz-ghidra] Detected overlap for variable var_584h
// WARNING: [rz-ghidra] Detected overlap for variable var_580h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h

void fcn.180044980(int64_t arg1, int64_t arg_30h)
{
    code *pcVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    bool bVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    int64_t iVar9;
    char cVar10;
    char cVar11;
    uint8_t uVar12;
    int64_t *piVar13;
    undefined8 uVar14;
    int16_t *piVar15;
    int64_t iVar16;
    int16_t *piVar17;
    int64_t iVar18;
    int64_t iVar19;
    int16_t *piVar20;
    uint64_t uVar21;
    int16_t *piVar22;
    int32_t iVar23;
    uint64_t uVar24;
    int16_t *piVar25;
    undefined *puVar26;
    undefined *puVar27;
    uint32_t uVar28;
    int16_t *piVar29;
    uint64_t uVar30;
    int64_t iVar31;
    uint32_t uVar32;
    uint32_t uVar33;
    undefined4 uVar34;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Db;
    undefined4 extraout_XMM0_Dc;
    undefined4 extraout_XMM0_Dd;
    undefined8 uStackY_5b0;
    undefined auStackY_5a8 [8];
    undefined auStackY_5a0 [24];
    int64_t var_588h;
    undefined var_580h;
    int64_t var_578h;
    int64_t var_570h;
    int64_t var_568h;
    int64_t var_560h;
    int64_t var_558h;
    int64_t var_550h;
    int64_t var_548h;
    int64_t var_540h;
    int64_t var_538h;
    int64_t var_530h;
    int64_t var_520h;
    int64_t var_518h;
    int64_t var_510h;
    int64_t var_508h;
    int64_t var_500h;
    int64_t var_4e0h;
    int64_t var_4d8h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4a0h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_438h;
    int64_t var_430h;
    int64_t var_410h;
    int64_t var_408h;
    int64_t var_400h;
    int64_t var_3e0h;
    int64_t var_3d8h;
    int64_t var_3d0h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_388h;
    int64_t var_358h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_300h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_78h;
    int64_t var_58h;
    
    puVar27 = auStackY_5a8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_5a8;
    uVar32 = 0;
    var_588h._0_4_ = 0;
    uVar28 = 0;
    var_588h._4_4_ = 0;
    var_550h = arg1;
    fcn.180043a10((int64_t)&var_98h, arg1, var_578h);
    func_0x000180086fd0(arg1, 0, 0);
    uVar34 = fcn.1800814c0();
    uVar34 = fcn.180081ec0(uVar34, &var_98h);
    cVar10 = func_0x000180043b90(uVar34);
    if (cVar10 != '\0') {
        piVar13 = (int64_t *)fcn.1800814c0();
        var_468h = *piVar13;
        var_540h._0_4_ = 0;
        var_538h = 0x1806a45e0;
        iVar23 = 0;
        var_560h._0_4_ = 0;
        func_0x000180007fb0(&var_448h, &var_98h, &var_540h);
        uVar14 = func_0x00018000a260(&var_518h, &var_448h);
        func_0x0001800082d0(&var_4d8h, uVar14);
        uVar14 = func_0x00018000a260(&var_398h, &var_448h);
        func_0x000180008350(&var_530h, uVar14);
        iVar18 = var_530h;
        if (var_4d8h != var_530h) {
code_r0x000180044a90:
            fcn.180042ab0((int64_t)&var_238h, var_4d8h + 0x20, (int64_t)&var_540h, var_578h);
            if ((int32_t)var_540h == 0) {
                fcn.180042ab0((int64_t)&var_1b8h, var_468h, (int64_t)&var_540h, var_578h);
                if ((int32_t)var_540h != 0) {
                    var_318h = 0;
                    var_310h = 7;
                    stack0xfffffffffffffcda = SUB1614(ZEXT816(0), 2);
                    auVar3._14_2_ = 0;
                    auVar3._0_14_ = stack0xfffffffffffffcda;
                    _var_328h = auVar3 << 0x10;
                    uVar32 = uVar32 | 1;
                    var_588h._0_4_ = uVar32;
                    fcn.18000dc80(&var_1b8h);
                    fcn.18000dc80(&var_238h);
                    goto code_r0x00018004634e;
                }
                var_518h = 0x1806230ec;
                var_510h = 1;
                piVar13 = &var_238h;
                if (7 < (uint64_t)var_220h) {
                    piVar13 = (int64_t *)var_238h;
                }
                if ((((uint64_t)var_228h < 6) || (iVar23 = func_0x000180005b70(piVar13, 0x1806230d8, 4), iVar23 != 0))
                   || (0x19 < (*(uint32_t *)(piVar13 + 1) & 0xffffffdf) - 0x3a0041)) {
code_r0x000180044ca0:
                    bVar4 = false;
                    piVar13 = (int64_t *)fcn.180007340(&var_78h, &var_238h);
                    uVar32 = uVar32 | 4;
                } else {
                    piVar13 = &var_1b8h;
                    if (7 < (uint64_t)var_1a0h) {
                        piVar13 = (int64_t *)var_1b8h;
                    }
                    if ((((uint64_t)var_1a8h < 6) ||
                        (iVar23 = func_0x000180005b70(piVar13, 0x1806230d8, 4), iVar23 != 0)) ||
                       (0x19 < (*(uint32_t *)(piVar13 + 1) & 0xffffffdf) - 0x3a0041)) goto code_r0x000180044ca0;
                    bVar4 = true;
                    piVar13 = &var_238h;
                    if (7 < (uint64_t)var_220h) {
                        piVar13 = (int64_t *)var_238h;
                    }
                    piVar20 = (int16_t *)((int64_t)piVar13 + var_228h * 2);
                    for (piVar15 = (int16_t *)func_0x000180006c10();
                        (piVar15 != piVar20 && ((*piVar15 == 0x5c || (*piVar15 == 0x2f)))); piVar15 = piVar15 + 1) {
                    }
                    _var_168h = ZEXT816(0);
                    var_158h = 0;
                    var_150h = 0;
                    func_0x00018000d380(&var_168h, piVar15, (int64_t)piVar20 - (int64_t)piVar15 >> 1);
                    piVar13 = &var_168h;
                    uVar32 = uVar32 | 0x70000002;
                }
                var_588h._0_4_ = uVar32;
                fcn.180007340(&var_258h, piVar13);
                if ((uVar32 & 4) != 0) {
                    uVar32 = uVar32 & 0xfffffffb;
                    var_588h._0_4_ = uVar32;
                    fcn.18000dc80(&var_78h);
                }
                if (((uVar32 & 2) != 0) &&
                   (uVar32 = uVar32 & 0xfffffffd, var_588h._0_4_ = uVar32, 7 < (uint64_t)var_150h)) {
                    func_0x00018000f950(&var_168h, var_168h);
                }
                if (bVar4) {
                    piVar13 = &var_1b8h;
                    if (7 < (uint64_t)var_1a0h) {
                        piVar13 = (int64_t *)var_1b8h;
                    }
                    piVar20 = (int16_t *)((int64_t)piVar13 + var_1a8h * 2);
                    for (piVar15 = (int16_t *)func_0x000180006c10();
                        (piVar15 != piVar20 && ((*piVar15 == 0x5c || (*piVar15 == 0x2f)))); piVar15 = piVar15 + 1) {
                    }
                    _var_358h = ZEXT816(0);
                    var_348h = 0;
                    var_340h = 0;
                    func_0x00018000d380(&var_358h, piVar15, (int64_t)piVar20 - (int64_t)piVar15 >> 1);
                    uVar28 = uVar28 | 3;
                    piVar13 = &var_358h;
                    uVar32 = uVar32 | 0x80000008;
                    var_588h._4_4_ = uVar28;
                } else {
                    piVar13 = (int64_t *)fcn.180007340(&var_2a8h, &var_1b8h);
                    uVar32 = uVar32 | 0x10;
                }
                var_588h._0_4_ = uVar32;
                fcn.180007340(&var_278h, piVar13);
                if ((uVar32 & 0x10) != 0) {
                    uVar32 = uVar32 & 0xffffffef;
                    fcn.18000dc80(&var_2a8h);
                }
                if ((uVar32 & 8) != 0) {
                    uVar32 = uVar32 & 0xfffffff7;
                    fcn.18000dc80(&var_358h);
                }
                var_318h = 0;
                var_310h = 7;
                stack0xfffffffffffffcda = SUB1614(ZEXT816(0), 2);
                auVar5._14_2_ = 0;
                auVar5._0_14_ = stack0xfffffffffffffcda;
                _var_328h = auVar5 << 0x10;
                var_588h._0_4_ = uVar32 | 0x20;
                piVar13 = &var_278h;
                if (7 < (uint64_t)var_260h) {
                    piVar13 = (int64_t *)var_278h;
                }
                iVar16 = func_0x000180006c10(piVar13, (int64_t)piVar13 + var_268h * 2);
                var_358h._4_4_ = extraout_XMM0_Db;
                var_358h._0_4_ = extraout_XMM0_Da;
                unique0x10000605 = extraout_XMM0_Dc;
                unique0x10000609 = extraout_XMM0_Dd;
                var_348h = 0;
                var_340h = 0;
                func_0x00018000d380(&var_358h, piVar13, iVar16 - (int64_t)piVar13 >> 1);
                var_588h._0_4_ = uVar32 | 0x1c60;
                piVar13 = &var_258h;
                if (7 < (uint64_t)var_240h) {
                    piVar13 = (int64_t *)var_258h;
                }
                iVar16 = func_0x000180006c10(piVar13, (int64_t)piVar13 + var_248h * 2);
                _var_2a8h = ZEXT816(0);
                var_298h = 0;
                var_290h = 0;
                func_0x00018000d380(&var_2a8h, piVar13, iVar16 - (int64_t)piVar13 >> 1);
                uVar32 = uVar32 | 0xfce0;
                var_588h._0_4_ = uVar32;
                iVar23 = func_0x000180006fa0(&var_2a8h, &var_358h);
                if (iVar23 == 0) {
                    cVar10 = func_0x0001800072b0(&var_278h);
                    cVar11 = func_0x0001800072b0(&var_258h);
                    if ((cVar11 != cVar10) ||
                       ((((cVar10 = fcn.180041aa0((int64_t)&var_258h), cVar10 == '\0' &&
                          (cVar10 = fcn.180041aa0((int64_t)&var_278h), cVar10 != '\0')) ||
                         (cVar10 = fcn.180041d90((int64_t)&var_258h), cVar10 != '\0')) ||
                        (cVar10 = fcn.180041d90((int64_t)&var_278h), cVar10 != '\0')))) goto code_r0x000180044f84;
                    bVar4 = false;
                } else {
code_r0x000180044f84:
                    bVar4 = true;
                }
                uVar33 = uVar32 & 0xffffff7f;
                var_588h._0_4_ = uVar33;
                if (7 < (uint64_t)var_290h) {
                    uVar21 = var_290h * 2 + 2;
                    iVar16 = var_2a8h;
                    if (0xfff < uVar21) {
                        iVar16 = *(int64_t *)(var_2a8h + -8);
                        if (0x1f < (var_2a8h - iVar16) - 8U) {
                            pcVar1 = (code *)swi(0x29);
                            (*pcVar1)(5);
                            puVar26 = auStackY_5a0;
code_r0x00018004643d:
                            pcVar1 = (code *)swi(0x29);
                            (*pcVar1)(5);
                            puVar27 = puVar26 + 8;
code_r0x000180046444:
                            *(undefined8 *)(puVar27 + -8) = 0x180046449;
                            func_0x00018000f930();
                            pcVar1 = (code *)swi(3);
                            (*pcVar1)();
                            return;
                        }
                        uVar21 = var_290h * 2 + 0x29;
                    }
                    fcn.180459c3c(iVar16, uVar21);
                }
                var_298h = 0;
                var_290h = 7;
                auVar6._14_2_ = 0;
                auVar6._0_14_ = stack0xfffffffffffffd5a;
                _var_2a8h = auVar6 << 0x10;
                if (((uVar32 & 0x40) != 0) &&
                   (uVar33 = uVar32 & 0xffffff3f, var_588h._0_4_ = uVar33, 7 < (uint64_t)var_340h)) {
                    func_0x00018000f950(&var_358h, var_358h);
                }
                if (!bVar4) {
                    piVar13 = &var_258h;
                    if (7 < (uint64_t)var_240h) {
                        piVar13 = (int64_t *)var_258h;
                    }
                    iVar18 = (int64_t)piVar13 + var_248h * 2;
                    var_1d0h = 0;
                    var_1c8h = 7;
                    stack0xfffffffffffffe22 = SUB1614(ZEXT816(0), 2);
                    auVar7._14_2_ = 0;
                    auVar7._0_14_ = stack0xfffffffffffffe22;
                    _var_1e0h = auVar7 << 0x10;
                    var_1c0h = (int64_t)&var_258h;
                    var_1e8h = iVar18;
                    fcn.180041eb0((int64_t)&var_278h, (int64_t)&var_148h);
                    piVar13 = &var_278h;
                    if (7 < (uint64_t)var_260h) {
                        piVar13 = (int64_t *)var_278h;
                    }
                    var_3d8h = (int64_t)piVar13 + var_268h * 2;
                    var_200h = 0;
                    var_1f8h = 7;
                    stack0xfffffffffffffdf2 = SUB1614(ZEXT816(0), 2);
                    auVar8._14_2_ = 0;
                    auVar8._0_14_ = stack0xfffffffffffffdf2;
                    _var_210h = auVar8 << 0x10;
                    var_1f0h = (int64_t)&var_278h;
                    var_578h = (int64_t)&var_3d8h;
                    var_218h = var_3d8h;
                    fcn.180007340(&var_3d0h, &var_210h);
                    var_3b0h = var_1f0h;
                    var_548h = (int64_t)&var_3d8h;
                    var_568h = (int64_t)&var_408h;
                    var_408h = var_148h;
                    fcn.180007340(&var_400h, &var_140h);
                    var_3e0h = var_120h;
                    var_570h = (int64_t)&var_408h;
                    var_460h = (int64_t)&var_438h;
                    var_438h = iVar18;
                    fcn.180007340(&var_430h, &var_1e0h);
                    var_410h = var_1c0h;
                    var_3a8h = (int64_t)&var_438h;
                    piVar13 = (int64_t *)fcn.180041eb0((int64_t)&var_258h, (int64_t)&var_388h);
                    var_460h = (int64_t)&var_508h;
                    var_508h = var_3d8h;
                    var_458h = (int64_t)piVar13;
                    fcn.180007340(&var_500h, &var_3d0h);
                    var_4e0h = var_3b0h;
                    var_578h = (int64_t)&var_508h;
                    var_3a0h = (int64_t)&var_4c8h;
                    var_4c8h = var_408h;
                    fcn.180007340(&var_4c0h, &var_400h);
                    var_4a0h = var_3e0h;
                    var_450h = (int64_t)&var_4c8h;
                    var_520h = (int64_t)&var_198h;
                    var_198h = var_438h;
                    fcn.180007340(&var_190h, &var_430h);
                    var_170h = var_410h;
                    var_558h = (int64_t)&var_198h;
                    var_498h = *piVar13;
                    var_568h = (int64_t)(piVar13 + 1);
                    fcn.180007340(&var_490h, var_568h);
                    iVar18 = piVar13[5];
                    var_520h = (int64_t)&var_498h;
                    var_2a8h = var_498h;
                    var_470h = iVar18;
                    fcn.180007340(&var_2a0h, &var_490h);
                    iVar19 = var_170h;
                    var_588h._0_4_ = uVar33 | 0x300000;
                    var_118h = var_198h;
                    var_280h = iVar18;
                    fcn.180007340(&var_110h, &var_190h);
                    iVar16 = var_4a0h;
                    var_f0h = iVar19;
                    var_588h._0_4_ = uVar33 | 0xf00000;
                    var_358h = var_4c8h;
                    fcn.180007340(&var_350h, &var_4c0h);
                    iVar18 = var_4e0h;
                    var_330h = iVar16;
                    var_588h._0_4_ = uVar33 | 0x3f00000;
                    var_e8h = var_508h;
                    fcn.180007340(&var_e0h, &var_500h);
                    iVar19 = var_e8h;
                    iVar16 = var_118h;
                    var_c0h = iVar18;
                    var_588h._0_4_ = uVar33 | 0xff00000;
                    if (var_2a8h != var_118h) {
                        iVar18 = var_358h;
code_r0x0001800453b0:
                        if (iVar18 != iVar19) {
                            iVar23 = func_0x000180006fa0(&var_2a0h, &var_350h);
                            if (iVar23 == 0) {
                                iVar18 = var_280h;
                                if (7 < *(uint64_t *)(var_280h + 0x18)) {
                                    iVar18 = *(int64_t *)var_280h;
                                }
                                piVar20 = (int16_t *)(iVar18 + *(int64_t *)(var_280h + 0x10) * 2);
                                if (iVar18 == var_2a8h) {
                                    piVar15 = (int16_t *)(var_2a8h + var_290h * 2);
                                    var_2a8h = (int64_t)piVar15;
                                    piVar25 = (int16_t *)var_280h;
                                    if (7 < *(uint64_t *)(var_280h + 0x18)) {
                                        piVar25 = *(int16_t **)var_280h;
                                    }
                                    piVar22 = piVar25 + *(int64_t *)(var_280h + 0x10);
                                    piVar17 = (int16_t *)func_0x000180006c10(piVar25);
                                    for (piVar29 = piVar17;
                                        (piVar29 != piVar22 && ((*piVar29 == 0x5c || (*piVar29 == 0x2f))));
                                        piVar29 = piVar29 + 1) {
                                    }
                                    if ((piVar25 == piVar17) || (piVar17 == piVar29)) {
code_r0x0001800454a9:
                                        if (piVar15 != piVar20) {
                                            do {
                                                piVar25 = piVar15;
                                                if ((*piVar25 != 0x5c) && (piVar15 = piVar25, *piVar25 != 0x2f))
                                                goto joined_r0x0001800455bb;
                                                piVar15 = piVar25 + 1;
                                                var_2a8h = (int64_t)piVar15;
                                            } while (piVar15 != piVar20);
                                            var_2a0h = var_2a0h;
                                            var_2a8h = (int64_t)piVar25;
                                        }
                                        piVar13 = &var_2a0h;
                                        if (7 < (uint64_t)var_288h) {
                                            piVar13 = (int64_t *)var_2a0h;
                                        }
                                        var_290h = 0;
                                        *(undefined2 *)piVar13 = 0;
                                    } else {
                                        func_0x00018000d7e0(&var_2a0h, piVar17, (int64_t)piVar29 - (int64_t)piVar17 >> 1
                                                           );
                                    }
                                } else {
                                    if (((*(int16_t *)var_2a8h != 0x5c) && (*(int16_t *)var_2a8h != 0x2f)) ||
                                       (var_290h != 0)) {
                                        piVar15 = (int16_t *)(var_2a8h + var_290h * 2);
                                        var_2a8h = (int64_t)piVar15;
                                        goto code_r0x0001800454a9;
                                    }
                                    var_2a8h = var_2a8h + 2;
                                }
                                goto code_r0x000180045506;
                            }
                            goto code_r0x0001800456c4;
                        }
                        goto code_r0x0001800456cb;
                    }
code_r0x0001800456c4:
                    iVar18 = var_358h;
code_r0x0001800456cb:
                    piVar13 = &var_350h;
                    if (7 < (uint64_t)var_338h) {
                        piVar13 = (int64_t *)var_350h;
                    }
                    var_4c8h = iVar18;
                    func_0x00018000d7e0(&var_4c0h, piVar13, var_340h);
                    var_498h = var_2a8h;
                    piVar13 = &var_2a0h;
                    if (7 < (uint64_t)var_288h) {
                        piVar13 = (int64_t *)var_2a0h;
                    }
                    func_0x00018000d7e0(&var_490h, piVar13, var_290h);
                    var_308h = var_498h;
                    fcn.180007340(&var_300h, &var_490h);
                    var_2e0h = var_470h;
                    var_2d8h = var_4c8h;
                    fcn.180007340(&var_2d0h, &var_4c0h);
                    var_2b0h = var_4a0h;
                    fcn.18000dc80(&var_e0h);
                    fcn.18000dc80(&var_350h);
                    fcn.18000dc80(&var_110h);
                    fcn.18000dc80(&var_2a0h);
                    fcn.18000dc80(&var_490h);
                    fcn.18000dc80(&var_190h);
                    fcn.18000dc80(&var_4c0h);
                    fcn.18000dc80(&var_500h);
                    var_570h = CONCAT44(var_570h._4_4_, uVar33) | 0xffc0000;
                    var_588h._0_4_ = uVar33 | 0xffc0000;
                    fcn.18000dc80(var_568h);
                    fcn.18000dc80(&var_430h);
                    fcn.18000dc80(&var_400h);
                    fcn.18000dc80(&var_3d0h);
                    iVar16 = var_1e8h;
                    iVar18 = var_218h;
                    if ((var_308h != var_1e8h) || (var_2d8h != var_218h)) {
                        var_558h = (int64_t)&var_e8h;
                        piVar13 = (int64_t *)fcn.180041e50((int64_t)&var_e8h, (int64_t)&var_2d8h);
                        var_508h = var_148h;
                        var_520h = (int64_t)piVar13;
                        fcn.180007340(&var_500h, &var_140h);
                        iVar19 = var_120h;
                        var_4e0h = var_120h;
                        var_558h = (int64_t)&var_508h;
                        var_198h = var_508h;
                        fcn.180007340(&var_190h, &var_500h);
                        uVar28 = var_588h._4_4_;
                        var_170h = iVar19;
                        iVar19 = piVar13[5];
                        var_118h = *piVar13;
                        fcn.180007340(&var_110h, piVar13 + 1);
                        iVar9 = var_118h;
                        var_588h._4_4_ = uVar28 | 0xf0;
                        iVar31 = 0;
                        var_f0h = iVar19;
                        while (var_198h != iVar9) {
                            iVar31 = iVar31 + 1;
                            func_0x0001800474f0(&var_198h);
                        }
                        fcn.18000dc80(&var_110h);
                        fcn.18000dc80(&var_190h);
                        fcn.18000dc80(&var_500h);
                        fcn.18000dc80(piVar13 + 1);
                        piVar13 = &var_278h;
                        if (7 < (uint64_t)var_260h) {
                            piVar13 = (int64_t *)var_278h;
                        }
                        iVar19 = func_0x000180006c10(piVar13, (int64_t)piVar13 + var_268h * 2);
                        uVar12 = fcn.180041aa0((int64_t)&var_278h);
                        var_568h = (uint64_t)(1 < (uint64_t)(iVar19 - (int64_t)piVar13)) + (uint64_t)uVar12;
                        if (iVar31 < var_568h) {
code_r0x0001800459c0:
                            piVar20 = (int16_t *)var_2b0h;
                            if (7 < *(uint64_t *)(var_2b0h + 0x18)) {
                                piVar20 = *(int16_t **)var_2b0h;
                            }
                            iVar19 = *(int64_t *)(var_2b0h + 0x10);
                            if (piVar20 == (int16_t *)var_2d8h) {
                                piVar15 = (int16_t *)(var_2d8h + var_2c0h * 2);
                                piVar25 = (int16_t *)var_2b0h;
                                if (7 < *(uint64_t *)(var_2b0h + 0x18)) {
                                    piVar25 = *(int16_t **)var_2b0h;
                                }
                                piVar22 = piVar25 + *(int64_t *)(var_2b0h + 0x10);
                                var_2d8h = (int64_t)piVar15;
                                piVar17 = (int16_t *)func_0x000180006c10(piVar25);
                                for (piVar29 = piVar17;
                                    (piVar29 != piVar22 && ((*piVar29 == 0x5c || (*piVar29 == 0x2f))));
                                    piVar29 = piVar29 + 1) {
                                }
                                piVar22 = (int16_t *)var_2d8h;
                                if ((piVar25 == piVar17) || (piVar17 == piVar29)) goto joined_r0x000180045a8c;
                                func_0x00018000d7e0(&var_2d0h, piVar17, (int64_t)piVar29 - (int64_t)piVar17 >> 1);
                            } else if (((*(int16_t *)var_2d8h == 0x5c) || (*(int16_t *)var_2d8h == 0x2f)) &&
                                      (var_2c0h == 0)) {
                                var_2d8h = (int64_t)(var_2d8h + 2);
                            } else {
                                var_2d8h = var_2d8h + var_2c0h * 2;
                                piVar15 = (int16_t *)var_2d8h;
                                piVar22 = (int16_t *)var_2d8h;
joined_r0x000180045a8c:
                                while (piVar25 = piVar15, piVar25 != piVar20 + iVar19) {
                                    if ((*piVar25 != 0x5c) && (piVar15 = piVar25, *piVar25 != 0x2f))
                                    goto joined_r0x000180045c58;
                                    var_2d8h = (int64_t)(piVar25 + 1);
                                    piVar22 = piVar25;
                                    piVar15 = (int16_t *)var_2d8h;
                                }
                                piVar13 = &var_2d0h;
                                if (7 < (uint64_t)var_2b8h) {
                                    piVar13 = (int64_t *)var_2d0h;
                                }
                                var_2c0h = 0;
                                *(undefined2 *)piVar13 = 0;
                                var_2d8h = (int64_t)piVar22;
                            }
                            goto code_r0x000180045aed;
                        }
code_r0x000180045afb:
                        iVar19 = 0;
                        if (var_2d8h != iVar18) {
code_r0x000180045b10:
                            if (var_2c0h != 0) {
                                _var_358h = ZEXT816(0);
                                var_348h = 0;
                                var_340h = 0;
                                func_0x00018000d380(&var_358h, 0x1806230ec, 1);
                                var_588h._0_4_ = (uint32_t)var_570h | 0x30000;
                                var_570h = var_570h | 0x30000;
                                iVar23 = func_0x000180006fa0(&var_2d0h, &var_358h);
                                if (7 < (uint64_t)var_340h) {
                                    uVar21 = var_340h * 2 + 2;
                                    iVar31 = var_358h;
                                    if (0xfff < uVar21) {
                                        iVar31 = *(int64_t *)(var_358h + -8);
                                        puVar26 = auStackY_5a8;
                                        if (0x1f < (var_358h - iVar31) - 8U) goto code_r0x00018004643d;
                                        uVar21 = var_340h * 2 + 0x29;
                                    }
                                    fcn.180459c3c(iVar31, uVar21);
                                }
                                if (iVar23 != 0) {
                                    _var_358h = ZEXT816(0);
                                    var_348h = 0;
                                    var_340h = 0;
                                    func_0x00018000d380(&var_358h, 0x1806230e4, 2);
                                    var_588h._4_4_ = var_588h._4_4_ | 0xc;
                                    iVar23 = func_0x000180006fa0(&var_2d0h, &var_358h);
                                    if (7 < (uint64_t)var_340h) {
                                        func_0x00018000f950(&var_358h, var_358h);
                                    }
                                    if (iVar23 == 0) {
                                        iVar19 = iVar19 + -1;
                                    } else {
                                        iVar19 = iVar19 + 1;
                                    }
                                }
                            }
                            piVar20 = (int16_t *)var_2b0h;
                            if (7 < *(uint64_t *)(var_2b0h + 0x18)) {
                                piVar20 = *(int16_t **)var_2b0h;
                            }
                            iVar31 = *(int64_t *)(var_2b0h + 0x10);
                            if (piVar20 == (int16_t *)var_2d8h) {
                                piVar15 = (int16_t *)(var_2d8h + var_2c0h * 2);
                                piVar25 = (int16_t *)var_2b0h;
                                if (7 < *(uint64_t *)(var_2b0h + 0x18)) {
                                    piVar25 = *(int16_t **)var_2b0h;
                                }
                                piVar22 = piVar25 + *(int64_t *)(var_2b0h + 0x10);
                                var_2d8h = (int64_t)piVar15;
                                piVar17 = (int16_t *)func_0x000180006c10(piVar25);
                                for (piVar29 = piVar17;
                                    (piVar29 != piVar22 && ((*piVar29 == 0x5c || (*piVar29 == 0x2f))));
                                    piVar29 = piVar29 + 1) {
                                }
                                piVar22 = (int16_t *)var_2d8h;
                                if ((piVar25 == piVar17) || (piVar17 == piVar29)) goto joined_r0x000180045d62;
                                func_0x00018000d7e0(&var_2d0h, piVar17, (int64_t)piVar29 - (int64_t)piVar17 >> 1);
                            } else if (((*(int16_t *)var_2d8h == 0x5c) || (*(int16_t *)var_2d8h == 0x2f)) &&
                                      (var_2c0h == 0)) {
                                var_2d8h = (int64_t)(var_2d8h + 2);
                            } else {
                                var_2d8h = var_2d8h + var_2c0h * 2;
                                piVar15 = (int16_t *)var_2d8h;
                                piVar22 = (int16_t *)var_2d8h;
joined_r0x000180045d62:
                                while (piVar25 = piVar15, piVar25 != piVar20 + iVar31) {
                                    if ((*piVar25 != 0x5c) && (piVar15 = piVar25, *piVar25 != 0x2f))
                                    goto joined_r0x000180045e26;
                                    var_2d8h = (int64_t)(piVar25 + 1);
                                    piVar22 = piVar25;
                                    piVar15 = (int16_t *)var_2d8h;
                                }
                                piVar13 = &var_2d0h;
                                if (7 < (uint64_t)var_2b8h) {
                                    piVar13 = (int64_t *)var_2d0h;
                                }
                                var_2c0h = 0;
                                *(undefined2 *)piVar13 = 0;
                                var_2d8h = (int64_t)piVar22;
                            }
                            goto code_r0x000180045dc1;
                        }
                        goto code_r0x000180045f24;
                    }
                    func_0x0001800473b0(&var_328h, &var_518h);
                    uVar33 = uVar33 | 0xffc0000;
                    goto code_r0x000180046295;
                }
                uVar33 = uVar33 & 0xffffffdf;
                fcn.18000dc80(&var_278h);
                goto code_r0x00018004631c;
            }
            var_318h = 0;
            var_310h = 7;
            stack0xfffffffffffffcda = SUB1614(ZEXT816(0), 2);
            auVar2._14_2_ = 0;
            auVar2._0_14_ = stack0xfffffffffffffcda;
            _var_328h = auVar2 << 0x10;
            uVar32 = uVar32 | 1;
            var_588h._0_4_ = uVar32;
            fcn.18000dc80(&var_238h);
            goto code_r0x00018004634e;
        }
code_r0x0001800463e3:
        func_0x000180008300(&var_530h);
        func_0x000180008300(&var_4d8h);
        func_0x000180008300(&var_448h);
    }
    fcn.18000dc80(&var_98h);
    fcn.180459870(var_58h ^ (uint64_t)auStackY_5a8);
    return;
joined_r0x0001800455bb:
    for (; (piVar15 != piVar20 && ((*piVar15 != 0x5c && (*piVar15 != 0x2f)))); piVar15 = piVar15 + 1) {
    }
    func_0x00018000d7e0(&var_2a0h, piVar25, (int64_t)piVar15 - (int64_t)piVar25 >> 1);
code_r0x000180045506:
    iVar18 = var_330h;
    if (7 < *(uint64_t *)(var_330h + 0x18)) {
        iVar18 = *(int64_t *)var_330h;
    }
    piVar20 = (int16_t *)(iVar18 + *(int64_t *)(var_330h + 0x10) * 2);
    if (iVar18 == var_358h) {
        piVar15 = (int16_t *)(var_358h + var_340h * 2);
        var_358h = (int64_t)piVar15;
        piVar25 = (int16_t *)var_330h;
        if (7 < *(uint64_t *)(var_330h + 0x18)) {
            piVar25 = *(int16_t **)var_330h;
        }
        piVar22 = piVar25 + *(int64_t *)(var_330h + 0x10);
        piVar17 = (int16_t *)func_0x000180006c10(piVar25);
        for (piVar29 = piVar17; (piVar29 != piVar22 && ((*piVar29 == 0x5c || (*piVar29 == 0x2f))));
            piVar29 = piVar29 + 1) {
        }
        if ((piVar25 != piVar17) && (piVar17 != piVar29)) {
            func_0x00018000d7e0(&var_350h, piVar17, (int64_t)piVar29 - (int64_t)piVar17 >> 1);
            goto code_r0x000180045676;
        }
    } else {
        if (((*(int16_t *)var_358h == 0x5c) || (*(int16_t *)var_358h == 0x2f)) && (var_340h == 0)) {
            iVar18 = var_358h + 2;
            var_358h = iVar18;
            goto code_r0x00018004567d;
        }
        piVar15 = (int16_t *)(var_358h + var_340h * 2);
        var_358h = (int64_t)piVar15;
    }
    if (piVar15 != piVar20) {
        do {
            piVar25 = piVar15;
            if ((*piVar25 != 0x5c) && (piVar15 = piVar25, *piVar25 != 0x2f)) goto joined_r0x000180045692;
            piVar15 = piVar25 + 1;
            var_358h = (int64_t)piVar15;
        } while (piVar15 != piVar20);
        var_350h = var_350h;
        var_358h = (int64_t)piVar25;
    }
    piVar13 = &var_350h;
    if (7 < (uint64_t)var_338h) {
        piVar13 = (int64_t *)var_350h;
    }
    var_340h = 0;
    *(undefined2 *)piVar13 = 0;
code_r0x000180045676:
    iVar18 = var_358h;
code_r0x00018004567d:
    if (var_2a8h == iVar16) goto code_r0x0001800456cb;
    goto code_r0x0001800453b0;
joined_r0x000180045692:
    for (; (piVar15 != piVar20 && ((*piVar15 != 0x5c && (*piVar15 != 0x2f)))); piVar15 = piVar15 + 1) {
    }
    func_0x00018000d7e0(&var_350h, piVar25, (int64_t)piVar15 - (int64_t)piVar25 >> 1);
    goto code_r0x000180045676;
joined_r0x000180045c58:
    for (; ((piVar15 != piVar20 + iVar19 && (*piVar15 != 0x5c)) && (*piVar15 != 0x2f)); piVar15 = piVar15 + 1) {
    }
    func_0x00018000d7e0(&var_2d0h, piVar25, (int64_t)piVar15 - (int64_t)piVar25 >> 1);
code_r0x000180045aed:
    iVar31 = iVar31 + 1;
    if (var_568h <= iVar31) goto code_r0x000180045afb;
    goto code_r0x0001800459c0;
joined_r0x000180045e26:
    for (; ((piVar15 != piVar20 + iVar31 && (*piVar15 != 0x5c)) && (*piVar15 != 0x2f)); piVar15 = piVar15 + 1) {
    }
    func_0x00018000d7e0(&var_2d0h, piVar25, (int64_t)piVar15 - (int64_t)piVar25 >> 1);
code_r0x000180045dc1:
    if (var_2d8h == iVar18) goto code_r0x000180045dca;
    goto code_r0x000180045b10;
code_r0x000180045dca:
    if (-1 < iVar19) {
        if (iVar19 == 0) {
code_r0x000180045f24:
            if ((var_308h == iVar16) || (var_2f0h == 0)) {
                func_0x0001800473b0(&var_328h, &var_518h);
                uVar33 = (uint32_t)var_570h;
code_r0x000180046295:
                uVar33 = uVar33 & 0xffffffdf;
                fcn.18000dc80(&var_2d0h);
                fcn.18000dc80(&var_300h);
                if (7 < (uint64_t)var_1f8h) {
                    func_0x00018000f950(&var_210h, var_210h);
                }
                fcn.18000dc80(&var_140h);
                if (7 < (uint64_t)var_1c8h) {
                    func_0x00018000f950(&var_1e0h, var_1e0h);
                }
                goto code_r0x000180046301;
            }
        } else {
            for (; 0 < iVar19; iVar19 = iVar19 + -1) {
                _var_358h = ZEXT816(0);
                var_348h = 0;
                var_340h = 0;
                func_0x00018000d380(&var_358h, 0x1806230e4, 2);
                var_588h._0_4_ = (uint32_t)var_570h | 0x300;
                var_570h = var_570h | 0x300;
                func_0x000180006d80(&var_328h, &var_358h);
                if (7 < (uint64_t)var_340h) {
                    uVar21 = var_340h * 2 + 2;
                    iVar18 = var_358h;
                    if (0xfff < uVar21) {
                        iVar18 = *(int64_t *)(var_358h + -8);
                        puVar26 = auStackY_5a8;
                        if (0x1f < (var_358h - iVar18) - 8U) goto code_r0x00018004643d;
                        uVar21 = var_340h * 2 + 0x29;
                    }
                    fcn.180459c3c(iVar18, uVar21);
                }
            }
        }
        if (var_308h != iVar16) {
code_r0x000180045f50:
            cVar10 = func_0x0001800072b0(&var_300h);
            uVar21 = var_310h;
            if (cVar10 == '\0') {
                piVar13 = &var_328h;
                if (7 < (uint64_t)var_310h) {
                    piVar13 = (int64_t *)var_328h;
                }
                var_578h = (int64_t)piVar13 + var_318h * 2;
                var_568h = (int64_t)&var_300h;
                if (7 < (uint64_t)var_2e8h) {
                    var_568h = var_300h;
                }
                iVar18 = var_568h + var_2f0h * 2;
                uVar30 = var_318h;
                iVar19 = func_0x000180006c10(piVar13);
                var_548h = func_0x000180006c10(var_568h, iVar18);
                if ((var_568h != var_548h) &&
                   (iVar23 = func_0x000180006d10(piVar13, iVar19, var_568h, var_548h), uVar30 = var_318h,
                   uVar21 = var_310h, iVar23 != 0)) goto code_r0x000180045f60;
                if ((var_548h == iVar18) || ((*(int16_t *)var_548h != 0x5c && (*(int16_t *)var_548h != 0x2f)))) {
                    if (iVar19 == var_578h) {
                        if (5 < (int64_t)(iVar19 - (int64_t)piVar13 & 0xfffffffffffffffeU)) {
                            if (uVar21 <= uVar30) goto code_r0x0001800460e5;
code_r0x0001800460c0:
                            var_318h = uVar30 + 1;
                            piVar13 = &var_328h;
                            if (7 < uVar21) {
                                piVar13 = (int64_t *)var_328h;
                            }
                            *(undefined4 *)((int64_t)piVar13 + uVar30 * 2) = 0x5c;
                        }
                    } else if ((*(int16_t *)(var_578h + -2) != 0x5c) && (*(int16_t *)(var_578h + -2) != 0x2f)) {
                        if (uVar30 < uVar21) goto code_r0x0001800460c0;
code_r0x0001800460e5:
                        func_0x00018000d650(&var_328h, 1, var_580h, 0x5c);
                    }
                } else {
                    uVar24 = iVar19 - (int64_t)piVar13 >> 1;
                    if (uVar30 < uVar24) goto code_r0x000180046444;
                    piVar13 = &var_328h;
                    if (7 < uVar21) {
                        piVar13 = (int64_t *)var_328h;
                    }
                    var_318h = uVar24;
                    *(undefined2 *)((int64_t)piVar13 + uVar24 * 2) = 0;
                }
                func_0x00018000d4b0(&var_328h, var_548h, iVar18 - var_548h >> 1);
            } else {
code_r0x000180045f60:
                piVar13 = &var_300h;
                if (7 < (uint64_t)var_2e8h) {
                    piVar13 = (int64_t *)var_300h;
                }
                func_0x00018000d7e0(&var_328h, piVar13, var_2f0h);
            }
            iVar18 = var_2e0h;
            if (7 < *(uint64_t *)(var_2e0h + 0x18)) {
                iVar18 = *(int64_t *)var_2e0h;
            }
            piVar20 = (int16_t *)(iVar18 + *(int64_t *)(var_2e0h + 0x10) * 2);
            if (iVar18 == var_308h) {
                piVar15 = (int16_t *)(var_308h + var_2f0h * 2);
                piVar25 = (int16_t *)var_2e0h;
                if (7 < *(uint64_t *)(var_2e0h + 0x18)) {
                    piVar25 = *(int16_t **)var_2e0h;
                }
                piVar22 = piVar25 + *(int64_t *)(var_2e0h + 0x10);
                var_308h = (int64_t)piVar15;
                piVar17 = (int16_t *)func_0x000180006c10(piVar25);
                for (piVar29 = piVar17; (piVar29 != piVar22 && ((*piVar29 == 0x5c || (*piVar29 == 0x2f))));
                    piVar29 = piVar29 + 1) {
                }
                piVar22 = (int16_t *)var_308h;
                if ((piVar25 == piVar17) || (piVar17 == piVar29)) goto joined_r0x0001800461dc;
                func_0x00018000d7e0(&var_300h, piVar17, (int64_t)piVar29 - (int64_t)piVar17 >> 1);
            } else if (((*(int16_t *)var_308h == 0x5c) || (*(int16_t *)var_308h == 0x2f)) && (var_2f0h == 0)) {
                var_308h = var_308h + 2;
            } else {
                var_308h = var_308h + var_2f0h * 2;
                piVar15 = (int16_t *)var_308h;
                piVar22 = (int16_t *)var_308h;
joined_r0x0001800461dc:
                while (piVar25 = piVar15, piVar25 != piVar20) {
                    if ((*piVar25 != 0x5c) && (piVar15 = piVar25, *piVar25 != 0x2f)) goto joined_r0x00018004624d;
                    var_308h = (int64_t)(piVar25 + 1);
                    piVar22 = piVar25;
                    piVar15 = (int16_t *)var_308h;
                }
                piVar13 = &var_300h;
                if (7 < (uint64_t)var_2e8h) {
                    piVar13 = (int64_t *)var_300h;
                }
                var_2f0h = 0;
                *(undefined2 *)piVar13 = 0;
                var_308h = (int64_t)piVar22;
            }
            goto code_r0x000180046239;
        }
    }
code_r0x000180045dd3:
    uVar33 = (uint32_t)var_570h & 0xffffffdf;
    fcn.18000dc80(&var_2d0h);
    fcn.18000dc80(&var_300h);
    fcn.18000dc80(&var_210h);
    fcn.18000dc80(&var_140h);
    fcn.18000dc80(&var_1e0h);
code_r0x000180046301:
    fcn.18000dc80(&var_278h);
    arg1 = var_550h;
    iVar18 = var_530h;
    uVar28 = var_588h._4_4_;
code_r0x00018004631c:
    fcn.18000dc80(&var_258h);
    uVar32 = uVar33 | 1;
    var_588h._0_4_ = uVar32;
    fcn.18000dc80(&var_1b8h);
    fcn.18000dc80(&var_238h);
    iVar23 = (int32_t)var_560h;
code_r0x00018004634e:
    if ((int32_t)var_540h == 0) {
        func_0x000180006eb0(&var_328h, &var_b8h);
        uVar14 = func_0x00018000b450(&var_b8h);
        fcn.1800867f0(arg1, uVar14, var_a8h);
        iVar23 = iVar23 + 1;
        var_560h._0_4_ = iVar23;
        func_0x000180087560(arg1, 0xfffffffe, iVar23);
        func_0x000180004e40(&var_b8h);
    } else {
        var_540h._0_4_ = 0;
        var_538h = 0x1806a45e0;
    }
    fcn.18000dc80(&var_328h);
    func_0x0001800082a0(&var_4d8h);
    if (var_4d8h == iVar18) goto code_r0x0001800463e3;
    goto code_r0x000180044a90;
joined_r0x00018004624d:
    for (; (piVar15 != piVar20 && ((*piVar15 != 0x5c && (*piVar15 != 0x2f)))); piVar15 = piVar15 + 1) {
    }
    func_0x00018000d7e0(&var_300h, piVar25, (int64_t)piVar15 - (int64_t)piVar25 >> 1);
code_r0x000180046239:
    if (var_308h == iVar16) goto code_r0x000180045dd3;
    goto code_r0x000180045f50;
}

// ============================================================
// Function: FUN_180046450
// Address: 0x180046450
// Size: 519 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180046450(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t iVar10;
    uint64_t uVar11;
    undefined *puVar12;
    undefined4 uVar13;
    int64_t var_10h;
    undefined auStack_a8 [8];
    undefined auStack_a0 [24];
    int64_t var_88h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_10;
    
    uStack_10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    fcn.180043ba0((int64_t)&var_50h, arg1);
    uVar13 = fcn.1800814c0();
    fcn.180081f50(uVar13, &var_70h, &var_50h);
    if (var_60h == 0) {
        piVar9 = &var_50h;
        if (7 < (uint64_t)var_38h) {
            piVar9 = (int64_t *)var_50h;
        }
        iVar8 = func_0x000180455104(piVar9, &var_30h, 9, 0xffffffff);
        puVar12 = auStack_a8;
        if ((iVar8 != 0) || (puVar12 = auStack_a8, var_28h != 0)) goto code_r0x000180046642;
    }
    uVar13 = func_0x000180012f50();
    var_88h._0_4_ = 0;
    cVar7 = func_0x0001800131b0(uVar13, arg1, &var_70h, 0x1805aae98);
    if (cVar7 == '\0') {
        func_0x000180086510(arg1);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        puVar2 = puVar1;
        while (puVar1 + -8 < puVar2) {
            *puVar2 = puVar2[-4];
            puVar2[1] = puVar2[-3];
            puVar2[2] = puVar2[-2];
            puVar2[3] = puVar2[-1];
            puVar2 = puVar2 + -4;
        }
        puVar2 = *(undefined4 **)(arg1 + 0x40);
        uVar13 = puVar2[1];
        uVar4 = puVar2[2];
        uVar5 = puVar2[3];
        puVar1[-8] = *puVar2;
        puVar1[-7] = uVar13;
        puVar1[-6] = uVar4;
        puVar1[-5] = uVar5;
        if (0xf < (uint64_t)var_58h) {
            iVar10 = CONCAT71(var_70h._1_7_, (undefined)var_70h);
            uVar11 = var_58h + 1;
            if (0xfff < uVar11) {
                if (0x1f < (iVar10 - *(int64_t *)(iVar10 + -8)) - 8U) {
code_r0x00018004663b:
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    puVar12 = auStack_a0;
code_r0x000180046642:
                    *(undefined8 *)(puVar12 + -8) = 0x180046656;
                    fcn.180088380(arg1, 1, 0x180623130);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar11 = var_58h + 0x28;
                iVar10 = *(int64_t *)(iVar10 + -8);
            }
            fcn.180459c3c(iVar10, uVar11);
        }
        var_60h = 0;
        var_58h = 0xf;
        var_70h._0_1_ = 0;
        fcn.18000dc80(&var_50h);
    } else {
        if (0xf < (uint64_t)var_58h) {
            uVar11 = var_58h + 1;
            iVar6 = CONCAT71(var_70h._1_7_, (undefined)var_70h);
            iVar10 = iVar6;
            if (0xfff < uVar11) {
                iVar10 = *(int64_t *)(iVar6 + -8);
                if (0x1f < (iVar6 - iVar10) - 8U) goto code_r0x00018004663b;
                uVar11 = var_58h + 0x28;
            }
            fcn.180459c3c(iVar10, uVar11);
        }
        var_60h = 0;
        var_58h = 0xf;
        var_70h._0_1_ = 0;
        fcn.18000dc80(&var_50h);
    }
    fcn.180459870(uStack_10 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180046670
// Address: 0x180046670
// Size: 692 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180046670(int64_t arg1)
{
    uint32_t *puVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    undefined4 *puVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    int64_t iVar12;
    uint64_t uVar13;
    undefined *puVar14;
    undefined4 uVar15;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [8];
    undefined auStack_a0 [24];
    int64_t var_88h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_10;
    int64_t var_8h;
    
    puVar14 = auStack_a8;
    uStack_10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    fcn.180043ba0((int64_t)&var_50h, arg1);
    uVar15 = fcn.1800814c0();
    fcn.180081f50(uVar15, &var_70h, &var_50h);
    if (var_60h == 0) {
        piVar10 = &var_50h;
        if (7 < (uint64_t)var_38h) {
            piVar10 = (int64_t *)var_50h;
        }
        iVar8 = func_0x000180455104(piVar10, &var_30h, 9, 0xffffffff);
        if ((iVar8 != 0) || (var_28h != 0)) {
            fcn.180088380(arg1, 1, 0x180623130);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    }
    uVar15 = func_0x000180012f50();
    var_88h = (uint64_t)var_88h._4_4_ << 0x20;
    cVar7 = func_0x0001800131b0(uVar15, arg1, &var_70h, 0x1805aae98);
    puVar2 = *(undefined4 **)0x180782430;
    if (cVar7 == '\0') goto code_r0x000180046906;
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar9 = *(undefined4 **)(arg1 + 0x28);
    if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar9 = *(undefined4 **)0x180782430;
    }
    puVar9 = puVar9 + 4;
    if (puVar9 < puVar11) {
        do {
            puVar9[-4] = *puVar9;
            puVar9[-3] = puVar9[1];
            puVar9[-2] = puVar9[2];
            puVar9[-1] = puVar9[3];
            puVar9 = puVar9 + 4;
            puVar11 = *(undefined4 **)(arg1 + 0x40);
        } while (puVar9 < puVar11);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar11 + -4;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar9 = *(undefined4 **)(arg1 + 0x28);
    if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar9 = puVar2;
    }
    while (puVar9 < puVar11) {
        *puVar11 = puVar11[-4];
        puVar11[1] = puVar11[-3];
        puVar11[2] = puVar11[-2];
        puVar11[3] = puVar11[-1];
        puVar11 = puVar11 + -4;
    }
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    uVar15 = puVar2[1];
    uVar4 = puVar2[2];
    uVar5 = puVar2[3];
    *puVar9 = *puVar2;
    puVar9[1] = uVar15;
    puVar9[2] = uVar4;
    puVar9[3] = uVar5;
    iVar12 = *(int64_t *)(arg1 + 0x28);
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + 1;
    var_88h = 0;
    func_0x000180094080(arg1, 0x180046660, iVar12, iVar12 - *(int64_t *)(arg1 + 0x38));
    *(int16_t *)(arg1 + 0x6a) = *(int16_t *)(arg1 + 0x6a) + -1;
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    cVar7 = *(char *)(arg1 + 3);
    if (((cVar7 == '\x01') || (cVar7 == '\x06')) || (cVar7 == '\x7f')) {
        if (0xf < (uint64_t)var_58h) {
            uVar13 = var_58h + 1;
            iVar6 = CONCAT71(var_70h._1_7_, (undefined)var_70h);
            iVar12 = iVar6;
            if (0xfff < uVar13) {
                iVar12 = *(int64_t *)(iVar6 + -8);
                if (0x1f < (iVar6 - iVar12) - 8U) goto code_r0x0001800468ff;
                uVar13 = var_58h + 0x28;
            }
            fcn.180459c3c(iVar12, uVar13);
        }
        var_60h = 0;
        var_58h = 0xf;
        var_70h._0_1_ = 0;
        fcn.18000dc80(&var_50h);
    } else {
        arg1 = *(int64_t *)(arg1 + 0x28);
        if (0xf < (uint64_t)var_58h) {
            iVar12 = CONCAT71(var_70h._1_7_, (undefined)var_70h);
            uVar13 = var_58h + 1;
            if (0xfff < uVar13) {
                if (0x1f < (iVar12 - *(int64_t *)(iVar12 + -8)) - 8U) {
code_r0x0001800468ff:
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    puVar14 = auStack_a0;
code_r0x000180046906:
                    *(undefined8 *)(puVar14 + -8) = 0x18004690e;
                    fcn.180087960(arg1);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar13 = var_58h + 0x28;
                iVar12 = *(int64_t *)(iVar12 + -8);
            }
            fcn.180459c3c(iVar12, uVar13);
        }
        var_60h = 0;
        var_58h = 0xf;
        var_70h._0_1_ = 0;
        fcn.18000dc80(&var_50h);
    }
    fcn.180459870(uStack_10 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180046930
// Address: 0x180046930
// Size: 1562 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.180046930(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    undefined8 uVar6;
    undefined (*pauVar7) [16];
    undefined *puVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    uint32_t *puVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    undefined *puVar17;
    bool bVar18;
    undefined4 uVar19;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_160;
    undefined auStack_158 [8];
    undefined auStack_150 [24];
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    uint32_t uStack_d0;
    uint32_t uStack_cc;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_60h;
    undefined auStack_58 [8];
    int64_t var_50h;
    int64_t var_38h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    puVar17 = auStack_158;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_158;
    fcn.180043ba0((int64_t)&var_78h, arg1);
    uVar19 = fcn.1800814c0();
    fcn.180081f50(uVar19, &var_f8h, &var_78h);
    if (var_e8h == 0) {
        piVar9 = &var_78h;
        if (7 < (uint64_t)var_60h) {
            piVar9 = (int64_t *)var_78h;
        }
        iVar4 = func_0x000180455104(piVar9, auStack_58, 9, 0xffffffff);
        puVar8 = auStack_158;
        if ((iVar4 == 0) && (puVar8 = auStack_158, var_50h == 0)) goto code_r0x0001800469b7;
code_r0x000180046f1f:
        puVar17 = puVar8;
        *(undefined8 *)(puVar17 + -8) = 0x180046f33;
        fcn.180088380(arg1, 1, 0x1806231a0);
code_r0x000180046f34:
        *(undefined8 *)(puVar17 + -8) = 0x180046f49;
        fcn.180041fb0(0x180623124, (int64_t)(puVar17 + 0x20), (int64_t)&var_98h);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
code_r0x0001800469b7:
    func_0x00018007ff90();
    uVar6 = func_0x00018020e880();
    var_138h = (int64_t)&var_f8h;
    if (0xf < (uint64_t)var_e0h) {
        var_138h = var_f8h;
    }
    var_130h = var_e8h;
    func_0x000180081030(var_e8h, &var_b8h, &var_138h, uVar6);
    if (var_a8h == 0) {
        fcn.1800867f0(arg1, 0x1805aadb1, 0);
        if (0xf < (uint64_t)var_a0h) {
            uVar15 = var_a0h + 1;
            if (0xfff < uVar15) {
                if ((var_b8h - *(int64_t *)(var_b8h + -8)) - 8U < 0x20) {
                    uVar15 = var_a0h + 0x28;
                    var_b8h = *(int64_t *)(var_b8h + -8);
                    goto code_r0x000180046a49;
                }
code_r0x000180046eca:
                pcVar1 = (code *)swi(0x29);
                var_b8h = (*pcVar1)(5);
                puVar17 = puVar17 + 8;
                goto code_r0x000180046ed4;
            }
code_r0x000180046a49:
            fcn.180459c3c(var_b8h, uVar15);
        }
        puVar17 = auStack_158;
        if ((uint64_t)var_e0h < 0x10) goto code_r0x000180046a8c;
        uVar16 = var_e0h + 1;
        iVar13 = var_f8h;
        puVar17 = auStack_158;
        if (0xfff < uVar16) {
            iVar13 = *(int64_t *)(var_f8h + -8);
            puVar17 = auStack_158;
            if (0x1f < (var_f8h - iVar13) - 8U) {
code_r0x000180046f18:
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar8 = puVar17 + 8;
                goto code_r0x000180046f1f;
            }
            uVar16 = var_e0h + 0x28;
            puVar17 = auStack_158;
        }
    } else {
        uVar6 = func_0x0001800071a0(&var_78h, &var_38h);
        uVar6 = func_0x000180006eb0(uVar6, &var_d8h);
        piVar9 = &var_b8h;
        if (0xf < (uint64_t)var_a0h) {
            piVar9 = (int64_t *)var_b8h;
        }
        pauVar7 = (undefined (*) [16])func_0x000180018c80(uVar6, 0, piVar9, var_a8h);
        _var_118h = *pauVar7;
        var_108h = *(int64_t *)pauVar7[1];
        var_100h = *(int64_t *)(pauVar7[1] + 8);
        *(undefined8 *)pauVar7[1] = 0;
        *(undefined8 *)(pauVar7[1] + 8) = 0xf;
        (*pauVar7)[0] = 0;
        puVar17 = auStack_158;
        if (0xf < (uint64_t)var_c0h) {
            iVar12 = CONCAT44(var_d8h._4_4_, (uint32_t)var_d8h);
            iVar13 = iVar12;
            puVar17 = auStack_158;
            if ((0xfff < var_c0h + 1U) &&
               (iVar13 = *(int64_t *)(iVar12 + -8), puVar17 = auStack_158, 0x1f < (iVar12 - iVar13) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar13 = (*pcVar1)(5);
                puVar17 = auStack_150;
            }
            *(undefined8 *)(puVar17 + -8) = 0x180046b77;
            fcn.180459c3c(iVar13);
        }
        var_c8h = 0;
        var_c0h = 0xf;
        var_d8h._0_4_ = (uint32_t)var_d8h & 0xffffff00;
        *(undefined8 *)(puVar17 + -8) = 0x180046b90;
        fcn.18000dc80(&var_38h);
        puVar8 = puVar17 + 0x40;
        if (0xf < *(uint64_t *)(puVar17 + 0x58)) {
            puVar8 = *(undefined **)(puVar17 + 0x40);
        }
        *(undefined **)(puVar17 + 0x20) = puVar8;
        *(undefined8 *)(puVar17 + 0x28) = *(undefined8 *)(puVar17 + 0x50);
        *(undefined8 *)(puVar17 + -8) = 0x180046bbe;
        fcn.1800476c0(auStack_58, puVar17 + 0x20);
        *(undefined8 *)(puVar17 + -8) = 0x180046bc4;
        piVar9 = (int64_t *)fcn.1800814c0();
        iVar13 = *piVar9;
        *(undefined8 *)(puVar17 + -8) = 0x180046bd8;
        fcn.180041b00((int64_t)&var_98h, iVar13 + 0x40, (int64_t)auStack_58);
        *(undefined8 *)(puVar17 + -8) = 0x180046be2;
        fcn.18000dc80(auStack_58);
        piVar9 = &var_98h;
        if (7 < (uint64_t)var_80h) {
            piVar9 = (int64_t *)var_98h;
        }
        *(undefined8 *)(puVar17 + -8) = 0x180046c05;
        uVar5 = func_0x000180455104(piVar9, &var_d8h, 3, 0xffffffff);
        if (uVar5 == 0) {
            if (((uint32_t)var_c8h >> 10 & 1) == 0) {
code_r0x000180046c98:
                uVar14 = ((uint32_t)var_c8h >> 4 & 1) + 2;
                goto code_r0x000180046cd2;
            }
            if (var_c8h._4_4_ == -0x5ffffff4) {
                uVar14 = 4;
            } else {
                if (var_c8h._4_4_ != -0x5ffffffd) goto code_r0x000180046c98;
                uVar14 = 10;
            }
code_r0x000180046c2c:
            if (uVar14 == 1) goto code_r0x000180046c35;
code_r0x000180046d01:
            *(undefined (*) [16])(puVar17 + 0x20) = ZEXT816(0);
            *(undefined8 *)(puVar17 + 0x30) = 0;
            *(undefined8 *)(puVar17 + 0x38) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x180046d1d;
            puVar10 = (undefined4 *)fcn.180459890(0x20);
            *(undefined4 **)(puVar17 + 0x20) = puVar10;
            *(undefined8 *)(puVar17 + 0x30) = 0x14;
            *(undefined8 *)(puVar17 + 0x38) = 0x1f;
            *puVar10 = 0x61786272;
            puVar10[1] = 0x74657373;
            puVar10[2] = 0x742f2f3a;
            puVar10[3] = 0x75747865;
            puVar10[4] = 0x2f736572;
            *(undefined *)(puVar10 + 5) = 0;
            puVar8 = puVar17 + 0x40;
            if (0xf < *(uint64_t *)(puVar17 + 0x58)) {
                puVar8 = *(undefined **)(puVar17 + 0x40);
            }
            *(undefined8 *)(puVar17 + -8) = 0x180046d6b;
            puVar11 = (uint32_t *)func_0x00018000d970(puVar17 + 0x20, puVar8, *(undefined8 *)(puVar17 + 0x50));
            var_d8h._0_4_ = *puVar11;
            var_d8h._4_4_ = puVar11[1];
            uStack_d0 = puVar11[2];
            uStack_cc = puVar11[3];
            var_c8h = *(int64_t *)(puVar11 + 4);
            var_c0h = *(int64_t *)(puVar11 + 6);
            *(undefined8 *)(puVar11 + 4) = 0;
            *(undefined8 *)(puVar11 + 6) = 0xf;
            *(undefined *)puVar11 = 0;
            if (0xf < *(uint64_t *)(puVar17 + 0x38)) {
                iVar13 = *(int64_t *)(puVar17 + 0x20);
                iVar12 = iVar13;
                if ((0xfff < *(uint64_t *)(puVar17 + 0x38) + 1) &&
                   (iVar12 = *(int64_t *)(iVar13 + -8), 0x1f < (iVar13 - iVar12) - 8U)) {
                    pcVar1 = (code *)swi(0x29);
                    iVar12 = (*pcVar1)(5);
                    puVar17 = puVar17 + 8;
                }
                *(undefined8 *)(puVar17 + -8) = 0x180046dcb;
                fcn.180459c3c(iVar12);
            }
            *(undefined8 *)(puVar17 + 0x30) = 0;
            *(undefined8 *)(puVar17 + 0x38) = 0xf;
            puVar17[0x20] = 0;
            piVar9 = &var_d8h;
            if (0xf < (uint64_t)var_c0h) {
                piVar9 = (int64_t *)CONCAT44(var_d8h._4_4_, (uint32_t)var_d8h);
            }
            *(undefined8 *)(puVar17 + -8) = 0x180046df8;
            fcn.1800867f0(arg1, piVar9, var_c8h);
            if (0xf < (uint64_t)var_c0h) {
                iVar12 = CONCAT44(var_d8h._4_4_, (uint32_t)var_d8h);
                iVar13 = iVar12;
                if ((0xfff < var_c0h + 1U) && (iVar13 = *(int64_t *)(iVar12 + -8), 0x1f < (iVar12 - iVar13) - 8U)) {
                    pcVar1 = (code *)swi(0x29);
                    iVar13 = (*pcVar1)(5);
                    puVar17 = puVar17 + 8;
                }
                *(undefined8 *)(puVar17 + -8) = 0x180046e39;
                fcn.180459c3c(iVar13);
            }
        } else {
            if (uVar5 < 0x41) {
                if (((uVar5 == 0x40) || (uVar5 == 2)) || (uVar5 == 3)) goto code_r0x000180046ccd;
                bVar18 = uVar5 == 0x35;
code_r0x000180046cc7:
                if (bVar18) goto code_r0x000180046ccd;
                uVar3 = 0;
            } else {
                if ((uVar5 != 0x7b) && (uVar5 != 0xa1)) {
                    bVar18 = uVar5 == 0x10b;
                    goto code_r0x000180046cc7;
                }
code_r0x000180046ccd:
                uVar3 = 1;
            }
            uVar14 = (uint32_t)uVar3;
code_r0x000180046cd2:
            *(uint32_t *)(puVar17 + 0x20) = uVar5;
            *(undefined4 *)(puVar17 + 0x24) = *(undefined4 *)(puVar17 + 0x24);
            *(undefined8 *)(puVar17 + 0x28) = 0x1806a45e0;
            if (uVar14 != 0) goto code_r0x000180046c2c;
            if (uVar5 != 0) goto code_r0x000180046f34;
code_r0x000180046c35:
            *(undefined8 *)(puVar17 + -8) = 0x180046c3a;
            fcn.1800814c0();
            puVar8 = puVar17 + 0x60;
            if (0xf < *(uint64_t *)(puVar17 + 0x78)) {
                puVar8 = *(undefined **)(puVar17 + 0x60);
            }
            *(undefined **)(puVar17 + 0x20) = puVar8;
            *(undefined8 *)(puVar17 + 0x28) = *(undefined8 *)(puVar17 + 0x70);
            *(undefined8 *)(puVar17 + -8) = 0x180046c6b;
            cVar2 = func_0x000180082240(puVar8, &var_98h, puVar17 + 0x20, 0);
            if (cVar2 != '\0') goto code_r0x000180046d01;
            *(undefined8 *)(puVar17 + -8) = 0x180046c85;
            fcn.1800867f0(arg1, 0x1805aadb1, 0);
        }
        *(undefined8 *)(puVar17 + -8) = 0x180046e43;
        fcn.18000dc80(&var_98h);
        if (0xf < *(uint64_t *)(puVar17 + 0x58)) {
            iVar13 = *(int64_t *)(puVar17 + 0x40);
            iVar12 = iVar13;
            if ((0xfff < *(uint64_t *)(puVar17 + 0x58) + 1) &&
               (iVar12 = *(int64_t *)(iVar13 + -8), 0x1f < (iVar13 - iVar12) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar12 = (*pcVar1)(5);
                puVar17 = puVar17 + 8;
            }
            *(undefined8 *)(puVar17 + -8) = 0x180046e86;
            fcn.180459c3c(iVar12);
        }
        *(undefined8 *)(puVar17 + 0x50) = 0;
        *(undefined8 *)(puVar17 + 0x58) = 0xf;
        puVar17[0x40] = 0;
        if (0xf < (uint64_t)var_a0h) {
            if ((0xfff < var_a0h + 1U) &&
               (iVar13 = var_b8h - *(int64_t *)(var_b8h + -8), var_b8h = *(int64_t *)(var_b8h + -8), 0x1f < iVar13 - 8U)
               ) goto code_r0x000180046eca;
code_r0x000180046ed4:
            *(undefined8 *)(puVar17 + -8) = 0x180046ed9;
            fcn.180459c3c(var_b8h);
        }
        uVar15 = *(uint64_t *)(puVar17 + 0x78);
        if (uVar15 < 0x10) goto code_r0x000180046a8c;
        iVar13 = *(int64_t *)(puVar17 + 0x60);
        uVar16 = uVar15 + 1;
        if (0xfff < uVar16) {
            if (0x1f < (iVar13 - *(int64_t *)(iVar13 + -8)) - 8U) goto code_r0x000180046f18;
            uVar16 = uVar15 + 0x28;
            iVar13 = *(int64_t *)(iVar13 + -8);
        }
    }
    *(undefined8 *)(puVar17 + -8) = 0x180046a8c;
    fcn.180459c3c(iVar13, uVar16);
code_r0x000180046a8c:
    *(undefined8 *)(puVar17 + 0x70) = 0;
    *(undefined8 *)(puVar17 + 0x78) = 0xf;
    puVar17[0x60] = 0;
    *(undefined8 *)(puVar17 + -8) = 0x180046aa8;
    fcn.18000dc80(&var_78h);
    *(undefined8 *)(puVar17 + -8) = 0x180046ab9;
    fcn.180459870(uStack_18 ^ (uint64_t)puVar17);
    return;
}

// ============================================================
// Function: FUN_180046f50
// Address: 0x180046f50
// Size: 1109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_584h
// WARNING: [rz-ghidra] Detected overlap for variable var_580h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h

void fcn.180046f50(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    func_0x000180018f70();
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180043e70, 0x1806231d8, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x1806231d8);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180043c10, 0x180623210, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623210);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180043d40, 0x180623200, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623200);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180044980, 0x180623230, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623230);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.1800441a0, 0x180623220, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623220);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180043f30, 0x18062324c, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x18062324c);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.1800445a0, 0x180623240, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623240);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_48h = 0x180623260;
    func_0x0001800869f0(arg2, fcn.180044410, 0x180623258, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180623258);
    piVar4 = &var_48h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180623258);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_40h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_40h = 0x180623280;
    func_0x0001800869f0(arg2, fcn.180044740, 0x180623270, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180623270);
    piVar4 = &var_40h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180623270);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_38h);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.180046450, 0x180623298, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623298);
    var_38h = 0x180623290;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    func_0x0001800869f0(arg2, fcn.180046670, 0x1806232b4, 0, 0x18001afa0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x1806232b4);
    piVar4 = &var_38h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x1806232b4);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_30h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_30h = 0x1806232a8;
    func_0x0001800869f0(arg2, fcn.180046930, 0x1806232c0, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x1806232c0);
    piVar4 = &var_30h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x1806232c0);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_28h);
    return;
}

// ============================================================
// Function: FUN_1800473b0
// Address: 0x1800473b0
// Size: 167 bytes
// ============================================================
void fcn.1800473b0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined *puVar3;
    undefined auStack_58 [8];
    undefined auStack_50 [32];
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar3 = auStack_58;
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    var_20h = 0;
    var_18h = 0;
    _var_30h = ZEXT816(0);
    func_0x00018000d380(&var_30h, *(undefined8 *)arg2, *(undefined8 *)(arg2 + 8));
    func_0x00018000b1a0(arg1, &var_30h);
    if (7 < (uint64_t)var_18h) {
        iVar2 = var_30h;
        puVar3 = auStack_58;
        if ((0xfff < var_18h * 2 + 2U) &&
           (iVar2 = *(int64_t *)(var_30h + -8), puVar3 = auStack_58, 0x1f < (var_30h - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar3 = auStack_50;
        }
        *(undefined8 *)(puVar3 + -8) = 0x180047441;
        fcn.180459c3c(iVar2);
    }
    *(undefined8 *)(puVar3 + -8) = 0x180047451;
    fcn.180459870(*(uint64_t *)(puVar3 + 0x48) ^ (uint64_t)puVar3);
    return;
}

// ============================================================
// Function: FUN_180047460
// Address: 0x180047460
// Size: 141 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180047460(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    undefined2 *puVar3;
    undefined2 in_R8W;
    int64_t var_8h;
    int64_t in_stack_00000028;
    int64_t var_18h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if ((uint64_t)arg2 <= uVar1) {
        *(int64_t *)(arg1 + 0x10) = arg2;
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        *(undefined2 *)(arg1 + arg2 * 2) = 0;
        return;
    }
    uVar2 = arg2 - uVar1;
    if (*(uint64_t *)(arg1 + 0x18) - uVar1 < uVar2) {
        fcn.1800477b0(CONCAT62(var_18h._2_6_, in_R8W), in_stack_00000028);
        return;
    }
    *(int64_t *)(arg1 + 0x10) = arg2;
    if (7 < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    puVar3 = (undefined2 *)(arg1 + uVar1 * 2);
    if (uVar2 != 0) {
        for (; uVar2 != 0; uVar2 = uVar2 - 1) {
            *puVar3 = in_R8W;
            puVar3 = puVar3 + 1;
        }
    }
    *(undefined2 *)(arg1 + arg2 * 2) = 0;
    return;
}

// ============================================================
// Function: FUN_1800474f0
// Address: 0x1800474f0
// Size: 350 bytes
// ============================================================
int64_t fcn.1800474f0(int64_t arg1)
{
    int64_t iVar1;
    int16_t *piVar2;
    int16_t **ppiVar3;
    int16_t **ppiVar4;
    int16_t **ppiVar5;
    undefined8 *puVar6;
    int16_t **ppiVar7;
    int16_t *piVar8;
    int16_t *piVar9;
    int16_t **ppiVar10;
    
    ppiVar5 = *(int16_t ***)(arg1 + 0x28);
    puVar6 = (undefined8 *)(arg1 + 8);
    iVar1 = *(int64_t *)(arg1 + 0x18);
    ppiVar10 = ppiVar5;
    if ((int16_t *)0x7 < ppiVar5[3]) {
        ppiVar10 = (int16_t **)*ppiVar5;
    }
    ppiVar7 = *(int16_t ***)arg1;
    ppiVar4 = ppiVar5 + 2;
    piVar2 = *ppiVar4;
    if (ppiVar10 == ppiVar7) {
        piVar8 = (int16_t *)((int64_t)ppiVar7 + iVar1 * 2);
        *(int16_t **)arg1 = piVar8;
        if ((int16_t *)0x7 < ppiVar5[3]) {
            ppiVar5 = (int16_t **)*ppiVar5;
        }
        ppiVar4 = (int16_t **)((int64_t)ppiVar5 + (int64_t)*ppiVar4 * 2);
        ppiVar3 = (int16_t **)func_0x000180006c10(ppiVar5);
        for (ppiVar7 = ppiVar3; (ppiVar7 != ppiVar4 && ((*(int16_t *)ppiVar7 == 0x5c || (*(int16_t *)ppiVar7 == 0x2f))))
            ; ppiVar7 = (int16_t **)((int64_t)ppiVar7 + 2)) {
        }
        if ((ppiVar5 != ppiVar3) && (ppiVar3 != ppiVar7)) {
            func_0x00018000d7e0(puVar6, ppiVar3, (int64_t)ppiVar7 - (int64_t)ppiVar3 >> 1);
            return arg1;
        }
    } else {
        if (((*(int16_t *)ppiVar7 == 0x5c) || (*(int16_t *)ppiVar7 == 0x2f)) && (iVar1 == 0)) {
            *(int16_t **)arg1 = (int16_t *)((int64_t)ppiVar7 + 2);
            return arg1;
        }
        piVar8 = (int16_t *)((int64_t)ppiVar7 + iVar1 * 2);
        *(int16_t **)arg1 = piVar8;
    }
    piVar2 = (int16_t *)((int64_t)ppiVar10 + (int64_t)piVar2 * 2);
    if (piVar8 != piVar2) {
        do {
            piVar9 = piVar8;
            if ((*piVar9 != 0x5c) && (*piVar9 != 0x2f)) goto code_r0x000180047613;
            piVar8 = piVar9 + 1;
            *(int16_t **)arg1 = piVar8;
        } while (piVar8 != piVar2);
        *(int16_t **)arg1 = piVar9;
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    if (7 < *(uint64_t *)(arg1 + 0x20)) {
        puVar6 = (undefined8 *)*puVar6;
    }
    *(undefined2 *)puVar6 = 0;
    return arg1;
code_r0x000180047613:
    if (*piVar9 == 0x5c) {
code_r0x00018004762c:
        func_0x00018000d7e0(puVar6, *(int64_t *)arg1, (int64_t)piVar9 - *(int64_t *)arg1 >> 1);
        return arg1;
    }
    if ((*piVar9 == 0x2f) || (piVar9 = piVar9 + 1, piVar9 == piVar2)) goto code_r0x00018004762c;
    goto code_r0x000180047613;
}

// ============================================================
// Function: FUN_180047650
// Address: 0x180047650
// Size: 111 bytes
// ============================================================
uint64_t fcn.180047650(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    
    if (*(uint64_t *)arg2 < 0x1000000000000000) {
        uVar5 = *(uint64_t *)arg2 * 0x10;
        if (uVar5 == 0) {
            return 0;
        }
        if (uVar5 < 0x1000) {
            do {
                uVar4 = fcn.18046d050(uVar5);
                if (uVar4 != 0) {
                    return uVar4;
                }
                iVar2 = fcn.18047a460(uVar5);
            } while (iVar2 != 0);
            if (uVar5 == 0xffffffffffffffff) {
                fcn.180004720();
                pcVar1 = (code *)swi(3);
                uVar5 = (*pcVar1)();
                return uVar5;
            }
            fcn.180454670();
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if (uVar5 < uVar5 + 0x27) {
            iVar3 = fcn.180459890(uVar5 + 0x27);
            iVar6 = iVar3;
            if (iVar3 == 0) {
                iVar6 = 5;
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)();
            }
            uVar5 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar6;
            return uVar5;
        }
    }
    fcn.180004720();
    pcVar1 = (code *)swi(3);
    uVar5 = (*pcVar1)();
    return uVar5;
}

// ============================================================
// Function: FUN_1800476c0
// Address: 0x1800476c0
// Size: 230 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800476c0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined8 uVar5;
    int32_t extraout_var;
    int64_t iVar6;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar4 = func_0x000180454ce0();
    uVar1 = *(uint64_t *)(arg2 + 8);
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 7;
    *(undefined2 *)arg1 = 0;
    if (uVar1 != 0) {
        if (0x7fffffff < uVar1) {
            func_0x000180006180();
            pcVar3 = (code *)swi(3);
            iVar6 = (*pcVar3)();
            return iVar6;
        }
        uVar2 = *(undefined8 *)arg2;
        uVar5 = func_0x000180454d08(uVar4, uVar2, uVar1 & 0xffffffff, 0, 0);
        if ((int32_t)((uint64_t)uVar5 >> 0x20) != 0) {
            func_0x000180006560();
            pcVar3 = (code *)swi(3);
            iVar6 = (*pcVar3)();
            return iVar6;
        }
        fcn.180047460(arg1, (int64_t)(int32_t)uVar5);
        iVar6 = arg1;
        if (7 < *(uint64_t *)(arg1 + 0x18)) {
            iVar6 = *(int64_t *)arg1;
        }
        func_0x000180454d08(uVar4, uVar2, uVar1 & 0xffffffff, iVar6, (int32_t)uVar5);
        if (extraout_var != 0) {
            func_0x000180006560(extraout_var);
            pcVar3 = (code *)swi(3);
            iVar6 = (*pcVar3)();
            return iVar6;
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800477b0
// Address: 0x1800477b0
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800477b0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_68h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    uint64_t uVar10;
    undefined2 *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar10 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar3 < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar8 = iVar3 + arg2;
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = uVar8 | 7;
    if ((uVar7 < 0x7fffffffffffffff) && (uVar4 <= 0x7ffffffffffffffe - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar10 = uVar7;
        if (uVar7 < uVar2) {
            uVar10 = uVar2;
        }
        if (0x7fffffffffffffff < uVar10 + 1) goto code_r0x000180047954;
        uVar7 = (uVar10 + 1) * 2;
        if (uVar7 != 0) goto code_r0x00018004784a;
        unaff_RSI = 0;
code_r0x000180047887:
        *(uint64_t *)(arg1 + 0x18) = uVar10;
        *(uint64_t *)(arg1 + 0x10) = uVar8;
        puVar11 = (undefined2 *)(iVar3 * 2 + unaff_RSI);
        if (uVar4 < 8) {
            fcn.180498030(unaff_RSI, arg1);
            iVar6 = arg4;
            if (arg4 != 0) {
                for (; iVar6 != 0; iVar6 = iVar6 + -1) {
                    *puVar11 = (undefined2)arg_28h;
                    puVar11 = puVar11 + 1;
                }
            }
            *(undefined2 *)(unaff_RSI + (iVar3 + arg4) * 2) = 0;
            goto code_r0x00018004792a;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RSI, uVar8);
        iVar6 = arg4;
        if (arg4 != 0) {
            for (; iVar6 != 0; iVar6 = iVar6 + -1) {
                *puVar11 = (undefined2)arg_28h;
                puVar11 = puVar11 + 1;
            }
        }
        *(undefined2 *)(unaff_RSI + (iVar3 + arg4) * 2) = 0;
        if (0xfff < uVar4 * 2 + 2) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 * 2 + 0x29);
                goto code_r0x00018004792a;
            }
            goto code_r0x0001800478f7;
        }
    } else {
        uVar7 = 0xfffffffffffffffe;
code_r0x00018004784a:
        if (uVar7 < 0x1000) {
            unaff_RSI = fcn.180459890();
            goto code_r0x000180047887;
        }
        if (uVar7 + 0x27 <= uVar7) {
code_r0x000180047954:
            fcn.180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar6 = fcn.180459890(uVar7 + 0x27);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x000180047887;
        }
code_r0x0001800478f7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x180047906;
    fcn.180459c3c(uVar8);
code_r0x00018004792a:
    *(uint64_t *)arg1 = unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_1800477e1
// Address: 0x1800477e1
// Size: 365 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800477b0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_68h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    uint64_t uVar10;
    undefined2 *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar10 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar3 < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar8 = iVar3 + arg2;
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = uVar8 | 7;
    if ((uVar7 < 0x7fffffffffffffff) && (uVar4 <= 0x7ffffffffffffffe - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar10 = uVar7;
        if (uVar7 < uVar2) {
            uVar10 = uVar2;
        }
        if (0x7fffffffffffffff < uVar10 + 1) goto code_r0x000180047954;
        uVar7 = (uVar10 + 1) * 2;
        if (uVar7 != 0) goto code_r0x00018004784a;
        unaff_RSI = 0;
code_r0x000180047887:
        *(uint64_t *)(arg1 + 0x18) = uVar10;
        *(uint64_t *)(arg1 + 0x10) = uVar8;
        puVar11 = (undefined2 *)(iVar3 * 2 + unaff_RSI);
        if (uVar4 < 8) {
            fcn.180498030(unaff_RSI, arg1);
            iVar6 = arg4;
            if (arg4 != 0) {
                for (; iVar6 != 0; iVar6 = iVar6 + -1) {
                    *puVar11 = (undefined2)arg_28h;
                    puVar11 = puVar11 + 1;
                }
            }
            *(undefined2 *)(unaff_RSI + (iVar3 + arg4) * 2) = 0;
            goto code_r0x00018004792a;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RSI, uVar8);
        iVar6 = arg4;
        if (arg4 != 0) {
            for (; iVar6 != 0; iVar6 = iVar6 + -1) {
                *puVar11 = (undefined2)arg_28h;
                puVar11 = puVar11 + 1;
            }
        }
        *(undefined2 *)(unaff_RSI + (iVar3 + arg4) * 2) = 0;
        if (0xfff < uVar4 * 2 + 2) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 * 2 + 0x29);
                goto code_r0x00018004792a;
            }
            goto code_r0x0001800478f7;
        }
    } else {
        uVar7 = 0xfffffffffffffffe;
code_r0x00018004784a:
        if (uVar7 < 0x1000) {
            unaff_RSI = fcn.180459890();
            goto code_r0x000180047887;
        }
        if (uVar7 + 0x27 <= uVar7) {
code_r0x000180047954:
            fcn.180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar6 = fcn.180459890(uVar7 + 0x27);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x000180047887;
        }
code_r0x0001800478f7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x180047906;
    fcn.180459c3c(uVar8);
code_r0x00018004792a:
    *(uint64_t *)arg1 = unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_18004794e
// Address: 0x18004794e
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800477b0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_68h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    uint64_t uVar10;
    undefined2 *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar10 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar3 < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar8 = iVar3 + arg2;
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = uVar8 | 7;
    if ((uVar7 < 0x7fffffffffffffff) && (uVar4 <= 0x7ffffffffffffffe - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar10 = uVar7;
        if (uVar7 < uVar2) {
            uVar10 = uVar2;
        }
        if (0x7fffffffffffffff < uVar10 + 1) goto code_r0x000180047954;
        uVar7 = (uVar10 + 1) * 2;
        if (uVar7 != 0) goto code_r0x00018004784a;
        unaff_RSI = 0;
code_r0x000180047887:
        *(uint64_t *)(arg1 + 0x18) = uVar10;
        *(uint64_t *)(arg1 + 0x10) = uVar8;
        puVar11 = (undefined2 *)(iVar3 * 2 + unaff_RSI);
        if (uVar4 < 8) {
            fcn.180498030(unaff_RSI, arg1);
            iVar6 = arg4;
            if (arg4 != 0) {
                for (; iVar6 != 0; iVar6 = iVar6 + -1) {
                    *puVar11 = (undefined2)arg_28h;
                    puVar11 = puVar11 + 1;
                }
            }
            *(undefined2 *)(unaff_RSI + (iVar3 + arg4) * 2) = 0;
            goto code_r0x00018004792a;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RSI, uVar8);
        iVar6 = arg4;
        if (arg4 != 0) {
            for (; iVar6 != 0; iVar6 = iVar6 + -1) {
                *puVar11 = (undefined2)arg_28h;
                puVar11 = puVar11 + 1;
            }
        }
        *(undefined2 *)(unaff_RSI + (iVar3 + arg4) * 2) = 0;
        if (0xfff < uVar4 * 2 + 2) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 * 2 + 0x29);
                goto code_r0x00018004792a;
            }
            goto code_r0x0001800478f7;
        }
    } else {
        uVar7 = 0xfffffffffffffffe;
code_r0x00018004784a:
        if (uVar7 < 0x1000) {
            unaff_RSI = fcn.180459890();
            goto code_r0x000180047887;
        }
        if (uVar7 + 0x27 <= uVar7) {
code_r0x000180047954:
            fcn.180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar6 = fcn.180459890(uVar7 + 0x27);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x000180047887;
        }
code_r0x0001800478f7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x180047906;
    fcn.180459c3c(uVar8);
code_r0x00018004792a:
    *(uint64_t *)arg1 = unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_180047954
// Address: 0x180047954
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800477b0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_68h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RSI;
    uint64_t uVar10;
    undefined2 *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar10 = 0x7ffffffffffffffe;
    if (0x7ffffffffffffffeU - iVar3 < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar8 = iVar3 + arg2;
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = uVar8 | 7;
    if ((uVar7 < 0x7fffffffffffffff) && (uVar4 <= 0x7ffffffffffffffe - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar10 = uVar7;
        if (uVar7 < uVar2) {
            uVar10 = uVar2;
        }
        if (0x7fffffffffffffff < uVar10 + 1) goto code_r0x000180047954;
        uVar7 = (uVar10 + 1) * 2;
        if (uVar7 != 0) goto code_r0x00018004784a;
        unaff_RSI = 0;
code_r0x000180047887:
        *(uint64_t *)(arg1 + 0x18) = uVar10;
        *(uint64_t *)(arg1 + 0x10) = uVar8;
        puVar11 = (undefined2 *)(iVar3 * 2 + unaff_RSI);
        if (uVar4 < 8) {
            fcn.180498030(unaff_RSI, arg1);
            iVar6 = arg4;
            if (arg4 != 0) {
                for (; iVar6 != 0; iVar6 = iVar6 + -1) {
                    *puVar11 = (undefined2)arg_28h;
                    puVar11 = puVar11 + 1;
                }
            }
            *(undefined2 *)(unaff_RSI + (iVar3 + arg4) * 2) = 0;
            goto code_r0x00018004792a;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RSI, uVar8);
        iVar6 = arg4;
        if (arg4 != 0) {
            for (; iVar6 != 0; iVar6 = iVar6 + -1) {
                *puVar11 = (undefined2)arg_28h;
                puVar11 = puVar11 + 1;
            }
        }
        *(undefined2 *)(unaff_RSI + (iVar3 + arg4) * 2) = 0;
        if (0xfff < uVar4 * 2 + 2) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                fcn.180459c3c(*piVar1, uVar4 * 2 + 0x29);
                goto code_r0x00018004792a;
            }
            goto code_r0x0001800478f7;
        }
    } else {
        uVar7 = 0xfffffffffffffffe;
code_r0x00018004784a:
        if (uVar7 < 0x1000) {
            unaff_RSI = fcn.180459890();
            goto code_r0x000180047887;
        }
        if (uVar7 + 0x27 <= uVar7) {
code_r0x000180047954:
            fcn.180004720();
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar6 = fcn.180459890(uVar7 + 0x27);
        if (iVar6 != 0) {
            unaff_RSI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RSI - 8) = iVar6;
            goto code_r0x000180047887;
        }
code_r0x0001800478f7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x180047906;
    fcn.180459c3c(uVar8);
code_r0x00018004792a:
    *(uint64_t *)arg1 = unaff_RSI;
    return;
}

// ============================================================
// Function: FUN_180047960
// Address: 0x180047960
// Size: 161 bytes
// ============================================================
int64_t fcn.180047960(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_38h)
{
    int32_t *piVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int64_t var_8h;
    
    *(undefined4 *)(arg1 + 8) = 2;
    *(undefined8 *)arg1 = 0x180623918;
    *(undefined8 *)(arg1 + 0x48) = 0;
    puVar2 = *(undefined8 **)(arg2 + 0x38);
    if (puVar2 != (undefined8 *)0x0) {
        uVar3 = (**(code **)*puVar2)(puVar2, arg1 + 0x10);
        *(undefined8 *)(arg1 + 0x48) = uVar3;
    }
    *(int64_t *)(arg1 + 0x50) = arg_28h;
    *(int64_t *)(arg1 + 0x58) = arg3;
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0;
    if (*(int64_t *)(arg4 + 8) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg4 + 8) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    *(undefined8 *)(arg1 + 0x60) = *(undefined8 *)arg4;
    *(undefined8 *)(arg1 + 0x68) = *(undefined8 *)(arg4 + 8);
    *(undefined *)(arg1 + 0x70) = (undefined)arg_30h;
    *(undefined4 *)(arg1 + 8) = 1;
    return arg1;
}

// ============================================================
// Function: FUN_180047a10
// Address: 0x180047a10
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180047a10(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t var_10h;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    piVar5 = (int64_t *)fcn.180008740();
    iVar1 = *(int64_t *)(**(int64_t **)(arg1 + 0x60) + 0x28);
    if ((iVar1 != 0) && (*(int64_t *)(*piVar5 + 0x18) == *(int64_t *)(arg1 + 0x50))) {
        piVar2 = *(int64_t **)(arg1 + 0x48);
        var_38h = iVar1;
        if (piVar2 == (int64_t *)0x0) {
            fcn.180454690();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        iVar4 = (**(code **)(*piVar2 + 0x10))(piVar2, &var_38h);
        var_20h = 0;
        _var_30h = ZEXT816(0);
        if (iVar4 != -1) {
            var_48h._0_1_ = *(char *)(arg1 + 0x70);
            var_40h = 0;
            if ((char)var_48h != '\0') {
                iVar4 = 0;
            }
            (**(code **)0x180782530)
                      (*(int64_t *)(*piVar5 + 0x20) + 0x7f8, &var_30h, *(undefined8 *)(arg1 + 0x60), iVar4);
        }
    }
    fcn.180459870(var_18h ^ (uint64_t)auStack_68);
    return;
}

// ============================================================
// Function: FUN_180047ae0
// Address: 0x180047ae0
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180047ae0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar4 = *(int64_t **)(arg1 + 0x68);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x48);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x10));
        *(undefined8 *)(arg1 + 0x48) = 0;
    }
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x78);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180047ae6
// Address: 0x180047ae6
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180047ae0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar4 = *(int64_t **)(arg1 + 0x68);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x48);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x10));
        *(undefined8 *)(arg1 + 0x48) = 0;
    }
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x78);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180047afe
// Address: 0x180047afe
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180047ae0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar4 = *(int64_t **)(arg1 + 0x68);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x48);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x10));
        *(undefined8 *)(arg1 + 0x48) = 0;
    }
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x78);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180047b34
// Address: 0x180047b34
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180047ae0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar4 = *(int64_t **)(arg1 + 0x68);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x48);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x10));
        *(undefined8 *)(arg1 + 0x48) = 0;
    }
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x78);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180047b65
// Address: 0x180047b65
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180047ae0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar4 = *(int64_t **)(arg1 + 0x68);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x48);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x10));
        *(undefined8 *)(arg1 + 0x48) = 0;
    }
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x78);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180047b80
// Address: 0x180047b80
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180047b80(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = *(uint64_t *)(arg1 + 0x10);
    uVar3 = 7;
    if (uVar5 < 7) {
        uVar3 = uVar5;
    }
    iVar2 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar2 = *(int64_t *)arg1;
    }
    uVar4 = uVar3;
    if (7 < uVar3) {
        uVar4 = 7;
    }
    iVar1 = func_0x000180497f30(iVar2, 0x1806237a8, uVar4);
    if ((iVar1 != 0) || (uVar3 != 7)) {
        uVar3 = 8;
        if (uVar5 < 8) {
            uVar3 = uVar5;
        }
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        uVar5 = uVar3;
        if (8 < uVar3) {
            uVar5 = 8;
        }
        iVar1 = func_0x000180497f30(arg1, 0x180623770, uVar5);
        if ((iVar1 != 0) || (uVar3 != 8)) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180047c30
// Address: 0x180047c30
// Size: 1280 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch

void fcn.180047c30(int64_t arg1)
{
    uint32_t *puVar1;
    int32_t *piVar2;
    uint32_t uVar3;
    code *pcVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    undefined *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_148 [8];
    undefined auStack_140 [24];
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    undefined8 uStack_98;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar12 = auStack_148;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_148;
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x0001800480f5;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
    }
    iVar9 = *piVar11 + 0x18;
    if (iVar9 == 0) goto code_r0x0001800480f5;
    uVar3 = *(uint32_t *)(*piVar11 + 0x14);
    uVar15 = (uint64_t)uVar3;
    _var_a0h = ZEXT816(0);
    var_90h = 0;
    var_88h = 0;
    if (0xf < uVar15) {
        uVar13 = uVar15 | 0xf;
        if (uVar13 < 0x16) {
            uVar13 = 0x16;
        }
        if (uVar13 + 1 < 0x1000) {
            piVar11 = (int64_t *)fcn.180459890();
code_r0x000180047d80:
            var_a0h = (int64_t)piVar11;
            var_90h = uVar15;
            var_88h = uVar13;
            fcn.180498030(piVar11, iVar9, uVar15);
            *(undefined *)(uVar15 + (int64_t)piVar11) = 0;
            goto code_r0x000180047d9e;
        }
        if (uVar13 + 1 < uVar13 + 0x28) {
            iVar8 = fcn.180459890(uVar13 + 0x28);
            if (iVar8 != 0) {
                piVar11 = (int64_t *)(iVar8 + 0x27U & 0xffffffffffffffe0);
                piVar11[-1] = iVar8;
                goto code_r0x000180047d80;
            }
code_r0x000180048099:
            pcVar4 = (code *)swi(0x29);
            iVar9 = (*pcVar4)(5);
            puVar12 = auStack_140;
code_r0x0001800480a3:
            *(undefined8 *)(puVar12 + -8) = 0x1800480a8;
            fcn.180459c3c(iVar9);
code_r0x0001800480a8:
            *(undefined8 *)(puVar12 + -8) = 0x1800480b9;
            fcn.180459870(var_38h ^ (uint64_t)puVar12);
            return;
        }
        fcn.180004720();
code_r0x00018004810f:
        func_0x00018045f7d4();
code_r0x000180048115:
        func_0x000180093000(arg1, 0x18063e070);
        auVar6 = _var_108h;
code_r0x000180048125:
        _var_108h = auVar6;
        func_0x0001804542e8(1);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_88h = 0xf;
    var_90h = uVar15;
    fcn.180498030(&var_a0h, iVar9, uVar3);
    *(undefined *)((int64_t)&var_a0h + uVar15) = 0;
    uVar15 = var_90h;
    uVar13 = var_88h;
    piVar11 = (int64_t *)var_a0h;
code_r0x000180047d9e:
    uVar16 = 7;
    if (uVar15 < 7) {
        uVar16 = uVar15;
    }
    piVar10 = &var_a0h;
    if (0xf < uVar13) {
        piVar10 = piVar11;
    }
    uVar14 = uVar16;
    if (7 < uVar16) {
        uVar14 = 7;
    }
    iVar7 = func_0x000180497f30(piVar10, 0x1806237a8, uVar14);
    if ((iVar7 == 0) && (uVar16 == 7)) {
code_r0x000180047e1c:
        func_0x0001800205e0(&var_e8h, arg1);
        piVar11 = (int64_t *)fcn.180008740();
        iVar9 = *(int64_t *)(*piVar11 + 0x18);
        func_0x0001800137d0();
        var_d8h = iVar9;
        func_0x00018000b4d0(&var_d0h, &var_a0h);
        if (var_e0h != 0) {
            LOCK();
            *(int32_t *)(var_e0h + 8) = *(int32_t *)(var_e0h + 8) + 1;
            UNLOCK();
        }
        var_b0h = var_e8h;
        var_a8h = var_e0h;
        var_f0h = (int64_t)&var_d8h;
        iVar9 = func_0x00018045838c();
        var_78h = var_d8h;
        func_0x00018000b4d0(&var_70h, &var_d0h);
        if (var_a8h != 0) {
            LOCK();
            *(int32_t *)(var_a8h + 8) = *(int32_t *)(var_a8h + 8) + 1;
            UNLOCK();
        }
        var_50h = var_b0h;
        var_48h = var_a8h;
        _var_108h = ZEXT816(0);
        var_40h = iVar9;
        var_f8h = fcn.180459890();
        *(undefined4 *)var_f8h = 1;
        *(undefined4 *)(var_f8h + 4) = 2;
        *(undefined8 *)(var_f8h + 8) = 0;
        *(undefined8 *)(var_f8h + 0x10) = 0;
        *(undefined4 *)(var_f8h + 0x18) = 0;
        piVar11 = (int64_t *)fcn.180459890(0x40);
        *piVar11 = var_78h;
        var_118h = (int64_t)piVar11;
        func_0x00018000b4d0(piVar11 + 1, &var_70h);
        piVar11[5] = var_50h;
        piVar11[6] = var_48h;
        var_50h = 0;
        var_48h = 0;
        piVar11[7] = var_40h;
        var_118h = (int64_t)piVar11;
        var_120h = (int64_t)&var_100h;
        var_128h._0_4_ = 0;
        iVar9 = func_0x00018045f6e8(0, 0, 0x18004a630, piVar11);
        auVar5 = _var_108h;
        var_108h = iVar9;
        auVar6 = _var_108h;
        var_100h._4_4_ = auVar5._12_4_;
        if (iVar9 != 0) {
            var_100h._0_4_ = auVar5._8_4_;
            if ((int32_t)var_100h == 0) goto code_r0x000180048125;
            var_110h._0_4_ = (int32_t)var_100h;
            var_118h = iVar9;
            var_110h._4_4_ = var_100h._4_4_;
            _var_108h = auVar6;
            iVar7 = func_0x000180454a0c(&var_118h);
            auVar6 = _var_108h;
            if (iVar7 != 0) goto code_r0x000180048125;
            _var_118h = ZEXT816(0);
            _var_108h = ZEXT812(0);
            var_100h._4_4_ = 0;
            if (var_f8h != 0) {
                LOCK();
                puVar1 = (uint32_t *)(var_f8h + 4);
                uVar3 = *puVar1;
                *puVar1 = *puVar1 - 2;
                UNLOCK();
                if ((uVar3 & 0xfffffffe) == 2) {
                    LOCK();
                    iVar7 = *(int32_t *)var_f8h;
                    *(int32_t *)var_f8h = *(int32_t *)var_f8h + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                        fcn.180459c3c(var_f8h, 0x20);
                    }
                }
            }
            if ((int32_t)var_100h != 0) goto code_r0x00018004810f;
            func_0x000180004e40(&var_70h);
            func_0x000180048130(&var_d8h);
            if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
                *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg1 + 0x40) + -0x10;
                *(undefined *)(arg1 + 3) = 1;
                if (var_e0h != 0) {
                    LOCK();
                    piVar2 = (int32_t *)(var_e0h + 8);
                    iVar7 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                        (***(code ***)var_e0h)(var_e0h);
                        LOCK();
                        piVar2 = (int32_t *)(var_e0h + 0xc);
                        iVar7 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar7 == 1) {
                            (**(code **)(*(int64_t *)var_e0h + 8))(var_e0h);
                        }
                    }
                }
                if ((uint64_t)var_88h < 0x10) goto code_r0x0001800480a8;
                iVar9 = var_a0h;
                puVar12 = auStack_148;
                if ((0xfff < var_88h + 1U) &&
                   (iVar9 = *(int64_t *)(var_a0h + -8), puVar12 = auStack_148, 0x1f < (var_a0h - iVar9) - 8U))
                goto code_r0x000180048099;
                goto code_r0x0001800480a3;
            }
            goto code_r0x000180048115;
        }
        _var_108h = ZEXT812(0);
        func_0x0001804542e8(6);
    } else {
        uVar16 = 8;
        if (uVar15 < 8) {
            uVar16 = uVar15;
        }
        piVar10 = &var_a0h;
        if (0xf < uVar13) {
            piVar10 = piVar11;
        }
        uVar15 = uVar16;
        if (8 < uVar16) {
            uVar15 = 8;
        }
        iVar7 = func_0x000180497f30(piVar10, 0x180623770, uVar15);
        if ((iVar7 == 0) && (uVar16 == 8)) goto code_r0x000180047e1c;
    }
    fcn.180088560(arg1, 0x180623780);
code_r0x0001800480f5:
    func_0x000180088470(arg1, 2, 6);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_180048130
// Address: 0x180048130
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180048130(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)(arg1 + 0x30);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    if (0xf < *(uint64_t *)(arg1 + 0x20)) {
        iVar4 = *(int64_t *)(arg1 + 8);
        iVar7 = iVar4;
        puVar8 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x20) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_28, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_20;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        fcn.180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 8) = 0;
    return;
}

// ============================================================
// Function: FUN_180048146
// Address: 0x180048146
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180048130(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)(arg1 + 0x30);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    if (0xf < *(uint64_t *)(arg1 + 0x20)) {
        iVar4 = *(int64_t *)(arg1 + 8);
        iVar7 = iVar4;
        puVar8 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x20) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_28, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_20;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        fcn.180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 8) = 0;
    return;
}

// ============================================================
// Function: FUN_18004817c
// Address: 0x18004817c
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180048130(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)(arg1 + 0x30);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    if (0xf < *(uint64_t *)(arg1 + 0x20)) {
        iVar4 = *(int64_t *)(arg1 + 8);
        iVar7 = iVar4;
        puVar8 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x20) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_28, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_20;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        fcn.180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 8) = 0;
    return;
}

// ============================================================
// Function: FUN_180048190
// Address: 0x180048190
// Size: 2300 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ech

void fcn.180048190(int64_t arg1)
{
    uint32_t *puVar1;
    int32_t *piVar2;
    uint32_t uVar3;
    code *pcVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    int32_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined *puVar15;
    undefined *puVar16;
    undefined *puVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    undefined8 uStack_240;
    undefined auStack_238 [8];
    undefined auStack_230 [24];
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1a8h;
    int64_t var_188h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    undefined8 uStack_130;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    undefined8 uStack_110;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_b0h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar17 = auStack_238;
    puVar15 = auStack_238;
    puVar16 = auStack_238;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_238;
    piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x000180048a37;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
    }
    piVar14 = *(int64_t **)0x180782430;
    iVar10 = *piVar11 + 0x18;
    if (iVar10 == 0) goto code_r0x000180048a37;
    uVar3 = *(uint32_t *)(*piVar11 + 0x14);
    uVar19 = (uint64_t)uVar3;
    _var_138h = ZEXT816(0);
    var_128h = 0;
    var_120h = 0;
    if (0xf < uVar19) {
        uVar13 = uVar19 | 0xf;
        if (uVar13 < 0x16) {
            uVar13 = 0x16;
        }
        if (uVar13 + 1 < 0x1000) {
            piVar11 = (int64_t *)fcn.180459890();
code_r0x0001800482e7:
            var_138h = (int64_t)piVar11;
            var_128h = uVar19;
            var_120h = uVar13;
            fcn.180498030(piVar11, iVar10, uVar19);
            *(undefined *)(uVar19 + (int64_t)piVar11) = 0;
            piVar14 = *(int64_t **)0x180782430;
            goto code_r0x00018004830c;
        }
        if (uVar13 + 0x28 <= uVar13 + 1) {
            fcn.180004720();
            goto code_r0x000180048a51;
        }
        iVar8 = fcn.180459890(uVar13 + 0x28);
        if (iVar8 != 0) {
            piVar11 = (int64_t *)(iVar8 + 0x27U & 0xffffffffffffffe0);
            piVar11[-1] = iVar8;
            goto code_r0x0001800482e7;
        }
code_r0x0001800489e1:
        pcVar4 = (code *)swi(0x29);
        iVar10 = (*pcVar4)(5);
        puVar16 = puVar17 + 8;
code_r0x0001800489eb:
        *(undefined8 *)(puVar16 + -8) = 0x1800489f0;
        fcn.180459c3c(iVar10);
code_r0x0001800489f0:
        *(undefined8 *)(puVar16 + -8) = 0x180048a04;
        fcn.180459870(var_58h ^ (uint64_t)puVar16);
        return;
    }
    var_120h = 0xf;
    var_128h = uVar19;
    fcn.180498030(&var_138h, iVar10, uVar3);
    *(undefined *)((int64_t)&var_138h + uVar19) = 0;
    uVar19 = var_128h;
    uVar13 = var_120h;
    piVar11 = (int64_t *)var_138h;
code_r0x00018004830c:
    uVar20 = 7;
    if (uVar19 < 7) {
        uVar20 = uVar19;
    }
    piVar9 = &var_138h;
    if (0xf < uVar13) {
        piVar9 = piVar11;
    }
    uVar18 = uVar20;
    if (7 < uVar20) {
        uVar18 = 7;
    }
    iVar7 = func_0x000180497f30(piVar9, 0x1806237a8, uVar18);
    if ((iVar7 == 0) && (uVar20 == 7)) {
code_r0x00018004838a:
        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
            piVar11 = piVar14;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar7 = func_0x0001800a8360(arg1);
            if (iVar7 == 0) goto code_r0x000180048a51;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            piVar14 = *(int64_t **)0x180782430;
            if (*(int64_t **)(arg1 + 0x40) <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        iVar10 = *piVar11 + 0x18;
        if (iVar10 == 0) {
code_r0x000180048a51:
            func_0x000180088470(arg1, 3, 6);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        uVar3 = *(uint32_t *)(*piVar11 + 0x14);
        uVar19 = (uint64_t)uVar3;
        _var_118h = ZEXT816(0);
        var_108h = 0;
        var_100h = 0;
        if (uVar19 < 0x10) {
            var_100h = 0xf;
            var_108h = uVar19;
            fcn.180498030(&var_118h, iVar10, uVar3);
            *(undefined *)((int64_t)&var_118h + uVar19) = 0;
code_r0x0001800484c2:
            var_e8h = 0;
            var_e0h = 0xf;
            stack0xffffffffffffff09 = SUB1615(ZEXT816(0), 1);
            auVar5[15] = 0;
            auVar5._0_15_ = stack0xffffffffffffff09;
            _var_f8h = auVar5 << 8;
            piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar11 <= piVar12) {
                piVar9 = piVar14;
            }
            if ((piVar9 == piVar14) ||
               ((*(int32_t *)((int64_t)piVar9 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar9 + 0xc) != 3)))) {
                if (piVar11 <= piVar12) {
                    piVar12 = piVar14;
                }
                if (((piVar12 != piVar14) && (*(int32_t *)((int64_t)piVar12 + 0xc) == 1)) &&
                   (iVar7 = func_0x000180085dd0(arg1, 5), iVar7 != 0)) {
                    func_0x0001800860c0(arg1, 5, &var_208h);
                    goto code_r0x00018004858a;
                }
            } else {
                if (piVar11 <= piVar12) {
                    piVar12 = piVar14;
                }
                if (*(int32_t *)((int64_t)piVar12 + 0xc) != 6) {
                    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                    }
                    iVar7 = func_0x0001800a8360(arg1);
                    if ((iVar7 != 0) &&
                       (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <=
                        *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))) {
                        (**(code **)0x180782658)(arg1, 1);
                    }
                }
code_r0x00018004858a:
                var_148h = 0;
                var_140h = 0xf;
                stack0xfffffffffffffea9 = SUB1615(ZEXT816(0), 1);
                auVar6[15] = 0;
                auVar6._0_15_ = stack0xfffffffffffffea9;
                _var_158h = auVar6 << 8;
                var_e8h = 0;
                var_e0h = 0xf;
                _var_f8h = ZEXT816(0);
            }
            func_0x0001800205e0(&var_1e8h, arg1);
            piVar11 = (int64_t *)fcn.180008740();
            iVar10 = *(int64_t *)(*piVar11 + 0x18);
            func_0x0001800137d0();
            var_208h = (int64_t)&var_1d0h;
            var_1d0h = iVar10;
            func_0x00018000b4d0(&var_1c8h, &var_138h);
            func_0x00018000b4d0(&var_1a8h, &var_118h);
            func_0x00018000b4d0(&var_188h, &var_f8h);
            if (var_1e0h != 0) {
                LOCK();
                *(int32_t *)(var_1e0h + 8) = *(int32_t *)(var_1e0h + 8) + 1;
                UNLOCK();
            }
            var_168h = var_1e8h;
            var_160h = var_1e0h;
            var_208h = (int64_t)&var_1d0h;
            iVar10 = func_0x00018045838c();
            var_1d8h = (int64_t)&var_d8h;
            var_d8h = var_1d0h;
            func_0x00018000b4d0(&var_d0h, &var_1c8h);
            func_0x00018000b4d0(&var_b0h, &var_1a8h);
            func_0x00018000b4d0(&var_90h, &var_188h);
            if (var_160h != 0) {
                LOCK();
                *(int32_t *)(var_160h + 8) = *(int32_t *)(var_160h + 8) + 1;
                UNLOCK();
            }
            var_70h = var_168h;
            var_68h = var_160h;
            _var_158h = ZEXT816(0);
            var_60h = iVar10;
            var_148h = fcn.180459890();
            *(undefined4 *)var_148h = 1;
            *(undefined4 *)(var_148h + 4) = 2;
            *(undefined8 *)(var_148h + 8) = 0;
            *(undefined8 *)(var_148h + 0x10) = 0;
            *(undefined4 *)(var_148h + 0x18) = 0;
            piVar11 = (int64_t *)fcn.180459890(0x80);
            *piVar11 = var_d8h;
            var_1d8h = (int64_t)piVar11;
            var_1f8h = (int64_t)piVar11;
            func_0x00018000b4d0(piVar11 + 1, &var_d0h);
            func_0x00018000b4d0(piVar11 + 5, &var_b0h);
            *(undefined (*) [16])(piVar11 + 9) = ZEXT816(0);
            piVar11[0xb] = 0;
            piVar11[0xc] = 0;
            piVar11[9] = CONCAT71(var_90h._1_7_, (undefined)var_90h);
            piVar11[10] = var_88h;
            piVar11[0xb] = var_80h;
            piVar11[0xc] = var_78h;
            var_80h = 0;
            var_78h = 0xf;
            var_90h._0_1_ = 0;
            piVar11[0xd] = 0;
            piVar11[0xe] = 0;
            piVar11[0xd] = var_70h;
            piVar11[0xe] = var_68h;
            var_70h = 0;
            var_68h = 0;
            piVar11[0xf] = var_60h;
            var_1f8h = (int64_t)piVar11;
            var_210h = (int64_t)&var_150h;
            var_218h._0_4_ = 0;
            iVar10 = func_0x00018045f6e8(0, 0, 0x18004a8e0, piVar11);
            auVar5 = _var_158h;
            var_158h = iVar10;
            auVar6 = _var_158h;
            var_150h._4_4_ = auVar5._12_4_;
            if (iVar10 == 0) {
                _var_158h = ZEXT812(0);
                func_0x0001804542e8(6);
                goto code_r0x000180048a27;
            }
            var_150h._0_4_ = auVar5._8_4_;
            if ((int32_t)var_150h == 0) goto code_r0x000180048a81;
            var_1f0h._0_4_ = (int32_t)var_150h;
            var_1f8h = iVar10;
            var_1f0h._4_4_ = var_150h._4_4_;
            _var_158h = auVar6;
            iVar7 = func_0x000180454a0c(&var_1f8h);
            auVar6 = _var_158h;
            if (iVar7 != 0) goto code_r0x000180048a81;
            _var_1f8h = ZEXT816(0);
            _var_158h = ZEXT812(0);
            var_150h._4_4_ = 0;
            if (var_148h != 0) {
                LOCK();
                puVar1 = (uint32_t *)(var_148h + 4);
                uVar3 = *puVar1;
                *puVar1 = *puVar1 - 2;
                UNLOCK();
                if ((uVar3 & 0xfffffffe) == 2) {
                    LOCK();
                    iVar7 = *(int32_t *)var_148h;
                    *(int32_t *)var_148h = *(int32_t *)var_148h + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                        fcn.180459c3c(var_148h, 0x20);
                    }
                }
            }
            iVar10 = var_68h;
            if ((int32_t)var_150h != 0) goto code_r0x000180048a6b;
            if (var_68h != 0) {
                LOCK();
                piVar2 = (int32_t *)(var_68h + 8);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (***(code ***)var_68h)(var_68h);
                    LOCK();
                    piVar2 = (int32_t *)(iVar10 + 0xc);
                    iVar7 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                        (**(code **)(*(int64_t *)iVar10 + 8))(iVar10);
                    }
                }
            }
            func_0x000180004e40(&var_90h);
            func_0x000180004e40(&var_b0h);
            func_0x000180004e40(&var_d0h);
            func_0x000180048a90(&var_1d0h);
            if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
                *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg1 + 0x40) + -0x10;
                *(undefined *)(arg1 + 3) = 1;
                if (var_1e0h != 0) {
                    LOCK();
                    piVar2 = (int32_t *)(var_1e0h + 8);
                    iVar7 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                        (***(code ***)var_1e0h)(var_1e0h);
                        LOCK();
                        piVar2 = (int32_t *)(var_1e0h + 0xc);
                        iVar7 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar7 == 1) {
                            (**(code **)(*(int64_t *)var_1e0h + 8))(var_1e0h);
                        }
                    }
                }
                if (0xf < (uint64_t)var_e0h) {
                    iVar10 = var_f8h;
                    puVar16 = auStack_238;
                    if ((0xfff < var_e0h + 1U) &&
                       (iVar10 = *(int64_t *)(var_f8h + -8), puVar16 = auStack_238, 0x1f < (var_f8h - iVar10) - 8U)) {
                        pcVar4 = (code *)swi(0x29);
                        iVar10 = (*pcVar4)(5);
                        puVar16 = auStack_230;
                    }
                    *(undefined8 *)(puVar16 + -8) = 0x18004896e;
                    fcn.180459c3c(iVar10);
                }
                if (0xf < (uint64_t)var_100h) {
                    iVar10 = var_118h;
                    if ((0xfff < var_100h + 1U) &&
                       (iVar10 = *(int64_t *)(var_118h + -8), puVar15 = puVar16, 0x1f < (var_118h - iVar10) - 8U))
                    goto code_r0x0001800489a0;
                    goto code_r0x0001800489aa;
                }
                goto code_r0x0001800489b0;
            }
        } else {
            uVar13 = uVar19 | 0xf;
            if (uVar13 < 0x16) {
                uVar13 = 0x16;
            }
            if (uVar13 + 1 < 0x1000) {
                uVar20 = fcn.180459890();
code_r0x00018004849c:
                var_118h = uVar20;
                var_108h = uVar19;
                var_100h = uVar13;
                fcn.180498030(uVar20, iVar10, uVar19);
                *(undefined *)(uVar19 + uVar20) = 0;
                piVar14 = *(int64_t **)0x180782430;
                goto code_r0x0001800484c2;
            }
            if (uVar13 + 1 < uVar13 + 0x28) {
                iVar8 = fcn.180459890(uVar13 + 0x28);
                if (iVar8 != 0) {
                    uVar20 = iVar8 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar20 - 8) = iVar8;
                    goto code_r0x00018004849c;
                }
code_r0x0001800489a0:
                pcVar4 = (code *)swi(0x29);
                iVar10 = (*pcVar4)(5);
                puVar16 = puVar15 + 8;
code_r0x0001800489aa:
                *(undefined8 *)(puVar16 + -8) = 0x1800489af;
                fcn.180459c3c(iVar10);
code_r0x0001800489b0:
                if ((uint64_t)var_120h < 0x10) goto code_r0x0001800489f0;
                iVar10 = var_138h;
                if ((0xfff < var_120h + 1U) &&
                   (iVar10 = *(int64_t *)(var_138h + -8), puVar17 = puVar16, 0x1f < (var_138h - iVar10) - 8U))
                goto code_r0x0001800489e1;
                goto code_r0x0001800489eb;
            }
            fcn.180004720();
code_r0x000180048a6b:
            func_0x00018045f7d4();
        }
        func_0x000180093000(arg1, 0x18063e070);
        auVar6 = _var_158h;
code_r0x000180048a81:
        _var_158h = auVar6;
        func_0x0001804542e8(1);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar20 = 8;
    if (uVar19 < 8) {
        uVar20 = uVar19;
    }
    piVar9 = &var_138h;
    if (0xf < uVar13) {
        piVar9 = piVar11;
    }
    uVar19 = uVar20;
    if (8 < uVar20) {
        uVar19 = 8;
    }
    iVar7 = func_0x000180497f30(piVar9, 0x180623770, uVar19);
    if ((iVar7 == 0) && (uVar20 == 8)) goto code_r0x00018004838a;
code_r0x000180048a27:
    fcn.180088560(arg1, 0x180623780);
code_r0x000180048a37:
    func_0x000180088470(arg1, 2, 6);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_180048a90
// Address: 0x180048a90
// Size: 22 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180048ae0: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180048ae5)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180048a90(int64_t arg1, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t *piStack_38;
    undefined8 uStack_30;
    
    piVar5 = *(int64_t **)(arg1 + 0x70);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            uStack_30 = 0x180048ac4;
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                uStack_30 = 0x180048ad7;
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    uStack_30 = 0x180048ae5;
    if (0xf < *(uint64_t *)(arg1 + 0x60)) {
        iVar4 = *(int64_t *)(arg1 + 0x48);
        iVar7 = iVar4;
        puVar8 = auStack_58;
        piStack_38 = piVar5;
        if ((0xfff < *(uint64_t *)(arg1 + 0x60) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_58, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_50;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        fcn.180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x48) = 0;
    return;
}

// ============================================================
// Function: FUN_180048aa6
// Address: 0x180048aa6
// Size: 54 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180048ae0: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180048ae5)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180048a90(int64_t arg1, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t *piStack_38;
    undefined8 uStack_30;
    
    piVar5 = *(int64_t **)(arg1 + 0x70);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            uStack_30 = 0x180048ac4;
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                uStack_30 = 0x180048ad7;
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    uStack_30 = 0x180048ae5;
    if (0xf < *(uint64_t *)(arg1 + 0x60)) {
        iVar4 = *(int64_t *)(arg1 + 0x48);
        iVar7 = iVar4;
        puVar8 = auStack_58;
        piStack_38 = piVar5;
        if ((0xfff < *(uint64_t *)(arg1 + 0x60) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_58, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_50;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        fcn.180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x48) = 0;
    return;
}

