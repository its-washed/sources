// Chunk 76 - 50 functions

// ============================================================
// Function: FUN_1800fca1a
// Address: 0x1800fca1a
// Size: 562 bytes
// ============================================================
void fcn.1800fca1a(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h,
                  int64_t arg_c0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_110h, int64_t arg_118h
                  , int64_t arg_120h, int64_t arg_128h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    int64_t in_RAX;
    int32_t *piVar24;
    int64_t iVar25;
    int32_t iVar26;
    int32_t iVar27;
    int64_t unaff_RBP;
    int32_t iVar28;
    int64_t iVar29;
    int32_t iVar30;
    undefined4 unaff_R14D;
    float fVar31;
    float fVar32;
    float fVar33;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    undefined4 unaff_XMM12_Da;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_20h;
    
    auVar6._4_4_ = unaff_XMM11_Db;
    auVar6._0_4_ = unaff_XMM11_Da;
    auVar6._8_4_ = unaff_XMM11_Dc;
    auVar6._12_4_ = unaff_XMM11_Dd;
    *(undefined (*) [16])(in_RAX + -0x78) = auVar6;
    auVar7._4_4_ = unaff_XMM12_Db;
    auVar7._0_4_ = unaff_XMM12_Da;
    auVar7._8_4_ = unaff_XMM12_Dc;
    auVar7._12_4_ = unaff_XMM12_Dd;
    *(undefined (*) [16])(in_RAX + -0x88) = auVar7;
    iVar25 = *(int64_t *)(arg1 + 0x48);
    fVar2 = *(float *)(iVar25 + 8);
    fVar3 = *(float *)(iVar25 + 0xc);
    fVar32 = fVar2 + *(float *)(iVar25 + 0x10);
    fVar33 = fVar3 + *(float *)(iVar25 + 0x14);
    piVar5 = *(int32_t **)(*(int64_t *)(arg1 + 0x428) + 800);
    arg_30h._0_4_ = fVar2;
    arg_30h._4_4_ = fVar3;
    arg_38h._0_4_ = fVar32;
    arg_38h._4_4_ = fVar33;
    func_0x000180126c00(piVar5 + 0x22, piVar5);
    if (*piVar5 == 0) {
        func_0x000180124200(piVar5);
    }
    arg_120h._0_4_ = fVar32 + 1.0;
    arg_128h._0_4_ = fVar2 - 1.0;
    arg_120h._4_4_ = fVar33 + 1.0;
    arg_128h._4_4_ = fVar3 - 1.0;
    func_0x0001801244b0(piVar5, &arg_128h, &arg_120h, 0);
    func_0x000180126550(piVar5, &arg_30h, &arg_38h, unaff_R14D, 0);
    iVar25 = *(int64_t *)(piVar5 + 2);
    iVar28 = 8;
    iVar26 = *piVar5;
    iVar29 = (int64_t)iVar26;
    puVar1 = (undefined4 *)(iVar25 + -0x48 + iVar29 * 0x48);
    uVar8 = *puVar1;
    uVar9 = puVar1[1];
    uVar10 = puVar1[2];
    uVar11 = puVar1[3];
    iVar30 = iVar26 + -1;
    uVar4 = *(undefined8 *)(iVar25 + -8 + iVar29 * 0x48);
    puVar1 = (undefined4 *)(iVar25 + -0x38 + iVar29 * 0x48);
    uVar12 = *puVar1;
    uVar13 = puVar1[1];
    uVar14 = puVar1[2];
    uVar15 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x28 + iVar29 * 0x48);
    uVar16 = *puVar1;
    uVar17 = puVar1[1];
    uVar18 = puVar1[2];
    uVar19 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x18 + iVar29 * 0x48);
    uVar20 = *puVar1;
    uVar21 = puVar1[1];
    uVar22 = puVar1[2];
    uVar23 = puVar1[3];
    *piVar5 = iVar30;
    iVar27 = piVar5[1];
    if (iVar30 == 0) {
        if (iVar27 == 0) {
            if (iVar26 < 8) {
                iVar26 = 8;
            }
            func_0x00018011fc10(piVar5, iVar26);
        }
        iVar29 = (int64_t)*piVar5;
        iVar25 = *(int64_t *)(piVar5 + 2);
        puVar1 = (undefined4 *)(iVar25 + iVar29 * 0x48);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1 = (undefined4 *)(iVar25 + 0x10 + iVar29 * 0x48);
        *puVar1 = uVar12;
        puVar1[1] = uVar13;
        puVar1[2] = uVar14;
        puVar1[3] = uVar15;
        puVar1 = (undefined4 *)(iVar25 + 0x20 + iVar29 * 0x48);
        *puVar1 = uVar16;
        puVar1[1] = uVar17;
        puVar1[2] = uVar18;
        puVar1[3] = uVar19;
        puVar1 = (undefined4 *)(iVar25 + 0x30 + iVar29 * 0x48);
        *puVar1 = uVar20;
        puVar1[1] = uVar21;
        puVar1[2] = uVar22;
        puVar1[3] = uVar23;
        *(undefined8 *)(iVar25 + 0x40 + iVar29 * 0x48) = uVar4;
    } else {
        if (iVar30 == iVar27) {
            if (iVar27 == 0) {
                iVar27 = 8;
            } else {
                iVar27 = iVar27 / 2 + iVar27;
            }
            if (iVar26 < iVar27) {
                iVar26 = iVar27;
            }
            func_0x00018011fc10(piVar5, iVar26);
            iVar25 = *(int64_t *)(piVar5 + 2);
        }
        if (0 < (int64_t)*piVar5) {
            func_0x000180498030(iVar25 + 0x48, iVar25, (int64_t)*piVar5 * 0x48);
        }
        puVar1 = *(undefined4 **)(piVar5 + 2);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1[4] = uVar12;
        puVar1[5] = uVar13;
        puVar1[6] = uVar14;
        puVar1[7] = uVar15;
        puVar1[8] = uVar16;
        puVar1[9] = uVar17;
        puVar1[10] = uVar18;
        puVar1[0xb] = uVar19;
        puVar1[0xc] = uVar20;
        puVar1[0xd] = uVar21;
        puVar1[0xe] = uVar22;
        puVar1[0xf] = uVar23;
        *(undefined8 *)(puVar1 + 0x10) = uVar4;
    }
    *piVar5 = *piVar5 + 1;
    func_0x000180124200(piVar5);
    piVar24 = piVar5 + 0x28;
    *piVar24 = *piVar24 + -1;
    if (*piVar24 == 0) {
        piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
    } else {
        piVar24 = (int32_t *)((int64_t)(piVar5[0x28] + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
    }
    iVar26 = piVar24[1];
    iVar27 = piVar24[2];
    iVar30 = piVar24[3];
    piVar5[0x18] = *piVar24;
    piVar5[0x19] = iVar26;
    piVar5[0x1a] = iVar27;
    piVar5[0x1b] = iVar30;
    func_0x0001801242c0(piVar5);
    if ((*(uint8_t *)(*(int64_t *)(unaff_RBP + 0x418) + 0x495) & 1) != 0) {
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        iVar26 = *(int32_t *)(iVar25 + 0x1f0) + -1;
        if (-1 < iVar26) {
            do {
                iVar29 = *(int64_t *)(*(int64_t *)(iVar25 + 0x1f8) + (int64_t)iVar26 * 8);
                if ((*(char *)(iVar29 + 0x109) != '\0') && (*(char *)(iVar29 + 0x111) == '\0')) {
                    iVar25 = func_0x0001800fc9a0(iVar29);
                    break;
                }
                iVar26 = iVar26 + -1;
            } while (-1 < iVar26);
        }
        piVar5 = *(int32_t **)(iVar25 + 800);
        func_0x000180126c00(piVar5 + 0x22, piVar5);
        if (*piVar5 == 0) {
            func_0x000180124200(piVar5);
        }
        piVar24 = piVar5 + 0x28;
        iVar26 = piVar5[0x29];
        fVar31 = fVar2;
        if (fVar2 <= fVar32) {
            fVar31 = fVar32;
        }
        fVar32 = fVar3;
        if (fVar3 <= fVar33) {
            fVar32 = fVar33;
        }
        if (*piVar24 == iVar26) {
            iVar27 = *piVar24 + 1;
            if (iVar26 != 0) {
                iVar28 = iVar26 + iVar26 / 2;
            }
            if (iVar27 < iVar28) {
                iVar27 = iVar28;
            }
            func_0x00018011faa0(piVar24, iVar27);
        }
        iVar29 = (int64_t)*piVar24;
        iVar25 = *(int64_t *)(piVar5 + 0x2a);
        *(float *)(iVar25 + iVar29 * 0x10) = fVar2;
        *(float *)(iVar25 + 4 + iVar29 * 0x10) = fVar3;
        *(float *)(iVar25 + 8 + iVar29 * 0x10) = fVar31;
        *(float *)(iVar25 + 0xc + iVar29 * 0x10) = fVar32;
        *piVar24 = *piVar24 + 1;
        piVar5[0x18] = (int32_t)fVar2;
        piVar5[0x19] = (int32_t)fVar3;
        piVar5[0x1a] = (int32_t)fVar31;
        piVar5[0x1b] = (int32_t)fVar32;
        func_0x0001801242c0(piVar5);
        iVar25 = *(int64_t *)(unaff_RBP + 0x418);
        arg_30h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_30h._4_4_ = *(float *)(iVar25 + 100);
        arg_38h._0_4_ = (float)arg_30h + *(float *)(iVar25 + 0x68);
        arg_38h._4_4_ = arg_30h._4_4_ + *(float *)(iVar25 + 0x6c);
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        arg_40h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_40h._4_4_ = *(float *)(iVar25 + 100);
        arg_48h._0_4_ = (float)arg_40h + *(float *)(iVar25 + 0x68);
        arg_48h._4_4_ = arg_40h._4_4_ + *(float *)(iVar25 + 0x6c);
        func_0x000180130c50(piVar5, &arg_40h, &arg_30h, unaff_R14D, 0);
        *piVar24 = *piVar24 + -1;
        if (*piVar24 == 0) {
            piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
        } else {
            piVar24 = (int32_t *)((int64_t)(*piVar24 + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
        }
        iVar26 = piVar24[1];
        iVar27 = piVar24[2];
        iVar28 = piVar24[3];
        piVar5[0x18] = *piVar24;
        piVar5[0x19] = iVar26;
        piVar5[0x1a] = iVar27;
        piVar5[0x1b] = iVar28;
        func_0x0001801242c0(piVar5);
    }
    return;
}

// ============================================================
// Function: FUN_1800fcc4c
// Address: 0x1800fcc4c
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_118h
// WARNING: Variable defined which should be unmapped: arg_f0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_124h
// WARNING: [rz-ghidra] Detected overlap for variable arg_12ch
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch

void fcn.1800fca1a(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h,
                  int64_t arg_c0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_110h, int64_t arg_118h
                  , int64_t arg_120h, int64_t arg_128h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    int64_t in_RAX;
    int32_t *piVar24;
    int64_t iVar25;
    int32_t iVar26;
    int32_t iVar27;
    int64_t unaff_RBP;
    int32_t iVar28;
    int64_t iVar29;
    int32_t iVar30;
    undefined4 unaff_R14D;
    float fVar31;
    float fVar32;
    float fVar33;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    undefined4 unaff_XMM12_Da;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_20h;
    
    auVar6._4_4_ = unaff_XMM11_Db;
    auVar6._0_4_ = unaff_XMM11_Da;
    auVar6._8_4_ = unaff_XMM11_Dc;
    auVar6._12_4_ = unaff_XMM11_Dd;
    *(undefined (*) [16])(in_RAX + -0x78) = auVar6;
    auVar7._4_4_ = unaff_XMM12_Db;
    auVar7._0_4_ = unaff_XMM12_Da;
    auVar7._8_4_ = unaff_XMM12_Dc;
    auVar7._12_4_ = unaff_XMM12_Dd;
    *(undefined (*) [16])(in_RAX + -0x88) = auVar7;
    iVar25 = *(int64_t *)(arg1 + 0x48);
    fVar2 = *(float *)(iVar25 + 8);
    fVar3 = *(float *)(iVar25 + 0xc);
    fVar32 = fVar2 + *(float *)(iVar25 + 0x10);
    fVar33 = fVar3 + *(float *)(iVar25 + 0x14);
    piVar5 = *(int32_t **)(*(int64_t *)(arg1 + 0x428) + 800);
    arg_30h._0_4_ = fVar2;
    arg_30h._4_4_ = fVar3;
    arg_38h._0_4_ = fVar32;
    arg_38h._4_4_ = fVar33;
    func_0x000180126c00(piVar5 + 0x22, piVar5);
    if (*piVar5 == 0) {
        func_0x000180124200(piVar5);
    }
    arg_120h._0_4_ = fVar32 + 1.0;
    arg_128h._0_4_ = fVar2 - 1.0;
    arg_120h._4_4_ = fVar33 + 1.0;
    arg_128h._4_4_ = fVar3 - 1.0;
    func_0x0001801244b0(piVar5, &arg_128h, &arg_120h, 0);
    func_0x000180126550(piVar5, &arg_30h, &arg_38h, unaff_R14D, 0);
    iVar25 = *(int64_t *)(piVar5 + 2);
    iVar28 = 8;
    iVar26 = *piVar5;
    iVar29 = (int64_t)iVar26;
    puVar1 = (undefined4 *)(iVar25 + -0x48 + iVar29 * 0x48);
    uVar8 = *puVar1;
    uVar9 = puVar1[1];
    uVar10 = puVar1[2];
    uVar11 = puVar1[3];
    iVar30 = iVar26 + -1;
    uVar4 = *(undefined8 *)(iVar25 + -8 + iVar29 * 0x48);
    puVar1 = (undefined4 *)(iVar25 + -0x38 + iVar29 * 0x48);
    uVar12 = *puVar1;
    uVar13 = puVar1[1];
    uVar14 = puVar1[2];
    uVar15 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x28 + iVar29 * 0x48);
    uVar16 = *puVar1;
    uVar17 = puVar1[1];
    uVar18 = puVar1[2];
    uVar19 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x18 + iVar29 * 0x48);
    uVar20 = *puVar1;
    uVar21 = puVar1[1];
    uVar22 = puVar1[2];
    uVar23 = puVar1[3];
    *piVar5 = iVar30;
    iVar27 = piVar5[1];
    if (iVar30 == 0) {
        if (iVar27 == 0) {
            if (iVar26 < 8) {
                iVar26 = 8;
            }
            func_0x00018011fc10(piVar5, iVar26);
        }
        iVar29 = (int64_t)*piVar5;
        iVar25 = *(int64_t *)(piVar5 + 2);
        puVar1 = (undefined4 *)(iVar25 + iVar29 * 0x48);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1 = (undefined4 *)(iVar25 + 0x10 + iVar29 * 0x48);
        *puVar1 = uVar12;
        puVar1[1] = uVar13;
        puVar1[2] = uVar14;
        puVar1[3] = uVar15;
        puVar1 = (undefined4 *)(iVar25 + 0x20 + iVar29 * 0x48);
        *puVar1 = uVar16;
        puVar1[1] = uVar17;
        puVar1[2] = uVar18;
        puVar1[3] = uVar19;
        puVar1 = (undefined4 *)(iVar25 + 0x30 + iVar29 * 0x48);
        *puVar1 = uVar20;
        puVar1[1] = uVar21;
        puVar1[2] = uVar22;
        puVar1[3] = uVar23;
        *(undefined8 *)(iVar25 + 0x40 + iVar29 * 0x48) = uVar4;
    } else {
        if (iVar30 == iVar27) {
            if (iVar27 == 0) {
                iVar27 = 8;
            } else {
                iVar27 = iVar27 / 2 + iVar27;
            }
            if (iVar26 < iVar27) {
                iVar26 = iVar27;
            }
            func_0x00018011fc10(piVar5, iVar26);
            iVar25 = *(int64_t *)(piVar5 + 2);
        }
        if (0 < (int64_t)*piVar5) {
            func_0x000180498030(iVar25 + 0x48, iVar25, (int64_t)*piVar5 * 0x48);
        }
        puVar1 = *(undefined4 **)(piVar5 + 2);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1[4] = uVar12;
        puVar1[5] = uVar13;
        puVar1[6] = uVar14;
        puVar1[7] = uVar15;
        puVar1[8] = uVar16;
        puVar1[9] = uVar17;
        puVar1[10] = uVar18;
        puVar1[0xb] = uVar19;
        puVar1[0xc] = uVar20;
        puVar1[0xd] = uVar21;
        puVar1[0xe] = uVar22;
        puVar1[0xf] = uVar23;
        *(undefined8 *)(puVar1 + 0x10) = uVar4;
    }
    *piVar5 = *piVar5 + 1;
    func_0x000180124200(piVar5);
    piVar24 = piVar5 + 0x28;
    *piVar24 = *piVar24 + -1;
    if (*piVar24 == 0) {
        piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
    } else {
        piVar24 = (int32_t *)((int64_t)(piVar5[0x28] + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
    }
    iVar26 = piVar24[1];
    iVar27 = piVar24[2];
    iVar30 = piVar24[3];
    piVar5[0x18] = *piVar24;
    piVar5[0x19] = iVar26;
    piVar5[0x1a] = iVar27;
    piVar5[0x1b] = iVar30;
    func_0x0001801242c0(piVar5);
    if ((*(uint8_t *)(*(int64_t *)(unaff_RBP + 0x418) + 0x495) & 1) != 0) {
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        iVar26 = *(int32_t *)(iVar25 + 0x1f0) + -1;
        if (-1 < iVar26) {
            do {
                iVar29 = *(int64_t *)(*(int64_t *)(iVar25 + 0x1f8) + (int64_t)iVar26 * 8);
                if ((*(char *)(iVar29 + 0x109) != '\0') && (*(char *)(iVar29 + 0x111) == '\0')) {
                    iVar25 = func_0x0001800fc9a0(iVar29);
                    break;
                }
                iVar26 = iVar26 + -1;
            } while (-1 < iVar26);
        }
        piVar5 = *(int32_t **)(iVar25 + 800);
        func_0x000180126c00(piVar5 + 0x22, piVar5);
        if (*piVar5 == 0) {
            func_0x000180124200(piVar5);
        }
        piVar24 = piVar5 + 0x28;
        iVar26 = piVar5[0x29];
        fVar31 = fVar2;
        if (fVar2 <= fVar32) {
            fVar31 = fVar32;
        }
        fVar32 = fVar3;
        if (fVar3 <= fVar33) {
            fVar32 = fVar33;
        }
        if (*piVar24 == iVar26) {
            iVar27 = *piVar24 + 1;
            if (iVar26 != 0) {
                iVar28 = iVar26 + iVar26 / 2;
            }
            if (iVar27 < iVar28) {
                iVar27 = iVar28;
            }
            func_0x00018011faa0(piVar24, iVar27);
        }
        iVar29 = (int64_t)*piVar24;
        iVar25 = *(int64_t *)(piVar5 + 0x2a);
        *(float *)(iVar25 + iVar29 * 0x10) = fVar2;
        *(float *)(iVar25 + 4 + iVar29 * 0x10) = fVar3;
        *(float *)(iVar25 + 8 + iVar29 * 0x10) = fVar31;
        *(float *)(iVar25 + 0xc + iVar29 * 0x10) = fVar32;
        *piVar24 = *piVar24 + 1;
        piVar5[0x18] = (int32_t)fVar2;
        piVar5[0x19] = (int32_t)fVar3;
        piVar5[0x1a] = (int32_t)fVar31;
        piVar5[0x1b] = (int32_t)fVar32;
        func_0x0001801242c0(piVar5);
        iVar25 = *(int64_t *)(unaff_RBP + 0x418);
        arg_30h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_30h._4_4_ = *(float *)(iVar25 + 100);
        arg_38h._0_4_ = (float)arg_30h + *(float *)(iVar25 + 0x68);
        arg_38h._4_4_ = arg_30h._4_4_ + *(float *)(iVar25 + 0x6c);
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        arg_40h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_40h._4_4_ = *(float *)(iVar25 + 100);
        arg_48h._0_4_ = (float)arg_40h + *(float *)(iVar25 + 0x68);
        arg_48h._4_4_ = arg_40h._4_4_ + *(float *)(iVar25 + 0x6c);
        func_0x000180130c50(piVar5, &arg_40h, &arg_30h, unaff_R14D, 0);
        *piVar24 = *piVar24 + -1;
        if (*piVar24 == 0) {
            piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
        } else {
            piVar24 = (int32_t *)((int64_t)(*piVar24 + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
        }
        iVar26 = piVar24[1];
        iVar27 = piVar24[2];
        iVar28 = piVar24[3];
        piVar5[0x18] = *piVar24;
        piVar5[0x19] = iVar26;
        piVar5[0x1a] = iVar27;
        piVar5[0x1b] = iVar28;
        func_0x0001801242c0(piVar5);
    }
    return;
}

// ============================================================
// Function: FUN_1800fcc8f
// Address: 0x1800fcc8f
// Size: 392 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_118h
// WARNING: Variable defined which should be unmapped: arg_f0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_124h
// WARNING: [rz-ghidra] Detected overlap for variable arg_12ch
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch

void fcn.1800fca1a(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h,
                  int64_t arg_c0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_110h, int64_t arg_118h
                  , int64_t arg_120h, int64_t arg_128h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    int64_t in_RAX;
    int32_t *piVar24;
    int64_t iVar25;
    int32_t iVar26;
    int32_t iVar27;
    int64_t unaff_RBP;
    int32_t iVar28;
    int64_t iVar29;
    int32_t iVar30;
    undefined4 unaff_R14D;
    float fVar31;
    float fVar32;
    float fVar33;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    undefined4 unaff_XMM12_Da;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_20h;
    
    auVar6._4_4_ = unaff_XMM11_Db;
    auVar6._0_4_ = unaff_XMM11_Da;
    auVar6._8_4_ = unaff_XMM11_Dc;
    auVar6._12_4_ = unaff_XMM11_Dd;
    *(undefined (*) [16])(in_RAX + -0x78) = auVar6;
    auVar7._4_4_ = unaff_XMM12_Db;
    auVar7._0_4_ = unaff_XMM12_Da;
    auVar7._8_4_ = unaff_XMM12_Dc;
    auVar7._12_4_ = unaff_XMM12_Dd;
    *(undefined (*) [16])(in_RAX + -0x88) = auVar7;
    iVar25 = *(int64_t *)(arg1 + 0x48);
    fVar2 = *(float *)(iVar25 + 8);
    fVar3 = *(float *)(iVar25 + 0xc);
    fVar32 = fVar2 + *(float *)(iVar25 + 0x10);
    fVar33 = fVar3 + *(float *)(iVar25 + 0x14);
    piVar5 = *(int32_t **)(*(int64_t *)(arg1 + 0x428) + 800);
    arg_30h._0_4_ = fVar2;
    arg_30h._4_4_ = fVar3;
    arg_38h._0_4_ = fVar32;
    arg_38h._4_4_ = fVar33;
    func_0x000180126c00(piVar5 + 0x22, piVar5);
    if (*piVar5 == 0) {
        func_0x000180124200(piVar5);
    }
    arg_120h._0_4_ = fVar32 + 1.0;
    arg_128h._0_4_ = fVar2 - 1.0;
    arg_120h._4_4_ = fVar33 + 1.0;
    arg_128h._4_4_ = fVar3 - 1.0;
    func_0x0001801244b0(piVar5, &arg_128h, &arg_120h, 0);
    func_0x000180126550(piVar5, &arg_30h, &arg_38h, unaff_R14D, 0);
    iVar25 = *(int64_t *)(piVar5 + 2);
    iVar28 = 8;
    iVar26 = *piVar5;
    iVar29 = (int64_t)iVar26;
    puVar1 = (undefined4 *)(iVar25 + -0x48 + iVar29 * 0x48);
    uVar8 = *puVar1;
    uVar9 = puVar1[1];
    uVar10 = puVar1[2];
    uVar11 = puVar1[3];
    iVar30 = iVar26 + -1;
    uVar4 = *(undefined8 *)(iVar25 + -8 + iVar29 * 0x48);
    puVar1 = (undefined4 *)(iVar25 + -0x38 + iVar29 * 0x48);
    uVar12 = *puVar1;
    uVar13 = puVar1[1];
    uVar14 = puVar1[2];
    uVar15 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x28 + iVar29 * 0x48);
    uVar16 = *puVar1;
    uVar17 = puVar1[1];
    uVar18 = puVar1[2];
    uVar19 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x18 + iVar29 * 0x48);
    uVar20 = *puVar1;
    uVar21 = puVar1[1];
    uVar22 = puVar1[2];
    uVar23 = puVar1[3];
    *piVar5 = iVar30;
    iVar27 = piVar5[1];
    if (iVar30 == 0) {
        if (iVar27 == 0) {
            if (iVar26 < 8) {
                iVar26 = 8;
            }
            func_0x00018011fc10(piVar5, iVar26);
        }
        iVar29 = (int64_t)*piVar5;
        iVar25 = *(int64_t *)(piVar5 + 2);
        puVar1 = (undefined4 *)(iVar25 + iVar29 * 0x48);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1 = (undefined4 *)(iVar25 + 0x10 + iVar29 * 0x48);
        *puVar1 = uVar12;
        puVar1[1] = uVar13;
        puVar1[2] = uVar14;
        puVar1[3] = uVar15;
        puVar1 = (undefined4 *)(iVar25 + 0x20 + iVar29 * 0x48);
        *puVar1 = uVar16;
        puVar1[1] = uVar17;
        puVar1[2] = uVar18;
        puVar1[3] = uVar19;
        puVar1 = (undefined4 *)(iVar25 + 0x30 + iVar29 * 0x48);
        *puVar1 = uVar20;
        puVar1[1] = uVar21;
        puVar1[2] = uVar22;
        puVar1[3] = uVar23;
        *(undefined8 *)(iVar25 + 0x40 + iVar29 * 0x48) = uVar4;
    } else {
        if (iVar30 == iVar27) {
            if (iVar27 == 0) {
                iVar27 = 8;
            } else {
                iVar27 = iVar27 / 2 + iVar27;
            }
            if (iVar26 < iVar27) {
                iVar26 = iVar27;
            }
            func_0x00018011fc10(piVar5, iVar26);
            iVar25 = *(int64_t *)(piVar5 + 2);
        }
        if (0 < (int64_t)*piVar5) {
            func_0x000180498030(iVar25 + 0x48, iVar25, (int64_t)*piVar5 * 0x48);
        }
        puVar1 = *(undefined4 **)(piVar5 + 2);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1[4] = uVar12;
        puVar1[5] = uVar13;
        puVar1[6] = uVar14;
        puVar1[7] = uVar15;
        puVar1[8] = uVar16;
        puVar1[9] = uVar17;
        puVar1[10] = uVar18;
        puVar1[0xb] = uVar19;
        puVar1[0xc] = uVar20;
        puVar1[0xd] = uVar21;
        puVar1[0xe] = uVar22;
        puVar1[0xf] = uVar23;
        *(undefined8 *)(puVar1 + 0x10) = uVar4;
    }
    *piVar5 = *piVar5 + 1;
    func_0x000180124200(piVar5);
    piVar24 = piVar5 + 0x28;
    *piVar24 = *piVar24 + -1;
    if (*piVar24 == 0) {
        piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
    } else {
        piVar24 = (int32_t *)((int64_t)(piVar5[0x28] + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
    }
    iVar26 = piVar24[1];
    iVar27 = piVar24[2];
    iVar30 = piVar24[3];
    piVar5[0x18] = *piVar24;
    piVar5[0x19] = iVar26;
    piVar5[0x1a] = iVar27;
    piVar5[0x1b] = iVar30;
    func_0x0001801242c0(piVar5);
    if ((*(uint8_t *)(*(int64_t *)(unaff_RBP + 0x418) + 0x495) & 1) != 0) {
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        iVar26 = *(int32_t *)(iVar25 + 0x1f0) + -1;
        if (-1 < iVar26) {
            do {
                iVar29 = *(int64_t *)(*(int64_t *)(iVar25 + 0x1f8) + (int64_t)iVar26 * 8);
                if ((*(char *)(iVar29 + 0x109) != '\0') && (*(char *)(iVar29 + 0x111) == '\0')) {
                    iVar25 = func_0x0001800fc9a0(iVar29);
                    break;
                }
                iVar26 = iVar26 + -1;
            } while (-1 < iVar26);
        }
        piVar5 = *(int32_t **)(iVar25 + 800);
        func_0x000180126c00(piVar5 + 0x22, piVar5);
        if (*piVar5 == 0) {
            func_0x000180124200(piVar5);
        }
        piVar24 = piVar5 + 0x28;
        iVar26 = piVar5[0x29];
        fVar31 = fVar2;
        if (fVar2 <= fVar32) {
            fVar31 = fVar32;
        }
        fVar32 = fVar3;
        if (fVar3 <= fVar33) {
            fVar32 = fVar33;
        }
        if (*piVar24 == iVar26) {
            iVar27 = *piVar24 + 1;
            if (iVar26 != 0) {
                iVar28 = iVar26 + iVar26 / 2;
            }
            if (iVar27 < iVar28) {
                iVar27 = iVar28;
            }
            func_0x00018011faa0(piVar24, iVar27);
        }
        iVar29 = (int64_t)*piVar24;
        iVar25 = *(int64_t *)(piVar5 + 0x2a);
        *(float *)(iVar25 + iVar29 * 0x10) = fVar2;
        *(float *)(iVar25 + 4 + iVar29 * 0x10) = fVar3;
        *(float *)(iVar25 + 8 + iVar29 * 0x10) = fVar31;
        *(float *)(iVar25 + 0xc + iVar29 * 0x10) = fVar32;
        *piVar24 = *piVar24 + 1;
        piVar5[0x18] = (int32_t)fVar2;
        piVar5[0x19] = (int32_t)fVar3;
        piVar5[0x1a] = (int32_t)fVar31;
        piVar5[0x1b] = (int32_t)fVar32;
        func_0x0001801242c0(piVar5);
        iVar25 = *(int64_t *)(unaff_RBP + 0x418);
        arg_30h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_30h._4_4_ = *(float *)(iVar25 + 100);
        arg_38h._0_4_ = (float)arg_30h + *(float *)(iVar25 + 0x68);
        arg_38h._4_4_ = arg_30h._4_4_ + *(float *)(iVar25 + 0x6c);
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        arg_40h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_40h._4_4_ = *(float *)(iVar25 + 100);
        arg_48h._0_4_ = (float)arg_40h + *(float *)(iVar25 + 0x68);
        arg_48h._4_4_ = arg_40h._4_4_ + *(float *)(iVar25 + 0x6c);
        func_0x000180130c50(piVar5, &arg_40h, &arg_30h, unaff_R14D, 0);
        *piVar24 = *piVar24 + -1;
        if (*piVar24 == 0) {
            piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
        } else {
            piVar24 = (int32_t *)((int64_t)(*piVar24 + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
        }
        iVar26 = piVar24[1];
        iVar27 = piVar24[2];
        iVar28 = piVar24[3];
        piVar5[0x18] = *piVar24;
        piVar5[0x19] = iVar26;
        piVar5[0x1a] = iVar27;
        piVar5[0x1b] = iVar28;
        func_0x0001801242c0(piVar5);
    }
    return;
}

// ============================================================
// Function: FUN_1800fce17
// Address: 0x1800fce17
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_118h
// WARNING: Variable defined which should be unmapped: arg_f0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_124h
// WARNING: [rz-ghidra] Detected overlap for variable arg_12ch
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch

void fcn.1800fca1a(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h,
                  int64_t arg_c0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_110h, int64_t arg_118h
                  , int64_t arg_120h, int64_t arg_128h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    int64_t in_RAX;
    int32_t *piVar24;
    int64_t iVar25;
    int32_t iVar26;
    int32_t iVar27;
    int64_t unaff_RBP;
    int32_t iVar28;
    int64_t iVar29;
    int32_t iVar30;
    undefined4 unaff_R14D;
    float fVar31;
    float fVar32;
    float fVar33;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    undefined4 unaff_XMM12_Da;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_20h;
    
    auVar6._4_4_ = unaff_XMM11_Db;
    auVar6._0_4_ = unaff_XMM11_Da;
    auVar6._8_4_ = unaff_XMM11_Dc;
    auVar6._12_4_ = unaff_XMM11_Dd;
    *(undefined (*) [16])(in_RAX + -0x78) = auVar6;
    auVar7._4_4_ = unaff_XMM12_Db;
    auVar7._0_4_ = unaff_XMM12_Da;
    auVar7._8_4_ = unaff_XMM12_Dc;
    auVar7._12_4_ = unaff_XMM12_Dd;
    *(undefined (*) [16])(in_RAX + -0x88) = auVar7;
    iVar25 = *(int64_t *)(arg1 + 0x48);
    fVar2 = *(float *)(iVar25 + 8);
    fVar3 = *(float *)(iVar25 + 0xc);
    fVar32 = fVar2 + *(float *)(iVar25 + 0x10);
    fVar33 = fVar3 + *(float *)(iVar25 + 0x14);
    piVar5 = *(int32_t **)(*(int64_t *)(arg1 + 0x428) + 800);
    arg_30h._0_4_ = fVar2;
    arg_30h._4_4_ = fVar3;
    arg_38h._0_4_ = fVar32;
    arg_38h._4_4_ = fVar33;
    func_0x000180126c00(piVar5 + 0x22, piVar5);
    if (*piVar5 == 0) {
        func_0x000180124200(piVar5);
    }
    arg_120h._0_4_ = fVar32 + 1.0;
    arg_128h._0_4_ = fVar2 - 1.0;
    arg_120h._4_4_ = fVar33 + 1.0;
    arg_128h._4_4_ = fVar3 - 1.0;
    func_0x0001801244b0(piVar5, &arg_128h, &arg_120h, 0);
    func_0x000180126550(piVar5, &arg_30h, &arg_38h, unaff_R14D, 0);
    iVar25 = *(int64_t *)(piVar5 + 2);
    iVar28 = 8;
    iVar26 = *piVar5;
    iVar29 = (int64_t)iVar26;
    puVar1 = (undefined4 *)(iVar25 + -0x48 + iVar29 * 0x48);
    uVar8 = *puVar1;
    uVar9 = puVar1[1];
    uVar10 = puVar1[2];
    uVar11 = puVar1[3];
    iVar30 = iVar26 + -1;
    uVar4 = *(undefined8 *)(iVar25 + -8 + iVar29 * 0x48);
    puVar1 = (undefined4 *)(iVar25 + -0x38 + iVar29 * 0x48);
    uVar12 = *puVar1;
    uVar13 = puVar1[1];
    uVar14 = puVar1[2];
    uVar15 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x28 + iVar29 * 0x48);
    uVar16 = *puVar1;
    uVar17 = puVar1[1];
    uVar18 = puVar1[2];
    uVar19 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x18 + iVar29 * 0x48);
    uVar20 = *puVar1;
    uVar21 = puVar1[1];
    uVar22 = puVar1[2];
    uVar23 = puVar1[3];
    *piVar5 = iVar30;
    iVar27 = piVar5[1];
    if (iVar30 == 0) {
        if (iVar27 == 0) {
            if (iVar26 < 8) {
                iVar26 = 8;
            }
            func_0x00018011fc10(piVar5, iVar26);
        }
        iVar29 = (int64_t)*piVar5;
        iVar25 = *(int64_t *)(piVar5 + 2);
        puVar1 = (undefined4 *)(iVar25 + iVar29 * 0x48);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1 = (undefined4 *)(iVar25 + 0x10 + iVar29 * 0x48);
        *puVar1 = uVar12;
        puVar1[1] = uVar13;
        puVar1[2] = uVar14;
        puVar1[3] = uVar15;
        puVar1 = (undefined4 *)(iVar25 + 0x20 + iVar29 * 0x48);
        *puVar1 = uVar16;
        puVar1[1] = uVar17;
        puVar1[2] = uVar18;
        puVar1[3] = uVar19;
        puVar1 = (undefined4 *)(iVar25 + 0x30 + iVar29 * 0x48);
        *puVar1 = uVar20;
        puVar1[1] = uVar21;
        puVar1[2] = uVar22;
        puVar1[3] = uVar23;
        *(undefined8 *)(iVar25 + 0x40 + iVar29 * 0x48) = uVar4;
    } else {
        if (iVar30 == iVar27) {
            if (iVar27 == 0) {
                iVar27 = 8;
            } else {
                iVar27 = iVar27 / 2 + iVar27;
            }
            if (iVar26 < iVar27) {
                iVar26 = iVar27;
            }
            func_0x00018011fc10(piVar5, iVar26);
            iVar25 = *(int64_t *)(piVar5 + 2);
        }
        if (0 < (int64_t)*piVar5) {
            func_0x000180498030(iVar25 + 0x48, iVar25, (int64_t)*piVar5 * 0x48);
        }
        puVar1 = *(undefined4 **)(piVar5 + 2);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1[4] = uVar12;
        puVar1[5] = uVar13;
        puVar1[6] = uVar14;
        puVar1[7] = uVar15;
        puVar1[8] = uVar16;
        puVar1[9] = uVar17;
        puVar1[10] = uVar18;
        puVar1[0xb] = uVar19;
        puVar1[0xc] = uVar20;
        puVar1[0xd] = uVar21;
        puVar1[0xe] = uVar22;
        puVar1[0xf] = uVar23;
        *(undefined8 *)(puVar1 + 0x10) = uVar4;
    }
    *piVar5 = *piVar5 + 1;
    func_0x000180124200(piVar5);
    piVar24 = piVar5 + 0x28;
    *piVar24 = *piVar24 + -1;
    if (*piVar24 == 0) {
        piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
    } else {
        piVar24 = (int32_t *)((int64_t)(piVar5[0x28] + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
    }
    iVar26 = piVar24[1];
    iVar27 = piVar24[2];
    iVar30 = piVar24[3];
    piVar5[0x18] = *piVar24;
    piVar5[0x19] = iVar26;
    piVar5[0x1a] = iVar27;
    piVar5[0x1b] = iVar30;
    func_0x0001801242c0(piVar5);
    if ((*(uint8_t *)(*(int64_t *)(unaff_RBP + 0x418) + 0x495) & 1) != 0) {
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        iVar26 = *(int32_t *)(iVar25 + 0x1f0) + -1;
        if (-1 < iVar26) {
            do {
                iVar29 = *(int64_t *)(*(int64_t *)(iVar25 + 0x1f8) + (int64_t)iVar26 * 8);
                if ((*(char *)(iVar29 + 0x109) != '\0') && (*(char *)(iVar29 + 0x111) == '\0')) {
                    iVar25 = func_0x0001800fc9a0(iVar29);
                    break;
                }
                iVar26 = iVar26 + -1;
            } while (-1 < iVar26);
        }
        piVar5 = *(int32_t **)(iVar25 + 800);
        func_0x000180126c00(piVar5 + 0x22, piVar5);
        if (*piVar5 == 0) {
            func_0x000180124200(piVar5);
        }
        piVar24 = piVar5 + 0x28;
        iVar26 = piVar5[0x29];
        fVar31 = fVar2;
        if (fVar2 <= fVar32) {
            fVar31 = fVar32;
        }
        fVar32 = fVar3;
        if (fVar3 <= fVar33) {
            fVar32 = fVar33;
        }
        if (*piVar24 == iVar26) {
            iVar27 = *piVar24 + 1;
            if (iVar26 != 0) {
                iVar28 = iVar26 + iVar26 / 2;
            }
            if (iVar27 < iVar28) {
                iVar27 = iVar28;
            }
            func_0x00018011faa0(piVar24, iVar27);
        }
        iVar29 = (int64_t)*piVar24;
        iVar25 = *(int64_t *)(piVar5 + 0x2a);
        *(float *)(iVar25 + iVar29 * 0x10) = fVar2;
        *(float *)(iVar25 + 4 + iVar29 * 0x10) = fVar3;
        *(float *)(iVar25 + 8 + iVar29 * 0x10) = fVar31;
        *(float *)(iVar25 + 0xc + iVar29 * 0x10) = fVar32;
        *piVar24 = *piVar24 + 1;
        piVar5[0x18] = (int32_t)fVar2;
        piVar5[0x19] = (int32_t)fVar3;
        piVar5[0x1a] = (int32_t)fVar31;
        piVar5[0x1b] = (int32_t)fVar32;
        func_0x0001801242c0(piVar5);
        iVar25 = *(int64_t *)(unaff_RBP + 0x418);
        arg_30h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_30h._4_4_ = *(float *)(iVar25 + 100);
        arg_38h._0_4_ = (float)arg_30h + *(float *)(iVar25 + 0x68);
        arg_38h._4_4_ = arg_30h._4_4_ + *(float *)(iVar25 + 0x6c);
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        arg_40h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_40h._4_4_ = *(float *)(iVar25 + 100);
        arg_48h._0_4_ = (float)arg_40h + *(float *)(iVar25 + 0x68);
        arg_48h._4_4_ = arg_40h._4_4_ + *(float *)(iVar25 + 0x6c);
        func_0x000180130c50(piVar5, &arg_40h, &arg_30h, unaff_R14D, 0);
        *piVar24 = *piVar24 + -1;
        if (*piVar24 == 0) {
            piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
        } else {
            piVar24 = (int32_t *)((int64_t)(*piVar24 + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
        }
        iVar26 = piVar24[1];
        iVar27 = piVar24[2];
        iVar28 = piVar24[3];
        piVar5[0x18] = *piVar24;
        piVar5[0x19] = iVar26;
        piVar5[0x1a] = iVar27;
        piVar5[0x1b] = iVar28;
        func_0x0001801242c0(piVar5);
    }
    return;
}

// ============================================================
// Function: FUN_1800fce8a
// Address: 0x1800fce8a
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_118h
// WARNING: Variable defined which should be unmapped: arg_f0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_124h
// WARNING: [rz-ghidra] Detected overlap for variable arg_12ch
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch

void fcn.1800fca1a(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h,
                  int64_t arg_c0h, int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_110h, int64_t arg_118h
                  , int64_t arg_120h, int64_t arg_128h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    int64_t in_RAX;
    int32_t *piVar24;
    int64_t iVar25;
    int32_t iVar26;
    int32_t iVar27;
    int64_t unaff_RBP;
    int32_t iVar28;
    int64_t iVar29;
    int32_t iVar30;
    undefined4 unaff_R14D;
    float fVar31;
    float fVar32;
    float fVar33;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM11_Dc;
    undefined4 unaff_XMM11_Dd;
    undefined4 unaff_XMM12_Da;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_20h;
    
    auVar6._4_4_ = unaff_XMM11_Db;
    auVar6._0_4_ = unaff_XMM11_Da;
    auVar6._8_4_ = unaff_XMM11_Dc;
    auVar6._12_4_ = unaff_XMM11_Dd;
    *(undefined (*) [16])(in_RAX + -0x78) = auVar6;
    auVar7._4_4_ = unaff_XMM12_Db;
    auVar7._0_4_ = unaff_XMM12_Da;
    auVar7._8_4_ = unaff_XMM12_Dc;
    auVar7._12_4_ = unaff_XMM12_Dd;
    *(undefined (*) [16])(in_RAX + -0x88) = auVar7;
    iVar25 = *(int64_t *)(arg1 + 0x48);
    fVar2 = *(float *)(iVar25 + 8);
    fVar3 = *(float *)(iVar25 + 0xc);
    fVar32 = fVar2 + *(float *)(iVar25 + 0x10);
    fVar33 = fVar3 + *(float *)(iVar25 + 0x14);
    piVar5 = *(int32_t **)(*(int64_t *)(arg1 + 0x428) + 800);
    arg_30h._0_4_ = fVar2;
    arg_30h._4_4_ = fVar3;
    arg_38h._0_4_ = fVar32;
    arg_38h._4_4_ = fVar33;
    func_0x000180126c00(piVar5 + 0x22, piVar5);
    if (*piVar5 == 0) {
        func_0x000180124200(piVar5);
    }
    arg_120h._0_4_ = fVar32 + 1.0;
    arg_128h._0_4_ = fVar2 - 1.0;
    arg_120h._4_4_ = fVar33 + 1.0;
    arg_128h._4_4_ = fVar3 - 1.0;
    func_0x0001801244b0(piVar5, &arg_128h, &arg_120h, 0);
    func_0x000180126550(piVar5, &arg_30h, &arg_38h, unaff_R14D, 0);
    iVar25 = *(int64_t *)(piVar5 + 2);
    iVar28 = 8;
    iVar26 = *piVar5;
    iVar29 = (int64_t)iVar26;
    puVar1 = (undefined4 *)(iVar25 + -0x48 + iVar29 * 0x48);
    uVar8 = *puVar1;
    uVar9 = puVar1[1];
    uVar10 = puVar1[2];
    uVar11 = puVar1[3];
    iVar30 = iVar26 + -1;
    uVar4 = *(undefined8 *)(iVar25 + -8 + iVar29 * 0x48);
    puVar1 = (undefined4 *)(iVar25 + -0x38 + iVar29 * 0x48);
    uVar12 = *puVar1;
    uVar13 = puVar1[1];
    uVar14 = puVar1[2];
    uVar15 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x28 + iVar29 * 0x48);
    uVar16 = *puVar1;
    uVar17 = puVar1[1];
    uVar18 = puVar1[2];
    uVar19 = puVar1[3];
    puVar1 = (undefined4 *)(iVar25 + -0x18 + iVar29 * 0x48);
    uVar20 = *puVar1;
    uVar21 = puVar1[1];
    uVar22 = puVar1[2];
    uVar23 = puVar1[3];
    *piVar5 = iVar30;
    iVar27 = piVar5[1];
    if (iVar30 == 0) {
        if (iVar27 == 0) {
            if (iVar26 < 8) {
                iVar26 = 8;
            }
            func_0x00018011fc10(piVar5, iVar26);
        }
        iVar29 = (int64_t)*piVar5;
        iVar25 = *(int64_t *)(piVar5 + 2);
        puVar1 = (undefined4 *)(iVar25 + iVar29 * 0x48);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1 = (undefined4 *)(iVar25 + 0x10 + iVar29 * 0x48);
        *puVar1 = uVar12;
        puVar1[1] = uVar13;
        puVar1[2] = uVar14;
        puVar1[3] = uVar15;
        puVar1 = (undefined4 *)(iVar25 + 0x20 + iVar29 * 0x48);
        *puVar1 = uVar16;
        puVar1[1] = uVar17;
        puVar1[2] = uVar18;
        puVar1[3] = uVar19;
        puVar1 = (undefined4 *)(iVar25 + 0x30 + iVar29 * 0x48);
        *puVar1 = uVar20;
        puVar1[1] = uVar21;
        puVar1[2] = uVar22;
        puVar1[3] = uVar23;
        *(undefined8 *)(iVar25 + 0x40 + iVar29 * 0x48) = uVar4;
    } else {
        if (iVar30 == iVar27) {
            if (iVar27 == 0) {
                iVar27 = 8;
            } else {
                iVar27 = iVar27 / 2 + iVar27;
            }
            if (iVar26 < iVar27) {
                iVar26 = iVar27;
            }
            func_0x00018011fc10(piVar5, iVar26);
            iVar25 = *(int64_t *)(piVar5 + 2);
        }
        if (0 < (int64_t)*piVar5) {
            func_0x000180498030(iVar25 + 0x48, iVar25, (int64_t)*piVar5 * 0x48);
        }
        puVar1 = *(undefined4 **)(piVar5 + 2);
        *puVar1 = uVar8;
        puVar1[1] = uVar9;
        puVar1[2] = uVar10;
        puVar1[3] = uVar11;
        puVar1[4] = uVar12;
        puVar1[5] = uVar13;
        puVar1[6] = uVar14;
        puVar1[7] = uVar15;
        puVar1[8] = uVar16;
        puVar1[9] = uVar17;
        puVar1[10] = uVar18;
        puVar1[0xb] = uVar19;
        puVar1[0xc] = uVar20;
        puVar1[0xd] = uVar21;
        puVar1[0xe] = uVar22;
        puVar1[0xf] = uVar23;
        *(undefined8 *)(puVar1 + 0x10) = uVar4;
    }
    *piVar5 = *piVar5 + 1;
    func_0x000180124200(piVar5);
    piVar24 = piVar5 + 0x28;
    *piVar24 = *piVar24 + -1;
    if (*piVar24 == 0) {
        piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
    } else {
        piVar24 = (int32_t *)((int64_t)(piVar5[0x28] + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
    }
    iVar26 = piVar24[1];
    iVar27 = piVar24[2];
    iVar30 = piVar24[3];
    piVar5[0x18] = *piVar24;
    piVar5[0x19] = iVar26;
    piVar5[0x1a] = iVar27;
    piVar5[0x1b] = iVar30;
    func_0x0001801242c0(piVar5);
    if ((*(uint8_t *)(*(int64_t *)(unaff_RBP + 0x418) + 0x495) & 1) != 0) {
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        iVar26 = *(int32_t *)(iVar25 + 0x1f0) + -1;
        if (-1 < iVar26) {
            do {
                iVar29 = *(int64_t *)(*(int64_t *)(iVar25 + 0x1f8) + (int64_t)iVar26 * 8);
                if ((*(char *)(iVar29 + 0x109) != '\0') && (*(char *)(iVar29 + 0x111) == '\0')) {
                    iVar25 = func_0x0001800fc9a0(iVar29);
                    break;
                }
                iVar26 = iVar26 + -1;
            } while (-1 < iVar26);
        }
        piVar5 = *(int32_t **)(iVar25 + 800);
        func_0x000180126c00(piVar5 + 0x22, piVar5);
        if (*piVar5 == 0) {
            func_0x000180124200(piVar5);
        }
        piVar24 = piVar5 + 0x28;
        iVar26 = piVar5[0x29];
        fVar31 = fVar2;
        if (fVar2 <= fVar32) {
            fVar31 = fVar32;
        }
        fVar32 = fVar3;
        if (fVar3 <= fVar33) {
            fVar32 = fVar33;
        }
        if (*piVar24 == iVar26) {
            iVar27 = *piVar24 + 1;
            if (iVar26 != 0) {
                iVar28 = iVar26 + iVar26 / 2;
            }
            if (iVar27 < iVar28) {
                iVar27 = iVar28;
            }
            func_0x00018011faa0(piVar24, iVar27);
        }
        iVar29 = (int64_t)*piVar24;
        iVar25 = *(int64_t *)(piVar5 + 0x2a);
        *(float *)(iVar25 + iVar29 * 0x10) = fVar2;
        *(float *)(iVar25 + 4 + iVar29 * 0x10) = fVar3;
        *(float *)(iVar25 + 8 + iVar29 * 0x10) = fVar31;
        *(float *)(iVar25 + 0xc + iVar29 * 0x10) = fVar32;
        *piVar24 = *piVar24 + 1;
        piVar5[0x18] = (int32_t)fVar2;
        piVar5[0x19] = (int32_t)fVar3;
        piVar5[0x1a] = (int32_t)fVar31;
        piVar5[0x1b] = (int32_t)fVar32;
        func_0x0001801242c0(piVar5);
        iVar25 = *(int64_t *)(unaff_RBP + 0x418);
        arg_30h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_30h._4_4_ = *(float *)(iVar25 + 100);
        arg_38h._0_4_ = (float)arg_30h + *(float *)(iVar25 + 0x68);
        arg_38h._4_4_ = arg_30h._4_4_ + *(float *)(iVar25 + 0x6c);
        iVar25 = *(int64_t *)(unaff_RBP + 0x428);
        arg_40h._0_4_ = *(float *)(iVar25 + 0x60);
        arg_40h._4_4_ = *(float *)(iVar25 + 100);
        arg_48h._0_4_ = (float)arg_40h + *(float *)(iVar25 + 0x68);
        arg_48h._4_4_ = arg_40h._4_4_ + *(float *)(iVar25 + 0x6c);
        func_0x000180130c50(piVar5, &arg_40h, &arg_30h, unaff_R14D, 0);
        *piVar24 = *piVar24 + -1;
        if (*piVar24 == 0) {
            piVar24 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
        } else {
            piVar24 = (int32_t *)((int64_t)(*piVar24 + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
        }
        iVar26 = piVar24[1];
        iVar27 = piVar24[2];
        iVar28 = piVar24[3];
        piVar5[0x18] = *piVar24;
        piVar5[0x19] = iVar26;
        piVar5[0x1a] = iVar27;
        piVar5[0x1b] = iVar28;
        func_0x0001801242c0(piVar5);
    }
    return;
}

// ============================================================
// Function: FUN_1800fce90
// Address: 0x1800fce90
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fce90(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint32_t uVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    float var_50h;
    float var_4ch;
    int64_t var_48h;
    undefined4 uStack_40;
    float var_3ch;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) + -1;
    if (-1 < iVar14) {
        do {
            iVar16 = *(int64_t *)((int64_t)iVar14 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x8000000) != 0)) &&
                (*(char *)(iVar16 + 0x109) != '\0')) && (*(char *)(iVar16 + 0x111) == '\0')) goto code_r0x0001800fcef4;
            iVar14 = iVar14 + -1;
        } while (-1 < iVar14);
    }
    iVar16 = 0;
code_r0x0001800fcef4:
    fVar19 = *(float *)(*(int64_t *)0x180781f28 + 0x23fc);
    if ((0.0 < fVar19) || (0.0 < *(float *)(*(int64_t *)0x180781f28 + 0x23dc))) {
        iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c8);
        if ((iVar13 == 0) || (*(char *)(iVar13 + 0x109) == '\0')) {
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        if ((iVar16 != 0) || (bVar4)) {
            iVar17 = 0;
            if (iVar16 == 0) {
                iVar18 = 0;
                if (bVar4) {
                    var_58h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1290);
                    var_58h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1294);
                    var_50h = *(float *)(*(int64_t *)0x180781f28 + 0x1298);
                    var_4ch = *(float *)(*(int64_t *)0x180781f28 + 0x129c) *
                              fVar19 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    uVar6 = func_0x0001800f5fa0(&var_58h);
                    func_0x0001800fc9e0(iVar13, uVar6);
                    iVar13 = *(int64_t *)(iVar5 + 0x23d0);
                    iVar18 = *(int64_t *)(*(int64_t *)(iVar5 + 0x23c8) + 0x48);
                    if ((((iVar13 != 0) && (*(char *)(iVar13 + 0x109) != '\0')) && (*(int64_t *)(iVar13 + 0x48) != 0))
                       && (iVar17 = 0, *(int64_t *)(iVar13 + 0x48) != iVar18)) {
                        var_58h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1290);
                        var_58h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1294);
                        var_50h = *(float *)(*(int64_t *)0x180781f28 + 0x1298);
                        var_4ch = *(float *)(*(int64_t *)0x180781f28 + 0x129c) *
                                  *(float *)(*(int64_t *)0x180781f28 + 0xd9c) * *(float *)(iVar5 + 0x23fc);
                        uVar6 = func_0x0001800f5fa0(&var_58h);
                        func_0x0001800fc9e0(iVar13, uVar6);
                        iVar17 = *(int64_t *)(*(int64_t *)(iVar5 + 0x23d0) + 0x48);
                    }
                    iVar13 = *(int64_t *)(iVar5 + 0x23c8);
                    fVar19 = *(float *)(iVar5 + 0x12f8);
                    iVar7 = *(int64_t *)(iVar13 + 0x48);
                    var_58h._0_4_ = *(float *)(iVar13 + 0x60) - fVar19;
                    var_58h._4_4_ = *(float *)(iVar13 + 100) - fVar19;
                    var_50h = *(float *)(iVar13 + 0x60) + *(float *)(iVar13 + 0x68) + fVar19;
                    var_4ch = *(float *)(iVar13 + 100) + *(float *)(iVar13 + 0x6c) + fVar19;
                    if ((*(float *)(iVar7 + 0x10) <= var_50h - (float)var_58h) &&
                       (*(float *)(iVar7 + 0x14) <= var_4ch - var_58h._4_4_)) {
                        fVar19 = (float)((uint32_t)fVar19 ^ 0x80000000) - 1.0;
                        var_58h._0_4_ = (float)var_58h - fVar19;
                        var_58h._4_4_ = var_58h._4_4_ - fVar19;
                        var_50h = var_50h + fVar19;
                        var_4ch = var_4ch + fVar19;
                    }
                    func_0x000180126c00(*(int64_t *)(iVar13 + 800) + 0x88);
                    if (**(int32_t **)(iVar13 + 800) == 0) {
                        func_0x000180124200();
                    }
                    var_8h._4_4_ = *(float *)(iVar7 + 0xc) + *(float *)(iVar7 + 0x14);
                    var_8h._0_4_ = *(float *)(iVar7 + 0x10) + *(float *)(iVar7 + 8);
                    func_0x0001801244b0(*(undefined8 *)(iVar13 + 800), (float *)(iVar7 + 8), &var_8h, 0);
                    var_48h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1280);
                    var_48h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1284);
                    uStack_40 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1288);
                    var_3ch = *(float *)(*(int64_t *)0x180781f28 + 0x128c) *
                              *(float *)(iVar5 + 0x23dc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    uVar6 = func_0x0001800f5fa0(&var_48h);
                    func_0x000180126460(*(undefined8 *)(iVar13 + 800), &var_58h, &var_50h, uVar6, 
                                        *(undefined4 *)(iVar13 + 0x98));
                    func_0x0001801245e0(*(undefined8 *)(iVar13 + 800));
                }
            } else {
                piVar2 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x1588);
                for (piVar10 = piVar2;
                    (piVar10 < piVar2 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580) && (*piVar10 != iVar16));
                    piVar10 = piVar10 + 1) {
                }
                uVar11 = (int64_t)piVar10 - (int64_t)piVar2 >> 3;
                uVar15 = (uint32_t)uVar11;
                iVar13 = iVar16;
                while (-1 < (int32_t)uVar15) {
                    iVar18 = piVar2[uVar11 & 0xffffffff];
                    if ((*(uint32_t *)(iVar18 + 0x14) >> 0x18 & 1) == 0) {
                        iVar7 = iVar18;
                        if (*(int64_t *)(iVar18 + 0x418) != iVar16) {
                            while (iVar7 != iVar16) {
                                iVar7 = *(int64_t *)(iVar7 + 0x410);
                                if (iVar7 == 0) goto code_r0x0001800fd000;
                            }
                        }
                        if (((*(char *)(iVar18 + 0x109) != '\0') && (*(char *)(iVar18 + 0x111) == '\0')) &&
                           ((*(uint32_t *)(iVar18 + 0x14) & 0x2000000) <= (*(uint32_t *)(iVar16 + 0x14) & 0x2000000))) {
                            iVar13 = iVar18;
                        }
                    }
                    uVar15 = (int32_t)uVar11 - 1;
                    uVar11 = (uint64_t)uVar15;
                }
code_r0x0001800fd000:
                fVar19 = fVar19 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar15 = *(uint32_t *)(iVar16 + 0x21c);
                if (fVar19 < 1.0) {
                    uVar15 = (int32_t)(int64_t)((float)(uint64_t)(uVar15 >> 0x18) * fVar19) << 0x18 | uVar15 & 0xffffff;
                }
                func_0x0001800fc9e0(iVar13, uVar15);
                iVar18 = *(int64_t *)(iVar16 + 0x48);
            }
            piVar10 = *(int64_t **)(iVar5 + 0x2158);
            piVar2 = piVar10 + *(int32_t *)(iVar5 + 0x2150);
            iVar13 = *(int64_t *)0x180781f28;
            for (; piVar10 != piVar2; piVar10 = piVar10 + 1) {
                iVar7 = *piVar10;
                if ((iVar7 != iVar18) && (iVar7 != iVar17)) {
                    if ((iVar16 != 0) && (iVar12 = *(int64_t *)(iVar7 + 0x78), iVar12 != 0)) {
                        uVar9 = *(uint32_t *)(iVar12 + 0x14) >> 0x19 & 1;
                        uVar15 = *(uint32_t *)(iVar16 + 0x14) >> 0x19 & 1;
                        if (uVar9 == uVar15) {
                            uVar15 = *(int32_t *)(iVar13 + 0x1580) - 1;
                            if (-1 < (int32_t)uVar15) {
                                do {
                                    iVar3 = *(int64_t *)(*(int64_t *)(iVar13 + 0x1588) + (uint64_t)uVar15 * 8);
                                    if (iVar3 == iVar12) goto code_r0x0001800fd3d0;
                                } while ((iVar3 != iVar16) && (uVar15 = uVar15 - 1, -1 < (int32_t)uVar15));
                            }
                        } else if (0 < (int32_t)(uVar9 - uVar15)) goto code_r0x0001800fd3d0;
                    }
                    iVar12 = iVar7;
                    if (iVar7 == 0) {
                        iVar12 = *(int64_t *)(*(int64_t *)(iVar13 + 0x15e0) + 0x48);
                    }
                    uVar8 = func_0x0001800fa7f0(iVar12, 1, 0x1806444d0);
                    iVar13 = 0x500;
                    if (iVar16 != 0) {
                        iVar13 = 0x510;
                    }
                    puVar1 = (undefined4 *)(iVar13 + 0xd90 + *(int64_t *)0x180781f28);
                    var_48h._0_4_ = *puVar1;
                    var_48h._4_4_ = puVar1[1];
                    uStack_40 = puVar1[2];
                    var_3ch = (float)puVar1[3] *
                              *(float *)(*(int64_t *)0x180781f28 + 0xd9c) * *(float *)(iVar5 + 0x23fc);
                    var_8h._0_4_ = *(float *)(iVar7 + 0x10) + *(float *)(iVar7 + 8);
                    var_8h._4_4_ = *(float *)(iVar7 + 0x14) + *(float *)(iVar7 + 0xc);
                    uVar6 = func_0x0001800f5fa0(&var_48h);
                    func_0x000180126550(uVar8, iVar7 + 8, &var_8h, uVar6, 0, 0);
                    iVar13 = *(int64_t *)0x180781f28;
                }
code_r0x0001800fd3d0:
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fcf3c
// Address: 0x1800fcf3c
// Size: 1219 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fce90(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint32_t uVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    float var_50h;
    float var_4ch;
    int64_t var_48h;
    undefined4 uStack_40;
    float var_3ch;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) + -1;
    if (-1 < iVar14) {
        do {
            iVar16 = *(int64_t *)((int64_t)iVar14 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x8000000) != 0)) &&
                (*(char *)(iVar16 + 0x109) != '\0')) && (*(char *)(iVar16 + 0x111) == '\0')) goto code_r0x0001800fcef4;
            iVar14 = iVar14 + -1;
        } while (-1 < iVar14);
    }
    iVar16 = 0;
code_r0x0001800fcef4:
    fVar19 = *(float *)(*(int64_t *)0x180781f28 + 0x23fc);
    if ((0.0 < fVar19) || (0.0 < *(float *)(*(int64_t *)0x180781f28 + 0x23dc))) {
        iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c8);
        if ((iVar13 == 0) || (*(char *)(iVar13 + 0x109) == '\0')) {
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        if ((iVar16 != 0) || (bVar4)) {
            iVar17 = 0;
            if (iVar16 == 0) {
                iVar18 = 0;
                if (bVar4) {
                    var_58h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1290);
                    var_58h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1294);
                    var_50h = *(float *)(*(int64_t *)0x180781f28 + 0x1298);
                    var_4ch = *(float *)(*(int64_t *)0x180781f28 + 0x129c) *
                              fVar19 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    uVar6 = func_0x0001800f5fa0(&var_58h);
                    func_0x0001800fc9e0(iVar13, uVar6);
                    iVar13 = *(int64_t *)(iVar5 + 0x23d0);
                    iVar18 = *(int64_t *)(*(int64_t *)(iVar5 + 0x23c8) + 0x48);
                    if ((((iVar13 != 0) && (*(char *)(iVar13 + 0x109) != '\0')) && (*(int64_t *)(iVar13 + 0x48) != 0))
                       && (iVar17 = 0, *(int64_t *)(iVar13 + 0x48) != iVar18)) {
                        var_58h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1290);
                        var_58h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1294);
                        var_50h = *(float *)(*(int64_t *)0x180781f28 + 0x1298);
                        var_4ch = *(float *)(*(int64_t *)0x180781f28 + 0x129c) *
                                  *(float *)(*(int64_t *)0x180781f28 + 0xd9c) * *(float *)(iVar5 + 0x23fc);
                        uVar6 = func_0x0001800f5fa0(&var_58h);
                        func_0x0001800fc9e0(iVar13, uVar6);
                        iVar17 = *(int64_t *)(*(int64_t *)(iVar5 + 0x23d0) + 0x48);
                    }
                    iVar13 = *(int64_t *)(iVar5 + 0x23c8);
                    fVar19 = *(float *)(iVar5 + 0x12f8);
                    iVar7 = *(int64_t *)(iVar13 + 0x48);
                    var_58h._0_4_ = *(float *)(iVar13 + 0x60) - fVar19;
                    var_58h._4_4_ = *(float *)(iVar13 + 100) - fVar19;
                    var_50h = *(float *)(iVar13 + 0x60) + *(float *)(iVar13 + 0x68) + fVar19;
                    var_4ch = *(float *)(iVar13 + 100) + *(float *)(iVar13 + 0x6c) + fVar19;
                    if ((*(float *)(iVar7 + 0x10) <= var_50h - (float)var_58h) &&
                       (*(float *)(iVar7 + 0x14) <= var_4ch - var_58h._4_4_)) {
                        fVar19 = (float)((uint32_t)fVar19 ^ 0x80000000) - 1.0;
                        var_58h._0_4_ = (float)var_58h - fVar19;
                        var_58h._4_4_ = var_58h._4_4_ - fVar19;
                        var_50h = var_50h + fVar19;
                        var_4ch = var_4ch + fVar19;
                    }
                    func_0x000180126c00(*(int64_t *)(iVar13 + 800) + 0x88);
                    if (**(int32_t **)(iVar13 + 800) == 0) {
                        func_0x000180124200();
                    }
                    var_8h._4_4_ = *(float *)(iVar7 + 0xc) + *(float *)(iVar7 + 0x14);
                    var_8h._0_4_ = *(float *)(iVar7 + 0x10) + *(float *)(iVar7 + 8);
                    func_0x0001801244b0(*(undefined8 *)(iVar13 + 800), (float *)(iVar7 + 8), &var_8h, 0);
                    var_48h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1280);
                    var_48h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1284);
                    uStack_40 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1288);
                    var_3ch = *(float *)(*(int64_t *)0x180781f28 + 0x128c) *
                              *(float *)(iVar5 + 0x23dc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    uVar6 = func_0x0001800f5fa0(&var_48h);
                    func_0x000180126460(*(undefined8 *)(iVar13 + 800), &var_58h, &var_50h, uVar6, 
                                        *(undefined4 *)(iVar13 + 0x98));
                    func_0x0001801245e0(*(undefined8 *)(iVar13 + 800));
                }
            } else {
                piVar2 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x1588);
                for (piVar10 = piVar2;
                    (piVar10 < piVar2 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580) && (*piVar10 != iVar16));
                    piVar10 = piVar10 + 1) {
                }
                uVar11 = (int64_t)piVar10 - (int64_t)piVar2 >> 3;
                uVar15 = (uint32_t)uVar11;
                iVar13 = iVar16;
                while (-1 < (int32_t)uVar15) {
                    iVar18 = piVar2[uVar11 & 0xffffffff];
                    if ((*(uint32_t *)(iVar18 + 0x14) >> 0x18 & 1) == 0) {
                        iVar7 = iVar18;
                        if (*(int64_t *)(iVar18 + 0x418) != iVar16) {
                            while (iVar7 != iVar16) {
                                iVar7 = *(int64_t *)(iVar7 + 0x410);
                                if (iVar7 == 0) goto code_r0x0001800fd000;
                            }
                        }
                        if (((*(char *)(iVar18 + 0x109) != '\0') && (*(char *)(iVar18 + 0x111) == '\0')) &&
                           ((*(uint32_t *)(iVar18 + 0x14) & 0x2000000) <= (*(uint32_t *)(iVar16 + 0x14) & 0x2000000))) {
                            iVar13 = iVar18;
                        }
                    }
                    uVar15 = (int32_t)uVar11 - 1;
                    uVar11 = (uint64_t)uVar15;
                }
code_r0x0001800fd000:
                fVar19 = fVar19 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar15 = *(uint32_t *)(iVar16 + 0x21c);
                if (fVar19 < 1.0) {
                    uVar15 = (int32_t)(int64_t)((float)(uint64_t)(uVar15 >> 0x18) * fVar19) << 0x18 | uVar15 & 0xffffff;
                }
                func_0x0001800fc9e0(iVar13, uVar15);
                iVar18 = *(int64_t *)(iVar16 + 0x48);
            }
            piVar10 = *(int64_t **)(iVar5 + 0x2158);
            piVar2 = piVar10 + *(int32_t *)(iVar5 + 0x2150);
            iVar13 = *(int64_t *)0x180781f28;
            for (; piVar10 != piVar2; piVar10 = piVar10 + 1) {
                iVar7 = *piVar10;
                if ((iVar7 != iVar18) && (iVar7 != iVar17)) {
                    if ((iVar16 != 0) && (iVar12 = *(int64_t *)(iVar7 + 0x78), iVar12 != 0)) {
                        uVar9 = *(uint32_t *)(iVar12 + 0x14) >> 0x19 & 1;
                        uVar15 = *(uint32_t *)(iVar16 + 0x14) >> 0x19 & 1;
                        if (uVar9 == uVar15) {
                            uVar15 = *(int32_t *)(iVar13 + 0x1580) - 1;
                            if (-1 < (int32_t)uVar15) {
                                do {
                                    iVar3 = *(int64_t *)(*(int64_t *)(iVar13 + 0x1588) + (uint64_t)uVar15 * 8);
                                    if (iVar3 == iVar12) goto code_r0x0001800fd3d0;
                                } while ((iVar3 != iVar16) && (uVar15 = uVar15 - 1, -1 < (int32_t)uVar15));
                            }
                        } else if (0 < (int32_t)(uVar9 - uVar15)) goto code_r0x0001800fd3d0;
                    }
                    iVar12 = iVar7;
                    if (iVar7 == 0) {
                        iVar12 = *(int64_t *)(*(int64_t *)(iVar13 + 0x15e0) + 0x48);
                    }
                    uVar8 = func_0x0001800fa7f0(iVar12, 1, 0x1806444d0);
                    iVar13 = 0x500;
                    if (iVar16 != 0) {
                        iVar13 = 0x510;
                    }
                    puVar1 = (undefined4 *)(iVar13 + 0xd90 + *(int64_t *)0x180781f28);
                    var_48h._0_4_ = *puVar1;
                    var_48h._4_4_ = puVar1[1];
                    uStack_40 = puVar1[2];
                    var_3ch = (float)puVar1[3] *
                              *(float *)(*(int64_t *)0x180781f28 + 0xd9c) * *(float *)(iVar5 + 0x23fc);
                    var_8h._0_4_ = *(float *)(iVar7 + 0x10) + *(float *)(iVar7 + 8);
                    var_8h._4_4_ = *(float *)(iVar7 + 0x14) + *(float *)(iVar7 + 0xc);
                    uVar6 = func_0x0001800f5fa0(&var_48h);
                    func_0x000180126550(uVar8, iVar7 + 8, &var_8h, uVar6, 0, 0);
                    iVar13 = *(int64_t *)0x180781f28;
                }
code_r0x0001800fd3d0:
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fd3ff
// Address: 0x1800fd3ff
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fce90(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint32_t uVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    float var_50h;
    float var_4ch;
    int64_t var_48h;
    undefined4 uStack_40;
    float var_3ch;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) + -1;
    if (-1 < iVar14) {
        do {
            iVar16 = *(int64_t *)((int64_t)iVar14 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x8000000) != 0)) &&
                (*(char *)(iVar16 + 0x109) != '\0')) && (*(char *)(iVar16 + 0x111) == '\0')) goto code_r0x0001800fcef4;
            iVar14 = iVar14 + -1;
        } while (-1 < iVar14);
    }
    iVar16 = 0;
code_r0x0001800fcef4:
    fVar19 = *(float *)(*(int64_t *)0x180781f28 + 0x23fc);
    if ((0.0 < fVar19) || (0.0 < *(float *)(*(int64_t *)0x180781f28 + 0x23dc))) {
        iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c8);
        if ((iVar13 == 0) || (*(char *)(iVar13 + 0x109) == '\0')) {
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        if ((iVar16 != 0) || (bVar4)) {
            iVar17 = 0;
            if (iVar16 == 0) {
                iVar18 = 0;
                if (bVar4) {
                    var_58h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1290);
                    var_58h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1294);
                    var_50h = *(float *)(*(int64_t *)0x180781f28 + 0x1298);
                    var_4ch = *(float *)(*(int64_t *)0x180781f28 + 0x129c) *
                              fVar19 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    uVar6 = func_0x0001800f5fa0(&var_58h);
                    func_0x0001800fc9e0(iVar13, uVar6);
                    iVar13 = *(int64_t *)(iVar5 + 0x23d0);
                    iVar18 = *(int64_t *)(*(int64_t *)(iVar5 + 0x23c8) + 0x48);
                    if ((((iVar13 != 0) && (*(char *)(iVar13 + 0x109) != '\0')) && (*(int64_t *)(iVar13 + 0x48) != 0))
                       && (iVar17 = 0, *(int64_t *)(iVar13 + 0x48) != iVar18)) {
                        var_58h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1290);
                        var_58h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1294);
                        var_50h = *(float *)(*(int64_t *)0x180781f28 + 0x1298);
                        var_4ch = *(float *)(*(int64_t *)0x180781f28 + 0x129c) *
                                  *(float *)(*(int64_t *)0x180781f28 + 0xd9c) * *(float *)(iVar5 + 0x23fc);
                        uVar6 = func_0x0001800f5fa0(&var_58h);
                        func_0x0001800fc9e0(iVar13, uVar6);
                        iVar17 = *(int64_t *)(*(int64_t *)(iVar5 + 0x23d0) + 0x48);
                    }
                    iVar13 = *(int64_t *)(iVar5 + 0x23c8);
                    fVar19 = *(float *)(iVar5 + 0x12f8);
                    iVar7 = *(int64_t *)(iVar13 + 0x48);
                    var_58h._0_4_ = *(float *)(iVar13 + 0x60) - fVar19;
                    var_58h._4_4_ = *(float *)(iVar13 + 100) - fVar19;
                    var_50h = *(float *)(iVar13 + 0x60) + *(float *)(iVar13 + 0x68) + fVar19;
                    var_4ch = *(float *)(iVar13 + 100) + *(float *)(iVar13 + 0x6c) + fVar19;
                    if ((*(float *)(iVar7 + 0x10) <= var_50h - (float)var_58h) &&
                       (*(float *)(iVar7 + 0x14) <= var_4ch - var_58h._4_4_)) {
                        fVar19 = (float)((uint32_t)fVar19 ^ 0x80000000) - 1.0;
                        var_58h._0_4_ = (float)var_58h - fVar19;
                        var_58h._4_4_ = var_58h._4_4_ - fVar19;
                        var_50h = var_50h + fVar19;
                        var_4ch = var_4ch + fVar19;
                    }
                    func_0x000180126c00(*(int64_t *)(iVar13 + 800) + 0x88);
                    if (**(int32_t **)(iVar13 + 800) == 0) {
                        func_0x000180124200();
                    }
                    var_8h._4_4_ = *(float *)(iVar7 + 0xc) + *(float *)(iVar7 + 0x14);
                    var_8h._0_4_ = *(float *)(iVar7 + 0x10) + *(float *)(iVar7 + 8);
                    func_0x0001801244b0(*(undefined8 *)(iVar13 + 800), (float *)(iVar7 + 8), &var_8h, 0);
                    var_48h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1280);
                    var_48h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1284);
                    uStack_40 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1288);
                    var_3ch = *(float *)(*(int64_t *)0x180781f28 + 0x128c) *
                              *(float *)(iVar5 + 0x23dc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    uVar6 = func_0x0001800f5fa0(&var_48h);
                    func_0x000180126460(*(undefined8 *)(iVar13 + 800), &var_58h, &var_50h, uVar6, 
                                        *(undefined4 *)(iVar13 + 0x98));
                    func_0x0001801245e0(*(undefined8 *)(iVar13 + 800));
                }
            } else {
                piVar2 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x1588);
                for (piVar10 = piVar2;
                    (piVar10 < piVar2 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580) && (*piVar10 != iVar16));
                    piVar10 = piVar10 + 1) {
                }
                uVar11 = (int64_t)piVar10 - (int64_t)piVar2 >> 3;
                uVar15 = (uint32_t)uVar11;
                iVar13 = iVar16;
                while (-1 < (int32_t)uVar15) {
                    iVar18 = piVar2[uVar11 & 0xffffffff];
                    if ((*(uint32_t *)(iVar18 + 0x14) >> 0x18 & 1) == 0) {
                        iVar7 = iVar18;
                        if (*(int64_t *)(iVar18 + 0x418) != iVar16) {
                            while (iVar7 != iVar16) {
                                iVar7 = *(int64_t *)(iVar7 + 0x410);
                                if (iVar7 == 0) goto code_r0x0001800fd000;
                            }
                        }
                        if (((*(char *)(iVar18 + 0x109) != '\0') && (*(char *)(iVar18 + 0x111) == '\0')) &&
                           ((*(uint32_t *)(iVar18 + 0x14) & 0x2000000) <= (*(uint32_t *)(iVar16 + 0x14) & 0x2000000))) {
                            iVar13 = iVar18;
                        }
                    }
                    uVar15 = (int32_t)uVar11 - 1;
                    uVar11 = (uint64_t)uVar15;
                }
code_r0x0001800fd000:
                fVar19 = fVar19 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar15 = *(uint32_t *)(iVar16 + 0x21c);
                if (fVar19 < 1.0) {
                    uVar15 = (int32_t)(int64_t)((float)(uint64_t)(uVar15 >> 0x18) * fVar19) << 0x18 | uVar15 & 0xffffff;
                }
                func_0x0001800fc9e0(iVar13, uVar15);
                iVar18 = *(int64_t *)(iVar16 + 0x48);
            }
            piVar10 = *(int64_t **)(iVar5 + 0x2158);
            piVar2 = piVar10 + *(int32_t *)(iVar5 + 0x2150);
            iVar13 = *(int64_t *)0x180781f28;
            for (; piVar10 != piVar2; piVar10 = piVar10 + 1) {
                iVar7 = *piVar10;
                if ((iVar7 != iVar18) && (iVar7 != iVar17)) {
                    if ((iVar16 != 0) && (iVar12 = *(int64_t *)(iVar7 + 0x78), iVar12 != 0)) {
                        uVar9 = *(uint32_t *)(iVar12 + 0x14) >> 0x19 & 1;
                        uVar15 = *(uint32_t *)(iVar16 + 0x14) >> 0x19 & 1;
                        if (uVar9 == uVar15) {
                            uVar15 = *(int32_t *)(iVar13 + 0x1580) - 1;
                            if (-1 < (int32_t)uVar15) {
                                do {
                                    iVar3 = *(int64_t *)(*(int64_t *)(iVar13 + 0x1588) + (uint64_t)uVar15 * 8);
                                    if (iVar3 == iVar12) goto code_r0x0001800fd3d0;
                                } while ((iVar3 != iVar16) && (uVar15 = uVar15 - 1, -1 < (int32_t)uVar15));
                            }
                        } else if (0 < (int32_t)(uVar9 - uVar15)) goto code_r0x0001800fd3d0;
                    }
                    iVar12 = iVar7;
                    if (iVar7 == 0) {
                        iVar12 = *(int64_t *)(*(int64_t *)(iVar13 + 0x15e0) + 0x48);
                    }
                    uVar8 = func_0x0001800fa7f0(iVar12, 1, 0x1806444d0);
                    iVar13 = 0x500;
                    if (iVar16 != 0) {
                        iVar13 = 0x510;
                    }
                    puVar1 = (undefined4 *)(iVar13 + 0xd90 + *(int64_t *)0x180781f28);
                    var_48h._0_4_ = *puVar1;
                    var_48h._4_4_ = puVar1[1];
                    uStack_40 = puVar1[2];
                    var_3ch = (float)puVar1[3] *
                              *(float *)(*(int64_t *)0x180781f28 + 0xd9c) * *(float *)(iVar5 + 0x23fc);
                    var_8h._0_4_ = *(float *)(iVar7 + 0x10) + *(float *)(iVar7 + 8);
                    var_8h._4_4_ = *(float *)(iVar7 + 0x14) + *(float *)(iVar7 + 0xc);
                    uVar6 = func_0x0001800f5fa0(&var_48h);
                    func_0x000180126550(uVar8, iVar7 + 8, &var_8h, uVar6, 0, 0);
                    iVar13 = *(int64_t *)0x180781f28;
                }
code_r0x0001800fd3d0:
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fd410
// Address: 0x1800fd410
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fd45e
// Address: 0x1800fd45e
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fd482
// Address: 0x1800fd482
// Size: 1221 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fd947
// Address: 0x1800fd947
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fd9f7
// Address: 0x1800fd9f7
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fda1d
// Address: 0x1800fda1d
// Size: 211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fdaf0
// Address: 0x1800fdaf0
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fdb70
// Address: 0x1800fdb70
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fdb92
// Address: 0x1800fdb92
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel

void fcn.1800fd410(int64_t arg_e8h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    undefined8 uVar7;
    bool bVar8;
    bool bVar9;
    int64_t iVar10;
    char cVar11;
    int32_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t *piVar19;
    code *pcVar20;
    int32_t iVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_44h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 8) == *(int32_t *)(*(int64_t *)0x180781f28 + 4)) {
        return;
    }
    if (*(char *)(*(int64_t *)0x180781f28 + 1) == '\0') {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) == (code *)0x0) {
            return;
        }
    // WARNING: Could not recover jumptable at 0x0001800fd45b. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644478);
        return;
    }
    iVar18 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2978);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2970) * 0x20 + iVar18;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar18 != iVar15; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 2) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar10 + 0xb0) != '\0') {
        iVar13 = *(int16_t *)(iVar10 + 0x2a60);
        iVar21 = *(int32_t *)(iVar17 + 0x15b0);
        if (iVar13 < iVar21) {
            do {
                if ((*(uint32_t *)(*(int64_t *)(iVar17 + 0x15e0) + 0x14) & 0x1000000) == 0) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644c98);
                    }
                    func_0x000180105c20();
                } else if ((*(int64_t *)(iVar17 + 0x24d0) == 0) ||
                          (*(int64_t *)(*(int64_t *)(iVar17 + 0x24d0) + 0x188) != *(int64_t *)(iVar17 + 0x15e0))) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dd8);
                    }
                    func_0x0001800fea60();
                } else {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644dc0);
                    }
                    func_0x0001801346c0();
                }
                iVar13 = *(int16_t *)(iVar10 + 0x2a60);
                iVar21 = *(int32_t *)(iVar17 + 0x15b0);
            } while (iVar13 < iVar21);
        }
        if (iVar21 == iVar13) {
            func_0x00018010a070(iVar10 + 0x2a60);
        }
    }
    pcVar20 = *(code **)(iVar10 + 0xc70);
    if ((pcVar20 != (code *)0x0) &&
       (((*(int64_t *)(iVar10 + 0x28b0) != *(int64_t *)(iVar10 + 0x28c4) ||
         (*(int64_t *)(iVar10 + 0x28b8) != *(int64_t *)(iVar10 + 0x28cc))) ||
        (*(int32_t *)(iVar10 + 0x28c0) != *(int32_t *)(iVar10 + 0x28d4))))) {
        iVar17 = *(int64_t *)0x180781f28;
        iVar18 = func_0x0001801134f0(*(undefined4 *)(iVar10 + 0x28c0));
        if (iVar18 == 0) {
            iVar18 = **(int64_t **)(iVar17 + 0x2158);
        }
        (*pcVar20)(iVar10, iVar18, (int64_t *)(iVar10 + 0x28b0));
    }
    iVar21 = 0;
    bVar9 = false;
    *(undefined *)(iVar10 + 2) = 0;
    *(uint32_t *)(iVar10 + 0x2c8c) = (uint32_t)(*(char *)(iVar10 + 0x28b1) != '\0');
    iVar18 = *(int64_t *)(iVar10 + 0x15e0);
    if (((iVar18 != 0) && (*(char *)(iVar18 + 0x112) != '\0')) && (*(char *)(iVar18 + 0x10b) == '\0')) {
        *(undefined *)(iVar18 + 0x109) = 0;
        if ((*(int64_t *)(iVar10 + 0x21d8) != 0) &&
           (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x418) == *(int64_t *)(iVar10 + 0x15e0))) {
            func_0x00018010e050(0, 0);
        }
    }
    func_0x000180105c20();
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) != 0) {
        func_0x000180111e20();
    }
    if (((((*(int64_t *)(iVar18 + 0x21d8) != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
         (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) == 0 &&
         (uVar5 = *(uint32_t *)(iVar18 + 0x227c), (uVar5 & 0xf) != 0)))) && (-1 < (char)uVar5)) {
        func_0x000180110e90();
    }
    func_0x000180114fc0(iVar10);
    iVar18 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x2160) != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1308) = 0x3f800000;
        *(undefined8 *)(iVar18 + 0x2160) = 0;
        if (*(char *)(iVar18 + 0x8a) != '\0') {
            *(undefined4 *)(iVar18 + 0xd98) = 0x3f800000;
        }
    }
    if (*(char *)(iVar10 + 0x2400) != '\0') {
        if ((*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4)) &&
           ((((*(uint8_t *)(iVar10 + 0x2404) & 0x20) != 0 || (*(int32_t *)(iVar10 + 0x240c) == -1)) ||
            (cVar11 = func_0x000180107f80(), cVar11 == '\0')))) {
            bVar8 = true;
        } else {
            bVar8 = false;
        }
        if ((*(char *)(iVar10 + 0x244a) != '\0') || (bVar8)) {
            func_0x0001801120a0();
        }
        if (((*(char *)(iVar10 + 0x2400) != '\0') && (*(int32_t *)(iVar10 + 0x2408) + 1 < *(int32_t *)(iVar10 + 4))) &&
           ((*(uint8_t *)(iVar10 + 0x2404) & 1) == 0)) {
            *(undefined *)(iVar10 + 0x2401) = 1;
            func_0x00018010ce60(0x18063e3a8);
            *(undefined *)(iVar10 + 0x2401) = 0;
        }
    }
    *(undefined4 *)(iVar10 + 8) = *(undefined4 *)(iVar10 + 4);
    *(undefined *)(iVar10 + 1) = 0;
    func_0x000180107520();
    iVar18 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) ||
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x163c) != 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x1651) == '\0')))
        ) || ((iVar17 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar17 != 0 &&
              (*(char *)(iVar17 + 0x110) != '\0')))) goto code_r0x0001800fd905;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    if (*(char *)(*(int64_t *)0x180781f28 + 0xb50) != '\0') {
        if (iVar15 == 0) {
            iVar16 = 0;
        } else {
            iVar16 = *(int64_t *)(iVar15 + 0x418);
            if (((iVar16 != 0) && ((*(uint32_t *)(iVar16 + 0x14) & 0x4000000) != 0)) &&
               (cVar11 = func_0x00018010cf10(*(undefined4 *)(iVar16 + 0xd0), 0x800), cVar11 == '\0'))
            goto code_r0x0001800fd8b8;
        }
        if (iVar15 == 0) {
            if (iVar17 != 0) {
                func_0x00018010e050(0, 2);
            }
        } else {
            func_0x0001800faa00(iVar15);
            if (((*(uint8_t *)(iVar15 + 0x130) & 1) == 0) &&
               (((*(uint8_t *)(iVar16 + 0x14) & 1) == 0 || ((*(uint8_t *)(iVar16 + 0x495) & 1) != 0)))) {
                if ((*(float *)(iVar18 + 0xafc) < *(float *)(iVar16 + 0x60)) ||
                   (((*(float *)(iVar18 + 0xb00) < *(float *)(iVar16 + 100) ||
                     (*(float *)(iVar16 + 0x60) + *(float *)(iVar16 + 0x70) <= *(float *)(iVar18 + 0xafc))) ||
                    (*(float *)(iVar16 + 0xa0) + *(float *)(iVar16 + 100) <= *(float *)(iVar18 + 0xb00))))) {
                    *(undefined8 *)(iVar18 + 0x1600) = 0;
                }
            }
            if (*(char *)(iVar18 + 0x1651) != '\0') {
                *(undefined4 *)(iVar18 + 0x1668) = *(undefined4 *)(iVar18 + 0x163c);
                *(undefined8 *)(iVar18 + 0x1600) = 0;
            }
        }
    }
code_r0x0001800fd8b8:
    if ((*(char *)(iVar18 + 0xb51) != '\0') && (*(int32_t *)(iVar18 + 0x163c) == 0)) {
        iVar18 = func_0x00018010cfa0();
        if ((iVar15 != 0) && ((iVar18 == 0 || (cVar11 = func_0x000180106250(iVar15, iVar18), cVar11 != '\0')))) {
            bVar9 = true;
        }
        if (bVar9) {
            iVar18 = iVar15;
        }
        func_0x00018010d210(iVar18, 1);
    }
code_r0x0001800fd905:
    iVar18 = *(int64_t *)0x180781f28;
    piVar2 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd80);
    iVar14 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd84);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(piVar2, iVar12);
    }
    *piVar2 = 0;
    iVar14 = iVar21;
    if (0 < *(int32_t *)(iVar18 + 0x2150)) {
        do {
            iVar17 = *(int64_t *)(*(int64_t *)(iVar18 + 0x2158) + (int64_t)iVar14 * 8);
            *(undefined4 *)(iVar17 + 0x90) = *(undefined4 *)(iVar17 + 8);
            *(undefined4 *)(iVar17 + 0x94) = *(undefined4 *)(iVar17 + 0xc);
            *(undefined4 *)(iVar17 + 0x98) = *(undefined4 *)(iVar17 + 0x10);
            *(undefined4 *)(iVar17 + 0x9c) = *(undefined4 *)(iVar17 + 0x14);
            if (((((*(int32_t *)(iVar18 + 4) <= *(int32_t *)(iVar17 + 0x84)) && (0.0 < *(float *)(iVar17 + 0x10))) &&
                 (0.0 < *(float *)(iVar17 + 0x14))) || (iVar14 < 1)) &&
               ((iVar15 = *(int64_t *)(iVar17 + 0x78), iVar15 == 0 ||
                ((*(char *)(iVar15 + 0x109) != '\0' && (*(char *)(iVar15 + 0x111) == '\0')))))) {
                iVar12 = *(int32_t *)(iVar18 + 0xd84);
                if (*piVar2 == iVar12) {
                    iVar1 = *piVar2 + 1;
                    if (iVar12 == 0) {
                        iVar12 = 8;
                    } else {
                        iVar12 = iVar12 / 2 + iVar12;
                    }
                    if (iVar1 < iVar12) {
                        iVar1 = iVar12;
                    }
                    func_0x00018011f4f0(piVar2, iVar1);
                }
                *(int64_t *)(*(int64_t *)(iVar18 + 0xd88) + (int64_t)*piVar2 * 8) = iVar17;
                *piVar2 = *piVar2 + 1;
            }
            iVar14 = iVar14 + 1;
        } while (iVar14 < *(int32_t *)(iVar18 + 0x2150));
    }
    puVar3 = (undefined4 *)(iVar10 + 0x15a0);
    iVar18 = **(int64_t **)(iVar18 + 0x2158);
    *(undefined2 *)(iVar18 + 0x71) = 0;
    *(undefined *)(iVar18 + 0x73) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0x15a4);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        iVar12 = iVar21;
        if (0 < iVar14) {
            iVar12 = iVar14;
        }
        func_0x00018011f4f0(puVar3, iVar12);
    }
    *puVar3 = 0;
    func_0x00018011f4f0(puVar3, *(undefined4 *)(iVar10 + 0x1580));
    piVar19 = *(int64_t **)(iVar10 + 0x1588);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x1580);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        if ((*(char *)(*piVar19 + 0x109) == '\0') || ((*(uint32_t *)(*piVar19 + 0x14) & 0x1000000) == 0)) {
            func_0x0001800fc6e0(puVar3);
        }
    }
    uVar6 = *puVar3;
    *puVar3 = *(undefined4 *)(iVar10 + 0x1580);
    *(undefined4 *)(iVar10 + 0x1580) = uVar6;
    uVar6 = *(undefined4 *)(iVar10 + 0x15a4);
    *(undefined4 *)(iVar10 + 0x15a4) = *(undefined4 *)(iVar10 + 0x1584);
    *(undefined4 *)(iVar10 + 0x1584) = uVar6;
    uVar7 = *(undefined8 *)(iVar10 + 0x15a8);
    *(undefined8 *)(iVar10 + 0x15a8) = *(undefined8 *)(iVar10 + 0x1588);
    *(undefined4 *)(iVar10 + 0x100) = *(undefined4 *)(iVar10 + 0x15d0);
    *(undefined8 *)(iVar10 + 0x1588) = uVar7;
    func_0x000180106e00();
    piVar19 = *(int64_t **)(iVar10 + 0x12e0);
    piVar4 = piVar19 + *(int32_t *)(iVar10 + 0x12d8);
    for (; piVar19 != piVar4; piVar19 = piVar19 + 1) {
        *(undefined *)(*piVar19 + 0x50) = 0;
    }
    *(undefined8 *)(iVar10 + 0xaf4) = *(undefined8 *)(iVar10 + 0x118);
    *(undefined *)(iVar10 + 0xc14) = 0;
    *(undefined8 *)(iVar10 + 0x128) = 0;
    iVar14 = *(int32_t *)(iVar10 + 0xc1c);
    if (iVar14 < 0) {
        iVar14 = iVar14 + iVar14 / 2;
        if (0 < iVar14) {
            iVar21 = iVar14;
        }
        func_0x00018011f8d0(iVar10 + 0xc18, iVar21);
    }
    *(undefined4 *)(iVar10 + 0xc18) = 0;
    iVar18 = *(int64_t *)(iVar10 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar10 + 0x2970) * 0x20 + iVar18;
    for (; iVar18 != iVar17; iVar18 = iVar18 + 0x20) {
        if (*(int32_t *)(iVar18 + 4) == 3) {
            (**(code **)(iVar18 + 0x10))(iVar10, iVar18);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fdba0
// Address: 0x1800fdba0
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fdba0(int64_t arg1, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    uint64_t *puVar3;
    uint32_t **ppuVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int32_t *piVar7;
    uint32_t *puVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    uint32_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    undefined4 *puVar16;
    int64_t iVar17;
    uint64_t *puVar18;
    uint64_t uVar19;
    int32_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t **ppuVar23;
    uint64_t uVar24;
    int64_t *piVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_10h;
    
    puVar10 = *(undefined4 **)0x180781f28;
    if ((*(undefined4 **)0x180781f28)[2] != (*(undefined4 **)0x180781f28)[1]) {
        fcn.1800fd410(arg_78h);
    }
    if (puVar10[4] != puVar10[1]) {
        uVar24 = 0;
        puVar10[0x3f] = 0;
        puVar10[4] = puVar10[1];
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 4) {
                arg1 = (int64_t)puVar10;
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        puVar14 = *(undefined4 **)0x180781f28;
        for (; *(undefined4 **)0x180781f28 = puVar14, piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            puVar16 = (undefined4 *)(iVar17 + 200);
            *(undefined4 **)(iVar17 + 0x40) = puVar16;
            puVar1 = (undefined4 *)(iVar17 + 0xd8);
            *(undefined4 **)(iVar17 + 0x110) = puVar1;
            *(int64_t *)(iVar17 + 0x118) = iVar17 + 0x120;
            iVar5 = *(int32_t *)(iVar17 + 0xdc);
            if (iVar5 < 0) {
                uVar11 = (iVar5 + 1 >> 1) + iVar5;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            puVar1 = *(undefined4 **)(iVar17 + 0x118);
            uVar11 = puVar1[1];
            arg1 = (int64_t)uVar11;
            if ((int32_t)uVar11 < 0) {
                uVar11 = ((int32_t)(uVar11 + 1) >> 1) + uVar11;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                arg1 = (int64_t)puVar1;
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            *(undefined *)puVar16 = 1;
            *(undefined8 *)(iVar17 + 0xcc) = 0;
            *(undefined4 *)(iVar17 + 0xd4) = 0;
            *(undefined8 *)(iVar17 + 0xe8) = *(undefined8 *)(iVar17 + 8);
            if ((*(uint32_t *)(iVar17 + 4) & 0x1000) == 0) {
                uVar26 = *(undefined4 *)(iVar17 + 0x10);
                uVar27 = *(undefined4 *)(iVar17 + 0x14);
            } else {
                uVar26 = 0;
                uVar27 = 0;
            }
            puVar13 = (undefined8 *)(iVar17 + 0x18);
            *(undefined4 *)(iVar17 + 0xf0) = uVar26;
            *(undefined4 *)(iVar17 + 0xf4) = uVar27;
            if (*(float *)puVar13 == 0.0) {
                puVar13 = (undefined8 *)(puVar14 + 0x10);
            }
            puVar14 = *(undefined4 **)0x180781f28 + 0x35c;
            *(undefined8 *)(iVar17 + 0xf8) = *puVar13;
            *(undefined4 **)(iVar17 + 0x108) = puVar14;
            *(int64_t *)(iVar17 + 0x100) = iVar17;
            if ((*(int64_t *)(iVar17 + 0xb8) != 0) && (*(float *)(iVar17 + 0xac) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 0, 0x1806444c0);
                func_0x0001801270f0(puVar16, *(undefined8 *)(iVar17 + 0x110), uVar15);
                arg1 = (int64_t)puVar16;
            }
            puVar14 = *(undefined4 **)0x180781f28;
        }
        fcn.1800fce90(arg1);
        iVar17 = *(int64_t *)(puVar10 + 0x8f0);
        if ((iVar17 == 0) || ((*(uint32_t *)(iVar17 + 0x14) & 0x2000) != 0)) {
            uVar19 = 0;
            if (iVar17 == 0) {
                uVar22 = 0;
            } else {
                uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
                uVar19 = uVar24;
            }
        } else {
            uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
            uVar19 = *(uint64_t *)(iVar17 + 0x428);
        }
        puVar18 = *(uint64_t **)(puVar10 + 0x562);
        puVar3 = puVar18 + (int32_t)puVar10[0x560];
        for (; puVar18 != puVar3; puVar18 = puVar18 + 1) {
            uVar6 = *puVar18;
            if ((((*(char *)(uVar6 + 0x109) != '\0') && (*(char *)(uVar6 + 0x111) == '\0')) &&
                ((*(uint32_t *)(uVar6 + 0x14) >> 0x18 & 1) == 0)) && ((uVar6 != uVar19 && (uVar6 != uVar22)))) {
                func_0x0001800fc7b0(uVar6, *(uint32_t *)(uVar6 + 0x14) >> 0x19 & 1);
            }
        }
        if (((uVar19 != 0) && (*(char *)(uVar19 + 0x109) != '\0')) && (*(char *)(uVar19 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar19, *(uint32_t *)(uVar19 + 0x14) >> 0x19 & 1);
        }
        if (((uVar22 != 0) && (*(char *)(uVar22 + 0x109) != '\0')) && (*(char *)(uVar22 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar22, *(uint32_t *)(uVar22 + 0x14) >> 0x19 & 1);
        }
        if ((*(char *)(puVar10 + 0x23) != '\0') && (puVar10[0x994] != -1)) {
            func_0x0001800f8020(*(undefined8 *)(puVar10 + 0x46), puVar10[0x3b0]);
        }
        *(undefined8 *)(puVar10 + 0x3d) = 0;
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        for (; piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            piVar7 = *(int32_t **)(iVar17 + 0x110);
            iVar5 = *piVar7;
            iVar12 = piVar7[1];
            iVar20 = **(int32_t **)(iVar17 + 0x118) + iVar5;
            if (iVar12 < iVar20) {
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                iVar9 = iVar20;
                if (iVar20 < iVar12) {
                    iVar9 = iVar12;
                }
                func_0x00018011f4f0(piVar7, iVar9);
            }
            *piVar7 = iVar20;
            piVar7 = *(int32_t **)(iVar17 + 0x118);
            if (*piVar7 != 0) {
                func_0x000180498030(*(int64_t *)(*(int64_t *)(iVar17 + 0x110) + 8) + (int64_t)iVar5 * 8, 
                                    *(undefined8 *)(piVar7 + 2), (int64_t)*piVar7 << 3);
                iVar5 = piVar7[1];
                if (iVar5 < 0) {
                    uVar11 = (iVar5 + 1 >> 1) + iVar5;
                    uVar19 = uVar24;
                    if (0 < (int32_t)uVar11) {
                        uVar19 = (uint64_t)uVar11;
                    }
                    func_0x00018011f4f0(piVar7, uVar19);
                }
                *piVar7 = 0;
            }
            if ((*(int64_t *)(iVar17 + 0xc0) != 0) && (*(float *)(iVar17 + 0xb0) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 1, 0x1806444d0);
                func_0x0001801270f0(iVar17 + 200, *(undefined8 *)(iVar17 + 0x110), uVar15);
            }
            ppuVar23 = *(uint32_t ***)(iVar17 + 0xe0);
            ppuVar4 = ppuVar23 + *(int32_t *)(iVar17 + 0xd8);
            for (; ppuVar23 != ppuVar4; ppuVar23 = ppuVar23 + 1) {
                puVar8 = *ppuVar23;
                uVar11 = *puVar8;
                while (0 < (int32_t)uVar11) {
                    if ((*(int32_t *)(*(int64_t *)(puVar8 + 2) + -0x20 + (uint64_t)uVar11 * 0x48) != 0) ||
                       (*(int64_t *)(*(int64_t *)(puVar8 + 2) + -0x18 + (uint64_t)uVar11 * 0x48) != 0)) break;
                    uVar11 = uVar11 - 1;
                    *puVar8 = uVar11;
                }
            }
            puVar10[0x3d] = puVar10[0x3d] + *(int32_t *)(iVar17 + 0xd4);
            puVar10[0x3e] = puVar10[0x3e] + *(int32_t *)(iVar17 + 0xd0);
        }
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 5) {
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fdbca
// Address: 0x1800fdbca
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fdba0(int64_t arg1, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    uint64_t *puVar3;
    uint32_t **ppuVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int32_t *piVar7;
    uint32_t *puVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    uint32_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    undefined4 *puVar16;
    int64_t iVar17;
    uint64_t *puVar18;
    uint64_t uVar19;
    int32_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t **ppuVar23;
    uint64_t uVar24;
    int64_t *piVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_10h;
    
    puVar10 = *(undefined4 **)0x180781f28;
    if ((*(undefined4 **)0x180781f28)[2] != (*(undefined4 **)0x180781f28)[1]) {
        fcn.1800fd410(arg_78h);
    }
    if (puVar10[4] != puVar10[1]) {
        uVar24 = 0;
        puVar10[0x3f] = 0;
        puVar10[4] = puVar10[1];
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 4) {
                arg1 = (int64_t)puVar10;
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        puVar14 = *(undefined4 **)0x180781f28;
        for (; *(undefined4 **)0x180781f28 = puVar14, piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            puVar16 = (undefined4 *)(iVar17 + 200);
            *(undefined4 **)(iVar17 + 0x40) = puVar16;
            puVar1 = (undefined4 *)(iVar17 + 0xd8);
            *(undefined4 **)(iVar17 + 0x110) = puVar1;
            *(int64_t *)(iVar17 + 0x118) = iVar17 + 0x120;
            iVar5 = *(int32_t *)(iVar17 + 0xdc);
            if (iVar5 < 0) {
                uVar11 = (iVar5 + 1 >> 1) + iVar5;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            puVar1 = *(undefined4 **)(iVar17 + 0x118);
            uVar11 = puVar1[1];
            arg1 = (int64_t)uVar11;
            if ((int32_t)uVar11 < 0) {
                uVar11 = ((int32_t)(uVar11 + 1) >> 1) + uVar11;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                arg1 = (int64_t)puVar1;
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            *(undefined *)puVar16 = 1;
            *(undefined8 *)(iVar17 + 0xcc) = 0;
            *(undefined4 *)(iVar17 + 0xd4) = 0;
            *(undefined8 *)(iVar17 + 0xe8) = *(undefined8 *)(iVar17 + 8);
            if ((*(uint32_t *)(iVar17 + 4) & 0x1000) == 0) {
                uVar26 = *(undefined4 *)(iVar17 + 0x10);
                uVar27 = *(undefined4 *)(iVar17 + 0x14);
            } else {
                uVar26 = 0;
                uVar27 = 0;
            }
            puVar13 = (undefined8 *)(iVar17 + 0x18);
            *(undefined4 *)(iVar17 + 0xf0) = uVar26;
            *(undefined4 *)(iVar17 + 0xf4) = uVar27;
            if (*(float *)puVar13 == 0.0) {
                puVar13 = (undefined8 *)(puVar14 + 0x10);
            }
            puVar14 = *(undefined4 **)0x180781f28 + 0x35c;
            *(undefined8 *)(iVar17 + 0xf8) = *puVar13;
            *(undefined4 **)(iVar17 + 0x108) = puVar14;
            *(int64_t *)(iVar17 + 0x100) = iVar17;
            if ((*(int64_t *)(iVar17 + 0xb8) != 0) && (*(float *)(iVar17 + 0xac) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 0, 0x1806444c0);
                func_0x0001801270f0(puVar16, *(undefined8 *)(iVar17 + 0x110), uVar15);
                arg1 = (int64_t)puVar16;
            }
            puVar14 = *(undefined4 **)0x180781f28;
        }
        fcn.1800fce90(arg1);
        iVar17 = *(int64_t *)(puVar10 + 0x8f0);
        if ((iVar17 == 0) || ((*(uint32_t *)(iVar17 + 0x14) & 0x2000) != 0)) {
            uVar19 = 0;
            if (iVar17 == 0) {
                uVar22 = 0;
            } else {
                uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
                uVar19 = uVar24;
            }
        } else {
            uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
            uVar19 = *(uint64_t *)(iVar17 + 0x428);
        }
        puVar18 = *(uint64_t **)(puVar10 + 0x562);
        puVar3 = puVar18 + (int32_t)puVar10[0x560];
        for (; puVar18 != puVar3; puVar18 = puVar18 + 1) {
            uVar6 = *puVar18;
            if ((((*(char *)(uVar6 + 0x109) != '\0') && (*(char *)(uVar6 + 0x111) == '\0')) &&
                ((*(uint32_t *)(uVar6 + 0x14) >> 0x18 & 1) == 0)) && ((uVar6 != uVar19 && (uVar6 != uVar22)))) {
                func_0x0001800fc7b0(uVar6, *(uint32_t *)(uVar6 + 0x14) >> 0x19 & 1);
            }
        }
        if (((uVar19 != 0) && (*(char *)(uVar19 + 0x109) != '\0')) && (*(char *)(uVar19 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar19, *(uint32_t *)(uVar19 + 0x14) >> 0x19 & 1);
        }
        if (((uVar22 != 0) && (*(char *)(uVar22 + 0x109) != '\0')) && (*(char *)(uVar22 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar22, *(uint32_t *)(uVar22 + 0x14) >> 0x19 & 1);
        }
        if ((*(char *)(puVar10 + 0x23) != '\0') && (puVar10[0x994] != -1)) {
            func_0x0001800f8020(*(undefined8 *)(puVar10 + 0x46), puVar10[0x3b0]);
        }
        *(undefined8 *)(puVar10 + 0x3d) = 0;
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        for (; piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            piVar7 = *(int32_t **)(iVar17 + 0x110);
            iVar5 = *piVar7;
            iVar12 = piVar7[1];
            iVar20 = **(int32_t **)(iVar17 + 0x118) + iVar5;
            if (iVar12 < iVar20) {
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                iVar9 = iVar20;
                if (iVar20 < iVar12) {
                    iVar9 = iVar12;
                }
                func_0x00018011f4f0(piVar7, iVar9);
            }
            *piVar7 = iVar20;
            piVar7 = *(int32_t **)(iVar17 + 0x118);
            if (*piVar7 != 0) {
                func_0x000180498030(*(int64_t *)(*(int64_t *)(iVar17 + 0x110) + 8) + (int64_t)iVar5 * 8, 
                                    *(undefined8 *)(piVar7 + 2), (int64_t)*piVar7 << 3);
                iVar5 = piVar7[1];
                if (iVar5 < 0) {
                    uVar11 = (iVar5 + 1 >> 1) + iVar5;
                    uVar19 = uVar24;
                    if (0 < (int32_t)uVar11) {
                        uVar19 = (uint64_t)uVar11;
                    }
                    func_0x00018011f4f0(piVar7, uVar19);
                }
                *piVar7 = 0;
            }
            if ((*(int64_t *)(iVar17 + 0xc0) != 0) && (*(float *)(iVar17 + 0xb0) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 1, 0x1806444d0);
                func_0x0001801270f0(iVar17 + 200, *(undefined8 *)(iVar17 + 0x110), uVar15);
            }
            ppuVar23 = *(uint32_t ***)(iVar17 + 0xe0);
            ppuVar4 = ppuVar23 + *(int32_t *)(iVar17 + 0xd8);
            for (; ppuVar23 != ppuVar4; ppuVar23 = ppuVar23 + 1) {
                puVar8 = *ppuVar23;
                uVar11 = *puVar8;
                while (0 < (int32_t)uVar11) {
                    if ((*(int32_t *)(*(int64_t *)(puVar8 + 2) + -0x20 + (uint64_t)uVar11 * 0x48) != 0) ||
                       (*(int64_t *)(*(int64_t *)(puVar8 + 2) + -0x18 + (uint64_t)uVar11 * 0x48) != 0)) break;
                    uVar11 = uVar11 - 1;
                    *puVar8 = uVar11;
                }
            }
            puVar10[0x3d] = puVar10[0x3d] + *(int32_t *)(iVar17 + 0xd4);
            puVar10[0x3e] = puVar10[0x3e] + *(int32_t *)(iVar17 + 0xd0);
        }
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 5) {
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fdbcf
// Address: 0x1800fdbcf
// Size: 132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fdba0(int64_t arg1, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    uint64_t *puVar3;
    uint32_t **ppuVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int32_t *piVar7;
    uint32_t *puVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    uint32_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    undefined4 *puVar16;
    int64_t iVar17;
    uint64_t *puVar18;
    uint64_t uVar19;
    int32_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t **ppuVar23;
    uint64_t uVar24;
    int64_t *piVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_10h;
    
    puVar10 = *(undefined4 **)0x180781f28;
    if ((*(undefined4 **)0x180781f28)[2] != (*(undefined4 **)0x180781f28)[1]) {
        fcn.1800fd410(arg_78h);
    }
    if (puVar10[4] != puVar10[1]) {
        uVar24 = 0;
        puVar10[0x3f] = 0;
        puVar10[4] = puVar10[1];
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 4) {
                arg1 = (int64_t)puVar10;
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        puVar14 = *(undefined4 **)0x180781f28;
        for (; *(undefined4 **)0x180781f28 = puVar14, piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            puVar16 = (undefined4 *)(iVar17 + 200);
            *(undefined4 **)(iVar17 + 0x40) = puVar16;
            puVar1 = (undefined4 *)(iVar17 + 0xd8);
            *(undefined4 **)(iVar17 + 0x110) = puVar1;
            *(int64_t *)(iVar17 + 0x118) = iVar17 + 0x120;
            iVar5 = *(int32_t *)(iVar17 + 0xdc);
            if (iVar5 < 0) {
                uVar11 = (iVar5 + 1 >> 1) + iVar5;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            puVar1 = *(undefined4 **)(iVar17 + 0x118);
            uVar11 = puVar1[1];
            arg1 = (int64_t)uVar11;
            if ((int32_t)uVar11 < 0) {
                uVar11 = ((int32_t)(uVar11 + 1) >> 1) + uVar11;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                arg1 = (int64_t)puVar1;
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            *(undefined *)puVar16 = 1;
            *(undefined8 *)(iVar17 + 0xcc) = 0;
            *(undefined4 *)(iVar17 + 0xd4) = 0;
            *(undefined8 *)(iVar17 + 0xe8) = *(undefined8 *)(iVar17 + 8);
            if ((*(uint32_t *)(iVar17 + 4) & 0x1000) == 0) {
                uVar26 = *(undefined4 *)(iVar17 + 0x10);
                uVar27 = *(undefined4 *)(iVar17 + 0x14);
            } else {
                uVar26 = 0;
                uVar27 = 0;
            }
            puVar13 = (undefined8 *)(iVar17 + 0x18);
            *(undefined4 *)(iVar17 + 0xf0) = uVar26;
            *(undefined4 *)(iVar17 + 0xf4) = uVar27;
            if (*(float *)puVar13 == 0.0) {
                puVar13 = (undefined8 *)(puVar14 + 0x10);
            }
            puVar14 = *(undefined4 **)0x180781f28 + 0x35c;
            *(undefined8 *)(iVar17 + 0xf8) = *puVar13;
            *(undefined4 **)(iVar17 + 0x108) = puVar14;
            *(int64_t *)(iVar17 + 0x100) = iVar17;
            if ((*(int64_t *)(iVar17 + 0xb8) != 0) && (*(float *)(iVar17 + 0xac) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 0, 0x1806444c0);
                func_0x0001801270f0(puVar16, *(undefined8 *)(iVar17 + 0x110), uVar15);
                arg1 = (int64_t)puVar16;
            }
            puVar14 = *(undefined4 **)0x180781f28;
        }
        fcn.1800fce90(arg1);
        iVar17 = *(int64_t *)(puVar10 + 0x8f0);
        if ((iVar17 == 0) || ((*(uint32_t *)(iVar17 + 0x14) & 0x2000) != 0)) {
            uVar19 = 0;
            if (iVar17 == 0) {
                uVar22 = 0;
            } else {
                uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
                uVar19 = uVar24;
            }
        } else {
            uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
            uVar19 = *(uint64_t *)(iVar17 + 0x428);
        }
        puVar18 = *(uint64_t **)(puVar10 + 0x562);
        puVar3 = puVar18 + (int32_t)puVar10[0x560];
        for (; puVar18 != puVar3; puVar18 = puVar18 + 1) {
            uVar6 = *puVar18;
            if ((((*(char *)(uVar6 + 0x109) != '\0') && (*(char *)(uVar6 + 0x111) == '\0')) &&
                ((*(uint32_t *)(uVar6 + 0x14) >> 0x18 & 1) == 0)) && ((uVar6 != uVar19 && (uVar6 != uVar22)))) {
                func_0x0001800fc7b0(uVar6, *(uint32_t *)(uVar6 + 0x14) >> 0x19 & 1);
            }
        }
        if (((uVar19 != 0) && (*(char *)(uVar19 + 0x109) != '\0')) && (*(char *)(uVar19 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar19, *(uint32_t *)(uVar19 + 0x14) >> 0x19 & 1);
        }
        if (((uVar22 != 0) && (*(char *)(uVar22 + 0x109) != '\0')) && (*(char *)(uVar22 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar22, *(uint32_t *)(uVar22 + 0x14) >> 0x19 & 1);
        }
        if ((*(char *)(puVar10 + 0x23) != '\0') && (puVar10[0x994] != -1)) {
            func_0x0001800f8020(*(undefined8 *)(puVar10 + 0x46), puVar10[0x3b0]);
        }
        *(undefined8 *)(puVar10 + 0x3d) = 0;
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        for (; piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            piVar7 = *(int32_t **)(iVar17 + 0x110);
            iVar5 = *piVar7;
            iVar12 = piVar7[1];
            iVar20 = **(int32_t **)(iVar17 + 0x118) + iVar5;
            if (iVar12 < iVar20) {
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                iVar9 = iVar20;
                if (iVar20 < iVar12) {
                    iVar9 = iVar12;
                }
                func_0x00018011f4f0(piVar7, iVar9);
            }
            *piVar7 = iVar20;
            piVar7 = *(int32_t **)(iVar17 + 0x118);
            if (*piVar7 != 0) {
                func_0x000180498030(*(int64_t *)(*(int64_t *)(iVar17 + 0x110) + 8) + (int64_t)iVar5 * 8, 
                                    *(undefined8 *)(piVar7 + 2), (int64_t)*piVar7 << 3);
                iVar5 = piVar7[1];
                if (iVar5 < 0) {
                    uVar11 = (iVar5 + 1 >> 1) + iVar5;
                    uVar19 = uVar24;
                    if (0 < (int32_t)uVar11) {
                        uVar19 = (uint64_t)uVar11;
                    }
                    func_0x00018011f4f0(piVar7, uVar19);
                }
                *piVar7 = 0;
            }
            if ((*(int64_t *)(iVar17 + 0xc0) != 0) && (*(float *)(iVar17 + 0xb0) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 1, 0x1806444d0);
                func_0x0001801270f0(iVar17 + 200, *(undefined8 *)(iVar17 + 0x110), uVar15);
            }
            ppuVar23 = *(uint32_t ***)(iVar17 + 0xe0);
            ppuVar4 = ppuVar23 + *(int32_t *)(iVar17 + 0xd8);
            for (; ppuVar23 != ppuVar4; ppuVar23 = ppuVar23 + 1) {
                puVar8 = *ppuVar23;
                uVar11 = *puVar8;
                while (0 < (int32_t)uVar11) {
                    if ((*(int32_t *)(*(int64_t *)(puVar8 + 2) + -0x20 + (uint64_t)uVar11 * 0x48) != 0) ||
                       (*(int64_t *)(*(int64_t *)(puVar8 + 2) + -0x18 + (uint64_t)uVar11 * 0x48) != 0)) break;
                    uVar11 = uVar11 - 1;
                    *puVar8 = uVar11;
                }
            }
            puVar10[0x3d] = puVar10[0x3d] + *(int32_t *)(iVar17 + 0xd4);
            puVar10[0x3e] = puVar10[0x3e] + *(int32_t *)(iVar17 + 0xd0);
        }
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 5) {
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fdc53
// Address: 0x1800fdc53
// Size: 330 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fdba0(int64_t arg1, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    uint64_t *puVar3;
    uint32_t **ppuVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int32_t *piVar7;
    uint32_t *puVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    uint32_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    undefined4 *puVar16;
    int64_t iVar17;
    uint64_t *puVar18;
    uint64_t uVar19;
    int32_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t **ppuVar23;
    uint64_t uVar24;
    int64_t *piVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_10h;
    
    puVar10 = *(undefined4 **)0x180781f28;
    if ((*(undefined4 **)0x180781f28)[2] != (*(undefined4 **)0x180781f28)[1]) {
        fcn.1800fd410(arg_78h);
    }
    if (puVar10[4] != puVar10[1]) {
        uVar24 = 0;
        puVar10[0x3f] = 0;
        puVar10[4] = puVar10[1];
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 4) {
                arg1 = (int64_t)puVar10;
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        puVar14 = *(undefined4 **)0x180781f28;
        for (; *(undefined4 **)0x180781f28 = puVar14, piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            puVar16 = (undefined4 *)(iVar17 + 200);
            *(undefined4 **)(iVar17 + 0x40) = puVar16;
            puVar1 = (undefined4 *)(iVar17 + 0xd8);
            *(undefined4 **)(iVar17 + 0x110) = puVar1;
            *(int64_t *)(iVar17 + 0x118) = iVar17 + 0x120;
            iVar5 = *(int32_t *)(iVar17 + 0xdc);
            if (iVar5 < 0) {
                uVar11 = (iVar5 + 1 >> 1) + iVar5;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            puVar1 = *(undefined4 **)(iVar17 + 0x118);
            uVar11 = puVar1[1];
            arg1 = (int64_t)uVar11;
            if ((int32_t)uVar11 < 0) {
                uVar11 = ((int32_t)(uVar11 + 1) >> 1) + uVar11;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                arg1 = (int64_t)puVar1;
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            *(undefined *)puVar16 = 1;
            *(undefined8 *)(iVar17 + 0xcc) = 0;
            *(undefined4 *)(iVar17 + 0xd4) = 0;
            *(undefined8 *)(iVar17 + 0xe8) = *(undefined8 *)(iVar17 + 8);
            if ((*(uint32_t *)(iVar17 + 4) & 0x1000) == 0) {
                uVar26 = *(undefined4 *)(iVar17 + 0x10);
                uVar27 = *(undefined4 *)(iVar17 + 0x14);
            } else {
                uVar26 = 0;
                uVar27 = 0;
            }
            puVar13 = (undefined8 *)(iVar17 + 0x18);
            *(undefined4 *)(iVar17 + 0xf0) = uVar26;
            *(undefined4 *)(iVar17 + 0xf4) = uVar27;
            if (*(float *)puVar13 == 0.0) {
                puVar13 = (undefined8 *)(puVar14 + 0x10);
            }
            puVar14 = *(undefined4 **)0x180781f28 + 0x35c;
            *(undefined8 *)(iVar17 + 0xf8) = *puVar13;
            *(undefined4 **)(iVar17 + 0x108) = puVar14;
            *(int64_t *)(iVar17 + 0x100) = iVar17;
            if ((*(int64_t *)(iVar17 + 0xb8) != 0) && (*(float *)(iVar17 + 0xac) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 0, 0x1806444c0);
                func_0x0001801270f0(puVar16, *(undefined8 *)(iVar17 + 0x110), uVar15);
                arg1 = (int64_t)puVar16;
            }
            puVar14 = *(undefined4 **)0x180781f28;
        }
        fcn.1800fce90(arg1);
        iVar17 = *(int64_t *)(puVar10 + 0x8f0);
        if ((iVar17 == 0) || ((*(uint32_t *)(iVar17 + 0x14) & 0x2000) != 0)) {
            uVar19 = 0;
            if (iVar17 == 0) {
                uVar22 = 0;
            } else {
                uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
                uVar19 = uVar24;
            }
        } else {
            uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
            uVar19 = *(uint64_t *)(iVar17 + 0x428);
        }
        puVar18 = *(uint64_t **)(puVar10 + 0x562);
        puVar3 = puVar18 + (int32_t)puVar10[0x560];
        for (; puVar18 != puVar3; puVar18 = puVar18 + 1) {
            uVar6 = *puVar18;
            if ((((*(char *)(uVar6 + 0x109) != '\0') && (*(char *)(uVar6 + 0x111) == '\0')) &&
                ((*(uint32_t *)(uVar6 + 0x14) >> 0x18 & 1) == 0)) && ((uVar6 != uVar19 && (uVar6 != uVar22)))) {
                func_0x0001800fc7b0(uVar6, *(uint32_t *)(uVar6 + 0x14) >> 0x19 & 1);
            }
        }
        if (((uVar19 != 0) && (*(char *)(uVar19 + 0x109) != '\0')) && (*(char *)(uVar19 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar19, *(uint32_t *)(uVar19 + 0x14) >> 0x19 & 1);
        }
        if (((uVar22 != 0) && (*(char *)(uVar22 + 0x109) != '\0')) && (*(char *)(uVar22 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar22, *(uint32_t *)(uVar22 + 0x14) >> 0x19 & 1);
        }
        if ((*(char *)(puVar10 + 0x23) != '\0') && (puVar10[0x994] != -1)) {
            func_0x0001800f8020(*(undefined8 *)(puVar10 + 0x46), puVar10[0x3b0]);
        }
        *(undefined8 *)(puVar10 + 0x3d) = 0;
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        for (; piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            piVar7 = *(int32_t **)(iVar17 + 0x110);
            iVar5 = *piVar7;
            iVar12 = piVar7[1];
            iVar20 = **(int32_t **)(iVar17 + 0x118) + iVar5;
            if (iVar12 < iVar20) {
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                iVar9 = iVar20;
                if (iVar20 < iVar12) {
                    iVar9 = iVar12;
                }
                func_0x00018011f4f0(piVar7, iVar9);
            }
            *piVar7 = iVar20;
            piVar7 = *(int32_t **)(iVar17 + 0x118);
            if (*piVar7 != 0) {
                func_0x000180498030(*(int64_t *)(*(int64_t *)(iVar17 + 0x110) + 8) + (int64_t)iVar5 * 8, 
                                    *(undefined8 *)(piVar7 + 2), (int64_t)*piVar7 << 3);
                iVar5 = piVar7[1];
                if (iVar5 < 0) {
                    uVar11 = (iVar5 + 1 >> 1) + iVar5;
                    uVar19 = uVar24;
                    if (0 < (int32_t)uVar11) {
                        uVar19 = (uint64_t)uVar11;
                    }
                    func_0x00018011f4f0(piVar7, uVar19);
                }
                *piVar7 = 0;
            }
            if ((*(int64_t *)(iVar17 + 0xc0) != 0) && (*(float *)(iVar17 + 0xb0) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 1, 0x1806444d0);
                func_0x0001801270f0(iVar17 + 200, *(undefined8 *)(iVar17 + 0x110), uVar15);
            }
            ppuVar23 = *(uint32_t ***)(iVar17 + 0xe0);
            ppuVar4 = ppuVar23 + *(int32_t *)(iVar17 + 0xd8);
            for (; ppuVar23 != ppuVar4; ppuVar23 = ppuVar23 + 1) {
                puVar8 = *ppuVar23;
                uVar11 = *puVar8;
                while (0 < (int32_t)uVar11) {
                    if ((*(int32_t *)(*(int64_t *)(puVar8 + 2) + -0x20 + (uint64_t)uVar11 * 0x48) != 0) ||
                       (*(int64_t *)(*(int64_t *)(puVar8 + 2) + -0x18 + (uint64_t)uVar11 * 0x48) != 0)) break;
                    uVar11 = uVar11 - 1;
                    *puVar8 = uVar11;
                }
            }
            puVar10[0x3d] = puVar10[0x3d] + *(int32_t *)(iVar17 + 0xd4);
            puVar10[0x3e] = puVar10[0x3e] + *(int32_t *)(iVar17 + 0xd0);
        }
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 5) {
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fdd9d
// Address: 0x1800fdd9d
// Size: 723 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fdba0(int64_t arg1, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    uint64_t *puVar3;
    uint32_t **ppuVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int32_t *piVar7;
    uint32_t *puVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    uint32_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    undefined4 *puVar16;
    int64_t iVar17;
    uint64_t *puVar18;
    uint64_t uVar19;
    int32_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t **ppuVar23;
    uint64_t uVar24;
    int64_t *piVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_10h;
    
    puVar10 = *(undefined4 **)0x180781f28;
    if ((*(undefined4 **)0x180781f28)[2] != (*(undefined4 **)0x180781f28)[1]) {
        fcn.1800fd410(arg_78h);
    }
    if (puVar10[4] != puVar10[1]) {
        uVar24 = 0;
        puVar10[0x3f] = 0;
        puVar10[4] = puVar10[1];
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 4) {
                arg1 = (int64_t)puVar10;
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        puVar14 = *(undefined4 **)0x180781f28;
        for (; *(undefined4 **)0x180781f28 = puVar14, piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            puVar16 = (undefined4 *)(iVar17 + 200);
            *(undefined4 **)(iVar17 + 0x40) = puVar16;
            puVar1 = (undefined4 *)(iVar17 + 0xd8);
            *(undefined4 **)(iVar17 + 0x110) = puVar1;
            *(int64_t *)(iVar17 + 0x118) = iVar17 + 0x120;
            iVar5 = *(int32_t *)(iVar17 + 0xdc);
            if (iVar5 < 0) {
                uVar11 = (iVar5 + 1 >> 1) + iVar5;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            puVar1 = *(undefined4 **)(iVar17 + 0x118);
            uVar11 = puVar1[1];
            arg1 = (int64_t)uVar11;
            if ((int32_t)uVar11 < 0) {
                uVar11 = ((int32_t)(uVar11 + 1) >> 1) + uVar11;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                arg1 = (int64_t)puVar1;
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            *(undefined *)puVar16 = 1;
            *(undefined8 *)(iVar17 + 0xcc) = 0;
            *(undefined4 *)(iVar17 + 0xd4) = 0;
            *(undefined8 *)(iVar17 + 0xe8) = *(undefined8 *)(iVar17 + 8);
            if ((*(uint32_t *)(iVar17 + 4) & 0x1000) == 0) {
                uVar26 = *(undefined4 *)(iVar17 + 0x10);
                uVar27 = *(undefined4 *)(iVar17 + 0x14);
            } else {
                uVar26 = 0;
                uVar27 = 0;
            }
            puVar13 = (undefined8 *)(iVar17 + 0x18);
            *(undefined4 *)(iVar17 + 0xf0) = uVar26;
            *(undefined4 *)(iVar17 + 0xf4) = uVar27;
            if (*(float *)puVar13 == 0.0) {
                puVar13 = (undefined8 *)(puVar14 + 0x10);
            }
            puVar14 = *(undefined4 **)0x180781f28 + 0x35c;
            *(undefined8 *)(iVar17 + 0xf8) = *puVar13;
            *(undefined4 **)(iVar17 + 0x108) = puVar14;
            *(int64_t *)(iVar17 + 0x100) = iVar17;
            if ((*(int64_t *)(iVar17 + 0xb8) != 0) && (*(float *)(iVar17 + 0xac) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 0, 0x1806444c0);
                func_0x0001801270f0(puVar16, *(undefined8 *)(iVar17 + 0x110), uVar15);
                arg1 = (int64_t)puVar16;
            }
            puVar14 = *(undefined4 **)0x180781f28;
        }
        fcn.1800fce90(arg1);
        iVar17 = *(int64_t *)(puVar10 + 0x8f0);
        if ((iVar17 == 0) || ((*(uint32_t *)(iVar17 + 0x14) & 0x2000) != 0)) {
            uVar19 = 0;
            if (iVar17 == 0) {
                uVar22 = 0;
            } else {
                uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
                uVar19 = uVar24;
            }
        } else {
            uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
            uVar19 = *(uint64_t *)(iVar17 + 0x428);
        }
        puVar18 = *(uint64_t **)(puVar10 + 0x562);
        puVar3 = puVar18 + (int32_t)puVar10[0x560];
        for (; puVar18 != puVar3; puVar18 = puVar18 + 1) {
            uVar6 = *puVar18;
            if ((((*(char *)(uVar6 + 0x109) != '\0') && (*(char *)(uVar6 + 0x111) == '\0')) &&
                ((*(uint32_t *)(uVar6 + 0x14) >> 0x18 & 1) == 0)) && ((uVar6 != uVar19 && (uVar6 != uVar22)))) {
                func_0x0001800fc7b0(uVar6, *(uint32_t *)(uVar6 + 0x14) >> 0x19 & 1);
            }
        }
        if (((uVar19 != 0) && (*(char *)(uVar19 + 0x109) != '\0')) && (*(char *)(uVar19 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar19, *(uint32_t *)(uVar19 + 0x14) >> 0x19 & 1);
        }
        if (((uVar22 != 0) && (*(char *)(uVar22 + 0x109) != '\0')) && (*(char *)(uVar22 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar22, *(uint32_t *)(uVar22 + 0x14) >> 0x19 & 1);
        }
        if ((*(char *)(puVar10 + 0x23) != '\0') && (puVar10[0x994] != -1)) {
            func_0x0001800f8020(*(undefined8 *)(puVar10 + 0x46), puVar10[0x3b0]);
        }
        *(undefined8 *)(puVar10 + 0x3d) = 0;
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        for (; piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            piVar7 = *(int32_t **)(iVar17 + 0x110);
            iVar5 = *piVar7;
            iVar12 = piVar7[1];
            iVar20 = **(int32_t **)(iVar17 + 0x118) + iVar5;
            if (iVar12 < iVar20) {
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                iVar9 = iVar20;
                if (iVar20 < iVar12) {
                    iVar9 = iVar12;
                }
                func_0x00018011f4f0(piVar7, iVar9);
            }
            *piVar7 = iVar20;
            piVar7 = *(int32_t **)(iVar17 + 0x118);
            if (*piVar7 != 0) {
                func_0x000180498030(*(int64_t *)(*(int64_t *)(iVar17 + 0x110) + 8) + (int64_t)iVar5 * 8, 
                                    *(undefined8 *)(piVar7 + 2), (int64_t)*piVar7 << 3);
                iVar5 = piVar7[1];
                if (iVar5 < 0) {
                    uVar11 = (iVar5 + 1 >> 1) + iVar5;
                    uVar19 = uVar24;
                    if (0 < (int32_t)uVar11) {
                        uVar19 = (uint64_t)uVar11;
                    }
                    func_0x00018011f4f0(piVar7, uVar19);
                }
                *piVar7 = 0;
            }
            if ((*(int64_t *)(iVar17 + 0xc0) != 0) && (*(float *)(iVar17 + 0xb0) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 1, 0x1806444d0);
                func_0x0001801270f0(iVar17 + 200, *(undefined8 *)(iVar17 + 0x110), uVar15);
            }
            ppuVar23 = *(uint32_t ***)(iVar17 + 0xe0);
            ppuVar4 = ppuVar23 + *(int32_t *)(iVar17 + 0xd8);
            for (; ppuVar23 != ppuVar4; ppuVar23 = ppuVar23 + 1) {
                puVar8 = *ppuVar23;
                uVar11 = *puVar8;
                while (0 < (int32_t)uVar11) {
                    if ((*(int32_t *)(*(int64_t *)(puVar8 + 2) + -0x20 + (uint64_t)uVar11 * 0x48) != 0) ||
                       (*(int64_t *)(*(int64_t *)(puVar8 + 2) + -0x18 + (uint64_t)uVar11 * 0x48) != 0)) break;
                    uVar11 = uVar11 - 1;
                    *puVar8 = uVar11;
                }
            }
            puVar10[0x3d] = puVar10[0x3d] + *(int32_t *)(iVar17 + 0xd4);
            puVar10[0x3e] = puVar10[0x3e] + *(int32_t *)(iVar17 + 0xd0);
        }
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 5) {
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fe070
// Address: 0x1800fe070
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fdba0(int64_t arg1, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    uint64_t *puVar3;
    uint32_t **ppuVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int32_t *piVar7;
    uint32_t *puVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    uint32_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    undefined4 *puVar16;
    int64_t iVar17;
    uint64_t *puVar18;
    uint64_t uVar19;
    int32_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t **ppuVar23;
    uint64_t uVar24;
    int64_t *piVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_10h;
    
    puVar10 = *(undefined4 **)0x180781f28;
    if ((*(undefined4 **)0x180781f28)[2] != (*(undefined4 **)0x180781f28)[1]) {
        fcn.1800fd410(arg_78h);
    }
    if (puVar10[4] != puVar10[1]) {
        uVar24 = 0;
        puVar10[0x3f] = 0;
        puVar10[4] = puVar10[1];
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 4) {
                arg1 = (int64_t)puVar10;
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        puVar14 = *(undefined4 **)0x180781f28;
        for (; *(undefined4 **)0x180781f28 = puVar14, piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            puVar16 = (undefined4 *)(iVar17 + 200);
            *(undefined4 **)(iVar17 + 0x40) = puVar16;
            puVar1 = (undefined4 *)(iVar17 + 0xd8);
            *(undefined4 **)(iVar17 + 0x110) = puVar1;
            *(int64_t *)(iVar17 + 0x118) = iVar17 + 0x120;
            iVar5 = *(int32_t *)(iVar17 + 0xdc);
            if (iVar5 < 0) {
                uVar11 = (iVar5 + 1 >> 1) + iVar5;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            puVar1 = *(undefined4 **)(iVar17 + 0x118);
            uVar11 = puVar1[1];
            arg1 = (int64_t)uVar11;
            if ((int32_t)uVar11 < 0) {
                uVar11 = ((int32_t)(uVar11 + 1) >> 1) + uVar11;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                arg1 = (int64_t)puVar1;
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            *(undefined *)puVar16 = 1;
            *(undefined8 *)(iVar17 + 0xcc) = 0;
            *(undefined4 *)(iVar17 + 0xd4) = 0;
            *(undefined8 *)(iVar17 + 0xe8) = *(undefined8 *)(iVar17 + 8);
            if ((*(uint32_t *)(iVar17 + 4) & 0x1000) == 0) {
                uVar26 = *(undefined4 *)(iVar17 + 0x10);
                uVar27 = *(undefined4 *)(iVar17 + 0x14);
            } else {
                uVar26 = 0;
                uVar27 = 0;
            }
            puVar13 = (undefined8 *)(iVar17 + 0x18);
            *(undefined4 *)(iVar17 + 0xf0) = uVar26;
            *(undefined4 *)(iVar17 + 0xf4) = uVar27;
            if (*(float *)puVar13 == 0.0) {
                puVar13 = (undefined8 *)(puVar14 + 0x10);
            }
            puVar14 = *(undefined4 **)0x180781f28 + 0x35c;
            *(undefined8 *)(iVar17 + 0xf8) = *puVar13;
            *(undefined4 **)(iVar17 + 0x108) = puVar14;
            *(int64_t *)(iVar17 + 0x100) = iVar17;
            if ((*(int64_t *)(iVar17 + 0xb8) != 0) && (*(float *)(iVar17 + 0xac) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 0, 0x1806444c0);
                func_0x0001801270f0(puVar16, *(undefined8 *)(iVar17 + 0x110), uVar15);
                arg1 = (int64_t)puVar16;
            }
            puVar14 = *(undefined4 **)0x180781f28;
        }
        fcn.1800fce90(arg1);
        iVar17 = *(int64_t *)(puVar10 + 0x8f0);
        if ((iVar17 == 0) || ((*(uint32_t *)(iVar17 + 0x14) & 0x2000) != 0)) {
            uVar19 = 0;
            if (iVar17 == 0) {
                uVar22 = 0;
            } else {
                uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
                uVar19 = uVar24;
            }
        } else {
            uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
            uVar19 = *(uint64_t *)(iVar17 + 0x428);
        }
        puVar18 = *(uint64_t **)(puVar10 + 0x562);
        puVar3 = puVar18 + (int32_t)puVar10[0x560];
        for (; puVar18 != puVar3; puVar18 = puVar18 + 1) {
            uVar6 = *puVar18;
            if ((((*(char *)(uVar6 + 0x109) != '\0') && (*(char *)(uVar6 + 0x111) == '\0')) &&
                ((*(uint32_t *)(uVar6 + 0x14) >> 0x18 & 1) == 0)) && ((uVar6 != uVar19 && (uVar6 != uVar22)))) {
                func_0x0001800fc7b0(uVar6, *(uint32_t *)(uVar6 + 0x14) >> 0x19 & 1);
            }
        }
        if (((uVar19 != 0) && (*(char *)(uVar19 + 0x109) != '\0')) && (*(char *)(uVar19 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar19, *(uint32_t *)(uVar19 + 0x14) >> 0x19 & 1);
        }
        if (((uVar22 != 0) && (*(char *)(uVar22 + 0x109) != '\0')) && (*(char *)(uVar22 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar22, *(uint32_t *)(uVar22 + 0x14) >> 0x19 & 1);
        }
        if ((*(char *)(puVar10 + 0x23) != '\0') && (puVar10[0x994] != -1)) {
            func_0x0001800f8020(*(undefined8 *)(puVar10 + 0x46), puVar10[0x3b0]);
        }
        *(undefined8 *)(puVar10 + 0x3d) = 0;
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        for (; piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            piVar7 = *(int32_t **)(iVar17 + 0x110);
            iVar5 = *piVar7;
            iVar12 = piVar7[1];
            iVar20 = **(int32_t **)(iVar17 + 0x118) + iVar5;
            if (iVar12 < iVar20) {
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                iVar9 = iVar20;
                if (iVar20 < iVar12) {
                    iVar9 = iVar12;
                }
                func_0x00018011f4f0(piVar7, iVar9);
            }
            *piVar7 = iVar20;
            piVar7 = *(int32_t **)(iVar17 + 0x118);
            if (*piVar7 != 0) {
                func_0x000180498030(*(int64_t *)(*(int64_t *)(iVar17 + 0x110) + 8) + (int64_t)iVar5 * 8, 
                                    *(undefined8 *)(piVar7 + 2), (int64_t)*piVar7 << 3);
                iVar5 = piVar7[1];
                if (iVar5 < 0) {
                    uVar11 = (iVar5 + 1 >> 1) + iVar5;
                    uVar19 = uVar24;
                    if (0 < (int32_t)uVar11) {
                        uVar19 = (uint64_t)uVar11;
                    }
                    func_0x00018011f4f0(piVar7, uVar19);
                }
                *piVar7 = 0;
            }
            if ((*(int64_t *)(iVar17 + 0xc0) != 0) && (*(float *)(iVar17 + 0xb0) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 1, 0x1806444d0);
                func_0x0001801270f0(iVar17 + 200, *(undefined8 *)(iVar17 + 0x110), uVar15);
            }
            ppuVar23 = *(uint32_t ***)(iVar17 + 0xe0);
            ppuVar4 = ppuVar23 + *(int32_t *)(iVar17 + 0xd8);
            for (; ppuVar23 != ppuVar4; ppuVar23 = ppuVar23 + 1) {
                puVar8 = *ppuVar23;
                uVar11 = *puVar8;
                while (0 < (int32_t)uVar11) {
                    if ((*(int32_t *)(*(int64_t *)(puVar8 + 2) + -0x20 + (uint64_t)uVar11 * 0x48) != 0) ||
                       (*(int64_t *)(*(int64_t *)(puVar8 + 2) + -0x18 + (uint64_t)uVar11 * 0x48) != 0)) break;
                    uVar11 = uVar11 - 1;
                    *puVar8 = uVar11;
                }
            }
            puVar10[0x3d] = puVar10[0x3d] + *(int32_t *)(iVar17 + 0xd4);
            puVar10[0x3e] = puVar10[0x3e] + *(int32_t *)(iVar17 + 0xd0);
        }
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 5) {
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fe092
// Address: 0x1800fe092
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_d80h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2158h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2110h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2108h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d38h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3d0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h

void fcn.1800fdba0(int64_t arg1, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h,
                  int64_t arg_80h, int64_t arg_a8h, int64_t arg_b0h)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    uint64_t *puVar3;
    uint32_t **ppuVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int32_t *piVar7;
    uint32_t *puVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    uint32_t uVar11;
    int32_t iVar12;
    undefined8 *puVar13;
    undefined4 *puVar14;
    undefined8 uVar15;
    undefined4 *puVar16;
    int64_t iVar17;
    uint64_t *puVar18;
    uint64_t uVar19;
    int32_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t **ppuVar23;
    uint64_t uVar24;
    int64_t *piVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_10h;
    
    puVar10 = *(undefined4 **)0x180781f28;
    if ((*(undefined4 **)0x180781f28)[2] != (*(undefined4 **)0x180781f28)[1]) {
        fcn.1800fd410(arg_78h);
    }
    if (puVar10[4] != puVar10[1]) {
        uVar24 = 0;
        puVar10[0x3f] = 0;
        puVar10[4] = puVar10[1];
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 4) {
                arg1 = (int64_t)puVar10;
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        puVar14 = *(undefined4 **)0x180781f28;
        for (; *(undefined4 **)0x180781f28 = puVar14, piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            puVar16 = (undefined4 *)(iVar17 + 200);
            *(undefined4 **)(iVar17 + 0x40) = puVar16;
            puVar1 = (undefined4 *)(iVar17 + 0xd8);
            *(undefined4 **)(iVar17 + 0x110) = puVar1;
            *(int64_t *)(iVar17 + 0x118) = iVar17 + 0x120;
            iVar5 = *(int32_t *)(iVar17 + 0xdc);
            if (iVar5 < 0) {
                uVar11 = (iVar5 + 1 >> 1) + iVar5;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            puVar1 = *(undefined4 **)(iVar17 + 0x118);
            uVar11 = puVar1[1];
            arg1 = (int64_t)uVar11;
            if ((int32_t)uVar11 < 0) {
                uVar11 = ((int32_t)(uVar11 + 1) >> 1) + uVar11;
                uVar19 = uVar24;
                if (0 < (int32_t)uVar11) {
                    uVar19 = (uint64_t)uVar11;
                }
                arg1 = (int64_t)puVar1;
                func_0x00018011f4f0(puVar1, uVar19);
            }
            *puVar1 = 0;
            *(undefined *)puVar16 = 1;
            *(undefined8 *)(iVar17 + 0xcc) = 0;
            *(undefined4 *)(iVar17 + 0xd4) = 0;
            *(undefined8 *)(iVar17 + 0xe8) = *(undefined8 *)(iVar17 + 8);
            if ((*(uint32_t *)(iVar17 + 4) & 0x1000) == 0) {
                uVar26 = *(undefined4 *)(iVar17 + 0x10);
                uVar27 = *(undefined4 *)(iVar17 + 0x14);
            } else {
                uVar26 = 0;
                uVar27 = 0;
            }
            puVar13 = (undefined8 *)(iVar17 + 0x18);
            *(undefined4 *)(iVar17 + 0xf0) = uVar26;
            *(undefined4 *)(iVar17 + 0xf4) = uVar27;
            if (*(float *)puVar13 == 0.0) {
                puVar13 = (undefined8 *)(puVar14 + 0x10);
            }
            puVar14 = *(undefined4 **)0x180781f28 + 0x35c;
            *(undefined8 *)(iVar17 + 0xf8) = *puVar13;
            *(undefined4 **)(iVar17 + 0x108) = puVar14;
            *(int64_t *)(iVar17 + 0x100) = iVar17;
            if ((*(int64_t *)(iVar17 + 0xb8) != 0) && (*(float *)(iVar17 + 0xac) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 0, 0x1806444c0);
                func_0x0001801270f0(puVar16, *(undefined8 *)(iVar17 + 0x110), uVar15);
                arg1 = (int64_t)puVar16;
            }
            puVar14 = *(undefined4 **)0x180781f28;
        }
        fcn.1800fce90(arg1);
        iVar17 = *(int64_t *)(puVar10 + 0x8f0);
        if ((iVar17 == 0) || ((*(uint32_t *)(iVar17 + 0x14) & 0x2000) != 0)) {
            uVar19 = 0;
            if (iVar17 == 0) {
                uVar22 = 0;
            } else {
                uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
                uVar19 = uVar24;
            }
        } else {
            uVar22 = *(uint64_t *)(puVar10 + 0x8f4);
            uVar19 = *(uint64_t *)(iVar17 + 0x428);
        }
        puVar18 = *(uint64_t **)(puVar10 + 0x562);
        puVar3 = puVar18 + (int32_t)puVar10[0x560];
        for (; puVar18 != puVar3; puVar18 = puVar18 + 1) {
            uVar6 = *puVar18;
            if ((((*(char *)(uVar6 + 0x109) != '\0') && (*(char *)(uVar6 + 0x111) == '\0')) &&
                ((*(uint32_t *)(uVar6 + 0x14) >> 0x18 & 1) == 0)) && ((uVar6 != uVar19 && (uVar6 != uVar22)))) {
                func_0x0001800fc7b0(uVar6, *(uint32_t *)(uVar6 + 0x14) >> 0x19 & 1);
            }
        }
        if (((uVar19 != 0) && (*(char *)(uVar19 + 0x109) != '\0')) && (*(char *)(uVar19 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar19, *(uint32_t *)(uVar19 + 0x14) >> 0x19 & 1);
        }
        if (((uVar22 != 0) && (*(char *)(uVar22 + 0x109) != '\0')) && (*(char *)(uVar22 + 0x111) == '\0')) {
            func_0x0001800fc7b0(uVar22, *(uint32_t *)(uVar22 + 0x14) >> 0x19 & 1);
        }
        if ((*(char *)(puVar10 + 0x23) != '\0') && (puVar10[0x994] != -1)) {
            func_0x0001800f8020(*(undefined8 *)(puVar10 + 0x46), puVar10[0x3b0]);
        }
        *(undefined8 *)(puVar10 + 0x3d) = 0;
        piVar25 = *(int64_t **)(puVar10 + 0x856);
        piVar2 = piVar25 + (int32_t)puVar10[0x854];
        for (; piVar25 != piVar2; piVar25 = piVar25 + 1) {
            iVar17 = *piVar25;
            piVar7 = *(int32_t **)(iVar17 + 0x110);
            iVar5 = *piVar7;
            iVar12 = piVar7[1];
            iVar20 = **(int32_t **)(iVar17 + 0x118) + iVar5;
            if (iVar12 < iVar20) {
                if (iVar12 == 0) {
                    iVar12 = 8;
                } else {
                    iVar12 = iVar12 / 2 + iVar12;
                }
                iVar9 = iVar20;
                if (iVar20 < iVar12) {
                    iVar9 = iVar12;
                }
                func_0x00018011f4f0(piVar7, iVar9);
            }
            *piVar7 = iVar20;
            piVar7 = *(int32_t **)(iVar17 + 0x118);
            if (*piVar7 != 0) {
                func_0x000180498030(*(int64_t *)(*(int64_t *)(iVar17 + 0x110) + 8) + (int64_t)iVar5 * 8, 
                                    *(undefined8 *)(piVar7 + 2), (int64_t)*piVar7 << 3);
                iVar5 = piVar7[1];
                if (iVar5 < 0) {
                    uVar11 = (iVar5 + 1 >> 1) + iVar5;
                    uVar19 = uVar24;
                    if (0 < (int32_t)uVar11) {
                        uVar19 = (uint64_t)uVar11;
                    }
                    func_0x00018011f4f0(piVar7, uVar19);
                }
                *piVar7 = 0;
            }
            if ((*(int64_t *)(iVar17 + 0xc0) != 0) && (*(float *)(iVar17 + 0xb0) == (float)*(double *)(puVar10 + 6))) {
                uVar15 = func_0x0001800fa7f0(iVar17, 1, 0x1806444d0);
                func_0x0001801270f0(iVar17 + 200, *(undefined8 *)(iVar17 + 0x110), uVar15);
            }
            ppuVar23 = *(uint32_t ***)(iVar17 + 0xe0);
            ppuVar4 = ppuVar23 + *(int32_t *)(iVar17 + 0xd8);
            for (; ppuVar23 != ppuVar4; ppuVar23 = ppuVar23 + 1) {
                puVar8 = *ppuVar23;
                uVar11 = *puVar8;
                while (0 < (int32_t)uVar11) {
                    if ((*(int32_t *)(*(int64_t *)(puVar8 + 2) + -0x20 + (uint64_t)uVar11 * 0x48) != 0) ||
                       (*(int64_t *)(*(int64_t *)(puVar8 + 2) + -0x18 + (uint64_t)uVar11 * 0x48) != 0)) break;
                    uVar11 = uVar11 - 1;
                    *puVar8 = uVar11;
                }
            }
            puVar10[0x3d] = puVar10[0x3d] + *(int32_t *)(iVar17 + 0xd4);
            puVar10[0x3e] = puVar10[0x3e] + *(int32_t *)(iVar17 + 0xd0);
        }
        iVar17 = *(int64_t *)(puVar10 + 0xa5e);
        iVar21 = (int64_t)(int32_t)puVar10[0xa5c] * 0x20 + iVar17;
        for (; iVar17 != iVar21; iVar17 = iVar17 + 0x20) {
            if (*(int32_t *)(iVar17 + 4) == 5) {
                (**(code **)(iVar17 + 0x10))(puVar10, iVar17);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fe0a0
// Address: 0x1800fe0a0
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800fe0a0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                     int64_t arg_110h)
{
    float fVar1;
    float fVar2;
    char cVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint32_t *puVar7;
    char *pcVar8;
    char *pcVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStackX_20;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    pcVar10 = (char *)arg3;
    if ((char)placeholder_3 != '\0') {
        pcVar8 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar8 = (char *)arg3;
        }
        pcVar10 = (char *)arg2;
        if ((uint64_t)arg2 < pcVar8) {
            while (*pcVar10 != '\0') {
                pcVar9 = pcVar10 + 1;
                if (((*pcVar10 == '#') && (*pcVar9 == '#')) || (pcVar10 = pcVar9, pcVar8 <= pcVar9)) break;
            }
        }
    }
    fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if ((char *)arg2 == pcVar10) {
        *(float *)(arg1 + 4) = fVar1;
        *(undefined4 *)arg1 = 0;
        return arg1;
    }
    uVar4 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    if (pcVar10 == (char *)0x0) {
        iVar6 = func_0x000180498cd0(arg2);
        pcVar10 = (char *)(iVar6 + arg2);
    }
    puVar7 = (uint32_t *)func_0x00018012ec80(uVar4, fVar1, 0xbf800000);
    fVar13 = 0.0;
    fVar2 = (float)puVar7[5];
    uStackX_20 = CONCAT31(uStackX_20._1_3_, 0.0 < (float)arg_28h);
    fVar14 = 0.0;
    pcVar9 = (char *)0x0;
    fVar11 = 0.0;
    pcVar8 = pcVar9;
    if ((uint64_t)arg2 < pcVar10) {
        do {
            if (0.0 < (float)arg_28h) {
                if (pcVar8 == (char *)0x0) {
                    pcVar8 = (char *)func_0x00018012f4a0(uVar4, fVar1, arg2, pcVar10, (float)arg_28h - fVar11, 0);
                }
                if ((uint64_t)arg2 < pcVar8) goto code_r0x0001800fe27a;
                if (fVar13 < fVar11) {
                    fVar13 = fVar11;
                }
                fVar14 = fVar14 + fVar1;
                fVar12 = 0.0;
                for (; pcVar8 = pcVar9, (uint64_t)arg2 < pcVar10; arg2 = arg2 + 1) {
                    cVar3 = *(char *)arg2;
                    if ((cVar3 != ' ') && (cVar3 != '\t')) {
                        if (cVar3 == '\n') {
                            arg2 = arg2 + 1;
                        }
                        break;
                    }
                }
            } else {
code_r0x0001800fe27a:
                uStackX_20 = (uint32_t)*(char *)arg2;
                if (uStackX_20 < 0x80) {
                    arg2 = arg2 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&uStackX_20, arg2, pcVar10);
                    arg2 = arg2 + iVar5;
                }
                if (uStackX_20 == 10) {
                    if (fVar13 <= fVar11) {
                        fVar13 = fVar11;
                    }
                    fVar14 = fVar14 + fVar1;
                    fVar12 = 0.0;
                } else {
                    fVar12 = fVar11;
                    if (uStackX_20 != 0xd) {
                        if ((*puVar7 <= uStackX_20) ||
                           (fVar12 = *(float *)(*(int64_t *)(puVar7 + 2) + (uint64_t)uStackX_20 * 4), fVar12 < 0.0)) {
                            fVar12 = (float)func_0x00018012bbd0(puVar7);
                        }
                        fVar12 = fVar12 * (fVar1 / fVar2) + fVar11;
                        if (3.402823e+38 <= fVar12) break;
                    }
                }
            }
            fVar11 = fVar12;
        } while ((uint64_t)arg2 < pcVar10);
        if (fVar13 < fVar11) {
            fVar13 = fVar11;
        }
        if ((fVar11 <= 0.0) && (fVar14 != 0.0)) goto code_r0x0001800fe32c;
    }
    fVar14 = fVar14 + fVar1;
code_r0x0001800fe32c:
    *(float *)(arg1 + 4) = fVar14;
    *(float *)arg1 = (float)(int32_t)(fVar13 + 0.99999);
    return arg1;
}

// ============================================================
// Function: FUN_1800fe127
// Address: 0x1800fe127
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800fe0a0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                     int64_t arg_110h)
{
    float fVar1;
    float fVar2;
    char cVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint32_t *puVar7;
    char *pcVar8;
    char *pcVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStackX_20;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    pcVar10 = (char *)arg3;
    if ((char)placeholder_3 != '\0') {
        pcVar8 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar8 = (char *)arg3;
        }
        pcVar10 = (char *)arg2;
        if ((uint64_t)arg2 < pcVar8) {
            while (*pcVar10 != '\0') {
                pcVar9 = pcVar10 + 1;
                if (((*pcVar10 == '#') && (*pcVar9 == '#')) || (pcVar10 = pcVar9, pcVar8 <= pcVar9)) break;
            }
        }
    }
    fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if ((char *)arg2 == pcVar10) {
        *(float *)(arg1 + 4) = fVar1;
        *(undefined4 *)arg1 = 0;
        return arg1;
    }
    uVar4 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    if (pcVar10 == (char *)0x0) {
        iVar6 = func_0x000180498cd0(arg2);
        pcVar10 = (char *)(iVar6 + arg2);
    }
    puVar7 = (uint32_t *)func_0x00018012ec80(uVar4, fVar1, 0xbf800000);
    fVar13 = 0.0;
    fVar2 = (float)puVar7[5];
    uStackX_20 = CONCAT31(uStackX_20._1_3_, 0.0 < (float)arg_28h);
    fVar14 = 0.0;
    pcVar9 = (char *)0x0;
    fVar11 = 0.0;
    pcVar8 = pcVar9;
    if ((uint64_t)arg2 < pcVar10) {
        do {
            if (0.0 < (float)arg_28h) {
                if (pcVar8 == (char *)0x0) {
                    pcVar8 = (char *)func_0x00018012f4a0(uVar4, fVar1, arg2, pcVar10, (float)arg_28h - fVar11, 0);
                }
                if ((uint64_t)arg2 < pcVar8) goto code_r0x0001800fe27a;
                if (fVar13 < fVar11) {
                    fVar13 = fVar11;
                }
                fVar14 = fVar14 + fVar1;
                fVar12 = 0.0;
                for (; pcVar8 = pcVar9, (uint64_t)arg2 < pcVar10; arg2 = arg2 + 1) {
                    cVar3 = *(char *)arg2;
                    if ((cVar3 != ' ') && (cVar3 != '\t')) {
                        if (cVar3 == '\n') {
                            arg2 = arg2 + 1;
                        }
                        break;
                    }
                }
            } else {
code_r0x0001800fe27a:
                uStackX_20 = (uint32_t)*(char *)arg2;
                if (uStackX_20 < 0x80) {
                    arg2 = arg2 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&uStackX_20, arg2, pcVar10);
                    arg2 = arg2 + iVar5;
                }
                if (uStackX_20 == 10) {
                    if (fVar13 <= fVar11) {
                        fVar13 = fVar11;
                    }
                    fVar14 = fVar14 + fVar1;
                    fVar12 = 0.0;
                } else {
                    fVar12 = fVar11;
                    if (uStackX_20 != 0xd) {
                        if ((*puVar7 <= uStackX_20) ||
                           (fVar12 = *(float *)(*(int64_t *)(puVar7 + 2) + (uint64_t)uStackX_20 * 4), fVar12 < 0.0)) {
                            fVar12 = (float)func_0x00018012bbd0(puVar7);
                        }
                        fVar12 = fVar12 * (fVar1 / fVar2) + fVar11;
                        if (3.402823e+38 <= fVar12) break;
                    }
                }
            }
            fVar11 = fVar12;
        } while ((uint64_t)arg2 < pcVar10);
        if (fVar13 < fVar11) {
            fVar13 = fVar11;
        }
        if ((fVar11 <= 0.0) && (fVar14 != 0.0)) goto code_r0x0001800fe32c;
    }
    fVar14 = fVar14 + fVar1;
code_r0x0001800fe32c:
    *(float *)(arg1 + 4) = fVar14;
    *(float *)arg1 = (float)(int32_t)(fVar13 + 0.99999);
    return arg1;
}

// ============================================================
// Function: FUN_1800fe1f4
// Address: 0x1800fe1f4
// Size: 290 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800fe0a0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                     int64_t arg_110h)
{
    float fVar1;
    float fVar2;
    char cVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint32_t *puVar7;
    char *pcVar8;
    char *pcVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStackX_20;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    pcVar10 = (char *)arg3;
    if ((char)placeholder_3 != '\0') {
        pcVar8 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar8 = (char *)arg3;
        }
        pcVar10 = (char *)arg2;
        if ((uint64_t)arg2 < pcVar8) {
            while (*pcVar10 != '\0') {
                pcVar9 = pcVar10 + 1;
                if (((*pcVar10 == '#') && (*pcVar9 == '#')) || (pcVar10 = pcVar9, pcVar8 <= pcVar9)) break;
            }
        }
    }
    fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if ((char *)arg2 == pcVar10) {
        *(float *)(arg1 + 4) = fVar1;
        *(undefined4 *)arg1 = 0;
        return arg1;
    }
    uVar4 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    if (pcVar10 == (char *)0x0) {
        iVar6 = func_0x000180498cd0(arg2);
        pcVar10 = (char *)(iVar6 + arg2);
    }
    puVar7 = (uint32_t *)func_0x00018012ec80(uVar4, fVar1, 0xbf800000);
    fVar13 = 0.0;
    fVar2 = (float)puVar7[5];
    uStackX_20 = CONCAT31(uStackX_20._1_3_, 0.0 < (float)arg_28h);
    fVar14 = 0.0;
    pcVar9 = (char *)0x0;
    fVar11 = 0.0;
    pcVar8 = pcVar9;
    if ((uint64_t)arg2 < pcVar10) {
        do {
            if (0.0 < (float)arg_28h) {
                if (pcVar8 == (char *)0x0) {
                    pcVar8 = (char *)func_0x00018012f4a0(uVar4, fVar1, arg2, pcVar10, (float)arg_28h - fVar11, 0);
                }
                if ((uint64_t)arg2 < pcVar8) goto code_r0x0001800fe27a;
                if (fVar13 < fVar11) {
                    fVar13 = fVar11;
                }
                fVar14 = fVar14 + fVar1;
                fVar12 = 0.0;
                for (; pcVar8 = pcVar9, (uint64_t)arg2 < pcVar10; arg2 = arg2 + 1) {
                    cVar3 = *(char *)arg2;
                    if ((cVar3 != ' ') && (cVar3 != '\t')) {
                        if (cVar3 == '\n') {
                            arg2 = arg2 + 1;
                        }
                        break;
                    }
                }
            } else {
code_r0x0001800fe27a:
                uStackX_20 = (uint32_t)*(char *)arg2;
                if (uStackX_20 < 0x80) {
                    arg2 = arg2 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&uStackX_20, arg2, pcVar10);
                    arg2 = arg2 + iVar5;
                }
                if (uStackX_20 == 10) {
                    if (fVar13 <= fVar11) {
                        fVar13 = fVar11;
                    }
                    fVar14 = fVar14 + fVar1;
                    fVar12 = 0.0;
                } else {
                    fVar12 = fVar11;
                    if (uStackX_20 != 0xd) {
                        if ((*puVar7 <= uStackX_20) ||
                           (fVar12 = *(float *)(*(int64_t *)(puVar7 + 2) + (uint64_t)uStackX_20 * 4), fVar12 < 0.0)) {
                            fVar12 = (float)func_0x00018012bbd0(puVar7);
                        }
                        fVar12 = fVar12 * (fVar1 / fVar2) + fVar11;
                        if (3.402823e+38 <= fVar12) break;
                    }
                }
            }
            fVar11 = fVar12;
        } while ((uint64_t)arg2 < pcVar10);
        if (fVar13 < fVar11) {
            fVar13 = fVar11;
        }
        if ((fVar11 <= 0.0) && (fVar14 != 0.0)) goto code_r0x0001800fe32c;
    }
    fVar14 = fVar14 + fVar1;
code_r0x0001800fe32c:
    *(float *)(arg1 + 4) = fVar14;
    *(float *)arg1 = (float)(int32_t)(fVar13 + 0.99999);
    return arg1;
}

// ============================================================
// Function: FUN_1800fe316
// Address: 0x1800fe316
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800fe0a0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                     int64_t arg_110h)
{
    float fVar1;
    float fVar2;
    char cVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint32_t *puVar7;
    char *pcVar8;
    char *pcVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStackX_20;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    pcVar10 = (char *)arg3;
    if ((char)placeholder_3 != '\0') {
        pcVar8 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar8 = (char *)arg3;
        }
        pcVar10 = (char *)arg2;
        if ((uint64_t)arg2 < pcVar8) {
            while (*pcVar10 != '\0') {
                pcVar9 = pcVar10 + 1;
                if (((*pcVar10 == '#') && (*pcVar9 == '#')) || (pcVar10 = pcVar9, pcVar8 <= pcVar9)) break;
            }
        }
    }
    fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if ((char *)arg2 == pcVar10) {
        *(float *)(arg1 + 4) = fVar1;
        *(undefined4 *)arg1 = 0;
        return arg1;
    }
    uVar4 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    if (pcVar10 == (char *)0x0) {
        iVar6 = func_0x000180498cd0(arg2);
        pcVar10 = (char *)(iVar6 + arg2);
    }
    puVar7 = (uint32_t *)func_0x00018012ec80(uVar4, fVar1, 0xbf800000);
    fVar13 = 0.0;
    fVar2 = (float)puVar7[5];
    uStackX_20 = CONCAT31(uStackX_20._1_3_, 0.0 < (float)arg_28h);
    fVar14 = 0.0;
    pcVar9 = (char *)0x0;
    fVar11 = 0.0;
    pcVar8 = pcVar9;
    if ((uint64_t)arg2 < pcVar10) {
        do {
            if (0.0 < (float)arg_28h) {
                if (pcVar8 == (char *)0x0) {
                    pcVar8 = (char *)func_0x00018012f4a0(uVar4, fVar1, arg2, pcVar10, (float)arg_28h - fVar11, 0);
                }
                if ((uint64_t)arg2 < pcVar8) goto code_r0x0001800fe27a;
                if (fVar13 < fVar11) {
                    fVar13 = fVar11;
                }
                fVar14 = fVar14 + fVar1;
                fVar12 = 0.0;
                for (; pcVar8 = pcVar9, (uint64_t)arg2 < pcVar10; arg2 = arg2 + 1) {
                    cVar3 = *(char *)arg2;
                    if ((cVar3 != ' ') && (cVar3 != '\t')) {
                        if (cVar3 == '\n') {
                            arg2 = arg2 + 1;
                        }
                        break;
                    }
                }
            } else {
code_r0x0001800fe27a:
                uStackX_20 = (uint32_t)*(char *)arg2;
                if (uStackX_20 < 0x80) {
                    arg2 = arg2 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&uStackX_20, arg2, pcVar10);
                    arg2 = arg2 + iVar5;
                }
                if (uStackX_20 == 10) {
                    if (fVar13 <= fVar11) {
                        fVar13 = fVar11;
                    }
                    fVar14 = fVar14 + fVar1;
                    fVar12 = 0.0;
                } else {
                    fVar12 = fVar11;
                    if (uStackX_20 != 0xd) {
                        if ((*puVar7 <= uStackX_20) ||
                           (fVar12 = *(float *)(*(int64_t *)(puVar7 + 2) + (uint64_t)uStackX_20 * 4), fVar12 < 0.0)) {
                            fVar12 = (float)func_0x00018012bbd0(puVar7);
                        }
                        fVar12 = fVar12 * (fVar1 / fVar2) + fVar11;
                        if (3.402823e+38 <= fVar12) break;
                    }
                }
            }
            fVar11 = fVar12;
        } while ((uint64_t)arg2 < pcVar10);
        if (fVar13 < fVar11) {
            fVar13 = fVar11;
        }
        if ((fVar11 <= 0.0) && (fVar14 != 0.0)) goto code_r0x0001800fe32c;
    }
    fVar14 = fVar14 + fVar1;
code_r0x0001800fe32c:
    *(float *)(arg1 + 4) = fVar14;
    *(float *)arg1 = (float)(int32_t)(fVar13 + 0.99999);
    return arg1;
}

// ============================================================
// Function: FUN_1800fe395
// Address: 0x1800fe395
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800fe0a0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                     int64_t arg_110h)
{
    float fVar1;
    float fVar2;
    char cVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint32_t *puVar7;
    char *pcVar8;
    char *pcVar9;
    char *pcVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 uStackX_20;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    pcVar10 = (char *)arg3;
    if ((char)placeholder_3 != '\0') {
        pcVar8 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar8 = (char *)arg3;
        }
        pcVar10 = (char *)arg2;
        if ((uint64_t)arg2 < pcVar8) {
            while (*pcVar10 != '\0') {
                pcVar9 = pcVar10 + 1;
                if (((*pcVar10 == '#') && (*pcVar9 == '#')) || (pcVar10 = pcVar9, pcVar8 <= pcVar9)) break;
            }
        }
    }
    fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    if ((char *)arg2 == pcVar10) {
        *(float *)(arg1 + 4) = fVar1;
        *(undefined4 *)arg1 = 0;
        return arg1;
    }
    uVar4 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x12e8);
    if (pcVar10 == (char *)0x0) {
        iVar6 = func_0x000180498cd0(arg2);
        pcVar10 = (char *)(iVar6 + arg2);
    }
    puVar7 = (uint32_t *)func_0x00018012ec80(uVar4, fVar1, 0xbf800000);
    fVar13 = 0.0;
    fVar2 = (float)puVar7[5];
    uStackX_20 = CONCAT31(uStackX_20._1_3_, 0.0 < (float)arg_28h);
    fVar14 = 0.0;
    pcVar9 = (char *)0x0;
    fVar11 = 0.0;
    pcVar8 = pcVar9;
    if ((uint64_t)arg2 < pcVar10) {
        do {
            if (0.0 < (float)arg_28h) {
                if (pcVar8 == (char *)0x0) {
                    pcVar8 = (char *)func_0x00018012f4a0(uVar4, fVar1, arg2, pcVar10, (float)arg_28h - fVar11, 0);
                }
                if ((uint64_t)arg2 < pcVar8) goto code_r0x0001800fe27a;
                if (fVar13 < fVar11) {
                    fVar13 = fVar11;
                }
                fVar14 = fVar14 + fVar1;
                fVar12 = 0.0;
                for (; pcVar8 = pcVar9, (uint64_t)arg2 < pcVar10; arg2 = arg2 + 1) {
                    cVar3 = *(char *)arg2;
                    if ((cVar3 != ' ') && (cVar3 != '\t')) {
                        if (cVar3 == '\n') {
                            arg2 = arg2 + 1;
                        }
                        break;
                    }
                }
            } else {
code_r0x0001800fe27a:
                uStackX_20 = (uint32_t)*(char *)arg2;
                if (uStackX_20 < 0x80) {
                    arg2 = arg2 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&uStackX_20, arg2, pcVar10);
                    arg2 = arg2 + iVar5;
                }
                if (uStackX_20 == 10) {
                    if (fVar13 <= fVar11) {
                        fVar13 = fVar11;
                    }
                    fVar14 = fVar14 + fVar1;
                    fVar12 = 0.0;
                } else {
                    fVar12 = fVar11;
                    if (uStackX_20 != 0xd) {
                        if ((*puVar7 <= uStackX_20) ||
                           (fVar12 = *(float *)(*(int64_t *)(puVar7 + 2) + (uint64_t)uStackX_20 * 4), fVar12 < 0.0)) {
                            fVar12 = (float)func_0x00018012bbd0(puVar7);
                        }
                        fVar12 = fVar12 * (fVar1 / fVar2) + fVar11;
                        if (3.402823e+38 <= fVar12) break;
                    }
                }
            }
            fVar11 = fVar12;
        } while ((uint64_t)arg2 < pcVar10);
        if (fVar13 < fVar11) {
            fVar13 = fVar11;
        }
        if ((fVar11 <= 0.0) && (fVar14 != 0.0)) goto code_r0x0001800fe32c;
    }
    fVar14 = fVar14 + fVar1;
code_r0x0001800fe32c:
    *(float *)(arg1 + 4) = fVar14;
    *(float *)arg1 = (float)(int32_t)(fVar13 + 0.99999);
    return arg1;
}

// ============================================================
// Function: FUN_1800fe3c0
// Address: 0x1800fe3c0
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800fe3c0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = 0;
    iVar10 = 0;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar13 == 0) {
        uVar11 = 0;
    } else {
        uVar11 = *(undefined8 *)(iVar13 + 0x48);
        *(undefined8 *)(iVar13 + 0x48) = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2168);
        if ((*(uint32_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x14) & 0x200) == 0) {
            iVar9 = *(int64_t *)(iVar8 + 0x1600);
        }
    }
    fVar15 = *(float *)(iVar8 + 0xdb4);
    fVar1 = *(float *)(iVar8 + 0xe04);
    fVar2 = *(float *)(iVar8 + 0xe08);
    fVar3 = fVar1;
    if (fVar1 <= fVar15) {
        fVar3 = fVar15;
    }
    uVar12 = *(int32_t *)(iVar8 + 0x1580) - 1;
    fVar4 = fVar2;
    if (fVar2 <= fVar15) {
        fVar4 = fVar15;
    }
    if (-1 < (int32_t)uVar12) {
        iVar13 = iVar9;
        do {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1588) + (uint64_t)uVar12 * 8);
            iVar9 = iVar13;
            if ((((*(char *)(iVar7 + 0x10a) != '\0') && (*(char *)(iVar7 + 0x111) == '\0')) &&
                ((*(uint32_t *)(iVar7 + 0x14) >> 9 & 1) == 0)) &&
               (*(int64_t *)(iVar7 + 0x48) == *(int64_t *)(iVar8 + 0x2168))) {
                fVar15 = fVar3;
                fVar14 = fVar4;
                if ((*(uint32_t *)(iVar7 + 0x14) & 0x42) != 0) {
                    fVar15 = fVar1;
                    fVar14 = fVar2;
                }
                fVar5 = *(float *)arg1;
                if (((*(float *)(iVar7 + 0x268) - fVar15 <= fVar5) &&
                    (fVar6 = *(float *)(arg1 + 4), *(float *)(iVar7 + 0x26c) - fVar14 <= fVar6)) &&
                   ((fVar5 < fVar15 + *(float *)(iVar7 + 0x270) && (fVar6 < fVar14 + *(float *)(iVar7 + 0x274))))) {
                    if (*(int16_t *)(iVar7 + 0x2d8) != 0) {
                        fVar15 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2dc) + *(float *)(iVar7 + 0x60);
                        if (((fVar15 <= fVar5) &&
                            (fVar14 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2de) + *(float *)(iVar7 + 100),
                            fVar14 <= fVar6)) &&
                           ((fVar5 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2d8) + fVar15 &&
                            (fVar6 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2da) + fVar14)))) goto code_r0x0001800fe5d8;
                    }
                    iVar9 = iVar7;
                    if (iVar13 != 0) {
                        iVar9 = iVar13;
                    }
                    if ((iVar10 == 0) &&
                       ((*(int64_t *)(iVar8 + 0x1600) == 0 ||
                        (*(int64_t *)(iVar7 + 0x428) != *(int64_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x428))))) {
                        iVar10 = iVar7;
                    }
                    if ((iVar9 != 0) && (iVar10 != 0)) break;
                }
            }
code_r0x0001800fe5d8:
            uVar12 = uVar12 - 1;
            iVar13 = iVar9;
        } while (-1 < (int32_t)uVar12);
    }
    *(int64_t *)arg3 = iVar9;
    if (arg4 != 0) {
        *(int64_t *)arg4 = iVar10;
    }
    if (*(int64_t *)(iVar8 + 0x1600) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar8 + 0x1600) + 0x48) = uVar11;
    }
    return;
}

// ============================================================
// Function: FUN_1800fe3d0
// Address: 0x1800fe3d0
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800fe3c0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = 0;
    iVar10 = 0;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar13 == 0) {
        uVar11 = 0;
    } else {
        uVar11 = *(undefined8 *)(iVar13 + 0x48);
        *(undefined8 *)(iVar13 + 0x48) = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2168);
        if ((*(uint32_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x14) & 0x200) == 0) {
            iVar9 = *(int64_t *)(iVar8 + 0x1600);
        }
    }
    fVar15 = *(float *)(iVar8 + 0xdb4);
    fVar1 = *(float *)(iVar8 + 0xe04);
    fVar2 = *(float *)(iVar8 + 0xe08);
    fVar3 = fVar1;
    if (fVar1 <= fVar15) {
        fVar3 = fVar15;
    }
    uVar12 = *(int32_t *)(iVar8 + 0x1580) - 1;
    fVar4 = fVar2;
    if (fVar2 <= fVar15) {
        fVar4 = fVar15;
    }
    if (-1 < (int32_t)uVar12) {
        iVar13 = iVar9;
        do {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1588) + (uint64_t)uVar12 * 8);
            iVar9 = iVar13;
            if ((((*(char *)(iVar7 + 0x10a) != '\0') && (*(char *)(iVar7 + 0x111) == '\0')) &&
                ((*(uint32_t *)(iVar7 + 0x14) >> 9 & 1) == 0)) &&
               (*(int64_t *)(iVar7 + 0x48) == *(int64_t *)(iVar8 + 0x2168))) {
                fVar15 = fVar3;
                fVar14 = fVar4;
                if ((*(uint32_t *)(iVar7 + 0x14) & 0x42) != 0) {
                    fVar15 = fVar1;
                    fVar14 = fVar2;
                }
                fVar5 = *(float *)arg1;
                if (((*(float *)(iVar7 + 0x268) - fVar15 <= fVar5) &&
                    (fVar6 = *(float *)(arg1 + 4), *(float *)(iVar7 + 0x26c) - fVar14 <= fVar6)) &&
                   ((fVar5 < fVar15 + *(float *)(iVar7 + 0x270) && (fVar6 < fVar14 + *(float *)(iVar7 + 0x274))))) {
                    if (*(int16_t *)(iVar7 + 0x2d8) != 0) {
                        fVar15 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2dc) + *(float *)(iVar7 + 0x60);
                        if (((fVar15 <= fVar5) &&
                            (fVar14 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2de) + *(float *)(iVar7 + 100),
                            fVar14 <= fVar6)) &&
                           ((fVar5 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2d8) + fVar15 &&
                            (fVar6 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2da) + fVar14)))) goto code_r0x0001800fe5d8;
                    }
                    iVar9 = iVar7;
                    if (iVar13 != 0) {
                        iVar9 = iVar13;
                    }
                    if ((iVar10 == 0) &&
                       ((*(int64_t *)(iVar8 + 0x1600) == 0 ||
                        (*(int64_t *)(iVar7 + 0x428) != *(int64_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x428))))) {
                        iVar10 = iVar7;
                    }
                    if ((iVar9 != 0) && (iVar10 != 0)) break;
                }
            }
code_r0x0001800fe5d8:
            uVar12 = uVar12 - 1;
            iVar13 = iVar9;
        } while (-1 < (int32_t)uVar12);
    }
    *(int64_t *)arg3 = iVar9;
    if (arg4 != 0) {
        *(int64_t *)arg4 = iVar10;
    }
    if (*(int64_t *)(iVar8 + 0x1600) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar8 + 0x1600) + 0x48) = uVar11;
    }
    return;
}

// ============================================================
// Function: FUN_1800fe3d7
// Address: 0x1800fe3d7
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800fe3c0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = 0;
    iVar10 = 0;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar13 == 0) {
        uVar11 = 0;
    } else {
        uVar11 = *(undefined8 *)(iVar13 + 0x48);
        *(undefined8 *)(iVar13 + 0x48) = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2168);
        if ((*(uint32_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x14) & 0x200) == 0) {
            iVar9 = *(int64_t *)(iVar8 + 0x1600);
        }
    }
    fVar15 = *(float *)(iVar8 + 0xdb4);
    fVar1 = *(float *)(iVar8 + 0xe04);
    fVar2 = *(float *)(iVar8 + 0xe08);
    fVar3 = fVar1;
    if (fVar1 <= fVar15) {
        fVar3 = fVar15;
    }
    uVar12 = *(int32_t *)(iVar8 + 0x1580) - 1;
    fVar4 = fVar2;
    if (fVar2 <= fVar15) {
        fVar4 = fVar15;
    }
    if (-1 < (int32_t)uVar12) {
        iVar13 = iVar9;
        do {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1588) + (uint64_t)uVar12 * 8);
            iVar9 = iVar13;
            if ((((*(char *)(iVar7 + 0x10a) != '\0') && (*(char *)(iVar7 + 0x111) == '\0')) &&
                ((*(uint32_t *)(iVar7 + 0x14) >> 9 & 1) == 0)) &&
               (*(int64_t *)(iVar7 + 0x48) == *(int64_t *)(iVar8 + 0x2168))) {
                fVar15 = fVar3;
                fVar14 = fVar4;
                if ((*(uint32_t *)(iVar7 + 0x14) & 0x42) != 0) {
                    fVar15 = fVar1;
                    fVar14 = fVar2;
                }
                fVar5 = *(float *)arg1;
                if (((*(float *)(iVar7 + 0x268) - fVar15 <= fVar5) &&
                    (fVar6 = *(float *)(arg1 + 4), *(float *)(iVar7 + 0x26c) - fVar14 <= fVar6)) &&
                   ((fVar5 < fVar15 + *(float *)(iVar7 + 0x270) && (fVar6 < fVar14 + *(float *)(iVar7 + 0x274))))) {
                    if (*(int16_t *)(iVar7 + 0x2d8) != 0) {
                        fVar15 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2dc) + *(float *)(iVar7 + 0x60);
                        if (((fVar15 <= fVar5) &&
                            (fVar14 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2de) + *(float *)(iVar7 + 100),
                            fVar14 <= fVar6)) &&
                           ((fVar5 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2d8) + fVar15 &&
                            (fVar6 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2da) + fVar14)))) goto code_r0x0001800fe5d8;
                    }
                    iVar9 = iVar7;
                    if (iVar13 != 0) {
                        iVar9 = iVar13;
                    }
                    if ((iVar10 == 0) &&
                       ((*(int64_t *)(iVar8 + 0x1600) == 0 ||
                        (*(int64_t *)(iVar7 + 0x428) != *(int64_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x428))))) {
                        iVar10 = iVar7;
                    }
                    if ((iVar9 != 0) && (iVar10 != 0)) break;
                }
            }
code_r0x0001800fe5d8:
            uVar12 = uVar12 - 1;
            iVar13 = iVar9;
        } while (-1 < (int32_t)uVar12);
    }
    *(int64_t *)arg3 = iVar9;
    if (arg4 != 0) {
        *(int64_t *)arg4 = iVar10;
    }
    if (*(int64_t *)(iVar8 + 0x1600) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar8 + 0x1600) + 0x48) = uVar11;
    }
    return;
}

// ============================================================
// Function: FUN_1800fe46e
// Address: 0x1800fe46e
// Size: 381 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800fe3c0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = 0;
    iVar10 = 0;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar13 == 0) {
        uVar11 = 0;
    } else {
        uVar11 = *(undefined8 *)(iVar13 + 0x48);
        *(undefined8 *)(iVar13 + 0x48) = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2168);
        if ((*(uint32_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x14) & 0x200) == 0) {
            iVar9 = *(int64_t *)(iVar8 + 0x1600);
        }
    }
    fVar15 = *(float *)(iVar8 + 0xdb4);
    fVar1 = *(float *)(iVar8 + 0xe04);
    fVar2 = *(float *)(iVar8 + 0xe08);
    fVar3 = fVar1;
    if (fVar1 <= fVar15) {
        fVar3 = fVar15;
    }
    uVar12 = *(int32_t *)(iVar8 + 0x1580) - 1;
    fVar4 = fVar2;
    if (fVar2 <= fVar15) {
        fVar4 = fVar15;
    }
    if (-1 < (int32_t)uVar12) {
        iVar13 = iVar9;
        do {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1588) + (uint64_t)uVar12 * 8);
            iVar9 = iVar13;
            if ((((*(char *)(iVar7 + 0x10a) != '\0') && (*(char *)(iVar7 + 0x111) == '\0')) &&
                ((*(uint32_t *)(iVar7 + 0x14) >> 9 & 1) == 0)) &&
               (*(int64_t *)(iVar7 + 0x48) == *(int64_t *)(iVar8 + 0x2168))) {
                fVar15 = fVar3;
                fVar14 = fVar4;
                if ((*(uint32_t *)(iVar7 + 0x14) & 0x42) != 0) {
                    fVar15 = fVar1;
                    fVar14 = fVar2;
                }
                fVar5 = *(float *)arg1;
                if (((*(float *)(iVar7 + 0x268) - fVar15 <= fVar5) &&
                    (fVar6 = *(float *)(arg1 + 4), *(float *)(iVar7 + 0x26c) - fVar14 <= fVar6)) &&
                   ((fVar5 < fVar15 + *(float *)(iVar7 + 0x270) && (fVar6 < fVar14 + *(float *)(iVar7 + 0x274))))) {
                    if (*(int16_t *)(iVar7 + 0x2d8) != 0) {
                        fVar15 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2dc) + *(float *)(iVar7 + 0x60);
                        if (((fVar15 <= fVar5) &&
                            (fVar14 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2de) + *(float *)(iVar7 + 100),
                            fVar14 <= fVar6)) &&
                           ((fVar5 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2d8) + fVar15 &&
                            (fVar6 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2da) + fVar14)))) goto code_r0x0001800fe5d8;
                    }
                    iVar9 = iVar7;
                    if (iVar13 != 0) {
                        iVar9 = iVar13;
                    }
                    if ((iVar10 == 0) &&
                       ((*(int64_t *)(iVar8 + 0x1600) == 0 ||
                        (*(int64_t *)(iVar7 + 0x428) != *(int64_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x428))))) {
                        iVar10 = iVar7;
                    }
                    if ((iVar9 != 0) && (iVar10 != 0)) break;
                }
            }
code_r0x0001800fe5d8:
            uVar12 = uVar12 - 1;
            iVar13 = iVar9;
        } while (-1 < (int32_t)uVar12);
    }
    *(int64_t *)arg3 = iVar9;
    if (arg4 != 0) {
        *(int64_t *)arg4 = iVar10;
    }
    if (*(int64_t *)(iVar8 + 0x1600) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar8 + 0x1600) + 0x48) = uVar11;
    }
    return;
}

// ============================================================
// Function: FUN_1800fe5eb
// Address: 0x1800fe5eb
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800fe3c0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = 0;
    iVar10 = 0;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar13 == 0) {
        uVar11 = 0;
    } else {
        uVar11 = *(undefined8 *)(iVar13 + 0x48);
        *(undefined8 *)(iVar13 + 0x48) = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2168);
        if ((*(uint32_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x14) & 0x200) == 0) {
            iVar9 = *(int64_t *)(iVar8 + 0x1600);
        }
    }
    fVar15 = *(float *)(iVar8 + 0xdb4);
    fVar1 = *(float *)(iVar8 + 0xe04);
    fVar2 = *(float *)(iVar8 + 0xe08);
    fVar3 = fVar1;
    if (fVar1 <= fVar15) {
        fVar3 = fVar15;
    }
    uVar12 = *(int32_t *)(iVar8 + 0x1580) - 1;
    fVar4 = fVar2;
    if (fVar2 <= fVar15) {
        fVar4 = fVar15;
    }
    if (-1 < (int32_t)uVar12) {
        iVar13 = iVar9;
        do {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1588) + (uint64_t)uVar12 * 8);
            iVar9 = iVar13;
            if ((((*(char *)(iVar7 + 0x10a) != '\0') && (*(char *)(iVar7 + 0x111) == '\0')) &&
                ((*(uint32_t *)(iVar7 + 0x14) >> 9 & 1) == 0)) &&
               (*(int64_t *)(iVar7 + 0x48) == *(int64_t *)(iVar8 + 0x2168))) {
                fVar15 = fVar3;
                fVar14 = fVar4;
                if ((*(uint32_t *)(iVar7 + 0x14) & 0x42) != 0) {
                    fVar15 = fVar1;
                    fVar14 = fVar2;
                }
                fVar5 = *(float *)arg1;
                if (((*(float *)(iVar7 + 0x268) - fVar15 <= fVar5) &&
                    (fVar6 = *(float *)(arg1 + 4), *(float *)(iVar7 + 0x26c) - fVar14 <= fVar6)) &&
                   ((fVar5 < fVar15 + *(float *)(iVar7 + 0x270) && (fVar6 < fVar14 + *(float *)(iVar7 + 0x274))))) {
                    if (*(int16_t *)(iVar7 + 0x2d8) != 0) {
                        fVar15 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2dc) + *(float *)(iVar7 + 0x60);
                        if (((fVar15 <= fVar5) &&
                            (fVar14 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2de) + *(float *)(iVar7 + 100),
                            fVar14 <= fVar6)) &&
                           ((fVar5 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2d8) + fVar15 &&
                            (fVar6 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2da) + fVar14)))) goto code_r0x0001800fe5d8;
                    }
                    iVar9 = iVar7;
                    if (iVar13 != 0) {
                        iVar9 = iVar13;
                    }
                    if ((iVar10 == 0) &&
                       ((*(int64_t *)(iVar8 + 0x1600) == 0 ||
                        (*(int64_t *)(iVar7 + 0x428) != *(int64_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x428))))) {
                        iVar10 = iVar7;
                    }
                    if ((iVar9 != 0) && (iVar10 != 0)) break;
                }
            }
code_r0x0001800fe5d8:
            uVar12 = uVar12 - 1;
            iVar13 = iVar9;
        } while (-1 < (int32_t)uVar12);
    }
    *(int64_t *)arg3 = iVar9;
    if (arg4 != 0) {
        *(int64_t *)arg4 = iVar10;
    }
    if (*(int64_t *)(iVar8 + 0x1600) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar8 + 0x1600) + 0x48) = uVar11;
    }
    return;
}

// ============================================================
// Function: FUN_1800fe5fd
// Address: 0x1800fe5fd
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800fe3c0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = 0;
    iVar10 = 0;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar13 == 0) {
        uVar11 = 0;
    } else {
        uVar11 = *(undefined8 *)(iVar13 + 0x48);
        *(undefined8 *)(iVar13 + 0x48) = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2168);
        if ((*(uint32_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x14) & 0x200) == 0) {
            iVar9 = *(int64_t *)(iVar8 + 0x1600);
        }
    }
    fVar15 = *(float *)(iVar8 + 0xdb4);
    fVar1 = *(float *)(iVar8 + 0xe04);
    fVar2 = *(float *)(iVar8 + 0xe08);
    fVar3 = fVar1;
    if (fVar1 <= fVar15) {
        fVar3 = fVar15;
    }
    uVar12 = *(int32_t *)(iVar8 + 0x1580) - 1;
    fVar4 = fVar2;
    if (fVar2 <= fVar15) {
        fVar4 = fVar15;
    }
    if (-1 < (int32_t)uVar12) {
        iVar13 = iVar9;
        do {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1588) + (uint64_t)uVar12 * 8);
            iVar9 = iVar13;
            if ((((*(char *)(iVar7 + 0x10a) != '\0') && (*(char *)(iVar7 + 0x111) == '\0')) &&
                ((*(uint32_t *)(iVar7 + 0x14) >> 9 & 1) == 0)) &&
               (*(int64_t *)(iVar7 + 0x48) == *(int64_t *)(iVar8 + 0x2168))) {
                fVar15 = fVar3;
                fVar14 = fVar4;
                if ((*(uint32_t *)(iVar7 + 0x14) & 0x42) != 0) {
                    fVar15 = fVar1;
                    fVar14 = fVar2;
                }
                fVar5 = *(float *)arg1;
                if (((*(float *)(iVar7 + 0x268) - fVar15 <= fVar5) &&
                    (fVar6 = *(float *)(arg1 + 4), *(float *)(iVar7 + 0x26c) - fVar14 <= fVar6)) &&
                   ((fVar5 < fVar15 + *(float *)(iVar7 + 0x270) && (fVar6 < fVar14 + *(float *)(iVar7 + 0x274))))) {
                    if (*(int16_t *)(iVar7 + 0x2d8) != 0) {
                        fVar15 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2dc) + *(float *)(iVar7 + 0x60);
                        if (((fVar15 <= fVar5) &&
                            (fVar14 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2de) + *(float *)(iVar7 + 100),
                            fVar14 <= fVar6)) &&
                           ((fVar5 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2d8) + fVar15 &&
                            (fVar6 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2da) + fVar14)))) goto code_r0x0001800fe5d8;
                    }
                    iVar9 = iVar7;
                    if (iVar13 != 0) {
                        iVar9 = iVar13;
                    }
                    if ((iVar10 == 0) &&
                       ((*(int64_t *)(iVar8 + 0x1600) == 0 ||
                        (*(int64_t *)(iVar7 + 0x428) != *(int64_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x428))))) {
                        iVar10 = iVar7;
                    }
                    if ((iVar9 != 0) && (iVar10 != 0)) break;
                }
            }
code_r0x0001800fe5d8:
            uVar12 = uVar12 - 1;
            iVar13 = iVar9;
        } while (-1 < (int32_t)uVar12);
    }
    *(int64_t *)arg3 = iVar9;
    if (arg4 != 0) {
        *(int64_t *)arg4 = iVar10;
    }
    if (*(int64_t *)(iVar8 + 0x1600) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar8 + 0x1600) + 0x48) = uVar11;
    }
    return;
}

// ============================================================
// Function: FUN_1800fe616
// Address: 0x1800fe616
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800fe3c0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t iVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    iVar9 = 0;
    iVar10 = 0;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar13 == 0) {
        uVar11 = 0;
    } else {
        uVar11 = *(undefined8 *)(iVar13 + 0x48);
        *(undefined8 *)(iVar13 + 0x48) = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2168);
        if ((*(uint32_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x14) & 0x200) == 0) {
            iVar9 = *(int64_t *)(iVar8 + 0x1600);
        }
    }
    fVar15 = *(float *)(iVar8 + 0xdb4);
    fVar1 = *(float *)(iVar8 + 0xe04);
    fVar2 = *(float *)(iVar8 + 0xe08);
    fVar3 = fVar1;
    if (fVar1 <= fVar15) {
        fVar3 = fVar15;
    }
    uVar12 = *(int32_t *)(iVar8 + 0x1580) - 1;
    fVar4 = fVar2;
    if (fVar2 <= fVar15) {
        fVar4 = fVar15;
    }
    if (-1 < (int32_t)uVar12) {
        iVar13 = iVar9;
        do {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1588) + (uint64_t)uVar12 * 8);
            iVar9 = iVar13;
            if ((((*(char *)(iVar7 + 0x10a) != '\0') && (*(char *)(iVar7 + 0x111) == '\0')) &&
                ((*(uint32_t *)(iVar7 + 0x14) >> 9 & 1) == 0)) &&
               (*(int64_t *)(iVar7 + 0x48) == *(int64_t *)(iVar8 + 0x2168))) {
                fVar15 = fVar3;
                fVar14 = fVar4;
                if ((*(uint32_t *)(iVar7 + 0x14) & 0x42) != 0) {
                    fVar15 = fVar1;
                    fVar14 = fVar2;
                }
                fVar5 = *(float *)arg1;
                if (((*(float *)(iVar7 + 0x268) - fVar15 <= fVar5) &&
                    (fVar6 = *(float *)(arg1 + 4), *(float *)(iVar7 + 0x26c) - fVar14 <= fVar6)) &&
                   ((fVar5 < fVar15 + *(float *)(iVar7 + 0x270) && (fVar6 < fVar14 + *(float *)(iVar7 + 0x274))))) {
                    if (*(int16_t *)(iVar7 + 0x2d8) != 0) {
                        fVar15 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2dc) + *(float *)(iVar7 + 0x60);
                        if (((fVar15 <= fVar5) &&
                            (fVar14 = (float)(int32_t)*(int16_t *)(iVar7 + 0x2de) + *(float *)(iVar7 + 100),
                            fVar14 <= fVar6)) &&
                           ((fVar5 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2d8) + fVar15 &&
                            (fVar6 < (float)(int32_t)*(int16_t *)(iVar7 + 0x2da) + fVar14)))) goto code_r0x0001800fe5d8;
                    }
                    iVar9 = iVar7;
                    if (iVar13 != 0) {
                        iVar9 = iVar13;
                    }
                    if ((iVar10 == 0) &&
                       ((*(int64_t *)(iVar8 + 0x1600) == 0 ||
                        (*(int64_t *)(iVar7 + 0x428) != *(int64_t *)(*(int64_t *)(iVar8 + 0x1600) + 0x428))))) {
                        iVar10 = iVar7;
                    }
                    if ((iVar9 != 0) && (iVar10 != 0)) break;
                }
            }
code_r0x0001800fe5d8:
            uVar12 = uVar12 - 1;
            iVar13 = iVar9;
        } while (-1 < (int32_t)uVar12);
    }
    *(int64_t *)arg3 = iVar9;
    if (arg4 != 0) {
        *(int64_t *)arg4 = iVar10;
    }
    if (*(int64_t *)(iVar8 + 0x1600) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar8 + 0x1600) + 0x48) = uVar11;
    }
    return;
}

// ============================================================
// Function: FUN_1800fe660
// Address: 0x1800fe660
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.1800fe660(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int64_t unaff_retaddr;
    int64_t in_stack_000000b8;
    int64_t var_38h;
    
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    fcn.1800f5a90(arg1, 0, *(undefined4 *)
                            (*(int64_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0x150) + -4 +
                            (int64_t)*(int32_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0x148) * 4));
    fcn.1800fe6d0(CONCAT44(var_38h._4_4_, (int32_t)arg4), unaff_retaddr, in_stack_000000b8);
    return;
}

// ============================================================
// Function: FUN_1800fe6d0
// Address: 0x1800fe6d0
// Size: 904 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1b4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1bah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

undefined fcn.1800fe6d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_60h,
                       int64_t arg_118h)
{
    undefined4 uVar1;
    uint8_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint8_t *puVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint32_t uVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    undefined4 uStack_48;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar11 = (uint64_t)((uint32_t)arg4 & 0xfffffffb);
    if ((arg4 & 0x10U) == 0) {
        uVar11 = arg4 & 0xffffffff;
    }
    uVar10 = (uint64_t)((uint32_t)uVar11 & 0xfffffff7);
    if ((uVar11 & 0x20) == 0) {
        uVar10 = uVar11;
    }
    uVar6 = 0x1080041;
    if ((uVar10 & 0x70) == 0) {
        uVar6 = 0x1080001;
    }
    arg_28h._0_4_ = uVar6 | *(uint32_t *)(iVar3 + 0x14) & 4 | (uint32_t)arg_28h;
    if ((uVar10 & 0xc) == 0) {
        arg_28h._0_4_ = (uint32_t)arg_28h | 0x102;
    }
    if ((char)uVar10 < '\0') {
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf00);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf04);
        uStack_4c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf08);
        uStack_48 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf0c);
        var_58h._0_4_ = 3;
        func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_58h);
        if (*(int32_t *)(iVar4 + 0x20bc) != 3) {
            *(undefined4 *)(iVar4 + 0xf00) = *(undefined4 *)(iVar4 + 0xf40);
            *(undefined4 *)(iVar4 + 0xf04) = *(undefined4 *)(iVar4 + 0xf44);
            *(undefined4 *)(iVar4 + 0xf08) = *(undefined4 *)(iVar4 + 0xf48);
            *(undefined4 *)(iVar4 + 0xf0c) = *(undefined4 *)(iVar4 + 0xf4c);
        }
        func_0x0001800f6810(7, *(undefined4 *)(iVar4 + 0xde4));
        func_0x0001800f6810(8, *(undefined4 *)(iVar4 + 0xde8));
        func_0x0001800f6960(2, iVar4 + 0xddc);
        uVar10 = (uint64_t)((uint32_t)uVar10 | 3);
        arg_28h._0_4_ = (uint32_t)arg_28h | 4;
    }
    iVar12 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if ((*(int64_t *)(iVar12 + 0x208) != 0) || (iVar7 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0)) {
        iVar7 = 0x2a0;
    }
    if ((uVar10 & 0x20) == 0) {
        fVar15 = *(float *)(iVar12 + 4 + iVar7) - *(float *)(iVar12 + 0x15c);
    } else {
        fVar15 = 0.0;
    }
    if ((uVar10 & 0x10) == 0) {
        fVar14 = *(float *)(iVar12 + iVar7) - *(float *)(iVar12 + 0x158);
    } else {
        fVar14 = 0.0;
    }
    iVar12 = *(int64_t *)0x180781f28;
    func_0x00018010be90(&var_8h, *(undefined8 *)arg3, fVar14, fVar15);
    if (((*(uint8_t *)(iVar4 + 0x2008) & 2) != 0) && ((*(uint8_t *)(iVar4 + 0x2010) & 1) != 0)) {
        fVar15 = *(float *)(iVar4 + 0x202c);
        if (0.0 < fVar15) {
            var_8h._0_4_ = fVar15;
        }
        uVar6 = (uint32_t)uVar10 & 0xfffffffb;
        if (fVar15 <= 0.0) {
            uVar6 = (uint32_t)uVar10;
        }
        uVar10 = (uint64_t)uVar6;
        if (0.0 < *(float *)(iVar4 + 0x2030)) {
            uVar10 = (uint64_t)(uVar6 & 0xfffffff7);
            var_8h._4_4_ = *(float *)(iVar4 + 0x2030);
        }
    }
    *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 2;
    *(uint64_t *)(iVar12 + 0x202c) = CONCAT44(var_8h._4_4_, (float)var_8h);
    *(undefined4 *)(iVar12 + 0x2010) = 1;
    uVar6 = (uint32_t)uVar10;
    if ((*(uint32_t *)(iVar4 + 0x2008) >> 9 & 1) == 0) {
        *(uint32_t *)(iVar4 + 0x2048) = uVar6;
    } else {
        *(uint32_t *)(iVar4 + 0x2048) = *(uint32_t *)(iVar4 + 0x2048) | uVar6;
    }
    *(uint32_t *)(iVar4 + 0x2008) = *(uint32_t *)(iVar4 + 0x2008) | 0x200;
    uVar13 = (uint32_t)arg2;
    if (arg1 == 0) {
        var_68h = arg2 & 0xffffffff;
        func_0x0001800f5970(&var_8h, 0, 0x1806444b0, *(undefined8 *)(iVar3 + 8), var_68h);
    } else {
        func_0x0001800f5970(&var_8h, 0, 0x1806444a0, *(undefined8 *)(iVar3 + 8), arg1, uVar13);
    }
    uVar1 = *(undefined4 *)(iVar4 + 0xdd0);
    if ((uVar10 & 1) == 0) {
        *(undefined4 *)(iVar4 + 0xdd0) = 0;
    }
    uVar5 = func_0x0001801019f0(CONCAT44(var_8h._4_4_, (float)var_8h), 0, (uint32_t)arg_28h);
    *(undefined4 *)(iVar4 + 0xdd0) = uVar1;
    if ((char)uVar10 < '\0') {
        func_0x0001800f6a20(3);
        func_0x0001800f6770(1);
    }
    iVar12 = *(int64_t *)(iVar4 + 0x15e0);
    *(uint32_t *)(iVar12 + 0xcc) = uVar13;
    if (*(int16_t *)(iVar12 + 0x118) == 1) {
        *(undefined8 *)(iVar3 + 0x158) = *(undefined8 *)(iVar12 + 0x60);
    }
    puVar8 = (uint8_t *)0x1806444b9;
    uVar11 = 0x23;
    uVar9 = ~uVar13;
    do {
        if ((((char)uVar11 == '#') && (*puVar8 == 0x23)) && (puVar8[1] == 0x23)) {
            puVar8 = puVar8 + 2;
            uVar9 = ~uVar13;
        } else {
            uVar9 = uVar9 >> 8 ^ *(uint32_t *)(((uint64_t)uVar9 & 0xff ^ uVar11) * 4 + 0x180618620);
        }
        uVar2 = *puVar8;
        uVar11 = (uint64_t)uVar2;
        puVar8 = puVar8 + 1;
    } while (uVar2 != 0);
    if (*(uint32_t *)(iVar4 + 0x1654) == ~uVar9) {
        func_0x0001800f9f30(0, 0);
    }
    if (((*(uint32_t *)(iVar4 + 0x21ec) == uVar13) && ((uVar6 >> 8 & 1) == 0)) &&
       ((*(int16_t *)(iVar12 + 0x1b4) != 0 || (*(char *)(iVar12 + 0x1ba) != '\0')))) {
        func_0x00018010e050(iVar12, 0);
        func_0x00018010ee50(iVar12, 0);
        func_0x0001800f9f30(~uVar9, iVar12);
        *(undefined4 *)(iVar4 + 0x1674) = *(undefined4 *)(iVar4 + 0x2228);
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1800fea60
// Address: 0x1800fea60
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800fea60(int64_t arg_80h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint32_t uVar11;
    float fVar12;
    float fVar13;
    int64_t var_8h;
    int64_t var_18h;
    float var_48h;
    int64_t var_44h;
    int64_t var_3ch;
    float var_34h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar2 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1548);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1548) = *(undefined4 *)(iVar4 + 0x10);
    var_8h = *(int64_t *)(iVar4 + 0x68);
    fVar12 = (float)var_8h;
    func_0x000180105c20();
    iVar5 = *(int64_t *)0x180781f28;
    if (*(int16_t *)(iVar4 + 0x118) == 1) {
        iVar5 = *(int64_t *)(iVar10 + 0x15e0);
        var_44h._0_4_ = *(float *)(iVar5 + 0x15c);
        var_48h = *(float *)(iVar5 + 0x158);
        var_3ch._0_4_ = (float)var_44h + var_8h._4_4_;
        var_44h._4_4_ = var_48h + fVar12;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        uVar11 = *(uint32_t *)(iVar4 + 0x1c) & 0x100;
        if (((*(int16_t *)(iVar4 + 0x1b4) == 0) && (*(char *)(iVar4 + 0x1ba) == '\0')) || (uVar11 != 0)) {
            func_0x00018010b530(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0, 2);
            if (uVar11 != 0) {
                *(uint16_t *)(iVar5 + 0x1b6) = *(uint16_t *)(iVar5 + 0x1b6) | *(uint16_t *)(iVar4 + 0x1b6);
            }
        } else {
            func_0x00018010b530(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0, 0);
            func_0x0001800f7d00(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0);
            if ((*(int16_t *)(iVar4 + 0x1b4) == 0) && (iVar4 == *(int64_t *)(iVar10 + 0x21d8))) {
                var_3ch._4_4_ = var_48h - 2.0;
                var_30h._0_4_ = var_44h._4_4_ + 2.0;
                var_34h = (float)var_44h - 2.0;
                var_30h._4_4_ = (float)var_3ch + 2.0;
                func_0x0001800f7d00((int64_t)&var_3ch + 4, *(undefined4 *)(iVar10 + 0x21d0), 2);
            }
        }
        if (*(int64_t *)(iVar10 + 0x15e8) == iVar4) {
            *(uint32_t *)(iVar10 + 0x1fc0) = *(uint32_t *)(iVar10 + 0x1fc0) | 0x80;
        }
        *(undefined4 *)(iVar4 + 0x224) = *(undefined4 *)(iVar10 + 0x1fc0);
    } else {
        puVar1 = (undefined8 *)(iVar4 + 0x60);
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        fVar12 = *(float *)puVar1 + *(float *)(iVar4 + 0x68);
        fVar13 = *(float *)(iVar4 + 100) + *(float *)(iVar4 + 0x6c);
        uVar3 = *(undefined4 *)(iVar4 + 0x224);
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = *(undefined4 *)(iVar4 + 0xcc);
        *(undefined4 *)(iVar5 + 0x1fbc) = *(undefined4 *)(iVar5 + 0x1f78);
        *(undefined4 *)(iVar5 + 0x1fc0) = uVar3;
        auVar6._8_4_ = fVar12;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar13;
        *(undefined (*) [16])(iVar5 + 0x1fd4) = auVar6;
        auVar7._8_4_ = fVar12;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar13;
        *(undefined (*) [16])(iVar5 + 0x1fc4) = auVar7;
    }
    *(undefined4 *)(iVar10 + 0x2a30) = 0xff7fffff;
    *(undefined4 *)(iVar10 + 0x1548) = uVar2;
    return;
}

// ============================================================
// Function: FUN_1800feaaa
// Address: 0x1800feaaa
// Size: 356 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800fea60(int64_t arg_80h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint32_t uVar11;
    float fVar12;
    float fVar13;
    int64_t var_8h;
    int64_t var_18h;
    float var_48h;
    int64_t var_44h;
    int64_t var_3ch;
    float var_34h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar2 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1548);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1548) = *(undefined4 *)(iVar4 + 0x10);
    var_8h = *(int64_t *)(iVar4 + 0x68);
    fVar12 = (float)var_8h;
    func_0x000180105c20();
    iVar5 = *(int64_t *)0x180781f28;
    if (*(int16_t *)(iVar4 + 0x118) == 1) {
        iVar5 = *(int64_t *)(iVar10 + 0x15e0);
        var_44h._0_4_ = *(float *)(iVar5 + 0x15c);
        var_48h = *(float *)(iVar5 + 0x158);
        var_3ch._0_4_ = (float)var_44h + var_8h._4_4_;
        var_44h._4_4_ = var_48h + fVar12;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        uVar11 = *(uint32_t *)(iVar4 + 0x1c) & 0x100;
        if (((*(int16_t *)(iVar4 + 0x1b4) == 0) && (*(char *)(iVar4 + 0x1ba) == '\0')) || (uVar11 != 0)) {
            func_0x00018010b530(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0, 2);
            if (uVar11 != 0) {
                *(uint16_t *)(iVar5 + 0x1b6) = *(uint16_t *)(iVar5 + 0x1b6) | *(uint16_t *)(iVar4 + 0x1b6);
            }
        } else {
            func_0x00018010b530(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0, 0);
            func_0x0001800f7d00(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0);
            if ((*(int16_t *)(iVar4 + 0x1b4) == 0) && (iVar4 == *(int64_t *)(iVar10 + 0x21d8))) {
                var_3ch._4_4_ = var_48h - 2.0;
                var_30h._0_4_ = var_44h._4_4_ + 2.0;
                var_34h = (float)var_44h - 2.0;
                var_30h._4_4_ = (float)var_3ch + 2.0;
                func_0x0001800f7d00((int64_t)&var_3ch + 4, *(undefined4 *)(iVar10 + 0x21d0), 2);
            }
        }
        if (*(int64_t *)(iVar10 + 0x15e8) == iVar4) {
            *(uint32_t *)(iVar10 + 0x1fc0) = *(uint32_t *)(iVar10 + 0x1fc0) | 0x80;
        }
        *(undefined4 *)(iVar4 + 0x224) = *(undefined4 *)(iVar10 + 0x1fc0);
    } else {
        puVar1 = (undefined8 *)(iVar4 + 0x60);
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        fVar12 = *(float *)puVar1 + *(float *)(iVar4 + 0x68);
        fVar13 = *(float *)(iVar4 + 100) + *(float *)(iVar4 + 0x6c);
        uVar3 = *(undefined4 *)(iVar4 + 0x224);
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = *(undefined4 *)(iVar4 + 0xcc);
        *(undefined4 *)(iVar5 + 0x1fbc) = *(undefined4 *)(iVar5 + 0x1f78);
        *(undefined4 *)(iVar5 + 0x1fc0) = uVar3;
        auVar6._8_4_ = fVar12;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar13;
        *(undefined (*) [16])(iVar5 + 0x1fd4) = auVar6;
        auVar7._8_4_ = fVar12;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar13;
        *(undefined (*) [16])(iVar5 + 0x1fc4) = auVar7;
    }
    *(undefined4 *)(iVar10 + 0x2a30) = 0xff7fffff;
    *(undefined4 *)(iVar10 + 0x1548) = uVar2;
    return;
}

// ============================================================
// Function: FUN_1800fec0e
// Address: 0x1800fec0e
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800fea60(int64_t arg_80h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined8 uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    uint32_t uVar11;
    float fVar12;
    float fVar13;
    int64_t var_8h;
    int64_t var_18h;
    float var_48h;
    int64_t var_44h;
    int64_t var_3ch;
    float var_34h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar10 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar2 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1548);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1548) = *(undefined4 *)(iVar4 + 0x10);
    var_8h = *(int64_t *)(iVar4 + 0x68);
    fVar12 = (float)var_8h;
    func_0x000180105c20();
    iVar5 = *(int64_t *)0x180781f28;
    if (*(int16_t *)(iVar4 + 0x118) == 1) {
        iVar5 = *(int64_t *)(iVar10 + 0x15e0);
        var_44h._0_4_ = *(float *)(iVar5 + 0x15c);
        var_48h = *(float *)(iVar5 + 0x158);
        var_3ch._0_4_ = (float)var_44h + var_8h._4_4_;
        var_44h._4_4_ = var_48h + fVar12;
        func_0x00018010bbf0(&var_8h, 0xbf800000);
        uVar11 = *(uint32_t *)(iVar4 + 0x1c) & 0x100;
        if (((*(int16_t *)(iVar4 + 0x1b4) == 0) && (*(char *)(iVar4 + 0x1ba) == '\0')) || (uVar11 != 0)) {
            func_0x00018010b530(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0, 2);
            if (uVar11 != 0) {
                *(uint16_t *)(iVar5 + 0x1b6) = *(uint16_t *)(iVar5 + 0x1b6) | *(uint16_t *)(iVar4 + 0x1b6);
            }
        } else {
            func_0x00018010b530(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0, 0);
            func_0x0001800f7d00(&var_48h, *(undefined4 *)(iVar4 + 0xcc), 0);
            if ((*(int16_t *)(iVar4 + 0x1b4) == 0) && (iVar4 == *(int64_t *)(iVar10 + 0x21d8))) {
                var_3ch._4_4_ = var_48h - 2.0;
                var_30h._0_4_ = var_44h._4_4_ + 2.0;
                var_34h = (float)var_44h - 2.0;
                var_30h._4_4_ = (float)var_3ch + 2.0;
                func_0x0001800f7d00((int64_t)&var_3ch + 4, *(undefined4 *)(iVar10 + 0x21d0), 2);
            }
        }
        if (*(int64_t *)(iVar10 + 0x15e8) == iVar4) {
            *(uint32_t *)(iVar10 + 0x1fc0) = *(uint32_t *)(iVar10 + 0x1fc0) | 0x80;
        }
        *(undefined4 *)(iVar4 + 0x224) = *(undefined4 *)(iVar10 + 0x1fc0);
    } else {
        puVar1 = (undefined8 *)(iVar4 + 0x60);
        uVar9 = *puVar1;
        uVar8 = *puVar1;
        fVar12 = *(float *)puVar1 + *(float *)(iVar4 + 0x68);
        fVar13 = *(float *)(iVar4 + 100) + *(float *)(iVar4 + 0x6c);
        uVar3 = *(undefined4 *)(iVar4 + 0x224);
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = *(undefined4 *)(iVar4 + 0xcc);
        *(undefined4 *)(iVar5 + 0x1fbc) = *(undefined4 *)(iVar5 + 0x1f78);
        *(undefined4 *)(iVar5 + 0x1fc0) = uVar3;
        auVar6._8_4_ = fVar12;
        auVar6._0_8_ = uVar8;
        auVar6._12_4_ = fVar13;
        *(undefined (*) [16])(iVar5 + 0x1fd4) = auVar6;
        auVar7._8_4_ = fVar12;
        auVar7._0_8_ = uVar9;
        auVar7._12_4_ = fVar13;
        *(undefined (*) [16])(iVar5 + 0x1fc4) = auVar7;
    }
    *(undefined4 *)(iVar10 + 0x2a30) = 0xff7fffff;
    *(undefined4 *)(iVar10 + 0x1548) = uVar2;
    return;
}

// ============================================================
// Function: FUN_1800fee20
// Address: 0x1800fee20
// Size: 279 bytes
// ============================================================
void fcn.1800fee20(int64_t arg1, int64_t arg2)
{
    float fVar1;
    float fVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    
    iVar5 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    fVar1 = *(float *)(iVar5 + 8);
    fVar2 = *(float *)(iVar5 + 0xc);
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0;
    *(float *)(arg1 + 0x60) = fVar1 + 60.0;
    *(float *)(arg1 + 100) = fVar2 + 60.0;
    *(undefined8 *)(arg1 + 0x54) = *(undefined8 *)(iVar5 + 8);
    *(undefined4 *)(arg1 + 0x131) = 0xf0f0f0f;
    if (arg2 != 0) {
        *(uint8_t *)(arg1 + 0x133) = *(uint8_t *)(arg1 + 0x133) & 0xfb;
        *(undefined2 *)(arg1 + 0x131) = 0xb0b;
        *(undefined *)(arg1 + 0x134) = 0xb;
        func_0x0001800fed40();
    }
    uVar3 = *(undefined4 *)(arg1 + 0x60);
    uVar4 = *(undefined4 *)(arg1 + 100);
    *(undefined4 *)(arg1 + 0x178) = uVar3;
    *(undefined4 *)(arg1 + 0x17c) = uVar4;
    *(undefined4 *)(arg1 + 0x170) = uVar3;
    *(undefined4 *)(arg1 + 0x174) = uVar4;
    *(undefined4 *)(arg1 + 0x168) = uVar3;
    *(undefined4 *)(arg1 + 0x16c) = uVar4;
    if ((*(uint8_t *)(arg1 + 0x14) & 0x40) != 0) {
        *(undefined2 *)(arg1 + 0x128) = 0x202;
        *(undefined *)(arg1 + 0x12a) = 0;
        return;
    }
    if (*(float *)(arg1 + 0x68) <= 0.0) {
        *(undefined *)(arg1 + 0x128) = 2;
    }
    if (*(float *)(arg1 + 0x6c) <= 0.0) {
        *(undefined *)(arg1 + 0x129) = 2;
    }
    if ((*(char *)(arg1 + 0x128) < '\x01') && (*(char *)(arg1 + 0x129) < '\x01')) {
        *(undefined *)(arg1 + 0x12a) = 0;
        return;
    }
    *(undefined *)(arg1 + 0x12a) = 1;
    return;
}

// ============================================================
// Function: FUN_1800ff010
// Address: 0x1800ff010
// Size: 309 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

int64_t fcn.1800ff010(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    float fVar3;
    undefined auVar4 [16];
    float fVar5;
    float fVar6;
    undefined auVar7 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_20h;
    undefined4 var_18h;
    undefined4 var_14h;
    float fStack_10;
    int64_t var_ch;
    
    fVar3 = *(float *)arg3;
    fVar6 = *(float *)(arg3 + 4);
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x2008) & 0x10) != 0) {
        fVar5 = *(float *)(*(int64_t *)0x180781f28 + 0x2050);
        fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0x2054);
        if ((fVar5 < 0.0) || (fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0x2058), fVar1 < 0.0)) {
            fVar5 = *(float *)(arg2 + 0x70);
        } else if ((fVar5 <= fVar3) && (fVar5 = fVar1, fVar3 <= fVar1)) {
            fVar5 = fVar3;
        }
        if ((fVar2 < 0.0) || (fVar3 = *(float *)(*(int64_t *)0x180781f28 + 0x205c), fVar3 < 0.0)) {
            fVar2 = *(float *)(arg2 + 0x74);
        } else if ((fVar2 <= fVar6) && (fVar2 = fVar3, fVar6 <= fVar3)) {
            fVar2 = fVar6;
        }
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2060) != (code *)0x0) {
            var_20h._0_4_ = *(undefined4 *)(arg2 + 0x60);
            var_20h._4_4_ = *(undefined4 *)(arg2 + 100);
            var_28h = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2068);
            var_18h = *(undefined4 *)(arg2 + 0x70);
            var_14h = *(undefined4 *)(arg2 + 0x74);
            fStack_10 = fVar5;
            var_ch._0_4_ = fVar2;
            (**(code **)(*(int64_t *)0x180781f28 + 0x2060))(&var_28h);
            fVar2 = (float)var_ch;
            fVar5 = fStack_10;
        }
        fVar3 = (float)(int32_t)fVar5;
        fVar6 = (float)(int32_t)fVar2;
    }
    auVar7 = ZEXT416((uint32_t)fVar6);
    auVar4 = ZEXT416((uint32_t)fVar3);
    func_0x0001800fef40(&var_8h, arg2);
    if (auVar4._0_4_ <= (float)var_8h) {
        auVar4._0_4_ = (float)var_8h;
    }
    if (auVar7._0_4_ <= var_8h._4_4_) {
        auVar7._0_4_ = var_8h._4_4_;
    }
    *(int32_t *)arg1 = auVar4._0_4_;
    *(int32_t *)(arg1 + 4) = auVar7._0_4_;
    return arg1;
}

// ============================================================
// Function: FUN_1800ff150
// Address: 0x1800ff150
// Size: 347 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800ff150(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    int64_t var_8h;
    
    if ((((*(char *)(arg1 + 0x10c) == '\0') || ('\0' < *(char *)(arg1 + 0x128))) || ('\0' < *(char *)(arg1 + 0x129))) &&
       (((*(char *)(arg1 + 0x111) == '\0' || (*(char *)(arg1 + 300) != '\0')) || (*(char *)(arg1 + 299) < '\x01')))) {
        fVar1 = *(float *)(arg1 + 0x88);
        if (fVar1 == 0.0) {
            fVar1 = (float)(int64_t)(*(float *)(arg1 + 0x170) - *(float *)(arg1 + 0x168));
        }
        *(float *)arg2 = fVar1;
        fVar1 = *(float *)(arg1 + 0x8c);
        if (fVar1 == 0.0) {
            fVar1 = (float)(int64_t)(*(float *)(arg1 + 0x174) - *(float *)(arg1 + 0x16c));
        }
        *(float *)(arg2 + 4) = fVar1;
        fVar1 = *(float *)(arg1 + 0x88);
        if (fVar1 == 0.0) {
            fVar1 = *(float *)(arg1 + 0x170);
            if (*(float *)(arg1 + 0x170) <= *(float *)(arg1 + 0x178)) {
                fVar1 = *(float *)(arg1 + 0x178);
            }
            fVar1 = (float)(int64_t)(fVar1 - *(float *)(arg1 + 0x168));
        }
        *(float *)arg3 = fVar1;
        fVar1 = *(float *)(arg1 + 0x8c);
        if (fVar1 == 0.0) {
            fVar1 = *(float *)(arg1 + 0x174);
            if (*(float *)(arg1 + 0x174) <= *(float *)(arg1 + 0x17c)) {
                fVar1 = *(float *)(arg1 + 0x17c);
            }
            fVar1 = (float)(int64_t)(fVar1 - *(float *)(arg1 + 0x16c));
        }
        *(float *)(arg3 + 4) = fVar1;
        return;
    }
    *(undefined8 *)arg2 = *(undefined8 *)(arg1 + 0x78);
    *(undefined8 *)arg3 = *(undefined8 *)(arg1 + 0x80);
    return;
}

// ============================================================
// Function: FUN_1800ff2b0
// Address: 0x1800ff2b0
// Size: 406 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

int64_t fcn.1800ff2b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    bool bVar2;
    bool bVar3;
    int64_t iVar4;
    uint32_t uVar5;
    float *pfVar6;
    int64_t arg2_00;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar11 = *(float *)(arg2 + 0x90) + *(float *)(arg2 + 0x90);
    fVar13 = *(float *)(arg2 + 0x94) + *(float *)(arg2 + 0x94);
    fVar15 = (*(float *)(arg2 + 0xb4) + *(float *)(arg2 + 0xac)) - *(float *)(arg2 + 0x100);
    fVar14 = (*(float *)(arg2 + 0xb0) + *(float *)(arg2 + 0xa8)) - *(float *)(arg2 + 0xfc);
    if ((arg4 & 1U) == 0) {
        fVar7 = *(float *)(arg2 + 0x68);
    } else {
        fVar7 = fVar11 + *(float *)arg3 + fVar14;
    }
    if ((arg4 & 2U) == 0) {
        fVar8 = *(float *)(arg2 + 0x6c);
    } else {
        fVar8 = fVar13 + *(float *)(arg3 + 4) + fVar15;
    }
    fVar9 = 3.402823e+38;
    fVar12 = 3.402823e+38;
    if ((*(uint32_t *)(arg2 + 0x14) & 0x5000000) != 0x1000000) {
        if (*(char *)(arg2 + 0x108) == '\0') {
            fVar9 = *(float *)(**(int64_t **)(*(int64_t *)0x180781f28 + 0x2158) + 0x28) -
                    (*(float *)(*(int64_t *)0x180781f28 + 0xeb0) + *(float *)(*(int64_t *)0x180781f28 + 0xeb0));
            fVar12 = *(float *)(**(int64_t **)(*(int64_t *)0x180781f28 + 0x2158) + 0x2c) -
                     (*(float *)(*(int64_t *)0x180781f28 + 0xeb4) + *(float *)(*(int64_t *)0x180781f28 + 0xeb4));
        }
        iVar1 = *(int32_t *)(arg2 + 0x5c);
        if ((-1 < iVar1) && (iVar1 < *(int32_t *)(*(int64_t *)0x180781f28 + 0xd60))) {
            fVar9 = *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0xd68) + 0x18 + (int64_t)iVar1 * 0x30) -
                    (*(float *)(*(int64_t *)0x180781f28 + 0xeb0) + *(float *)(*(int64_t *)0x180781f28 + 0xeb0));
            fVar12 = *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0xd68) + 0x1c + (int64_t)iVar1 * 0x30) -
                     (*(float *)(*(int64_t *)0x180781f28 + 0xeb4) + *(float *)(*(int64_t *)0x180781f28 + 0xeb4));
        }
    }
    if ((*(uint32_t *)(arg2 + 0x14) >> 0x19 & 1) == 0) {
        arg2_00 = arg2;
        func_0x0001800fef40(&var_10h);
        if (fVar12 <= var_10h._4_4_) {
            var_10h._4_4_ = fVar12;
        }
        if (fVar9 <= (float)var_10h) {
            var_10h._0_4_ = fVar9;
        }
        fVar10 = var_10h._4_4_;
        if ((var_10h._4_4_ <= fVar8) && (fVar10 = fVar12, fVar8 <= fVar12)) {
            fVar10 = fVar8;
        }
        fVar8 = (float)var_10h;
        if (((float)var_10h <= fVar7) && (fVar8 = fVar9, fVar7 <= fVar9)) {
            fVar8 = fVar7;
        }
        var_10h._0_4_ = fVar8;
        var_10h._4_4_ = fVar10;
        fcn.1800ff010((int64_t)&var_b8h, arg2_00, (int64_t)&var_10h);
        pfVar6 = (float *)arg3;
        if ((arg4 & 1U) == 0) {
            pfVar6 = (float *)(arg2 + 0x78);
        }
        if ((arg4 & 2U) == 0) {
            fVar7 = *(float *)(arg2 + 0x7c);
        } else {
            fVar7 = *(float *)(arg3 + 4);
        }
        if (((((float)var_b8h < fVar11 + *pfVar6 + fVar14) && (uVar5 = *(uint32_t *)(arg2 + 0x14), (uVar5 & 8) == 0)) &&
            ((uVar5 >> 0xb & 1) != 0)) || (uVar5 = *(uint32_t *)(arg2 + 0x14), (uVar5 >> 0xf & 1) != 0)) {
            bVar2 = true;
        } else {
            bVar2 = false;
        }
        if (((var_b8h._4_4_ < fVar13 + fVar7 + fVar15) && ((uVar5 & 8) == 0)) || ((uVar5 >> 0xe & 1) != 0)) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (bVar2) {
            fVar10 = fVar10 + *(float *)(iVar4 + 0xe14);
        }
        if (bVar3) {
            fVar8 = fVar8 + *(float *)(iVar4 + 0xe14);
        }
        *(uint64_t *)arg1 = CONCAT44(fVar10, fVar8);
    } else {
        if (fVar9 <= fVar7) {
            fVar7 = fVar9;
        }
        if (fVar12 <= fVar8) {
            fVar8 = fVar12;
        }
        *(float *)arg1 = fVar7;
        *(float *)(arg1 + 4) = fVar8;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800ff446
// Address: 0x1800ff446
// Size: 276 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

int64_t fcn.1800ff2b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    bool bVar2;
    bool bVar3;
    int64_t iVar4;
    uint32_t uVar5;
    float *pfVar6;
    int64_t arg2_00;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar11 = *(float *)(arg2 + 0x90) + *(float *)(arg2 + 0x90);
    fVar13 = *(float *)(arg2 + 0x94) + *(float *)(arg2 + 0x94);
    fVar15 = (*(float *)(arg2 + 0xb4) + *(float *)(arg2 + 0xac)) - *(float *)(arg2 + 0x100);
    fVar14 = (*(float *)(arg2 + 0xb0) + *(float *)(arg2 + 0xa8)) - *(float *)(arg2 + 0xfc);
    if ((arg4 & 1U) == 0) {
        fVar7 = *(float *)(arg2 + 0x68);
    } else {
        fVar7 = fVar11 + *(float *)arg3 + fVar14;
    }
    if ((arg4 & 2U) == 0) {
        fVar8 = *(float *)(arg2 + 0x6c);
    } else {
        fVar8 = fVar13 + *(float *)(arg3 + 4) + fVar15;
    }
    fVar9 = 3.402823e+38;
    fVar12 = 3.402823e+38;
    if ((*(uint32_t *)(arg2 + 0x14) & 0x5000000) != 0x1000000) {
        if (*(char *)(arg2 + 0x108) == '\0') {
            fVar9 = *(float *)(**(int64_t **)(*(int64_t *)0x180781f28 + 0x2158) + 0x28) -
                    (*(float *)(*(int64_t *)0x180781f28 + 0xeb0) + *(float *)(*(int64_t *)0x180781f28 + 0xeb0));
            fVar12 = *(float *)(**(int64_t **)(*(int64_t *)0x180781f28 + 0x2158) + 0x2c) -
                     (*(float *)(*(int64_t *)0x180781f28 + 0xeb4) + *(float *)(*(int64_t *)0x180781f28 + 0xeb4));
        }
        iVar1 = *(int32_t *)(arg2 + 0x5c);
        if ((-1 < iVar1) && (iVar1 < *(int32_t *)(*(int64_t *)0x180781f28 + 0xd60))) {
            fVar9 = *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0xd68) + 0x18 + (int64_t)iVar1 * 0x30) -
                    (*(float *)(*(int64_t *)0x180781f28 + 0xeb0) + *(float *)(*(int64_t *)0x180781f28 + 0xeb0));
            fVar12 = *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0xd68) + 0x1c + (int64_t)iVar1 * 0x30) -
                     (*(float *)(*(int64_t *)0x180781f28 + 0xeb4) + *(float *)(*(int64_t *)0x180781f28 + 0xeb4));
        }
    }
    if ((*(uint32_t *)(arg2 + 0x14) >> 0x19 & 1) == 0) {
        arg2_00 = arg2;
        func_0x0001800fef40(&var_10h);
        if (fVar12 <= var_10h._4_4_) {
            var_10h._4_4_ = fVar12;
        }
        if (fVar9 <= (float)var_10h) {
            var_10h._0_4_ = fVar9;
        }
        fVar10 = var_10h._4_4_;
        if ((var_10h._4_4_ <= fVar8) && (fVar10 = fVar12, fVar8 <= fVar12)) {
            fVar10 = fVar8;
        }
        fVar8 = (float)var_10h;
        if (((float)var_10h <= fVar7) && (fVar8 = fVar9, fVar7 <= fVar9)) {
            fVar8 = fVar7;
        }
        var_10h._0_4_ = fVar8;
        var_10h._4_4_ = fVar10;
        fcn.1800ff010((int64_t)&var_b8h, arg2_00, (int64_t)&var_10h);
        pfVar6 = (float *)arg3;
        if ((arg4 & 1U) == 0) {
            pfVar6 = (float *)(arg2 + 0x78);
        }
        if ((arg4 & 2U) == 0) {
            fVar7 = *(float *)(arg2 + 0x7c);
        } else {
            fVar7 = *(float *)(arg3 + 4);
        }
        if (((((float)var_b8h < fVar11 + *pfVar6 + fVar14) && (uVar5 = *(uint32_t *)(arg2 + 0x14), (uVar5 & 8) == 0)) &&
            ((uVar5 >> 0xb & 1) != 0)) || (uVar5 = *(uint32_t *)(arg2 + 0x14), (uVar5 >> 0xf & 1) != 0)) {
            bVar2 = true;
        } else {
            bVar2 = false;
        }
        if (((var_b8h._4_4_ < fVar13 + fVar7 + fVar15) && ((uVar5 & 8) == 0)) || ((uVar5 >> 0xe & 1) != 0)) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (bVar2) {
            fVar10 = fVar10 + *(float *)(iVar4 + 0xe14);
        }
        if (bVar3) {
            fVar8 = fVar8 + *(float *)(iVar4 + 0xe14);
        }
        *(uint64_t *)arg1 = CONCAT44(fVar10, fVar8);
    } else {
        if (fVar9 <= fVar7) {
            fVar7 = fVar9;
        }
        if (fVar12 <= fVar8) {
            fVar8 = fVar12;
        }
        *(float *)arg1 = fVar7;
        *(float *)(arg1 + 4) = fVar8;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800ff55a
// Address: 0x1800ff55a
// Size: 49 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

int64_t fcn.1800ff2b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    bool bVar2;
    bool bVar3;
    int64_t iVar4;
    uint32_t uVar5;
    float *pfVar6;
    int64_t arg2_00;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    iVar4 = *(int64_t *)0x180781f28;
    fVar11 = *(float *)(arg2 + 0x90) + *(float *)(arg2 + 0x90);
    fVar13 = *(float *)(arg2 + 0x94) + *(float *)(arg2 + 0x94);
    fVar15 = (*(float *)(arg2 + 0xb4) + *(float *)(arg2 + 0xac)) - *(float *)(arg2 + 0x100);
    fVar14 = (*(float *)(arg2 + 0xb0) + *(float *)(arg2 + 0xa8)) - *(float *)(arg2 + 0xfc);
    if ((arg4 & 1U) == 0) {
        fVar7 = *(float *)(arg2 + 0x68);
    } else {
        fVar7 = fVar11 + *(float *)arg3 + fVar14;
    }
    if ((arg4 & 2U) == 0) {
        fVar8 = *(float *)(arg2 + 0x6c);
    } else {
        fVar8 = fVar13 + *(float *)(arg3 + 4) + fVar15;
    }
    fVar9 = 3.402823e+38;
    fVar12 = 3.402823e+38;
    if ((*(uint32_t *)(arg2 + 0x14) & 0x5000000) != 0x1000000) {
        if (*(char *)(arg2 + 0x108) == '\0') {
            fVar9 = *(float *)(**(int64_t **)(*(int64_t *)0x180781f28 + 0x2158) + 0x28) -
                    (*(float *)(*(int64_t *)0x180781f28 + 0xeb0) + *(float *)(*(int64_t *)0x180781f28 + 0xeb0));
            fVar12 = *(float *)(**(int64_t **)(*(int64_t *)0x180781f28 + 0x2158) + 0x2c) -
                     (*(float *)(*(int64_t *)0x180781f28 + 0xeb4) + *(float *)(*(int64_t *)0x180781f28 + 0xeb4));
        }
        iVar1 = *(int32_t *)(arg2 + 0x5c);
        if ((-1 < iVar1) && (iVar1 < *(int32_t *)(*(int64_t *)0x180781f28 + 0xd60))) {
            fVar9 = *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0xd68) + 0x18 + (int64_t)iVar1 * 0x30) -
                    (*(float *)(*(int64_t *)0x180781f28 + 0xeb0) + *(float *)(*(int64_t *)0x180781f28 + 0xeb0));
            fVar12 = *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0xd68) + 0x1c + (int64_t)iVar1 * 0x30) -
                     (*(float *)(*(int64_t *)0x180781f28 + 0xeb4) + *(float *)(*(int64_t *)0x180781f28 + 0xeb4));
        }
    }
    if ((*(uint32_t *)(arg2 + 0x14) >> 0x19 & 1) == 0) {
        arg2_00 = arg2;
        func_0x0001800fef40(&var_10h);
        if (fVar12 <= var_10h._4_4_) {
            var_10h._4_4_ = fVar12;
        }
        if (fVar9 <= (float)var_10h) {
            var_10h._0_4_ = fVar9;
        }
        fVar10 = var_10h._4_4_;
        if ((var_10h._4_4_ <= fVar8) && (fVar10 = fVar12, fVar8 <= fVar12)) {
            fVar10 = fVar8;
        }
        fVar8 = (float)var_10h;
        if (((float)var_10h <= fVar7) && (fVar8 = fVar9, fVar7 <= fVar9)) {
            fVar8 = fVar7;
        }
        var_10h._0_4_ = fVar8;
        var_10h._4_4_ = fVar10;
        fcn.1800ff010((int64_t)&var_b8h, arg2_00, (int64_t)&var_10h);
        pfVar6 = (float *)arg3;
        if ((arg4 & 1U) == 0) {
            pfVar6 = (float *)(arg2 + 0x78);
        }
        if ((arg4 & 2U) == 0) {
            fVar7 = *(float *)(arg2 + 0x7c);
        } else {
            fVar7 = *(float *)(arg3 + 4);
        }
        if (((((float)var_b8h < fVar11 + *pfVar6 + fVar14) && (uVar5 = *(uint32_t *)(arg2 + 0x14), (uVar5 & 8) == 0)) &&
            ((uVar5 >> 0xb & 1) != 0)) || (uVar5 = *(uint32_t *)(arg2 + 0x14), (uVar5 >> 0xf & 1) != 0)) {
            bVar2 = true;
        } else {
            bVar2 = false;
        }
        if (((var_b8h._4_4_ < fVar13 + fVar7 + fVar15) && ((uVar5 & 8) == 0)) || ((uVar5 >> 0xe & 1) != 0)) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (bVar2) {
            fVar10 = fVar10 + *(float *)(iVar4 + 0xe14);
        }
        if (bVar3) {
            fVar8 = fVar8 + *(float *)(iVar4 + 0xe14);
        }
        *(uint64_t *)arg1 = CONCAT44(fVar10, fVar8);
    } else {
        if (fVar9 <= fVar7) {
            fVar7 = fVar9;
        }
        if (fVar12 <= fVar8) {
            fVar8 = fVar12;
        }
        *(float *)arg1 = fVar7;
        *(float *)(arg1 + 4) = fVar8;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800ff590
// Address: 0x1800ff590
// Size: 475 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.1800ff590(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    uint32_t uVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    fVar6 = *(float *)(arg2 + 4);
    fVar7 = *(float *)arg2;
    fVar4 = fVar6;
    fVar3 = fVar7;
    if ((*(uint32_t *)(arg1 + 0x14) & 0x1000000) != 0) {
        iVar1 = *(int64_t *)(arg1 + 0x408);
        fVar8 = *(float *)(iVar1 + 0x9c);
        uVar2 = *(uint32_t *)(iVar1 + 0x14) & 8;
        fVar9 = *(float *)(iVar1 + 0x90);
        if (*(float *)(iVar1 + 0x90) <= fVar8) {
            fVar9 = fVar8;
        }
        fVar5 = *(float *)(iVar1 + 0x94);
        if (*(float *)(iVar1 + 0x94) <= fVar8) {
            fVar5 = fVar8;
        }
        if (((*(uint32_t *)(iVar1 + 0x14) & 0x8800) == 0) || (uVar2 != 0)) {
            fVar3 = *(float *)(iVar1 + 0x278) - (float)((uint32_t)fVar9 ^ 0x80000000);
            if ((fVar3 <= fVar7) &&
               (fVar3 = (float)((uint32_t)fVar9 ^ 0x80000000) + *(float *)(iVar1 + 0x280), fVar7 <= fVar3)) {
                fVar3 = fVar7;
            }
            if (uVar2 != 0) {
                fVar4 = *(float *)(iVar1 + 0x27c) - (float)((uint32_t)fVar5 ^ 0x80000000);
                if ((fVar4 <= fVar6) &&
                   (fVar4 = (float)((uint32_t)fVar5 ^ 0x80000000) + *(float *)(iVar1 + 0x284), fVar6 <= fVar4)) {
                    fVar4 = fVar6;
                }
            }
        }
    }
    fVar6 = *(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68);
    fVar7 = *(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c);
    fVar9 = (*(float *)(arg1 + 0x60) - fVar3) * *(float *)arg3 + fVar3;
    fVar8 = (*(float *)(arg1 + 100) - fVar4) * *(float *)(arg3 + 4) + fVar4;
    fVar3 = ((fVar3 - fVar6) * *(float *)arg3 + fVar6) - fVar9;
    fVar6 = ((fVar4 - fVar7) * *(float *)(arg3 + 4) + fVar7) - fVar8;
    var_10h._0_4_ = fVar3;
    var_10h._4_4_ = fVar6;
    fcn.1800ff010((int64_t)&var_8h, arg1, (int64_t)&var_10h);
    *(float *)arg4 = fVar9;
    *(float *)(arg4 + 4) = fVar8;
    if (*(float *)arg3 == 0.0) {
        *(float *)arg4 = fVar9 - ((float)var_8h - fVar3);
    }
    if (*(float *)(arg3 + 4) == 0.0) {
        *(float *)(arg4 + 4) = fVar8 - (var_8h._4_4_ - fVar6);
    }
    *(uint64_t *)arg_28h = CONCAT44(var_8h._4_4_, (float)var_8h);
    return;
}

// ============================================================
// Function: FUN_1800ff770
// Address: 0x1800ff770
// Size: 313 bytes
// ============================================================
int64_t fcn.1800ff770(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    float fVar4;
    float fVar5;
    float in_XMM3_Da;
    int64_t var_18h;
    
    iVar3 = (int32_t)arg3;
    fVar1 = *(float *)(arg2 + 0x60);
    fVar2 = *(float *)(arg2 + 100);
    fVar5 = fVar1 + *(float *)(arg2 + 0x68);
    fVar4 = fVar2 + *(float *)(arg2 + 0x6c);
    if ((float)arg_28h == 0.0) {
        fVar4 = fVar4 - 1.0;
        fVar5 = fVar5 - 1.0;
    }
    if (iVar3 == 0) {
        *(float *)(arg1 + 4) = fVar2 + in_XMM3_Da;
        *(float *)arg1 = fVar1 - (float)arg_28h;
        *(float *)(arg1 + 8) = fVar1 + (float)arg_28h;
        *(float *)(arg1 + 0xc) = fVar4 - in_XMM3_Da;
        return arg1;
    }
    if (iVar3 == 1) {
        *(float *)(arg1 + 4) = fVar2 + in_XMM3_Da;
        *(float *)arg1 = fVar5 - (float)arg_28h;
        *(float *)(arg1 + 8) = fVar5 + (float)arg_28h;
        *(float *)(arg1 + 0xc) = fVar4 - in_XMM3_Da;
        return arg1;
    }
    if (iVar3 != 2) {
        if (iVar3 != 3) {
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            return arg1;
        }
        *(float *)arg1 = fVar1 + in_XMM3_Da;
        *(float *)(arg1 + 4) = fVar4 - (float)arg_28h;
        *(float *)(arg1 + 8) = fVar5 - in_XMM3_Da;
        *(float *)(arg1 + 0xc) = fVar4 + (float)arg_28h;
        return arg1;
    }
    *(float *)arg1 = fVar1 + in_XMM3_Da;
    *(float *)(arg1 + 4) = fVar2 - (float)arg_28h;
    *(float *)(arg1 + 8) = fVar5 - in_XMM3_Da;
    *(float *)(arg1 + 0xc) = fVar2 + (float)arg_28h;
    return arg1;
}

// ============================================================
// Function: FUN_1800ff8b0
// Address: 0x1800ff8b0
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_165h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ch
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_167h
// WARNING: [rz-ghidra] Detected overlap for variable var_166h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint32_t fcn.1800ff8b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    float fVar6;
    undefined4 uVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    uint32_t *puVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    undefined8 placeholder_3;
    int64_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint32_t uVar18;
    float *arg3_00;
    bool bVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_178h;
    char var_168h;
    char var_167h;
    char var_166h;
    char var_165h;
    int64_t var_160h;
    int64_t var_158h;
    float var_150h;
    int64_t var_14ch;
    float var_144h;
    float var_140h;
    float var_13ch;
    uint32_t var_138h;
    uint32_t var_134h;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h [4];
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    undefined4 uStack_e8;
    int64_t var_e4h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    uVar18 = *(uint32_t *)(arg1 + 0x14);
    if (((((uVar18 & 2) != 0) || ('\0' < *(char *)(arg1 + 0x128))) || ('\0' < *(char *)(arg1 + 0x129))) ||
       ((((uVar18 & 0x40) != 0 && ((*(uint8_t *)(arg1 + 0x1c) & 0xc) == 0)) || (*(char *)(arg1 + 0x10a) == '\0')))) {
        return 0;
    }
    var_14ch._0_4_ = 0;
    iVar16 = (int32_t)arg4;
    if (iVar16 < 1) {
        fVar21 = 0.0;
    } else {
        fVar21 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 1.35;
        fVar20 = *(float *)(arg1 + 0x98) + 1.0 + *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 0.2;
        if (fVar21 <= fVar20) {
            fVar21 = fVar20;
        }
        fVar21 = (float)(int32_t)((float)(int32_t)fVar21 * 0.75);
    }
    fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x15d4);
    fVar29 = *(float *)arg_30h;
    fVar25 = *(float *)(arg_30h + 0xc);
    fVar30 = *(float *)(arg_30h + 4);
    var_160h = CONCAT44(var_160h._4_4_, *(undefined4 *)(arg_30h + 8));
    if (((*(uint8_t *)(arg1 + 0x130) & 1) == 0) && ((uVar18 & 1) == 0)) {
        fVar30 = fVar30 - *(float *)(arg1 + 0xa0);
        var_165h = '\x01';
    } else {
        var_165h = '\0';
    }
    var_128h._0_4_ = 3.402823e+38;
    var_128h._4_4_ = 3.402823e+38;
    stack0xfffffffffffffeb8 = 0x7f7fffff7f7fffff;
    if ((((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x34) & 0x1000) == 0) ||
        (*(int32_t *)(*(int64_t *)0x180781f28 + 0x134) != *(int32_t *)(arg1 + 0x50))) ||
       ((*(uint8_t *)(*(int64_t *)(arg1 + 0x48) + 4) & 8) == 0)) {
        iVar15 = *(int64_t *)(arg1 + 0x48);
        fVar28 = *(float *)(iVar15 + 8);
        fVar22 = *(float *)(iVar15 + 0xc);
        fVar26 = *(float *)(iVar15 + 0x10);
        fVar23 = *(float *)(iVar15 + 0x14);
        *(float *)(arg1 + 0x2b8) = fVar28;
        *(float *)(arg1 + 700) = fVar22;
        *(float *)(arg1 + 0x2c0) = fVar28 + fVar26;
        *(float *)(arg1 + 0x2c4) = fVar22 + fVar23;
    }
    *(undefined4 *)(arg1 + 0x1b0) = 1;
    var_8h._0_4_ = fVar30;
    var_10h = arg2;
    var_18h = arg3;
    var_158h._0_4_ = fVar21;
    var_158h._4_4_ = fVar25;
    var_150h = fVar29;
    func_0x000180107590();
    uVar18 = 0;
    if (0 < iVar16) {
        iVar15 = 0;
        do {
            fVar29 = *(float *)(arg1 + 0x60);
            fVar25 = *(float *)(arg1 + 100);
            iVar9 = iVar15 * 0x18;
            fVar28 = *(float *)(iVar15 * 0x18 + 0x1806185cc);
            fVar22 = *(float *)(iVar15 * 0x18 + 0x1806185c8);
            arg3_00 = (float *)(iVar9 + 0x1806185c0);
            fVar29 = ((fVar29 + *(float *)(arg1 + 0x68)) - fVar29) * *arg3_00 + fVar29;
            var_110h._0_4_ = fVar21 * fVar22 + fVar29;
            fVar25 = ((fVar25 + *(float *)(arg1 + 0x6c)) - fVar25) * *(float *)(iVar15 * 0x18 + 0x1806185c4) + fVar25;
            fVar29 = fVar29 - fVar20 * fVar22;
            var_110h._4_4_ = fVar28 * (float)var_158h + fVar25;
            fVar25 = fVar25 - fVar28 * fVar20;
            var_120h[2] = fVar29;
            var_120h[3] = fVar25;
            if ((float)var_110h < fVar29) {
                var_120h[2] = (float)var_110h;
                var_110h._0_4_ = fVar29;
            }
            if (var_110h._4_4_ < fVar25) {
                var_120h[3] = var_110h._4_4_;
                var_110h._4_4_ = fVar25;
            }
            puVar11 = &var_138h;
            var_138h = uVar18;
            uVar14 = ~*(uint32_t *)(*(int64_t *)(arg1 + 0x150) + -4 + (int64_t)*(int32_t *)(arg1 + 0x148) * 4);
            do {
                uVar1 = *(uint8_t *)puVar11;
                puVar11 = (uint32_t *)((int64_t)puVar11 + 1);
                uVar14 = uVar14 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar14 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
            } while (puVar11 < &var_134h);
            func_0x00018010b530(var_120h + 2, ~uVar14, 0, 2);
            var_178h = CONCAT44(var_178h._4_4_, 0x40800);
            func_0x000180139d40(var_120h + 2, ~uVar14, &var_166h, &var_167h, var_178h);
            if ((var_166h == '\0') && (var_167h == '\0')) {
code_r0x0001800ffe50:
                if ((uVar18 == 0) && ((*(uint32_t *)(arg1 + 0x14) & 0x1000000) == 0)) goto code_r0x0001800ffe5e;
            } else {
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (~uVar18 & 1) + 5;
                if (var_167h == '\0') {
code_r0x0001800ffe47:
                    if (var_166h == '\0') goto code_r0x0001800ffe50;
                } else {
                    if (*(char *)(iVar5 + 0xb55) == '\0') {
                        fVar21 = *(float *)(iVar9 + 0x1806185c4);
                        if ((fVar21 != 1.0) && ((fVar21 != 0.0 || (var_165h == '\0')))) {
                            fVar30 = -3.402823e+38;
                        }
                        fVar29 = *arg3_00;
                        var_120h[0] = var_150h;
                        if (fVar29 != 1.0) {
                            var_120h[0] = -3.402823e+38;
                        }
                        fVar25 = var_158h._4_4_;
                        if (fVar21 != 0.0) {
                            fVar25 = 3.402823e+38;
                        }
                        fVar28 = 3.402823e+38;
                        if (fVar29 == 0.0) {
                            fVar28 = (float)var_160h;
                        }
                        fVar26 = *(float *)(iVar9 + 0x1806185cc) * fVar20;
                        fVar22 = *(float *)(iVar9 + 0x1806185c8) * fVar20;
                        fVar21 = (*(float *)(iVar5 + 0x11c) - *(float *)(iVar5 + 0x1670)) +
                                 ((float)((uint32_t)(float)var_158h ^ 0x80000000) * *(float *)(iVar9 + 0x1806185cc) -
                                 fVar26) * fVar21 + fVar26;
                        fVar29 = (*(float *)(iVar5 + 0x118) - *(float *)(iVar5 + 0x166c)) +
                                 ((float)((uint32_t)(float)var_158h ^ 0x80000000) * *(float *)(iVar9 + 0x1806185c8) -
                                 fVar22) * fVar29 + fVar22;
                        var_120h[1] = fVar30;
                        if ((fVar30 <= fVar21) && (var_120h[1] = fVar25, fVar21 <= fVar25)) {
                            var_120h[1] = fVar21;
                        }
                        if ((var_120h[0] <= fVar29) && (var_120h[0] = fVar28, fVar29 <= fVar28)) {
                            var_120h[0] = fVar29;
                        }
                        var_178h = (int64_t)&var_14ch + 4;
                        fcn.1800ff590(arg1, (int64_t)var_120h, (int64_t)arg3_00, (int64_t)&var_128h, var_178h);
                        fVar30 = (float)var_8h;
                    } else {
                        fcn.1800ff2b0((int64_t)&var_140h, arg1, arg1 + 0x80, 0xffffffff);
                        puVar8 = (undefined8 *)fcn.1800ff010((int64_t)&var_f8h, arg1, (int64_t)&var_140h);
                        var_14ch._0_4_ = 3;
                        unique0x00005500 = *puVar8;
                        func_0x0001800f9f30(0, 0);
                    }
                    if (var_167h == '\0') goto code_r0x0001800ffe47;
                }
code_r0x0001800ffe5e:
                if (var_167h == '\0') {
                    iVar9 = (uint64_t)(var_166h != '\0') + 0x1e;
                } else {
                    iVar9 = 0x20;
                }
                puVar10 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar9 + 0x14) * 0x10);
                var_108h._0_4_ = *puVar10;
                var_108h._4_4_ = puVar10[1];
                var_100h._0_4_ = puVar10[2];
                var_100h._4_4_ = (float)puVar10[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar7 = func_0x0001800f5fa0(&var_108h);
                *(undefined4 *)(arg_28h + iVar15 * 4) = uVar7;
            }
            uVar18 = uVar18 + 1;
            iVar15 = iVar15 + 1;
            arg3 = var_18h;
            fVar29 = var_150h;
            fVar25 = var_158h._4_4_;
            fVar21 = (float)var_158h;
        } while ((int32_t)uVar18 < iVar16);
    }
    if ((*(uint32_t *)(arg1 + 0x14) & 0x1000000) == 0) {
        uVar18 = -(uint32_t)(*(char *)(iVar5 + 0x92) != '\0') & 0xf;
    } else {
        uVar18 = *(uint32_t *)(arg1 + 0x1c) >> 1 & 2 | *(uint32_t *)(arg1 + 0x1c) & 8;
    }
    fVar21 = (float)var_160h;
    uVar14 = 0;
    var_150h = 1.401298e-45;
    var_158h._4_4_ = (float)uVar18;
    do {
        iVar15 = 0x180000000;
        if ((uVar18 & (uint32_t)var_150h) != 0) {
            if (uVar14 < 2) {
                var_160h = (uint64_t)(uint32_t)var_160h._4_4_ << 0x20;
                iVar9 = 1;
                uVar7 = 4;
                iVar17 = 0;
            } else {
                var_160h = CONCAT44(var_160h._4_4_, 1);
                iVar9 = 2;
                uVar7 = 3;
                iVar17 = 4;
            }
            var_178h = CONCAT44(var_178h._4_4_, *(undefined4 *)(iVar5 + 0x15d4));
            fcn.1800ff770((int64_t)&var_108h, arg1, (uint64_t)uVar14, 0x180000000, var_178h);
            var_130h._0_4_ = uVar14 + 4;
            piVar12 = &var_130h;
            uVar18 = ~*(uint32_t *)(*(int64_t *)(arg1 + 0x150) + -4 + (int64_t)*(int32_t *)(arg1 + 0x148) * 4);
            do {
                uVar1 = *(uint8_t *)piVar12;
                piVar12 = (int64_t *)((int64_t)piVar12 + 1);
                uVar18 = uVar18 >> 8 ^
                         *(uint32_t *)(iVar15 + 0x618620 + ((uint64_t)(uVar18 & 0xff) ^ (uint64_t)uVar1) * 4);
            } while (piVar12 < (int64_t *)((int64_t)&var_130h + 4U));
            func_0x00018010b530(&var_108h, ~uVar18, 0, 2);
            var_178h = CONCAT44(var_178h._4_4_, 0x40800);
            func_0x000180139d40(&var_108h, ~uVar18, &var_8h, &var_168h, var_178h);
            if ((char)var_8h == '\0') {
code_r0x00018010002f:
                if (var_168h != '\0') goto code_r0x00018010003a;
            } else {
                if (*(float *)(iVar5 + 0x1648) <= 0.04) {
                    var_8h._0_4_ = (float)((uint32_t)(float)var_8h & 0xffffff00);
                    goto code_r0x00018010002f;
                }
code_r0x00018010003a:
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = uVar7;
                if (var_168h != '\0') {
                    if (*(char *)(iVar5 + 0xb55) == '\0') {
                        iVar15 = *(int64_t *)(iVar5 + 0x1608);
                        iVar9 = (uint64_t)uVar14 * 0x1c;
                        if ((iVar15 == 0) || (iVar17 = arg1, *(int32_t *)(iVar5 + 0x161c) != *(int32_t *)(iVar5 + 4))) {
code_r0x00018010011c:
                            bVar19 = false;
                        } else {
                            do {
                                iVar2 = *(int64_t *)(*(int64_t *)(iVar17 + 0x418) + 0x428);
                                bVar19 = iVar17 != iVar2;
                                iVar17 = iVar2;
                            } while (bVar19);
                            iVar17 = arg1;
                            if (iVar2 != iVar15) {
                                do {
                                    if (iVar17 == iVar15) goto code_r0x000180100247;
                                } while ((iVar17 != iVar2) &&
                                        (piVar12 = (int64_t *)(iVar17 + 0x408), iVar17 = *piVar12, *piVar12 != 0));
                                goto code_r0x00018010011c;
                            }
code_r0x000180100247:
                            bVar19 = true;
                        }
                        if ((*(char *)(iVar5 + 0x1660) != '\0') || (bVar19)) {
                            *(undefined *)(iVar5 + 0x27fc) = 0;
                            *(undefined4 *)(iVar5 + 0x27ec) = (undefined4)var_108h;
                            *(undefined4 *)(iVar5 + 0x27f0) = var_108h._4_4_;
                            *(undefined4 *)(iVar5 + 0x27f4) = (undefined4)var_100h;
                            *(float *)(iVar5 + 0x27f8) = var_100h._4_4_;
                        }
                        if (((*(uint32_t *)(arg1 + 0x14) & 0x1000000) != 0) &&
                           ((*(int64_t *)(iVar5 + 0x27ec) != CONCAT44(var_108h._4_4_, (undefined4)var_108h) ||
                            (*(int64_t *)(iVar5 + 0x27f4) != CONCAT44(var_100h._4_4_, (undefined4)var_100h))))) {
                            *(undefined *)(iVar5 + 0x27fc) = 1;
                        }
                        uVar13 = var_160h & 0xffffffff;
                        fVar20 = *(float *)(iVar9 + 0x180618478);
                        if (*(float *)(iVar9 + 0x180618480) <= *(float *)(iVar9 + 0x180618478)) {
                            fVar20 = *(float *)(iVar9 + 0x180618480);
                        }
                        fVar28 = *(float *)(iVar9 + 0x18061847c);
                        if (*(float *)(iVar9 + 0x180618484) <= *(float *)(iVar9 + 0x18061847c)) {
                            fVar28 = *(float *)(iVar9 + 0x180618484);
                        }
                        fVar22 = *(float *)(arg1 + 0x6c);
                        fVar23 = (*(float *)(iVar5 + 0x118 + uVar13 * 4) - *(float *)(iVar5 + 0x166c + uVar13 * 4)) +
                                 *(float *)(iVar5 + 0x15d4);
                        fVar26 = *(float *)(arg1 + 100);
                        var_120h[0] = fVar20 * *(float *)(arg1 + 0x68) + *(float *)(arg1 + 0x60);
                        var_160h = *(int64_t *)(arg1 + 0x60);
                        *(float *)((int64_t)&var_160h + uVar13 * 4) = fVar23;
                        bVar19 = false;
                        var_120h[1] = fVar28 * fVar22 + fVar26;
                        if (*(char *)(iVar5 + 0x27fc) != '\0') {
                            fVar22 = *(float *)(iVar5 + 0x104 + uVar13 * 4);
                            fVar26 = var_120h[uVar13];
                            *(float *)((int64_t)&var_160h + uVar13 * 4) = fVar22 + fVar26;
                            if ((fVar22 == 0.0) || (0.0 < fVar22 == fVar23 < fVar22 + fVar26)) {
                                bVar19 = true;
                            }
                        }
                        fVar22 = fVar30;
                        if ((uVar14 != 3) && ((uVar14 != 2 || (var_165h == '\0')))) {
                            fVar22 = -3.402823e+38;
                        }
                        if (uVar14 == 1) {
                            fVar26 = fVar29;
                            fVar6 = 3.402823e+38;
code_r0x000180100264:
                            fVar24 = fVar6;
                            fVar27 = 3.402823e+38;
                            fVar23 = fVar26;
                        } else {
                            fVar23 = -3.402823e+38;
                            fVar26 = -3.402823e+38;
                            fVar6 = fVar25;
                            if (uVar14 == 2) goto code_r0x000180100264;
                            fVar24 = 3.402823e+38;
                            fVar27 = fVar21;
                            fVar6 = 3.402823e+38;
                            if (uVar14 != 0) goto code_r0x000180100264;
                        }
                        if ((fVar22 <= var_160h._4_4_) && (fVar22 = fVar24, var_160h._4_4_ <= fVar24)) {
                            fVar22 = var_160h._4_4_;
                        }
                        if ((fVar23 <= (float)var_160h) && (fVar23 = fVar27, (float)var_160h <= fVar27)) {
                            fVar23 = (float)var_160h;
                        }
                        var_160h = CONCAT44(fVar22, fVar23);
                        if (!bVar19) {
                            var_178h = (int64_t)&var_14ch + 4;
                            var_140h = fVar20;
                            var_13ch = fVar28;
                            fcn.1800ff590(arg1, (int64_t)&var_160h, (int64_t)&var_140h, (int64_t)&var_128h, var_178h);
                        }
                    } else {
                        if ((uVar14 - 1 & 0xfffffffd) == 0) {
                            fcn.1800ff2b0((int64_t)&var_f8h, arg1, arg1 + 0x80, iVar9);
                            iVar15 = fcn.1800ff010((int64_t)&var_f0h, arg1, (int64_t)&var_f8h);
                            *(undefined4 *)((int64_t)&var_14ch + (var_160h & 0xffffffffU) * 4 + 4) =
                                 *(undefined4 *)(iVar15 + iVar17);
                            var_14ch._0_4_ = (uint32_t)var_14ch | 1 << ((uint32_t)(float)var_160h & 0x1f);
                            var_168h = '\0';
                            var_8h._0_4_ = (float)((uint32_t)(float)var_8h & 0xffffff00);
                        }
                        func_0x0001800f9f30(0, 0);
                    }
                }
            }
            if ((char)var_8h != '\0') {
                *(uint32_t *)var_10h = uVar14;
            }
            arg3 = var_18h;
            uVar18 = (uint32_t)var_158h._4_4_;
            if (var_168h != '\0') {
                *(uint32_t *)var_18h = uVar14;
            }
        }
        var_150h = (float)((int32_t)var_150h << 1 | (uint32_t)((int32_t)var_150h < 0));
        placeholder_3 = 0x180000000;
        uVar14 = uVar14 + 1;
    } while ((int32_t)uVar14 < 4);
    iVar16 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar16 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar16 + -1;
    }
    *(undefined4 *)(arg1 + 0x1b0) = 0;
    iVar15 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(iVar5 + 0x23c0) != 0) && (*(int64_t *)(*(int64_t *)(iVar5 + 0x23c0) + 0x428) == arg1)) {
        if (*(int32_t *)(iVar5 + 0x2228) == 2) {
            if (*(char *)(iVar5 + 0x139) == '\0') goto code_r0x00018010059a;
            fVar21 = *(float *)(*(int64_t *)0x180781f28 + 0x16c) - *(float *)(*(int64_t *)0x180781f28 + 0x15c);
            fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x18c) - *(float *)(*(int64_t *)0x180781f28 + 0x17c);
        } else {
            if (*(int32_t *)(iVar5 + 0x2228) != 3) goto code_r0x00018010059a;
            fVar21 = *(float *)(*(int64_t *)0x180781f28 + 0x93c) - *(float *)(*(int64_t *)0x180781f28 + 0x92c);
            fVar20 = *(float *)(*(int64_t *)0x180781f28 + 0x95c) - *(float *)(*(int64_t *)0x180781f28 + 0x94c);
        }
        if ((fVar21 != 0.0) || (fVar20 != 0.0)) {
            fVar25 = *(float *)(iVar5 + 0x48) * 600.0 * *(float *)(*(int64_t *)0x180781f28 + 0x12c4);
            fVar20 = fVar25 * fVar20 + *(float *)(iVar5 + 0x23f8);
            fVar21 = fVar25 * fVar21 + *(float *)(iVar5 + 0x23f4);
            *(float *)(iVar5 + 0x23f8) = fVar20;
            *(float *)(iVar5 + 0x23f4) = fVar21;
            fVar25 = (fVar30 - *(float *)(arg1 + 100)) - *(float *)(arg1 + 0x6c);
            fVar29 = (fVar29 - *(float *)(arg1 + 0x60)) - *(float *)(arg1 + 0x68);
            *(undefined *)(iVar5 + 0x23e4) = 0;
            *(undefined *)(iVar5 + 0x21cd) = 1;
            if (fVar20 <= fVar25) {
                fVar20 = fVar25;
            }
            if (fVar21 <= fVar29) {
                fVar21 = fVar29;
            }
            *(float *)(iVar5 + 0x23f8) = fVar20;
            *(float *)(iVar5 + 0x23f4) = fVar21;
            var_f0h._0_4_ = *(undefined4 *)(iVar15 + 0x10d0);
            var_f0h._4_4_ = *(undefined4 *)(iVar15 + 0x10d4);
            uStack_e8 = *(undefined4 *)(iVar15 + 0x10d8);
            var_e4h._0_4_ = *(float *)(iVar15 + 0x10dc) * *(float *)(iVar15 + 0xd9c);
            uVar7 = func_0x0001800f5fa0(&var_f0h);
            *(undefined4 *)arg_28h = uVar7;
            fVar20 = (float)(int32_t)*(float *)(iVar5 + 0x23f4);
            fVar21 = (float)(int32_t)*(float *)(iVar5 + 0x23f8);
            if ((fVar20 != 0.0) || (fVar21 != 0.0)) {
                var_140h = fVar20 + *(float *)(arg1 + 0x70);
                var_13ch = fVar21 + *(float *)(arg1 + 0x74);
                puVar8 = (undefined8 *)fcn.1800ff010((int64_t)&var_f0h, arg1, (int64_t)&var_140h);
                unique0x00005500 = *puVar8;
                *(float *)(iVar5 + 0x23f4) = *(float *)(iVar5 + 0x23f4) - fVar20;
                *(float *)(iVar5 + 0x23f8) = *(float *)(iVar5 + 0x23f8) - fVar21;
            }
        }
    }
code_r0x00018010059a:
    fVar21 = *(float *)(arg1 + 0x60);
    fVar20 = *(float *)(arg1 + 100);
    fVar29 = *(float *)(arg1 + 0x70);
    fVar25 = *(float *)(arg1 + 0x74);
    fVar30 = fVar29;
    if ((var_14ch._4_4_ != 3.402823e+38) && ((*(float *)(arg1 + 0x68) != var_14ch._4_4_ || (fVar29 != var_14ch._4_4_))))
    {
        *(float *)(arg1 + 0x70) = var_14ch._4_4_;
        *(float *)(arg1 + 0x68) = var_14ch._4_4_;
        fVar30 = var_14ch._4_4_;
    }
    if ((var_144h != 3.402823e+38) && ((*(float *)(arg1 + 0x6c) != var_144h || (*(float *)(arg1 + 0x74) != var_144h))))
    {
        *(float *)(arg1 + 0x74) = var_144h;
        *(float *)(arg1 + 0x6c) = var_144h;
    }
    if (((float)var_128h != 3.402823e+38) && (fVar21 != (float)(int32_t)(float)var_128h)) {
        *(float *)(arg1 + 0x60) = (float)(int32_t)(float)var_128h;
    }
    if ((var_128h._4_4_ != 3.402823e+38) && (*(float *)(arg1 + 100) != (float)(int32_t)var_128h._4_4_)) {
        *(float *)(arg1 + 100) = (float)(int32_t)var_128h._4_4_;
    }
    if (((((fVar21 != *(float *)(arg1 + 0x60)) || (fVar20 != *(float *)(arg1 + 100))) || (fVar29 != fVar30)) ||
        (fVar25 != *(float *)(arg1 + 0x74))) &&
       (((*(uint32_t *)(arg1 + 0x14) & 0x100) == 0 && (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)))) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
    }
    if (*(uint32_t *)arg3 != 0xffffffff) {
        var_178h = CONCAT44(var_178h._4_4_, *(undefined4 *)(iVar5 + 0x15d4));
        puVar10 = (undefined4 *)
                  fcn.1800ff770((int64_t)&var_108h, arg1, (uint64_t)*(uint32_t *)arg3, placeholder_3, var_178h);
        uVar7 = puVar10[1];
        uVar3 = puVar10[2];
        uVar4 = puVar10[3];
        *(undefined4 *)(iVar5 + 0x27ec) = *puVar10;
        *(undefined4 *)(iVar5 + 0x27f0) = uVar7;
        *(undefined4 *)(iVar5 + 0x27f4) = uVar3;
        *(undefined4 *)(iVar5 + 0x27f8) = uVar4;
    }
    return (uint32_t)var_14ch;
}

