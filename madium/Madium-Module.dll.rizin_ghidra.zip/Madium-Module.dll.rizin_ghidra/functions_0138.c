// Chunk 138 - 50 functions

// ============================================================
// Function: FUN_1801db860
// Address: 0x1801db860
// Size: 87 bytes
// ============================================================
bool fcn.1801db860(int64_t arg_28h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801db870;
    iVar3 = func_0x00018045a350();
    iVar2 = 1;
    if (*(int64_t *)(in_RCX + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801db88d;
        iVar2 = func_0x00018019e150();
    }
    iVar1 = *(int64_t *)(in_RCX + 0x20);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801db8a1;
        iVar2 = func_0x00018019e1a0(iVar1, in_RDX);
    }
    return 0 < iVar2;
}

// ============================================================
// Function: FUN_1801db8c0
// Address: 0x1801db8c0
// Size: 71 bytes
// ============================================================
void fcn.1801db8c0(int64_t param_1)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801db8ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(param_1 + 0x68) = 9;
    *(int64_t *)((int64_t)&var_20h + iVar1) = param_1;
    *(undefined8 *)(param_1 + 0x60) = 0x1804b4d20;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801db902;
    fcn.18024a850(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801db910
// Address: 0x1801db910
// Size: 26 bytes
// ============================================================
undefined8
fcn.1801db910(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 *puVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x18) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4) = 0x1801dcb9e;
    iVar5 = fcn.18045a350();
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        if (*(int64_t *)(in_RCX + 0x20) == 0) {
            return 0;
        }
        puVar6 = *(undefined4 **)(*(int64_t *)(in_RCX + 0x20) + 0x10);
    } else {
        puVar6 = *(undefined4 **)(*(int64_t *)(in_RCX + 0x18) + 8);
    }
    uVar1 = *puVar6;
    puVar9 = (undefined8 *)0x1804b4e00;
    uVar8 = 0;
    do {
        uVar2 = *puVar9;
        *(undefined8 *)((int64_t)auStackX_8 + -iVar5 + iVar4) = 0x1801dcbdc;
        iVar3 = func_0x000180498f10(uVar2, in_RDX);
        if (iVar3 == 0) {
            iVar3 = *(int32_t *)(uVar8 * 0x10 + 0x1804b4e08);
            if (iVar3 < 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)auStackX_8 + -iVar5 + iVar4) = 0x1801dcc1e;
            uVar7 = func_0x0001801afd20(uVar1, iVar3, uVar7);
            return uVar7;
        }
        uVar8 = uVar8 + 1;
        puVar9 = puVar9 + 2;
    } while (uVar8 < 8);
    return 0;
}

// ============================================================
// Function: FUN_1801db930
// Address: 0x1801db930
// Size: 26 bytes
// ============================================================
undefined8 fcn.1801db930(int64_t param_1, undefined8 param_2)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 *puVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = *(undefined8 *)(param_1 + 0x58);
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x18) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4) = 0x1801dcb9e;
    iVar5 = fcn.18045a350();
    if (*(int64_t *)(param_1 + 0x18) == 0) {
        if (*(int64_t *)(param_1 + 0x20) == 0) {
            return 0;
        }
        puVar6 = *(undefined4 **)(*(int64_t *)(param_1 + 0x20) + 0x10);
    } else {
        puVar6 = *(undefined4 **)(*(int64_t *)(param_1 + 0x18) + 8);
    }
    uVar1 = *puVar6;
    puVar9 = (undefined8 *)0x1804b4e00;
    uVar8 = 0;
    do {
        uVar2 = *puVar9;
        *(undefined8 *)((int64_t)auStackX_8 + -iVar5 + iVar4) = 0x1801dcbdc;
        iVar3 = func_0x000180498f10(uVar2, param_2);
        if (iVar3 == 0) {
            iVar3 = *(int32_t *)(uVar8 * 0x10 + 0x1804b4e08);
            if (iVar3 < 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)auStackX_8 + -iVar5 + iVar4) = 0x1801dcc1e;
            uVar7 = func_0x0001801afd20(uVar1, iVar3, uVar7);
            return uVar7;
        }
        uVar8 = uVar8 + 1;
        puVar9 = puVar9 + 2;
    } while (uVar8 < 8);
    return 0;
}

// ============================================================
// Function: FUN_1801db950
// Address: 0x1801db950
// Size: 86 bytes
// ============================================================
undefined8 fcn.1801db950(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801db95a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_2 == 0) {
        return 0xfffffffd;
    }
    *(undefined8 *)(param_1 + 0x68) = 0x1b;
    *(undefined8 *)(param_1 + 0x60) = 0x1804b4e80;
    *(int64_t *)((int64_t)&var_20h + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801db9a1;
    uVar2 = fcn.18024a850(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_1801db9b0
// Address: 0x1801db9b0
// Size: 86 bytes
// ============================================================
undefined8 fcn.1801db9b0(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801db9ba;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_2 == 0) {
        return 0xfffffffd;
    }
    *(undefined8 *)(param_1 + 0x68) = 6;
    *(undefined8 *)(param_1 + 0x60) = 0x1804b5110;
    *(int64_t *)((int64_t)&var_20h + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801dba01;
    uVar2 = fcn.18024a850(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                          *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_1801dba10
// Address: 0x1801dba10
// Size: 287 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1801dba10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t *piVar7;
    uint8_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dba30;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar7 = (int64_t *)0x0;
    iVar4 = 1;
    iVar8 = 0;
    if (*(int64_t *)(in_RCX + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dba50;
        iVar4 = func_0x000180198d30();
        piVar7 = *(int64_t **)(*(int64_t *)(in_RCX + 0x18) + 0x158);
    }
    piVar6 = *(int32_t **)(in_RCX + 0x20);
    iVar9 = iVar8;
    if (piVar6 != (int32_t *)0x0) {
        if (*piVar6 != 0) {
            if (-1 < (char)*piVar6) goto code_r0x0001801dbb0e;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dba78;
            piVar6 = (int32_t *)func_0x0001801bda50(piVar6);
            if (piVar6 == (int32_t *)0x0) goto code_r0x0001801dbb0e;
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dba8c;
        iVar4 = func_0x000180199910(uVar1, in_RDX);
        piVar7 = *(int64_t **)(piVar6 + 0x21e);
    }
    iVar9 = iVar4;
    if ((((0 < iVar4) && (piVar7 != (int64_t *)0x0)) && ((*in_RCX & 0x40) != 0)) &&
       (uVar3 = (*piVar7 - piVar7[4]) / 0x28, iVar9 = iVar8, uVar3 < *(uint64_t *)(in_RCX + 0x38))) {
        iVar2 = *(int64_t *)(in_RCX + 0x30);
        uVar1 = *(undefined8 *)(iVar2 + uVar3 * 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dbaee;
        func_0x000180224990(uVar1, 0x1804b62c8, 0x1d3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dbb03;
        iVar5 = func_0x0001802231e0(in_RDX, 0x1804b62c8, 0x1d4);
        *(int64_t *)(iVar2 + uVar3 * 8) = iVar5;
        iVar9 = iVar4;
        if (iVar5 == 0) {
            iVar9 = iVar8;
        }
    }
code_r0x0001801dbb0e:
    return 0 < iVar9;
}

// ============================================================
// Function: FUN_1801dbb30
// Address: 0x1801dbb30
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801dbb30(int64_t arg_28h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint8_t *in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dbb40;
    iVar3 = fcn.18045a350();
    iVar1 = -iVar3;
    iVar2 = 1;
    if ((*in_RCX & (uint8_t)iVar3) == 0) {
        return 0xfffffffe;
    }
    if (*(int64_t *)(in_RCX + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dbb76;
        iVar2 = fcn.180198a80(*(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1));
    }
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dbb92;
        iVar2 = fcn.1801995e0(*(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1));
    }
    return (uint64_t)(0 < iVar2);
}

// ============================================================
// Function: FUN_1801dbbb0
// Address: 0x1801dbbb0
// Size: 49 bytes
// ============================================================
bool fcn.1801dbbb0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801dbbba;
    iVar2 = fcn.18045a350();
    iVar1 = 1;
    if (*(int64_t *)(param_1 + 0x18) != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x1801dbbd1;
        iVar1 = fcn.180199150(*(int64_t *)(&stack0x00000058 + -iVar2));
    }
    return 0 < iVar1;
}

// ============================================================
// Function: FUN_1801dbbf0
// Address: 0x1801dbbf0
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801dbbf0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar5;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dbc00;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        piVar3 = *(int32_t **)(in_RCX + 0x20);
        if (piVar3 == (int32_t *)0x0) {
            return 1;
        }
        if (*piVar3 != 0) {
            if (-1 < (char)*piVar3) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dbc33;
            piVar3 = (int32_t *)func_0x0001801bda50(piVar3);
            if (piVar3 == (int32_t *)0x0) {
                return 0;
            }
        }
        iVar5 = *(int64_t *)(piVar3 + 0x21e);
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0x158);
    }
    iVar4 = *(int64_t *)(iVar5 + 0x70);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dbc4d;
        iVar4 = func_0x00018021f3d0();
        *(int64_t *)(iVar5 + 0x70) = iVar4;
        if (iVar4 == 0) {
            return 0;
        }
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dbc66;
        iVar1 = func_0x0001802339b0(iVar4, in_RDX);
        if (iVar1 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801dbc90
// Address: 0x1801dbc90
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801dbc90(int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dbca8;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar4 = *(undefined8 **)(in_RCX + 0x18);
    uVar7 = 0;
    uVar8 = 0;
    if (puVar4 == (undefined8 *)0x0) {
        piVar3 = *(int32_t **)(in_RCX + 0x20);
        if (piVar3 == (int32_t *)0x0) {
            return 1;
        }
        if (*piVar3 != 0) {
            if (-1 < (char)*piVar3) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbce3;
            piVar3 = (int32_t *)func_0x0001801bda50(piVar3);
            if (piVar3 == (int32_t *)0x0) {
                return 0;
            }
        }
        iVar6 = *(int64_t *)(piVar3 + 0x21e);
        puVar4 = *(undefined8 **)(*(int64_t *)(in_RCX + 0x20) + 8);
        if (puVar4 == (undefined8 *)0x0) goto code_r0x0001801dbd06;
    } else {
        iVar6 = puVar4[0x2b];
    }
    uVar7 = *puVar4;
    uVar8 = puVar4[0x8c];
code_r0x0001801dbd06:
    iVar5 = *(int64_t *)(iVar6 + 0x70);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbd14;
        iVar5 = func_0x00018021f3d0();
        *(int64_t *)(iVar6 + 0x70) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbd33;
        iVar1 = func_0x000180233920(iVar5, in_RDX, uVar7, uVar8);
        if (iVar1 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801dbd60
// Address: 0x1801dbd60
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801dbd60(int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dbd78;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar4 = *(undefined8 **)(in_RCX + 0x18);
    uVar7 = 0;
    uVar8 = 0;
    if (puVar4 == (undefined8 *)0x0) {
        piVar3 = *(int32_t **)(in_RCX + 0x20);
        if (piVar3 == (int32_t *)0x0) {
            return 1;
        }
        if (*piVar3 != 0) {
            if (-1 < (char)*piVar3) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbdb3;
            piVar3 = (int32_t *)func_0x0001801bda50(piVar3);
            if (piVar3 == (int32_t *)0x0) {
                return 0;
            }
        }
        iVar6 = *(int64_t *)(piVar3 + 0x21e);
        puVar4 = *(undefined8 **)(*(int64_t *)(in_RCX + 0x20) + 8);
        if (puVar4 == (undefined8 *)0x0) goto code_r0x0001801dbdd6;
    } else {
        iVar6 = puVar4[0x2b];
    }
    uVar7 = *puVar4;
    uVar8 = puVar4[0x8c];
code_r0x0001801dbdd6:
    iVar5 = *(int64_t *)(iVar6 + 0x70);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbde4;
        iVar5 = func_0x00018021f3d0();
        *(int64_t *)(iVar6 + 0x70) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbe03;
        iVar1 = func_0x000180233a20(iVar5, in_RDX, uVar7, uVar8);
        if (iVar1 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801dbe30
// Address: 0x1801dbe30
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801dbe30(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar5;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dbe40;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        piVar3 = *(int32_t **)(in_RCX + 0x20);
        if (piVar3 == (int32_t *)0x0) {
            return 1;
        }
        if (*piVar3 != 0) {
            if (-1 < (char)*piVar3) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dbe73;
            piVar3 = (int32_t *)func_0x0001801bda50(piVar3);
            if (piVar3 == (int32_t *)0x0) {
                return 0;
            }
        }
        iVar5 = *(int64_t *)(piVar3 + 0x21e);
    } else {
        iVar5 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0x158);
    }
    iVar4 = *(int64_t *)(iVar5 + 0x78);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dbe8d;
        iVar4 = func_0x00018021f3d0();
        *(int64_t *)(iVar5 + 0x78) = iVar4;
        if (iVar4 == 0) {
            return 0;
        }
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dbea6;
        iVar1 = func_0x0001802339b0(iVar4, in_RDX);
        if (iVar1 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801dbed0
// Address: 0x1801dbed0
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801dbed0(int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dbee8;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar4 = *(undefined8 **)(in_RCX + 0x18);
    uVar7 = 0;
    uVar8 = 0;
    if (puVar4 == (undefined8 *)0x0) {
        piVar3 = *(int32_t **)(in_RCX + 0x20);
        if (piVar3 == (int32_t *)0x0) {
            return 1;
        }
        if (*piVar3 != 0) {
            if (-1 < (char)*piVar3) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbf23;
            piVar3 = (int32_t *)func_0x0001801bda50(piVar3);
            if (piVar3 == (int32_t *)0x0) {
                return 0;
            }
        }
        iVar6 = *(int64_t *)(piVar3 + 0x21e);
        puVar4 = *(undefined8 **)(*(int64_t *)(in_RCX + 0x20) + 8);
        if (puVar4 == (undefined8 *)0x0) goto code_r0x0001801dbf46;
    } else {
        iVar6 = puVar4[0x2b];
    }
    uVar7 = *puVar4;
    uVar8 = puVar4[0x8c];
code_r0x0001801dbf46:
    iVar5 = *(int64_t *)(iVar6 + 0x78);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbf54;
        iVar5 = func_0x00018021f3d0();
        *(int64_t *)(iVar6 + 0x78) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbf73;
        iVar1 = func_0x000180233920(iVar5, in_RDX, uVar7, uVar8);
        if (iVar1 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801dbfa0
// Address: 0x1801dbfa0
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801dbfa0(int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dbfb8;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar4 = *(undefined8 **)(in_RCX + 0x18);
    uVar7 = 0;
    uVar8 = 0;
    if (puVar4 == (undefined8 *)0x0) {
        piVar3 = *(int32_t **)(in_RCX + 0x20);
        if (piVar3 == (int32_t *)0x0) {
            return 1;
        }
        if (*piVar3 != 0) {
            if (-1 < (char)*piVar3) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dbff3;
            piVar3 = (int32_t *)func_0x0001801bda50(piVar3);
            if (piVar3 == (int32_t *)0x0) {
                return 0;
            }
        }
        iVar6 = *(int64_t *)(piVar3 + 0x21e);
        puVar4 = *(undefined8 **)(*(int64_t *)(in_RCX + 0x20) + 8);
        if (puVar4 == (undefined8 *)0x0) goto code_r0x0001801dc016;
    } else {
        iVar6 = puVar4[0x2b];
    }
    uVar7 = *puVar4;
    uVar8 = puVar4[0x8c];
code_r0x0001801dc016:
    iVar5 = *(int64_t *)(iVar6 + 0x78);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dc024;
        iVar5 = func_0x00018021f3d0();
        *(int64_t *)(iVar6 + 0x78) = iVar5;
        if (iVar5 == 0) {
            return 0;
        }
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801dc043;
        iVar1 = func_0x000180233a20(iVar5, in_RDX, uVar7, uVar8);
        if (iVar1 == 0) {
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801dc070
// Address: 0x1801dc070
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4
fcn.1801dc070(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_R14;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc080;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar6 = *(int64_t *)(in_RCX + 0x70);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc097;
        iVar6 = fcn.180221f20();
        *(int64_t *)(in_RCX + 0x70) = iVar6;
        if (iVar6 == 0) {
            return 0;
        }
    }
    uVar8 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = uVar8;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801a0e5b;
    iVar3 = fcn.18045a350(iVar6);
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0e77;
    fcn.180229130(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar5));
    *(undefined8 *)((int64_t)&arg_38h + iVar3 + iVar5) = 0x180195290;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0ea0;
    iVar4 = fcn.180229290(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5));
    if ((in_RDX == 0) || (iVar4 == 0)) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0ec8;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0edd;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar3 + iVar5), *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0eec;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar3 + iVar5));
        uVar2 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0efd;
        iVar1 = fcn.180222010(iVar6);
        iVar7 = 0;
        if (0 < iVar1) {
            do {
                *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0f0f;
                fcn.180222340(iVar6, iVar7);
                *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0f1a;
                fcn.180228fb0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                              *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar5));
                iVar7 = iVar7 + 1;
            } while (iVar7 < iVar1);
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0f2e;
        uVar2 = fcn.1801a1130(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5), 
                              *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar5), 
                              *(int64_t *)(&stack0x00000050 + iVar3 + iVar5));
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801a0f3d;
    fcn.180228ec0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar5), *(int64_t *)(&stack0x00000050 + iVar3 + iVar5), 
                  *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar5));
    return uVar2;
}

// ============================================================
// Function: FUN_1801dc0c0
// Address: 0x1801dc0c0
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_490h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_4eh

void fcn.1801dc0c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_80h)
{
    uint64_t uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc0d0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar9 = *(int64_t *)(in_RCX + 0x70);
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801dc0e7;
        iVar9 = fcn.180221f20();
        *(int64_t *)(in_RCX + 0x70) = iVar9;
        if (iVar9 == 0) {
            return;
        }
    }
    uVar2 = *(undefined8 *)((int64_t)&arg_28h + iVar8);
    uVar11 = *(undefined8 *)((int64_t)auStackX_10 + iVar8 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar8 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_10 + iVar8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_10 + iVar8 + -8) = 0x1801a0b5e;
    iVar4 = fcn.18045a350(iVar9, in_RDX);
    iVar4 = -iVar4;
    *(uint64_t *)(&stack0x00000480 + iVar4 + iVar8) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar4 + iVar8;
    *(undefined8 *)(&stack0x000004b0 + iVar4 + iVar8) = unaff_RSI;
    iVar10 = 0;
    *(undefined8 *)(&stack0x00000490 + iVar4 + iVar8) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_40h + iVar4 + iVar8) = 0;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0ba4;
    fcn.180229130(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), *(int64_t *)(&stack0x00000038 + iVar4 + iVar8));
    *(undefined8 *)((int64_t)&arg_30h + iVar4 + iVar8) = 0x180195290;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0bcd;
    iVar5 = fcn.180229290(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8));
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0bda;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), *(int64_t *)(&stack0x00000038 + iVar4 + iVar8));
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0bf2;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), *(int64_t *)(&stack0x00000038 + iVar4 + iVar8), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar8), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar8), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar8));
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0c04;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar8));
    } else {
        *(undefined8 *)(&stack0x000004e0 + iVar4 + iVar8) = uVar2;
        *(undefined8 *)(&stack0x000004a8 + iVar4 + iVar8) = uVar11;
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0c21;
        iVar3 = fcn.180222010(iVar9);
        if (0 < iVar3) {
            do {
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0c3a;
                fcn.180222340(iVar9, iVar10);
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0c45;
                fcn.180228fb0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar8), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar8), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar8));
                iVar10 = iVar10 + 1;
            } while (iVar10 < iVar3);
        }
        *(undefined8 *)(&stack0x000004a0 + iVar4 + iVar8) = unaff_R12;
        *(undefined8 *)(&stack0x00000498 + iVar4 + iVar8) = unaff_R13;
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0c68;
        iVar9 = fcn.18024b460(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                              *(int64_t *)(&stack0x00000060 + iVar4 + iVar8), 
                              *(int64_t *)(&stack0x00000068 + iVar4 + iVar8), 
                              *(int64_t *)(&stack0x00000070 + iVar4 + iVar8));
        while (iVar9 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0c88;
            iVar5 = fcn.180498cd0(iVar9);
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0c93;
            iVar6 = fcn.180498cd0(in_RDX);
            if (0x400 < (uint64_t)(iVar6 + 2 + iVar5)) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0da5;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar4 + iVar8));
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0dbd;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                              *(int64_t *)(&stack0x00000038 + iVar4 + iVar8), 
                              *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar8), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar8), 
                              *(int64_t *)(&stack0x00000060 + iVar4 + iVar8));
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0dcf;
                fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar8));
                goto code_r0x0001801a0df7;
            }
            *(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8) = iVar9;
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0cc5;
            iVar10 = fcn.180245f70(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                                   *(int64_t *)(&stack0x00000038 + iVar4 + iVar8), 
                                   *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar8), 
                                   *(int64_t *)(&stack0x00000050 + iVar4 + iVar8), 
                                   *(int64_t *)(&stack0x00000058 + iVar4 + iVar8), 
                                   *(int64_t *)(&stack0x00000060 + iVar4 + iVar8), 
                                   *(int64_t *)(&stack0x00000090 + iVar4 + iVar8), 
                                   *(int64_t *)(&stack0x000000b8 + iVar4 + iVar8));
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0cd6;
            iVar3 = fcn.180472e30((int64_t)&arg_80h + iVar4 + iVar8, (int64_t)&arg_48h + iVar4 + iVar8);
            if ((iVar3 != 0) || ((*(uint16_t *)((int64_t)&arg_48h + iVar4 + iVar8 + 6) & 0xf000) != 0x4000)) {
                if (0x3fe < iVar10 - 1U) goto code_r0x0001801a0df7;
                *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d07;
                iVar10 = fcn.1801a1130(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                                       *(int64_t *)(&stack0x00000038 + iVar4 + iVar8), 
                                       *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar8));
                if (iVar10 == 0) goto code_r0x0001801a0df7;
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d1c;
            iVar9 = fcn.18024b460(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                                  *(int64_t *)(&stack0x00000060 + iVar4 + iVar8), 
                                  *(int64_t *)(&stack0x00000068 + iVar4 + iVar8), 
                                  *(int64_t *)(&stack0x00000070 + iVar4 + iVar8));
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d2d;
        piVar7 = (int32_t *)fcn.18046b77c();
        if (*piVar7 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d3b;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar4 + iVar8));
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d53;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar4 + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar8), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar8), 
                          *(int64_t *)(&stack0x00000060 + iVar4 + iVar8));
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d59;
            (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d6f;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar8));
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d74;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar4 + iVar8));
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d8c;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), 
                          *(int64_t *)(&stack0x00000038 + iVar4 + iVar8), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar8), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar8), 
                          *(int64_t *)(&stack0x00000060 + iVar4 + iVar8));
            *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0d9e;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar8));
        }
    }
code_r0x0001801a0df7:
    if (*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar8) != 0) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0e19;
        fcn.18024b400((int64_t)&arg_40h + iVar4 + iVar8);
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0e21;
    fcn.180228ec0(*(int64_t *)((int64_t)&arg_30h + iVar4 + iVar8), *(int64_t *)(&stack0x00000038 + iVar4 + iVar8), 
                  *(int64_t *)((int64_t)&arg_40h + iVar4 + iVar8), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar8), 
                  *(int64_t *)(&stack0x00000060 + iVar4 + iVar8));
    uVar1 = *(uint64_t *)(&stack0x00000480 + iVar4 + iVar8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + iVar8 + -8) = 0x1801a0e34;
    fcn.180459870(uVar1 ^ (int64_t)auStackX_10 + iVar4 + iVar8);
    return;
}

// ============================================================
// Function: FUN_1801dc110
// Address: 0x1801dc110
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.1801dc110(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar5;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc120;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *(int64_t *)(in_RCX + 0x70);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dc137;
        iVar4 = fcn.180221f20();
        *(int64_t *)(in_RCX + 0x70) = iVar4;
        if (iVar4 == 0) {
            return 0;
        }
    }
    uVar5 = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = uVar5;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = 0x1801a0f75;
    iVar2 = fcn.18045a350(iVar4, in_RDX);
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + iVar3) = 0x1801a0f8a;
    uVar5 = fcn.180222270();
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + iVar3) = 0x1801a0f9e;
    uVar1 = fcn.1801a1290(*(int64_t *)((int64_t)&arg_48h + iVar2 + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar2 + iVar3), 
                          *(int64_t *)(&stack0x00000058 + iVar2 + iVar3));
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + iVar3) = 0x1801a0fab;
    fcn.180222270(iVar4, uVar5);
    return uVar1;
}

// ============================================================
// Function: FUN_1801dc160
// Address: 0x1801dc160
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1801dc160(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_a8h)
{
    bool bVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dc179;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *(int64_t *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
    iVar3 = 0;
    if (iVar5 == 0) {
        puVar7 = *(undefined8 **)(in_RCX + 0x18);
    } else {
        puVar7 = *(undefined8 **)(iVar5 + 8);
    }
    if ((*(int64_t *)(in_RCX + 0x18) == 0) && (iVar5 == 0)) {
        bVar1 = true;
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1bd;
        fcn.18023faa0();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1c5;
        iVar5 = fcn.18021a7c0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar4));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1e7;
            iVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar4));
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)&var_18h + iVar4) = puVar7[0x8c];
                *(undefined8 *)((int64_t)&var_10h + iVar4) = *puVar7;
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 4;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc226;
                iVar6 = func_0x000180271890((int64_t)&arg_48h + iVar4, 0x1804b62d8, 0, 0x1804ad19c);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc237;
                    func_0x000180229b10();
                    do {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc24b;
                        iVar2 = func_0x000180270860(iVar6, iVar5);
                        if ((iVar2 != 0) || (*(int64_t *)((int64_t)&arg_48h + iVar4) != 0)) break;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc269;
                        iVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar4), 
                                              *(int64_t *)(&stack0x00000030 + iVar4), 
                                              *(int64_t *)(&stack0x00000038 + iVar4));
                    } while (iVar2 == 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc275;
                    func_0x00018026f440(iVar6);
                    if (*(int64_t *)((int64_t)&arg_48h + iVar4) == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc281;
                        func_0x000180229900();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc288;
                        func_0x0001802299d0();
                        iVar5 = *(int64_t *)(in_RCX + 0x18);
                        iVar3 = 0;
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc29b;
                            iVar3 = func_0x000180192b80(iVar5, *(undefined8 *)((int64_t)&arg_48h + iVar4));
                            if (0 < iVar3) {
                                *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            }
                        }
                        iVar5 = *(int64_t *)(in_RCX + 0x20);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2b9;
                            iVar3 = func_0x000180194310(iVar5, *(undefined8 *)((int64_t)&arg_48h + iVar4));
                            if (0 < iVar3) {
                                *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            }
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2ce;
        func_0x00018022ecc0(*(undefined8 *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2d6;
        fcn.180219f80(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        bVar1 = 0 < iVar3;
    }
    return bVar1;
}

// ============================================================
// Function: FUN_1801dc1b3
// Address: 0x1801dc1b3
// Size: 304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1801dc160(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_a8h)
{
    bool bVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dc179;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *(int64_t *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
    iVar3 = 0;
    if (iVar5 == 0) {
        puVar7 = *(undefined8 **)(in_RCX + 0x18);
    } else {
        puVar7 = *(undefined8 **)(iVar5 + 8);
    }
    if ((*(int64_t *)(in_RCX + 0x18) == 0) && (iVar5 == 0)) {
        bVar1 = true;
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1bd;
        fcn.18023faa0();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1c5;
        iVar5 = fcn.18021a7c0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar4));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1e7;
            iVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar4));
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)&var_18h + iVar4) = puVar7[0x8c];
                *(undefined8 *)((int64_t)&var_10h + iVar4) = *puVar7;
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 4;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc226;
                iVar6 = func_0x000180271890((int64_t)&arg_48h + iVar4, 0x1804b62d8, 0, 0x1804ad19c);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc237;
                    func_0x000180229b10();
                    do {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc24b;
                        iVar2 = func_0x000180270860(iVar6, iVar5);
                        if ((iVar2 != 0) || (*(int64_t *)((int64_t)&arg_48h + iVar4) != 0)) break;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc269;
                        iVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar4), 
                                              *(int64_t *)(&stack0x00000030 + iVar4), 
                                              *(int64_t *)(&stack0x00000038 + iVar4));
                    } while (iVar2 == 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc275;
                    func_0x00018026f440(iVar6);
                    if (*(int64_t *)((int64_t)&arg_48h + iVar4) == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc281;
                        func_0x000180229900();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc288;
                        func_0x0001802299d0();
                        iVar5 = *(int64_t *)(in_RCX + 0x18);
                        iVar3 = 0;
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc29b;
                            iVar3 = func_0x000180192b80(iVar5, *(undefined8 *)((int64_t)&arg_48h + iVar4));
                            if (0 < iVar3) {
                                *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            }
                        }
                        iVar5 = *(int64_t *)(in_RCX + 0x20);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2b9;
                            iVar3 = func_0x000180194310(iVar5, *(undefined8 *)((int64_t)&arg_48h + iVar4));
                            if (0 < iVar3) {
                                *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            }
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2ce;
        func_0x00018022ecc0(*(undefined8 *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2d6;
        fcn.180219f80(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        bVar1 = 0 < iVar3;
    }
    return bVar1;
}

// ============================================================
// Function: FUN_1801dc2e3
// Address: 0x1801dc2e3
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1801dc160(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_a8h)
{
    bool bVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dc179;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar5 = *(int64_t *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
    iVar3 = 0;
    if (iVar5 == 0) {
        puVar7 = *(undefined8 **)(in_RCX + 0x18);
    } else {
        puVar7 = *(undefined8 **)(iVar5 + 8);
    }
    if ((*(int64_t *)(in_RCX + 0x18) == 0) && (iVar5 == 0)) {
        bVar1 = true;
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1bd;
        fcn.18023faa0();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1c5;
        iVar5 = fcn.18021a7c0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar4));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc1e7;
            iVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)(&stack0x00000038 + iVar4));
            if (0 < iVar2) {
                *(undefined8 *)((int64_t)&var_18h + iVar4) = puVar7[0x8c];
                *(undefined8 *)((int64_t)&var_10h + iVar4) = *puVar7;
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 4;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc226;
                iVar6 = func_0x000180271890((int64_t)&arg_48h + iVar4, 0x1804b62d8, 0, 0x1804ad19c);
                if (iVar6 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc237;
                    func_0x000180229b10();
                    do {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc24b;
                        iVar2 = func_0x000180270860(iVar6, iVar5);
                        if ((iVar2 != 0) || (*(int64_t *)((int64_t)&arg_48h + iVar4) != 0)) break;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc269;
                        iVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar4), 
                                              *(int64_t *)(&stack0x00000030 + iVar4), 
                                              *(int64_t *)(&stack0x00000038 + iVar4));
                    } while (iVar2 == 0);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc275;
                    func_0x00018026f440(iVar6);
                    if (*(int64_t *)((int64_t)&arg_48h + iVar4) == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc281;
                        func_0x000180229900();
                    } else {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc288;
                        func_0x0001802299d0();
                        iVar5 = *(int64_t *)(in_RCX + 0x18);
                        iVar3 = 0;
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc29b;
                            iVar3 = func_0x000180192b80(iVar5, *(undefined8 *)((int64_t)&arg_48h + iVar4));
                            if (0 < iVar3) {
                                *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            }
                        }
                        iVar5 = *(int64_t *)(in_RCX + 0x20);
                        if (iVar5 != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2b9;
                            iVar3 = func_0x000180194310(iVar5, *(undefined8 *)((int64_t)&arg_48h + iVar4));
                            if (0 < iVar3) {
                                *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
                            }
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2ce;
        func_0x00018022ecc0(*(undefined8 *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dc2d6;
        fcn.180219f80(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        bVar1 = 0 < iVar3;
    }
    return bVar1;
}

// ============================================================
// Function: FUN_1801dc300
// Address: 0x1801dc300
// Size: 78 bytes
// ============================================================
undefined4 fcn.1801dc300(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_a0h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined4 uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dc30e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar3 = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar5) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar5) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc33b;
    iVar6 = func_0x0001802231e0(in_RDX, 0x1804b62c8, 0x2a5);
    if (iVar6 == 0) goto code_r0x0001801dc3f1;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc35b;
    puVar7 = (undefined *)func_0x00018045bb90(iVar6, 0x180620388);
    if (puVar7 != (undefined *)0x0) {
        *puVar7 = 0;
        if (puVar7[1] == '\0') goto code_r0x0001801dc3f1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc381;
        iVar2 = func_0x000180223880(puVar7 + 1, (int64_t)&var_8h + iVar5, 0, (int64_t)&arg_48h + iVar5);
        if (iVar2 == 0) goto code_r0x0001801dc3f1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc39a;
    iVar2 = func_0x000180223880(iVar6, (int64_t)&var_8h + iVar5, 0, (int64_t)&arg_50h + iVar5);
    if (iVar2 != 0) {
        uVar8 = *(undefined4 *)((int64_t)&arg_50h + iVar5);
        if (puVar7 == (undefined *)0x0) {
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = uVar8;
            uVar4 = uVar8;
        } else {
            uVar4 = *(undefined4 *)((int64_t)&arg_48h + iVar5);
        }
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc3ca;
            uVar3 = func_0x000180192d30(iVar1, uVar8, uVar4);
            uVar8 = *(undefined4 *)((int64_t)&arg_50h + iVar5);
            uVar4 = *(undefined4 *)((int64_t)&arg_48h + iVar5);
        }
        iVar1 = *(int64_t *)(in_RCX + 0x20);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc3ea;
            uVar3 = func_0x000180194780(iVar1, uVar8, uVar4);
        }
    }
code_r0x0001801dc3f1:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc406;
    fcn.180224990(iVar6, 0x1804b62c8, 0x2c0);
    return uVar3;
}

// ============================================================
// Function: FUN_1801dc34e
// Address: 0x1801dc34e
// Size: 163 bytes
// ============================================================
undefined4 fcn.1801dc300(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_a0h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined4 uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dc30e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar3 = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar5) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar5) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc33b;
    iVar6 = func_0x0001802231e0(in_RDX, 0x1804b62c8, 0x2a5);
    if (iVar6 == 0) goto code_r0x0001801dc3f1;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc35b;
    puVar7 = (undefined *)func_0x00018045bb90(iVar6, 0x180620388);
    if (puVar7 != (undefined *)0x0) {
        *puVar7 = 0;
        if (puVar7[1] == '\0') goto code_r0x0001801dc3f1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc381;
        iVar2 = func_0x000180223880(puVar7 + 1, (int64_t)&var_8h + iVar5, 0, (int64_t)&arg_48h + iVar5);
        if (iVar2 == 0) goto code_r0x0001801dc3f1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc39a;
    iVar2 = func_0x000180223880(iVar6, (int64_t)&var_8h + iVar5, 0, (int64_t)&arg_50h + iVar5);
    if (iVar2 != 0) {
        uVar8 = *(undefined4 *)((int64_t)&arg_50h + iVar5);
        if (puVar7 == (undefined *)0x0) {
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = uVar8;
            uVar4 = uVar8;
        } else {
            uVar4 = *(undefined4 *)((int64_t)&arg_48h + iVar5);
        }
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc3ca;
            uVar3 = func_0x000180192d30(iVar1, uVar8, uVar4);
            uVar8 = *(undefined4 *)((int64_t)&arg_50h + iVar5);
            uVar4 = *(undefined4 *)((int64_t)&arg_48h + iVar5);
        }
        iVar1 = *(int64_t *)(in_RCX + 0x20);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc3ea;
            uVar3 = func_0x000180194780(iVar1, uVar8, uVar4);
        }
    }
code_r0x0001801dc3f1:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc406;
    fcn.180224990(iVar6, 0x1804b62c8, 0x2c0);
    return uVar3;
}

// ============================================================
// Function: FUN_1801dc3f1
// Address: 0x1801dc3f1
// Size: 31 bytes
// ============================================================
undefined4 fcn.1801dc300(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_a0h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined4 uVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dc30e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar3 = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar5) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar5) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc33b;
    iVar6 = func_0x0001802231e0(in_RDX, 0x1804b62c8, 0x2a5);
    if (iVar6 == 0) goto code_r0x0001801dc3f1;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc35b;
    puVar7 = (undefined *)func_0x00018045bb90(iVar6, 0x180620388);
    if (puVar7 != (undefined *)0x0) {
        *puVar7 = 0;
        if (puVar7[1] == '\0') goto code_r0x0001801dc3f1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc381;
        iVar2 = func_0x000180223880(puVar7 + 1, (int64_t)&var_8h + iVar5, 0, (int64_t)&arg_48h + iVar5);
        if (iVar2 == 0) goto code_r0x0001801dc3f1;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc39a;
    iVar2 = func_0x000180223880(iVar6, (int64_t)&var_8h + iVar5, 0, (int64_t)&arg_50h + iVar5);
    if (iVar2 != 0) {
        uVar8 = *(undefined4 *)((int64_t)&arg_50h + iVar5);
        if (puVar7 == (undefined *)0x0) {
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = uVar8;
            uVar4 = uVar8;
        } else {
            uVar4 = *(undefined4 *)((int64_t)&arg_48h + iVar5);
        }
        iVar1 = *(int64_t *)(in_RCX + 0x18);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc3ca;
            uVar3 = func_0x000180192d30(iVar1, uVar8, uVar4);
            uVar8 = *(undefined4 *)((int64_t)&arg_50h + iVar5);
            uVar4 = *(undefined4 *)((int64_t)&arg_48h + iVar5);
        }
        iVar1 = *(int64_t *)(in_RCX + 0x20);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc3ea;
            uVar3 = func_0x000180194780(iVar1, uVar8, uVar4);
        }
    }
code_r0x0001801dc3f1:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801dc406;
    fcn.180224990(iVar6, 0x1804b62c8, 0x2c0);
    return uVar3;
}

// ============================================================
// Function: FUN_1801dc410
// Address: 0x1801dc410
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.1801dc410(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc420;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc430;
    iVar1 = func_0x00018046eadc(in_RDX);
    if (iVar1 < 0) {
        return 0;
    }
    iVar3 = *(int64_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    iVar6 = (int64_t)iVar1;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc44d;
        uVar2 = func_0x000180192f90(iVar3, iVar6);
    }
    piVar4 = *(int32_t **)(in_RCX + 0x20);
    if (piVar4 == (int32_t *)0x0) {
        return uVar2;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -8) = 0x180194adc;
    iVar3 = fcn.18045a350();
    if (piVar4 != (int32_t *)0x0) {
        if (*piVar4 == 0) {
code_r0x000180194b01:
            *(int64_t *)(piVar4 + 0x552) = iVar6;
            return 1;
        }
        if ((char)*piVar4 < '\0') {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar5 - iVar3) + -8) = 0x180194afc;
            piVar4 = (int32_t *)func_0x0001801bda50(piVar4);
            if (piVar4 != (int32_t *)0x0) goto code_r0x000180194b01;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dc438
// Address: 0x1801dc438
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.1801dc410(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc420;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc430;
    iVar1 = func_0x00018046eadc(in_RDX);
    if (iVar1 < 0) {
        return 0;
    }
    iVar3 = *(int64_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    iVar6 = (int64_t)iVar1;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc44d;
        uVar2 = func_0x000180192f90(iVar3, iVar6);
    }
    piVar4 = *(int32_t **)(in_RCX + 0x20);
    if (piVar4 == (int32_t *)0x0) {
        return uVar2;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -8) = 0x180194adc;
    iVar3 = fcn.18045a350();
    if (piVar4 != (int32_t *)0x0) {
        if (*piVar4 == 0) {
code_r0x000180194b01:
            *(int64_t *)(piVar4 + 0x552) = iVar6;
            return 1;
        }
        if ((char)*piVar4 < '\0') {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar5 - iVar3) + -8) = 0x180194afc;
            piVar4 = (int32_t *)func_0x0001801bda50(piVar4);
            if (piVar4 != (int32_t *)0x0) goto code_r0x000180194b01;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dc46f
// Address: 0x1801dc46f
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.1801dc410(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc420;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc430;
    iVar1 = func_0x00018046eadc(in_RDX);
    if (iVar1 < 0) {
        return 0;
    }
    iVar3 = *(int64_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    iVar6 = (int64_t)iVar1;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc44d;
        uVar2 = func_0x000180192f90(iVar3, iVar6);
    }
    piVar4 = *(int32_t **)(in_RCX + 0x20);
    if (piVar4 == (int32_t *)0x0) {
        return uVar2;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -8) = 0x180194adc;
    iVar3 = fcn.18045a350();
    if (piVar4 != (int32_t *)0x0) {
        if (*piVar4 == 0) {
code_r0x000180194b01:
            *(int64_t *)(piVar4 + 0x552) = iVar6;
            return 1;
        }
        if ((char)*piVar4 < '\0') {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar5 - iVar3) + -8) = 0x180194afc;
            piVar4 = (int32_t *)func_0x0001801bda50(piVar4);
            if (piVar4 != (int32_t *)0x0) goto code_r0x000180194b01;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dc481
// Address: 0x1801dc481
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.1801dc410(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RDI;
    int64_t iVar6;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc420;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar2 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc430;
    iVar1 = func_0x00018046eadc(in_RDX);
    if (iVar1 < 0) {
        return 0;
    }
    iVar3 = *(int64_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    iVar6 = (int64_t)iVar1;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dc44d;
        uVar2 = func_0x000180192f90(iVar3, iVar6);
    }
    piVar4 = *(int32_t **)(in_RCX + 0x20);
    if (piVar4 == (int32_t *)0x0) {
        return uVar2;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + -8) = 0x180194adc;
    iVar3 = fcn.18045a350();
    if (piVar4 != (int32_t *)0x0) {
        if (*piVar4 == 0) {
code_r0x000180194b01:
            *(int64_t *)(piVar4 + 0x552) = iVar6;
            return 1;
        }
        if ((char)*piVar4 < '\0') {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar5 - iVar3) + -8) = 0x180194afc;
            piVar4 = (int32_t *)func_0x0001801bda50(piVar4);
            if (piVar4 != (int32_t *)0x0) goto code_r0x000180194b01;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dc490
// Address: 0x1801dc490
// Size: 332 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801dc490(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    uint8_t *in_RCX;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc4b0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        piVar3 = *(int32_t **)(in_RCX + 0x20);
        if (piVar3 == (int32_t *)0x0) goto code_r0x0001801dc56f;
        if (*piVar3 != 0) {
            if (-1 < (char)*piVar3) goto code_r0x0001801dc56f;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc4eb;
            piVar3 = (int32_t *)func_0x0001801bda50(piVar3);
            if (piVar3 == (int32_t *)0x0) goto code_r0x0001801dc56f;
        }
        iVar6 = *(int64_t *)(piVar3 + 0x21e);
    } else {
        iVar6 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0x158);
    }
    if (((iVar6 != 0) && ((*in_RCX & 0x40) != 0)) && (uVar5 = 0, *(int64_t *)(in_RCX + 0x38) != 0)) {
        iVar4 = 0;
        do {
            if (((*(int64_t *)(*(int64_t *)(in_RCX + 0x30) + uVar5 * 8) != 0) &&
                (*(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 8 + iVar4) == 0)) && (iVar1 = 1, (*in_RCX & 0x20) != 0)) {
                if (*(int64_t *)(in_RCX + 0x18) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc547;
                    iVar1 = fcn.180198a80(*(int64_t *)((int64_t)&arg_28h + iVar2), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar2), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar2));
                }
                if (*(int64_t *)(in_RCX + 0x20) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc55e;
                    iVar1 = fcn.1801995e0(*(int64_t *)((int64_t)&arg_28h + iVar2), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar2), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar2));
                }
                if (iVar1 < 1) {
                    return 0;
                }
            }
            uVar5 = uVar5 + 1;
            iVar4 = iVar4 + 0x28;
        } while (uVar5 < *(uint64_t *)(in_RCX + 0x38));
    }
code_r0x0001801dc56f:
    iVar6 = *(int64_t *)(in_RCX + 0x70);
    if (iVar6 != 0) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        if (iVar4 == 0) {
            iVar4 = *(int64_t *)(in_RCX + 0x18);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc5b4;
                func_0x000180222050(iVar6, fcn.1802348f0);
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc5a6;
                func_0x0001801a0b10(iVar4, iVar6);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc58c;
            func_0x0001801a10d0(iVar4, iVar6);
        }
        *(undefined8 *)(in_RCX + 0x70) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801dc5e0
// Address: 0x1801dc5e0
// Size: 92 bytes
// ============================================================
void fcn.1801dc5e0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801dc5f0;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc5fb;
        fcn.1801dcb00(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc611;
        fcn.180224990(uVar1, 0x1804b62c8, 0x452);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc621;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dc636;
        fcn.180224990(arg1, 0x1804b62c8, 0x454);
    }
    return;
}

// ============================================================
// Function: FUN_1801dc640
// Address: 0x1801dc640
// Size: 40 bytes
// ============================================================
int64_t fcn.1801dc640(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar4 = 0x78;
    *(undefined8 *)(&stack0x00000030 + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180224d70;
    iVar2 = fcn.18045a350(0x78, 0x1804b62c8, 0x417);
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d7b;
    iVar3 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                         );
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d90;
        fcn.1804986e0(iVar3, 0, uVar4);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1801dc680
// Address: 0x1801dc680
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801dc680(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t in_RCX;
    int32_t *in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc695;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(int32_t **)(in_RCX + 0x20) = in_RDX;
    *(undefined8 *)(in_RCX + 0x18) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dc6ad;
    fcn.1801dcb00(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (in_RDX == (int32_t *)0x0) {
        *(undefined8 *)(in_RCX + 0x28) = 0;
        *(undefined8 *)(in_RCX + 0x50) = 0;
        *(undefined8 *)(in_RCX + 0x58) = 0;
        *(undefined8 *)(in_RCX + 0x40) = 0;
        *(undefined8 *)(in_RCX + 0x48) = 0;
        return;
    }
    if (*in_RDX != 0) {
        if (-1 < (char)*in_RDX) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dc6cc;
        in_RDX = (int32_t *)func_0x0001801bda50(in_RDX);
        if (in_RDX == (int32_t *)0x0) {
            return;
        }
    }
    *(int32_t **)(in_RCX + 0x28) = in_RDX + 0x26a;
    *(int32_t **)(in_RCX + 0x50) = in_RDX + 0x26d;
    *(int32_t **)(in_RCX + 0x58) = in_RDX + 0x26e;
    *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RDX + 0x21e) + 0x1c;
    *(int32_t **)(in_RCX + 0x48) = in_RDX + 0x252;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dc730;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    *(int64_t *)(in_RCX + 0x30) = iVar1;
    if (iVar1 == 0) {
        return;
    }
    *(undefined8 *)(in_RCX + 0x38) = *(undefined8 *)(in_RDX + 0x46);
    return;
}

// ============================================================
// Function: FUN_1801dc780
// Address: 0x1801dc780
// Size: 222 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801dc780(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc795;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(int64_t *)(in_RCX + 0x18) = in_RDX;
    *(undefined8 *)(in_RCX + 0x20) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dc7ad;
    fcn.1801dcb00(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (in_RDX == 0) {
        *(undefined8 *)(in_RCX + 0x28) = 0;
        *(undefined8 *)(in_RCX + 0x50) = 0;
        *(undefined8 *)(in_RCX + 0x58) = 0;
        *(undefined8 *)(in_RCX + 0x40) = 0;
        *(undefined8 *)(in_RCX + 0x48) = 0;
    } else {
        *(int64_t *)(in_RCX + 0x28) = in_RDX + 0x138;
        *(int64_t *)(in_RCX + 0x50) = in_RDX + 0x144;
        *(int64_t *)(in_RCX + 0x58) = in_RDX + 0x148;
        *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RDX + 0x158) + 0x1c;
        *(int64_t *)(in_RCX + 0x48) = in_RDX + 0x180;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dc812;
        iVar1 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(int64_t *)(in_RCX + 0x30) = iVar1;
        if (iVar1 != 0) {
            *(int64_t *)(in_RCX + 0x38) = *(int64_t *)(in_RDX + 0x680) + 9;
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801dc860
// Address: 0x1801dc860
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dc8ec
// Address: 0x1801dc8ec
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dc951
// Address: 0x1801dc951
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dc9bb
// Address: 0x1801dc9bb
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dc9d6
// Address: 0x1801dc9d6
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dc9f9
// Address: 0x1801dc9f9
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dca17
// Address: 0x1801dca17
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dca42
// Address: 0x1801dca42
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dcaac
// Address: 0x1801dcaac
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1801dc860(uint8_t *placeholder_0, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_78h, int64_t arg_80h)
{
    int16_t iVar1;
    uint64_t *puVar2;
    uint64_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    code **ppcVar7;
    uint32_t uVar8;
    uint32_t *puVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    uint32_t uVar11;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dc875;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (arg2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc888;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8a0;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8b2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8c9;
    iVar5 = fcn.1801dccf0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc8de;
        ppcVar7 = (code **)fcn.1801dcc20(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                         *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                         *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6))
        ;
        if (ppcVar7 != (code **)0x0) {
            iVar1 = *(int16_t *)((int64_t)ppcVar7 + 0x1a);
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
            iVar5 = -3;
            if (iVar1 != 4) {
                if (in_R8 != 0) {
                    pcVar4 = *ppcVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca27;
                    iVar5 = (*pcVar4)(placeholder_0, in_R8);
                    if (0 < iVar5) {
                        return 2;
                    }
                    if (iVar5 != -2) {
                        iVar5 = 0;
                    }
                }
                if ((*placeholder_0 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca54;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca6c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                    iVar10 = 0x1804b6308;
                    if (in_R8 != 0) {
                        iVar10 = in_R8;
                    }
                    *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dca9a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                }
                return iVar5;
            }
            if (0x1e < (uint64_t)((int64_t)(ppcVar7 + -0x30096a34) >> 5)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc915;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc92d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dc93f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                return 0;
            }
            puVar2 = *(uint64_t **)(placeholder_0 + 0x28);
            iVar6 = ((int64_t)(ppcVar7 + -0x30096a34) >> 5) * 0x10;
            uVar3 = *(uint64_t *)(iVar6 + 0x1804b5940);
            if (puVar2 != (uint64_t *)0x0) {
                uVar8 = *(uint32_t *)(iVar6 + 0x1804b5948);
                uVar11 = uVar8 & 1;
                uVar8 = uVar8 & 0xf00;
                if (uVar8 != 0) {
                    if (uVar8 == 0x100) {
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x40);
                    } else {
                        if (uVar8 != 0x200) {
                            return 1;
                        }
                        puVar9 = *(uint32_t **)(placeholder_0 + 0x48);
                    }
                    if (uVar11 != 0) {
                        *puVar9 = ~(uint32_t)uVar3 & *puVar9;
                        return 1;
                    }
                    *puVar9 = (uint32_t)uVar3 | *puVar9;
                    return 1;
                }
                if (uVar11 == 0) {
                    *puVar2 = *puVar2 | uVar3;
                    return 1;
                }
                *puVar2 = ~uVar3 & *puVar2;
            }
            return 1;
        }
    }
    if ((*placeholder_0 & 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcab6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcace;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dcae9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    }
    return -2;
}

// ============================================================
// Function: FUN_1801dcb00
// Address: 0x1801dcb00
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801dcb00(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dcb15;
    iVar2 = fcn.18045a350();
    uVar3 = 0;
    if (*(int64_t *)(in_RCX + 0x38) != 0) {
        do {
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x30) + uVar3 * 8);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801dcb3d;
            fcn.180224990(uVar1, 0x1804b62c8, 0x448);
            uVar3 = uVar3 + 1;
        } while (uVar3 < *(uint64_t *)(in_RCX + 0x38));
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801dcb5c;
    fcn.180224990(uVar1, 0x1804b62c8, 0x449);
    *(undefined8 *)(in_RCX + 0x30) = 0;
    *(undefined8 *)(in_RCX + 0x38) = 0;
    return;
}

// ============================================================
// Function: FUN_1801dcb80
// Address: 0x1801dcb80
// Size: 160 bytes
// ============================================================
undefined8
fcn.1801db910(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 *puVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x18) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4) = 0x1801dcb9e;
    iVar5 = fcn.18045a350();
    if (*(int64_t *)(in_RCX + 0x18) == 0) {
        if (*(int64_t *)(in_RCX + 0x20) == 0) {
            return 0;
        }
        puVar6 = *(undefined4 **)(*(int64_t *)(in_RCX + 0x20) + 0x10);
    } else {
        puVar6 = *(undefined4 **)(*(int64_t *)(in_RCX + 0x18) + 8);
    }
    uVar1 = *puVar6;
    puVar9 = (undefined8 *)0x1804b4e00;
    uVar8 = 0;
    do {
        uVar2 = *puVar9;
        *(undefined8 *)((int64_t)auStackX_8 + -iVar5 + iVar4) = 0x1801dcbdc;
        iVar3 = func_0x000180498f10(uVar2, in_RDX);
        if (iVar3 == 0) {
            iVar3 = *(int32_t *)(uVar8 * 0x10 + 0x1804b4e08);
            if (iVar3 < 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)auStackX_8 + -iVar5 + iVar4) = 0x1801dcc1e;
            uVar7 = func_0x0001801afd20(uVar1, iVar3, uVar7);
            return uVar7;
        }
        uVar8 = uVar8 + 1;
        puVar9 = puVar9 + 2;
    } while (uVar8 < 8);
    return 0;
}

// ============================================================
// Function: FUN_1801dcc20
// Address: 0x1801dcc20
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801dcc20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint16_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint32_t *in_RCX;
    int64_t in_RDX;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dcc40;
    iVar5 = fcn.18045a350();
    if (in_RDX != 0) {
        uVar7 = 0;
        iVar6 = 0x1804b51a0;
        do {
            uVar1 = *(uint16_t *)(iVar6 + 0x18);
            uVar2 = *in_RCX;
            if (((((uVar1 & 8) == 0) || ((uVar2 & 8) != 0)) && (((uVar1 & 4) == 0 || ((uVar2 & 4) != 0)))) &&
               (((uVar1 & 0x20) == 0 || ((uVar2 & 0x20) != 0)))) {
                if (((uVar2 & 1) != 0) && (iVar3 = *(int64_t *)(iVar6 + 0x10), iVar3 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + -iVar5) = 0x1801dcc9c;
                    iVar4 = func_0x000180498f10(iVar3, in_RDX);
                    if (iVar4 == 0) {
                        return iVar6;
                    }
                }
                if (((uVar2 & 2) != 0) && (iVar3 = *(int64_t *)(iVar6 + 8), iVar3 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + -iVar5) = 0x1801dccb7;
                    iVar4 = func_0x000180223670(iVar3, in_RDX);
                    if (iVar4 == 0) {
                        return iVar6;
                    }
                }
            }
            uVar7 = uVar7 + 1;
            iVar6 = iVar6 + 0x20;
        } while (uVar7 < 0x3d);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dccf0
// Address: 0x1801dccf0
// Size: 210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801dccf0(int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint8_t *in_RCX;
    char **in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dcd05;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_RDX != (char **)0x0) && (pcVar1 = *in_RDX, pcVar1 != (char *)0x0)) {
        if (*(int64_t *)(in_RCX + 8) == 0) {
            if ((*in_RCX & 1) != 0) {
                if (*pcVar1 != '-') {
                    return 0;
                }
                if (pcVar1[1] == '\0') {
                    return 0;
                }
                *in_RDX = pcVar1 + 1;
            }
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dcd32;
        uVar6 = fcn.180498cd0(pcVar1);
        if (*(uint64_t *)(in_RCX + 0x10) < uVar6) {
            if ((*in_RCX & 1) != 0) {
                uVar2 = *(undefined8 *)(in_RCX + 0x10);
                uVar3 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dcd4d;
                iVar4 = func_0x000180498f90(pcVar1, uVar3, uVar2);
                if (iVar4 != 0) {
                    return 0;
                }
            }
            if ((*in_RCX & 2) != 0) {
                uVar2 = *(undefined8 *)(in_RCX + 0x10);
                uVar3 = *(undefined8 *)(in_RCX + 8);
                pcVar1 = *in_RDX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dcd66;
                iVar4 = func_0x0001802237e0(pcVar1, uVar3, uVar2);
                if (iVar4 != 0) {
                    return 0;
                }
            }
            *in_RDX = *in_RDX + *(int64_t *)(in_RCX + 0x10);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dce40
// Address: 0x1801dce40
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801dce40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    int32_t in_EDX;
    undefined8 *puVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    uint32_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dce5e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar6 = 1;
    if (in_RCX != (char *)0x0) {
        uVar7 = 0;
        if ((in_EDX != -1) && ((uVar1 = 1, *in_RCX == '+' || (uVar1 = 0, *in_RCX == '-')))) {
            uVar6 = uVar1;
            in_RCX = in_RCX + 1;
            in_EDX = in_EDX + -1;
        }
        puVar5 = *(undefined8 **)(in_R8 + 0x18);
        if (*(int64_t *)(in_R8 + 0x1a) != 0) {
            do {
                if ((*in_R8 & *(uint32_t *)((int64_t)puVar5 + 0xc) & 0xc) != 0) {
                    if (in_EDX == -1) {
                        uVar2 = *puVar5;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dceb0;
                        iVar3 = func_0x000180498f10(uVar2, in_RCX);
                    } else {
                        if (*(int32_t *)(puVar5 + 1) != in_EDX) goto code_r0x0001801dcec9;
                        uVar2 = *puVar5;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dcec5;
                        iVar3 = func_0x0001802237e0(uVar2, in_RCX, (int64_t)in_EDX);
                    }
                    if (iVar3 == 0) {
                        uVar2 = puVar5[2];
                        uVar1 = *(undefined4 *)((int64_t)puVar5 + 0xc);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dcf03;
                        func_0x0001801dcdd0(in_R8, uVar1, uVar2, uVar6);
                        return 1;
                    }
                }
code_r0x0001801dcec9:
                uVar7 = uVar7 + 1;
                puVar5 = puVar5 + 3;
            } while (uVar7 < *(uint64_t *)(in_R8 + 0x1a));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dcf10
// Address: 0x1801dcf10
// Size: 510 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h

void fcn.1801dcf10(int64_t arg_28h, int64_t arg_80h)
{
    char cVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    uint32_t uVar8;
    code *in_RDX;
    int32_t iVar9;
    undefined8 unaff_RDI;
    int32_t iVar10;
    undefined8 in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801dcf22;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_28h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar7);
    in_R9 = in_R9 & 0xffffffff;
    if ((*(uint8_t *)(in_RCX + 0x16) & 0x10) == 0) {
        iVar9 = -1;
    } else {
        iVar9 = in_RCX[0x10];
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar7) = unaff_RDI;
    do {
        if ((in_R9 & 1) == 0) {
            pcVar2 = *(code **)(in_RCX + 10);
            uVar4 = *(undefined8 *)(in_RCX + 0xc);
            *(undefined (*) [16])((int64_t)&var_18h + iVar7) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dcf80;
            (*pcVar2)((int64_t)&var_18h + iVar7, uVar4, 0);
            cVar1 = *(char *)((int64_t)&var_20h + iVar7 + 1);
            uVar8 = ((int32_t)*(char *)((int64_t)&var_20h + iVar7) ^ in_RCX[0x16]) & 1U ^ in_RCX[0x16];
            *(undefined8 *)(in_RCX + 8) = *(undefined8 *)((int64_t)&var_18h + iVar7);
            uVar8 = (cVar1 * 2 ^ uVar8) & 2 ^ uVar8;
            cVar1 = *(char *)((int64_t)&var_20h + iVar7 + 2);
            in_RCX[0x16] = uVar8;
            if (((cVar1 != '\0') && ((uVar8 & 0x10) != 0)) && (*(int64_t *)(in_RCX + 0x14) != 0)) {
                if ((uVar8 & 0x20) == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dcfc9;
                    func_0x0001801f81d0(in_RCX + 0x10);
                    in_RCX[0x16] = in_RCX[0x16] | 0x20;
                    if ((in_RCX[0x16] & 0x20U) == 0) goto code_r0x0001801dcff3;
                }
                do {
                    uVar4 = *(undefined8 *)(in_RCX + 0xe);
                    uVar5 = *(undefined8 *)(in_RCX + 0x12);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dcfed;
                    func_0x00018026d610(uVar5, uVar4);
                } while ((*(uint8_t *)(in_RCX + 0x16) & 0x20) != 0);
            }
        } else {
            in_R9 = 0;
        }
code_r0x0001801dcff3:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dcff9;
        iVar6 = (*in_RDX)(in_R8);
        if (iVar6 != 0) break;
        iVar3 = *(int64_t *)(in_RCX + 8);
        uVar8 = in_RCX[0x16] & 1;
        if (((uVar8 == 0) && (((uint32_t)in_RCX[0x16] >> 1 & 1) == 0)) && (iVar3 == -1)) break;
        *(int64_t *)(in_RCX + 0x14) = *(int64_t *)(in_RCX + 0x14) + 1;
        if (*in_RCX == 0) {
            iVar6 = -1;
code_r0x0001801dd050:
            if ((in_RCX + 4 == (int32_t *)0x0) || (iVar10 = in_RCX[4], iVar10 == 0)) {
                iVar10 = -1;
            } else if ((iVar10 != 1) || (iVar10 = in_RCX[6], iVar10 == -1)) goto code_r0x0001801dd06b;
            *(undefined8 *)((int64_t)&var_8h + iVar7) = *(undefined8 *)(in_RCX + 0xe);
            *(int64_t *)(&stack0x00000000 + iVar7) = iVar3;
            *(int32_t *)(&stack0xfffffffffffffff8 + iVar7) = iVar9;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dd08b;
            iVar6 = func_0x0001801dd370(iVar6, uVar8, iVar10);
        } else {
            if ((*in_RCX == 1) && (iVar6 = in_RCX[2], iVar6 != -1)) goto code_r0x0001801dd050;
code_r0x0001801dd06b:
            iVar6 = 0;
        }
        iVar3 = *(int64_t *)(in_RCX + 0x14);
        *(int64_t *)(in_RCX + 0x14) = iVar3 + -1;
        if (((uint8_t)in_RCX[0x16] & 0x30) == 0x30) {
            if (iVar3 + -1 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dd0b5;
                func_0x0001801f8220(in_RCX + 0x10);
                uVar4 = *(undefined8 *)(in_RCX + 0x12);
                in_RCX[0x16] = in_RCX[0x16] & 0xffffffdf;
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dd0c2;
                func_0x00018026d390(uVar4);
            } else if ((in_RCX[0x16] & 0x20U) != 0) {
                do {
                    uVar4 = *(undefined8 *)(in_RCX + 0xe);
                    uVar5 = *(undefined8 *)(in_RCX + 0x12);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dd0dd;
                    func_0x00018026d610(uVar5, uVar4);
                } while ((*(uint8_t *)(in_RCX + 0x16) & 0x20) != 0);
            }
        }
    } while (iVar6 != 0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801dd102;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801dd130
// Address: 0x1801dd130
// Size: 56 bytes
// ============================================================
void fcn.1801dd130(int64_t arg1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801dd140;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        if ((*(uint8_t *)(arg1 + 0x58) & 0x10) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dd155;
            fcn.1801f7d40(arg1 + 0x40);
            *(uint32_t *)(arg1 + 0x58) = *(uint32_t *)(arg1 + 0x58) & 0xffffffef;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801dd162;
            fcn.18026d400(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801dd180
// Address: 0x1801dd180
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_aah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ah

undefined8 fcn.1801dd180(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd190;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar3 = *(undefined8 *)((int64_t)&arg_48h + iVar5);
    *in_RCX = 0;
    in_RCX[4] = 0;
    uVar2 = in_RCX[0x16];
    *(undefined8 *)(in_RCX + 8) = uVar3;
    uVar1 = *(uint8_t *)((int64_t)&arg_50h + iVar5);
    in_RCX[0x16] = uVar2 & 0xfffffff0;
    *(undefined8 *)(in_RCX + 10) = in_RDX;
    *(undefined8 *)(in_RCX + 0xc) = in_R8;
    *(undefined8 *)(in_RCX + 0xe) = in_R9;
    *(undefined8 *)(in_RCX + 0x14) = 0;
    if ((uVar1 & 1) == 0) {
        in_RCX[0x16] = uVar2 & 0xffffffe0;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dd1d2;
    iVar4 = fcn.1801f7d80(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)&arg_28h + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                          *(int64_t *)(&stack0x00000070 + iVar5), *(int64_t *)(&stack0x00000078 + iVar5));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dd1db;
        iVar6 = fcn.18026d4a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
        *(int64_t *)(in_RCX + 0x12) = iVar6;
        if (iVar6 != 0) {
            in_RCX[0x16] = in_RCX[0x16] | 0x10;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dd1ed;
        fcn.1801f7d40(in_RCX + 0x10);
    }
    return 0;
}

