// Chunk 189 - 50 functions

// ============================================================
// Function: FUN_180253666
// Address: 0x180253666
// Size: 331 bytes
// ============================================================
undefined8
fcn.180253666(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    undefined8 uVar5;
    
    piVar1 = *(int64_t **)(arg2 + 0x40);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    if ((piVar2 == (int64_t *)0x0) || (piVar1 == (int64_t *)0x0)) {
        func_0x000180229480();
        uVar4 = 0x167;
code_r0x00018025377c:
        func_0x0001802295a0(0x1804e5c10, uVar4, 0x1804e5c40);
        uVar4 = 0x78;
    } else {
        if ((*piVar2 != 0) || (*piVar1 != 0)) {
            func_0x000180229480();
            func_0x0001802295a0(0x1804e5c10, 0x170, 0x1804e5c40);
            uVar5 = 0x1804e5c88;
            uVar4 = 0x7b;
            goto code_r0x000180253790;
        }
        if (((uint64_t)piVar2[6] < 0x400) || ((uint64_t)piVar1[6] < 0x400)) {
            func_0x000180229480();
            uVar4 = 0x177;
            goto code_r0x00018025377c;
        }
        if ((piVar2[2] == piVar2[6]) || (iVar3 = func_0x0001802540d0(piVar2 + 1), iVar3 != 0)) {
            if ((piVar1[2] != piVar1[6]) && (iVar3 = func_0x0001802540d0(piVar1 + 1), iVar3 == 0)) {
                func_0x000180229480();
                func_0x0001802295a0(0x1804e5c10, 0x183, 0x1804e5c40);
                func_0x0001802296d0(0x20, 0x80020, 0);
                func_0x000180254090(piVar2 + 1);
                return 0;
            }
            *piVar2 = unaff_RSI;
            *piVar1 = unaff_RBP;
            *(uint32_t *)(piVar2 + 0xb) = *(uint32_t *)(piVar2 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar1 + 0xb) = *(uint32_t *)(piVar1 + 0xb) | 4;
            *(undefined4 *)(unaff_RBP + 0x28) = 1;
            *(undefined4 *)(unaff_RSI + 0x28) = 1;
            return 1;
        }
        func_0x000180229480();
        func_0x0001802295a0(0x1804e5c10, 0x17d, 0x1804e5c40);
        uVar4 = 0x80020;
    }
    uVar5 = 0;
code_r0x000180253790:
    func_0x0001802296d0(0x20, uVar4, uVar5);
    return 0;
}

// ============================================================
// Function: FUN_1802537b1
// Address: 0x1802537b1
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h
// WARNING: Variable defined which should be unmapped: arg_38h

undefined8
fcn.180253666(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    undefined8 uVar5;
    
    piVar1 = *(int64_t **)(arg2 + 0x40);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    if ((piVar2 == (int64_t *)0x0) || (piVar1 == (int64_t *)0x0)) {
        func_0x000180229480();
        uVar4 = 0x167;
code_r0x00018025377c:
        func_0x0001802295a0(0x1804e5c10, uVar4, 0x1804e5c40);
        uVar4 = 0x78;
    } else {
        if ((*piVar2 != 0) || (*piVar1 != 0)) {
            func_0x000180229480();
            func_0x0001802295a0(0x1804e5c10, 0x170, 0x1804e5c40);
            uVar5 = 0x1804e5c88;
            uVar4 = 0x7b;
            goto code_r0x000180253790;
        }
        if (((uint64_t)piVar2[6] < 0x400) || ((uint64_t)piVar1[6] < 0x400)) {
            func_0x000180229480();
            uVar4 = 0x177;
            goto code_r0x00018025377c;
        }
        if ((piVar2[2] == piVar2[6]) || (iVar3 = func_0x0001802540d0(piVar2 + 1), iVar3 != 0)) {
            if ((piVar1[2] != piVar1[6]) && (iVar3 = func_0x0001802540d0(piVar1 + 1), iVar3 == 0)) {
                func_0x000180229480();
                func_0x0001802295a0(0x1804e5c10, 0x183, 0x1804e5c40);
                func_0x0001802296d0(0x20, 0x80020, 0);
                func_0x000180254090(piVar2 + 1);
                return 0;
            }
            *piVar2 = unaff_RSI;
            *piVar1 = unaff_RBP;
            *(uint32_t *)(piVar2 + 0xb) = *(uint32_t *)(piVar2 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar1 + 0xb) = *(uint32_t *)(piVar1 + 0xb) | 4;
            *(undefined4 *)(unaff_RBP + 0x28) = 1;
            *(undefined4 *)(unaff_RSI + 0x28) = 1;
            return 1;
        }
        func_0x000180229480();
        func_0x0001802295a0(0x1804e5c10, 0x17d, 0x1804e5c40);
        uVar4 = 0x80020;
    }
    uVar5 = 0;
code_r0x000180253790:
    func_0x0001802296d0(0x20, uVar4, uVar5);
    return 0;
}

// ============================================================
// Function: FUN_1802537ef
// Address: 0x1802537ef
// Size: 98 bytes
// ============================================================
undefined8 fcn.1802537ef(int64_t arg_40h)
{
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000038;
    int64_t in_stack_00000050;
    
    fcn.180229480(in_stack_00000020, in_stack_00000028);
    fcn.1802295a0(in_stack_00000020, in_stack_00000028, in_stack_00000030, in_stack_00000038, in_stack_00000050);
    fcn.1802296d0(arg_40h);
    return 0;
}

// ============================================================
// Function: FUN_180253860
// Address: 0x180253860
// Size: 122 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.180253860(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_f0h, int64_t arg_f8h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    int64_t iVar12;
    int64_t iVar13;
    int64_t in_RDX;
    uint64_t uVar14;
    undefined8 unaff_RBX;
    int64_t *piVar15;
    undefined8 unaff_RBP;
    uint64_t uVar16;
    undefined8 unaff_RSI;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t iVar19;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180253872;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_70h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    piVar4 = *(int64_t **)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_28h + iVar9) = *(undefined8 *)((int64_t)&arg_f0h + iVar9);
    *(int64_t *)((int64_t)&var_20h + iVar9) = in_R9;
    *(int64_t *)((int64_t)&var_8h + iVar9) = in_RDX;
    *(undefined8 *)(&stack0x00000000 + iVar9) = 0;
    if (*(int32_t *)((int64_t)&arg_f8h + iVar9) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802538c5;
        func_0x000180219ce0(extraout_XMM0_Da, 0xf);
        in_RDX = *(int64_t *)((int64_t)&var_8h + iVar9);
    }
    if (*(int32_t *)(in_RCX + 0x28) != 0) {
        *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_98h + iVar9) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_90h + iVar9) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_88h + iVar9) = unaff_R14;
        if (((piVar4 != (int64_t *)0x0) &&
            ((((piVar15 = piVar4, *piVar4 == 0 || (piVar15 = *(int64_t **)(*piVar4 + 0x40), piVar15 != (int64_t *)0x0))
              && (iVar18 = piVar15[1], iVar18 != 0)) && ((in_R8 == 0 || (in_RDX != 0)))))) &&
           ((in_R9 == 0 || ((*(uint8_t *)(piVar4 + 0xb) & 2) != 0)))) {
            iVar17 = (int64_t)&arg_30h + iVar9;
            *(int64_t *)((int64_t)&var_10h + iVar9) = piVar15[5];
            uVar16 = 0x40;
            iVar19 = 0;
            *(int64_t *)((int64_t)&var_18h + iVar9) = piVar15[3];
            do {
                iVar13 = piVar15[5];
                uVar11 = piVar15[3];
                uVar10 = piVar15[2] - iVar13;
                uVar14 = uVar11;
                if (uVar10 <= uVar11) {
                    uVar14 = uVar10;
                }
                if (uVar14 == 0) break;
                uVar10 = uVar16;
                if (uVar14 <= uVar16) {
                    uVar10 = uVar14;
                }
                if (iVar17 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802539ef;
                    func_0x000180498030(iVar17, iVar13 + iVar18, uVar10);
                    uVar11 = piVar15[3];
                    iVar18 = piVar15[1];
                }
                if ((uVar10 <= (uint64_t)(piVar15[2] - piVar15[5])) && (uVar10 <= uVar11)) {
                    iVar12 = piVar15[5] + uVar10;
                    iVar13 = 0;
                    if (iVar12 != piVar15[2]) {
                        iVar13 = iVar12;
                    }
                    piVar15[5] = iVar13;
                    piVar15[3] = piVar15[3] - uVar10;
                }
                if (iVar17 != 0) {
                    iVar17 = iVar17 + uVar10;
                }
                iVar19 = iVar19 + uVar10;
                uVar16 = uVar16 - uVar10;
            } while (uVar16 != 0);
            if (iVar19 == 0) {
                if (*(int32_t *)((int64_t)&arg_f8h + iVar9) == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253a53;
                    func_0x00018021b250(in_RCX, 9);
                }
            } else if (iVar19 == 0x40) {
                uVar16 = *(uint64_t *)((int64_t)&arg_30h + iVar9);
                uVar11 = uVar16;
                if ((uVar16 < in_R8) || (uVar11 = in_R8, uVar16 <= in_R8)) {
                    uVar16 = *(uint64_t *)(&stack0x00000000 + iVar9);
                    in_R8 = uVar11;
                } else {
                    uVar16 = uVar16 - in_R8;
                    uVar2 = *(uint8_t *)(piVar4 + 0xb);
                    *(uint64_t *)(&stack0x00000000 + iVar9) = uVar16;
                    if ((uVar2 & 1) != 0) {
                        piVar15[5] = *(int64_t *)((int64_t)&var_10h + iVar9);
                        piVar15[3] = *(int64_t *)((int64_t)&var_18h + iVar9);
                        goto code_r0x000180253938;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253a97;
                uVar11 = func_0x000180253be0(piVar15, *(undefined8 *)((int64_t)&var_8h + iVar9), in_R8);
                if (uVar11 == in_R8) {
                    if (uVar16 != 0) {
                        iVar18 = 0;
                        iVar17 = 0;
                        do {
                            iVar19 = piVar15[1];
                            uVar11 = piVar15[3];
                            if ((uint64_t)(piVar15[2] - piVar15[5]) <= (uint64_t)piVar15[3]) {
                                uVar11 = piVar15[2] - piVar15[5];
                            }
                            iVar13 = piVar15[5];
                            if (uVar11 == 0) break;
                            uVar14 = uVar16;
                            if (uVar11 <= uVar16) {
                                uVar14 = uVar11;
                            }
                            if (iVar18 != 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253afa;
                                func_0x000180498030(iVar18, iVar19 + iVar13, uVar14);
                            }
                            if ((uVar14 <= (uint64_t)(piVar15[2] - piVar15[5])) && (uVar14 <= (uint64_t)piVar15[3])) {
                                iVar13 = piVar15[5] + uVar14;
                                iVar19 = 0;
                                if (iVar13 != piVar15[2]) {
                                    iVar19 = iVar13;
                                }
                                piVar15[5] = iVar19;
                                piVar15[3] = piVar15[3] - uVar14;
                            }
                            if (iVar18 != 0) {
                                iVar18 = iVar18 + uVar14;
                            }
                            iVar17 = iVar17 + uVar14;
                            uVar16 = uVar16 - uVar14;
                        } while (uVar16 != 0);
                        if (iVar17 != *(int64_t *)(&stack0x00000000 + iVar9)) goto code_r0x000180253938;
                    }
                    puVar5 = *(undefined4 **)((int64_t)&var_20h + iVar9);
                    if (puVar5 != (undefined4 *)0x0) {
                        uVar6 = *(undefined4 *)(&stack0x00000058 + iVar9);
                        uVar7 = *(undefined4 *)(&stack0x0000005c + iVar9);
                        uVar8 = *(undefined4 *)(&stack0x00000060 + iVar9);
                        uVar3 = *(undefined4 *)(&stack0x0000006c + iVar9);
                        uVar1 = *(undefined8 *)(&stack0x00000064 + iVar9);
                        *puVar5 = *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4);
                        puVar5[1] = uVar6;
                        puVar5[2] = uVar7;
                        puVar5[3] = uVar8;
                        *(undefined8 *)(puVar5 + 4) = uVar1;
                        puVar5[6] = uVar3;
                    }
                    puVar5 = *(undefined4 **)((int64_t)&arg_28h + iVar9);
                    if (puVar5 != (undefined4 *)0x0) {
                        uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4);
                        uVar7 = *(undefined4 *)(&stack0x00000040 + iVar9);
                        uVar8 = *(undefined4 *)(&stack0x00000044 + iVar9);
                        uVar3 = *(undefined4 *)((int64_t)&arg_50h + iVar9);
                        uVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar9);
                        *puVar5 = *(undefined4 *)((int64_t)&arg_38h + iVar9);
                        puVar5[1] = uVar6;
                        puVar5[2] = uVar7;
                        puVar5[3] = uVar8;
                        *(undefined8 *)(puVar5 + 4) = uVar1;
                        puVar5[6] = uVar3;
                    }
                }
            }
        }
    }
code_r0x000180253938:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253948;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_1802538da
// Address: 0x1802538da
// Size: 94 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.180253860(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_f0h, int64_t arg_f8h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    int64_t iVar12;
    int64_t iVar13;
    int64_t in_RDX;
    uint64_t uVar14;
    undefined8 unaff_RBX;
    int64_t *piVar15;
    undefined8 unaff_RBP;
    uint64_t uVar16;
    undefined8 unaff_RSI;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t iVar19;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180253872;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_70h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    piVar4 = *(int64_t **)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_28h + iVar9) = *(undefined8 *)((int64_t)&arg_f0h + iVar9);
    *(int64_t *)((int64_t)&var_20h + iVar9) = in_R9;
    *(int64_t *)((int64_t)&var_8h + iVar9) = in_RDX;
    *(undefined8 *)(&stack0x00000000 + iVar9) = 0;
    if (*(int32_t *)((int64_t)&arg_f8h + iVar9) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802538c5;
        func_0x000180219ce0(extraout_XMM0_Da, 0xf);
        in_RDX = *(int64_t *)((int64_t)&var_8h + iVar9);
    }
    if (*(int32_t *)(in_RCX + 0x28) != 0) {
        *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_98h + iVar9) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_90h + iVar9) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_88h + iVar9) = unaff_R14;
        if (((piVar4 != (int64_t *)0x0) &&
            ((((piVar15 = piVar4, *piVar4 == 0 || (piVar15 = *(int64_t **)(*piVar4 + 0x40), piVar15 != (int64_t *)0x0))
              && (iVar18 = piVar15[1], iVar18 != 0)) && ((in_R8 == 0 || (in_RDX != 0)))))) &&
           ((in_R9 == 0 || ((*(uint8_t *)(piVar4 + 0xb) & 2) != 0)))) {
            iVar17 = (int64_t)&arg_30h + iVar9;
            *(int64_t *)((int64_t)&var_10h + iVar9) = piVar15[5];
            uVar16 = 0x40;
            iVar19 = 0;
            *(int64_t *)((int64_t)&var_18h + iVar9) = piVar15[3];
            do {
                iVar13 = piVar15[5];
                uVar11 = piVar15[3];
                uVar10 = piVar15[2] - iVar13;
                uVar14 = uVar11;
                if (uVar10 <= uVar11) {
                    uVar14 = uVar10;
                }
                if (uVar14 == 0) break;
                uVar10 = uVar16;
                if (uVar14 <= uVar16) {
                    uVar10 = uVar14;
                }
                if (iVar17 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802539ef;
                    func_0x000180498030(iVar17, iVar13 + iVar18, uVar10);
                    uVar11 = piVar15[3];
                    iVar18 = piVar15[1];
                }
                if ((uVar10 <= (uint64_t)(piVar15[2] - piVar15[5])) && (uVar10 <= uVar11)) {
                    iVar12 = piVar15[5] + uVar10;
                    iVar13 = 0;
                    if (iVar12 != piVar15[2]) {
                        iVar13 = iVar12;
                    }
                    piVar15[5] = iVar13;
                    piVar15[3] = piVar15[3] - uVar10;
                }
                if (iVar17 != 0) {
                    iVar17 = iVar17 + uVar10;
                }
                iVar19 = iVar19 + uVar10;
                uVar16 = uVar16 - uVar10;
            } while (uVar16 != 0);
            if (iVar19 == 0) {
                if (*(int32_t *)((int64_t)&arg_f8h + iVar9) == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253a53;
                    func_0x00018021b250(in_RCX, 9);
                }
            } else if (iVar19 == 0x40) {
                uVar16 = *(uint64_t *)((int64_t)&arg_30h + iVar9);
                uVar11 = uVar16;
                if ((uVar16 < in_R8) || (uVar11 = in_R8, uVar16 <= in_R8)) {
                    uVar16 = *(uint64_t *)(&stack0x00000000 + iVar9);
                    in_R8 = uVar11;
                } else {
                    uVar16 = uVar16 - in_R8;
                    uVar2 = *(uint8_t *)(piVar4 + 0xb);
                    *(uint64_t *)(&stack0x00000000 + iVar9) = uVar16;
                    if ((uVar2 & 1) != 0) {
                        piVar15[5] = *(int64_t *)((int64_t)&var_10h + iVar9);
                        piVar15[3] = *(int64_t *)((int64_t)&var_18h + iVar9);
                        goto code_r0x000180253938;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253a97;
                uVar11 = func_0x000180253be0(piVar15, *(undefined8 *)((int64_t)&var_8h + iVar9), in_R8);
                if (uVar11 == in_R8) {
                    if (uVar16 != 0) {
                        iVar18 = 0;
                        iVar17 = 0;
                        do {
                            iVar19 = piVar15[1];
                            uVar11 = piVar15[3];
                            if ((uint64_t)(piVar15[2] - piVar15[5]) <= (uint64_t)piVar15[3]) {
                                uVar11 = piVar15[2] - piVar15[5];
                            }
                            iVar13 = piVar15[5];
                            if (uVar11 == 0) break;
                            uVar14 = uVar16;
                            if (uVar11 <= uVar16) {
                                uVar14 = uVar11;
                            }
                            if (iVar18 != 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253afa;
                                func_0x000180498030(iVar18, iVar19 + iVar13, uVar14);
                            }
                            if ((uVar14 <= (uint64_t)(piVar15[2] - piVar15[5])) && (uVar14 <= (uint64_t)piVar15[3])) {
                                iVar13 = piVar15[5] + uVar14;
                                iVar19 = 0;
                                if (iVar13 != piVar15[2]) {
                                    iVar19 = iVar13;
                                }
                                piVar15[5] = iVar19;
                                piVar15[3] = piVar15[3] - uVar14;
                            }
                            if (iVar18 != 0) {
                                iVar18 = iVar18 + uVar14;
                            }
                            iVar17 = iVar17 + uVar14;
                            uVar16 = uVar16 - uVar14;
                        } while (uVar16 != 0);
                        if (iVar17 != *(int64_t *)(&stack0x00000000 + iVar9)) goto code_r0x000180253938;
                    }
                    puVar5 = *(undefined4 **)((int64_t)&var_20h + iVar9);
                    if (puVar5 != (undefined4 *)0x0) {
                        uVar6 = *(undefined4 *)(&stack0x00000058 + iVar9);
                        uVar7 = *(undefined4 *)(&stack0x0000005c + iVar9);
                        uVar8 = *(undefined4 *)(&stack0x00000060 + iVar9);
                        uVar3 = *(undefined4 *)(&stack0x0000006c + iVar9);
                        uVar1 = *(undefined8 *)(&stack0x00000064 + iVar9);
                        *puVar5 = *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4);
                        puVar5[1] = uVar6;
                        puVar5[2] = uVar7;
                        puVar5[3] = uVar8;
                        *(undefined8 *)(puVar5 + 4) = uVar1;
                        puVar5[6] = uVar3;
                    }
                    puVar5 = *(undefined4 **)((int64_t)&arg_28h + iVar9);
                    if (puVar5 != (undefined4 *)0x0) {
                        uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4);
                        uVar7 = *(undefined4 *)(&stack0x00000040 + iVar9);
                        uVar8 = *(undefined4 *)(&stack0x00000044 + iVar9);
                        uVar3 = *(undefined4 *)((int64_t)&arg_50h + iVar9);
                        uVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar9);
                        *puVar5 = *(undefined4 *)((int64_t)&arg_38h + iVar9);
                        puVar5[1] = uVar6;
                        puVar5[2] = uVar7;
                        puVar5[3] = uVar8;
                        *(undefined8 *)(puVar5 + 4) = uVar1;
                        puVar5[6] = uVar3;
                    }
                }
            }
        }
    }
code_r0x000180253938:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253948;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_180253938
// Address: 0x180253938
// Size: 31 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.180253860(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_f0h, int64_t arg_f8h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    int64_t iVar12;
    int64_t iVar13;
    int64_t in_RDX;
    uint64_t uVar14;
    undefined8 unaff_RBX;
    int64_t *piVar15;
    undefined8 unaff_RBP;
    uint64_t uVar16;
    undefined8 unaff_RSI;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t iVar19;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180253872;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_70h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    piVar4 = *(int64_t **)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_28h + iVar9) = *(undefined8 *)((int64_t)&arg_f0h + iVar9);
    *(int64_t *)((int64_t)&var_20h + iVar9) = in_R9;
    *(int64_t *)((int64_t)&var_8h + iVar9) = in_RDX;
    *(undefined8 *)(&stack0x00000000 + iVar9) = 0;
    if (*(int32_t *)((int64_t)&arg_f8h + iVar9) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802538c5;
        func_0x000180219ce0(extraout_XMM0_Da, 0xf);
        in_RDX = *(int64_t *)((int64_t)&var_8h + iVar9);
    }
    if (*(int32_t *)(in_RCX + 0x28) != 0) {
        *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_98h + iVar9) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_90h + iVar9) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_88h + iVar9) = unaff_R14;
        if (((piVar4 != (int64_t *)0x0) &&
            ((((piVar15 = piVar4, *piVar4 == 0 || (piVar15 = *(int64_t **)(*piVar4 + 0x40), piVar15 != (int64_t *)0x0))
              && (iVar18 = piVar15[1], iVar18 != 0)) && ((in_R8 == 0 || (in_RDX != 0)))))) &&
           ((in_R9 == 0 || ((*(uint8_t *)(piVar4 + 0xb) & 2) != 0)))) {
            iVar17 = (int64_t)&arg_30h + iVar9;
            *(int64_t *)((int64_t)&var_10h + iVar9) = piVar15[5];
            uVar16 = 0x40;
            iVar19 = 0;
            *(int64_t *)((int64_t)&var_18h + iVar9) = piVar15[3];
            do {
                iVar13 = piVar15[5];
                uVar11 = piVar15[3];
                uVar10 = piVar15[2] - iVar13;
                uVar14 = uVar11;
                if (uVar10 <= uVar11) {
                    uVar14 = uVar10;
                }
                if (uVar14 == 0) break;
                uVar10 = uVar16;
                if (uVar14 <= uVar16) {
                    uVar10 = uVar14;
                }
                if (iVar17 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802539ef;
                    func_0x000180498030(iVar17, iVar13 + iVar18, uVar10);
                    uVar11 = piVar15[3];
                    iVar18 = piVar15[1];
                }
                if ((uVar10 <= (uint64_t)(piVar15[2] - piVar15[5])) && (uVar10 <= uVar11)) {
                    iVar12 = piVar15[5] + uVar10;
                    iVar13 = 0;
                    if (iVar12 != piVar15[2]) {
                        iVar13 = iVar12;
                    }
                    piVar15[5] = iVar13;
                    piVar15[3] = piVar15[3] - uVar10;
                }
                if (iVar17 != 0) {
                    iVar17 = iVar17 + uVar10;
                }
                iVar19 = iVar19 + uVar10;
                uVar16 = uVar16 - uVar10;
            } while (uVar16 != 0);
            if (iVar19 == 0) {
                if (*(int32_t *)((int64_t)&arg_f8h + iVar9) == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253a53;
                    func_0x00018021b250(in_RCX, 9);
                }
            } else if (iVar19 == 0x40) {
                uVar16 = *(uint64_t *)((int64_t)&arg_30h + iVar9);
                uVar11 = uVar16;
                if ((uVar16 < in_R8) || (uVar11 = in_R8, uVar16 <= in_R8)) {
                    uVar16 = *(uint64_t *)(&stack0x00000000 + iVar9);
                    in_R8 = uVar11;
                } else {
                    uVar16 = uVar16 - in_R8;
                    uVar2 = *(uint8_t *)(piVar4 + 0xb);
                    *(uint64_t *)(&stack0x00000000 + iVar9) = uVar16;
                    if ((uVar2 & 1) != 0) {
                        piVar15[5] = *(int64_t *)((int64_t)&var_10h + iVar9);
                        piVar15[3] = *(int64_t *)((int64_t)&var_18h + iVar9);
                        goto code_r0x000180253938;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253a97;
                uVar11 = func_0x000180253be0(piVar15, *(undefined8 *)((int64_t)&var_8h + iVar9), in_R8);
                if (uVar11 == in_R8) {
                    if (uVar16 != 0) {
                        iVar18 = 0;
                        iVar17 = 0;
                        do {
                            iVar19 = piVar15[1];
                            uVar11 = piVar15[3];
                            if ((uint64_t)(piVar15[2] - piVar15[5]) <= (uint64_t)piVar15[3]) {
                                uVar11 = piVar15[2] - piVar15[5];
                            }
                            iVar13 = piVar15[5];
                            if (uVar11 == 0) break;
                            uVar14 = uVar16;
                            if (uVar11 <= uVar16) {
                                uVar14 = uVar11;
                            }
                            if (iVar18 != 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253afa;
                                func_0x000180498030(iVar18, iVar19 + iVar13, uVar14);
                            }
                            if ((uVar14 <= (uint64_t)(piVar15[2] - piVar15[5])) && (uVar14 <= (uint64_t)piVar15[3])) {
                                iVar13 = piVar15[5] + uVar14;
                                iVar19 = 0;
                                if (iVar13 != piVar15[2]) {
                                    iVar19 = iVar13;
                                }
                                piVar15[5] = iVar19;
                                piVar15[3] = piVar15[3] - uVar14;
                            }
                            if (iVar18 != 0) {
                                iVar18 = iVar18 + uVar14;
                            }
                            iVar17 = iVar17 + uVar14;
                            uVar16 = uVar16 - uVar14;
                        } while (uVar16 != 0);
                        if (iVar17 != *(int64_t *)(&stack0x00000000 + iVar9)) goto code_r0x000180253938;
                    }
                    puVar5 = *(undefined4 **)((int64_t)&var_20h + iVar9);
                    if (puVar5 != (undefined4 *)0x0) {
                        uVar6 = *(undefined4 *)(&stack0x00000058 + iVar9);
                        uVar7 = *(undefined4 *)(&stack0x0000005c + iVar9);
                        uVar8 = *(undefined4 *)(&stack0x00000060 + iVar9);
                        uVar3 = *(undefined4 *)(&stack0x0000006c + iVar9);
                        uVar1 = *(undefined8 *)(&stack0x00000064 + iVar9);
                        *puVar5 = *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4);
                        puVar5[1] = uVar6;
                        puVar5[2] = uVar7;
                        puVar5[3] = uVar8;
                        *(undefined8 *)(puVar5 + 4) = uVar1;
                        puVar5[6] = uVar3;
                    }
                    puVar5 = *(undefined4 **)((int64_t)&arg_28h + iVar9);
                    if (puVar5 != (undefined4 *)0x0) {
                        uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4);
                        uVar7 = *(undefined4 *)(&stack0x00000040 + iVar9);
                        uVar8 = *(undefined4 *)(&stack0x00000044 + iVar9);
                        uVar3 = *(undefined4 *)((int64_t)&arg_50h + iVar9);
                        uVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar9);
                        *puVar5 = *(undefined4 *)((int64_t)&arg_38h + iVar9);
                        puVar5[1] = uVar6;
                        puVar5[2] = uVar7;
                        puVar5[3] = uVar8;
                        *(undefined8 *)(puVar5 + 4) = uVar1;
                        puVar5[6] = uVar3;
                    }
                }
            }
        }
    }
code_r0x000180253938:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253948;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_180253957
// Address: 0x180253957
// Size: 642 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.180253860(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
                  int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_f0h, int64_t arg_f8h)
{
    undefined8 uVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t in_RCX;
    int64_t iVar12;
    int64_t iVar13;
    int64_t in_RDX;
    uint64_t uVar14;
    undefined8 unaff_RBX;
    int64_t *piVar15;
    undefined8 unaff_RBP;
    uint64_t uVar16;
    undefined8 unaff_RSI;
    int64_t iVar17;
    int64_t iVar18;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t iVar19;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180253872;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_70h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9);
    piVar4 = *(int64_t **)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_28h + iVar9) = *(undefined8 *)((int64_t)&arg_f0h + iVar9);
    *(int64_t *)((int64_t)&var_20h + iVar9) = in_R9;
    *(int64_t *)((int64_t)&var_8h + iVar9) = in_RDX;
    *(undefined8 *)(&stack0x00000000 + iVar9) = 0;
    if (*(int32_t *)((int64_t)&arg_f8h + iVar9) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802538c5;
        func_0x000180219ce0(extraout_XMM0_Da, 0xf);
        in_RDX = *(int64_t *)((int64_t)&var_8h + iVar9);
    }
    if (*(int32_t *)(in_RCX + 0x28) != 0) {
        *(undefined8 *)((int64_t)&arg_a0h + iVar9) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_98h + iVar9) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_90h + iVar9) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_88h + iVar9) = unaff_R14;
        if (((piVar4 != (int64_t *)0x0) &&
            ((((piVar15 = piVar4, *piVar4 == 0 || (piVar15 = *(int64_t **)(*piVar4 + 0x40), piVar15 != (int64_t *)0x0))
              && (iVar18 = piVar15[1], iVar18 != 0)) && ((in_R8 == 0 || (in_RDX != 0)))))) &&
           ((in_R9 == 0 || ((*(uint8_t *)(piVar4 + 0xb) & 2) != 0)))) {
            iVar17 = (int64_t)&arg_30h + iVar9;
            *(int64_t *)((int64_t)&var_10h + iVar9) = piVar15[5];
            uVar16 = 0x40;
            iVar19 = 0;
            *(int64_t *)((int64_t)&var_18h + iVar9) = piVar15[3];
            do {
                iVar13 = piVar15[5];
                uVar11 = piVar15[3];
                uVar10 = piVar15[2] - iVar13;
                uVar14 = uVar11;
                if (uVar10 <= uVar11) {
                    uVar14 = uVar10;
                }
                if (uVar14 == 0) break;
                uVar10 = uVar16;
                if (uVar14 <= uVar16) {
                    uVar10 = uVar14;
                }
                if (iVar17 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x1802539ef;
                    func_0x000180498030(iVar17, iVar13 + iVar18, uVar10);
                    uVar11 = piVar15[3];
                    iVar18 = piVar15[1];
                }
                if ((uVar10 <= (uint64_t)(piVar15[2] - piVar15[5])) && (uVar10 <= uVar11)) {
                    iVar12 = piVar15[5] + uVar10;
                    iVar13 = 0;
                    if (iVar12 != piVar15[2]) {
                        iVar13 = iVar12;
                    }
                    piVar15[5] = iVar13;
                    piVar15[3] = piVar15[3] - uVar10;
                }
                if (iVar17 != 0) {
                    iVar17 = iVar17 + uVar10;
                }
                iVar19 = iVar19 + uVar10;
                uVar16 = uVar16 - uVar10;
            } while (uVar16 != 0);
            if (iVar19 == 0) {
                if (*(int32_t *)((int64_t)&arg_f8h + iVar9) == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253a53;
                    func_0x00018021b250(in_RCX, 9);
                }
            } else if (iVar19 == 0x40) {
                uVar16 = *(uint64_t *)((int64_t)&arg_30h + iVar9);
                uVar11 = uVar16;
                if ((uVar16 < in_R8) || (uVar11 = in_R8, uVar16 <= in_R8)) {
                    uVar16 = *(uint64_t *)(&stack0x00000000 + iVar9);
                    in_R8 = uVar11;
                } else {
                    uVar16 = uVar16 - in_R8;
                    uVar2 = *(uint8_t *)(piVar4 + 0xb);
                    *(uint64_t *)(&stack0x00000000 + iVar9) = uVar16;
                    if ((uVar2 & 1) != 0) {
                        piVar15[5] = *(int64_t *)((int64_t)&var_10h + iVar9);
                        piVar15[3] = *(int64_t *)((int64_t)&var_18h + iVar9);
                        goto code_r0x000180253938;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253a97;
                uVar11 = func_0x000180253be0(piVar15, *(undefined8 *)((int64_t)&var_8h + iVar9), in_R8);
                if (uVar11 == in_R8) {
                    if (uVar16 != 0) {
                        iVar18 = 0;
                        iVar17 = 0;
                        do {
                            iVar19 = piVar15[1];
                            uVar11 = piVar15[3];
                            if ((uint64_t)(piVar15[2] - piVar15[5]) <= (uint64_t)piVar15[3]) {
                                uVar11 = piVar15[2] - piVar15[5];
                            }
                            iVar13 = piVar15[5];
                            if (uVar11 == 0) break;
                            uVar14 = uVar16;
                            if (uVar11 <= uVar16) {
                                uVar14 = uVar11;
                            }
                            if (iVar18 != 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253afa;
                                func_0x000180498030(iVar18, iVar19 + iVar13, uVar14);
                            }
                            if ((uVar14 <= (uint64_t)(piVar15[2] - piVar15[5])) && (uVar14 <= (uint64_t)piVar15[3])) {
                                iVar13 = piVar15[5] + uVar14;
                                iVar19 = 0;
                                if (iVar13 != piVar15[2]) {
                                    iVar19 = iVar13;
                                }
                                piVar15[5] = iVar19;
                                piVar15[3] = piVar15[3] - uVar14;
                            }
                            if (iVar18 != 0) {
                                iVar18 = iVar18 + uVar14;
                            }
                            iVar17 = iVar17 + uVar14;
                            uVar16 = uVar16 - uVar14;
                        } while (uVar16 != 0);
                        if (iVar17 != *(int64_t *)(&stack0x00000000 + iVar9)) goto code_r0x000180253938;
                    }
                    puVar5 = *(undefined4 **)((int64_t)&var_20h + iVar9);
                    if (puVar5 != (undefined4 *)0x0) {
                        uVar6 = *(undefined4 *)(&stack0x00000058 + iVar9);
                        uVar7 = *(undefined4 *)(&stack0x0000005c + iVar9);
                        uVar8 = *(undefined4 *)(&stack0x00000060 + iVar9);
                        uVar3 = *(undefined4 *)(&stack0x0000006c + iVar9);
                        uVar1 = *(undefined8 *)(&stack0x00000064 + iVar9);
                        *puVar5 = *(undefined4 *)((int64_t)&arg_50h + iVar9 + 4);
                        puVar5[1] = uVar6;
                        puVar5[2] = uVar7;
                        puVar5[3] = uVar8;
                        *(undefined8 *)(puVar5 + 4) = uVar1;
                        puVar5[6] = uVar3;
                    }
                    puVar5 = *(undefined4 **)((int64_t)&arg_28h + iVar9);
                    if (puVar5 != (undefined4 *)0x0) {
                        uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar9 + 4);
                        uVar7 = *(undefined4 *)(&stack0x00000040 + iVar9);
                        uVar8 = *(undefined4 *)(&stack0x00000044 + iVar9);
                        uVar3 = *(undefined4 *)((int64_t)&arg_50h + iVar9);
                        uVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar9);
                        *puVar5 = *(undefined4 *)((int64_t)&arg_38h + iVar9);
                        puVar5[1] = uVar6;
                        puVar5[2] = uVar7;
                        puVar5[3] = uVar8;
                        *(undefined8 *)(puVar5 + 4) = uVar1;
                        puVar5[6] = uVar3;
                    }
                }
            }
        }
    }
code_r0x000180253938:
    *(undefined8 *)((int64_t)&uStack_28 + iVar9) = 0x180253948;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar9));
    return;
}

// ============================================================
// Function: FUN_180253be0
// Address: 0x180253be0
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180253be0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t in_R8;
    int64_t iVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180253bfb;
    iVar1 = fcn.18045a350();
    iVar7 = 0;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar1) = unaff_RBX;
        do {
            uVar6 = *(uint64_t *)(in_RCX + 0x18);
            iVar3 = *(int64_t *)(in_RCX + 0x28);
            uVar2 = *(int64_t *)(in_RCX + 0x10) - iVar3;
            uVar4 = uVar6;
            if (uVar2 <= uVar6) {
                uVar4 = uVar2;
            }
            if (uVar4 == 0) {
                return iVar7;
            }
            uVar2 = in_R8;
            if (uVar4 <= in_R8) {
                uVar2 = uVar4;
            }
            if (in_RDX != 0) {
                iVar5 = *(int64_t *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180253c5f;
                func_0x000180498030(in_RDX, iVar5 + iVar3, uVar2);
                uVar6 = *(uint64_t *)(in_RCX + 0x18);
            }
            if ((uVar2 <= (uint64_t)(*(int64_t *)(in_RCX + 0x10) - *(int64_t *)(in_RCX + 0x28))) && (uVar2 <= uVar6)) {
                iVar5 = *(int64_t *)(in_RCX + 0x28) + uVar2;
                iVar3 = 0;
                if (iVar5 != *(int64_t *)(in_RCX + 0x10)) {
                    iVar3 = iVar5;
                }
                *(int64_t *)(in_RCX + 0x28) = iVar3;
                *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) - uVar2;
            }
            iVar7 = iVar7 + uVar2;
            iVar3 = uVar2 + in_RDX;
            if (in_RDX == 0) {
                iVar3 = in_RDX;
            }
            in_R8 = in_R8 - uVar2;
            in_RDX = iVar3;
        } while (in_R8 != 0);
    }
    return iVar7;
}

// ============================================================
// Function: FUN_180253c13
// Address: 0x180253c13
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180253be0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t in_R8;
    int64_t iVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180253bfb;
    iVar1 = fcn.18045a350();
    iVar7 = 0;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar1) = unaff_RBX;
        do {
            uVar6 = *(uint64_t *)(in_RCX + 0x18);
            iVar3 = *(int64_t *)(in_RCX + 0x28);
            uVar2 = *(int64_t *)(in_RCX + 0x10) - iVar3;
            uVar4 = uVar6;
            if (uVar2 <= uVar6) {
                uVar4 = uVar2;
            }
            if (uVar4 == 0) {
                return iVar7;
            }
            uVar2 = in_R8;
            if (uVar4 <= in_R8) {
                uVar2 = uVar4;
            }
            if (in_RDX != 0) {
                iVar5 = *(int64_t *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180253c5f;
                func_0x000180498030(in_RDX, iVar5 + iVar3, uVar2);
                uVar6 = *(uint64_t *)(in_RCX + 0x18);
            }
            if ((uVar2 <= (uint64_t)(*(int64_t *)(in_RCX + 0x10) - *(int64_t *)(in_RCX + 0x28))) && (uVar2 <= uVar6)) {
                iVar5 = *(int64_t *)(in_RCX + 0x28) + uVar2;
                iVar3 = 0;
                if (iVar5 != *(int64_t *)(in_RCX + 0x10)) {
                    iVar3 = iVar5;
                }
                *(int64_t *)(in_RCX + 0x28) = iVar3;
                *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) - uVar2;
            }
            iVar7 = iVar7 + uVar2;
            iVar3 = uVar2 + in_RDX;
            if (in_RDX == 0) {
                iVar3 = in_RDX;
            }
            in_R8 = in_R8 - uVar2;
            in_RDX = iVar3;
        } while (in_R8 != 0);
    }
    return iVar7;
}

// ============================================================
// Function: FUN_180253cb1
// Address: 0x180253cb1
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180253be0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t in_R8;
    int64_t iVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180253bfb;
    iVar1 = fcn.18045a350();
    iVar7 = 0;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar1) = unaff_RBX;
        do {
            uVar6 = *(uint64_t *)(in_RCX + 0x18);
            iVar3 = *(int64_t *)(in_RCX + 0x28);
            uVar2 = *(int64_t *)(in_RCX + 0x10) - iVar3;
            uVar4 = uVar6;
            if (uVar2 <= uVar6) {
                uVar4 = uVar2;
            }
            if (uVar4 == 0) {
                return iVar7;
            }
            uVar2 = in_R8;
            if (uVar4 <= in_R8) {
                uVar2 = uVar4;
            }
            if (in_RDX != 0) {
                iVar5 = *(int64_t *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180253c5f;
                func_0x000180498030(in_RDX, iVar5 + iVar3, uVar2);
                uVar6 = *(uint64_t *)(in_RCX + 0x18);
            }
            if ((uVar2 <= (uint64_t)(*(int64_t *)(in_RCX + 0x10) - *(int64_t *)(in_RCX + 0x28))) && (uVar2 <= uVar6)) {
                iVar5 = *(int64_t *)(in_RCX + 0x28) + uVar2;
                iVar3 = 0;
                if (iVar5 != *(int64_t *)(in_RCX + 0x10)) {
                    iVar3 = iVar5;
                }
                *(int64_t *)(in_RCX + 0x28) = iVar3;
                *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) - uVar2;
            }
            iVar7 = iVar7 + uVar2;
            iVar3 = uVar2 + in_RDX;
            if (in_RDX == 0) {
                iVar3 = in_RDX;
            }
            in_R8 = in_R8 - uVar2;
            in_RDX = iVar3;
        } while (in_R8 != 0);
    }
    return iVar7;
}

// ============================================================
// Function: FUN_180253cd0
// Address: 0x180253cd0
// Size: 456 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180253cd0(int64_t arg_30h, int64_t arg_a0h, int64_t arg_a8h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t in_RCX;
    undefined4 *puVar13;
    int64_t in_RDX;
    undefined4 *puVar14;
    int64_t in_R8;
    undefined4 *in_R9;
    undefined8 uStackX_8;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_8h;
    
    uStack_38 = 0x180253ce3;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_30h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar10)
    ;
    iVar3 = *(int32_t *)((int64_t)&arg_a8h + iVar10);
    puVar14 = *(undefined4 **)((int64_t)&arg_a0h + iVar10);
    piVar4 = *(int64_t **)(in_RCX + 0x40);
    *(undefined (*) [16])(&stack0x00000000 + iVar10) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)auStackX_18 + iVar10 + -8) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_20h + iVar10) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_8h + iVar10) = 0;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x180253d42;
        func_0x000180219ce0(0, 0xf);
    }
    if (((((*(int32_t *)(in_RCX + 0x28) != 0) && (piVar4 != (int64_t *)0x0)) && (piVar4[1] != 0)) &&
        ((in_R8 == 0 || (in_RDX != 0)))) && ((in_R9 == (undefined4 *)0x0 || ((*(uint8_t *)(piVar4 + 0xb) & 2) != 0)))) {
        piVar11 = piVar4;
        if (*piVar4 != 0) {
            piVar11 = *(int64_t **)(*piVar4 + 0x40);
        }
        if ((puVar14 == (undefined4 *)0x0) || ((*(uint8_t *)(piVar11 + 8) & 2) != 0)) {
            *(int64_t *)(&stack0xfffffffffffffff0 + iVar10) = in_R8;
            puVar13 = (undefined4 *)0x1804e5bd0;
            if (puVar14 == (undefined4 *)0x0) {
                puVar14 = (undefined4 *)0x1804e5bd0;
            }
            uVar2 = puVar14[6];
            *(undefined8 *)((int64_t)&var_20h + iVar10 + 4) = *(undefined8 *)(puVar14 + 4);
            *(undefined4 *)(&stack0x0000002c + iVar10) = uVar2;
            uVar2 = puVar14[1];
            uVar7 = puVar14[2];
            uVar8 = puVar14[3];
            *(undefined4 *)((int64_t)auStackX_18 + iVar10 + -4) = *puVar14;
            *(undefined4 *)((int64_t)auStackX_18 + iVar10) = uVar2;
            *(undefined4 *)((int64_t)auStackX_18 + iVar10 + 4) = uVar7;
            *(undefined4 *)((int64_t)&var_20h + iVar10) = uVar8;
            if ((in_R9 != (undefined4 *)0x0) ||
               (in_R9 = (undefined4 *)piVar4[9], (undefined4 *)piVar4[9] != (undefined4 *)0x0)) {
                puVar13 = in_R9;
            }
            uVar7 = puVar13[1];
            uVar8 = puVar13[2];
            uVar9 = puVar13[3];
            uVar2 = puVar13[6];
            uVar1 = *(undefined8 *)(puVar13 + 4);
            iVar5 = piVar4[4];
            iVar6 = piVar4[3];
            *(undefined4 *)((int64_t)&var_8h + iVar10) = *puVar13;
            *(undefined4 *)((int64_t)&var_8h + iVar10 + 4) = uVar7;
            *(undefined4 *)(&stack0x00000000 + iVar10) = uVar8;
            *(undefined4 *)(&stack0x00000004 + iVar10) = uVar9;
            *(undefined4 *)((int64_t)auStackX_18 + iVar10 + -8) = uVar2;
            *(undefined8 *)((int64_t)&uStackX_8 + iVar10) = uVar1;
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x180253e31;
            iVar12 = func_0x000180253ea0(piVar4, &stack0xfffffffffffffff0 + iVar10, 0x40);
            if (iVar12 == 0x40) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x180253e45;
                iVar12 = func_0x000180253ea0(piVar4, in_RDX, in_R8);
                if (iVar12 == in_R8) goto code_r0x000180253e7e;
            }
            iVar3 = *(int32_t *)((int64_t)&arg_a8h + iVar10);
            piVar4[4] = iVar5;
            piVar4[3] = iVar6;
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x180253e6e;
                func_0x00018021b250(in_RCX, 10);
            }
        }
    }
code_r0x000180253e7e:
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x180253e8b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_30h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar10));
    return;
}

// ============================================================
// Function: FUN_180253ea0
// Address: 0x180253ea0
// Size: 41 bytes
// ============================================================
int64_t fcn.180253ea0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    bool bVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t in_RDX;
    int64_t iVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    uint64_t in_R8;
    undefined8 unaff_R13;
    int64_t iVar14;
    undefined8 unaff_R15;
    undefined8 uStack_28;
    
    uStack_28 = 0x180253eb1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar14 = 0;
    if (in_R8 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar8) = unaff_R15;
    do {
        iVar2 = *(int64_t *)(in_RCX + 0x10);
        iVar3 = *(int64_t *)(in_RCX + 0x20);
        iVar4 = *(int64_t *)(in_RCX + 8);
        iVar11 = *(int64_t *)(in_RCX + 0x18);
        if ((uint64_t)(iVar2 - iVar3) <= (uint64_t)(iVar2 - *(int64_t *)(in_RCX + 0x18))) {
            iVar11 = iVar3;
        }
        uVar13 = iVar2 - iVar11;
        if (uVar13 == 0) {
            if ((*(uint8_t *)(in_RCX + 0x58) & 8) == 0) {
                return iVar14;
            }
            uVar12 = *(uint64_t *)(in_RCX + 0x30);
            bVar5 = false;
            uVar1 = uVar12 + in_R8;
            while (uVar12 < uVar1) {
                if (0x7ffffffffffffffe < uVar12) {
                    return iVar14;
                }
                if (uVar12 < 0x2000000000000000) {
                    uVar12 = (uVar12 * 8) / 5;
                } else {
                    if (0x1fffffffffffffff < uVar12 % 5) {
                        bVar5 = true;
                    }
                    bVar6 = bVar5;
                    if (0x1fffffffffffffff < uVar12 / 5) {
                        bVar6 = true;
                    }
                    uVar9 = (uVar12 / 5) * 8;
                    uVar10 = ((uVar12 % 5) * 8) / 5;
                    uVar12 = uVar9 + uVar10;
                    bVar5 = true;
                    if (uVar10 <= ~uVar9) {
                        bVar5 = bVar6;
                    }
                    if (bVar5) {
                        return iVar14;
                    }
                }
                if (0x7ffffffffffffffe < uVar12) {
                    uVar12 = 0x7fffffffffffffff;
                }
            }
            if (uVar12 == 0) {
                return iVar14;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180253ffb;
            iVar7 = func_0x000180254140(in_RCX + 8, uVar12);
            if (iVar7 == 0) {
                return iVar14;
            }
            *(uint64_t *)(in_RCX + 0x30) = uVar12;
        }
        if (in_R8 < uVar13) {
            uVar13 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180254018;
        func_0x000180498030(iVar3 + iVar4, in_RDX, uVar13);
        uVar1 = *(uint64_t *)(in_RCX + 0x10);
        if ((uVar13 <= uVar1 - *(int64_t *)(in_RCX + 0x20)) &&
           (uVar12 = *(int64_t *)(in_RCX + 0x18) + uVar13, uVar12 <= uVar1)) {
            uVar10 = *(int64_t *)(in_RCX + 0x20) + uVar13;
            uVar9 = 0;
            if (uVar10 != uVar1) {
                uVar9 = uVar10;
            }
            *(uint64_t *)(in_RCX + 0x20) = uVar9;
            *(uint64_t *)(in_RCX + 0x18) = uVar12;
        }
        in_RDX = in_RDX + uVar13;
        iVar14 = iVar14 + uVar13;
        in_R8 = in_R8 - uVar13;
        if (in_R8 == 0) {
            return iVar14;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180253ec9
// Address: 0x180253ec9
// Size: 435 bytes
// ============================================================
int64_t fcn.180253ea0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    bool bVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t in_RDX;
    int64_t iVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    uint64_t in_R8;
    undefined8 unaff_R13;
    int64_t iVar14;
    undefined8 unaff_R15;
    undefined8 uStack_28;
    
    uStack_28 = 0x180253eb1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar14 = 0;
    if (in_R8 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar8) = unaff_R15;
    do {
        iVar2 = *(int64_t *)(in_RCX + 0x10);
        iVar3 = *(int64_t *)(in_RCX + 0x20);
        iVar4 = *(int64_t *)(in_RCX + 8);
        iVar11 = *(int64_t *)(in_RCX + 0x18);
        if ((uint64_t)(iVar2 - iVar3) <= (uint64_t)(iVar2 - *(int64_t *)(in_RCX + 0x18))) {
            iVar11 = iVar3;
        }
        uVar13 = iVar2 - iVar11;
        if (uVar13 == 0) {
            if ((*(uint8_t *)(in_RCX + 0x58) & 8) == 0) {
                return iVar14;
            }
            uVar12 = *(uint64_t *)(in_RCX + 0x30);
            bVar5 = false;
            uVar1 = uVar12 + in_R8;
            while (uVar12 < uVar1) {
                if (0x7ffffffffffffffe < uVar12) {
                    return iVar14;
                }
                if (uVar12 < 0x2000000000000000) {
                    uVar12 = (uVar12 * 8) / 5;
                } else {
                    if (0x1fffffffffffffff < uVar12 % 5) {
                        bVar5 = true;
                    }
                    bVar6 = bVar5;
                    if (0x1fffffffffffffff < uVar12 / 5) {
                        bVar6 = true;
                    }
                    uVar9 = (uVar12 / 5) * 8;
                    uVar10 = ((uVar12 % 5) * 8) / 5;
                    uVar12 = uVar9 + uVar10;
                    bVar5 = true;
                    if (uVar10 <= ~uVar9) {
                        bVar5 = bVar6;
                    }
                    if (bVar5) {
                        return iVar14;
                    }
                }
                if (0x7ffffffffffffffe < uVar12) {
                    uVar12 = 0x7fffffffffffffff;
                }
            }
            if (uVar12 == 0) {
                return iVar14;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180253ffb;
            iVar7 = func_0x000180254140(in_RCX + 8, uVar12);
            if (iVar7 == 0) {
                return iVar14;
            }
            *(uint64_t *)(in_RCX + 0x30) = uVar12;
        }
        if (in_R8 < uVar13) {
            uVar13 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180254018;
        func_0x000180498030(iVar3 + iVar4, in_RDX, uVar13);
        uVar1 = *(uint64_t *)(in_RCX + 0x10);
        if ((uVar13 <= uVar1 - *(int64_t *)(in_RCX + 0x20)) &&
           (uVar12 = *(int64_t *)(in_RCX + 0x18) + uVar13, uVar12 <= uVar1)) {
            uVar10 = *(int64_t *)(in_RCX + 0x20) + uVar13;
            uVar9 = 0;
            if (uVar10 != uVar1) {
                uVar9 = uVar10;
            }
            *(uint64_t *)(in_RCX + 0x20) = uVar9;
            *(uint64_t *)(in_RCX + 0x18) = uVar12;
        }
        in_RDX = in_RDX + uVar13;
        iVar14 = iVar14 + uVar13;
        in_R8 = in_R8 - uVar13;
        if (in_R8 == 0) {
            return iVar14;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18025407c
// Address: 0x18025407c
// Size: 14 bytes
// ============================================================
int64_t fcn.180253ea0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    bool bVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t in_RDX;
    int64_t iVar11;
    undefined8 unaff_RBX;
    uint64_t uVar12;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    uint64_t in_R8;
    undefined8 unaff_R13;
    int64_t iVar14;
    undefined8 unaff_R15;
    undefined8 uStack_28;
    
    uStack_28 = 0x180253eb1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar14 = 0;
    if (in_R8 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar8) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar8) = unaff_R15;
    do {
        iVar2 = *(int64_t *)(in_RCX + 0x10);
        iVar3 = *(int64_t *)(in_RCX + 0x20);
        iVar4 = *(int64_t *)(in_RCX + 8);
        iVar11 = *(int64_t *)(in_RCX + 0x18);
        if ((uint64_t)(iVar2 - iVar3) <= (uint64_t)(iVar2 - *(int64_t *)(in_RCX + 0x18))) {
            iVar11 = iVar3;
        }
        uVar13 = iVar2 - iVar11;
        if (uVar13 == 0) {
            if ((*(uint8_t *)(in_RCX + 0x58) & 8) == 0) {
                return iVar14;
            }
            uVar12 = *(uint64_t *)(in_RCX + 0x30);
            bVar5 = false;
            uVar1 = uVar12 + in_R8;
            while (uVar12 < uVar1) {
                if (0x7ffffffffffffffe < uVar12) {
                    return iVar14;
                }
                if (uVar12 < 0x2000000000000000) {
                    uVar12 = (uVar12 * 8) / 5;
                } else {
                    if (0x1fffffffffffffff < uVar12 % 5) {
                        bVar5 = true;
                    }
                    bVar6 = bVar5;
                    if (0x1fffffffffffffff < uVar12 / 5) {
                        bVar6 = true;
                    }
                    uVar9 = (uVar12 / 5) * 8;
                    uVar10 = ((uVar12 % 5) * 8) / 5;
                    uVar12 = uVar9 + uVar10;
                    bVar5 = true;
                    if (uVar10 <= ~uVar9) {
                        bVar5 = bVar6;
                    }
                    if (bVar5) {
                        return iVar14;
                    }
                }
                if (0x7ffffffffffffffe < uVar12) {
                    uVar12 = 0x7fffffffffffffff;
                }
            }
            if (uVar12 == 0) {
                return iVar14;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180253ffb;
            iVar7 = func_0x000180254140(in_RCX + 8, uVar12);
            if (iVar7 == 0) {
                return iVar14;
            }
            *(uint64_t *)(in_RCX + 0x30) = uVar12;
        }
        if (in_R8 < uVar13) {
            uVar13 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180254018;
        func_0x000180498030(iVar3 + iVar4, in_RDX, uVar13);
        uVar1 = *(uint64_t *)(in_RCX + 0x10);
        if ((uVar13 <= uVar1 - *(int64_t *)(in_RCX + 0x20)) &&
           (uVar12 = *(int64_t *)(in_RCX + 0x18) + uVar13, uVar12 <= uVar1)) {
            uVar10 = *(int64_t *)(in_RCX + 0x20) + uVar13;
            uVar9 = 0;
            if (uVar10 != uVar1) {
                uVar9 = uVar10;
            }
            *(uint64_t *)(in_RCX + 0x20) = uVar9;
            *(uint64_t *)(in_RCX + 0x18) = uVar12;
        }
        in_RDX = in_RDX + uVar13;
        iVar14 = iVar14 + uVar13;
        in_R8 = in_R8 - uVar13;
        if (in_R8 == 0) {
            return iVar14;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180254090
// Address: 0x180254090
// Size: 58 bytes
// ============================================================
void fcn.180254090(undefined8 *param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025409c;
    iVar2 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1802540b7;
    fcn.180224990(uVar1, 0x1804e5c10, 0x30);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    return;
}

// ============================================================
// Function: FUN_1802540d0
// Address: 0x1802540d0
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1802540d0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802540e0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802540fe;
    iVar1 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *in_RCX = iVar1;
    if (iVar1 == 0) {
        return 0;
    }
    in_RCX[1] = in_RDX;
    in_RCX[2] = 0;
    in_RCX[4] = 0;
    in_RCX[3] = 0;
    return 1;
}

// ============================================================
// Function: FUN_180254140
// Address: 0x180254140
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180254140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar5;
    undefined8 unaff_RBP;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180254150;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*in_RCX != 0) {
        uVar1 = in_RCX[1];
        if (in_RDX == uVar1) {
            return 1;
        }
        iVar3 = in_RCX[2];
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        if ((iVar3 == 0) || (uVar1 <= in_RDX)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541af;
            iVar3 = func_0x0001802249c0();
            if (iVar3 != 0) {
                if (in_RCX[2] == 0) {
                    in_RCX[4] = 0;
                    in_RCX[3] = 0;
                } else {
                    uVar1 = in_RCX[4];
                    if ((uint64_t)in_RCX[3] <= uVar1) {
                        iVar2 = in_RCX[1];
                        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
                        iVar5 = in_RDX - iVar2;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541fc;
                        func_0x000180498030(iVar5 + uVar1 + iVar3, uVar1 + iVar3, iVar2 - uVar1);
                        in_RCX[4] = in_RCX[4] + iVar5;
                    }
                }
                *in_RCX = iVar3;
                in_RCX[1] = in_RDX;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&var_18h + iVar4);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1802540e0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar4) = 0x1802540fe;
    iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar3 + iVar4));
    *in_RCX = iVar4;
    if (iVar4 == 0) {
        return 0;
    }
    in_RCX[1] = in_RDX;
    in_RCX[2] = 0;
    in_RCX[4] = 0;
    in_RCX[3] = 0;
    return 1;
}

// ============================================================
// Function: FUN_180254191
// Address: 0x180254191
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180254140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar5;
    undefined8 unaff_RBP;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180254150;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*in_RCX != 0) {
        uVar1 = in_RCX[1];
        if (in_RDX == uVar1) {
            return 1;
        }
        iVar3 = in_RCX[2];
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        if ((iVar3 == 0) || (uVar1 <= in_RDX)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541af;
            iVar3 = func_0x0001802249c0();
            if (iVar3 != 0) {
                if (in_RCX[2] == 0) {
                    in_RCX[4] = 0;
                    in_RCX[3] = 0;
                } else {
                    uVar1 = in_RCX[4];
                    if ((uint64_t)in_RCX[3] <= uVar1) {
                        iVar2 = in_RCX[1];
                        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
                        iVar5 = in_RDX - iVar2;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541fc;
                        func_0x000180498030(iVar5 + uVar1 + iVar3, uVar1 + iVar3, iVar2 - uVar1);
                        in_RCX[4] = in_RCX[4] + iVar5;
                    }
                }
                *in_RCX = iVar3;
                in_RCX[1] = in_RDX;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&var_18h + iVar4);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1802540e0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar4) = 0x1802540fe;
    iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar3 + iVar4));
    *in_RCX = iVar4;
    if (iVar4 == 0) {
        return 0;
    }
    in_RCX[1] = in_RDX;
    in_RCX[2] = 0;
    in_RCX[4] = 0;
    in_RCX[3] = 0;
    return 1;
}

// ============================================================
// Function: FUN_1802541c9
// Address: 0x1802541c9
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180254140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar5;
    undefined8 unaff_RBP;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180254150;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*in_RCX != 0) {
        uVar1 = in_RCX[1];
        if (in_RDX == uVar1) {
            return 1;
        }
        iVar3 = in_RCX[2];
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        if ((iVar3 == 0) || (uVar1 <= in_RDX)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541af;
            iVar3 = func_0x0001802249c0();
            if (iVar3 != 0) {
                if (in_RCX[2] == 0) {
                    in_RCX[4] = 0;
                    in_RCX[3] = 0;
                } else {
                    uVar1 = in_RCX[4];
                    if ((uint64_t)in_RCX[3] <= uVar1) {
                        iVar2 = in_RCX[1];
                        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
                        iVar5 = in_RDX - iVar2;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541fc;
                        func_0x000180498030(iVar5 + uVar1 + iVar3, uVar1 + iVar3, iVar2 - uVar1);
                        in_RCX[4] = in_RCX[4] + iVar5;
                    }
                }
                *in_RCX = iVar3;
                in_RCX[1] = in_RDX;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&var_18h + iVar4);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1802540e0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar4) = 0x1802540fe;
    iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar3 + iVar4));
    *in_RCX = iVar4;
    if (iVar4 == 0) {
        return 0;
    }
    in_RCX[1] = in_RDX;
    in_RCX[2] = 0;
    in_RCX[4] = 0;
    in_RCX[3] = 0;
    return 1;
}

// ============================================================
// Function: FUN_1802541e2
// Address: 0x1802541e2
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180254140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar5;
    undefined8 unaff_RBP;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180254150;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*in_RCX != 0) {
        uVar1 = in_RCX[1];
        if (in_RDX == uVar1) {
            return 1;
        }
        iVar3 = in_RCX[2];
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        if ((iVar3 == 0) || (uVar1 <= in_RDX)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541af;
            iVar3 = func_0x0001802249c0();
            if (iVar3 != 0) {
                if (in_RCX[2] == 0) {
                    in_RCX[4] = 0;
                    in_RCX[3] = 0;
                } else {
                    uVar1 = in_RCX[4];
                    if ((uint64_t)in_RCX[3] <= uVar1) {
                        iVar2 = in_RCX[1];
                        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
                        iVar5 = in_RDX - iVar2;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541fc;
                        func_0x000180498030(iVar5 + uVar1 + iVar3, uVar1 + iVar3, iVar2 - uVar1);
                        in_RCX[4] = in_RCX[4] + iVar5;
                    }
                }
                *in_RCX = iVar3;
                in_RCX[1] = in_RDX;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&var_18h + iVar4);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1802540e0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar4) = 0x1802540fe;
    iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar3 + iVar4));
    *in_RCX = iVar4;
    if (iVar4 == 0) {
        return 0;
    }
    in_RCX[1] = in_RDX;
    in_RCX[2] = 0;
    in_RCX[4] = 0;
    in_RCX[3] = 0;
    return 1;
}

// ============================================================
// Function: FUN_180254207
// Address: 0x180254207
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180254140(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar5;
    undefined8 unaff_RBP;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180254150;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*in_RCX != 0) {
        uVar1 = in_RCX[1];
        if (in_RDX == uVar1) {
            return 1;
        }
        iVar3 = in_RCX[2];
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
        if ((iVar3 == 0) || (uVar1 <= in_RDX)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541af;
            iVar3 = func_0x0001802249c0();
            if (iVar3 != 0) {
                if (in_RCX[2] == 0) {
                    in_RCX[4] = 0;
                    in_RCX[3] = 0;
                } else {
                    uVar1 = in_RCX[4];
                    if ((uint64_t)in_RCX[3] <= uVar1) {
                        iVar2 = in_RCX[1];
                        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
                        iVar5 = in_RDX - iVar2;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802541fc;
                        func_0x000180498030(iVar5 + uVar1 + iVar3, uVar1 + iVar3, iVar2 - uVar1);
                        in_RCX[4] = in_RCX[4] + iVar5;
                    }
                }
                *in_RCX = iVar3;
                in_RCX[1] = in_RDX;
                return 1;
            }
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&var_18h + iVar4);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar4) = 0x1802540e0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar4) = 0x1802540fe;
    iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar3 + iVar4));
    *in_RCX = iVar4;
    if (iVar4 == 0) {
        return 0;
    }
    in_RCX[1] = in_RDX;
    in_RCX[2] = 0;
    in_RCX[4] = 0;
    in_RCX[3] = 0;
    return 1;
}

// ============================================================
// Function: FUN_180254240
// Address: 0x180254240
// Size: 52 bytes
// ============================================================
uint64_t fcn.180254240(undefined8 param_1, int64_t param_2)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025424a;
    iVar1 = fcn.18045a350();
    if (param_2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180254261;
    uVar2 = fcn.180498cd0(param_2);
    uVar3 = uVar2 & 0xffffffff;
    if (0x7fffffff < uVar2) {
        uVar3 = 0xffffffff;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1802542f0
// Address: 0x1802542f0
// Size: 32 bytes
// ============================================================
int64_t fcn.1802542f0(int64_t arg_30h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0x348;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180224d70;
    iVar1 = fcn.18045a350(0x348, 0, 0);
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224d7b;
    iVar2 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar1 + iVar3), *(int64_t *)(&stack0x00000048 + iVar1 + iVar3)
                         );
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224d90;
        fcn.1804986e0(iVar2, 0, uVar4);
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180254310
// Address: 0x180254310
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180254310(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    char *pcVar3;
    char *pcVar4;
    undefined *puVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254325;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (*(int32_t *)(arg1 + 0x344) != *(int32_t *)(arg1 + 0x340)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254347;
            iVar8 = func_0x000180221280();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RBX;
                uVar12 = *(uint32_t *)(arg1 + 0x344);
                if (uVar12 != *(uint32_t *)(arg1 + 0x340)) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R15;
                    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_RBP;
                    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
                    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
                    do {
                        uVar12 = uVar12 + 1 & 0x8000000f;
                        if ((int32_t)uVar12 < 0) {
                            uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                        }
                        iVar14 = (int64_t)(int32_t)uVar12;
                        if ((*(uint8_t *)(arg1 + iVar14 * 4) & 2) == 0) {
                            uVar6 = *(int32_t *)(iVar8 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar6 < 0) {
                                uVar6 = (uVar6 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar8 + 0x340) = uVar6;
                            if (uVar6 == *(uint32_t *)(iVar8 + 0x344)) {
                                uVar11 = *(uint32_t *)(iVar8 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar11 < 0) {
                                    uVar11 = (uVar11 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar8 + 0x344) = uVar11;
                            }
                            iVar13 = (int64_t)(int32_t)uVar6;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802543f2;
                            func_0x000180220e60(iVar8, iVar13, 0);
                            *(undefined4 *)(iVar8 + iVar13 * 4) = *(undefined4 *)(arg1 + iVar14 * 4);
                            *(undefined4 *)(iVar8 + 0x80 + iVar13 * 4) = *(undefined4 *)(arg1 + 0x80 + iVar14 * 4);
                            uVar2 = *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8);
                            pcVar3 = *(char **)(arg1 + 0x2c0 + iVar14 * 8);
                            uVar1 = *(undefined4 *)(arg1 + 0x280 + iVar14 * 4);
                            pcVar4 = *(char **)(arg1 + 0x200 + iVar14 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025443a;
                            fcn.180224990(uVar2, 0x1804bf6a0, 0x39);
                            if ((pcVar4 == (char *)0x0) || (*pcVar4 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254456;
                                fcn.180498cd0(pcVar4);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254464;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x200 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025447c;
                                    func_0x0001804990c0(iVar9, pcVar4);
                                }
                            }
                            *(undefined4 *)(iVar8 + 0x280 + iVar13 * 4) = uVar1;
                            uVar2 = *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544a1;
                            fcn.180224990(uVar2, 0x1804bf6a0);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544b4;
                                fcn.180498cd0(pcVar3);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544c2;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x2c0 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544da;
                                    func_0x0001804990c0(iVar9, pcVar3);
                                }
                            }
                            if ((*(int64_t *)(arg1 + 0xc0 + iVar14 * 8) == 0) ||
                               (iVar9 = *(int64_t *)(arg1 + 0x140 + iVar14 * 8), iVar9 == 0)) {
                                iVar14 = iVar8 + iVar13 * 4;
                                iVar9 = iVar8 + iVar13 * 8;
                                if ((*(uint8_t *)(iVar14 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar9 + 0xc0) = 0;
                                    *(undefined8 *)(iVar8 + 0x140 + iVar13 * 8) = 0;
                                    *(undefined4 *)(iVar14 + 0x1c0) = 0;
                                } else {
                                    puVar5 = *(undefined **)(iVar9 + 0xc0);
                                    if (puVar5 != (undefined *)0x0) {
                                        *puVar5 = 0;
                                        *(undefined4 *)(iVar14 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025451a;
                                iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar7));
                                if (iVar10 != 0) {
                                    uVar2 = *(undefined8 *)(arg1 + 0xc0 + iVar14 * 8);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254539;
                                    func_0x000180498030(iVar10, uVar2);
                                    uVar6 = *(uint32_t *)(arg1 + 0x1c0 + iVar14 * 4);
                                    if ((*(uint8_t *)(iVar8 + 0x1c0 + iVar13 * 4) & 1) != 0) {
                                        uVar2 = *(undefined8 *)(iVar8 + 0xc0 + iVar13 * 8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254569;
                                        fcn.180224990(uVar2, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar8 + 0xc0 + iVar13 * 8) = iVar10;
                                    *(int64_t *)(iVar8 + 0x140 + iVar13 * 8) = iVar9;
                                    *(uint32_t *)(iVar8 + 0x1c0 + iVar13 * 4) = uVar6 | 1;
                                }
                            }
                        }
                    } while (uVar12 != *(uint32_t *)(arg1 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18025433d
// Address: 0x18025433d
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180254310(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    char *pcVar3;
    char *pcVar4;
    undefined *puVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254325;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (*(int32_t *)(arg1 + 0x344) != *(int32_t *)(arg1 + 0x340)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254347;
            iVar8 = func_0x000180221280();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RBX;
                uVar12 = *(uint32_t *)(arg1 + 0x344);
                if (uVar12 != *(uint32_t *)(arg1 + 0x340)) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R15;
                    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_RBP;
                    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
                    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
                    do {
                        uVar12 = uVar12 + 1 & 0x8000000f;
                        if ((int32_t)uVar12 < 0) {
                            uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                        }
                        iVar14 = (int64_t)(int32_t)uVar12;
                        if ((*(uint8_t *)(arg1 + iVar14 * 4) & 2) == 0) {
                            uVar6 = *(int32_t *)(iVar8 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar6 < 0) {
                                uVar6 = (uVar6 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar8 + 0x340) = uVar6;
                            if (uVar6 == *(uint32_t *)(iVar8 + 0x344)) {
                                uVar11 = *(uint32_t *)(iVar8 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar11 < 0) {
                                    uVar11 = (uVar11 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar8 + 0x344) = uVar11;
                            }
                            iVar13 = (int64_t)(int32_t)uVar6;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802543f2;
                            func_0x000180220e60(iVar8, iVar13, 0);
                            *(undefined4 *)(iVar8 + iVar13 * 4) = *(undefined4 *)(arg1 + iVar14 * 4);
                            *(undefined4 *)(iVar8 + 0x80 + iVar13 * 4) = *(undefined4 *)(arg1 + 0x80 + iVar14 * 4);
                            uVar2 = *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8);
                            pcVar3 = *(char **)(arg1 + 0x2c0 + iVar14 * 8);
                            uVar1 = *(undefined4 *)(arg1 + 0x280 + iVar14 * 4);
                            pcVar4 = *(char **)(arg1 + 0x200 + iVar14 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025443a;
                            fcn.180224990(uVar2, 0x1804bf6a0, 0x39);
                            if ((pcVar4 == (char *)0x0) || (*pcVar4 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254456;
                                fcn.180498cd0(pcVar4);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254464;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x200 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025447c;
                                    func_0x0001804990c0(iVar9, pcVar4);
                                }
                            }
                            *(undefined4 *)(iVar8 + 0x280 + iVar13 * 4) = uVar1;
                            uVar2 = *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544a1;
                            fcn.180224990(uVar2, 0x1804bf6a0);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544b4;
                                fcn.180498cd0(pcVar3);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544c2;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x2c0 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544da;
                                    func_0x0001804990c0(iVar9, pcVar3);
                                }
                            }
                            if ((*(int64_t *)(arg1 + 0xc0 + iVar14 * 8) == 0) ||
                               (iVar9 = *(int64_t *)(arg1 + 0x140 + iVar14 * 8), iVar9 == 0)) {
                                iVar14 = iVar8 + iVar13 * 4;
                                iVar9 = iVar8 + iVar13 * 8;
                                if ((*(uint8_t *)(iVar14 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar9 + 0xc0) = 0;
                                    *(undefined8 *)(iVar8 + 0x140 + iVar13 * 8) = 0;
                                    *(undefined4 *)(iVar14 + 0x1c0) = 0;
                                } else {
                                    puVar5 = *(undefined **)(iVar9 + 0xc0);
                                    if (puVar5 != (undefined *)0x0) {
                                        *puVar5 = 0;
                                        *(undefined4 *)(iVar14 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025451a;
                                iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar7));
                                if (iVar10 != 0) {
                                    uVar2 = *(undefined8 *)(arg1 + 0xc0 + iVar14 * 8);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254539;
                                    func_0x000180498030(iVar10, uVar2);
                                    uVar6 = *(uint32_t *)(arg1 + 0x1c0 + iVar14 * 4);
                                    if ((*(uint8_t *)(iVar8 + 0x1c0 + iVar13 * 4) & 1) != 0) {
                                        uVar2 = *(undefined8 *)(iVar8 + 0xc0 + iVar13 * 8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254569;
                                        fcn.180224990(uVar2, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar8 + 0xc0 + iVar13 * 8) = iVar10;
                                    *(int64_t *)(iVar8 + 0x140 + iVar13 * 8) = iVar9;
                                    *(uint32_t *)(iVar8 + 0x1c0 + iVar13 * 4) = uVar6 | 1;
                                }
                            }
                        }
                    } while (uVar12 != *(uint32_t *)(arg1 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180254353
// Address: 0x180254353
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180254310(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    char *pcVar3;
    char *pcVar4;
    undefined *puVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254325;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (*(int32_t *)(arg1 + 0x344) != *(int32_t *)(arg1 + 0x340)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254347;
            iVar8 = func_0x000180221280();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RBX;
                uVar12 = *(uint32_t *)(arg1 + 0x344);
                if (uVar12 != *(uint32_t *)(arg1 + 0x340)) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R15;
                    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_RBP;
                    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
                    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
                    do {
                        uVar12 = uVar12 + 1 & 0x8000000f;
                        if ((int32_t)uVar12 < 0) {
                            uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                        }
                        iVar14 = (int64_t)(int32_t)uVar12;
                        if ((*(uint8_t *)(arg1 + iVar14 * 4) & 2) == 0) {
                            uVar6 = *(int32_t *)(iVar8 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar6 < 0) {
                                uVar6 = (uVar6 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar8 + 0x340) = uVar6;
                            if (uVar6 == *(uint32_t *)(iVar8 + 0x344)) {
                                uVar11 = *(uint32_t *)(iVar8 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar11 < 0) {
                                    uVar11 = (uVar11 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar8 + 0x344) = uVar11;
                            }
                            iVar13 = (int64_t)(int32_t)uVar6;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802543f2;
                            func_0x000180220e60(iVar8, iVar13, 0);
                            *(undefined4 *)(iVar8 + iVar13 * 4) = *(undefined4 *)(arg1 + iVar14 * 4);
                            *(undefined4 *)(iVar8 + 0x80 + iVar13 * 4) = *(undefined4 *)(arg1 + 0x80 + iVar14 * 4);
                            uVar2 = *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8);
                            pcVar3 = *(char **)(arg1 + 0x2c0 + iVar14 * 8);
                            uVar1 = *(undefined4 *)(arg1 + 0x280 + iVar14 * 4);
                            pcVar4 = *(char **)(arg1 + 0x200 + iVar14 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025443a;
                            fcn.180224990(uVar2, 0x1804bf6a0, 0x39);
                            if ((pcVar4 == (char *)0x0) || (*pcVar4 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254456;
                                fcn.180498cd0(pcVar4);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254464;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x200 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025447c;
                                    func_0x0001804990c0(iVar9, pcVar4);
                                }
                            }
                            *(undefined4 *)(iVar8 + 0x280 + iVar13 * 4) = uVar1;
                            uVar2 = *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544a1;
                            fcn.180224990(uVar2, 0x1804bf6a0);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544b4;
                                fcn.180498cd0(pcVar3);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544c2;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x2c0 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544da;
                                    func_0x0001804990c0(iVar9, pcVar3);
                                }
                            }
                            if ((*(int64_t *)(arg1 + 0xc0 + iVar14 * 8) == 0) ||
                               (iVar9 = *(int64_t *)(arg1 + 0x140 + iVar14 * 8), iVar9 == 0)) {
                                iVar14 = iVar8 + iVar13 * 4;
                                iVar9 = iVar8 + iVar13 * 8;
                                if ((*(uint8_t *)(iVar14 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar9 + 0xc0) = 0;
                                    *(undefined8 *)(iVar8 + 0x140 + iVar13 * 8) = 0;
                                    *(undefined4 *)(iVar14 + 0x1c0) = 0;
                                } else {
                                    puVar5 = *(undefined **)(iVar9 + 0xc0);
                                    if (puVar5 != (undefined *)0x0) {
                                        *puVar5 = 0;
                                        *(undefined4 *)(iVar14 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025451a;
                                iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar7));
                                if (iVar10 != 0) {
                                    uVar2 = *(undefined8 *)(arg1 + 0xc0 + iVar14 * 8);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254539;
                                    func_0x000180498030(iVar10, uVar2);
                                    uVar6 = *(uint32_t *)(arg1 + 0x1c0 + iVar14 * 4);
                                    if ((*(uint8_t *)(iVar8 + 0x1c0 + iVar13 * 4) & 1) != 0) {
                                        uVar2 = *(undefined8 *)(iVar8 + 0xc0 + iVar13 * 8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254569;
                                        fcn.180224990(uVar2, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar8 + 0xc0 + iVar13 * 8) = iVar10;
                                    *(int64_t *)(iVar8 + 0x140 + iVar13 * 8) = iVar9;
                                    *(uint32_t *)(iVar8 + 0x1c0 + iVar13 * 4) = uVar6 | 1;
                                }
                            }
                        }
                    } while (uVar12 != *(uint32_t *)(arg1 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18025436c
// Address: 0x18025436c
// Size: 639 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180254310(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    char *pcVar3;
    char *pcVar4;
    undefined *puVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254325;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (*(int32_t *)(arg1 + 0x344) != *(int32_t *)(arg1 + 0x340)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254347;
            iVar8 = func_0x000180221280();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RBX;
                uVar12 = *(uint32_t *)(arg1 + 0x344);
                if (uVar12 != *(uint32_t *)(arg1 + 0x340)) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R15;
                    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_RBP;
                    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
                    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
                    do {
                        uVar12 = uVar12 + 1 & 0x8000000f;
                        if ((int32_t)uVar12 < 0) {
                            uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                        }
                        iVar14 = (int64_t)(int32_t)uVar12;
                        if ((*(uint8_t *)(arg1 + iVar14 * 4) & 2) == 0) {
                            uVar6 = *(int32_t *)(iVar8 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar6 < 0) {
                                uVar6 = (uVar6 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar8 + 0x340) = uVar6;
                            if (uVar6 == *(uint32_t *)(iVar8 + 0x344)) {
                                uVar11 = *(uint32_t *)(iVar8 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar11 < 0) {
                                    uVar11 = (uVar11 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar8 + 0x344) = uVar11;
                            }
                            iVar13 = (int64_t)(int32_t)uVar6;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802543f2;
                            func_0x000180220e60(iVar8, iVar13, 0);
                            *(undefined4 *)(iVar8 + iVar13 * 4) = *(undefined4 *)(arg1 + iVar14 * 4);
                            *(undefined4 *)(iVar8 + 0x80 + iVar13 * 4) = *(undefined4 *)(arg1 + 0x80 + iVar14 * 4);
                            uVar2 = *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8);
                            pcVar3 = *(char **)(arg1 + 0x2c0 + iVar14 * 8);
                            uVar1 = *(undefined4 *)(arg1 + 0x280 + iVar14 * 4);
                            pcVar4 = *(char **)(arg1 + 0x200 + iVar14 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025443a;
                            fcn.180224990(uVar2, 0x1804bf6a0, 0x39);
                            if ((pcVar4 == (char *)0x0) || (*pcVar4 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254456;
                                fcn.180498cd0(pcVar4);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254464;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x200 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025447c;
                                    func_0x0001804990c0(iVar9, pcVar4);
                                }
                            }
                            *(undefined4 *)(iVar8 + 0x280 + iVar13 * 4) = uVar1;
                            uVar2 = *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544a1;
                            fcn.180224990(uVar2, 0x1804bf6a0);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544b4;
                                fcn.180498cd0(pcVar3);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544c2;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x2c0 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544da;
                                    func_0x0001804990c0(iVar9, pcVar3);
                                }
                            }
                            if ((*(int64_t *)(arg1 + 0xc0 + iVar14 * 8) == 0) ||
                               (iVar9 = *(int64_t *)(arg1 + 0x140 + iVar14 * 8), iVar9 == 0)) {
                                iVar14 = iVar8 + iVar13 * 4;
                                iVar9 = iVar8 + iVar13 * 8;
                                if ((*(uint8_t *)(iVar14 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar9 + 0xc0) = 0;
                                    *(undefined8 *)(iVar8 + 0x140 + iVar13 * 8) = 0;
                                    *(undefined4 *)(iVar14 + 0x1c0) = 0;
                                } else {
                                    puVar5 = *(undefined **)(iVar9 + 0xc0);
                                    if (puVar5 != (undefined *)0x0) {
                                        *puVar5 = 0;
                                        *(undefined4 *)(iVar14 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025451a;
                                iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar7));
                                if (iVar10 != 0) {
                                    uVar2 = *(undefined8 *)(arg1 + 0xc0 + iVar14 * 8);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254539;
                                    func_0x000180498030(iVar10, uVar2);
                                    uVar6 = *(uint32_t *)(arg1 + 0x1c0 + iVar14 * 4);
                                    if ((*(uint8_t *)(iVar8 + 0x1c0 + iVar13 * 4) & 1) != 0) {
                                        uVar2 = *(undefined8 *)(iVar8 + 0xc0 + iVar13 * 8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254569;
                                        fcn.180224990(uVar2, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar8 + 0xc0 + iVar13 * 8) = iVar10;
                                    *(int64_t *)(iVar8 + 0x140 + iVar13 * 8) = iVar9;
                                    *(uint32_t *)(iVar8 + 0x1c0 + iVar13 * 4) = uVar6 | 1;
                                }
                            }
                        }
                    } while (uVar12 != *(uint32_t *)(arg1 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802545eb
// Address: 0x1802545eb
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180254310(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    char *pcVar3;
    char *pcVar4;
    undefined *puVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254325;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (*(int32_t *)(arg1 + 0x344) != *(int32_t *)(arg1 + 0x340)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254347;
            iVar8 = func_0x000180221280();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RBX;
                uVar12 = *(uint32_t *)(arg1 + 0x344);
                if (uVar12 != *(uint32_t *)(arg1 + 0x340)) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R15;
                    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_RBP;
                    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
                    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
                    do {
                        uVar12 = uVar12 + 1 & 0x8000000f;
                        if ((int32_t)uVar12 < 0) {
                            uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                        }
                        iVar14 = (int64_t)(int32_t)uVar12;
                        if ((*(uint8_t *)(arg1 + iVar14 * 4) & 2) == 0) {
                            uVar6 = *(int32_t *)(iVar8 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar6 < 0) {
                                uVar6 = (uVar6 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar8 + 0x340) = uVar6;
                            if (uVar6 == *(uint32_t *)(iVar8 + 0x344)) {
                                uVar11 = *(uint32_t *)(iVar8 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar11 < 0) {
                                    uVar11 = (uVar11 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar8 + 0x344) = uVar11;
                            }
                            iVar13 = (int64_t)(int32_t)uVar6;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802543f2;
                            func_0x000180220e60(iVar8, iVar13, 0);
                            *(undefined4 *)(iVar8 + iVar13 * 4) = *(undefined4 *)(arg1 + iVar14 * 4);
                            *(undefined4 *)(iVar8 + 0x80 + iVar13 * 4) = *(undefined4 *)(arg1 + 0x80 + iVar14 * 4);
                            uVar2 = *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8);
                            pcVar3 = *(char **)(arg1 + 0x2c0 + iVar14 * 8);
                            uVar1 = *(undefined4 *)(arg1 + 0x280 + iVar14 * 4);
                            pcVar4 = *(char **)(arg1 + 0x200 + iVar14 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025443a;
                            fcn.180224990(uVar2, 0x1804bf6a0, 0x39);
                            if ((pcVar4 == (char *)0x0) || (*pcVar4 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254456;
                                fcn.180498cd0(pcVar4);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254464;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x200 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025447c;
                                    func_0x0001804990c0(iVar9, pcVar4);
                                }
                            }
                            *(undefined4 *)(iVar8 + 0x280 + iVar13 * 4) = uVar1;
                            uVar2 = *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544a1;
                            fcn.180224990(uVar2, 0x1804bf6a0);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544b4;
                                fcn.180498cd0(pcVar3);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544c2;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x2c0 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544da;
                                    func_0x0001804990c0(iVar9, pcVar3);
                                }
                            }
                            if ((*(int64_t *)(arg1 + 0xc0 + iVar14 * 8) == 0) ||
                               (iVar9 = *(int64_t *)(arg1 + 0x140 + iVar14 * 8), iVar9 == 0)) {
                                iVar14 = iVar8 + iVar13 * 4;
                                iVar9 = iVar8 + iVar13 * 8;
                                if ((*(uint8_t *)(iVar14 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar9 + 0xc0) = 0;
                                    *(undefined8 *)(iVar8 + 0x140 + iVar13 * 8) = 0;
                                    *(undefined4 *)(iVar14 + 0x1c0) = 0;
                                } else {
                                    puVar5 = *(undefined **)(iVar9 + 0xc0);
                                    if (puVar5 != (undefined *)0x0) {
                                        *puVar5 = 0;
                                        *(undefined4 *)(iVar14 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025451a;
                                iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar7));
                                if (iVar10 != 0) {
                                    uVar2 = *(undefined8 *)(arg1 + 0xc0 + iVar14 * 8);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254539;
                                    func_0x000180498030(iVar10, uVar2);
                                    uVar6 = *(uint32_t *)(arg1 + 0x1c0 + iVar14 * 4);
                                    if ((*(uint8_t *)(iVar8 + 0x1c0 + iVar13 * 4) & 1) != 0) {
                                        uVar2 = *(undefined8 *)(iVar8 + 0xc0 + iVar13 * 8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254569;
                                        fcn.180224990(uVar2, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar8 + 0xc0 + iVar13 * 8) = iVar10;
                                    *(int64_t *)(iVar8 + 0x140 + iVar13 * 8) = iVar9;
                                    *(uint32_t *)(iVar8 + 0x1c0 + iVar13 * 4) = uVar6 | 1;
                                }
                            }
                        }
                    } while (uVar12 != *(uint32_t *)(arg1 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802545f0
// Address: 0x1802545f0
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180254310(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    char *pcVar3;
    char *pcVar4;
    undefined *puVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254325;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (*(int32_t *)(arg1 + 0x344) != *(int32_t *)(arg1 + 0x340)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254347;
            iVar8 = func_0x000180221280();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RBX;
                uVar12 = *(uint32_t *)(arg1 + 0x344);
                if (uVar12 != *(uint32_t *)(arg1 + 0x340)) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R15;
                    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_RBP;
                    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
                    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
                    do {
                        uVar12 = uVar12 + 1 & 0x8000000f;
                        if ((int32_t)uVar12 < 0) {
                            uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                        }
                        iVar14 = (int64_t)(int32_t)uVar12;
                        if ((*(uint8_t *)(arg1 + iVar14 * 4) & 2) == 0) {
                            uVar6 = *(int32_t *)(iVar8 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar6 < 0) {
                                uVar6 = (uVar6 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar8 + 0x340) = uVar6;
                            if (uVar6 == *(uint32_t *)(iVar8 + 0x344)) {
                                uVar11 = *(uint32_t *)(iVar8 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar11 < 0) {
                                    uVar11 = (uVar11 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar8 + 0x344) = uVar11;
                            }
                            iVar13 = (int64_t)(int32_t)uVar6;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802543f2;
                            func_0x000180220e60(iVar8, iVar13, 0);
                            *(undefined4 *)(iVar8 + iVar13 * 4) = *(undefined4 *)(arg1 + iVar14 * 4);
                            *(undefined4 *)(iVar8 + 0x80 + iVar13 * 4) = *(undefined4 *)(arg1 + 0x80 + iVar14 * 4);
                            uVar2 = *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8);
                            pcVar3 = *(char **)(arg1 + 0x2c0 + iVar14 * 8);
                            uVar1 = *(undefined4 *)(arg1 + 0x280 + iVar14 * 4);
                            pcVar4 = *(char **)(arg1 + 0x200 + iVar14 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025443a;
                            fcn.180224990(uVar2, 0x1804bf6a0, 0x39);
                            if ((pcVar4 == (char *)0x0) || (*pcVar4 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254456;
                                fcn.180498cd0(pcVar4);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254464;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x200 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025447c;
                                    func_0x0001804990c0(iVar9, pcVar4);
                                }
                            }
                            *(undefined4 *)(iVar8 + 0x280 + iVar13 * 4) = uVar1;
                            uVar2 = *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544a1;
                            fcn.180224990(uVar2, 0x1804bf6a0);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544b4;
                                fcn.180498cd0(pcVar3);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544c2;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x2c0 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544da;
                                    func_0x0001804990c0(iVar9, pcVar3);
                                }
                            }
                            if ((*(int64_t *)(arg1 + 0xc0 + iVar14 * 8) == 0) ||
                               (iVar9 = *(int64_t *)(arg1 + 0x140 + iVar14 * 8), iVar9 == 0)) {
                                iVar14 = iVar8 + iVar13 * 4;
                                iVar9 = iVar8 + iVar13 * 8;
                                if ((*(uint8_t *)(iVar14 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar9 + 0xc0) = 0;
                                    *(undefined8 *)(iVar8 + 0x140 + iVar13 * 8) = 0;
                                    *(undefined4 *)(iVar14 + 0x1c0) = 0;
                                } else {
                                    puVar5 = *(undefined **)(iVar9 + 0xc0);
                                    if (puVar5 != (undefined *)0x0) {
                                        *puVar5 = 0;
                                        *(undefined4 *)(iVar14 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025451a;
                                iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar7));
                                if (iVar10 != 0) {
                                    uVar2 = *(undefined8 *)(arg1 + 0xc0 + iVar14 * 8);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254539;
                                    func_0x000180498030(iVar10, uVar2);
                                    uVar6 = *(uint32_t *)(arg1 + 0x1c0 + iVar14 * 4);
                                    if ((*(uint8_t *)(iVar8 + 0x1c0 + iVar13 * 4) & 1) != 0) {
                                        uVar2 = *(undefined8 *)(iVar8 + 0xc0 + iVar13 * 8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254569;
                                        fcn.180224990(uVar2, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar8 + 0xc0 + iVar13 * 8) = iVar10;
                                    *(int64_t *)(iVar8 + 0x140 + iVar13 * 8) = iVar9;
                                    *(uint32_t *)(iVar8 + 0x1c0 + iVar13 * 4) = uVar6 | 1;
                                }
                            }
                        }
                    } while (uVar12 != *(uint32_t *)(arg1 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802545f5
// Address: 0x1802545f5
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180254310(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_80h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    char *pcVar3;
    char *pcVar4;
    undefined *puVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar13;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254325;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (*(int32_t *)(arg1 + 0x344) != *(int32_t *)(arg1 + 0x340)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254347;
            iVar8 = func_0x000180221280();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RBX;
                uVar12 = *(uint32_t *)(arg1 + 0x344);
                if (uVar12 != *(uint32_t *)(arg1 + 0x340)) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_R15;
                    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_RBP;
                    *(undefined8 *)((int64_t)&arg_58h + iVar7) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_R12;
                    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_R13;
                    do {
                        uVar12 = uVar12 + 1 & 0x8000000f;
                        if ((int32_t)uVar12 < 0) {
                            uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                        }
                        iVar14 = (int64_t)(int32_t)uVar12;
                        if ((*(uint8_t *)(arg1 + iVar14 * 4) & 2) == 0) {
                            uVar6 = *(int32_t *)(iVar8 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar6 < 0) {
                                uVar6 = (uVar6 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar8 + 0x340) = uVar6;
                            if (uVar6 == *(uint32_t *)(iVar8 + 0x344)) {
                                uVar11 = *(uint32_t *)(iVar8 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar11 < 0) {
                                    uVar11 = (uVar11 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar8 + 0x344) = uVar11;
                            }
                            iVar13 = (int64_t)(int32_t)uVar6;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802543f2;
                            func_0x000180220e60(iVar8, iVar13, 0);
                            *(undefined4 *)(iVar8 + iVar13 * 4) = *(undefined4 *)(arg1 + iVar14 * 4);
                            *(undefined4 *)(iVar8 + 0x80 + iVar13 * 4) = *(undefined4 *)(arg1 + 0x80 + iVar14 * 4);
                            uVar2 = *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8);
                            pcVar3 = *(char **)(arg1 + 0x2c0 + iVar14 * 8);
                            uVar1 = *(undefined4 *)(arg1 + 0x280 + iVar14 * 4);
                            pcVar4 = *(char **)(arg1 + 0x200 + iVar14 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025443a;
                            fcn.180224990(uVar2, 0x1804bf6a0, 0x39);
                            if ((pcVar4 == (char *)0x0) || (*pcVar4 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x200 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254456;
                                fcn.180498cd0(pcVar4);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254464;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x200 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025447c;
                                    func_0x0001804990c0(iVar9, pcVar4);
                                }
                            }
                            *(undefined4 *)(iVar8 + 0x280 + iVar13 * 4) = uVar1;
                            uVar2 = *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544a1;
                            fcn.180224990(uVar2, 0x1804bf6a0);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x2c0 + iVar13 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544b4;
                                fcn.180498cd0(pcVar3);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544c2;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7));
                                *(int64_t *)(iVar8 + 0x2c0 + iVar13 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802544da;
                                    func_0x0001804990c0(iVar9, pcVar3);
                                }
                            }
                            if ((*(int64_t *)(arg1 + 0xc0 + iVar14 * 8) == 0) ||
                               (iVar9 = *(int64_t *)(arg1 + 0x140 + iVar14 * 8), iVar9 == 0)) {
                                iVar14 = iVar8 + iVar13 * 4;
                                iVar9 = iVar8 + iVar13 * 8;
                                if ((*(uint8_t *)(iVar14 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar9 + 0xc0) = 0;
                                    *(undefined8 *)(iVar8 + 0x140 + iVar13 * 8) = 0;
                                    *(undefined4 *)(iVar14 + 0x1c0) = 0;
                                } else {
                                    puVar5 = *(undefined **)(iVar9 + 0xc0);
                                    if (puVar5 != (undefined *)0x0) {
                                        *puVar5 = 0;
                                        *(undefined4 *)(iVar14 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025451a;
                                iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar7));
                                if (iVar10 != 0) {
                                    uVar2 = *(undefined8 *)(arg1 + 0xc0 + iVar14 * 8);
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254539;
                                    func_0x000180498030(iVar10, uVar2);
                                    uVar6 = *(uint32_t *)(arg1 + 0x1c0 + iVar14 * 4);
                                    if ((*(uint8_t *)(iVar8 + 0x1c0 + iVar13 * 4) & 1) != 0) {
                                        uVar2 = *(undefined8 *)(iVar8 + 0xc0 + iVar13 * 8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180254569;
                                        fcn.180224990(uVar2, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar8 + 0xc0 + iVar13 * 8) = iVar10;
                                    *(int64_t *)(iVar8 + 0x140 + iVar13 * 8) = iVar9;
                                    *(uint32_t *)(iVar8 + 0x1c0 + iVar13 * 4) = uVar6 | 1;
                                }
                            }
                        }
                    } while (uVar12 != *(uint32_t *)(arg1 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180254600
// Address: 0x180254600
// Size: 23 bytes
// ============================================================
void fcn.180254600(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 *puVar11;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254614;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
        iVar10 = 0x10;
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        puVar7 = (undefined4 *)(arg1 + 0x1c0);
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R14;
        puVar11 = (undefined8 *)(arg1 + 0xc0);
        do {
            if ((*(uint8_t *)puVar7 & 1) != 0) {
                uVar1 = *puVar11;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025465e;
                fcn.180224990(uVar1, 0x1804bf6a0, 0x19);
            }
            *puVar11 = 0;
            puVar11[0x10] = 0;
            *puVar7 = 0;
            puVar7[-0x60] = 0;
            puVar7[-0x70] = 0;
            puVar7[-0x50] = 0;
            puVar7[0x30] = 0xffffffff;
            uVar1 = puVar11[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546a3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar11[0x40];
            puVar11[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546c3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar11[0x40] = 0;
            puVar7 = puVar7 + 1;
            puVar11 = puVar11 + 1;
            iVar10 = iVar10 + -1;
        } while (iVar10 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546f5;
        puVar7 = (undefined4 *)func_0x000180221280();
        if (puVar7 != (undefined4 *)0x0) {
            iVar10 = 6;
            puVar5 = puVar7;
            do {
                puVar9 = (undefined4 *)arg1;
                puVar8 = puVar5;
                uVar2 = puVar8[1];
                uVar3 = puVar8[2];
                uVar4 = puVar8[3];
                *puVar9 = *puVar8;
                puVar9[1] = uVar2;
                puVar9[2] = uVar3;
                puVar9[3] = uVar4;
                uVar2 = puVar8[5];
                uVar3 = puVar8[6];
                uVar4 = puVar8[7];
                puVar9[4] = puVar8[4];
                puVar9[5] = uVar2;
                puVar9[6] = uVar3;
                puVar9[7] = uVar4;
                uVar2 = puVar8[9];
                uVar3 = puVar8[10];
                uVar4 = puVar8[0xb];
                puVar9[8] = puVar8[8];
                puVar9[9] = uVar2;
                puVar9[10] = uVar3;
                puVar9[0xb] = uVar4;
                uVar2 = puVar8[0xd];
                uVar3 = puVar8[0xe];
                uVar4 = puVar8[0xf];
                puVar9[0xc] = puVar8[0xc];
                puVar9[0xd] = uVar2;
                puVar9[0xe] = uVar3;
                puVar9[0xf] = uVar4;
                uVar2 = puVar8[0x11];
                uVar3 = puVar8[0x12];
                uVar4 = puVar8[0x13];
                puVar9[0x10] = puVar8[0x10];
                puVar9[0x11] = uVar2;
                puVar9[0x12] = uVar3;
                puVar9[0x13] = uVar4;
                uVar2 = puVar8[0x15];
                uVar3 = puVar8[0x16];
                uVar4 = puVar8[0x17];
                puVar9[0x14] = puVar8[0x14];
                puVar9[0x15] = uVar2;
                puVar9[0x16] = uVar3;
                puVar9[0x17] = uVar4;
                uVar2 = puVar8[0x19];
                uVar3 = puVar8[0x1a];
                uVar4 = puVar8[0x1b];
                puVar9[0x18] = puVar8[0x18];
                puVar9[0x19] = uVar2;
                puVar9[0x1a] = uVar3;
                puVar9[0x1b] = uVar4;
                uVar2 = puVar8[0x1d];
                uVar3 = puVar8[0x1e];
                uVar4 = puVar8[0x1f];
                puVar9[0x1c] = puVar8[0x1c];
                puVar9[0x1d] = uVar2;
                puVar9[0x1e] = uVar3;
                puVar9[0x1f] = uVar4;
                iVar10 = iVar10 + -1;
                puVar5 = puVar8 + 0x20;
                arg1 = (int64_t)(puVar9 + 0x20);
            } while (iVar10 != 0);
            uVar2 = puVar8[0x21];
            uVar3 = puVar8[0x22];
            uVar4 = puVar8[0x23];
            puVar9[0x20] = puVar8[0x20];
            puVar9[0x21] = uVar2;
            puVar9[0x22] = uVar3;
            puVar9[0x23] = uVar4;
            uVar2 = puVar8[0x25];
            uVar3 = puVar8[0x26];
            uVar4 = puVar8[0x27];
            puVar9[0x24] = puVar8[0x24];
            puVar9[0x25] = uVar2;
            puVar9[0x26] = uVar3;
            puVar9[0x27] = uVar4;
            uVar2 = puVar8[0x29];
            uVar3 = puVar8[0x2a];
            uVar4 = puVar8[0x2b];
            puVar9[0x28] = puVar8[0x28];
            puVar9[0x29] = uVar2;
            puVar9[0x2a] = uVar3;
            puVar9[0x2b] = uVar4;
            uVar2 = puVar8[0x2d];
            uVar3 = puVar8[0x2e];
            uVar4 = puVar8[0x2f];
            puVar9[0x2c] = puVar8[0x2c];
            puVar9[0x2d] = uVar2;
            puVar9[0x2e] = uVar3;
            puVar9[0x2f] = uVar4;
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar8 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025478f;
            fcn.1804986e0(puVar7, 0, 0x348);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180254617
// Address: 0x180254617
// Size: 234 bytes
// ============================================================
void fcn.180254600(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 *puVar11;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254614;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
        iVar10 = 0x10;
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        puVar7 = (undefined4 *)(arg1 + 0x1c0);
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R14;
        puVar11 = (undefined8 *)(arg1 + 0xc0);
        do {
            if ((*(uint8_t *)puVar7 & 1) != 0) {
                uVar1 = *puVar11;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025465e;
                fcn.180224990(uVar1, 0x1804bf6a0, 0x19);
            }
            *puVar11 = 0;
            puVar11[0x10] = 0;
            *puVar7 = 0;
            puVar7[-0x60] = 0;
            puVar7[-0x70] = 0;
            puVar7[-0x50] = 0;
            puVar7[0x30] = 0xffffffff;
            uVar1 = puVar11[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546a3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar11[0x40];
            puVar11[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546c3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar11[0x40] = 0;
            puVar7 = puVar7 + 1;
            puVar11 = puVar11 + 1;
            iVar10 = iVar10 + -1;
        } while (iVar10 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546f5;
        puVar7 = (undefined4 *)func_0x000180221280();
        if (puVar7 != (undefined4 *)0x0) {
            iVar10 = 6;
            puVar5 = puVar7;
            do {
                puVar9 = (undefined4 *)arg1;
                puVar8 = puVar5;
                uVar2 = puVar8[1];
                uVar3 = puVar8[2];
                uVar4 = puVar8[3];
                *puVar9 = *puVar8;
                puVar9[1] = uVar2;
                puVar9[2] = uVar3;
                puVar9[3] = uVar4;
                uVar2 = puVar8[5];
                uVar3 = puVar8[6];
                uVar4 = puVar8[7];
                puVar9[4] = puVar8[4];
                puVar9[5] = uVar2;
                puVar9[6] = uVar3;
                puVar9[7] = uVar4;
                uVar2 = puVar8[9];
                uVar3 = puVar8[10];
                uVar4 = puVar8[0xb];
                puVar9[8] = puVar8[8];
                puVar9[9] = uVar2;
                puVar9[10] = uVar3;
                puVar9[0xb] = uVar4;
                uVar2 = puVar8[0xd];
                uVar3 = puVar8[0xe];
                uVar4 = puVar8[0xf];
                puVar9[0xc] = puVar8[0xc];
                puVar9[0xd] = uVar2;
                puVar9[0xe] = uVar3;
                puVar9[0xf] = uVar4;
                uVar2 = puVar8[0x11];
                uVar3 = puVar8[0x12];
                uVar4 = puVar8[0x13];
                puVar9[0x10] = puVar8[0x10];
                puVar9[0x11] = uVar2;
                puVar9[0x12] = uVar3;
                puVar9[0x13] = uVar4;
                uVar2 = puVar8[0x15];
                uVar3 = puVar8[0x16];
                uVar4 = puVar8[0x17];
                puVar9[0x14] = puVar8[0x14];
                puVar9[0x15] = uVar2;
                puVar9[0x16] = uVar3;
                puVar9[0x17] = uVar4;
                uVar2 = puVar8[0x19];
                uVar3 = puVar8[0x1a];
                uVar4 = puVar8[0x1b];
                puVar9[0x18] = puVar8[0x18];
                puVar9[0x19] = uVar2;
                puVar9[0x1a] = uVar3;
                puVar9[0x1b] = uVar4;
                uVar2 = puVar8[0x1d];
                uVar3 = puVar8[0x1e];
                uVar4 = puVar8[0x1f];
                puVar9[0x1c] = puVar8[0x1c];
                puVar9[0x1d] = uVar2;
                puVar9[0x1e] = uVar3;
                puVar9[0x1f] = uVar4;
                iVar10 = iVar10 + -1;
                puVar5 = puVar8 + 0x20;
                arg1 = (int64_t)(puVar9 + 0x20);
            } while (iVar10 != 0);
            uVar2 = puVar8[0x21];
            uVar3 = puVar8[0x22];
            uVar4 = puVar8[0x23];
            puVar9[0x20] = puVar8[0x20];
            puVar9[0x21] = uVar2;
            puVar9[0x22] = uVar3;
            puVar9[0x23] = uVar4;
            uVar2 = puVar8[0x25];
            uVar3 = puVar8[0x26];
            uVar4 = puVar8[0x27];
            puVar9[0x24] = puVar8[0x24];
            puVar9[0x25] = uVar2;
            puVar9[0x26] = uVar3;
            puVar9[0x27] = uVar4;
            uVar2 = puVar8[0x29];
            uVar3 = puVar8[0x2a];
            uVar4 = puVar8[0x2b];
            puVar9[0x28] = puVar8[0x28];
            puVar9[0x29] = uVar2;
            puVar9[0x2a] = uVar3;
            puVar9[0x2b] = uVar4;
            uVar2 = puVar8[0x2d];
            uVar3 = puVar8[0x2e];
            uVar4 = puVar8[0x2f];
            puVar9[0x2c] = puVar8[0x2c];
            puVar9[0x2d] = uVar2;
            puVar9[0x2e] = uVar3;
            puVar9[0x2f] = uVar4;
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar8 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025478f;
            fcn.1804986e0(puVar7, 0, 0x348);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180254701
// Address: 0x180254701
// Size: 148 bytes
// ============================================================
void fcn.180254600(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined8 unaff_RBP;
    int64_t iVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 *puVar11;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254614;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
        iVar10 = 0x10;
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RDI;
        puVar7 = (undefined4 *)(arg1 + 0x1c0);
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R14;
        puVar11 = (undefined8 *)(arg1 + 0xc0);
        do {
            if ((*(uint8_t *)puVar7 & 1) != 0) {
                uVar1 = *puVar11;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025465e;
                fcn.180224990(uVar1, 0x1804bf6a0, 0x19);
            }
            *puVar11 = 0;
            puVar11[0x10] = 0;
            *puVar7 = 0;
            puVar7[-0x60] = 0;
            puVar7[-0x70] = 0;
            puVar7[-0x50] = 0;
            puVar7[0x30] = 0xffffffff;
            uVar1 = puVar11[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546a3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar11[0x40];
            puVar11[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546c3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar11[0x40] = 0;
            puVar7 = puVar7 + 1;
            puVar11 = puVar11 + 1;
            iVar10 = iVar10 + -1;
        } while (iVar10 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802546f5;
        puVar7 = (undefined4 *)func_0x000180221280();
        if (puVar7 != (undefined4 *)0x0) {
            iVar10 = 6;
            puVar5 = puVar7;
            do {
                puVar9 = (undefined4 *)arg1;
                puVar8 = puVar5;
                uVar2 = puVar8[1];
                uVar3 = puVar8[2];
                uVar4 = puVar8[3];
                *puVar9 = *puVar8;
                puVar9[1] = uVar2;
                puVar9[2] = uVar3;
                puVar9[3] = uVar4;
                uVar2 = puVar8[5];
                uVar3 = puVar8[6];
                uVar4 = puVar8[7];
                puVar9[4] = puVar8[4];
                puVar9[5] = uVar2;
                puVar9[6] = uVar3;
                puVar9[7] = uVar4;
                uVar2 = puVar8[9];
                uVar3 = puVar8[10];
                uVar4 = puVar8[0xb];
                puVar9[8] = puVar8[8];
                puVar9[9] = uVar2;
                puVar9[10] = uVar3;
                puVar9[0xb] = uVar4;
                uVar2 = puVar8[0xd];
                uVar3 = puVar8[0xe];
                uVar4 = puVar8[0xf];
                puVar9[0xc] = puVar8[0xc];
                puVar9[0xd] = uVar2;
                puVar9[0xe] = uVar3;
                puVar9[0xf] = uVar4;
                uVar2 = puVar8[0x11];
                uVar3 = puVar8[0x12];
                uVar4 = puVar8[0x13];
                puVar9[0x10] = puVar8[0x10];
                puVar9[0x11] = uVar2;
                puVar9[0x12] = uVar3;
                puVar9[0x13] = uVar4;
                uVar2 = puVar8[0x15];
                uVar3 = puVar8[0x16];
                uVar4 = puVar8[0x17];
                puVar9[0x14] = puVar8[0x14];
                puVar9[0x15] = uVar2;
                puVar9[0x16] = uVar3;
                puVar9[0x17] = uVar4;
                uVar2 = puVar8[0x19];
                uVar3 = puVar8[0x1a];
                uVar4 = puVar8[0x1b];
                puVar9[0x18] = puVar8[0x18];
                puVar9[0x19] = uVar2;
                puVar9[0x1a] = uVar3;
                puVar9[0x1b] = uVar4;
                uVar2 = puVar8[0x1d];
                uVar3 = puVar8[0x1e];
                uVar4 = puVar8[0x1f];
                puVar9[0x1c] = puVar8[0x1c];
                puVar9[0x1d] = uVar2;
                puVar9[0x1e] = uVar3;
                puVar9[0x1f] = uVar4;
                iVar10 = iVar10 + -1;
                puVar5 = puVar8 + 0x20;
                arg1 = (int64_t)(puVar9 + 0x20);
            } while (iVar10 != 0);
            uVar2 = puVar8[0x21];
            uVar3 = puVar8[0x22];
            uVar4 = puVar8[0x23];
            puVar9[0x20] = puVar8[0x20];
            puVar9[0x21] = uVar2;
            puVar9[0x22] = uVar3;
            puVar9[0x23] = uVar4;
            uVar2 = puVar8[0x25];
            uVar3 = puVar8[0x26];
            uVar4 = puVar8[0x27];
            puVar9[0x24] = puVar8[0x24];
            puVar9[0x25] = uVar2;
            puVar9[0x26] = uVar3;
            puVar9[0x27] = uVar4;
            uVar2 = puVar8[0x29];
            uVar3 = puVar8[0x2a];
            uVar4 = puVar8[0x2b];
            puVar9[0x28] = puVar8[0x28];
            puVar9[0x29] = uVar2;
            puVar9[0x2a] = uVar3;
            puVar9[0x2b] = uVar4;
            uVar2 = puVar8[0x2d];
            uVar3 = puVar8[0x2e];
            uVar4 = puVar8[0x2f];
            puVar9[0x2c] = puVar8[0x2c];
            puVar9[0x2d] = uVar2;
            puVar9[0x2e] = uVar3;
            puVar9[0x2f] = uVar4;
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar8 + 0x30);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025478f;
            fcn.1804986e0(puVar7, 0, 0x348);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802547a0
// Address: 0x1802547a0
// Size: 24 bytes
// ============================================================
void fcn.1802547a0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    uint32_t uVar15;
    undefined8 unaff_RDI;
    undefined8 *puVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802547b5;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802547d9;
        iVar5 = func_0x000180221280();
        uVar9 = 0;
        iVar3 = 0;
        if (iVar5 == 0) {
            puVar16 = (undefined8 *)(arg1 + 0xc0);
            iVar5 = 0x10;
            puVar14 = (undefined4 *)(arg1 + 0x1c0);
            do {
                if ((*(uint8_t *)puVar14 & 1) != 0) {
                    uVar2 = *puVar16;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025481a;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                }
                *puVar16 = 0;
                puVar16[0x10] = 0;
                *puVar14 = 0;
                puVar14[-0x60] = 0;
                puVar14[-0x70] = 0;
                puVar14[-0x50] = 0;
                puVar14[0x30] = 0xffffffff;
                uVar2 = puVar16[0x28];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025485b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                uVar2 = puVar16[0x40];
                puVar16[0x28] = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025487b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                puVar16[0x40] = 0;
                puVar14 = puVar14 + 1;
                puVar16 = puVar16 + 1;
                iVar5 = iVar5 + -1;
            } while (iVar5 != 0);
            *(undefined8 *)(arg1 + 0x340) = 0;
        } else {
            uVar11 = *(uint32_t *)(iVar5 + 0x340);
            uVar12 = (uint64_t)(int32_t)uVar11;
            iVar6 = 0;
            uVar13 = uVar12;
            iVar7 = iVar6;
            while ((*(uint32_t *)(iVar5 + 0x344) != uVar11 &&
                   (uVar11 = (uint32_t)uVar13, *(int32_t *)(iVar5 + 0x40 + uVar12 * 4) == 0))) {
                if ((int64_t)uVar12 < 1) {
                    uVar13 = 0xf;
                    uVar12 = 0xf;
                } else {
                    uVar13 = (uint64_t)(uVar11 - 1);
                    uVar12 = uVar12 - 1;
                }
                iVar7 = iVar7 + 1;
                uVar11 = (uint32_t)uVar13;
            }
            *(int64_t *)((int64_t)&arg_60h + iVar4) = (int64_t)iVar7;
            if (0 < iVar7) {
                *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
                puVar14 = (undefined4 *)(arg1 + 0x80);
                *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R13;
                puVar16 = (undefined8 *)(arg1 + 0xc0);
                *(int32_t *)((int64_t)&arg_58h + iVar4) = iVar7;
                uVar15 = uVar11;
                do {
                    uVar15 = uVar15 + 1 & 0x8000000f;
                    if ((int32_t)uVar15 < 0) {
                        uVar15 = (uVar15 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(puVar14 + 0x50) & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254942;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    puVar14[0x50] = 0;
                    puVar14[-0x10] = 0;
                    puVar14[-0x20] = 0;
                    *puVar14 = 0;
                    puVar14[0x80] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254988;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802549a8;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    iVar8 = (int64_t)(int32_t)uVar15;
                    puVar14[-0x20] = *(undefined4 *)(iVar5 + iVar8 * 4);
                    puVar14[-0x10] = 0;
                    *puVar14 = *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4);
                    *puVar16 = *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8);
                    puVar16[0x10] = *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8);
                    puVar14[0x50] = *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4);
                    puVar16[0x28] = *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8);
                    puVar14[0x80] = *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4);
                    puVar14 = puVar14 + 1;
                    puVar16[0x40] = *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8);
                    puVar16 = puVar16 + 1;
                    piVar1 = (int64_t *)((int64_t)&arg_60h + iVar4);
                    *piVar1 = *piVar1 + -1;
                    iVar10 = *piVar1;
                    *(undefined4 *)(iVar5 + iVar8 * 4) = 0;
                    *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8) = 0;
                    *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8) = 0;
                } while (iVar10 != 0);
                iVar6 = *(int32_t *)((int64_t)&arg_58h + iVar4);
            }
            if (0 < iVar6) {
                *(uint32_t *)(iVar5 + 0x340) = uVar11;
                iVar3 = iVar6 + -1;
                uVar9 = 0xf;
            }
            *(int32_t *)(arg1 + 0x340) = iVar3;
            iVar5 = (int64_t)iVar6;
            *(undefined4 *)(arg1 + 0x344) = uVar9;
            if (iVar5 < 0x10) {
                iVar10 = 0x10 - iVar5;
                puVar16 = (undefined8 *)(arg1 + 0xc0 + iVar5 * 8);
                puVar14 = (undefined4 *)(arg1 + 0x1c0 + iVar5 * 4);
                do {
                    if ((*(uint8_t *)puVar14 & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254aea;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    *puVar14 = 0;
                    puVar14[-0x60] = 0;
                    puVar14[-0x70] = 0;
                    puVar14[-0x50] = 0;
                    puVar14[0x30] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b2b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b4b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    puVar14 = puVar14 + 1;
                    puVar16 = puVar16 + 1;
                    iVar10 = iVar10 + -1;
                } while (iVar10 != 0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802547b8
// Address: 0x1802547b8
// Size: 314 bytes
// ============================================================
void fcn.1802547a0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    uint32_t uVar15;
    undefined8 unaff_RDI;
    undefined8 *puVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802547b5;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802547d9;
        iVar5 = func_0x000180221280();
        uVar9 = 0;
        iVar3 = 0;
        if (iVar5 == 0) {
            puVar16 = (undefined8 *)(arg1 + 0xc0);
            iVar5 = 0x10;
            puVar14 = (undefined4 *)(arg1 + 0x1c0);
            do {
                if ((*(uint8_t *)puVar14 & 1) != 0) {
                    uVar2 = *puVar16;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025481a;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                }
                *puVar16 = 0;
                puVar16[0x10] = 0;
                *puVar14 = 0;
                puVar14[-0x60] = 0;
                puVar14[-0x70] = 0;
                puVar14[-0x50] = 0;
                puVar14[0x30] = 0xffffffff;
                uVar2 = puVar16[0x28];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025485b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                uVar2 = puVar16[0x40];
                puVar16[0x28] = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025487b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                puVar16[0x40] = 0;
                puVar14 = puVar14 + 1;
                puVar16 = puVar16 + 1;
                iVar5 = iVar5 + -1;
            } while (iVar5 != 0);
            *(undefined8 *)(arg1 + 0x340) = 0;
        } else {
            uVar11 = *(uint32_t *)(iVar5 + 0x340);
            uVar12 = (uint64_t)(int32_t)uVar11;
            iVar6 = 0;
            uVar13 = uVar12;
            iVar7 = iVar6;
            while ((*(uint32_t *)(iVar5 + 0x344) != uVar11 &&
                   (uVar11 = (uint32_t)uVar13, *(int32_t *)(iVar5 + 0x40 + uVar12 * 4) == 0))) {
                if ((int64_t)uVar12 < 1) {
                    uVar13 = 0xf;
                    uVar12 = 0xf;
                } else {
                    uVar13 = (uint64_t)(uVar11 - 1);
                    uVar12 = uVar12 - 1;
                }
                iVar7 = iVar7 + 1;
                uVar11 = (uint32_t)uVar13;
            }
            *(int64_t *)((int64_t)&arg_60h + iVar4) = (int64_t)iVar7;
            if (0 < iVar7) {
                *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
                puVar14 = (undefined4 *)(arg1 + 0x80);
                *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R13;
                puVar16 = (undefined8 *)(arg1 + 0xc0);
                *(int32_t *)((int64_t)&arg_58h + iVar4) = iVar7;
                uVar15 = uVar11;
                do {
                    uVar15 = uVar15 + 1 & 0x8000000f;
                    if ((int32_t)uVar15 < 0) {
                        uVar15 = (uVar15 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(puVar14 + 0x50) & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254942;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    puVar14[0x50] = 0;
                    puVar14[-0x10] = 0;
                    puVar14[-0x20] = 0;
                    *puVar14 = 0;
                    puVar14[0x80] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254988;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802549a8;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    iVar8 = (int64_t)(int32_t)uVar15;
                    puVar14[-0x20] = *(undefined4 *)(iVar5 + iVar8 * 4);
                    puVar14[-0x10] = 0;
                    *puVar14 = *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4);
                    *puVar16 = *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8);
                    puVar16[0x10] = *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8);
                    puVar14[0x50] = *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4);
                    puVar16[0x28] = *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8);
                    puVar14[0x80] = *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4);
                    puVar14 = puVar14 + 1;
                    puVar16[0x40] = *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8);
                    puVar16 = puVar16 + 1;
                    piVar1 = (int64_t *)((int64_t)&arg_60h + iVar4);
                    *piVar1 = *piVar1 + -1;
                    iVar10 = *piVar1;
                    *(undefined4 *)(iVar5 + iVar8 * 4) = 0;
                    *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8) = 0;
                    *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8) = 0;
                } while (iVar10 != 0);
                iVar6 = *(int32_t *)((int64_t)&arg_58h + iVar4);
            }
            if (0 < iVar6) {
                *(uint32_t *)(iVar5 + 0x340) = uVar11;
                iVar3 = iVar6 + -1;
                uVar9 = 0xf;
            }
            *(int32_t *)(arg1 + 0x340) = iVar3;
            iVar5 = (int64_t)iVar6;
            *(undefined4 *)(arg1 + 0x344) = uVar9;
            if (iVar5 < 0x10) {
                iVar10 = 0x10 - iVar5;
                puVar16 = (undefined8 *)(arg1 + 0xc0 + iVar5 * 8);
                puVar14 = (undefined4 *)(arg1 + 0x1c0 + iVar5 * 4);
                do {
                    if ((*(uint8_t *)puVar14 & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254aea;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    *puVar14 = 0;
                    puVar14[-0x60] = 0;
                    puVar14[-0x70] = 0;
                    puVar14[-0x50] = 0;
                    puVar14[0x30] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b2b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b4b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    puVar14 = puVar14 + 1;
                    puVar16 = puVar16 + 1;
                    iVar10 = iVar10 + -1;
                } while (iVar10 != 0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802548f2
// Address: 0x1802548f2
// Size: 401 bytes
// ============================================================
void fcn.1802547a0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    uint32_t uVar15;
    undefined8 unaff_RDI;
    undefined8 *puVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802547b5;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802547d9;
        iVar5 = func_0x000180221280();
        uVar9 = 0;
        iVar3 = 0;
        if (iVar5 == 0) {
            puVar16 = (undefined8 *)(arg1 + 0xc0);
            iVar5 = 0x10;
            puVar14 = (undefined4 *)(arg1 + 0x1c0);
            do {
                if ((*(uint8_t *)puVar14 & 1) != 0) {
                    uVar2 = *puVar16;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025481a;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                }
                *puVar16 = 0;
                puVar16[0x10] = 0;
                *puVar14 = 0;
                puVar14[-0x60] = 0;
                puVar14[-0x70] = 0;
                puVar14[-0x50] = 0;
                puVar14[0x30] = 0xffffffff;
                uVar2 = puVar16[0x28];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025485b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                uVar2 = puVar16[0x40];
                puVar16[0x28] = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025487b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                puVar16[0x40] = 0;
                puVar14 = puVar14 + 1;
                puVar16 = puVar16 + 1;
                iVar5 = iVar5 + -1;
            } while (iVar5 != 0);
            *(undefined8 *)(arg1 + 0x340) = 0;
        } else {
            uVar11 = *(uint32_t *)(iVar5 + 0x340);
            uVar12 = (uint64_t)(int32_t)uVar11;
            iVar6 = 0;
            uVar13 = uVar12;
            iVar7 = iVar6;
            while ((*(uint32_t *)(iVar5 + 0x344) != uVar11 &&
                   (uVar11 = (uint32_t)uVar13, *(int32_t *)(iVar5 + 0x40 + uVar12 * 4) == 0))) {
                if ((int64_t)uVar12 < 1) {
                    uVar13 = 0xf;
                    uVar12 = 0xf;
                } else {
                    uVar13 = (uint64_t)(uVar11 - 1);
                    uVar12 = uVar12 - 1;
                }
                iVar7 = iVar7 + 1;
                uVar11 = (uint32_t)uVar13;
            }
            *(int64_t *)((int64_t)&arg_60h + iVar4) = (int64_t)iVar7;
            if (0 < iVar7) {
                *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
                puVar14 = (undefined4 *)(arg1 + 0x80);
                *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R13;
                puVar16 = (undefined8 *)(arg1 + 0xc0);
                *(int32_t *)((int64_t)&arg_58h + iVar4) = iVar7;
                uVar15 = uVar11;
                do {
                    uVar15 = uVar15 + 1 & 0x8000000f;
                    if ((int32_t)uVar15 < 0) {
                        uVar15 = (uVar15 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(puVar14 + 0x50) & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254942;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    puVar14[0x50] = 0;
                    puVar14[-0x10] = 0;
                    puVar14[-0x20] = 0;
                    *puVar14 = 0;
                    puVar14[0x80] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254988;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802549a8;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    iVar8 = (int64_t)(int32_t)uVar15;
                    puVar14[-0x20] = *(undefined4 *)(iVar5 + iVar8 * 4);
                    puVar14[-0x10] = 0;
                    *puVar14 = *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4);
                    *puVar16 = *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8);
                    puVar16[0x10] = *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8);
                    puVar14[0x50] = *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4);
                    puVar16[0x28] = *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8);
                    puVar14[0x80] = *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4);
                    puVar14 = puVar14 + 1;
                    puVar16[0x40] = *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8);
                    puVar16 = puVar16 + 1;
                    piVar1 = (int64_t *)((int64_t)&arg_60h + iVar4);
                    *piVar1 = *piVar1 + -1;
                    iVar10 = *piVar1;
                    *(undefined4 *)(iVar5 + iVar8 * 4) = 0;
                    *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8) = 0;
                    *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8) = 0;
                } while (iVar10 != 0);
                iVar6 = *(int32_t *)((int64_t)&arg_58h + iVar4);
            }
            if (0 < iVar6) {
                *(uint32_t *)(iVar5 + 0x340) = uVar11;
                iVar3 = iVar6 + -1;
                uVar9 = 0xf;
            }
            *(int32_t *)(arg1 + 0x340) = iVar3;
            iVar5 = (int64_t)iVar6;
            *(undefined4 *)(arg1 + 0x344) = uVar9;
            if (iVar5 < 0x10) {
                iVar10 = 0x10 - iVar5;
                puVar16 = (undefined8 *)(arg1 + 0xc0 + iVar5 * 8);
                puVar14 = (undefined4 *)(arg1 + 0x1c0 + iVar5 * 4);
                do {
                    if ((*(uint8_t *)puVar14 & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254aea;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    *puVar14 = 0;
                    puVar14[-0x60] = 0;
                    puVar14[-0x70] = 0;
                    puVar14[-0x50] = 0;
                    puVar14[0x30] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b2b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b4b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    puVar14 = puVar14 + 1;
                    puVar16 = puVar16 + 1;
                    iVar10 = iVar10 + -1;
                } while (iVar10 != 0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180254a83
// Address: 0x180254a83
// Size: 256 bytes
// ============================================================
void fcn.1802547a0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    uint32_t uVar15;
    undefined8 unaff_RDI;
    undefined8 *puVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802547b5;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802547d9;
        iVar5 = func_0x000180221280();
        uVar9 = 0;
        iVar3 = 0;
        if (iVar5 == 0) {
            puVar16 = (undefined8 *)(arg1 + 0xc0);
            iVar5 = 0x10;
            puVar14 = (undefined4 *)(arg1 + 0x1c0);
            do {
                if ((*(uint8_t *)puVar14 & 1) != 0) {
                    uVar2 = *puVar16;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025481a;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                }
                *puVar16 = 0;
                puVar16[0x10] = 0;
                *puVar14 = 0;
                puVar14[-0x60] = 0;
                puVar14[-0x70] = 0;
                puVar14[-0x50] = 0;
                puVar14[0x30] = 0xffffffff;
                uVar2 = puVar16[0x28];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025485b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                uVar2 = puVar16[0x40];
                puVar16[0x28] = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025487b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                puVar16[0x40] = 0;
                puVar14 = puVar14 + 1;
                puVar16 = puVar16 + 1;
                iVar5 = iVar5 + -1;
            } while (iVar5 != 0);
            *(undefined8 *)(arg1 + 0x340) = 0;
        } else {
            uVar11 = *(uint32_t *)(iVar5 + 0x340);
            uVar12 = (uint64_t)(int32_t)uVar11;
            iVar6 = 0;
            uVar13 = uVar12;
            iVar7 = iVar6;
            while ((*(uint32_t *)(iVar5 + 0x344) != uVar11 &&
                   (uVar11 = (uint32_t)uVar13, *(int32_t *)(iVar5 + 0x40 + uVar12 * 4) == 0))) {
                if ((int64_t)uVar12 < 1) {
                    uVar13 = 0xf;
                    uVar12 = 0xf;
                } else {
                    uVar13 = (uint64_t)(uVar11 - 1);
                    uVar12 = uVar12 - 1;
                }
                iVar7 = iVar7 + 1;
                uVar11 = (uint32_t)uVar13;
            }
            *(int64_t *)((int64_t)&arg_60h + iVar4) = (int64_t)iVar7;
            if (0 < iVar7) {
                *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
                puVar14 = (undefined4 *)(arg1 + 0x80);
                *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R13;
                puVar16 = (undefined8 *)(arg1 + 0xc0);
                *(int32_t *)((int64_t)&arg_58h + iVar4) = iVar7;
                uVar15 = uVar11;
                do {
                    uVar15 = uVar15 + 1 & 0x8000000f;
                    if ((int32_t)uVar15 < 0) {
                        uVar15 = (uVar15 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(puVar14 + 0x50) & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254942;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    puVar14[0x50] = 0;
                    puVar14[-0x10] = 0;
                    puVar14[-0x20] = 0;
                    *puVar14 = 0;
                    puVar14[0x80] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254988;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802549a8;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    iVar8 = (int64_t)(int32_t)uVar15;
                    puVar14[-0x20] = *(undefined4 *)(iVar5 + iVar8 * 4);
                    puVar14[-0x10] = 0;
                    *puVar14 = *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4);
                    *puVar16 = *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8);
                    puVar16[0x10] = *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8);
                    puVar14[0x50] = *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4);
                    puVar16[0x28] = *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8);
                    puVar14[0x80] = *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4);
                    puVar14 = puVar14 + 1;
                    puVar16[0x40] = *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8);
                    puVar16 = puVar16 + 1;
                    piVar1 = (int64_t *)((int64_t)&arg_60h + iVar4);
                    *piVar1 = *piVar1 + -1;
                    iVar10 = *piVar1;
                    *(undefined4 *)(iVar5 + iVar8 * 4) = 0;
                    *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8) = 0;
                    *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8) = 0;
                } while (iVar10 != 0);
                iVar6 = *(int32_t *)((int64_t)&arg_58h + iVar4);
            }
            if (0 < iVar6) {
                *(uint32_t *)(iVar5 + 0x340) = uVar11;
                iVar3 = iVar6 + -1;
                uVar9 = 0xf;
            }
            *(int32_t *)(arg1 + 0x340) = iVar3;
            iVar5 = (int64_t)iVar6;
            *(undefined4 *)(arg1 + 0x344) = uVar9;
            if (iVar5 < 0x10) {
                iVar10 = 0x10 - iVar5;
                puVar16 = (undefined8 *)(arg1 + 0xc0 + iVar5 * 8);
                puVar14 = (undefined4 *)(arg1 + 0x1c0 + iVar5 * 4);
                do {
                    if ((*(uint8_t *)puVar14 & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254aea;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    *puVar14 = 0;
                    puVar14[-0x60] = 0;
                    puVar14[-0x70] = 0;
                    puVar14[-0x50] = 0;
                    puVar14[0x30] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b2b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b4b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    puVar14 = puVar14 + 1;
                    puVar16 = puVar16 + 1;
                    iVar10 = iVar10 + -1;
                } while (iVar10 != 0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180254b83
// Address: 0x180254b83
// Size: 1 bytes
// ============================================================
void fcn.1802547a0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined4 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RSI;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    uint32_t uVar15;
    undefined8 unaff_RDI;
    undefined8 *puVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802547b5;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802547d9;
        iVar5 = func_0x000180221280();
        uVar9 = 0;
        iVar3 = 0;
        if (iVar5 == 0) {
            puVar16 = (undefined8 *)(arg1 + 0xc0);
            iVar5 = 0x10;
            puVar14 = (undefined4 *)(arg1 + 0x1c0);
            do {
                if ((*(uint8_t *)puVar14 & 1) != 0) {
                    uVar2 = *puVar16;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025481a;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                }
                *puVar16 = 0;
                puVar16[0x10] = 0;
                *puVar14 = 0;
                puVar14[-0x60] = 0;
                puVar14[-0x70] = 0;
                puVar14[-0x50] = 0;
                puVar14[0x30] = 0xffffffff;
                uVar2 = puVar16[0x28];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025485b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                uVar2 = puVar16[0x40];
                puVar16[0x28] = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025487b;
                fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                puVar16[0x40] = 0;
                puVar14 = puVar14 + 1;
                puVar16 = puVar16 + 1;
                iVar5 = iVar5 + -1;
            } while (iVar5 != 0);
            *(undefined8 *)(arg1 + 0x340) = 0;
        } else {
            uVar11 = *(uint32_t *)(iVar5 + 0x340);
            uVar12 = (uint64_t)(int32_t)uVar11;
            iVar6 = 0;
            uVar13 = uVar12;
            iVar7 = iVar6;
            while ((*(uint32_t *)(iVar5 + 0x344) != uVar11 &&
                   (uVar11 = (uint32_t)uVar13, *(int32_t *)(iVar5 + 0x40 + uVar12 * 4) == 0))) {
                if ((int64_t)uVar12 < 1) {
                    uVar13 = 0xf;
                    uVar12 = 0xf;
                } else {
                    uVar13 = (uint64_t)(uVar11 - 1);
                    uVar12 = uVar12 - 1;
                }
                iVar7 = iVar7 + 1;
                uVar11 = (uint32_t)uVar13;
            }
            *(int64_t *)((int64_t)&arg_60h + iVar4) = (int64_t)iVar7;
            if (0 < iVar7) {
                *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R12;
                puVar14 = (undefined4 *)(arg1 + 0x80);
                *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R13;
                puVar16 = (undefined8 *)(arg1 + 0xc0);
                *(int32_t *)((int64_t)&arg_58h + iVar4) = iVar7;
                uVar15 = uVar11;
                do {
                    uVar15 = uVar15 + 1 & 0x8000000f;
                    if ((int32_t)uVar15 < 0) {
                        uVar15 = (uVar15 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(puVar14 + 0x50) & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254942;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    puVar14[0x50] = 0;
                    puVar14[-0x10] = 0;
                    puVar14[-0x20] = 0;
                    *puVar14 = 0;
                    puVar14[0x80] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254988;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802549a8;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    iVar8 = (int64_t)(int32_t)uVar15;
                    puVar14[-0x20] = *(undefined4 *)(iVar5 + iVar8 * 4);
                    puVar14[-0x10] = 0;
                    *puVar14 = *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4);
                    *puVar16 = *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8);
                    puVar16[0x10] = *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8);
                    puVar14[0x50] = *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4);
                    puVar16[0x28] = *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8);
                    puVar14[0x80] = *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4);
                    puVar14 = puVar14 + 1;
                    puVar16[0x40] = *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8);
                    puVar16 = puVar16 + 1;
                    piVar1 = (int64_t *)((int64_t)&arg_60h + iVar4);
                    *piVar1 = *piVar1 + -1;
                    iVar10 = *piVar1;
                    *(undefined4 *)(iVar5 + iVar8 * 4) = 0;
                    *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0xc0 + iVar8 * 8) = 0;
                    *(undefined8 *)(iVar5 + 0x140 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x200 + iVar8 * 8) = 0;
                    *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4) = 0;
                    *(undefined8 *)(iVar5 + 0x2c0 + iVar8 * 8) = 0;
                } while (iVar10 != 0);
                iVar6 = *(int32_t *)((int64_t)&arg_58h + iVar4);
            }
            if (0 < iVar6) {
                *(uint32_t *)(iVar5 + 0x340) = uVar11;
                iVar3 = iVar6 + -1;
                uVar9 = 0xf;
            }
            *(int32_t *)(arg1 + 0x340) = iVar3;
            iVar5 = (int64_t)iVar6;
            *(undefined4 *)(arg1 + 0x344) = uVar9;
            if (iVar5 < 0x10) {
                iVar10 = 0x10 - iVar5;
                puVar16 = (undefined8 *)(arg1 + 0xc0 + iVar5 * 8);
                puVar14 = (undefined4 *)(arg1 + 0x1c0 + iVar5 * 4);
                do {
                    if ((*(uint8_t *)puVar14 & 1) != 0) {
                        uVar2 = *puVar16;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254aea;
                        fcn.180224990(uVar2, 0x1804bf6a0, 0x19);
                    }
                    *puVar16 = 0;
                    puVar16[0x10] = 0;
                    *puVar14 = 0;
                    puVar14[-0x60] = 0;
                    puVar14[-0x70] = 0;
                    puVar14[-0x50] = 0;
                    puVar14[0x30] = 0xffffffff;
                    uVar2 = puVar16[0x28];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b2b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5b);
                    uVar2 = puVar16[0x40];
                    puVar16[0x28] = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180254b4b;
                    fcn.180224990(uVar2, 0x1804bf6a0, 0x5d);
                    puVar16[0x40] = 0;
                    puVar14 = puVar14 + 1;
                    puVar16 = puVar16 + 1;
                    iVar10 = iVar10 + -1;
                } while (iVar10 != 0);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180254b90
// Address: 0x180254b90
// Size: 41 bytes
// ============================================================
void fcn.180254b90(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    if (arg1 != 0) {
        uStack_8 = 0x180254b9f;
        iVar1 = fcn.18045a350();
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180254bb4;
        fcn.180224990();
    }
    return;
}

// ============================================================
// Function: FUN_180254bc0
// Address: 0x180254bc0
// Size: 40 bytes
// ============================================================
int64_t fcn.180254bc0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar6;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = 0x44c;
    iVar5 = 0x1804e5df0;
    iVar4 = 0x18;
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802248e5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)0x1806a0020 == fcn.1802248d0) {
        if (iVar4 == 0) {
            return 0;
        }
        if (*(int32_t *)0x1806a0018 != 0) {
            *(int32_t *)0x1806a0018 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224943;
        iVar4 = fcn.18046d050(iVar4);
        if (iVar4 != 0) {
            return iVar4;
        }
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224909;
        iVar2 = (**(code **)0x1806a0020)(iVar4);
        if (iVar2 != 0) {
            return iVar2;
        }
        if (iVar4 == 0) {
            return 0;
        }
    }
    if ((iVar5 != 0) || (iVar6 != 0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224956;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar1 + iVar3), *(int64_t *)(&stack0x00000048 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224963;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar1 + iVar3), *(int64_t *)(&stack0x00000048 + iVar1 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar1 + iVar3), *(int64_t *)(&stack0x00000058 + iVar1 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar1 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224975;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar1 + iVar3));
    }
    return 0;
}

// ============================================================
// Function: FUN_180254c30
// Address: 0x180254c30
// Size: 34 bytes
// ============================================================
void fcn.180254c30(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180254c3a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180254c4d;
    fcn.180255b10(*(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180254c60
// Address: 0x180254c60
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180254c60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int32_t iVar5;
    int64_t in_RDX;
    bool bVar6;
    uint8_t uVar7;
    uint8_t *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180254c72;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    bVar6 = false;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180254c82;
    iVar3 = fcn.180255500(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4));
    iVar5 = *(uint32_t *)((int64_t)in_RCX + 0xc) << 3;
    iVar3 = (int32_t)(iVar3 + 7 + (iVar3 + 7 >> 0x1f & 7U)) >> 3;
    if ((*(uint32_t *)((int64_t)in_RCX + 0xc) & 0x1fffffff) == 0) {
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180254cb1;
            fcn.1804986e0(in_RDX, iVar5, (int64_t)iVar3);
            return iVar3;
        }
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
        iVar2 = *(int32_t *)(in_RCX + 1);
        puVar8 = (uint8_t *)((iVar3 + -1) + in_RDX);
        uVar9 = 0;
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R15;
        if (iVar3 != 0) {
            do {
                uVar7 = (uint8_t)(*(uint64_t *)(*in_RCX + (uVar9 & 0xfffffffffffffff8)) >> (((uint8_t)uVar9 & 7) << 3))
                        & (uint8_t)((int64_t)(uVar10 - (int64_t)(iVar2 << 3)) >> 0x3f);
                uVar1 = uVar7 + bVar6;
                *puVar8 = uVar1;
                bVar6 = uVar1 < uVar7;
                uVar10 = uVar10 + 1;
                uVar9 = uVar9 - ((int64_t)(uVar9 - ((int64_t)iVar5 + -1)) >> 0x3f);
                puVar8 = puVar8 + -1;
            } while (uVar10 < (uint64_t)(int64_t)iVar3);
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180254cc3
// Address: 0x180254cc3
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180254c60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int32_t iVar5;
    int64_t in_RDX;
    bool bVar6;
    uint8_t uVar7;
    uint8_t *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180254c72;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    bVar6 = false;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180254c82;
    iVar3 = fcn.180255500(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4));
    iVar5 = *(uint32_t *)((int64_t)in_RCX + 0xc) << 3;
    iVar3 = (int32_t)(iVar3 + 7 + (iVar3 + 7 >> 0x1f & 7U)) >> 3;
    if ((*(uint32_t *)((int64_t)in_RCX + 0xc) & 0x1fffffff) == 0) {
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180254cb1;
            fcn.1804986e0(in_RDX, iVar5, (int64_t)iVar3);
            return iVar3;
        }
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
        iVar2 = *(int32_t *)(in_RCX + 1);
        puVar8 = (uint8_t *)((iVar3 + -1) + in_RDX);
        uVar9 = 0;
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R15;
        if (iVar3 != 0) {
            do {
                uVar7 = (uint8_t)(*(uint64_t *)(*in_RCX + (uVar9 & 0xfffffffffffffff8)) >> (((uint8_t)uVar9 & 7) << 3))
                        & (uint8_t)((int64_t)(uVar10 - (int64_t)(iVar2 << 3)) >> 0x3f);
                uVar1 = uVar7 + bVar6;
                *puVar8 = uVar1;
                bVar6 = uVar1 < uVar7;
                uVar10 = uVar10 + 1;
                uVar9 = uVar9 - ((int64_t)(uVar9 - ((int64_t)iVar5 + -1)) >> 0x3f);
                puVar8 = puVar8 + -1;
            } while (uVar10 < (uint64_t)(int64_t)iVar3);
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180254d4e
// Address: 0x180254d4e
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180254c60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int32_t iVar5;
    int64_t in_RDX;
    bool bVar6;
    uint8_t uVar7;
    uint8_t *puVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180254c72;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    bVar6 = false;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180254c82;
    iVar3 = fcn.180255500(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4));
    iVar5 = *(uint32_t *)((int64_t)in_RCX + 0xc) << 3;
    iVar3 = (int32_t)(iVar3 + 7 + (iVar3 + 7 >> 0x1f & 7U)) >> 3;
    if ((*(uint32_t *)((int64_t)in_RCX + 0xc) & 0x1fffffff) == 0) {
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180254cb1;
            fcn.1804986e0(in_RDX, iVar5, (int64_t)iVar3);
            return iVar3;
        }
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
        iVar2 = *(int32_t *)(in_RCX + 1);
        puVar8 = (uint8_t *)((iVar3 + -1) + in_RDX);
        uVar9 = 0;
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R15;
        if (iVar3 != 0) {
            do {
                uVar7 = (uint8_t)(*(uint64_t *)(*in_RCX + (uVar9 & 0xfffffffffffffff8)) >> (((uint8_t)uVar9 & 7) << 3))
                        & (uint8_t)((int64_t)(uVar10 - (int64_t)(iVar2 << 3)) >> 0x3f);
                uVar1 = uVar7 + bVar6;
                *puVar8 = uVar1;
                bVar6 = uVar1 < uVar7;
                uVar10 = uVar10 + 1;
                uVar9 = uVar9 - ((int64_t)(uVar9 - ((int64_t)iVar5 + -1)) >> 0x3f);
                puVar8 = puVar8 + -1;
            } while (uVar10 < (uint64_t)(int64_t)iVar3);
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180254d60
// Address: 0x180254d60
// Size: 49 bytes
// ============================================================
undefined8 fcn.180254d60(undefined8 param_1, undefined8 param_2, int32_t param_3)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180254d6a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_3 < 0) {
        return 0xffffffff;
    }
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180254d8c;
    uVar2 = fcn.180255d90(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_180254da0
// Address: 0x180254da0
// Size: 52 bytes
// ============================================================
undefined8 fcn.180254da0(undefined8 param_1, undefined8 param_2, int32_t param_3)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180254daa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_3 < 0) {
        return 0xffffffff;
    }
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180254dcf;
    uVar2 = fcn.180255d90(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_180254de0
// Address: 0x180254de0
// Size: 57 bytes
// ============================================================
void fcn.180254de0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254df0;
        iVar3 = fcn.18045a350();
        iVar2 = *(int64_t *)arg1;
        if (iVar2 != 0) {
            iVar1 = *(int32_t *)(arg1 + 0xc);
            *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x180254e0b;
            fcn.180244fc0(iVar2, (int64_t)iVar1 << 3);
        }
        *(undefined4 *)(arg1 + 0x10) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180254e90
// Address: 0x180254e90
// Size: 126 bytes
// ============================================================
void fcn.180254e90(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180254ea0;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        iVar2 = *(int64_t *)arg1;
        if ((iVar2 != 0) && ((*(uint32_t *)(arg1 + 0x14) & 2) == 0)) {
            iVar1 = *(int32_t *)(arg1 + 0xc);
            if ((*(uint32_t *)(arg1 + 0x14) & 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180254ee0;
                func_0x000180224b90(iVar2, (int64_t)iVar1 << 3, 0x1804e5df0, 0xd0);
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180254ed3;
                func_0x000180225130();
            }
        }
        if ((*(uint8_t *)(arg1 + 0x14) & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180254ef3;
            fcn.180244fc0(arg1, 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180254f08;
            fcn.180224990(arg1, 0x1804e5df0, 0xde);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180254fa0
// Address: 0x180254fa0
// Size: 353 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180254fa0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    uint32_t *puVar2;
    uint64_t *puVar3;
    uint32_t *puVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    uint32_t uVar15;
    int32_t iVar16;
    int32_t iVar17;
    int32_t iVar18;
    uint32_t uVar19;
    uint64_t uVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    int64_t iVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint32_t uVar27;
    uint32_t uVar28;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar23 = (uint32_t)arg4;
    iVar21 = (int64_t)(int32_t)uVar23;
    uVar20 = 0xffffffffffffffff - ((int64_t)(arg1 - 1U & ~arg1) >> 0x3f);
    uVar19 = (uint32_t)uVar20;
    uVar15 = (*(uint32_t *)(arg2 + 8) ^ *(uint32_t *)(arg3 + 8)) & uVar19;
    *(uint32_t *)(arg2 + 8) = *(uint32_t *)(arg2 + 8) ^ uVar15;
    *(uint32_t *)(arg3 + 8) = *(uint32_t *)(arg3 + 8) ^ uVar15;
    iVar16 = 0;
    uVar15 = (*(uint32_t *)(arg2 + 0x10) ^ *(uint32_t *)(arg3 + 0x10)) & uVar19;
    *(uint32_t *)(arg2 + 0x10) = *(uint32_t *)(arg2 + 0x10) ^ uVar15;
    *(uint32_t *)(arg3 + 0x10) = *(uint32_t *)(arg3 + 0x10) ^ uVar15;
    uVar15 = (*(uint32_t *)(arg2 + 0x14) ^ *(uint32_t *)(arg3 + 0x14)) & uVar19 & 4;
    *(uint32_t *)(arg2 + 0x14) = *(uint32_t *)(arg2 + 0x14) ^ uVar15;
    *(uint32_t *)(arg3 + 0x14) = *(uint32_t *)(arg3 + 0x14) ^ uVar15;
    iVar17 = 0;
    iVar18 = iVar16;
    if ((0 < (int32_t)uVar23) && (1 < uVar23)) {
        uVar5 = *(uint64_t *)arg3;
        uVar6 = *(uint64_t *)arg2;
        uVar22 = uVar5 + (iVar21 + -1) * 8;
        uVar1 = uVar6 + (iVar21 + -1) * 8;
        if (((uVar1 < uVar5) || (uVar22 < uVar6)) &&
           ((((iVar18 = iVar17, (uint64_t)arg3 < uVar5 || (uVar22 < (uint64_t)arg3)) &&
             (((uint64_t)arg2 < uVar5 || (uVar22 < (uint64_t)arg2)))) &&
            ((((uint64_t)arg3 < uVar6 || (uVar1 < (uint64_t)arg3)) &&
             (((uint64_t)arg2 < uVar6 || (uVar1 < (uint64_t)arg2)))))))) {
            iVar14 = 0;
            iVar18 = iVar16;
            do {
                puVar2 = (uint32_t *)(iVar14 + uVar5);
                uVar15 = *puVar2;
                uVar8 = puVar2[1];
                uVar9 = puVar2[2];
                uVar10 = puVar2[3];
                iVar18 = iVar18 + 2;
                puVar2 = (uint32_t *)(iVar14 + uVar6);
                uVar11 = puVar2[1];
                uVar12 = puVar2[2];
                uVar13 = puVar2[3];
                uVar25 = (uVar15 ^ *puVar2) & uVar19;
                uVar28 = (uint32_t)(uVar20 >> 0x20);
                uVar26 = (uVar8 ^ uVar11) & uVar28;
                uVar27 = (uVar9 ^ uVar12) & uVar19;
                uVar28 = (uVar10 ^ uVar13) & uVar28;
                puVar4 = (uint32_t *)(iVar14 + uVar6);
                *puVar4 = uVar25 ^ *puVar2;
                puVar4[1] = uVar26 ^ uVar11;
                puVar4[2] = uVar27 ^ uVar12;
                puVar4[3] = uVar28 ^ uVar13;
                puVar2 = (uint32_t *)(iVar14 + uVar5);
                *puVar2 = uVar25 ^ uVar15;
                puVar2[1] = uVar26 ^ uVar8;
                puVar2[2] = uVar27 ^ uVar9;
                puVar2[3] = uVar28 ^ uVar10;
                iVar14 = iVar14 + 0x10;
            } while (iVar18 < (int32_t)(uVar23 & 0xfffffffe));
        }
    }
    iVar14 = (int64_t)iVar18;
    if (iVar14 < iVar21) {
        iVar24 = iVar14 * 8;
        do {
            iVar7 = *(int64_t *)arg2;
            iVar24 = iVar24 + 8;
            uVar22 = (*(uint64_t *)(iVar7 + -8 + iVar24) ^ *(uint64_t *)(*(int64_t *)arg3 + iVar14 * 8)) & uVar20;
            *(uint64_t *)(iVar7 + iVar14 * 8) = uVar22 ^ *(uint64_t *)(iVar7 + -8 + iVar24);
            puVar3 = (uint64_t *)(*(int64_t *)arg3 + iVar14 * 8);
            *puVar3 = *puVar3 ^ uVar22;
            iVar14 = iVar14 + 1;
        } while (iVar14 < iVar21);
    }
    return;
}

// ============================================================
// Function: FUN_180255110
// Address: 0x180255110
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.180255110(int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    int32_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 *in_RCX;
    undefined8 *in_RDX;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180255125;
    iVar4 = fcn.18045a350();
    iVar1 = *(int32_t *)(((uint64_t)(*(uint32_t *)((int64_t)in_RDX + 0x14) & 4) | 8) + (int64_t)in_RDX);
    if (in_RCX != in_RDX) {
        puVar5 = in_RCX;
        if (*(int32_t *)((int64_t)in_RCX + 0xc) < iVar1) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x180255152;
            puVar5 = (undefined8 *)func_0x000180256190();
        }
        if (puVar5 == (undefined8 *)0x0) {
            return (undefined8 *)0x0;
        }
        if (0 < *(int32_t *)(in_RDX + 1)) {
            uVar2 = *in_RDX;
            uVar3 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18025517f;
            func_0x000180498030(uVar3, uVar2, (int64_t)iVar1 << 3);
        }
        *(undefined4 *)(in_RCX + 2) = *(undefined4 *)(in_RDX + 2);
        *(undefined4 *)(in_RCX + 1) = *(undefined4 *)(in_RDX + 1);
    }
    return in_RCX;
}

