// Chunk 47 - 50 functions

// ============================================================
// Function: FUN_180096f14
// Address: 0x180096f14
// Size: 20 bytes
// ============================================================
void fcn.180096f14(void)
{
    code *pcVar1;
    
    fcn.180088470();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180096f30
// Address: 0x180096f30
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096f30(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18048d7c0();
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096f80
// Address: 0x180096f80
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096f80(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.1804905c0();
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180096fd0
// Address: 0x180096fd0
// Size: 78 bytes
// ============================================================
undefined8 fcn.180096fd0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    int64_t var_10h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        fcn.180086570(arg1, SUB84(dVar3 / 0.0174532925199433, 0));
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097020
// Address: 0x180097020
// Size: 78 bytes
// ============================================================
undefined8 fcn.180097020(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    int64_t var_10h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        fcn.180086570(arg1, SUB84(dVar3 * 0.0174532925199433, 0));
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097070
// Address: 0x180097070
// Size: 95 bytes
// ============================================================
undefined8 fcn.180097070(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.180467d50(uVar3, &var_18h);
        fcn.180086570(arg1, uVar3);
        fcn.1800865e0(arg1, (undefined4)var_18h);
        return 2;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_1800970d0
// Address: 0x1800970d0
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800970d0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t unaff_RBX;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    fcn.180088860(arg1, 2);
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18046d9a0(unaff_RBX);
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097140
// Address: 0x180097140
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180097140(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined8 uVar8;
    undefined4 uVar10;
    double dVar9;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    uVar8 = fcn.180085ea0(arg1, 1, &var_8h);
    uVar7 = (undefined4)uVar8;
    uVar10 = (undefined4)((uint64_t)uVar8 >> 0x20);
    if ((int32_t)var_8h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar4 = (code *)swi(3);
        uVar8 = (*pcVar4)();
        return uVar8;
    }
    iVar6 = 2;
    iVar5 = (int32_t)(iVar1 - iVar2 >> 4);
    if (1 < iVar5) {
        do {
            dVar9 = (double)fcn.180085ea0(arg1, iVar6, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, iVar6, 3);
                pcVar4 = (code *)swi(3);
                uVar8 = (*pcVar4)();
                return uVar8;
            }
            if ((double)CONCAT44(uVar10, uVar7) <= dVar9) {
                dVar9 = (double)CONCAT44(uVar10, uVar7);
            }
            iVar6 = iVar6 + 1;
            uVar7 = SUB84(dVar9, 0);
            uVar10 = (undefined4)((uint64_t)dVar9 >> 0x20);
        } while (iVar6 <= iVar5);
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(unaff_retaddr);
        if (iVar5 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
    }
    puVar3 = *(undefined8 **)(arg1 + 0x40);
    *puVar3 = CONCAT44(uVar10, uVar7);
    *(undefined4 *)((int64_t)puVar3 + 0xc) = 3;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180097250
// Address: 0x180097250
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180097250(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined8 uVar8;
    undefined4 uVar10;
    double dVar9;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    uVar8 = fcn.180085ea0(arg1, 1, &var_8h);
    uVar7 = (undefined4)uVar8;
    uVar10 = (undefined4)((uint64_t)uVar8 >> 0x20);
    if ((int32_t)var_8h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar4 = (code *)swi(3);
        uVar8 = (*pcVar4)();
        return uVar8;
    }
    iVar6 = 2;
    iVar5 = (int32_t)(iVar1 - iVar2 >> 4);
    if (1 < iVar5) {
        do {
            dVar9 = (double)fcn.180085ea0(arg1, iVar6, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, iVar6, 3);
                pcVar4 = (code *)swi(3);
                uVar8 = (*pcVar4)();
                return uVar8;
            }
            if (dVar9 <= (double)CONCAT44(uVar10, uVar7)) {
                dVar9 = (double)CONCAT44(uVar10, uVar7);
            }
            iVar6 = iVar6 + 1;
            uVar7 = SUB84(dVar9, 0);
            uVar10 = (undefined4)((uint64_t)dVar9 >> 0x20);
        } while (iVar6 <= iVar5);
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(unaff_retaddr);
        if (iVar5 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
    }
    puVar3 = *(undefined8 **)(arg1 + 0x40);
    *puVar3 = CONCAT44(uVar10, uVar7);
    *(undefined4 *)((int64_t)puVar3 + 0xc) = 3;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180097360
// Address: 0x180097360
// Size: 634 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180097360(int64_t arg1)
{
    int64_t iVar1;
    uint64_t uVar2;
    code *pcVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t unaff_RBX;
    uint32_t uVar8;
    undefined4 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg1 + 0x20);
    iVar5 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (iVar5 == 0) {
        *(int64_t *)(iVar1 + 0x500) =
             (*(int64_t *)(iVar1 + 0x500) * 0x5851f42d4c957f2d + 0x69) * 0x5851f42d4c957f2d + 0x69;
        uVar9 = fcn.18046d9a0(unaff_RBX);
        fcn.180086570(arg1, uVar9);
    } else if (iVar5 == 1) {
        iVar5 = fcn.180088860(arg1, 1);
        if (iVar5 < 1) {
            func_0x000180088380(arg1, 1, 0x18063e298);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        uVar2 = *(uint64_t *)(iVar1 + 0x500);
        *(uint64_t *)(iVar1 + 0x500) = uVar2 * 0x5851f42d4c957f2d + 0x69;
        uVar4 = (uint8_t)(uVar2 >> 0x38);
        uVar8 = (uint32_t)(uVar2 >> 0x2d) ^ (uint32_t)(uVar2 >> 0x1b);
        fcn.1800865e0(arg1, (int32_t)((int64_t)iVar5 *
                                      (uint64_t)(uVar8 << (-(uVar4 >> 3) & 0x1f) | uVar8 >> (uVar4 >> 3)) >> 0x20) + 1);
    } else {
        if (iVar5 != 2) {
            fcn.180088560(arg1, 0x18063e2d8);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        iVar5 = fcn.180088860(arg1, 1);
        iVar6 = fcn.180088860(arg1, 2);
        if (iVar6 < iVar5) {
            func_0x000180088380(arg1, 2, 0x18063e298);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        if (iVar6 - iVar5 == -1) {
            func_0x000180088380(arg1, 2, 0x18063e2f8);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
        uVar2 = *(uint64_t *)(iVar1 + 0x500);
        *(uint64_t *)(iVar1 + 0x500) = uVar2 * 0x5851f42d4c957f2d + 0x69;
        uVar4 = (uint8_t)(uVar2 >> 0x38);
        uVar8 = (uint32_t)(uVar2 >> 0x2d) ^ (uint32_t)(uVar2 >> 0x1b);
        fcn.1800865e0(arg1, (int32_t)((uint64_t)((iVar6 - iVar5) + 1) *
                                      (uint64_t)(uVar8 << (-(uVar4 >> 3) & 0x1f) | uVar8 >> (uVar4 >> 3)) >> 0x20) +
                            iVar5);
    }
    return 1;
}

// ============================================================
// Function: FUN_1800975e0
// Address: 0x1800975e0
// Size: 68 bytes
// ============================================================
undefined8 fcn.1800975e0(int64_t arg1)
{
    int32_t iVar1;
    
    iVar1 = fcn.180088860(arg1, 1);
    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x500) = (int64_t)iVar1 * 0x5851f42d4c957f2d + 0x399d2694695129de;
    return 0;
}

// ============================================================
// Function: FUN_180097630
// Address: 0x180097630
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180097630(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    double dVar15;
    double dVar16;
    double dVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    dVar15 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    dVar16 = (double)fcn.180085ea0(arg1, 2, &var_18h);
    dVar17 = (double)fcn.180085ea0(arg1, 3, &var_20h);
    if ((float)var_10h == 0.0) {
        fcn.1800883d0(arg1, 1, 0x18063e2d0);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    if ((int32_t)var_18h == 0) {
        uVar2 = *(int64_t *)(arg1 + 0x28) + 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar2 + 0xc))) {
            fcn.1800883d0(arg1, 2, 0x18063e2d0);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
    }
    if ((int32_t)var_20h == 0) {
        uVar2 = *(int64_t *)(arg1 + 0x28) + 0x20;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar2 + 0xc))) {
            fcn.1800883d0(arg1, 3, 0x18063e2d0);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
    }
    if (*(char *)0x1807778d0 != '\0') {
        dVar15 = (double)fcn.180490b30(SUB84(dVar15, 0), 0x4070000000000000);
        dVar16 = (double)fcn.180490b30(SUB84(dVar16, 0), 0x4070000000000000);
        dVar17 = (double)fcn.180490b30(SUB84(dVar17, 0), 0x4070000000000000);
    }
    fVar12 = (float)fcn.180490aa0((float)dVar15);
    fVar13 = (float)fcn.180490aa0((float)dVar16);
    var_10h._0_4_ = (float)dVar17;
    fVar14 = (float)fcn.180490aa0();
    fVar22 = (float)dVar15 - fVar12;
    var_10h._0_4_ = (float)var_10h - fVar14;
    iVar8 = (int32_t)fVar14;
    fVar14 = (float)dVar16 - fVar13;
    fVar21 = fVar22 - 1.0;
    uVar6 = (uint64_t)
            ((uint32_t)*(uint8_t *)((uint64_t)((int32_t)fVar12 & 0xff) + 0x180612400) + (int32_t)fVar13 & 0xff);
    uVar5 = (uint64_t)
            ((uint32_t)*(uint8_t *)((uint64_t)((int32_t)fVar12 & 0xff) + 0x180612401) + (int32_t)fVar13 & 0xff);
    fVar24 = ((fVar22 * 6.0 - 15.0) * fVar22 + 10.0) * fVar22 * fVar22 * fVar22;
    uVar4 = (uint64_t)((uint32_t)*(uint8_t *)(uVar5 + 0x180612400) + iVar8 & 0xff);
    uVar2 = (uint64_t)(*(uint8_t *)(uVar4 + 0x180612400) & 0xf);
    fVar23 = ((fVar14 * 6.0 - 15.0) * fVar14 + 10.0) * fVar14 * fVar14 * fVar14;
    uVar11 = (uint64_t)((uint32_t)*(uint8_t *)(uVar6 + 0x180612400) + iVar8 & 0xff);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar11 + 0x180612400) & 0xf);
    fVar12 = fVar14 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             (float)var_10h * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar12 = ((fVar14 * *(float *)(uVar2 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar2 * 0xc + 0x180612340) +
              (float)var_10h * *(float *)(uVar2 * 0xc + 0x180612348)) - fVar12) * fVar24 + fVar12;
    fVar20 = fVar14 - 1.0;
    uVar10 = (uint64_t)((uint32_t)*(uint8_t *)(uVar5 + 0x180612401) + iVar8 & 0xff);
    fVar18 = (float)var_10h - 1.0;
    uVar2 = (uint64_t)(*(uint8_t *)(uVar10 + 0x180612400) & 0xf);
    uVar9 = (uint64_t)((uint32_t)*(uint8_t *)(uVar6 + 0x180612401) + iVar8 & 0xff);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar9 + 0x180612400) & 0xf);
    uVar4 = (uint64_t)(*(uint8_t *)(uVar4 + 0x180612401) & 0xf);
    uVar5 = (uint64_t)(*(uint8_t *)(uVar11 + 0x180612401) & 0xf);
    uVar6 = (uint64_t)(*(uint8_t *)(uVar10 + 0x180612401) & 0xf);
    fVar19 = fVar20 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             (float)var_10h * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar13 = fVar14 * *(float *)(uVar5 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar5 * 0xc + 0x180612340) +
             fVar18 * *(float *)(uVar5 * 0xc + 0x180612348);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar9 + 0x180612401) & 0xf);
    fVar13 = ((fVar14 * *(float *)(uVar4 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar4 * 0xc + 0x180612340) +
              fVar18 * *(float *)(uVar4 * 0xc + 0x180612348)) - fVar13) * fVar24 + fVar13;
    fVar14 = fVar20 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             fVar18 * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar12 = ((((fVar20 * *(float *)(uVar2 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar2 * 0xc + 0x180612340) +
                (float)var_10h * *(float *)(uVar2 * 0xc + 0x180612348)) - fVar19) * fVar24 + fVar19) - fVar12) * fVar23
             + fVar12;
    fcn.180086570(arg1, (double)(((((((fVar20 * *(float *)(uVar6 * 0xc + 0x180612344) +
                                       fVar21 * *(float *)(uVar6 * 0xc + 0x180612340) +
                                      fVar18 * *(float *)(uVar6 * 0xc + 0x180612348)) - fVar14) * fVar24 + fVar14) -
                                   fVar13) * fVar23 + fVar13) - fVar12) *
                                 (((float)var_10h * 6.0 - 15.0) * (float)var_10h + 10.0) *
                                 (float)var_10h * (float)var_10h * (float)var_10h + fVar12));
    return 1;
}

// ============================================================
// Function: FUN_1800976fd
// Address: 0x1800976fd
// Size: 1218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180097630(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    double dVar15;
    double dVar16;
    double dVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    dVar15 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    dVar16 = (double)fcn.180085ea0(arg1, 2, &var_18h);
    dVar17 = (double)fcn.180085ea0(arg1, 3, &var_20h);
    if ((float)var_10h == 0.0) {
        fcn.1800883d0(arg1, 1, 0x18063e2d0);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    if ((int32_t)var_18h == 0) {
        uVar2 = *(int64_t *)(arg1 + 0x28) + 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar2 + 0xc))) {
            fcn.1800883d0(arg1, 2, 0x18063e2d0);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
    }
    if ((int32_t)var_20h == 0) {
        uVar2 = *(int64_t *)(arg1 + 0x28) + 0x20;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar2 + 0xc))) {
            fcn.1800883d0(arg1, 3, 0x18063e2d0);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
    }
    if (*(char *)0x1807778d0 != '\0') {
        dVar15 = (double)fcn.180490b30(SUB84(dVar15, 0), 0x4070000000000000);
        dVar16 = (double)fcn.180490b30(SUB84(dVar16, 0), 0x4070000000000000);
        dVar17 = (double)fcn.180490b30(SUB84(dVar17, 0), 0x4070000000000000);
    }
    fVar12 = (float)fcn.180490aa0((float)dVar15);
    fVar13 = (float)fcn.180490aa0((float)dVar16);
    var_10h._0_4_ = (float)dVar17;
    fVar14 = (float)fcn.180490aa0();
    fVar22 = (float)dVar15 - fVar12;
    var_10h._0_4_ = (float)var_10h - fVar14;
    iVar8 = (int32_t)fVar14;
    fVar14 = (float)dVar16 - fVar13;
    fVar21 = fVar22 - 1.0;
    uVar6 = (uint64_t)
            ((uint32_t)*(uint8_t *)((uint64_t)((int32_t)fVar12 & 0xff) + 0x180612400) + (int32_t)fVar13 & 0xff);
    uVar5 = (uint64_t)
            ((uint32_t)*(uint8_t *)((uint64_t)((int32_t)fVar12 & 0xff) + 0x180612401) + (int32_t)fVar13 & 0xff);
    fVar24 = ((fVar22 * 6.0 - 15.0) * fVar22 + 10.0) * fVar22 * fVar22 * fVar22;
    uVar4 = (uint64_t)((uint32_t)*(uint8_t *)(uVar5 + 0x180612400) + iVar8 & 0xff);
    uVar2 = (uint64_t)(*(uint8_t *)(uVar4 + 0x180612400) & 0xf);
    fVar23 = ((fVar14 * 6.0 - 15.0) * fVar14 + 10.0) * fVar14 * fVar14 * fVar14;
    uVar11 = (uint64_t)((uint32_t)*(uint8_t *)(uVar6 + 0x180612400) + iVar8 & 0xff);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar11 + 0x180612400) & 0xf);
    fVar12 = fVar14 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             (float)var_10h * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar12 = ((fVar14 * *(float *)(uVar2 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar2 * 0xc + 0x180612340) +
              (float)var_10h * *(float *)(uVar2 * 0xc + 0x180612348)) - fVar12) * fVar24 + fVar12;
    fVar20 = fVar14 - 1.0;
    uVar10 = (uint64_t)((uint32_t)*(uint8_t *)(uVar5 + 0x180612401) + iVar8 & 0xff);
    fVar18 = (float)var_10h - 1.0;
    uVar2 = (uint64_t)(*(uint8_t *)(uVar10 + 0x180612400) & 0xf);
    uVar9 = (uint64_t)((uint32_t)*(uint8_t *)(uVar6 + 0x180612401) + iVar8 & 0xff);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar9 + 0x180612400) & 0xf);
    uVar4 = (uint64_t)(*(uint8_t *)(uVar4 + 0x180612401) & 0xf);
    uVar5 = (uint64_t)(*(uint8_t *)(uVar11 + 0x180612401) & 0xf);
    uVar6 = (uint64_t)(*(uint8_t *)(uVar10 + 0x180612401) & 0xf);
    fVar19 = fVar20 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             (float)var_10h * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar13 = fVar14 * *(float *)(uVar5 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar5 * 0xc + 0x180612340) +
             fVar18 * *(float *)(uVar5 * 0xc + 0x180612348);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar9 + 0x180612401) & 0xf);
    fVar13 = ((fVar14 * *(float *)(uVar4 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar4 * 0xc + 0x180612340) +
              fVar18 * *(float *)(uVar4 * 0xc + 0x180612348)) - fVar13) * fVar24 + fVar13;
    fVar14 = fVar20 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             fVar18 * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar12 = ((((fVar20 * *(float *)(uVar2 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar2 * 0xc + 0x180612340) +
                (float)var_10h * *(float *)(uVar2 * 0xc + 0x180612348)) - fVar19) * fVar24 + fVar19) - fVar12) * fVar23
             + fVar12;
    fcn.180086570(arg1, (double)(((((((fVar20 * *(float *)(uVar6 * 0xc + 0x180612344) +
                                       fVar21 * *(float *)(uVar6 * 0xc + 0x180612340) +
                                      fVar18 * *(float *)(uVar6 * 0xc + 0x180612348)) - fVar14) * fVar24 + fVar14) -
                                   fVar13) * fVar23 + fVar13) - fVar12) *
                                 (((float)var_10h * 6.0 - 15.0) * (float)var_10h + 10.0) *
                                 (float)var_10h * (float)var_10h * (float)var_10h + fVar12));
    return 1;
}

// ============================================================
// Function: FUN_180097bbf
// Address: 0x180097bbf
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180097630(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    double dVar15;
    double dVar16;
    double dVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    dVar15 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    dVar16 = (double)fcn.180085ea0(arg1, 2, &var_18h);
    dVar17 = (double)fcn.180085ea0(arg1, 3, &var_20h);
    if ((float)var_10h == 0.0) {
        fcn.1800883d0(arg1, 1, 0x18063e2d0);
        pcVar1 = (code *)swi(3);
        uVar7 = (*pcVar1)();
        return uVar7;
    }
    if ((int32_t)var_18h == 0) {
        uVar2 = *(int64_t *)(arg1 + 0x28) + 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar2 + 0xc))) {
            fcn.1800883d0(arg1, 2, 0x18063e2d0);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
    }
    if ((int32_t)var_20h == 0) {
        uVar2 = *(int64_t *)(arg1 + 0x28) + 0x20;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar2) {
            uVar2 = *(uint64_t *)0x180782430;
        }
        if ((uVar2 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar2 + 0xc))) {
            fcn.1800883d0(arg1, 3, 0x18063e2d0);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
    }
    if (*(char *)0x1807778d0 != '\0') {
        dVar15 = (double)fcn.180490b30(SUB84(dVar15, 0), 0x4070000000000000);
        dVar16 = (double)fcn.180490b30(SUB84(dVar16, 0), 0x4070000000000000);
        dVar17 = (double)fcn.180490b30(SUB84(dVar17, 0), 0x4070000000000000);
    }
    fVar12 = (float)fcn.180490aa0((float)dVar15);
    fVar13 = (float)fcn.180490aa0((float)dVar16);
    var_10h._0_4_ = (float)dVar17;
    fVar14 = (float)fcn.180490aa0();
    fVar22 = (float)dVar15 - fVar12;
    var_10h._0_4_ = (float)var_10h - fVar14;
    iVar8 = (int32_t)fVar14;
    fVar14 = (float)dVar16 - fVar13;
    fVar21 = fVar22 - 1.0;
    uVar6 = (uint64_t)
            ((uint32_t)*(uint8_t *)((uint64_t)((int32_t)fVar12 & 0xff) + 0x180612400) + (int32_t)fVar13 & 0xff);
    uVar5 = (uint64_t)
            ((uint32_t)*(uint8_t *)((uint64_t)((int32_t)fVar12 & 0xff) + 0x180612401) + (int32_t)fVar13 & 0xff);
    fVar24 = ((fVar22 * 6.0 - 15.0) * fVar22 + 10.0) * fVar22 * fVar22 * fVar22;
    uVar4 = (uint64_t)((uint32_t)*(uint8_t *)(uVar5 + 0x180612400) + iVar8 & 0xff);
    uVar2 = (uint64_t)(*(uint8_t *)(uVar4 + 0x180612400) & 0xf);
    fVar23 = ((fVar14 * 6.0 - 15.0) * fVar14 + 10.0) * fVar14 * fVar14 * fVar14;
    uVar11 = (uint64_t)((uint32_t)*(uint8_t *)(uVar6 + 0x180612400) + iVar8 & 0xff);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar11 + 0x180612400) & 0xf);
    fVar12 = fVar14 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             (float)var_10h * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar12 = ((fVar14 * *(float *)(uVar2 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar2 * 0xc + 0x180612340) +
              (float)var_10h * *(float *)(uVar2 * 0xc + 0x180612348)) - fVar12) * fVar24 + fVar12;
    fVar20 = fVar14 - 1.0;
    uVar10 = (uint64_t)((uint32_t)*(uint8_t *)(uVar5 + 0x180612401) + iVar8 & 0xff);
    fVar18 = (float)var_10h - 1.0;
    uVar2 = (uint64_t)(*(uint8_t *)(uVar10 + 0x180612400) & 0xf);
    uVar9 = (uint64_t)((uint32_t)*(uint8_t *)(uVar6 + 0x180612401) + iVar8 & 0xff);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar9 + 0x180612400) & 0xf);
    uVar4 = (uint64_t)(*(uint8_t *)(uVar4 + 0x180612401) & 0xf);
    uVar5 = (uint64_t)(*(uint8_t *)(uVar11 + 0x180612401) & 0xf);
    uVar6 = (uint64_t)(*(uint8_t *)(uVar10 + 0x180612401) & 0xf);
    fVar19 = fVar20 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             (float)var_10h * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar13 = fVar14 * *(float *)(uVar5 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar5 * 0xc + 0x180612340) +
             fVar18 * *(float *)(uVar5 * 0xc + 0x180612348);
    uVar3 = (uint64_t)(*(uint8_t *)(uVar9 + 0x180612401) & 0xf);
    fVar13 = ((fVar14 * *(float *)(uVar4 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar4 * 0xc + 0x180612340) +
              fVar18 * *(float *)(uVar4 * 0xc + 0x180612348)) - fVar13) * fVar24 + fVar13;
    fVar14 = fVar20 * *(float *)(uVar3 * 0xc + 0x180612344) + fVar22 * *(float *)(uVar3 * 0xc + 0x180612340) +
             fVar18 * *(float *)(uVar3 * 0xc + 0x180612348);
    fVar12 = ((((fVar20 * *(float *)(uVar2 * 0xc + 0x180612344) + fVar21 * *(float *)(uVar2 * 0xc + 0x180612340) +
                (float)var_10h * *(float *)(uVar2 * 0xc + 0x180612348)) - fVar19) * fVar24 + fVar19) - fVar12) * fVar23
             + fVar12;
    fcn.180086570(arg1, (double)(((((((fVar20 * *(float *)(uVar6 * 0xc + 0x180612344) +
                                       fVar21 * *(float *)(uVar6 * 0xc + 0x180612340) +
                                      fVar18 * *(float *)(uVar6 * 0xc + 0x180612348)) - fVar14) * fVar24 + fVar14) -
                                   fVar13) * fVar23 + fVar13) - fVar12) *
                                 (((float)var_10h * 6.0 - 15.0) * (float)var_10h + 10.0) *
                                 (float)var_10h * (float)var_10h * (float)var_10h + fVar12));
    return 1;
}

// ============================================================
// Function: FUN_180097c00
// Address: 0x180097c00
// Size: 47 bytes
// ============================================================
undefined8 fcn.180097c00(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar4 <= dVar5) {
        uVar6 = SUB84(dVar4, 0);
        uVar7 = (int32_t)((uint64_t)dVar4 >> 0x20);
        if (dVar4 <= dVar3) {
            uVar6 = SUB84(dVar3, 0);
            uVar7 = (int32_t)((uint64_t)dVar3 >> 0x20);
        }
        if ((double)CONCAT44(uVar7, uVar6) <= dVar5) {
            dVar5 = (double)CONCAT44(uVar7, uVar6);
        }
        fcn.180086570(arg1, SUB84(dVar5, 0));
        return 1;
    }
    fcn.180088380(arg1, 3, 0x18063e200);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097c2f
// Address: 0x180097c2f
// Size: 96 bytes
// ============================================================
undefined8 fcn.180097c00(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar4 <= dVar5) {
        uVar6 = SUB84(dVar4, 0);
        uVar7 = (int32_t)((uint64_t)dVar4 >> 0x20);
        if (dVar4 <= dVar3) {
            uVar6 = SUB84(dVar3, 0);
            uVar7 = (int32_t)((uint64_t)dVar3 >> 0x20);
        }
        if ((double)CONCAT44(uVar7, uVar6) <= dVar5) {
            dVar5 = (double)CONCAT44(uVar7, uVar6);
        }
        fcn.180086570(arg1, SUB84(dVar5, 0));
        return 1;
    }
    fcn.180088380(arg1, 3, 0x18063e200);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097c8f
// Address: 0x180097c8f
// Size: 18 bytes
// ============================================================
undefined8 fcn.180097c00(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar4 <= dVar5) {
        uVar6 = SUB84(dVar4, 0);
        uVar7 = (int32_t)((uint64_t)dVar4 >> 0x20);
        if (dVar4 <= dVar3) {
            uVar6 = SUB84(dVar3, 0);
            uVar7 = (int32_t)((uint64_t)dVar3 >> 0x20);
        }
        if ((double)CONCAT44(uVar7, uVar6) <= dVar5) {
            dVar5 = (double)CONCAT44(uVar7, uVar6);
        }
        fcn.180086570(arg1, SUB84(dVar5, 0));
        return 1;
    }
    fcn.180088380(arg1, 3, 0x18063e200);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097ca1
// Address: 0x180097ca1
// Size: 17 bytes
// ============================================================
undefined8 fcn.180097c00(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar4 <= dVar5) {
        uVar6 = SUB84(dVar4, 0);
        uVar7 = (int32_t)((uint64_t)dVar4 >> 0x20);
        if (dVar4 <= dVar3) {
            uVar6 = SUB84(dVar3, 0);
            uVar7 = (int32_t)((uint64_t)dVar3 >> 0x20);
        }
        if ((double)CONCAT44(uVar7, uVar6) <= dVar5) {
            dVar5 = (double)CONCAT44(uVar7, uVar6);
        }
        fcn.180086570(arg1, SUB84(dVar5, 0));
        return 1;
    }
    fcn.180088380(arg1, 3, 0x18063e200);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097cb2
// Address: 0x180097cb2
// Size: 31 bytes
// ============================================================
undefined8 fcn.180097c00(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar4 <= dVar5) {
        uVar6 = SUB84(dVar4, 0);
        uVar7 = (int32_t)((uint64_t)dVar4 >> 0x20);
        if (dVar4 <= dVar3) {
            uVar6 = SUB84(dVar3, 0);
            uVar7 = (int32_t)((uint64_t)dVar3 >> 0x20);
        }
        if ((double)CONCAT44(uVar7, uVar6) <= dVar5) {
            dVar5 = (double)CONCAT44(uVar7, uVar6);
        }
        fcn.180086570(arg1, SUB84(dVar5, 0));
        return 1;
    }
    fcn.180088380(arg1, 3, 0x18063e200);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097ce0
// Address: 0x180097ce0
// Size: 120 bytes
// ============================================================
undefined8 fcn.180097ce0(int64_t arg1)
{
    code *pcVar1;
    double dVar2;
    undefined8 uVar3;
    int64_t var_10h;
    
    dVar2 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    uVar3 = 0;
    if (0.0 < dVar2) {
        fcn.180086570(arg1, 0x3ff0000000000000);
        return 1;
    }
    if (dVar2 < 0.0) {
        uVar3 = 0xbff0000000000000;
    }
    fcn.180086570(arg1, uVar3);
    return 1;
}

// ============================================================
// Function: FUN_180097d60
// Address: 0x180097d60
// Size: 78 bytes
// ============================================================
undefined8 fcn.180097d60(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        uVar3 = fcn.18046e0b0();
        fcn.180086570(arg1, uVar3);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097db0
// Address: 0x180097db0
// Size: 51 bytes
// ============================================================
undefined8 fcn.180097db0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar6 = (double)fcn.180085ea0(arg1, 4, &var_10h);
    if ((int32_t)var_10h != 0) {
        dVar7 = (double)fcn.180085ea0(arg1, 5, &var_10h);
        if ((int32_t)var_10h != 0) {
            fcn.180086570(arg1, SUB84(((dVar3 - dVar4) * (dVar7 - dVar6)) / (dVar5 - dVar4) + dVar6, 0));
            return 1;
        }
        fcn.180088470(arg1, 5, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    fcn.180088470(arg1, 4, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097de3
// Address: 0x180097de3
// Size: 208 bytes
// ============================================================
undefined8 fcn.180097db0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar6 = (double)fcn.180085ea0(arg1, 4, &var_10h);
    if ((int32_t)var_10h != 0) {
        dVar7 = (double)fcn.180085ea0(arg1, 5, &var_10h);
        if ((int32_t)var_10h != 0) {
            fcn.180086570(arg1, SUB84(((dVar3 - dVar4) * (dVar7 - dVar6)) / (dVar5 - dVar4) + dVar6, 0));
            return 1;
        }
        fcn.180088470(arg1, 5, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    fcn.180088470(arg1, 4, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097eb3
// Address: 0x180097eb3
// Size: 17 bytes
// ============================================================
undefined8 fcn.180097db0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar6 = (double)fcn.180085ea0(arg1, 4, &var_10h);
    if ((int32_t)var_10h != 0) {
        dVar7 = (double)fcn.180085ea0(arg1, 5, &var_10h);
        if ((int32_t)var_10h != 0) {
            fcn.180086570(arg1, SUB84(((dVar3 - dVar4) * (dVar7 - dVar6)) / (dVar5 - dVar4) + dVar6, 0));
            return 1;
        }
        fcn.180088470(arg1, 5, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    fcn.180088470(arg1, 4, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097ec4
// Address: 0x180097ec4
// Size: 17 bytes
// ============================================================
undefined8 fcn.180097db0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar6 = (double)fcn.180085ea0(arg1, 4, &var_10h);
    if ((int32_t)var_10h != 0) {
        dVar7 = (double)fcn.180085ea0(arg1, 5, &var_10h);
        if ((int32_t)var_10h != 0) {
            fcn.180086570(arg1, SUB84(((dVar3 - dVar4) * (dVar7 - dVar6)) / (dVar5 - dVar4) + dVar6, 0));
            return 1;
        }
        fcn.180088470(arg1, 5, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    fcn.180088470(arg1, 4, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097ed5
// Address: 0x180097ed5
// Size: 14 bytes
// ============================================================
undefined8 fcn.180097db0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar6 = (double)fcn.180085ea0(arg1, 4, &var_10h);
    if ((int32_t)var_10h != 0) {
        dVar7 = (double)fcn.180085ea0(arg1, 5, &var_10h);
        if ((int32_t)var_10h != 0) {
            fcn.180086570(arg1, SUB84(((dVar3 - dVar4) * (dVar7 - dVar6)) / (dVar5 - dVar4) + dVar6, 0));
            return 1;
        }
        fcn.180088470(arg1, 5, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    fcn.180088470(arg1, 4, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097ee3
// Address: 0x180097ee3
// Size: 34 bytes
// ============================================================
undefined8 fcn.180097db0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar6 = (double)fcn.180085ea0(arg1, 4, &var_10h);
    if ((int32_t)var_10h != 0) {
        dVar7 = (double)fcn.180085ea0(arg1, 5, &var_10h);
        if ((int32_t)var_10h != 0) {
            fcn.180086570(arg1, SUB84(((dVar3 - dVar4) * (dVar7 - dVar6)) / (dVar5 - dVar4) + dVar6, 0));
            return 1;
        }
        fcn.180088470(arg1, 5, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    fcn.180088470(arg1, 4, 3);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180097f10
// Address: 0x180097f10
// Size: 47 bytes
// ============================================================
undefined8 fcn.180097f10(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    uVar6 = SUB84(dVar4, 0);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar5 != 1.0) {
        uVar6 = SUB84((dVar4 - dVar3) * dVar5 + dVar3, 0);
    }
    fcn.180086570(arg1, uVar6);
    return 1;
}

// ============================================================
// Function: FUN_180097f3f
// Address: 0x180097f3f
// Size: 106 bytes
// ============================================================
undefined8 fcn.180097f10(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    uVar6 = SUB84(dVar4, 0);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar5 != 1.0) {
        uVar6 = SUB84((dVar4 - dVar3) * dVar5 + dVar3, 0);
    }
    fcn.180086570(arg1, uVar6);
    return 1;
}

// ============================================================
// Function: FUN_180097fa9
// Address: 0x180097fa9
// Size: 17 bytes
// ============================================================
undefined8 fcn.180097f10(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    uVar6 = SUB84(dVar4, 0);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar5 != 1.0) {
        uVar6 = SUB84((dVar4 - dVar3) * dVar5 + dVar3, 0);
    }
    fcn.180086570(arg1, uVar6);
    return 1;
}

// ============================================================
// Function: FUN_180097fba
// Address: 0x180097fba
// Size: 34 bytes
// ============================================================
undefined8 fcn.180097f10(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    undefined4 uVar6;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar4 = (double)fcn.180085ea0(arg1, 2, &var_10h);
    uVar6 = SUB84(dVar4, 0);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 2, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    dVar5 = (double)fcn.180085ea0(arg1, 3, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 3, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar5 != 1.0) {
        uVar6 = SUB84((dVar4 - dVar3) * dVar5 + dVar3, 0);
    }
    fcn.180086570(arg1, uVar6);
    return 1;
}

// ============================================================
// Function: FUN_180097fe0
// Address: 0x180097fe0
// Size: 84 bytes
// ============================================================
undefined8 fcn.180097fe0(int64_t arg1)
{
    code *pcVar1;
    int16_t iVar2;
    undefined8 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        iVar2 = fcn.18046ea10();
        fcn.180086b20(arg1, iVar2 == 2);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180098040
// Address: 0x180098040
// Size: 84 bytes
// ============================================================
undefined8 fcn.180098040(int64_t arg1)
{
    code *pcVar1;
    int16_t iVar2;
    undefined8 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        iVar2 = fcn.18046ea10();
        fcn.180086b20(arg1, iVar2 == 1);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800980a0
// Address: 0x1800980a0
// Size: 83 bytes
// ============================================================
undefined8 fcn.1800980a0(int64_t arg1)
{
    code *pcVar1;
    int16_t iVar2;
    undefined8 uVar3;
    int64_t var_10h;
    
    fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h != 0) {
        iVar2 = fcn.18046ea10();
        fcn.180086b20(arg1, iVar2 < 1);
        return 1;
    }
    fcn.180088470(arg1, 1, 3);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180098100
// Address: 0x180098100
// Size: 797 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.180098100(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    undefined4 *puVar11;
    undefined8 *puVar12;
    int32_t iVar13;
    int64_t unaff_RDI;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)(arg1 + 0x20);
    iVar1 = *(int64_t *)(iVar8 + 0x4e8);
    iVar2 = *(int64_t *)(iVar8 + 0x4e0);
    iVar3 = *(int64_t *)(iVar8 + 0x4f8);
    iVar8 = *(int64_t *)(iVar8 + 0x4f0);
    uVar6 = func_0x000180467bd4(0);
    iVar5 = func_0x00018046e174();
    puVar12 = (undefined8 *)0x1806120e0;
    iVar13 = 0;
    *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x500) =
         ((int64_t)iVar5 ^ arg1 * iVar1 + iVar3 ^ arg1 * iVar2 + iVar8 ^ uVar6) * 0x5851f42d4c957f2d +
         0x399d2694695129de;
    piVar7 = (int64_t *)0x1806120e0;
    do {
        iVar13 = iVar13 + 1;
        piVar7 = piVar7 + 2;
    } while (*piVar7 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x180625d34);
    iVar8 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar8 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar8;
        iVar8 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x180625d34, iVar13);
        if (iVar8 != 0) {
            fcn.180088560(arg1, 0x18063da68, 0x180625d34);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar5 = fcn.180085510(unaff_RDI), iVar5 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x180625d34);
    }
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar9 = puVar11 + -4;
    if (puVar9 < puVar11) {
        do {
            puVar9[-4] = *puVar9;
            puVar9[-3] = puVar9[1];
            puVar9[-2] = puVar9[2];
            puVar9[-1] = puVar9[3];
            puVar11 = *(undefined4 **)(arg1 + 0x40);
            puVar9 = puVar9 + 4;
        } while (puVar9 < puVar11);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar11 + -4;
    iVar8 = 0x18063c1c8;
    do {
        func_0x0001800869f0(arg1, puVar12[1], iVar8, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar12);
        iVar8 = puVar12[2];
        puVar12 = puVar12 + 2;
    } while (iVar8 != 0);
    fcn.180086570(arg1, 0x400921fb54442d18);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063c888);
    fcn.180086570(arg1, 0x7ff0000000000000);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063c6c4);
    fcn.180086570(arg1, 0x7ff8000000000000);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063e358);
    fcn.180086570(arg1, 0x4005bf0a8b145769);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063e354);
    fcn.180086570(arg1, 0x3ff9e3779b97f4a8);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063e350);
    fcn.180086570(arg1, 0x3ff6a09e667f3bcd);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063e370);
    fcn.180086570(arg1, 0x401921fb54442d18);
    func_0x000180087370(arg1, 0xfffffffe, 0x18063e36c);
    return 1;
}

// ============================================================
// Function: FUN_180098420
// Address: 0x180098420
// Size: 17 bytes
// ============================================================
void fcn.180098420(undefined8 param_1)
{
    code *pcVar1;
    
    fcn.180093000(param_1, 0x18063e378);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180098440
// Address: 0x180098440
// Size: 209 bytes
// ============================================================
undefined8 * fcn.180098440(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t var_40h;
    
    iVar1 = *(int32_t *)((uint64_t)(uint8_t)placeholder_3 * 4 + 0x1807778f0);
    iVar5 = 0x3fe8;
    if (0x200 < iVar1) {
        iVar5 = 0x7fe8;
    }
    puVar4 = (undefined8 *)
             (**(code **)(*(int64_t *)(arg1 + 0x20) + 0x48))
                       (*(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x50), 0, 0, iVar5);
    if (puVar4 != (undefined8 *)0x0) {
        *(int32_t *)(puVar4 + 4) = (int32_t)iVar5;
        puVar4[2] = 0;
        puVar4[3] = 0;
        iVar1 = iVar1 + (uint32_t)(uint8_t)arg_28h * 8;
        *puVar4 = 0;
        puVar4[1] = 0;
        *(int32_t *)((int64_t)puVar4 + 0x24) = iVar1;
        puVar4[5] = 0;
        *(undefined4 *)((int64_t)puVar4 + 0x34) = 0;
        *(int32_t *)(puVar4 + 6) = ((int32_t)((iVar5 - 0x40U) / (uint64_t)(int64_t)iVar1) + -1) * iVar1;
        if (arg3 != 0) {
            puVar2 = *(undefined8 **)arg3;
            puVar4[1] = puVar2;
            if (puVar2 != (undefined8 *)0x0) {
                *puVar2 = puVar4;
            }
            *(undefined8 **)arg3 = puVar4;
        }
        *(undefined8 **)(arg2 + (uint64_t)(uint8_t)placeholder_3 * 8) = puVar4;
        return puVar4;
    }
    fcn.1800931b0(arg1, 4);
    pcVar3 = (code *)swi(3);
    puVar4 = (undefined8 *)(*pcVar3)();
    return puVar4;
}

// ============================================================
// Function: FUN_180098520
// Address: 0x180098520
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t * fcn.180098520(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x20) + (int64_t)(int32_t)arg2 * 8;
    iVar3 = *(int64_t *)(iVar1 + 0x98);
    if (iVar3 == 0) {
        iVar3 = fcn.180098440(arg1, *(int64_t *)(arg1 + 0x20) + 0x98, 0, arg2 & 0xff, CONCAT71(var_18h._1_7_, 1));
    }
    iVar2 = *(int32_t *)(iVar3 + 0x30);
    if (iVar2 < 0) {
        piVar4 = *(int64_t **)(iVar3 + 0x28);
        *(int64_t *)(iVar3 + 0x28) = *piVar4;
    } else {
        piVar4 = (int64_t *)((int64_t)iVar2 + 0x40 + iVar3);
        *(int32_t *)(iVar3 + 0x30) = iVar2 - *(int32_t *)(iVar3 + 0x24);
    }
    *(int32_t *)(iVar3 + 0x34) = *(int32_t *)(iVar3 + 0x34) + 1;
    *piVar4 = iVar3;
    if ((*(int64_t *)(iVar3 + 0x28) == 0) && (*(int32_t *)(iVar3 + 0x30) < 0)) {
        *(undefined8 *)(iVar1 + 0x98) = *(undefined8 *)(iVar3 + 0x18);
        if (*(int64_t *)(iVar3 + 0x18) != 0) {
            *(undefined8 *)(*(int64_t *)(iVar3 + 0x18) + 0x10) = 0;
        }
        *(undefined8 *)(iVar3 + 0x18) = 0;
    }
    return piVar4 + 1;
}

// ============================================================
// Function: FUN_1800985c0
// Address: 0x1800985c0
// Size: 169 bytes
// ============================================================
void fcn.1800985c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    
    iVar4 = *(int64_t *)(arg1 + 0x20);
    piVar1 = (int64_t *)(arg3 + -8);
    iVar5 = *piVar1;
    if ((*(int64_t *)(iVar5 + 0x28) == 0) && (*(int32_t *)(iVar5 + 0x30) < 0)) {
        iVar3 = iVar4 + (int64_t)(int32_t)arg2 * 8;
        iVar6 = *(int64_t *)(iVar3 + 0x98);
        *(int64_t *)(iVar5 + 0x18) = iVar6;
        if (iVar6 != 0) {
            *(int64_t *)(iVar6 + 0x10) = iVar5;
        }
        *(int64_t *)(iVar3 + 0x98) = iVar5;
    }
    *piVar1 = *(int64_t *)(iVar5 + 0x28);
    piVar2 = (int32_t *)(iVar5 + 0x34);
    *piVar2 = *piVar2 + -1;
    *(int64_t **)(iVar5 + 0x28) = piVar1;
    if (*piVar2 == 0) {
        if (*(int64_t *)(iVar5 + 0x18) != 0) {
            *(undefined8 *)(*(int64_t *)(iVar5 + 0x18) + 0x10) = *(undefined8 *)(iVar5 + 0x10);
        }
        if (*(int64_t *)(iVar5 + 0x10) == 0) {
            iVar4 = iVar4 + (arg2 & 0xffU) * 8;
            if (*(int64_t *)(iVar4 + 0x98) == iVar5) {
                *(undefined8 *)(iVar4 + 0x98) = *(undefined8 *)(iVar5 + 0x18);
            }
        } else {
            *(undefined8 *)(*(int64_t *)(iVar5 + 0x10) + 0x18) = *(undefined8 *)(iVar5 + 0x18);
        }
    // WARNING: Could not recover jumptable at 0x000180098663. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)(arg1 + 0x20) + 0x48))
                  (*(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x50), iVar5, (int64_t)*(int32_t *)(iVar5 + 0x20), 0);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180098670
// Address: 0x180098670
// Size: 149 bytes
// ============================================================
int64_t fcn.180098670(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t in_R8;
    
    iVar4 = *(int64_t *)(arg1 + 0x20);
    if ((arg2 - 1U < 0x400) && (-1 < *(char *)(arg2 + 0x180777990))) {
        iVar3 = fcn.180098520(arg1, (uint64_t)(uint32_t)(int32_t)*(char *)(arg2 + 0x180777990));
    } else {
        iVar3 = (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), 0, 0, arg2);
    }
    if ((iVar3 == 0) && (arg2 != 0)) {
        fcn.1800931b0(arg1, 4);
        pcVar2 = (code *)swi(3);
        iVar4 = (*pcVar2)();
        return iVar4;
    }
    *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + arg2;
    piVar1 = (int64_t *)(iVar4 + 0x2c30 + (in_R8 & 0xff) * 8);
    *piVar1 = *piVar1 + arg2;
    if (*(code **)(iVar4 + 0x510) != (code *)0x0) {
        (**(code **)(iVar4 + 0x510))(arg1, 0, arg2);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180098710
// Address: 0x180098710
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.180098710(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = *(int64_t *)(arg1 + 0x20);
    if ((arg2 - 1U < 0x400) && (cVar3 = *(char *)(arg2 + 0x180777990), -1 < cVar3)) {
        iVar1 = iVar4 + (int64_t)cVar3 * 8;
        iVar7 = *(int64_t *)(iVar1 + 0x1e8);
        if (iVar7 == 0) {
            iVar7 = fcn.180098440(arg1, iVar4 + 0x1e8, iVar4 + 0x1e0, (int64_t)cVar3, (uint64_t)var_28h._1_7_ << 8);
        }
        iVar9 = *(int32_t *)(iVar7 + 0x30);
        if (iVar9 < 0) {
            puVar10 = *(undefined8 **)(iVar7 + 0x28);
            *(undefined8 *)(iVar7 + 0x28) = puVar10[1];
        } else {
            puVar10 = (undefined8 *)((int64_t)iVar9 + 0x40 + iVar7);
            iVar9 = iVar9 - *(int32_t *)(iVar7 + 0x24);
            *(int32_t *)(iVar7 + 0x30) = iVar9;
        }
        *(int32_t *)(iVar7 + 0x34) = *(int32_t *)(iVar7 + 0x34) + 1;
        if ((*(int64_t *)(iVar7 + 0x28) == 0) && (iVar9 < 0)) {
            *(undefined8 *)(iVar1 + 0x1e8) = *(undefined8 *)(iVar7 + 0x18);
            if (*(int64_t *)(iVar7 + 0x18) != 0) {
                *(undefined8 *)(*(int64_t *)(iVar7 + 0x18) + 0x10) = 0;
            }
            *(undefined8 *)(iVar7 + 0x18) = 0;
        }
    } else {
        iVar9 = (int32_t)arg2 + 0x40;
        puVar8 = (undefined8 *)(**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), 0, 0, (int64_t)iVar9);
        if (puVar8 == (undefined8 *)0x0) goto code_r0x000180098885;
        *(int32_t *)(puVar8 + 4) = iVar9;
        puVar10 = (undefined8 *)(iVar4 + 0x1e0);
        puVar8[2] = 0;
        puVar8[3] = 0;
        *puVar8 = 0;
        puVar8[1] = 0;
        *(int32_t *)((int64_t)puVar8 + 0x24) = (int32_t)arg2;
        puVar8[5] = 0;
        puVar8[6] = 0;
        if (puVar10 != (undefined8 *)0x0) {
            puVar5 = (undefined8 *)*puVar10;
            puVar8[1] = puVar5;
            if (puVar5 != (undefined8 *)0x0) {
                *puVar5 = puVar8;
            }
            *puVar10 = puVar8;
        }
        puVar10 = puVar8 + 8;
        *(int32_t *)(puVar8 + 6) = *(int32_t *)(puVar8 + 6) - *(int32_t *)((int64_t)puVar8 + 0x24);
        *(int32_t *)((int64_t)puVar8 + 0x34) = *(int32_t *)((int64_t)puVar8 + 0x34) + 1;
    }
    if ((puVar10 != (undefined8 *)0x0) || (arg2 == 0)) {
        *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + arg2;
        piVar2 = (int64_t *)(iVar4 + 0x2c30 + (in_R8 & 0xff) * 8);
        *piVar2 = *piVar2 + arg2;
        if (*(code **)(iVar4 + 0x510) != (code *)0x0) {
            (**(code **)(iVar4 + 0x510))(arg1, 0, arg2);
        }
        return puVar10;
    }
code_r0x000180098885:
    fcn.1800931b0(arg1, 4);
    pcVar6 = (code *)swi(3);
    puVar8 = (undefined8 *)(*pcVar6)();
    return puVar8;
}

// ============================================================
// Function: FUN_180098755
// Address: 0x180098755
// Size: 134 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.180098710(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = *(int64_t *)(arg1 + 0x20);
    if ((arg2 - 1U < 0x400) && (cVar3 = *(char *)(arg2 + 0x180777990), -1 < cVar3)) {
        iVar1 = iVar4 + (int64_t)cVar3 * 8;
        iVar7 = *(int64_t *)(iVar1 + 0x1e8);
        if (iVar7 == 0) {
            iVar7 = fcn.180098440(arg1, iVar4 + 0x1e8, iVar4 + 0x1e0, (int64_t)cVar3, (uint64_t)var_28h._1_7_ << 8);
        }
        iVar9 = *(int32_t *)(iVar7 + 0x30);
        if (iVar9 < 0) {
            puVar10 = *(undefined8 **)(iVar7 + 0x28);
            *(undefined8 *)(iVar7 + 0x28) = puVar10[1];
        } else {
            puVar10 = (undefined8 *)((int64_t)iVar9 + 0x40 + iVar7);
            iVar9 = iVar9 - *(int32_t *)(iVar7 + 0x24);
            *(int32_t *)(iVar7 + 0x30) = iVar9;
        }
        *(int32_t *)(iVar7 + 0x34) = *(int32_t *)(iVar7 + 0x34) + 1;
        if ((*(int64_t *)(iVar7 + 0x28) == 0) && (iVar9 < 0)) {
            *(undefined8 *)(iVar1 + 0x1e8) = *(undefined8 *)(iVar7 + 0x18);
            if (*(int64_t *)(iVar7 + 0x18) != 0) {
                *(undefined8 *)(*(int64_t *)(iVar7 + 0x18) + 0x10) = 0;
            }
            *(undefined8 *)(iVar7 + 0x18) = 0;
        }
    } else {
        iVar9 = (int32_t)arg2 + 0x40;
        puVar8 = (undefined8 *)(**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), 0, 0, (int64_t)iVar9);
        if (puVar8 == (undefined8 *)0x0) goto code_r0x000180098885;
        *(int32_t *)(puVar8 + 4) = iVar9;
        puVar10 = (undefined8 *)(iVar4 + 0x1e0);
        puVar8[2] = 0;
        puVar8[3] = 0;
        *puVar8 = 0;
        puVar8[1] = 0;
        *(int32_t *)((int64_t)puVar8 + 0x24) = (int32_t)arg2;
        puVar8[5] = 0;
        puVar8[6] = 0;
        if (puVar10 != (undefined8 *)0x0) {
            puVar5 = (undefined8 *)*puVar10;
            puVar8[1] = puVar5;
            if (puVar5 != (undefined8 *)0x0) {
                *puVar5 = puVar8;
            }
            *puVar10 = puVar8;
        }
        puVar10 = puVar8 + 8;
        *(int32_t *)(puVar8 + 6) = *(int32_t *)(puVar8 + 6) - *(int32_t *)((int64_t)puVar8 + 0x24);
        *(int32_t *)((int64_t)puVar8 + 0x34) = *(int32_t *)((int64_t)puVar8 + 0x34) + 1;
    }
    if ((puVar10 != (undefined8 *)0x0) || (arg2 == 0)) {
        *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + arg2;
        piVar2 = (int64_t *)(iVar4 + 0x2c30 + (in_R8 & 0xff) * 8);
        *piVar2 = *piVar2 + arg2;
        if (*(code **)(iVar4 + 0x510) != (code *)0x0) {
            (**(code **)(iVar4 + 0x510))(arg1, 0, arg2);
        }
        return puVar10;
    }
code_r0x000180098885:
    fcn.1800931b0(arg1, 4);
    pcVar6 = (code *)swi(3);
    puVar8 = (undefined8 *)(*pcVar6)();
    return puVar8;
}

// ============================================================
// Function: FUN_1800987db
// Address: 0x1800987db
// Size: 184 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.180098710(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar4 = *(int64_t *)(arg1 + 0x20);
    if ((arg2 - 1U < 0x400) && (cVar3 = *(char *)(arg2 + 0x180777990), -1 < cVar3)) {
        iVar1 = iVar4 + (int64_t)cVar3 * 8;
        iVar7 = *(int64_t *)(iVar1 + 0x1e8);
        if (iVar7 == 0) {
            iVar7 = fcn.180098440(arg1, iVar4 + 0x1e8, iVar4 + 0x1e0, (int64_t)cVar3, (uint64_t)var_28h._1_7_ << 8);
        }
        iVar9 = *(int32_t *)(iVar7 + 0x30);
        if (iVar9 < 0) {
            puVar10 = *(undefined8 **)(iVar7 + 0x28);
            *(undefined8 *)(iVar7 + 0x28) = puVar10[1];
        } else {
            puVar10 = (undefined8 *)((int64_t)iVar9 + 0x40 + iVar7);
            iVar9 = iVar9 - *(int32_t *)(iVar7 + 0x24);
            *(int32_t *)(iVar7 + 0x30) = iVar9;
        }
        *(int32_t *)(iVar7 + 0x34) = *(int32_t *)(iVar7 + 0x34) + 1;
        if ((*(int64_t *)(iVar7 + 0x28) == 0) && (iVar9 < 0)) {
            *(undefined8 *)(iVar1 + 0x1e8) = *(undefined8 *)(iVar7 + 0x18);
            if (*(int64_t *)(iVar7 + 0x18) != 0) {
                *(undefined8 *)(*(int64_t *)(iVar7 + 0x18) + 0x10) = 0;
            }
            *(undefined8 *)(iVar7 + 0x18) = 0;
        }
    } else {
        iVar9 = (int32_t)arg2 + 0x40;
        puVar8 = (undefined8 *)(**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), 0, 0, (int64_t)iVar9);
        if (puVar8 == (undefined8 *)0x0) goto code_r0x000180098885;
        *(int32_t *)(puVar8 + 4) = iVar9;
        puVar10 = (undefined8 *)(iVar4 + 0x1e0);
        puVar8[2] = 0;
        puVar8[3] = 0;
        *puVar8 = 0;
        puVar8[1] = 0;
        *(int32_t *)((int64_t)puVar8 + 0x24) = (int32_t)arg2;
        puVar8[5] = 0;
        puVar8[6] = 0;
        if (puVar10 != (undefined8 *)0x0) {
            puVar5 = (undefined8 *)*puVar10;
            puVar8[1] = puVar5;
            if (puVar5 != (undefined8 *)0x0) {
                *puVar5 = puVar8;
            }
            *puVar10 = puVar8;
        }
        puVar10 = puVar8 + 8;
        *(int32_t *)(puVar8 + 6) = *(int32_t *)(puVar8 + 6) - *(int32_t *)((int64_t)puVar8 + 0x24);
        *(int32_t *)((int64_t)puVar8 + 0x34) = *(int32_t *)((int64_t)puVar8 + 0x34) + 1;
    }
    if ((puVar10 != (undefined8 *)0x0) || (arg2 == 0)) {
        *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + arg2;
        piVar2 = (int64_t *)(iVar4 + 0x2c30 + (in_R8 & 0xff) * 8);
        *piVar2 = *piVar2 + arg2;
        if (*(code **)(iVar4 + 0x510) != (code *)0x0) {
            (**(code **)(iVar4 + 0x510))(arg1, 0, arg2);
        }
        return puVar10;
    }
code_r0x000180098885:
    fcn.1800931b0(arg1, 4);
    pcVar6 = (code *)swi(3);
    puVar8 = (undefined8 *)(*pcVar6)();
    return puVar8;
}

// ============================================================
// Function: FUN_1800988a0
// Address: 0x1800988a0
// Size: 321 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800988a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t arg2_00;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_58h;
    
    iVar4 = *(int64_t *)(arg1 + 0x20);
    uVar6 = 0xffffffff;
    if (arg4 - 1U < 0x400) {
        arg2_00 = (uint64_t)(uint32_t)(int32_t)*(char *)(arg4 + 0x180777990);
    } else {
        arg2_00 = 0xffffffff;
    }
    if (arg3 - 1U < 0x400) {
        uVar6 = (uint32_t)*(char *)(arg3 + 0x180777990);
    }
    if ((int32_t)arg2_00 < 0) {
        if ((int32_t)uVar6 < 0) {
            iVar3 = (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), arg2);
            if ((iVar3 == 0) && (arg4 != 0)) goto code_r0x0001800989d3;
            goto code_r0x00018009898c;
        }
        iVar3 = (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), 0, 0);
    } else {
        iVar3 = fcn.180098520(arg1, arg2_00);
    }
    if ((iVar3 == 0) && (arg4 != 0)) {
code_r0x0001800989d3:
        fcn.1800931b0(arg1, 4);
        pcVar2 = (code *)swi(3);
        iVar4 = (*pcVar2)();
        return iVar4;
    }
    if ((arg3 != 0) && (arg4 != 0)) {
        iVar5 = arg4;
        if ((uint64_t)arg3 < (uint64_t)arg4) {
            iVar5 = arg3;
        }
        func_0x000180498030(iVar3, arg2, iVar5);
    }
    if ((int32_t)uVar6 < 0) {
        (**(code **)(iVar4 + 0x48))(*(undefined8 *)(iVar4 + 0x50), arg2, arg3, 0);
    } else {
        fcn.1800985c0(arg1, (uint64_t)uVar6, arg2);
    }
code_r0x00018009898c:
    *(int64_t *)(iVar4 + 0x30) = *(int64_t *)(iVar4 + 0x30) + (arg4 - arg3);
    piVar1 = (int64_t *)(iVar4 + 0x2c30 + (arg_28h & 0xffU) * 8);
    *piVar1 = *piVar1 + (arg4 - arg3);
    if (*(code **)(iVar4 + 0x510) != (code *)0x0) {
        (**(code **)(iVar4 + 0x510))(arg1, arg3, arg4);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1800989f0
// Address: 0x1800989f0
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800989f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1e0);
    while (iVar4 = iVar3, iVar4 != 0) {
        iVar1 = *(int32_t *)(iVar4 + 0x24);
        uVar6 = (uint64_t)iVar1;
        iVar2 = *(int32_t *)(iVar4 + 0x20);
        iVar3 = *(int64_t *)(iVar4 + 8);
        iVar8 = *(int32_t *)(iVar4 + 0x34);
        iVar7 = (int64_t)*(int32_t *)(iVar4 + 0x30) + uVar6 + iVar4 + 0x40;
        while ((iVar7 != (int64_t)((int32_t)(((int64_t)iVar2 - 0x40U) / uVar6) * iVar1) + iVar4 + 0x40 &&
               (((*(char *)(iVar7 + 2) == '\0' || (cVar5 = (*(code *)arg3)(arg2, iVar4, iVar7), cVar5 == '\0')) ||
                (iVar8 = iVar8 + -1, iVar8 != 0))))) {
            iVar7 = iVar7 + uVar6;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180098a14
// Address: 0x180098a14
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800989f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1e0);
    while (iVar4 = iVar3, iVar4 != 0) {
        iVar1 = *(int32_t *)(iVar4 + 0x24);
        uVar6 = (uint64_t)iVar1;
        iVar2 = *(int32_t *)(iVar4 + 0x20);
        iVar3 = *(int64_t *)(iVar4 + 8);
        iVar8 = *(int32_t *)(iVar4 + 0x34);
        iVar7 = (int64_t)*(int32_t *)(iVar4 + 0x30) + uVar6 + iVar4 + 0x40;
        while ((iVar7 != (int64_t)((int32_t)(((int64_t)iVar2 - 0x40U) / uVar6) * iVar1) + iVar4 + 0x40 &&
               (((*(char *)(iVar7 + 2) == '\0' || (cVar5 = (*(code *)arg3)(arg2, iVar4, iVar7), cVar5 == '\0')) ||
                (iVar8 = iVar8 + -1, iVar8 != 0))))) {
            iVar7 = iVar7 + uVar6;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180098aab
// Address: 0x180098aab
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800989f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1e0);
    while (iVar4 = iVar3, iVar4 != 0) {
        iVar1 = *(int32_t *)(iVar4 + 0x24);
        uVar6 = (uint64_t)iVar1;
        iVar2 = *(int32_t *)(iVar4 + 0x20);
        iVar3 = *(int64_t *)(iVar4 + 8);
        iVar8 = *(int32_t *)(iVar4 + 0x34);
        iVar7 = (int64_t)*(int32_t *)(iVar4 + 0x30) + uVar6 + iVar4 + 0x40;
        while ((iVar7 != (int64_t)((int32_t)(((int64_t)iVar2 - 0x40U) / uVar6) * iVar1) + iVar4 + 0x40 &&
               (((*(char *)(iVar7 + 2) == '\0' || (cVar5 = (*(code *)arg3)(arg2, iVar4, iVar7), cVar5 == '\0')) ||
                (iVar8 = iVar8 + -1, iVar8 != 0))))) {
            iVar7 = iVar7 + uVar6;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180098ac0
// Address: 0x180098ac0
// Size: 226 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180098ac0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    char cVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar19 [16];
    undefined auVar20 [16];
    undefined auVar21 [16];
    undefined auVar22 [16];
    undefined auVar23 [16];
    undefined auVar24 [16];
    bool bVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined4 uVar29;
    int64_t iVar30;
    undefined *puVar31;
    uint8_t uVar32;
    int8_t iVar33;
    undefined uVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined *puVar37;
    uint64_t uVar38;
    uint64_t uVar39;
    uint32_t uVar40;
    uint64_t uVar41;
    uint64_t uVar42;
    int64_t *piVar43;
    undefined2 *puVar44;
    int64_t iVar45;
    uint64_t uVar46;
    uint64_t uVar47;
    int32_t iVar48;
    bool bVar49;
    uint64_t in_XMM1_Qa;
    int64_t var_18h;
    int64_t var_78h;
    undefined2 auStack_60 [2];
    int64_t var_5ch;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_78h;
    uVar39 = in_XMM1_Qa & 0xfffffffffffff;
    uVar35 = (uint32_t)(in_XMM1_Qa >> 0x34) & 0x7ff;
    if (uVar35 == 0x7ff) {
        if (uVar39 == 0) {
            *(undefined4 *)arg1 = *(undefined4 *)(((int64_t)in_XMM1_Qa >> 0x3f) + 0x18063e3a1);
            fcn.180459870(var_48h ^ (uint64_t)&var_78h);
            return;
        }
        *(undefined4 *)arg1 = 0x6e616e;
        fcn.180459870(var_48h ^ (uint64_t)&var_78h);
        return;
    }
    puVar1 = (undefined4 *)(arg1 - ((int64_t)in_XMM1_Qa >> 0x3f));
    *(undefined *)arg1 = 0x2d;
    if (uVar35 == 0) {
        if (uVar39 == 0) {
            *(undefined *)puVar1 = 0x30;
            goto code_r0x000180099054;
        }
        iVar36 = -0x432;
code_r0x000180098ba2:
        uVar32 = 0;
        if ((uVar39 == 0x10000000000000) && (iVar36 != -0x432)) {
            iVar45 = -1;
            uVar32 = 1;
        } else {
            iVar45 = -2;
        }
        iVar48 = (int32_t)((-(uint32_t)uVar32 & 0xfffe0040) + iVar36 * 0x4d104) >> 0x14;
        uVar35 = 0x124 - iVar48;
        iVar30 = (int64_t)(int32_t)uVar35 >> 4;
        uVar32 = (char)(iVar48 * -0x35269e >> 0x14) + (char)iVar36 + '\x01';
        uVar42 = *(uint64_t *)((uint64_t)(uVar35 & 0xf) * 8 + 0x180612510);
        auVar5._8_8_ = 0;
        auVar5._0_8_ = uVar42;
        auVar13._8_8_ = 0;
        auVar13._0_8_ = *(uint64_t *)(iVar30 * 0x18 + 0x180612660);
        auVar6._8_8_ = 0;
        auVar6._0_8_ = uVar42;
        auVar14._8_8_ = 0;
        auVar14._0_8_ = *(uint64_t *)(iVar30 * 0x18 + 0x180612668);
        auVar21._8_8_ = 0;
        auVar21._0_8_ = SUB168(auVar6 * auVar14, 8);
        auVar21 = auVar5 * auVar13 + auVar21;
        uVar42 = auVar21._0_8_;
        iVar2 = uVar39 * 4;
        uVar40 = (uint32_t)(*(uint64_t *)(iVar30 * 0x18 + 0x180612670) >> (int8_t)((uVar35 & 0xf) << 2));
        uVar35 = (uVar40 & 0xf) >> 3;
        iVar33 = (int8_t)uVar35;
        uVar41 = iVar45 + iVar2 << (uVar32 & 0x3f);
        uVar38 = (uVar42 >> 0x3f & (uint64_t)uVar35) + (auVar21._8_8_ << iVar33);
        uVar42 = ((uVar42 << iVar33) - (uint64_t)(uVar40 & 7)) + 4;
        auVar7._8_8_ = 0;
        auVar7._0_8_ = uVar41;
        auVar15._8_8_ = 0;
        auVar15._0_8_ = uVar42;
        auVar22._8_8_ = 0;
        auVar22._0_8_ = SUB168(auVar7 * auVar15, 8);
        auVar8._8_8_ = 0;
        auVar8._0_8_ = uVar41;
        auVar16._8_8_ = 0;
        auVar16._0_8_ = uVar38;
        auVar22 = auVar8 * auVar16 + auVar22;
        uVar41 = iVar2 << (uVar32 & 0x3f);
        uVar46 = auVar22._8_8_ | (uint64_t)(1 < auVar22._0_8_);
        auVar9._8_8_ = 0;
        auVar9._0_8_ = uVar41;
        auVar17._8_8_ = 0;
        auVar17._0_8_ = uVar42;
        auVar23._8_8_ = 0;
        auVar23._0_8_ = SUB168(auVar9 * auVar17, 8);
        auVar10._8_8_ = 0;
        auVar10._0_8_ = uVar41;
        auVar18._8_8_ = 0;
        auVar18._0_8_ = uVar38;
        auVar23 = auVar10 * auVar18 + auVar23;
        uVar47 = auVar23._8_8_;
        uVar41 = iVar2 + 2 << (uVar32 & 0x3f);
        auVar11._8_8_ = 0;
        auVar11._0_8_ = uVar41;
        auVar19._8_8_ = 0;
        auVar19._0_8_ = uVar42;
        auVar24._8_8_ = 0;
        auVar24._0_8_ = SUB168(auVar11 * auVar19, 8);
        auVar12._8_8_ = 0;
        auVar12._0_8_ = uVar41;
        auVar20._8_8_ = 0;
        auVar20._0_8_ = uVar38;
        auVar24 = auVar12 * auVar20 + auVar24;
        uVar42 = uVar47 >> 2;
        uVar38 = auVar24._8_8_ | (uint64_t)(1 < auVar24._0_8_);
        uVar39 = (uint64_t)((uint32_t)uVar39 & 1);
        if (9 < uVar42) {
            uVar41 = (uVar42 / 10) * 0x28;
            bVar49 = uVar41 + 0x28 + uVar39 <= uVar38;
            if (uVar39 + uVar46 <= uVar41 != bVar49) {
                iVar48 = iVar48 + 1;
                uVar42 = (uint64_t)bVar49 + uVar42 / 10;
                goto code_r0x000180098e12;
            }
        }
        uVar41 = uVar47 & 0xfffffffffffffffc;
        bVar49 = uVar41 + 4 + uVar39 <= uVar38;
        bVar25 = (uVar41 - ((uint32_t)uVar42 & 1)) + 3 <= (uVar47 | 1 < auVar23._0_8_);
        if (uVar39 + uVar46 <= uVar41 != bVar49) {
            bVar25 = bVar49;
        }
        uVar42 = bVar25 + uVar42;
    } else {
        iVar36 = uVar35 - 0x433;
        uVar39 = uVar39 | 0x10000000000000;
        if ((0x34 < 0x433 - uVar35) || (uVar32 = 0x33 - (char)uVar35, (uVar39 & (1LL << (uVar32 & 0x3f)) - 1U) != 0))
        goto code_r0x000180098ba2;
        uVar42 = uVar39 >> (uVar32 & 0x3f);
        iVar48 = 0;
    }
code_r0x000180098e12:
    piVar43 = &var_5ch;
    while (uVar35 = (uint32_t)uVar42, 9999 < uVar42) {
        uVar42 = uVar42 / 10000;
        uVar35 = uVar35 + (int32_t)uVar42 * -10000;
        *(undefined2 *)((int64_t)piVar43 + -4) = *(undefined2 *)((int64_t)(int32_t)((uVar35 / 100) * 2) + 0x180612590);
        *(undefined2 *)((int64_t)piVar43 + -2) = *(undefined2 *)((int64_t)(int32_t)((uVar35 % 100) * 2) + 0x180612590);
        piVar43 = (int64_t *)((int64_t)piVar43 + -4);
    }
    while (9 < uVar35) {
        piVar43 = (int64_t *)((int64_t)piVar43 + -2);
        uVar39 = (uVar42 & 0xffffffff) / 100;
        uVar35 = (uint32_t)uVar39;
        *(undefined2 *)piVar43 =
             *(undefined2 *)((int64_t)(int32_t)(((int32_t)uVar42 + uVar35 * -100) * 2) + 0x180612590);
        uVar42 = uVar39;
    }
    if (uVar35 != 0) {
        piVar43 = (int64_t *)((int64_t)piVar43 + -1);
        *(char *)piVar43 = (char)uVar35 + '0';
    }
    iVar36 = (int32_t)&var_5ch - (int32_t)piVar43;
    iVar48 = iVar36 + iVar48;
    if (iVar48 + 5U < 0x1b) {
        uVar26 = *(undefined4 *)piVar43;
        uVar27 = *(undefined4 *)((int64_t)piVar43 + 4);
        uVar28 = *(undefined4 *)(piVar43 + 1);
        uVar29 = *(undefined4 *)((int64_t)piVar43 + 0xc);
        if (iVar48 < 1) {
            *(undefined2 *)puVar1 = 0x2e30;
            *(undefined4 *)((int64_t)puVar1 + 2) = 0x30303030;
            *(undefined *)((int64_t)puVar1 + 6) = 0x30;
            uVar34 = *(undefined *)(piVar43 + 2);
            iVar45 = (int64_t)-iVar48;
            puVar3 = (undefined4 *)((int64_t)puVar1 + iVar45 + 2);
            *puVar3 = uVar26;
            puVar3[1] = uVar27;
            puVar3[2] = uVar28;
            puVar3[3] = uVar29;
            *(undefined *)((int64_t)puVar1 + iVar45 + 0x12) = uVar34;
            puVar31 = (undefined *)((int64_t)puVar1 + iVar45 + (int64_t)iVar36 + 2);
            cVar4 = puVar31[-1];
            while (cVar4 == '0') {
                cVar4 = puVar31[-2];
                puVar31 = puVar31 + -1;
            }
        } else {
            *puVar1 = uVar26;
            puVar1[1] = uVar27;
            puVar1[2] = uVar28;
            puVar1[3] = uVar29;
            puVar31 = (undefined *)((int64_t)puVar1 + (int64_t)iVar48);
            if (iVar48 == iVar36) {
                *(undefined *)(puVar1 + 4) = *(undefined *)(piVar43 + 2);
            } else {
                iVar45 = (int64_t)iVar36;
                if (iVar48 < iVar36) {
                    puVar3 = (undefined4 *)((int64_t)iVar48 + (int64_t)piVar43);
                    uVar26 = *puVar3;
                    uVar27 = puVar3[1];
                    uVar28 = puVar3[2];
                    uVar29 = puVar3[3];
                    *puVar31 = 0x2e;
                    *(undefined4 *)(puVar31 + 1) = uVar26;
                    *(undefined4 *)(puVar31 + 5) = uVar27;
                    *(undefined4 *)(puVar31 + 9) = uVar28;
                    *(undefined4 *)(puVar31 + 0xd) = uVar29;
                    cVar4 = *(char *)(iVar45 + (int64_t)puVar1);
                    puVar31 = (undefined *)((int64_t)puVar1 + iVar45 + 1);
                    while (cVar4 == '0') {
                        cVar4 = puVar31[-2];
                        puVar31 = puVar31 + -1;
                    }
                } else {
                    *(undefined *)(puVar1 + 4) = *(undefined *)(piVar43 + 2);
                    *(undefined8 *)(iVar45 + (int64_t)puVar1) = 0x3030303030303030;
                }
            }
        }
    } else {
        uVar26 = *(undefined4 *)((int64_t)piVar43 + 1);
        uVar27 = *(undefined4 *)((int64_t)piVar43 + 5);
        uVar28 = *(undefined4 *)((int64_t)piVar43 + 9);
        uVar29 = *(undefined4 *)((int64_t)piVar43 + 0xd);
        *(undefined *)puVar1 = *(undefined *)piVar43;
        *(undefined *)((int64_t)puVar1 + 1) = 0x2e;
        *(undefined4 *)((int64_t)puVar1 + 2) = uVar26;
        *(undefined4 *)((int64_t)puVar1 + 6) = uVar27;
        *(undefined4 *)((int64_t)puVar1 + 10) = uVar28;
        *(undefined4 *)((int64_t)puVar1 + 0xe) = uVar29;
        cVar4 = *(char *)((int64_t)iVar36 + (int64_t)puVar1);
        puVar31 = (undefined *)((int64_t)puVar1 + (int64_t)iVar36 + 1);
        while (cVar4 == '0') {
            cVar4 = puVar31[-2];
            puVar31 = puVar31 + -1;
        }
        puVar37 = puVar31 + -1;
        if (puVar31[-1] != '.') {
            puVar37 = puVar31;
        }
        iVar48 = iVar48 + -1;
        uVar34 = 0x2b;
        if (iVar48 < 0) {
            uVar34 = 0x2d;
        }
        puVar37[1] = uVar34;
        puVar44 = (undefined2 *)(puVar37 + 2);
        *puVar37 = 0x65;
        iVar36 = -iVar48;
        if (0 < iVar48) {
            iVar36 = iVar48;
        }
        if (99 < iVar36) {
            *(char *)puVar44 = (char)(iVar36 / 100) + '0';
            puVar44 = (undefined2 *)(puVar37 + 3);
            iVar36 = iVar36 % 100;
        }
        *puVar44 = *(undefined2 *)((int64_t)(iVar36 * 2) + 0x180612590);
    }
code_r0x000180099054:
    fcn.180459870(var_48h ^ (uint64_t)&var_78h);
    return;
}

// ============================================================
// Function: FUN_180098ba2
// Address: 0x180098ba2
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180098ac0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    char cVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar19 [16];
    undefined auVar20 [16];
    undefined auVar21 [16];
    undefined auVar22 [16];
    undefined auVar23 [16];
    undefined auVar24 [16];
    bool bVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined4 uVar29;
    int64_t iVar30;
    undefined *puVar31;
    uint8_t uVar32;
    int8_t iVar33;
    undefined uVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined *puVar37;
    uint64_t uVar38;
    uint64_t uVar39;
    uint32_t uVar40;
    uint64_t uVar41;
    uint64_t uVar42;
    int64_t *piVar43;
    undefined2 *puVar44;
    int64_t iVar45;
    uint64_t uVar46;
    uint64_t uVar47;
    int32_t iVar48;
    bool bVar49;
    uint64_t in_XMM1_Qa;
    int64_t var_18h;
    int64_t var_78h;
    undefined2 auStack_60 [2];
    int64_t var_5ch;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_78h;
    uVar39 = in_XMM1_Qa & 0xfffffffffffff;
    uVar35 = (uint32_t)(in_XMM1_Qa >> 0x34) & 0x7ff;
    if (uVar35 == 0x7ff) {
        if (uVar39 == 0) {
            *(undefined4 *)arg1 = *(undefined4 *)(((int64_t)in_XMM1_Qa >> 0x3f) + 0x18063e3a1);
            fcn.180459870(var_48h ^ (uint64_t)&var_78h);
            return;
        }
        *(undefined4 *)arg1 = 0x6e616e;
        fcn.180459870(var_48h ^ (uint64_t)&var_78h);
        return;
    }
    puVar1 = (undefined4 *)(arg1 - ((int64_t)in_XMM1_Qa >> 0x3f));
    *(undefined *)arg1 = 0x2d;
    if (uVar35 == 0) {
        if (uVar39 == 0) {
            *(undefined *)puVar1 = 0x30;
            goto code_r0x000180099054;
        }
        iVar36 = -0x432;
code_r0x000180098ba2:
        uVar32 = 0;
        if ((uVar39 == 0x10000000000000) && (iVar36 != -0x432)) {
            iVar45 = -1;
            uVar32 = 1;
        } else {
            iVar45 = -2;
        }
        iVar48 = (int32_t)((-(uint32_t)uVar32 & 0xfffe0040) + iVar36 * 0x4d104) >> 0x14;
        uVar35 = 0x124 - iVar48;
        iVar30 = (int64_t)(int32_t)uVar35 >> 4;
        uVar32 = (char)(iVar48 * -0x35269e >> 0x14) + (char)iVar36 + '\x01';
        uVar42 = *(uint64_t *)((uint64_t)(uVar35 & 0xf) * 8 + 0x180612510);
        auVar5._8_8_ = 0;
        auVar5._0_8_ = uVar42;
        auVar13._8_8_ = 0;
        auVar13._0_8_ = *(uint64_t *)(iVar30 * 0x18 + 0x180612660);
        auVar6._8_8_ = 0;
        auVar6._0_8_ = uVar42;
        auVar14._8_8_ = 0;
        auVar14._0_8_ = *(uint64_t *)(iVar30 * 0x18 + 0x180612668);
        auVar21._8_8_ = 0;
        auVar21._0_8_ = SUB168(auVar6 * auVar14, 8);
        auVar21 = auVar5 * auVar13 + auVar21;
        uVar42 = auVar21._0_8_;
        iVar2 = uVar39 * 4;
        uVar40 = (uint32_t)(*(uint64_t *)(iVar30 * 0x18 + 0x180612670) >> (int8_t)((uVar35 & 0xf) << 2));
        uVar35 = (uVar40 & 0xf) >> 3;
        iVar33 = (int8_t)uVar35;
        uVar41 = iVar45 + iVar2 << (uVar32 & 0x3f);
        uVar38 = (uVar42 >> 0x3f & (uint64_t)uVar35) + (auVar21._8_8_ << iVar33);
        uVar42 = ((uVar42 << iVar33) - (uint64_t)(uVar40 & 7)) + 4;
        auVar7._8_8_ = 0;
        auVar7._0_8_ = uVar41;
        auVar15._8_8_ = 0;
        auVar15._0_8_ = uVar42;
        auVar22._8_8_ = 0;
        auVar22._0_8_ = SUB168(auVar7 * auVar15, 8);
        auVar8._8_8_ = 0;
        auVar8._0_8_ = uVar41;
        auVar16._8_8_ = 0;
        auVar16._0_8_ = uVar38;
        auVar22 = auVar8 * auVar16 + auVar22;
        uVar41 = iVar2 << (uVar32 & 0x3f);
        uVar46 = auVar22._8_8_ | (uint64_t)(1 < auVar22._0_8_);
        auVar9._8_8_ = 0;
        auVar9._0_8_ = uVar41;
        auVar17._8_8_ = 0;
        auVar17._0_8_ = uVar42;
        auVar23._8_8_ = 0;
        auVar23._0_8_ = SUB168(auVar9 * auVar17, 8);
        auVar10._8_8_ = 0;
        auVar10._0_8_ = uVar41;
        auVar18._8_8_ = 0;
        auVar18._0_8_ = uVar38;
        auVar23 = auVar10 * auVar18 + auVar23;
        uVar47 = auVar23._8_8_;
        uVar41 = iVar2 + 2 << (uVar32 & 0x3f);
        auVar11._8_8_ = 0;
        auVar11._0_8_ = uVar41;
        auVar19._8_8_ = 0;
        auVar19._0_8_ = uVar42;
        auVar24._8_8_ = 0;
        auVar24._0_8_ = SUB168(auVar11 * auVar19, 8);
        auVar12._8_8_ = 0;
        auVar12._0_8_ = uVar41;
        auVar20._8_8_ = 0;
        auVar20._0_8_ = uVar38;
        auVar24 = auVar12 * auVar20 + auVar24;
        uVar42 = uVar47 >> 2;
        uVar38 = auVar24._8_8_ | (uint64_t)(1 < auVar24._0_8_);
        uVar39 = (uint64_t)((uint32_t)uVar39 & 1);
        if (9 < uVar42) {
            uVar41 = (uVar42 / 10) * 0x28;
            bVar49 = uVar41 + 0x28 + uVar39 <= uVar38;
            if (uVar39 + uVar46 <= uVar41 != bVar49) {
                iVar48 = iVar48 + 1;
                uVar42 = (uint64_t)bVar49 + uVar42 / 10;
                goto code_r0x000180098e12;
            }
        }
        uVar41 = uVar47 & 0xfffffffffffffffc;
        bVar49 = uVar41 + 4 + uVar39 <= uVar38;
        bVar25 = (uVar41 - ((uint32_t)uVar42 & 1)) + 3 <= (uVar47 | 1 < auVar23._0_8_);
        if (uVar39 + uVar46 <= uVar41 != bVar49) {
            bVar25 = bVar49;
        }
        uVar42 = bVar25 + uVar42;
    } else {
        iVar36 = uVar35 - 0x433;
        uVar39 = uVar39 | 0x10000000000000;
        if ((0x34 < 0x433 - uVar35) || (uVar32 = 0x33 - (char)uVar35, (uVar39 & (1LL << (uVar32 & 0x3f)) - 1U) != 0))
        goto code_r0x000180098ba2;
        uVar42 = uVar39 >> (uVar32 & 0x3f);
        iVar48 = 0;
    }
code_r0x000180098e12:
    piVar43 = &var_5ch;
    while (uVar35 = (uint32_t)uVar42, 9999 < uVar42) {
        uVar42 = uVar42 / 10000;
        uVar35 = uVar35 + (int32_t)uVar42 * -10000;
        *(undefined2 *)((int64_t)piVar43 + -4) = *(undefined2 *)((int64_t)(int32_t)((uVar35 / 100) * 2) + 0x180612590);
        *(undefined2 *)((int64_t)piVar43 + -2) = *(undefined2 *)((int64_t)(int32_t)((uVar35 % 100) * 2) + 0x180612590);
        piVar43 = (int64_t *)((int64_t)piVar43 + -4);
    }
    while (9 < uVar35) {
        piVar43 = (int64_t *)((int64_t)piVar43 + -2);
        uVar39 = (uVar42 & 0xffffffff) / 100;
        uVar35 = (uint32_t)uVar39;
        *(undefined2 *)piVar43 =
             *(undefined2 *)((int64_t)(int32_t)(((int32_t)uVar42 + uVar35 * -100) * 2) + 0x180612590);
        uVar42 = uVar39;
    }
    if (uVar35 != 0) {
        piVar43 = (int64_t *)((int64_t)piVar43 + -1);
        *(char *)piVar43 = (char)uVar35 + '0';
    }
    iVar36 = (int32_t)&var_5ch - (int32_t)piVar43;
    iVar48 = iVar36 + iVar48;
    if (iVar48 + 5U < 0x1b) {
        uVar26 = *(undefined4 *)piVar43;
        uVar27 = *(undefined4 *)((int64_t)piVar43 + 4);
        uVar28 = *(undefined4 *)(piVar43 + 1);
        uVar29 = *(undefined4 *)((int64_t)piVar43 + 0xc);
        if (iVar48 < 1) {
            *(undefined2 *)puVar1 = 0x2e30;
            *(undefined4 *)((int64_t)puVar1 + 2) = 0x30303030;
            *(undefined *)((int64_t)puVar1 + 6) = 0x30;
            uVar34 = *(undefined *)(piVar43 + 2);
            iVar45 = (int64_t)-iVar48;
            puVar3 = (undefined4 *)((int64_t)puVar1 + iVar45 + 2);
            *puVar3 = uVar26;
            puVar3[1] = uVar27;
            puVar3[2] = uVar28;
            puVar3[3] = uVar29;
            *(undefined *)((int64_t)puVar1 + iVar45 + 0x12) = uVar34;
            puVar31 = (undefined *)((int64_t)puVar1 + iVar45 + (int64_t)iVar36 + 2);
            cVar4 = puVar31[-1];
            while (cVar4 == '0') {
                cVar4 = puVar31[-2];
                puVar31 = puVar31 + -1;
            }
        } else {
            *puVar1 = uVar26;
            puVar1[1] = uVar27;
            puVar1[2] = uVar28;
            puVar1[3] = uVar29;
            puVar31 = (undefined *)((int64_t)puVar1 + (int64_t)iVar48);
            if (iVar48 == iVar36) {
                *(undefined *)(puVar1 + 4) = *(undefined *)(piVar43 + 2);
            } else {
                iVar45 = (int64_t)iVar36;
                if (iVar48 < iVar36) {
                    puVar3 = (undefined4 *)((int64_t)iVar48 + (int64_t)piVar43);
                    uVar26 = *puVar3;
                    uVar27 = puVar3[1];
                    uVar28 = puVar3[2];
                    uVar29 = puVar3[3];
                    *puVar31 = 0x2e;
                    *(undefined4 *)(puVar31 + 1) = uVar26;
                    *(undefined4 *)(puVar31 + 5) = uVar27;
                    *(undefined4 *)(puVar31 + 9) = uVar28;
                    *(undefined4 *)(puVar31 + 0xd) = uVar29;
                    cVar4 = *(char *)(iVar45 + (int64_t)puVar1);
                    puVar31 = (undefined *)((int64_t)puVar1 + iVar45 + 1);
                    while (cVar4 == '0') {
                        cVar4 = puVar31[-2];
                        puVar31 = puVar31 + -1;
                    }
                } else {
                    *(undefined *)(puVar1 + 4) = *(undefined *)(piVar43 + 2);
                    *(undefined8 *)(iVar45 + (int64_t)puVar1) = 0x3030303030303030;
                }
            }
        }
    } else {
        uVar26 = *(undefined4 *)((int64_t)piVar43 + 1);
        uVar27 = *(undefined4 *)((int64_t)piVar43 + 5);
        uVar28 = *(undefined4 *)((int64_t)piVar43 + 9);
        uVar29 = *(undefined4 *)((int64_t)piVar43 + 0xd);
        *(undefined *)puVar1 = *(undefined *)piVar43;
        *(undefined *)((int64_t)puVar1 + 1) = 0x2e;
        *(undefined4 *)((int64_t)puVar1 + 2) = uVar26;
        *(undefined4 *)((int64_t)puVar1 + 6) = uVar27;
        *(undefined4 *)((int64_t)puVar1 + 10) = uVar28;
        *(undefined4 *)((int64_t)puVar1 + 0xe) = uVar29;
        cVar4 = *(char *)((int64_t)iVar36 + (int64_t)puVar1);
        puVar31 = (undefined *)((int64_t)puVar1 + (int64_t)iVar36 + 1);
        while (cVar4 == '0') {
            cVar4 = puVar31[-2];
            puVar31 = puVar31 + -1;
        }
        puVar37 = puVar31 + -1;
        if (puVar31[-1] != '.') {
            puVar37 = puVar31;
        }
        iVar48 = iVar48 + -1;
        uVar34 = 0x2b;
        if (iVar48 < 0) {
            uVar34 = 0x2d;
        }
        puVar37[1] = uVar34;
        puVar44 = (undefined2 *)(puVar37 + 2);
        *puVar37 = 0x65;
        iVar36 = -iVar48;
        if (0 < iVar48) {
            iVar36 = iVar48;
        }
        if (99 < iVar36) {
            *(char *)puVar44 = (char)(iVar36 / 100) + '0';
            puVar44 = (undefined2 *)(puVar37 + 3);
            iVar36 = iVar36 % 100;
        }
        *puVar44 = *(undefined2 *)((int64_t)(iVar36 * 2) + 0x180612590);
    }
code_r0x000180099054:
    fcn.180459870(var_48h ^ (uint64_t)&var_78h);
    return;
}

// ============================================================
// Function: FUN_180098bcf
// Address: 0x180098bcf
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180098ac0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    char cVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar19 [16];
    undefined auVar20 [16];
    undefined auVar21 [16];
    undefined auVar22 [16];
    undefined auVar23 [16];
    undefined auVar24 [16];
    bool bVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined4 uVar29;
    int64_t iVar30;
    undefined *puVar31;
    uint8_t uVar32;
    int8_t iVar33;
    undefined uVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined *puVar37;
    uint64_t uVar38;
    uint64_t uVar39;
    uint32_t uVar40;
    uint64_t uVar41;
    uint64_t uVar42;
    int64_t *piVar43;
    undefined2 *puVar44;
    int64_t iVar45;
    uint64_t uVar46;
    uint64_t uVar47;
    int32_t iVar48;
    bool bVar49;
    uint64_t in_XMM1_Qa;
    int64_t var_18h;
    int64_t var_78h;
    undefined2 auStack_60 [2];
    int64_t var_5ch;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_78h;
    uVar39 = in_XMM1_Qa & 0xfffffffffffff;
    uVar35 = (uint32_t)(in_XMM1_Qa >> 0x34) & 0x7ff;
    if (uVar35 == 0x7ff) {
        if (uVar39 == 0) {
            *(undefined4 *)arg1 = *(undefined4 *)(((int64_t)in_XMM1_Qa >> 0x3f) + 0x18063e3a1);
            fcn.180459870(var_48h ^ (uint64_t)&var_78h);
            return;
        }
        *(undefined4 *)arg1 = 0x6e616e;
        fcn.180459870(var_48h ^ (uint64_t)&var_78h);
        return;
    }
    puVar1 = (undefined4 *)(arg1 - ((int64_t)in_XMM1_Qa >> 0x3f));
    *(undefined *)arg1 = 0x2d;
    if (uVar35 == 0) {
        if (uVar39 == 0) {
            *(undefined *)puVar1 = 0x30;
            goto code_r0x000180099054;
        }
        iVar36 = -0x432;
code_r0x000180098ba2:
        uVar32 = 0;
        if ((uVar39 == 0x10000000000000) && (iVar36 != -0x432)) {
            iVar45 = -1;
            uVar32 = 1;
        } else {
            iVar45 = -2;
        }
        iVar48 = (int32_t)((-(uint32_t)uVar32 & 0xfffe0040) + iVar36 * 0x4d104) >> 0x14;
        uVar35 = 0x124 - iVar48;
        iVar30 = (int64_t)(int32_t)uVar35 >> 4;
        uVar32 = (char)(iVar48 * -0x35269e >> 0x14) + (char)iVar36 + '\x01';
        uVar42 = *(uint64_t *)((uint64_t)(uVar35 & 0xf) * 8 + 0x180612510);
        auVar5._8_8_ = 0;
        auVar5._0_8_ = uVar42;
        auVar13._8_8_ = 0;
        auVar13._0_8_ = *(uint64_t *)(iVar30 * 0x18 + 0x180612660);
        auVar6._8_8_ = 0;
        auVar6._0_8_ = uVar42;
        auVar14._8_8_ = 0;
        auVar14._0_8_ = *(uint64_t *)(iVar30 * 0x18 + 0x180612668);
        auVar21._8_8_ = 0;
        auVar21._0_8_ = SUB168(auVar6 * auVar14, 8);
        auVar21 = auVar5 * auVar13 + auVar21;
        uVar42 = auVar21._0_8_;
        iVar2 = uVar39 * 4;
        uVar40 = (uint32_t)(*(uint64_t *)(iVar30 * 0x18 + 0x180612670) >> (int8_t)((uVar35 & 0xf) << 2));
        uVar35 = (uVar40 & 0xf) >> 3;
        iVar33 = (int8_t)uVar35;
        uVar41 = iVar45 + iVar2 << (uVar32 & 0x3f);
        uVar38 = (uVar42 >> 0x3f & (uint64_t)uVar35) + (auVar21._8_8_ << iVar33);
        uVar42 = ((uVar42 << iVar33) - (uint64_t)(uVar40 & 7)) + 4;
        auVar7._8_8_ = 0;
        auVar7._0_8_ = uVar41;
        auVar15._8_8_ = 0;
        auVar15._0_8_ = uVar42;
        auVar22._8_8_ = 0;
        auVar22._0_8_ = SUB168(auVar7 * auVar15, 8);
        auVar8._8_8_ = 0;
        auVar8._0_8_ = uVar41;
        auVar16._8_8_ = 0;
        auVar16._0_8_ = uVar38;
        auVar22 = auVar8 * auVar16 + auVar22;
        uVar41 = iVar2 << (uVar32 & 0x3f);
        uVar46 = auVar22._8_8_ | (uint64_t)(1 < auVar22._0_8_);
        auVar9._8_8_ = 0;
        auVar9._0_8_ = uVar41;
        auVar17._8_8_ = 0;
        auVar17._0_8_ = uVar42;
        auVar23._8_8_ = 0;
        auVar23._0_8_ = SUB168(auVar9 * auVar17, 8);
        auVar10._8_8_ = 0;
        auVar10._0_8_ = uVar41;
        auVar18._8_8_ = 0;
        auVar18._0_8_ = uVar38;
        auVar23 = auVar10 * auVar18 + auVar23;
        uVar47 = auVar23._8_8_;
        uVar41 = iVar2 + 2 << (uVar32 & 0x3f);
        auVar11._8_8_ = 0;
        auVar11._0_8_ = uVar41;
        auVar19._8_8_ = 0;
        auVar19._0_8_ = uVar42;
        auVar24._8_8_ = 0;
        auVar24._0_8_ = SUB168(auVar11 * auVar19, 8);
        auVar12._8_8_ = 0;
        auVar12._0_8_ = uVar41;
        auVar20._8_8_ = 0;
        auVar20._0_8_ = uVar38;
        auVar24 = auVar12 * auVar20 + auVar24;
        uVar42 = uVar47 >> 2;
        uVar38 = auVar24._8_8_ | (uint64_t)(1 < auVar24._0_8_);
        uVar39 = (uint64_t)((uint32_t)uVar39 & 1);
        if (9 < uVar42) {
            uVar41 = (uVar42 / 10) * 0x28;
            bVar49 = uVar41 + 0x28 + uVar39 <= uVar38;
            if (uVar39 + uVar46 <= uVar41 != bVar49) {
                iVar48 = iVar48 + 1;
                uVar42 = (uint64_t)bVar49 + uVar42 / 10;
                goto code_r0x000180098e12;
            }
        }
        uVar41 = uVar47 & 0xfffffffffffffffc;
        bVar49 = uVar41 + 4 + uVar39 <= uVar38;
        bVar25 = (uVar41 - ((uint32_t)uVar42 & 1)) + 3 <= (uVar47 | 1 < auVar23._0_8_);
        if (uVar39 + uVar46 <= uVar41 != bVar49) {
            bVar25 = bVar49;
        }
        uVar42 = bVar25 + uVar42;
    } else {
        iVar36 = uVar35 - 0x433;
        uVar39 = uVar39 | 0x10000000000000;
        if ((0x34 < 0x433 - uVar35) || (uVar32 = 0x33 - (char)uVar35, (uVar39 & (1LL << (uVar32 & 0x3f)) - 1U) != 0))
        goto code_r0x000180098ba2;
        uVar42 = uVar39 >> (uVar32 & 0x3f);
        iVar48 = 0;
    }
code_r0x000180098e12:
    piVar43 = &var_5ch;
    while (uVar35 = (uint32_t)uVar42, 9999 < uVar42) {
        uVar42 = uVar42 / 10000;
        uVar35 = uVar35 + (int32_t)uVar42 * -10000;
        *(undefined2 *)((int64_t)piVar43 + -4) = *(undefined2 *)((int64_t)(int32_t)((uVar35 / 100) * 2) + 0x180612590);
        *(undefined2 *)((int64_t)piVar43 + -2) = *(undefined2 *)((int64_t)(int32_t)((uVar35 % 100) * 2) + 0x180612590);
        piVar43 = (int64_t *)((int64_t)piVar43 + -4);
    }
    while (9 < uVar35) {
        piVar43 = (int64_t *)((int64_t)piVar43 + -2);
        uVar39 = (uVar42 & 0xffffffff) / 100;
        uVar35 = (uint32_t)uVar39;
        *(undefined2 *)piVar43 =
             *(undefined2 *)((int64_t)(int32_t)(((int32_t)uVar42 + uVar35 * -100) * 2) + 0x180612590);
        uVar42 = uVar39;
    }
    if (uVar35 != 0) {
        piVar43 = (int64_t *)((int64_t)piVar43 + -1);
        *(char *)piVar43 = (char)uVar35 + '0';
    }
    iVar36 = (int32_t)&var_5ch - (int32_t)piVar43;
    iVar48 = iVar36 + iVar48;
    if (iVar48 + 5U < 0x1b) {
        uVar26 = *(undefined4 *)piVar43;
        uVar27 = *(undefined4 *)((int64_t)piVar43 + 4);
        uVar28 = *(undefined4 *)(piVar43 + 1);
        uVar29 = *(undefined4 *)((int64_t)piVar43 + 0xc);
        if (iVar48 < 1) {
            *(undefined2 *)puVar1 = 0x2e30;
            *(undefined4 *)((int64_t)puVar1 + 2) = 0x30303030;
            *(undefined *)((int64_t)puVar1 + 6) = 0x30;
            uVar34 = *(undefined *)(piVar43 + 2);
            iVar45 = (int64_t)-iVar48;
            puVar3 = (undefined4 *)((int64_t)puVar1 + iVar45 + 2);
            *puVar3 = uVar26;
            puVar3[1] = uVar27;
            puVar3[2] = uVar28;
            puVar3[3] = uVar29;
            *(undefined *)((int64_t)puVar1 + iVar45 + 0x12) = uVar34;
            puVar31 = (undefined *)((int64_t)puVar1 + iVar45 + (int64_t)iVar36 + 2);
            cVar4 = puVar31[-1];
            while (cVar4 == '0') {
                cVar4 = puVar31[-2];
                puVar31 = puVar31 + -1;
            }
        } else {
            *puVar1 = uVar26;
            puVar1[1] = uVar27;
            puVar1[2] = uVar28;
            puVar1[3] = uVar29;
            puVar31 = (undefined *)((int64_t)puVar1 + (int64_t)iVar48);
            if (iVar48 == iVar36) {
                *(undefined *)(puVar1 + 4) = *(undefined *)(piVar43 + 2);
            } else {
                iVar45 = (int64_t)iVar36;
                if (iVar48 < iVar36) {
                    puVar3 = (undefined4 *)((int64_t)iVar48 + (int64_t)piVar43);
                    uVar26 = *puVar3;
                    uVar27 = puVar3[1];
                    uVar28 = puVar3[2];
                    uVar29 = puVar3[3];
                    *puVar31 = 0x2e;
                    *(undefined4 *)(puVar31 + 1) = uVar26;
                    *(undefined4 *)(puVar31 + 5) = uVar27;
                    *(undefined4 *)(puVar31 + 9) = uVar28;
                    *(undefined4 *)(puVar31 + 0xd) = uVar29;
                    cVar4 = *(char *)(iVar45 + (int64_t)puVar1);
                    puVar31 = (undefined *)((int64_t)puVar1 + iVar45 + 1);
                    while (cVar4 == '0') {
                        cVar4 = puVar31[-2];
                        puVar31 = puVar31 + -1;
                    }
                } else {
                    *(undefined *)(puVar1 + 4) = *(undefined *)(piVar43 + 2);
                    *(undefined8 *)(iVar45 + (int64_t)puVar1) = 0x3030303030303030;
                }
            }
        }
    } else {
        uVar26 = *(undefined4 *)((int64_t)piVar43 + 1);
        uVar27 = *(undefined4 *)((int64_t)piVar43 + 5);
        uVar28 = *(undefined4 *)((int64_t)piVar43 + 9);
        uVar29 = *(undefined4 *)((int64_t)piVar43 + 0xd);
        *(undefined *)puVar1 = *(undefined *)piVar43;
        *(undefined *)((int64_t)puVar1 + 1) = 0x2e;
        *(undefined4 *)((int64_t)puVar1 + 2) = uVar26;
        *(undefined4 *)((int64_t)puVar1 + 6) = uVar27;
        *(undefined4 *)((int64_t)puVar1 + 10) = uVar28;
        *(undefined4 *)((int64_t)puVar1 + 0xe) = uVar29;
        cVar4 = *(char *)((int64_t)iVar36 + (int64_t)puVar1);
        puVar31 = (undefined *)((int64_t)puVar1 + (int64_t)iVar36 + 1);
        while (cVar4 == '0') {
            cVar4 = puVar31[-2];
            puVar31 = puVar31 + -1;
        }
        puVar37 = puVar31 + -1;
        if (puVar31[-1] != '.') {
            puVar37 = puVar31;
        }
        iVar48 = iVar48 + -1;
        uVar34 = 0x2b;
        if (iVar48 < 0) {
            uVar34 = 0x2d;
        }
        puVar37[1] = uVar34;
        puVar44 = (undefined2 *)(puVar37 + 2);
        *puVar37 = 0x65;
        iVar36 = -iVar48;
        if (0 < iVar48) {
            iVar36 = iVar48;
        }
        if (99 < iVar36) {
            *(char *)puVar44 = (char)(iVar36 / 100) + '0';
            puVar44 = (undefined2 *)(puVar37 + 3);
            iVar36 = iVar36 % 100;
        }
        *puVar44 = *(undefined2 *)((int64_t)(iVar36 * 2) + 0x180612590);
    }
code_r0x000180099054:
    fcn.180459870(var_48h ^ (uint64_t)&var_78h);
    return;
}

