// Chunk 20 - 50 functions

// ============================================================
// Function: FUN_180036a21
// Address: 0x180036a21
// Size: 31 bytes
// ============================================================
void fcn.180036a21(int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t unaff_ESI;
    int64_t unaff_RDI;
    int64_t unaff_R14;
    
    iVar1 = func_0x000180085f50();
    iVar2 = func_0x000180033c60();
    if (iVar1 != iVar2) {
        func_0x0001800865e0();
        func_0x000180085a50();
    }
    if ((unaff_R14 != unaff_RDI) && (unaff_ESI == 0)) {
        func_0x000180085610();
        func_0x000180051290();
        func_0x0001800859a0();
    }
    // WARNING: Could not recover jumptable at 0x000180036b1c. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782100)();
    return;
}

// ============================================================
// Function: FUN_180036a40
// Address: 0x180036a40
// Size: 239 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_48h

void fcn.180036a21(int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t unaff_ESI;
    int64_t unaff_RDI;
    int64_t unaff_R14;
    
    iVar1 = func_0x000180085f50();
    iVar2 = func_0x000180033c60();
    if (iVar1 != iVar2) {
        func_0x0001800865e0();
        func_0x000180085a50();
    }
    if ((unaff_R14 != unaff_RDI) && (unaff_ESI == 0)) {
        func_0x000180085610();
        func_0x000180051290();
        func_0x0001800859a0();
    }
    // WARNING: Could not recover jumptable at 0x000180036b1c. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782100)();
    return;
}

// ============================================================
// Function: FUN_180036b30
// Address: 0x180036b30
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180036b30(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_3e8 [32];
    int64_t var_3c8h;
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_174h;
    undefined uStack_39;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3e8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar10;
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        iVar9 = 0;
        var_3c8h = 0;
        cVar2 = func_0x000180051370(arg1, &var_3c8h);
        uVar12 = 1;
        iVar14 = arg1;
        if (cVar2 != '\0') {
            iVar14 = var_3c8h;
        }
        uVar15 = 2;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        iVar14 = 0;
        if (*(int32_t *)((int64_t)piVar10 + 0xc) == 10) {
            iVar14 = *piVar10;
        }
        uVar12 = 2;
        iVar9 = 0x10;
        uVar15 = 3;
    }
    piVar8 = (int64_t *)0x0;
    piVar10 = (int64_t *)(iVar9 + *(int64_t *)(arg1 + 0x28));
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar10 = *(int64_t **)0x180782430;
    }
    piVar5 = piVar8;
    if (((piVar10 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar10 + 0xc))) &&
       (piVar5 = (int64_t *)func_0x0001800860c0(arg1, uVar12, 0), piVar5 == (int64_t *)0x0)) {
        func_0x000180088470(arg1, uVar12, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = func_0x0001800889f0(arg1, uVar15, arg1 == iVar14);
    if (iVar3 < 0) {
        func_0x000180088380(arg1, uVar15, 0x180622770);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    var_3b0h = (int64_t)&var_198h;
    var_3a0h = 0;
    var_3b8h = (int64_t)&var_398h;
    var_3a8h = arg1;
    if (piVar5 != (int64_t *)0x0) {
        uVar6 = func_0x000180498cd0(piVar5);
        piVar10 = &var_398h;
        if (0x200 < uVar6) {
            func_0x0001800890e0(&var_3b8h, uVar6 - 0x200, 0xffffffff);
            piVar10 = (int64_t *)var_3b8h;
        }
        func_0x000180498030(piVar10, piVar5, uVar6);
        var_3b8h = var_3b8h + uVar6;
        if (var_3b0h == var_3b8h) {
            func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
        }
        *(undefined *)var_3b8h = 10;
        var_3b8h = var_3b8h + 1;
    }
    iVar4 = func_0x000180092a10(iVar14, iVar3, 0x180622768, &var_198h);
    do {
        if (iVar4 == 0) {
            func_0x0001800892d0(&var_3b8h);
            func_0x000180459870(var_38h ^ (uint64_t)auStack_3e8);
            return;
        }
        piVar10 = (int64_t *)(*(int64_t *)(iVar14 + 0x40) - 0x10);
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar14 + 0x40) + -4) != 8)) {
            *(int64_t **)(iVar14 + 0x40) = piVar10;
code_r0x000180036d5d:
            iVar9 = var_180h;
            if ((*(char *)var_190h != 'C') || (*(char *)(var_190h + 1) != '\0')) {
                if (var_188h != 0) {
                    uVar6 = func_0x000180498cd0(var_180h);
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, (uVar6 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    func_0x000180498030(var_3b8h, iVar9, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (0 < (int32_t)(uint32_t)var_174h) {
                    piVar10 = &var_38h;
                    uVar7 = (uint32_t)var_174h;
                    do {
                        piVar10 = (int64_t *)((int64_t)piVar10 + -1);
                        uVar13 = uVar7 / 10;
                        *(char *)piVar10 = (char)uVar7 + (char)uVar13 * -10 + '0';
                        uVar7 = uVar13;
                    } while (uVar13 != 0);
                    if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_3b8h = 0x3a;
                    uVar6 = (int64_t)&var_38h - (int64_t)piVar10;
                    var_3b8h = var_3b8h + 1;
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, (uVar6 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    func_0x000180498030(var_3b8h, piVar10, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (var_198h != 0) {
                    if ((uint64_t)(var_3b0h - var_3b8h) < 10) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 10, 0xffffffff);
                    }
                    iVar9 = var_198h;
                    *(undefined8 *)var_3b8h = 0x6f6974636e756620;
                    *(undefined2 *)(var_3b8h + 8) = 0x206e;
                    iVar11 = var_3b8h + 10;
                    var_3b8h = iVar11;
                    uVar6 = func_0x000180498cd0(var_198h);
                    if ((uint64_t)(var_3b0h - iVar11) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, uVar6 + (iVar11 - var_3b0h), 0xffffffff);
                        iVar11 = var_3b8h;
                    }
                    func_0x000180498030(iVar11, iVar9, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                    func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                }
                *(undefined *)var_3b8h = 10;
                var_3b8h = var_3b8h + 1;
            }
        } else {
            piVar5 = piVar10;
            if (piVar10 == *(int64_t **)0x180782430) {
                piVar5 = piVar8;
            }
            var_3c8h = *piVar5;
            *(int64_t **)(iVar14 + 0x40) = piVar10;
            if ((var_3c8h == 0) || (cVar2 = func_0x000180028f00(piVar10, &var_3c8h), cVar2 == '\0'))
            goto code_r0x000180036d5d;
        }
        iVar3 = iVar3 + 1;
        iVar4 = func_0x000180092a10(iVar14, iVar3, 0x180622768, &var_198h);
    } while( true );
}

// ============================================================
// Function: FUN_180036c21
// Address: 0x180036c21
// Size: 1023 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180036b30(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_3e8 [32];
    int64_t var_3c8h;
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_174h;
    undefined uStack_39;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3e8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar10;
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        iVar9 = 0;
        var_3c8h = 0;
        cVar2 = func_0x000180051370(arg1, &var_3c8h);
        uVar12 = 1;
        iVar14 = arg1;
        if (cVar2 != '\0') {
            iVar14 = var_3c8h;
        }
        uVar15 = 2;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        iVar14 = 0;
        if (*(int32_t *)((int64_t)piVar10 + 0xc) == 10) {
            iVar14 = *piVar10;
        }
        uVar12 = 2;
        iVar9 = 0x10;
        uVar15 = 3;
    }
    piVar8 = (int64_t *)0x0;
    piVar10 = (int64_t *)(iVar9 + *(int64_t *)(arg1 + 0x28));
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar10 = *(int64_t **)0x180782430;
    }
    piVar5 = piVar8;
    if (((piVar10 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar10 + 0xc))) &&
       (piVar5 = (int64_t *)func_0x0001800860c0(arg1, uVar12, 0), piVar5 == (int64_t *)0x0)) {
        func_0x000180088470(arg1, uVar12, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = func_0x0001800889f0(arg1, uVar15, arg1 == iVar14);
    if (iVar3 < 0) {
        func_0x000180088380(arg1, uVar15, 0x180622770);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    var_3b0h = (int64_t)&var_198h;
    var_3a0h = 0;
    var_3b8h = (int64_t)&var_398h;
    var_3a8h = arg1;
    if (piVar5 != (int64_t *)0x0) {
        uVar6 = func_0x000180498cd0(piVar5);
        piVar10 = &var_398h;
        if (0x200 < uVar6) {
            func_0x0001800890e0(&var_3b8h, uVar6 - 0x200, 0xffffffff);
            piVar10 = (int64_t *)var_3b8h;
        }
        func_0x000180498030(piVar10, piVar5, uVar6);
        var_3b8h = var_3b8h + uVar6;
        if (var_3b0h == var_3b8h) {
            func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
        }
        *(undefined *)var_3b8h = 10;
        var_3b8h = var_3b8h + 1;
    }
    iVar4 = func_0x000180092a10(iVar14, iVar3, 0x180622768, &var_198h);
    do {
        if (iVar4 == 0) {
            func_0x0001800892d0(&var_3b8h);
            func_0x000180459870(var_38h ^ (uint64_t)auStack_3e8);
            return;
        }
        piVar10 = (int64_t *)(*(int64_t *)(iVar14 + 0x40) - 0x10);
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar14 + 0x40) + -4) != 8)) {
            *(int64_t **)(iVar14 + 0x40) = piVar10;
code_r0x000180036d5d:
            iVar9 = var_180h;
            if ((*(char *)var_190h != 'C') || (*(char *)(var_190h + 1) != '\0')) {
                if (var_188h != 0) {
                    uVar6 = func_0x000180498cd0(var_180h);
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, (uVar6 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    func_0x000180498030(var_3b8h, iVar9, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (0 < (int32_t)(uint32_t)var_174h) {
                    piVar10 = &var_38h;
                    uVar7 = (uint32_t)var_174h;
                    do {
                        piVar10 = (int64_t *)((int64_t)piVar10 + -1);
                        uVar13 = uVar7 / 10;
                        *(char *)piVar10 = (char)uVar7 + (char)uVar13 * -10 + '0';
                        uVar7 = uVar13;
                    } while (uVar13 != 0);
                    if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_3b8h = 0x3a;
                    uVar6 = (int64_t)&var_38h - (int64_t)piVar10;
                    var_3b8h = var_3b8h + 1;
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, (uVar6 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    func_0x000180498030(var_3b8h, piVar10, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (var_198h != 0) {
                    if ((uint64_t)(var_3b0h - var_3b8h) < 10) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 10, 0xffffffff);
                    }
                    iVar9 = var_198h;
                    *(undefined8 *)var_3b8h = 0x6f6974636e756620;
                    *(undefined2 *)(var_3b8h + 8) = 0x206e;
                    iVar11 = var_3b8h + 10;
                    var_3b8h = iVar11;
                    uVar6 = func_0x000180498cd0(var_198h);
                    if ((uint64_t)(var_3b0h - iVar11) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, uVar6 + (iVar11 - var_3b0h), 0xffffffff);
                        iVar11 = var_3b8h;
                    }
                    func_0x000180498030(iVar11, iVar9, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                    func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                }
                *(undefined *)var_3b8h = 10;
                var_3b8h = var_3b8h + 1;
            }
        } else {
            piVar5 = piVar10;
            if (piVar10 == *(int64_t **)0x180782430) {
                piVar5 = piVar8;
            }
            var_3c8h = *piVar5;
            *(int64_t **)(iVar14 + 0x40) = piVar10;
            if ((var_3c8h == 0) || (cVar2 = func_0x000180028f00(piVar10, &var_3c8h), cVar2 == '\0'))
            goto code_r0x000180036d5d;
        }
        iVar3 = iVar3 + 1;
        iVar4 = func_0x000180092a10(iVar14, iVar3, 0x180622768, &var_198h);
    } while( true );
}

// ============================================================
// Function: FUN_180037020
// Address: 0x180037020
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180036b30(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_3e8 [32];
    int64_t var_3c8h;
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_174h;
    undefined uStack_39;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3e8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar10;
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        iVar9 = 0;
        var_3c8h = 0;
        cVar2 = func_0x000180051370(arg1, &var_3c8h);
        uVar12 = 1;
        iVar14 = arg1;
        if (cVar2 != '\0') {
            iVar14 = var_3c8h;
        }
        uVar15 = 2;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        iVar14 = 0;
        if (*(int32_t *)((int64_t)piVar10 + 0xc) == 10) {
            iVar14 = *piVar10;
        }
        uVar12 = 2;
        iVar9 = 0x10;
        uVar15 = 3;
    }
    piVar8 = (int64_t *)0x0;
    piVar10 = (int64_t *)(iVar9 + *(int64_t *)(arg1 + 0x28));
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar10 = *(int64_t **)0x180782430;
    }
    piVar5 = piVar8;
    if (((piVar10 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar10 + 0xc))) &&
       (piVar5 = (int64_t *)func_0x0001800860c0(arg1, uVar12, 0), piVar5 == (int64_t *)0x0)) {
        func_0x000180088470(arg1, uVar12, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = func_0x0001800889f0(arg1, uVar15, arg1 == iVar14);
    if (iVar3 < 0) {
        func_0x000180088380(arg1, uVar15, 0x180622770);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    var_3b0h = (int64_t)&var_198h;
    var_3a0h = 0;
    var_3b8h = (int64_t)&var_398h;
    var_3a8h = arg1;
    if (piVar5 != (int64_t *)0x0) {
        uVar6 = func_0x000180498cd0(piVar5);
        piVar10 = &var_398h;
        if (0x200 < uVar6) {
            func_0x0001800890e0(&var_3b8h, uVar6 - 0x200, 0xffffffff);
            piVar10 = (int64_t *)var_3b8h;
        }
        func_0x000180498030(piVar10, piVar5, uVar6);
        var_3b8h = var_3b8h + uVar6;
        if (var_3b0h == var_3b8h) {
            func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
        }
        *(undefined *)var_3b8h = 10;
        var_3b8h = var_3b8h + 1;
    }
    iVar4 = func_0x000180092a10(iVar14, iVar3, 0x180622768, &var_198h);
    do {
        if (iVar4 == 0) {
            func_0x0001800892d0(&var_3b8h);
            func_0x000180459870(var_38h ^ (uint64_t)auStack_3e8);
            return;
        }
        piVar10 = (int64_t *)(*(int64_t *)(iVar14 + 0x40) - 0x10);
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar14 + 0x40) + -4) != 8)) {
            *(int64_t **)(iVar14 + 0x40) = piVar10;
code_r0x000180036d5d:
            iVar9 = var_180h;
            if ((*(char *)var_190h != 'C') || (*(char *)(var_190h + 1) != '\0')) {
                if (var_188h != 0) {
                    uVar6 = func_0x000180498cd0(var_180h);
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, (uVar6 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    func_0x000180498030(var_3b8h, iVar9, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (0 < (int32_t)(uint32_t)var_174h) {
                    piVar10 = &var_38h;
                    uVar7 = (uint32_t)var_174h;
                    do {
                        piVar10 = (int64_t *)((int64_t)piVar10 + -1);
                        uVar13 = uVar7 / 10;
                        *(char *)piVar10 = (char)uVar7 + (char)uVar13 * -10 + '0';
                        uVar7 = uVar13;
                    } while (uVar13 != 0);
                    if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_3b8h = 0x3a;
                    uVar6 = (int64_t)&var_38h - (int64_t)piVar10;
                    var_3b8h = var_3b8h + 1;
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, (uVar6 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    func_0x000180498030(var_3b8h, piVar10, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (var_198h != 0) {
                    if ((uint64_t)(var_3b0h - var_3b8h) < 10) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 10, 0xffffffff);
                    }
                    iVar9 = var_198h;
                    *(undefined8 *)var_3b8h = 0x6f6974636e756620;
                    *(undefined2 *)(var_3b8h + 8) = 0x206e;
                    iVar11 = var_3b8h + 10;
                    var_3b8h = iVar11;
                    uVar6 = func_0x000180498cd0(var_198h);
                    if ((uint64_t)(var_3b0h - iVar11) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, uVar6 + (iVar11 - var_3b0h), 0xffffffff);
                        iVar11 = var_3b8h;
                    }
                    func_0x000180498030(iVar11, iVar9, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                    func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                }
                *(undefined *)var_3b8h = 10;
                var_3b8h = var_3b8h + 1;
            }
        } else {
            piVar5 = piVar10;
            if (piVar10 == *(int64_t **)0x180782430) {
                piVar5 = piVar8;
            }
            var_3c8h = *piVar5;
            *(int64_t **)(iVar14 + 0x40) = piVar10;
            if ((var_3c8h == 0) || (cVar2 = func_0x000180028f00(piVar10, &var_3c8h), cVar2 == '\0'))
            goto code_r0x000180036d5d;
        }
        iVar3 = iVar3 + 1;
        iVar4 = func_0x000180092a10(iVar14, iVar3, 0x180622768, &var_198h);
    } while( true );
}

// ============================================================
// Function: FUN_180037033
// Address: 0x180037033
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180036b30(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    undefined8 uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_3e8 [32];
    int64_t var_3c8h;
    int64_t var_3b8h;
    int64_t var_3b0h;
    int64_t var_3a8h;
    int64_t var_3a0h;
    int64_t var_398h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_174h;
    undefined uStack_39;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_3e8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar10;
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        iVar9 = 0;
        var_3c8h = 0;
        cVar2 = func_0x000180051370(arg1, &var_3c8h);
        uVar12 = 1;
        iVar14 = arg1;
        if (cVar2 != '\0') {
            iVar14 = var_3c8h;
        }
        uVar15 = 2;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        iVar14 = 0;
        if (*(int32_t *)((int64_t)piVar10 + 0xc) == 10) {
            iVar14 = *piVar10;
        }
        uVar12 = 2;
        iVar9 = 0x10;
        uVar15 = 3;
    }
    piVar8 = (int64_t *)0x0;
    piVar10 = (int64_t *)(iVar9 + *(int64_t *)(arg1 + 0x28));
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar10 = *(int64_t **)0x180782430;
    }
    piVar5 = piVar8;
    if (((piVar10 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar10 + 0xc))) &&
       (piVar5 = (int64_t *)func_0x0001800860c0(arg1, uVar12, 0), piVar5 == (int64_t *)0x0)) {
        func_0x000180088470(arg1, uVar12, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = func_0x0001800889f0(arg1, uVar15, arg1 == iVar14);
    if (iVar3 < 0) {
        func_0x000180088380(arg1, uVar15, 0x180622770);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    var_3b0h = (int64_t)&var_198h;
    var_3a0h = 0;
    var_3b8h = (int64_t)&var_398h;
    var_3a8h = arg1;
    if (piVar5 != (int64_t *)0x0) {
        uVar6 = func_0x000180498cd0(piVar5);
        piVar10 = &var_398h;
        if (0x200 < uVar6) {
            func_0x0001800890e0(&var_3b8h, uVar6 - 0x200, 0xffffffff);
            piVar10 = (int64_t *)var_3b8h;
        }
        func_0x000180498030(piVar10, piVar5, uVar6);
        var_3b8h = var_3b8h + uVar6;
        if (var_3b0h == var_3b8h) {
            func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
        }
        *(undefined *)var_3b8h = 10;
        var_3b8h = var_3b8h + 1;
    }
    iVar4 = func_0x000180092a10(iVar14, iVar3, 0x180622768, &var_198h);
    do {
        if (iVar4 == 0) {
            func_0x0001800892d0(&var_3b8h);
            func_0x000180459870(var_38h ^ (uint64_t)auStack_3e8);
            return;
        }
        piVar10 = (int64_t *)(*(int64_t *)(iVar14 + 0x40) - 0x10);
        if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar14 + 0x40) + -4) != 8)) {
            *(int64_t **)(iVar14 + 0x40) = piVar10;
code_r0x000180036d5d:
            iVar9 = var_180h;
            if ((*(char *)var_190h != 'C') || (*(char *)(var_190h + 1) != '\0')) {
                if (var_188h != 0) {
                    uVar6 = func_0x000180498cd0(var_180h);
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, (uVar6 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    func_0x000180498030(var_3b8h, iVar9, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (0 < (int32_t)(uint32_t)var_174h) {
                    piVar10 = &var_38h;
                    uVar7 = (uint32_t)var_174h;
                    do {
                        piVar10 = (int64_t *)((int64_t)piVar10 + -1);
                        uVar13 = uVar7 / 10;
                        *(char *)piVar10 = (char)uVar7 + (char)uVar13 * -10 + '0';
                        uVar7 = uVar13;
                    } while (uVar13 != 0);
                    if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_3b8h = 0x3a;
                    uVar6 = (int64_t)&var_38h - (int64_t)piVar10;
                    var_3b8h = var_3b8h + 1;
                    if ((uint64_t)(var_3b0h - var_3b8h) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, (uVar6 - var_3b0h) + var_3b8h, 0xffffffff);
                    }
                    func_0x000180498030(var_3b8h, piVar10, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (var_198h != 0) {
                    if ((uint64_t)(var_3b0h - var_3b8h) < 10) {
                        func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 10, 0xffffffff);
                    }
                    iVar9 = var_198h;
                    *(undefined8 *)var_3b8h = 0x6f6974636e756620;
                    *(undefined2 *)(var_3b8h + 8) = 0x206e;
                    iVar11 = var_3b8h + 10;
                    var_3b8h = iVar11;
                    uVar6 = func_0x000180498cd0(var_198h);
                    if ((uint64_t)(var_3b0h - iVar11) < uVar6) {
                        func_0x0001800890e0(&var_3b8h, uVar6 + (iVar11 - var_3b0h), 0xffffffff);
                        iVar11 = var_3b8h;
                    }
                    func_0x000180498030(iVar11, iVar9, uVar6);
                    var_3b8h = var_3b8h + uVar6;
                }
                if (((uint64_t)var_3b0h <= (uint64_t)var_3b8h) && (var_3b0h == var_3b8h)) {
                    func_0x0001800890e0(&var_3b8h, (var_3b8h - var_3b0h) + 1, 0xffffffff);
                }
                *(undefined *)var_3b8h = 10;
                var_3b8h = var_3b8h + 1;
            }
        } else {
            piVar5 = piVar10;
            if (piVar10 == *(int64_t **)0x180782430) {
                piVar5 = piVar8;
            }
            var_3c8h = *piVar5;
            *(int64_t **)(iVar14 + 0x40) = piVar10;
            if ((var_3c8h == 0) || (cVar2 = func_0x000180028f00(piVar10, &var_3c8h), cVar2 == '\0'))
            goto code_r0x000180036d5d;
        }
        iVar3 = iVar3 + 1;
        iVar4 = func_0x000180092a10(iVar14, iVar3, 0x180622768, &var_198h);
    } while( true );
}

// ============================================================
// Function: FUN_180037050
// Address: 0x180037050
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037050(int64_t arg1, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    char cVar4;
    int32_t iVar5;
    uint32_t uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if (((puVar7 != *(undefined4 **)0x180782430) &&
        (((puVar7[3] == 6 || (puVar7[3] == 3)) && (iVar5 = func_0x000180085d50(arg1, 2), iVar5 != 0)))) &&
       (uVar6 = func_0x000180085f50(arg1, 2, 0), 0 < (int32_t)uVar6)) {
        var_8h = 0;
        cVar4 = func_0x000180051370(arg1, &var_8h);
        iVar8 = arg1;
        if (cVar4 != '\0') {
            iVar8 = var_8h;
        }
        iVar5 = 0;
        uVar12 = 0;
        uVar13 = *(uint64_t *)(iVar8 + 0x78);
        uVar10 = *(int64_t *)(iVar8 + 0x18) - 0x28;
        uVar14 = extraout_XMM0_Da;
        if (uVar13 <= uVar10) {
            do {
                if (*(int32_t *)((int64_t)*(int64_t **)(uVar10 + 8) + 0xc) == 8) {
                    var_8h = **(int64_t **)(uVar10 + 8);
                    iVar5 = iVar5 + 1;
                    cVar4 = func_0x000180028f00(uVar14, &var_8h);
                    uVar14 = extraout_XMM0_Da_00;
                    if ((cVar4 == '\0') && (uVar11 = (int32_t)uVar12 + 1, uVar12 = (uint64_t)uVar11, uVar11 == uVar6)) {
                        func_0x000180085bf0(arg1, 1);
                        func_0x0001800865e0(arg1, iVar5);
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar3 = *(undefined4 **)0x180782430;
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        if (puVar7 <= puVar9) {
                            puVar9 = *(undefined4 **)0x180782430;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        puVar9 = *(undefined4 **)(arg1 + 0x28);
                        if (puVar7 <= *(undefined4 **)(arg1 + 0x28)) {
                            puVar9 = puVar3;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        break;
                    }
                }
                uVar10 = uVar10 - 0x28;
            } while (uVar13 <= uVar10);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001800371e3. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782110)(arg1);
    return;
}

// ============================================================
// Function: FUN_18003709f
// Address: 0x18003709f
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037050(int64_t arg1, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    char cVar4;
    int32_t iVar5;
    uint32_t uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if (((puVar7 != *(undefined4 **)0x180782430) &&
        (((puVar7[3] == 6 || (puVar7[3] == 3)) && (iVar5 = func_0x000180085d50(arg1, 2), iVar5 != 0)))) &&
       (uVar6 = func_0x000180085f50(arg1, 2, 0), 0 < (int32_t)uVar6)) {
        var_8h = 0;
        cVar4 = func_0x000180051370(arg1, &var_8h);
        iVar8 = arg1;
        if (cVar4 != '\0') {
            iVar8 = var_8h;
        }
        iVar5 = 0;
        uVar12 = 0;
        uVar13 = *(uint64_t *)(iVar8 + 0x78);
        uVar10 = *(int64_t *)(iVar8 + 0x18) - 0x28;
        uVar14 = extraout_XMM0_Da;
        if (uVar13 <= uVar10) {
            do {
                if (*(int32_t *)((int64_t)*(int64_t **)(uVar10 + 8) + 0xc) == 8) {
                    var_8h = **(int64_t **)(uVar10 + 8);
                    iVar5 = iVar5 + 1;
                    cVar4 = func_0x000180028f00(uVar14, &var_8h);
                    uVar14 = extraout_XMM0_Da_00;
                    if ((cVar4 == '\0') && (uVar11 = (int32_t)uVar12 + 1, uVar12 = (uint64_t)uVar11, uVar11 == uVar6)) {
                        func_0x000180085bf0(arg1, 1);
                        func_0x0001800865e0(arg1, iVar5);
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar3 = *(undefined4 **)0x180782430;
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        if (puVar7 <= puVar9) {
                            puVar9 = *(undefined4 **)0x180782430;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        puVar9 = *(undefined4 **)(arg1 + 0x28);
                        if (puVar7 <= *(undefined4 **)(arg1 + 0x28)) {
                            puVar9 = puVar3;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        break;
                    }
                }
                uVar10 = uVar10 - 0x28;
            } while (uVar13 <= uVar10);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001800371e3. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782110)(arg1);
    return;
}

// ============================================================
// Function: FUN_1800370c0
// Address: 0x1800370c0
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037050(int64_t arg1, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    char cVar4;
    int32_t iVar5;
    uint32_t uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if (((puVar7 != *(undefined4 **)0x180782430) &&
        (((puVar7[3] == 6 || (puVar7[3] == 3)) && (iVar5 = func_0x000180085d50(arg1, 2), iVar5 != 0)))) &&
       (uVar6 = func_0x000180085f50(arg1, 2, 0), 0 < (int32_t)uVar6)) {
        var_8h = 0;
        cVar4 = func_0x000180051370(arg1, &var_8h);
        iVar8 = arg1;
        if (cVar4 != '\0') {
            iVar8 = var_8h;
        }
        iVar5 = 0;
        uVar12 = 0;
        uVar13 = *(uint64_t *)(iVar8 + 0x78);
        uVar10 = *(int64_t *)(iVar8 + 0x18) - 0x28;
        uVar14 = extraout_XMM0_Da;
        if (uVar13 <= uVar10) {
            do {
                if (*(int32_t *)((int64_t)*(int64_t **)(uVar10 + 8) + 0xc) == 8) {
                    var_8h = **(int64_t **)(uVar10 + 8);
                    iVar5 = iVar5 + 1;
                    cVar4 = func_0x000180028f00(uVar14, &var_8h);
                    uVar14 = extraout_XMM0_Da_00;
                    if ((cVar4 == '\0') && (uVar11 = (int32_t)uVar12 + 1, uVar12 = (uint64_t)uVar11, uVar11 == uVar6)) {
                        func_0x000180085bf0(arg1, 1);
                        func_0x0001800865e0(arg1, iVar5);
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar3 = *(undefined4 **)0x180782430;
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        if (puVar7 <= puVar9) {
                            puVar9 = *(undefined4 **)0x180782430;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        puVar9 = *(undefined4 **)(arg1 + 0x28);
                        if (puVar7 <= *(undefined4 **)(arg1 + 0x28)) {
                            puVar9 = puVar3;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        break;
                    }
                }
                uVar10 = uVar10 - 0x28;
            } while (uVar13 <= uVar10);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001800371e3. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782110)(arg1);
    return;
}

// ============================================================
// Function: FUN_1800371cf
// Address: 0x1800371cf
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037050(int64_t arg1, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    char cVar4;
    int32_t iVar5;
    uint32_t uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if (((puVar7 != *(undefined4 **)0x180782430) &&
        (((puVar7[3] == 6 || (puVar7[3] == 3)) && (iVar5 = func_0x000180085d50(arg1, 2), iVar5 != 0)))) &&
       (uVar6 = func_0x000180085f50(arg1, 2, 0), 0 < (int32_t)uVar6)) {
        var_8h = 0;
        cVar4 = func_0x000180051370(arg1, &var_8h);
        iVar8 = arg1;
        if (cVar4 != '\0') {
            iVar8 = var_8h;
        }
        iVar5 = 0;
        uVar12 = 0;
        uVar13 = *(uint64_t *)(iVar8 + 0x78);
        uVar10 = *(int64_t *)(iVar8 + 0x18) - 0x28;
        uVar14 = extraout_XMM0_Da;
        if (uVar13 <= uVar10) {
            do {
                if (*(int32_t *)((int64_t)*(int64_t **)(uVar10 + 8) + 0xc) == 8) {
                    var_8h = **(int64_t **)(uVar10 + 8);
                    iVar5 = iVar5 + 1;
                    cVar4 = func_0x000180028f00(uVar14, &var_8h);
                    uVar14 = extraout_XMM0_Da_00;
                    if ((cVar4 == '\0') && (uVar11 = (int32_t)uVar12 + 1, uVar12 = (uint64_t)uVar11, uVar11 == uVar6)) {
                        func_0x000180085bf0(arg1, 1);
                        func_0x0001800865e0(arg1, iVar5);
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar3 = *(undefined4 **)0x180782430;
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        if (puVar7 <= puVar9) {
                            puVar9 = *(undefined4 **)0x180782430;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        puVar9 = *(undefined4 **)(arg1 + 0x28);
                        if (puVar7 <= *(undefined4 **)(arg1 + 0x28)) {
                            puVar9 = puVar3;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        break;
                    }
                }
                uVar10 = uVar10 - 0x28;
            } while (uVar13 <= uVar10);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001800371e3. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782110)(arg1);
    return;
}

// ============================================================
// Function: FUN_1800371d4
// Address: 0x1800371d4
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037050(int64_t arg1, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    char cVar4;
    int32_t iVar5;
    uint32_t uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar7 = *(undefined4 **)(arg1 + 0x28);
    if (*(undefined4 **)(arg1 + 0x40) <= *(undefined4 **)(arg1 + 0x28)) {
        puVar7 = *(undefined4 **)0x180782430;
    }
    if (((puVar7 != *(undefined4 **)0x180782430) &&
        (((puVar7[3] == 6 || (puVar7[3] == 3)) && (iVar5 = func_0x000180085d50(arg1, 2), iVar5 != 0)))) &&
       (uVar6 = func_0x000180085f50(arg1, 2, 0), 0 < (int32_t)uVar6)) {
        var_8h = 0;
        cVar4 = func_0x000180051370(arg1, &var_8h);
        iVar8 = arg1;
        if (cVar4 != '\0') {
            iVar8 = var_8h;
        }
        iVar5 = 0;
        uVar12 = 0;
        uVar13 = *(uint64_t *)(iVar8 + 0x78);
        uVar10 = *(int64_t *)(iVar8 + 0x18) - 0x28;
        uVar14 = extraout_XMM0_Da;
        if (uVar13 <= uVar10) {
            do {
                if (*(int32_t *)((int64_t)*(int64_t **)(uVar10 + 8) + 0xc) == 8) {
                    var_8h = **(int64_t **)(uVar10 + 8);
                    iVar5 = iVar5 + 1;
                    cVar4 = func_0x000180028f00(uVar14, &var_8h);
                    uVar14 = extraout_XMM0_Da_00;
                    if ((cVar4 == '\0') && (uVar11 = (int32_t)uVar12 + 1, uVar12 = (uint64_t)uVar11, uVar11 == uVar6)) {
                        func_0x000180085bf0(arg1, 1);
                        func_0x0001800865e0(arg1, iVar5);
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar3 = *(undefined4 **)0x180782430;
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        puVar9 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        if (puVar7 <= puVar9) {
                            puVar9 = *(undefined4 **)0x180782430;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar7 = *(undefined4 **)(arg1 + 0x40);
                        uVar14 = puVar7[-3];
                        uVar1 = puVar7[-2];
                        uVar2 = puVar7[-1];
                        puVar9 = *(undefined4 **)(arg1 + 0x28);
                        if (puVar7 <= *(undefined4 **)(arg1 + 0x28)) {
                            puVar9 = puVar3;
                        }
                        *puVar9 = puVar7[-4];
                        puVar9[1] = uVar14;
                        puVar9[2] = uVar1;
                        puVar9[3] = uVar2;
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        break;
                    }
                }
                uVar10 = uVar10 - 0x28;
            } while (uVar13 <= uVar10);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001800371e3. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782110)(arg1);
    return;
}

// ============================================================
// Function: FUN_1800371f0
// Address: 0x1800371f0
// Size: 561 bytes
// ============================================================
void fcn.1800371f0(int64_t arg1)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 *puVar10;
    undefined4 *puVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int64_t *piVar15;
    int64_t var_8h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if (((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) &&
       (iVar6 = func_0x000180085d50(arg1, 1), iVar6 != 0)) {
        var_8h = 0;
        cVar5 = func_0x000180051370(arg1, &var_8h);
        iVar14 = arg1;
        if (cVar5 != '\0') {
            iVar14 = var_8h;
        }
        iVar6 = func_0x000180085f50(arg1, 1, 0);
        iVar7 = func_0x000180033c60(iVar14, iVar6);
        if (iVar6 == iVar7) goto code_r0x0001800373e4;
        func_0x0001800865e0(arg1, iVar7);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        piVar12 = *(int64_t **)(arg1 + 0x40);
        piVar13 = *(int64_t **)(arg1 + 0x28);
        if (piVar12 <= *(int64_t **)(arg1 + 0x28)) {
            piVar13 = *(int64_t **)0x180782430;
        }
    } else {
        piVar15 = *(int64_t **)0x180782430;
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar12;
        if (piVar13 <= piVar12) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) != 9) && (*(int32_t *)((int64_t)piVar8 + 0xc) != 2))
        goto code_r0x0001800373e4;
        piVar8 = piVar12;
        if (piVar13 <= piVar12) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) != 9) || (*(char *)(*piVar8 + 3) != 'x')) goto code_r0x0001800373e4;
        if (piVar13 <= piVar12) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
            puVar9 = (undefined4 *)(*piVar12 + 0x10);
        } else {
            puVar9 = (undefined4 *)0x0;
        }
        uVar1 = *puVar9;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = func_0x000180085510(arg1, 1), piVar15 = *(int64_t **)0x180782430, iVar6 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar10 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar11 = (undefined4 *)func_0x0001800a0d50(*puVar10, uVar1);
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        uVar1 = puVar11[1];
        uVar3 = puVar11[2];
        uVar4 = puVar11[3];
        *puVar9 = *puVar11;
        puVar9[1] = uVar1;
        puVar9[2] = uVar3;
        puVar9[3] = uVar4;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8) {
            func_0x000180088560(arg1, 0x1806224c8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        piVar12 = *(int64_t **)(arg1 + 0x40);
        piVar13 = *(int64_t **)(arg1 + 0x28);
        if (piVar12 <= *(int64_t **)(arg1 + 0x28)) {
            piVar13 = piVar15;
        }
    }
    uVar1 = *(undefined4 *)((int64_t)piVar12 - 0xc);
    uVar3 = *(undefined4 *)(piVar12 + -1);
    uVar4 = *(undefined4 *)((int64_t)piVar12 - 4);
    *(undefined4 *)piVar13 = *(undefined4 *)(piVar12 + -2);
    *(undefined4 *)((int64_t)piVar13 + 4) = uVar1;
    *(undefined4 *)(piVar13 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
code_r0x0001800373e4:
    // WARNING: Could not recover jumptable at 0x0001800373f6. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782108)(arg1);
    return;
}

// ============================================================
// Function: FUN_180037430
// Address: 0x180037430
// Size: 561 bytes
// ============================================================
void fcn.180037430(int64_t arg1)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 *puVar10;
    undefined4 *puVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int64_t *piVar15;
    int64_t var_8h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if (((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) &&
       (iVar6 = func_0x000180085d50(arg1, 1), iVar6 != 0)) {
        var_8h = 0;
        cVar5 = func_0x000180051370(arg1, &var_8h);
        iVar14 = arg1;
        if (cVar5 != '\0') {
            iVar14 = var_8h;
        }
        iVar6 = func_0x000180085f50(arg1, 1, 0);
        iVar7 = func_0x000180033c60(iVar14, iVar6);
        if (iVar6 == iVar7) goto code_r0x000180037624;
        func_0x0001800865e0(arg1, iVar7);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        piVar12 = *(int64_t **)(arg1 + 0x40);
        piVar13 = *(int64_t **)(arg1 + 0x28);
        if (piVar12 <= *(int64_t **)(arg1 + 0x28)) {
            piVar13 = *(int64_t **)0x180782430;
        }
    } else {
        piVar15 = *(int64_t **)0x180782430;
        piVar12 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar12;
        if (piVar13 <= piVar12) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) != 9) && (*(int32_t *)((int64_t)piVar8 + 0xc) != 2))
        goto code_r0x000180037624;
        piVar8 = piVar12;
        if (piVar13 <= piVar12) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) != 9) || (*(char *)(*piVar8 + 3) != 'x')) goto code_r0x000180037624;
        if (piVar13 <= piVar12) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
            puVar9 = (undefined4 *)(*piVar12 + 0x10);
        } else {
            puVar9 = (undefined4 *)0x0;
        }
        uVar1 = *puVar9;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = func_0x000180085510(arg1, 1), piVar15 = *(int64_t **)0x180782430, iVar6 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        puVar10 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar11 = (undefined4 *)func_0x0001800a0d50(*puVar10, uVar1);
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        uVar1 = puVar11[1];
        uVar3 = puVar11[2];
        uVar4 = puVar11[3];
        *puVar9 = *puVar11;
        puVar9[1] = uVar1;
        puVar9[2] = uVar3;
        puVar9[3] = uVar4;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8) {
            func_0x000180088560(arg1, 0x1806224c8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        piVar12 = *(int64_t **)(arg1 + 0x40);
        piVar13 = *(int64_t **)(arg1 + 0x28);
        if (piVar12 <= *(int64_t **)(arg1 + 0x28)) {
            piVar13 = piVar15;
        }
    }
    uVar1 = *(undefined4 *)((int64_t)piVar12 - 0xc);
    uVar3 = *(undefined4 *)(piVar12 + -1);
    uVar4 = *(undefined4 *)((int64_t)piVar12 - 4);
    *(undefined4 *)piVar13 = *(undefined4 *)(piVar12 + -2);
    *(undefined4 *)((int64_t)piVar13 + 4) = uVar1;
    *(undefined4 *)(piVar13 + 1) = uVar3;
    *(undefined4 *)((int64_t)piVar13 + 0xc) = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
code_r0x000180037624:
    // WARNING: Could not recover jumptable at 0x000180037636. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x180782118)(arg1);
    return;
}

// ============================================================
// Function: FUN_180037670
// Address: 0x180037670
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180037670(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 *puVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg4 == 0) {
        func_0x000180086cc0(arg1, 0xffffd8ee, arg2);
    } else {
        func_0x000180086cc0(arg1, 0xffffd8ee, arg4);
        func_0x000180086cc0(arg1, 0xffffffff, arg2);
        puVar3 = *(undefined4 **)(arg1 + 0x40);
        puVar1 = puVar3 + -4;
        if (puVar1 < puVar3) {
            do {
                puVar1[-4] = *puVar1;
                puVar1[-3] = puVar1[1];
                puVar1[-2] = puVar1[2];
                puVar1[-1] = puVar1[3];
                puVar3 = *(undefined4 **)(arg1 + 0x40);
                puVar1 = puVar1 + 4;
            } while (puVar1 < puVar3);
        }
        *(undefined4 **)(arg1 + 0x40) = puVar3 + -4;
    }
    piVar2 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar2 == *(int64_t **)0x180782430) {
        piVar2 = (int64_t *)0x0;
    }
    if (*(int64_t *)(*piVar2 + 0x20) != arg3) {
        *(int64_t *)(*piVar2 + 0x20) = arg3;
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return;
}

// ============================================================
// Function: FUN_180037720
// Address: 0x180037720
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x37f0) = 0x180033990;
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x1d8);
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar6 = func_0x000180085510(iVar1, 1), iVar6 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        func_0x000180087960(iVar1);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    puVar7 = (undefined4 *)func_0x000180085370(iVar1, 0xffffd8ee);
    puVar9 = *(undefined4 **)(iVar1 + 0x40);
    uVar13 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *puVar9 = *puVar7;
    puVar9[1] = uVar13;
    puVar9[2] = uVar4;
    puVar9[3] = uVar5;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    func_0x000180086cc0(iVar1, 0xffffffff, 0x1806227a4);
    func_0x000180085680(iVar1, arg2, 1);
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg2 + 0x40) + 0x10U <= **(uint64_t **)(arg2 + 0x18))) ||
       (iVar6 = func_0x000180085510(arg2, 1), iVar6 != 0)) {
        piVar11 = (int64_t *)0x0;
        *(undefined4 *)(*(int64_t *)(arg2 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
        iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        while( true ) {
            if (iVar6 == 0) {
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180018f70();
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b00, 0x180622848, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622848);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b70, 0x180622870, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622870);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                uVar12 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
                var_38h = 0x180622890;
                func_0x0001800869f0(arg2, 0x180036450, 0x180622880, 0, 0);
                func_0x000180087370(arg2, uVar12 & 0xffffffff, 0x180622880);
                piVar10 = &var_38h;
                do {
                    func_0x000180086cc0(arg2, uVar12 & 0xffffffff, 0x180622880);
                    piVar8 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                        func_0x000180087370(arg2, uVar12 & 0xffffffff, *piVar10);
                    } else {
                        *(int64_t **)(arg2 + 0x40) = piVar8;
                    }
                    piVar10 = piVar10 + 1;
                } while (piVar10 != &var_30h);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                *(undefined *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 4) = 1;
                func_0x000180087370(arg2, 0xfffffffe, 0x1806227a4);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                uVar13 = func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                var_30h = (int64_t)&var_10h;
                var_28h = (int64_t)&var_18h;
                var_10h = 0x180622890;
                func_0x00018001aeb0(uVar13, arg2, 0x180036450, 0x180622880, &var_30h, 0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                if (*(int64_t **)0x180782108 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                    *(int64_t **)0x180782108 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782108 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782118 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                    *(int64_t **)0x180782118 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782118 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782110 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                    *(int64_t **)0x180782110 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782110 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782100 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                    func_0x000180086cc0(arg2, 0xffffffff, 0x1806228d4);
                    *(int64_t **)0x180782100 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782100 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffd);
                }
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.1800371f0) {
                    *(code **)(*piVar10 + 0x20) = fcn.1800371f0;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037430) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037430;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037050) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037050;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                fcn.180037670(arg2, 0x1806228d4, 0x180036990, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffffff, 0x1806228c8);
                puVar7 = *(undefined4 **)(arg2 + 0x40);
                puVar9 = puVar7 + -4;
                if (puVar9 < puVar7) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar7 = *(undefined4 **)(arg2 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar7);
                }
                *(undefined4 **)(arg2 + 0x40) = puVar7 + -4;
                piVar10 = (int64_t *)(puVar7 + -8);
                if ((int64_t *)(puVar7 + -8) == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180036b30) {
                    *(code **)(*piVar10 + 0x20) = fcn.180036b30;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                return;
            }
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            iVar1 = *(int64_t *)(arg2 + 0x40);
            *(int64_t *)(arg2 + 0x40) = iVar1 + 0x10;
            func_0x0001800a8680(arg2, iVar1 + -0x50, iVar1 + -0x10);
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x30;
            iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        }
    }
    func_0x000180099450(arg2, 0x18063d8d0);
    func_0x000180087960(arg2);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800377a5
// Address: 0x1800377a5
// Size: 398 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x37f0) = 0x180033990;
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x1d8);
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar6 = func_0x000180085510(iVar1, 1), iVar6 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        func_0x000180087960(iVar1);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    puVar7 = (undefined4 *)func_0x000180085370(iVar1, 0xffffd8ee);
    puVar9 = *(undefined4 **)(iVar1 + 0x40);
    uVar13 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *puVar9 = *puVar7;
    puVar9[1] = uVar13;
    puVar9[2] = uVar4;
    puVar9[3] = uVar5;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    func_0x000180086cc0(iVar1, 0xffffffff, 0x1806227a4);
    func_0x000180085680(iVar1, arg2, 1);
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg2 + 0x40) + 0x10U <= **(uint64_t **)(arg2 + 0x18))) ||
       (iVar6 = func_0x000180085510(arg2, 1), iVar6 != 0)) {
        piVar11 = (int64_t *)0x0;
        *(undefined4 *)(*(int64_t *)(arg2 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
        iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        while( true ) {
            if (iVar6 == 0) {
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180018f70();
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b00, 0x180622848, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622848);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b70, 0x180622870, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622870);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                uVar12 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
                var_38h = 0x180622890;
                func_0x0001800869f0(arg2, 0x180036450, 0x180622880, 0, 0);
                func_0x000180087370(arg2, uVar12 & 0xffffffff, 0x180622880);
                piVar10 = &var_38h;
                do {
                    func_0x000180086cc0(arg2, uVar12 & 0xffffffff, 0x180622880);
                    piVar8 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                        func_0x000180087370(arg2, uVar12 & 0xffffffff, *piVar10);
                    } else {
                        *(int64_t **)(arg2 + 0x40) = piVar8;
                    }
                    piVar10 = piVar10 + 1;
                } while (piVar10 != &var_30h);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                *(undefined *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 4) = 1;
                func_0x000180087370(arg2, 0xfffffffe, 0x1806227a4);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                uVar13 = func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                var_30h = (int64_t)&var_10h;
                var_28h = (int64_t)&var_18h;
                var_10h = 0x180622890;
                func_0x00018001aeb0(uVar13, arg2, 0x180036450, 0x180622880, &var_30h, 0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                if (*(int64_t **)0x180782108 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                    *(int64_t **)0x180782108 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782108 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782118 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                    *(int64_t **)0x180782118 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782118 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782110 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                    *(int64_t **)0x180782110 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782110 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782100 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                    func_0x000180086cc0(arg2, 0xffffffff, 0x1806228d4);
                    *(int64_t **)0x180782100 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782100 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffd);
                }
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.1800371f0) {
                    *(code **)(*piVar10 + 0x20) = fcn.1800371f0;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037430) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037430;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037050) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037050;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                fcn.180037670(arg2, 0x1806228d4, 0x180036990, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffffff, 0x1806228c8);
                puVar7 = *(undefined4 **)(arg2 + 0x40);
                puVar9 = puVar7 + -4;
                if (puVar9 < puVar7) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar7 = *(undefined4 **)(arg2 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar7);
                }
                *(undefined4 **)(arg2 + 0x40) = puVar7 + -4;
                piVar10 = (int64_t *)(puVar7 + -8);
                if ((int64_t *)(puVar7 + -8) == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180036b30) {
                    *(code **)(*piVar10 + 0x20) = fcn.180036b30;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                return;
            }
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            iVar1 = *(int64_t *)(arg2 + 0x40);
            *(int64_t *)(arg2 + 0x40) = iVar1 + 0x10;
            func_0x0001800a8680(arg2, iVar1 + -0x50, iVar1 + -0x10);
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x30;
            iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        }
    }
    func_0x000180099450(arg2, 0x18063d8d0);
    func_0x000180087960(arg2);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180037933
// Address: 0x180037933
// Size: 2065 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x37f0) = 0x180033990;
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x1d8);
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar6 = func_0x000180085510(iVar1, 1), iVar6 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        func_0x000180087960(iVar1);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    puVar7 = (undefined4 *)func_0x000180085370(iVar1, 0xffffd8ee);
    puVar9 = *(undefined4 **)(iVar1 + 0x40);
    uVar13 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *puVar9 = *puVar7;
    puVar9[1] = uVar13;
    puVar9[2] = uVar4;
    puVar9[3] = uVar5;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    func_0x000180086cc0(iVar1, 0xffffffff, 0x1806227a4);
    func_0x000180085680(iVar1, arg2, 1);
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg2 + 0x40) + 0x10U <= **(uint64_t **)(arg2 + 0x18))) ||
       (iVar6 = func_0x000180085510(arg2, 1), iVar6 != 0)) {
        piVar11 = (int64_t *)0x0;
        *(undefined4 *)(*(int64_t *)(arg2 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
        iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        while( true ) {
            if (iVar6 == 0) {
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180018f70();
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b00, 0x180622848, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622848);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b70, 0x180622870, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622870);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                uVar12 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
                var_38h = 0x180622890;
                func_0x0001800869f0(arg2, 0x180036450, 0x180622880, 0, 0);
                func_0x000180087370(arg2, uVar12 & 0xffffffff, 0x180622880);
                piVar10 = &var_38h;
                do {
                    func_0x000180086cc0(arg2, uVar12 & 0xffffffff, 0x180622880);
                    piVar8 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                        func_0x000180087370(arg2, uVar12 & 0xffffffff, *piVar10);
                    } else {
                        *(int64_t **)(arg2 + 0x40) = piVar8;
                    }
                    piVar10 = piVar10 + 1;
                } while (piVar10 != &var_30h);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                *(undefined *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 4) = 1;
                func_0x000180087370(arg2, 0xfffffffe, 0x1806227a4);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                uVar13 = func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                var_30h = (int64_t)&var_10h;
                var_28h = (int64_t)&var_18h;
                var_10h = 0x180622890;
                func_0x00018001aeb0(uVar13, arg2, 0x180036450, 0x180622880, &var_30h, 0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                if (*(int64_t **)0x180782108 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                    *(int64_t **)0x180782108 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782108 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782118 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                    *(int64_t **)0x180782118 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782118 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782110 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                    *(int64_t **)0x180782110 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782110 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782100 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                    func_0x000180086cc0(arg2, 0xffffffff, 0x1806228d4);
                    *(int64_t **)0x180782100 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782100 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffd);
                }
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.1800371f0) {
                    *(code **)(*piVar10 + 0x20) = fcn.1800371f0;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037430) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037430;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037050) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037050;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                fcn.180037670(arg2, 0x1806228d4, 0x180036990, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffffff, 0x1806228c8);
                puVar7 = *(undefined4 **)(arg2 + 0x40);
                puVar9 = puVar7 + -4;
                if (puVar9 < puVar7) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar7 = *(undefined4 **)(arg2 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar7);
                }
                *(undefined4 **)(arg2 + 0x40) = puVar7 + -4;
                piVar10 = (int64_t *)(puVar7 + -8);
                if ((int64_t *)(puVar7 + -8) == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180036b30) {
                    *(code **)(*piVar10 + 0x20) = fcn.180036b30;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                return;
            }
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            iVar1 = *(int64_t *)(arg2 + 0x40);
            *(int64_t *)(arg2 + 0x40) = iVar1 + 0x10;
            func_0x0001800a8680(arg2, iVar1 + -0x50, iVar1 + -0x10);
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x30;
            iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        }
    }
    func_0x000180099450(arg2, 0x18063d8d0);
    func_0x000180087960(arg2);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180038144
// Address: 0x180038144
// Size: 700 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x37f0) = 0x180033990;
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x1d8);
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar6 = func_0x000180085510(iVar1, 1), iVar6 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        func_0x000180087960(iVar1);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    puVar7 = (undefined4 *)func_0x000180085370(iVar1, 0xffffd8ee);
    puVar9 = *(undefined4 **)(iVar1 + 0x40);
    uVar13 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *puVar9 = *puVar7;
    puVar9[1] = uVar13;
    puVar9[2] = uVar4;
    puVar9[3] = uVar5;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    func_0x000180086cc0(iVar1, 0xffffffff, 0x1806227a4);
    func_0x000180085680(iVar1, arg2, 1);
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg2 + 0x40) + 0x10U <= **(uint64_t **)(arg2 + 0x18))) ||
       (iVar6 = func_0x000180085510(arg2, 1), iVar6 != 0)) {
        piVar11 = (int64_t *)0x0;
        *(undefined4 *)(*(int64_t *)(arg2 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
        iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        while( true ) {
            if (iVar6 == 0) {
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180018f70();
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b00, 0x180622848, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622848);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b70, 0x180622870, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622870);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                uVar12 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
                var_38h = 0x180622890;
                func_0x0001800869f0(arg2, 0x180036450, 0x180622880, 0, 0);
                func_0x000180087370(arg2, uVar12 & 0xffffffff, 0x180622880);
                piVar10 = &var_38h;
                do {
                    func_0x000180086cc0(arg2, uVar12 & 0xffffffff, 0x180622880);
                    piVar8 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                        func_0x000180087370(arg2, uVar12 & 0xffffffff, *piVar10);
                    } else {
                        *(int64_t **)(arg2 + 0x40) = piVar8;
                    }
                    piVar10 = piVar10 + 1;
                } while (piVar10 != &var_30h);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                *(undefined *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 4) = 1;
                func_0x000180087370(arg2, 0xfffffffe, 0x1806227a4);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                uVar13 = func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                var_30h = (int64_t)&var_10h;
                var_28h = (int64_t)&var_18h;
                var_10h = 0x180622890;
                func_0x00018001aeb0(uVar13, arg2, 0x180036450, 0x180622880, &var_30h, 0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                if (*(int64_t **)0x180782108 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                    *(int64_t **)0x180782108 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782108 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782118 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                    *(int64_t **)0x180782118 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782118 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782110 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                    *(int64_t **)0x180782110 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782110 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782100 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                    func_0x000180086cc0(arg2, 0xffffffff, 0x1806228d4);
                    *(int64_t **)0x180782100 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782100 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffd);
                }
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.1800371f0) {
                    *(code **)(*piVar10 + 0x20) = fcn.1800371f0;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037430) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037430;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037050) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037050;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                fcn.180037670(arg2, 0x1806228d4, 0x180036990, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffffff, 0x1806228c8);
                puVar7 = *(undefined4 **)(arg2 + 0x40);
                puVar9 = puVar7 + -4;
                if (puVar9 < puVar7) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar7 = *(undefined4 **)(arg2 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar7);
                }
                *(undefined4 **)(arg2 + 0x40) = puVar7 + -4;
                piVar10 = (int64_t *)(puVar7 + -8);
                if ((int64_t *)(puVar7 + -8) == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180036b30) {
                    *(code **)(*piVar10 + 0x20) = fcn.180036b30;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                return;
            }
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            iVar1 = *(int64_t *)(arg2 + 0x40);
            *(int64_t *)(arg2 + 0x40) = iVar1 + 0x10;
            func_0x0001800a8680(arg2, iVar1 + -0x50, iVar1 + -0x10);
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x30;
            iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        }
    }
    func_0x000180099450(arg2, 0x18063d8d0);
    func_0x000180087960(arg2);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180038400
// Address: 0x180038400
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x37f0) = 0x180033990;
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x1d8);
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar6 = func_0x000180085510(iVar1, 1), iVar6 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        func_0x000180087960(iVar1);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    puVar7 = (undefined4 *)func_0x000180085370(iVar1, 0xffffd8ee);
    puVar9 = *(undefined4 **)(iVar1 + 0x40);
    uVar13 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *puVar9 = *puVar7;
    puVar9[1] = uVar13;
    puVar9[2] = uVar4;
    puVar9[3] = uVar5;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    func_0x000180086cc0(iVar1, 0xffffffff, 0x1806227a4);
    func_0x000180085680(iVar1, arg2, 1);
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg2 + 0x40) + 0x10U <= **(uint64_t **)(arg2 + 0x18))) ||
       (iVar6 = func_0x000180085510(arg2, 1), iVar6 != 0)) {
        piVar11 = (int64_t *)0x0;
        *(undefined4 *)(*(int64_t *)(arg2 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
        iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        while( true ) {
            if (iVar6 == 0) {
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180018f70();
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b00, 0x180622848, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622848);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b70, 0x180622870, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622870);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                uVar12 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
                var_38h = 0x180622890;
                func_0x0001800869f0(arg2, 0x180036450, 0x180622880, 0, 0);
                func_0x000180087370(arg2, uVar12 & 0xffffffff, 0x180622880);
                piVar10 = &var_38h;
                do {
                    func_0x000180086cc0(arg2, uVar12 & 0xffffffff, 0x180622880);
                    piVar8 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                        func_0x000180087370(arg2, uVar12 & 0xffffffff, *piVar10);
                    } else {
                        *(int64_t **)(arg2 + 0x40) = piVar8;
                    }
                    piVar10 = piVar10 + 1;
                } while (piVar10 != &var_30h);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                *(undefined *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 4) = 1;
                func_0x000180087370(arg2, 0xfffffffe, 0x1806227a4);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                uVar13 = func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                var_30h = (int64_t)&var_10h;
                var_28h = (int64_t)&var_18h;
                var_10h = 0x180622890;
                func_0x00018001aeb0(uVar13, arg2, 0x180036450, 0x180622880, &var_30h, 0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                if (*(int64_t **)0x180782108 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                    *(int64_t **)0x180782108 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782108 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782118 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                    *(int64_t **)0x180782118 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782118 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782110 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                    *(int64_t **)0x180782110 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782110 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782100 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                    func_0x000180086cc0(arg2, 0xffffffff, 0x1806228d4);
                    *(int64_t **)0x180782100 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782100 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffd);
                }
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.1800371f0) {
                    *(code **)(*piVar10 + 0x20) = fcn.1800371f0;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037430) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037430;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037050) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037050;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                fcn.180037670(arg2, 0x1806228d4, 0x180036990, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffffff, 0x1806228c8);
                puVar7 = *(undefined4 **)(arg2 + 0x40);
                puVar9 = puVar7 + -4;
                if (puVar9 < puVar7) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar7 = *(undefined4 **)(arg2 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar7);
                }
                *(undefined4 **)(arg2 + 0x40) = puVar7 + -4;
                piVar10 = (int64_t *)(puVar7 + -8);
                if ((int64_t *)(puVar7 + -8) == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180036b30) {
                    *(code **)(*piVar10 + 0x20) = fcn.180036b30;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                return;
            }
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            iVar1 = *(int64_t *)(arg2 + 0x40);
            *(int64_t *)(arg2 + 0x40) = iVar1 + 0x10;
            func_0x0001800a8680(arg2, iVar1 + -0x50, iVar1 + -0x10);
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x30;
            iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        }
    }
    func_0x000180099450(arg2, 0x18063d8d0);
    func_0x000180087960(arg2);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180038418
// Address: 0x180038418
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180037720(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined4 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x37f0) = 0x180033990;
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x1d8);
    if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
        *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
        *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = iVar1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar1 + 0x18) < *(int64_t *)(iVar1 + 0x40) + 0x10U)) &&
       (iVar6 = func_0x000180085510(iVar1, 1), iVar6 == 0)) {
        func_0x000180099450(iVar1, 0x18063d8d0);
        func_0x000180087960(iVar1);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    puVar7 = (undefined4 *)func_0x000180085370(iVar1, 0xffffd8ee);
    puVar9 = *(undefined4 **)(iVar1 + 0x40);
    uVar13 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *puVar9 = *puVar7;
    puVar9[1] = uVar13;
    puVar9[2] = uVar4;
    puVar9[3] = uVar5;
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
    func_0x000180086cc0(iVar1, 0xffffffff, 0x1806227a4);
    func_0x000180085680(iVar1, arg2, 1);
    *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + -0x10;
    if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg2 + 0x40) + 0x10U <= **(uint64_t **)(arg2 + 0x18))) ||
       (iVar6 = func_0x000180085510(arg2, 1), iVar6 != 0)) {
        piVar11 = (int64_t *)0x0;
        *(undefined4 *)(*(int64_t *)(arg2 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
        iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        while( true ) {
            if (iVar6 == 0) {
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180018f70();
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b00, 0x180622848, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622848);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035b70, 0x180622870, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622870);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                uVar12 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
                var_38h = 0x180622890;
                func_0x0001800869f0(arg2, 0x180036450, 0x180622880, 0, 0);
                func_0x000180087370(arg2, uVar12 & 0xffffffff, 0x180622880);
                piVar10 = &var_38h;
                do {
                    func_0x000180086cc0(arg2, uVar12 & 0xffffffff, 0x180622880);
                    piVar8 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                        func_0x000180087370(arg2, uVar12 & 0xffffffff, *piVar10);
                    } else {
                        *(int64_t **)(arg2 + 0x40) = piVar8;
                    }
                    piVar10 = piVar10 + 1;
                } while (piVar10 != &var_30h);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                *(undefined *)(*(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10) + 4) = 1;
                func_0x000180087370(arg2, 0xfffffffe, 0x1806227a4);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180033e20, 0x180622798, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622798);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034070, 0x1806227c0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227c0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800343a0, 0x1806227b0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227b0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800346e0, 0x1806227e0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227e0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800348c0, 0x1806227d0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227d0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034a50, 0x180622800, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622800);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034b70, 0x1806227f0, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806227f0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180034de0, 0x180622820, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622820);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800350b0, 0x180622810, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622810);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035320, 0x180622838, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622838);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035610, 0x180622830, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622830);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035a70, 0x180622858, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622858);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x180035c30, 0x180622868, 0, 0);
                uVar13 = func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x180622868);
                var_30h = (int64_t)&var_10h;
                var_28h = (int64_t)&var_18h;
                var_10h = 0x180622890;
                func_0x00018001aeb0(uVar13, arg2, 0x180036450, 0x180622880, &var_30h, 0);
                iVar1 = *(int64_t *)(arg2 + 0x40);
                iVar2 = *(int64_t *)(arg2 + 0x28);
                func_0x0001800869f0(arg2, 0x1800365e0, 0x1806228a8, 0, 0);
                func_0x000180087370(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806228a8);
                if (*(int64_t **)0x180782108 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                    *(int64_t **)0x180782108 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782108 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782118 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                    *(int64_t **)0x180782118 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782118 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782110 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                    *(int64_t **)0x180782110 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782110 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffe);
                }
                if (*(int64_t **)0x180782100 == (int64_t *)0x0) {
                    func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                    func_0x000180086cc0(arg2, 0xffffffff, 0x1806228d4);
                    *(int64_t **)0x180782100 = piVar11;
                    if ((*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) == 8) &&
                       (iVar1 = *(int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10), *(char *)(iVar1 + 3) != '\0')) {
                        *(int64_t **)0x180782100 = *(int64_t **)(iVar1 + 0x20);
                    }
                    func_0x0001800858c0(arg2, 0xfffffffd);
                }
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228a0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.1800371f0) {
                    *(code **)(*piVar10 + 0x20) = fcn.1800371f0;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228c0);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037430) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037430;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806228b8);
                piVar10 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
                if (piVar10 == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180037050) {
                    *(code **)(*piVar10 + 0x20) = fcn.180037050;
                }
                func_0x0001800858c0(arg2, 0xfffffffe);
                fcn.180037670(arg2, 0x1806228d4, 0x180036990, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffd8ee, 0x1806227a4);
                func_0x000180086cc0(arg2, 0xffffffff, 0x1806228c8);
                puVar7 = *(undefined4 **)(arg2 + 0x40);
                puVar9 = puVar7 + -4;
                if (puVar9 < puVar7) {
                    do {
                        puVar9[-4] = *puVar9;
                        puVar9[-3] = puVar9[1];
                        puVar9[-2] = puVar9[2];
                        puVar9[-1] = puVar9[3];
                        puVar7 = *(undefined4 **)(arg2 + 0x40);
                        puVar9 = puVar9 + 4;
                    } while (puVar9 < puVar7);
                }
                *(undefined4 **)(arg2 + 0x40) = puVar7 + -4;
                piVar10 = (int64_t *)(puVar7 + -8);
                if ((int64_t *)(puVar7 + -8) == *(int64_t **)0x180782430) {
                    piVar10 = piVar11;
                }
                if (*(code **)(*piVar10 + 0x20) != fcn.180036b30) {
                    *(code **)(*piVar10 + 0x20) = fcn.180036b30;
                }
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
                return;
            }
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
                *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
                *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg2, 1), iVar6 == 0)) break;
            puVar9 = *(undefined4 **)(arg2 + 0x40);
            *puVar9 = puVar9[-8];
            puVar9[1] = puVar9[-7];
            puVar9[2] = puVar9[-6];
            puVar9[3] = puVar9[-5];
            iVar1 = *(int64_t *)(arg2 + 0x40);
            *(int64_t *)(arg2 + 0x40) = iVar1 + 0x10;
            func_0x0001800a8680(arg2, iVar1 + -0x50, iVar1 + -0x10);
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x30;
            iVar6 = func_0x000180087970(arg2, 0xfffffffe);
        }
    }
    func_0x000180099450(arg2, 0x18063d8d0);
    func_0x000180087960(arg2);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_180038430
// Address: 0x180038430
// Size: 131 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180038430(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar2 = func_0x000180498cd0(arg2);
    if (0x7fffffffffffffffU - *(int64_t *)(arg3 + 0x10) < uVar2) {
        func_0x0001800047c0();
        pcVar1 = (code *)swi(3);
        iVar3 = (*pcVar1)();
        return iVar3;
    }
    iVar3 = arg3;
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        iVar3 = *(int64_t *)arg3;
    }
    func_0x0001800384c0(arg1, (undefined)var_18h, arg3, arg2, uVar2, iVar3, *(int64_t *)(arg3 + 0x10));
    return arg1;
}

// ============================================================
// Function: FUN_1800384c0
// Address: 0x1800384c0
// Size: 268 bytes
// ============================================================
int64_t fcn.1800384c0(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    undefined8 uStack_60;
    undefined auStack_58 [32];
    
    puVar7 = auStack_58;
    uVar6 = 0;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    uVar1 = arg_28h + arg_38h;
    if (uVar1 < 0x10) {
        uVar3 = 0xf;
        uVar6 = arg1;
    } else {
        uVar3 = uVar1 | 0xf;
        puVar7 = auStack_58;
        if (uVar3 < 0x8000000000000000) goto code_r0x000180038533;
        uVar4 = 0x8000000000000027;
        puVar7 = auStack_58;
        uVar3 = 0x7fffffffffffffff;
        while( true ) {
            *(undefined8 *)(puVar7 + -8) = 0x180038527;
            iVar5 = func_0x000180459890(uVar4);
            if (iVar5 != 0) {
                uVar6 = iVar5 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar6 - 8) = iVar5;
                *(uint64_t *)arg1 = uVar6;
                goto code_r0x000180038585;
            }
            pcVar2 = (code *)swi(0x29);
            uVar3 = (*pcVar2)(5);
            puVar7 = puVar7 + 8;
code_r0x000180038533:
            if (uVar3 < 0x16) {
                uVar3 = 0x16;
            }
            if (uVar3 == 0xffffffffffffffff) break;
            if (uVar3 + 1 < 0x1000) {
                *(undefined8 *)(puVar7 + -8) = 0x180038575;
                uVar6 = func_0x000180459890();
                break;
            }
            uVar4 = uVar3 + 0x28;
            if (uVar4 <= uVar3 + 1) {
                *(undefined8 *)(puVar7 + -8) = 0x1800385cb;
                func_0x000180004720();
                pcVar2 = (code *)swi(3);
                iVar5 = (*pcVar2)();
                return iVar5;
            }
        }
        *(uint64_t *)arg1 = uVar6;
    }
code_r0x000180038585:
    *(uint64_t *)(arg1 + 0x10) = uVar1;
    *(uint64_t *)(arg1 + 0x18) = uVar3;
    *(undefined8 *)(puVar7 + -8) = 0x18003859b;
    func_0x000180498030(uVar6, arg4, arg_28h);
    *(undefined8 *)(puVar7 + -8) = 0x1800385af;
    func_0x000180498030(uVar6 + arg_28h, *(undefined8 *)(puVar7 + 0x88), arg_38h);
    *(undefined *)(uVar1 + uVar6) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_1800385d0
// Address: 0x1800385d0
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800385d0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_10h;
    
    fcn.18000b4d0();
    fcn.18000b4d0(arg1 + 0x20, arg2 + 0x20);
    fcn.18000b4d0(arg1 + 0x40, arg2 + 0x40);
    *(undefined *)(arg1 + 0x60) = *(undefined *)(arg2 + 0x60);
    fcn.18000b4d0(arg1 + 0x68, arg2 + 0x68);
    *(undefined *)(arg1 + 0x88) = *(undefined *)(arg2 + 0x88);
    *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(arg2 + 0x90);
    return arg1;
}

// ============================================================
// Function: FUN_180038650
// Address: 0x180038650
// Size: 49 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018003865d: Changing call to branch
// WARNING: Possible PIC construction at 0x00018003866f: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180038662)
// WARNING: Removing unreachable block (ram,0x000180038674)

void fcn.180038650(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t iStack_38;
    undefined8 uStack_30;
    
    uStack_30 = 0x180038662;
    if (0xf < *(uint64_t *)(arg1 + 0x80)) {
        iVar1 = *(int64_t *)(arg1 + 0x68);
        iVar3 = iVar1;
        puVar4 = auStack_58;
        iStack_38 = arg1;
        if ((0xfff < *(uint64_t *)(arg1 + 0x80) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_58, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_50;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined8 *)(arg1 + 0x80) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x68) = 0;
    return;
}

// ============================================================
// Function: FUN_180038690
// Address: 0x180038690
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180038690(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 8);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800386e0
// Address: 0x1800386e0
// Size: 180 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800386e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar4 = auStack_28;
    *(undefined8 *)arg1 = 0x180622970;
    if (*(int64_t **)(arg1 + 0x270) != (int64_t *)0x0) {
        (**(code **)(**(int64_t **)(arg1 + 0x270) + 0x10))();
        *(undefined8 *)(arg1 + 0x270) = 0;
    }
    iVar1 = *(int64_t *)(arg1 + 0x38);
    if (iVar1 != *(int64_t *)(arg1 + 0x40)) {
        *(int64_t *)(arg1 + 0x40) = iVar1;
    }
    if (iVar1 != 0) {
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x48) - iVar1)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180038762;
        fcn.180459c3c(iVar3);
        *(undefined8 *)(arg1 + 0x38) = 0;
        *(undefined8 *)(arg1 + 0x40) = 0;
        *(undefined8 *)(arg1 + 0x48) = 0;
    }
    if ((arg2 & 1U) != 0) {
        *(undefined8 *)(puVar4 + -8) = 0x180038781;
        fcn.180459c3c(arg1, 0x288);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180038820
// Address: 0x180038820
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180038820(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t var_8h;
    
    func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaef0);
    func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaeec);
    func_0x000180086570(arg1, (double)*(float *)arg2);
    func_0x000180086570(arg1, (double)*(float *)(arg2 + 4));
    func_0x0001800878a0(arg1, 2, 1);
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    puVar1 = puVar2 + -4;
    if (puVar1 < puVar2) {
        do {
            puVar1[-4] = *puVar1;
            puVar1[-3] = puVar1[1];
            puVar1[-2] = puVar1[2];
            puVar1[-1] = puVar1[3];
            puVar2 = *(undefined4 **)(arg1 + 0x40);
            puVar1 = puVar1 + 4;
        } while (puVar1 < puVar2);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar2 + -4;
    return;
}

// ============================================================
// Function: FUN_1800388d0
// Address: 0x1800388d0
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800388d0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    int64_t var_8h;
    
    func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaee4);
    func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaeec);
    func_0x000180086570(arg1, (double)*(float *)arg2);
    func_0x000180086570(arg1, (double)*(float *)(arg2 + 4));
    func_0x000180086570(arg1, (double)*(float *)(arg2 + 8));
    func_0x0001800878a0(arg1, 3, 1);
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    puVar1 = puVar2 + -4;
    if (puVar1 < puVar2) {
        do {
            puVar1[-4] = *puVar1;
            puVar1[-3] = puVar1[1];
            puVar1[-2] = puVar1[2];
            puVar1[-1] = puVar1[3];
            puVar2 = *(undefined4 **)(arg1 + 0x40);
            puVar1 = puVar1 + 4;
        } while (puVar1 < puVar2);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar2 + -4;
    return;
}

// ============================================================
// Function: FUN_180038990
// Address: 0x180038990
// Size: 173 bytes
// ============================================================
int64_t fcn.180038990(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    
    piVar4 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar1 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar1 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar1 + 0xc) == 9) {
        uVar3 = (uint32_t)*(uint8_t *)(*piVar1 + 3);
    } else {
        uVar3 = 0xffffffff;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 9)) {
        if (uVar3 == *(uint32_t *)0x1807823d0) {
            return 0x1805aaef0;
        }
        iVar2 = 0x180622a70;
        if (uVar3 == *(uint32_t *)0x1807823d8) {
            iVar2 = 0x1805aaee4;
        }
        return iVar2;
    }
    iVar2 = func_0x000180085430(arg1, 3);
    if (iVar2 != 0) {
        iVar2 = func_0x0001800a3b90(arg1, iVar2);
        return iVar2 + 0x18;
    }
    return 0x18063d8c0;
}

// ============================================================
// Function: FUN_180038a40
// Address: 0x180038a40
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.180038a40(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    
    piVar2 = (int64_t *)(*(int64_t *)(arg2 + 0x28) + 0x20);
    if (*(int64_t **)(arg2 + 0x40) <= piVar2) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar2 + 0xc) == 9) {
        uVar5 = (uint32_t)*(uint8_t *)(*piVar2 + 3);
    } else {
        uVar5 = 0xffffffff;
    }
    if (uVar5 == *(uint32_t *)0x1807823d0) {
        puVar3 = (undefined8 *)func_0x0001800864a0(arg2, 3);
        *(undefined8 *)arg1 = *puVar3;
        return (undefined8 *)arg1;
    }
    uVar4 = fcn.180038990(arg2);
    func_0x000180088560(arg2, 0x180622ac0, arg4, uVar4);
    pcVar1 = (code *)swi(3);
    puVar3 = (undefined8 *)(*pcVar1)();
    return puVar3;
}

// ============================================================
// Function: FUN_180038ad0
// Address: 0x180038ad0
// Size: 148 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.180038ad0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    undefined4 uVar1;
    code *pcVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int64_t var_8h;
    
    piVar3 = (int64_t *)(*(int64_t *)(arg2 + 0x28) + 0x20);
    if (*(int64_t **)(arg2 + 0x40) <= piVar3) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 9) {
        uVar6 = (uint32_t)*(uint8_t *)(*piVar3 + 3);
    } else {
        uVar6 = 0xffffffff;
    }
    if (uVar6 == *(uint32_t *)0x1807823d8) {
        puVar4 = (undefined4 *)func_0x0001800864a0(arg2, 3);
        *(undefined4 *)(arg1 + 0xc) = 0x3f800000;
        *(undefined4 *)arg1 = *puVar4;
        uVar1 = puVar4[1];
        *(undefined4 *)(arg1 + 8) = puVar4[2];
        *(undefined4 *)(arg1 + 4) = uVar1;
        return (undefined4 *)arg1;
    }
    uVar5 = fcn.180038990(arg2);
    func_0x000180088560(arg2, 0x180622a88, arg4, uVar5);
    pcVar2 = (code *)swi(3);
    puVar4 = (undefined4 *)(*pcVar2)();
    return puVar4;
}

// ============================================================
// Function: FUN_180038b70
// Address: 0x180038b70
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180038b70(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    uVar5 = *(int64_t *)(arg1 + 0x28) + 0x20;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
        uVar5 = *(uint64_t *)0x180782430;
    }
    if ((uVar5 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar5 + 0xc) == 1)) {
        iVar4 = fcn.180085ff0(arg1, 3);
        return iVar4 != 0;
    }
    uVar2 = fcn.180038990(arg1);
    fcn.180088560(arg1, 0x180622b30, arg3, uVar2);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return (bool)uVar3;
}

// ============================================================
// Function: FUN_180038be0
// Address: 0x180038be0
// Size: 130 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180085f2a)
// WARNING: Removing unreachable block (ram,0x000180085ed0)
// WARNING: Removing unreachable block (ram,0x000180085ed8)
// WARNING: Removing unreachable block (ram,0x000180085ee5)
// WARNING: Removing unreachable block (ram,0x000180085f3f)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_ch

int64_t fcn.180038be0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_ch;
    
    piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar5 = piVar3;
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 3)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
            piVar3 = *(int64_t **)0x180782430;
        }
        if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 4)) {
            uVar4 = fcn.180038990(arg1);
            fcn.180088560(arg1, 0x180622af8, arg3, uVar4);
            pcVar1 = (code *)swi(3);
            iVar6 = (*pcVar1)();
            return iVar6;
        }
    }
    piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar3) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) != 3) {
        if ((*(int32_t *)((int64_t)piVar3 + 0xc) != 6) ||
           (iVar2 = func_0x0001800992c0(*piVar3 + 0x18, &var_18h), iVar2 == 0)) {
            return 0;
        }
        piVar3 = &var_18h;
        var_ch._0_4_ = 3;
    }
    return *piVar3;
}

// ============================================================
// Function: FUN_180038c70
// Address: 0x180038c70
// Size: 107 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800861ad)
// WARNING: Removing unreachable block (ram,0x0001800861b5)
// WARNING: Removing unreachable block (ram,0x0001800860fc)
// WARNING: Removing unreachable block (ram,0x000180086104)
// WARNING: Removing unreachable block (ram,0x000180086111)
// WARNING: Removing unreachable block (ram,0x0001800861c2)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180038c70(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 6)) {
        uVar3 = fcn.180038990(arg1);
        fcn.180088560(arg1, 0x180622bb8, arg3, uVar3);
        pcVar1 = (code *)swi(3);
        iVar4 = (*pcVar1)();
        return iVar4;
    }
    piVar5 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1, piVar5);
        if (iVar2 == 0) {
            if (arg4 != 0) {
                *(undefined8 *)arg4 = 0;
            }
            return 0;
        }
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    if (arg4 != 0) {
        *(uint64_t *)arg4 = (uint64_t)*(uint32_t *)(*piVar5 + 0x14);
    }
    return *piVar5 + 0x18;
}

// ============================================================
// Function: FUN_180038cf0
// Address: 0x180038cf0
// Size: 451 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180038cf0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t *piStack_10;
    
    ppiVar7 = *(int64_t ***)(arg1 + 0x28);
    if (*(int64_t ***)(arg1 + 0x40) <= *(int64_t ***)(arg1 + 0x28)) {
        ppiVar7 = *(int64_t ***)0x180782430;
    }
    if (*(int32_t *)((int64_t)ppiVar7 + 0xc) == 9) {
        piVar8 = *ppiVar7 + 2;
    } else if (*(int32_t *)((int64_t)ppiVar7 + 0xc) == 2) {
        piVar8 = *ppiVar7;
    } else {
        piVar8 = (int64_t *)0x0;
    }
    if (piVar8[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar8[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    var_18h = *piVar8;
    piVar8 = (int64_t *)piVar8[1];
    piStack_10 = piVar8;
    func_0x00018003df40(arg1, &var_8h, &var_18h);
    iVar6 = *(int64_t *)0x18077af48;
    if (var_8h != *(int64_t *)0x18077af48) {
        uVar9 = *(uint64_t *)(var_8h + 0x10);
        uVar9 = ((((((((uVar9 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar9 >> 8 & 0xffU) *
                      0x100000001b3 ^ (int64_t)uVar9 >> 0x10 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar9 >> 0x18 & 0xffU)
                    * 0x100000001b3 ^ (int64_t)uVar9 >> 0x20 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar9 >> 0x28 & 0xffU)
                  * 0x100000001b3 ^ (int64_t)uVar9 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar9 >> 0x38 & 0xffU) *
                0x100000001b3 & *(uint64_t *)0x18077af70;
        iVar2 = *(int64_t *)0x18077af58 + uVar9 * 0x10;
        piVar3 = (int64_t *)(*(int64_t *)0x18077af58 + uVar9 * 0x10);
        iVar5 = *(int64_t *)(*(int64_t *)0x18077af58 + uVar9 * 0x10);
        if (*(int64_t *)(iVar2 + 8) == var_8h) {
            if (iVar5 == var_8h) {
                *piVar3 = *(int64_t *)0x18077af48;
                *(int64_t *)(iVar2 + 8) = iVar6;
            } else {
                *(undefined8 *)(iVar2 + 8) = *(undefined8 *)(var_8h + 8);
            }
        } else if (iVar5 == var_8h) {
            *piVar3 = *(int64_t *)var_8h;
        }
        iVar6 = *(int64_t *)var_8h;
        *(int64_t *)0x18077af50 = *(int64_t *)0x18077af50 + -1;
        **(int64_t **)(var_8h + 8) = iVar6;
        *(undefined8 *)(iVar6 + 8) = *(undefined8 *)(var_8h + 8);
        func_0x00018000d070(var_8h + 0x10);
        fcn.180459c3c(var_8h, 0x20);
    }
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        piVar3 = piVar8 + 1;
        iVar4 = *(int32_t *)piVar3;
        *(int32_t *)piVar3 = *(int32_t *)piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar8)(piVar8);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
            iVar4 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar8 + 8))(piVar8);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180038ec0
// Address: 0x180038ec0
// Size: 42 bytes
// ============================================================
undefined8 fcn.180038ec0(void)
{
    int64_t unaff_retaddr;
    int64_t in_stack_00000008;
    
    LOCK();
    *(undefined *)0x180781ed9 = 1;
    UNLOCK();
    fcn.18000adc0(unaff_retaddr, in_stack_00000008);
    LOCK();
    *(undefined *)0x180781ed9 = 0;
    UNLOCK();
    return 0;
}

// ============================================================
// Function: FUN_180038ef0
// Address: 0x180038ef0
// Size: 242 bytes
// ============================================================
undefined8 fcn.180038ef0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t var_18h;
    
    iVar2 = (int32_t)arg4;
    var_18h = arg3;
    if (iVar2 == -0x5fab7c80) {
        fcn.180086b20(arg1, *(undefined *)(*(int64_t *)arg2 + 8));
        return 1;
    }
    if (iVar2 == -0x4c2a89f3) {
        fcn.1800865e0(arg1, *(undefined4 *)(*(int64_t *)arg2 + 0xc));
        return 1;
    }
    if (iVar2 == 0x1227aca4) {
        fcn.1800388d0(arg1, *(int64_t *)arg2 + 0x14);
        return 1;
    }
    if ((iVar2 != 0x4893da69) && (iVar2 != 0x6ee28d50)) {
        if (iVar2 == -0x6a9ece27) {
            fcn.180086570(arg1, (double)*(float *)(*(int64_t *)arg2 + 0x10));
            return 1;
        }
        if (iVar2 == 0x4795eab1) {
            piVar1 = (int64_t *)fcn.18003df40(arg1, &var_18h, arg2);
            fcn.180086b20(arg1, *piVar1 != *(int64_t *)0x18077af48);
            return 1;
        }
        return 0;
    }
    fcn.180018f70();
    fcn.18001afc0();
    return 1;
}

// ============================================================
// Function: FUN_180038ff0
// Address: 0x180038ff0
// Size: 179 bytes
// ============================================================
undefined8 fcn.180038ff0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    double dVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined uVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t var_18h;
    
    iVar9 = (int32_t)arg4;
    if (iVar9 == -0x5fab7c80) {
        uVar6 = fcn.180038b70(arg1, arg2, arg3);
        *(undefined *)(*(int64_t *)arg2 + 8) = uVar6;
        return 1;
    }
    if (iVar9 == -0x4c2a89f3) {
        dVar2 = (double)fcn.180038be0(arg1, arg2, arg3);
        *(int32_t *)(*(int64_t *)arg2 + 0xc) = (int32_t)dVar2;
        return 1;
    }
    if (iVar9 == -0x6a9ece27) {
        dVar2 = (double)fcn.180038be0(arg1, arg2, arg3);
        *(float *)(*(int64_t *)arg2 + 0x10) = (float)dVar2;
        return 1;
    }
    if (iVar9 == 0x1227aca4) {
        puVar7 = (undefined4 *)fcn.180038ad0((int64_t)&var_18h, arg1, arg3, arg3);
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        arg2 = *(int64_t *)arg2;
        *(undefined4 *)(arg2 + 0x14) = *puVar7;
        *(undefined4 *)(arg2 + 0x18) = uVar3;
        *(undefined4 *)(arg2 + 0x1c) = uVar4;
        *(undefined4 *)(arg2 + 0x20) = uVar5;
        return 1;
    }
    if (iVar9 != 0x4795eab1) {
        return 0;
    }
    fcn.180088560(arg1, 0x180622b70);
    pcVar1 = (code *)swi(3);
    uVar8 = (*pcVar1)();
    return uVar8;
}

// ============================================================
// Function: FUN_1800390b0
// Address: 0x1800390b0
// Size: 78 bytes
// ============================================================
undefined8 fcn.1800390b0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    code *pcVar6;
    int64_t **ppiVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    int64_t unaff_RDI;
    uint64_t uVar12;
    int64_t **ppiStackX_8;
    undefined8 uStackY_18;
    int64_t *piStackY_10;
    
    iVar5 = *(int64_t *)(arg1 + 8);
    if (iVar5 == 0) {
        fcn.180088560(arg1, 0x180622c20);
        pcVar6 = (code *)swi(3);
        uVar8 = (*pcVar6)();
        return uVar8;
    }
    iVar9 = *(int32_t *)(iVar5 + 0x10) + 0x10 + (int32_t)iVar5;
    if ((iVar9 != 0x6ee28d50) && (iVar9 != 0x4893da69)) {
        fcn.180088560(arg1, 0x180622bf0, iVar5 + 0x18);
        pcVar6 = (code *)swi(3);
        uVar8 = (*pcVar6)();
        return uVar8;
    }
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 9) {
        puVar11 = (undefined8 *)(*piVar10 + 0x10);
    } else if (*(int32_t *)((int64_t)piVar10 + 0xc) == 2) {
        puVar11 = (undefined8 *)*piVar10;
    } else {
        puVar11 = (undefined8 *)0x0;
    }
    if (puVar11[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(puVar11[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    uStackY_18 = *puVar11;
    piVar10 = (int64_t *)puVar11[1];
    piStackY_10 = piVar10;
    fcn.18003df40(arg1, &ppiStackX_8, &uStackY_18);
    ppiVar7 = *(int64_t ***)0x18077af48;
    if (ppiStackX_8 != *(int64_t ***)0x18077af48) {
        piVar3 = ppiStackX_8[2];
        uVar12 = (((((((((uint64_t)piVar3 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)piVar3 >> 8 & 0xffU) *
                       0x100000001b3 ^ (int64_t)piVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^
                     (int64_t)piVar3 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)piVar3 >> 0x20 & 0xffU) * 0x100000001b3
                   ^ (int64_t)piVar3 >> 0x28 & 0xffU) * 0x100000001b3 ^ (int64_t)piVar3 >> 0x30 & 0xffU) * 0x100000001b3
                 ^ (int64_t)piVar3 >> 0x38 & 0xffU) * 0x100000001b3 & *(uint64_t *)0x18077af70;
        iVar5 = *(int64_t *)0x18077af58 + uVar12 * 0x10;
        ppiVar2 = (int64_t **)(*(int64_t *)0x18077af58 + uVar12 * 0x10);
        ppiVar4 = *(int64_t ***)(*(int64_t *)0x18077af58 + uVar12 * 0x10);
        if (*(int64_t ***)(iVar5 + 8) == ppiStackX_8) {
            if (ppiVar4 == ppiStackX_8) {
                *ppiVar2 = (int64_t *)*(int64_t ***)0x18077af48;
                *(int64_t ***)(iVar5 + 8) = ppiVar7;
            } else {
                *(int64_t **)(iVar5 + 8) = ppiStackX_8[1];
            }
        } else if (ppiVar4 == ppiStackX_8) {
            *ppiVar2 = *ppiStackX_8;
        }
        piVar3 = *ppiStackX_8;
        *(int64_t *)0x18077af50 = *(int64_t *)0x18077af50 + -1;
        *ppiStackX_8[1] = (int64_t)piVar3;
        piVar3[1] = (int64_t)ppiStackX_8[1];
        fcn.18000d070(unaff_RDI);
        fcn.180459c3c(ppiStackX_8, 0x20);
    }
    if (piVar10 != (int64_t *)0x0) {
        LOCK();
        piVar3 = piVar10 + 1;
        iVar9 = *(int32_t *)piVar3;
        *(int32_t *)piVar3 = *(int32_t *)piVar3 + -1;
        UNLOCK();
        if (iVar9 == 1) {
            (**(code **)*piVar10)(piVar10);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
            iVar9 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                (**(code **)(*piVar10 + 8))(piVar10);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180039100
// Address: 0x180039100
// Size: 605 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 fcn.180039100(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    uint64_t arg3;
    uint32_t uVar12;
    int64_t *piVar13;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar2 = *piVar7, *(char *)(iVar2 + 3) != '{')) ||
       ((int64_t *)(iVar2 + 0x10) == (int64_t *)0x0)) goto code_r0x000180039348;
    if (*(int64_t *)(iVar2 + 0x18) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar2 + 0x18) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar11 = *(int64_t *)(iVar2 + 0x10);
    piVar7 = *(int64_t **)(iVar2 + 0x18);
    arg3 = *(uint64_t *)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar8 = (int64_t *)(arg3 + 0x10);
    if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x000180039321;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        arg3 = *(uint64_t *)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar8 = (int64_t *)(arg3 + 0x10);
        if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar8;
    if (iVar2 + 0x18 == 0) {
code_r0x000180039321:
        func_0x000180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    piVar8 = (int64_t *)(arg3 + 0x10);
    piVar10 = piVar8;
    if (piVar13 <= piVar8) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
code_r0x0001800392c2:
        piVar13 = (int64_t *)0x0;
    } else {
        uVar12 = *(uint32_t *)((int64_t)piVar10 + 0xc);
        arg3 = (uint64_t)uVar12;
        if ((uVar12 != 6) && (uVar12 != 3)) goto code_r0x0001800392c2;
        if (piVar13 <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        piVar13 = (int64_t *)0x0;
        if (piVar8 == *(int64_t **)0x180782430) {
            piVar8 = piVar13;
        }
        iVar3 = *piVar8;
        if (iVar3 != 0) {
            uVar12 = *(int32_t *)(iVar3 + 0x10) + 0x10 + (int32_t)iVar3;
            piVar13 = (int64_t *)(uint64_t)uVar12;
            if (uVar12 == 0x743abb) {
                iVar11 = iVar11 + 0x38;
            } else {
                if (uVar12 != 0x16b2) {
                    if (uVar12 == 0xf8aabb18) {
                        fcn.180086570(arg1, (double)*(int32_t *)(iVar11 + 0x48), arg3, piVar13, iVar11, piVar7);
                        goto code_r0x00018003925b;
                    }
                    goto code_r0x0001800392c5;
                }
                iVar11 = iVar11 + 0x40;
            }
            fcn.180038820(arg1, iVar11);
            goto code_r0x00018003925b;
        }
    }
code_r0x0001800392c5:
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar7 + 1) = *(int32_t *)(piVar7 + 1) + 1;
        UNLOCK();
    }
    var_48h._0_4_ = (undefined4)iVar11;
    var_48h._4_4_ = (undefined4)((uint64_t)iVar11 >> 0x20);
    var_40h._0_4_ = SUB84(piVar7, 0);
    var_40h._4_4_ = (undefined4)((uint64_t)piVar7 >> 0x20);
    var_38h._0_4_ = (undefined4)var_48h;
    var_38h._4_4_ = var_48h._4_4_;
    uStack_30 = (undefined4)var_40h;
    uStack_2c = var_40h._4_4_;
    cVar5 = fcn.180038ef0(arg1, (int64_t)&var_38h, arg3, (int64_t)piVar13);
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar7 + 1;
        iVar6 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    if (cVar5 == '\0') {
        fcn.180088560(arg1, 0x180622c78, iVar2 + 0x18);
code_r0x000180039348:
        func_0x0001800883d0(arg1, 1, 0x180622ca0);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
code_r0x00018003925b:
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar7 + 1;
        iVar6 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180039360
// Address: 0x180039360
// Size: 812 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180039360(int64_t arg1)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    double dVar6;
    char cVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    uint64_t arg4;
    undefined4 *puVar13;
    int64_t arg3;
    uint32_t uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (iVar16 = *piVar9, *(char *)(iVar16 + 3) == '{')) &&
       ((int64_t *)(iVar16 + 0x10) != (int64_t *)0x0)) {
        if (*(int64_t *)(iVar16 + 0x18) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(iVar16 + 0x18) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar3 = *(int64_t *)(iVar16 + 0x10);
        piVar9 = *(int64_t **)(iVar16 + 0x18);
        iVar16 = *(int64_t *)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar10 = (int64_t *)(iVar16 + 0x10U);
        if (piVar15 <= (int64_t *)(iVar16 + 0x10U)) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar10 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar8 = func_0x0001800a8360(arg1);
            if (iVar8 == 0) goto code_r0x00018003965a;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            iVar16 = *(int64_t *)(arg1 + 0x28);
            piVar15 = *(int64_t **)(arg1 + 0x40);
            piVar10 = (int64_t *)(iVar16 + 0x10U);
            if (piVar15 <= (int64_t *)(iVar16 + 0x10U)) {
                piVar10 = *(int64_t **)0x180782430;
            }
        }
        arg3 = *piVar10 + 0x18;
        if (arg3 == 0) goto code_r0x00018003965a;
        piVar10 = (int64_t *)(iVar16 + 0x10);
        piVar11 = piVar10;
        if (piVar15 <= piVar10) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if ((piVar11 == *(int64_t **)0x180782430) ||
           ((*(int32_t *)((int64_t)piVar11 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar11 + 0xc) != 3)))) {
code_r0x00018003949b:
            arg4 = 0;
        } else {
            if (piVar15 <= piVar10) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if (piVar10 == *(int64_t **)0x180782430) {
                piVar10 = (int64_t *)0x0;
            }
            iVar4 = *piVar10;
            if (iVar4 == 0) goto code_r0x00018003949b;
            arg4 = (uint64_t)(uint32_t)(*(int32_t *)(iVar4 + 0x10) + 0x10 + (int32_t)iVar4);
        }
        puVar13 = (undefined4 *)0x0;
        piVar10 = (int64_t *)(iVar16 + 0x20);
        piVar11 = piVar10;
        if (piVar15 <= piVar10) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if ((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3, arg4, iVar3, piVar9);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        iVar8 = (int32_t)arg4;
        if (iVar8 == 0x743abb) {
            piVar11 = piVar10;
            if (piVar15 <= piVar10) {
                piVar11 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
                uVar14 = (uint32_t)*(uint8_t *)(*piVar11 + 3);
            } else {
                uVar14 = 0xffffffff;
            }
            if (uVar14 != *(uint32_t *)0x1807823d0) {
                uVar12 = fcn.180038990(arg1);
                fcn.180088560(arg1, 0x180622ac0, arg3, uVar12);
                pcVar5 = (code *)swi(3);
                uVar12 = (*pcVar5)();
                return uVar12;
            }
            if (piVar15 <= piVar10) {
                piVar10 = *(int64_t **)0x180782430;
            }
            iVar8 = *(int32_t *)((int64_t)piVar10 + 0xc);
            if (iVar8 == 2) {
code_r0x000180039514:
                puVar13 = (undefined4 *)*piVar10;
            } else if (iVar8 == 9) {
                puVar13 = (undefined4 *)(*piVar10 + 0x10);
            } else if (5 < iVar8) goto code_r0x000180039514;
            uVar2 = puVar13[1];
            *(undefined4 *)(iVar3 + 0x38) = *puVar13;
            *(undefined4 *)(iVar3 + 0x3c) = uVar2;
code_r0x000180039528:
            if (piVar9 != (int64_t *)0x0) {
                LOCK();
                piVar15 = piVar9 + 1;
                iVar8 = *(int32_t *)piVar15;
                *(int32_t *)piVar15 = *(int32_t *)piVar15 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)*piVar9)(piVar9);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
                    iVar8 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        (**(code **)(*piVar9 + 8))(piVar9);
                    }
                }
            }
            return 0;
        }
        if (iVar8 == 0x16b2) {
            puVar13 = (undefined4 *)fcn.180038a40((int64_t)&var_8h, arg1, *(int64_t **)0x180782430, arg3);
            uVar2 = puVar13[1];
            *(undefined4 *)(iVar3 + 0x40) = *puVar13;
            *(undefined4 *)(iVar3 + 0x44) = uVar2;
            goto code_r0x000180039528;
        }
        if (iVar8 == -0x75544e8) {
            dVar6 = (double)fcn.180038be0(arg1, piVar10, arg3);
            *(int32_t *)(iVar3 + 0x48) = (int32_t)dVar6;
            goto code_r0x000180039528;
        }
        if (piVar9 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar9 + 1) = *(int32_t *)(piVar9 + 1) + 1;
            UNLOCK();
        }
        var_38h._0_4_ = (undefined4)iVar3;
        var_38h._4_4_ = (undefined4)((uint64_t)iVar3 >> 0x20);
        var_30h._0_4_ = SUB84(piVar9, 0);
        var_30h._4_4_ = (undefined4)((uint64_t)piVar9 >> 0x20);
        var_28h._0_4_ = (undefined4)var_38h;
        var_28h._4_4_ = var_38h._4_4_;
        uStack_20 = (undefined4)var_30h;
        uStack_1c = var_30h._4_4_;
        cVar7 = fcn.180038ff0(arg1, (int64_t)&var_28h, arg3, arg4);
        if (piVar9 != (int64_t *)0x0) {
            LOCK();
            piVar15 = piVar9 + 1;
            iVar8 = *(int32_t *)piVar15;
            *(int32_t *)piVar15 = *(int32_t *)piVar15 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)*piVar9)(piVar9);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)(*piVar9 + 8))(piVar9);
                }
            }
        }
        if (cVar7 != '\0') goto code_r0x000180039528;
        fcn.180088560(arg1, 0x180622c78, arg3);
    }
    func_0x0001800883d0();
code_r0x00018003965a:
    func_0x000180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar12 = (*pcVar5)();
    return uVar12;
}

// ============================================================
// Function: FUN_180039690
// Address: 0x180039690
// Size: 645 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

undefined8 fcn.180039690(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    char cVar6;
    int32_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    uint64_t arg3;
    uint32_t uVar12;
    int64_t *piVar13;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar8 + 0xc) != 9) || (iVar2 = *piVar8, *(char *)(iVar2 + 3) != '{')) ||
       ((int64_t *)(iVar2 + 0x10) == (int64_t *)0x0)) goto code_r0x000180039900;
    if (*(int64_t *)(iVar2 + 0x18) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar2 + 0x18) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar3 = *(int64_t *)(iVar2 + 0x10);
    piVar8 = *(int64_t **)(iVar2 + 0x18);
    arg3 = *(uint64_t *)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar9 = (int64_t *)(arg3 + 0x10);
    if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x0001800398d9;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        arg3 = *(uint64_t *)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar9 = (int64_t *)(arg3 + 0x10);
        if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar9;
    if (iVar2 + 0x18 == 0) {
code_r0x0001800398d9:
        func_0x000180088470(arg1, 2, 6);
        pcVar5 = (code *)swi(3);
        uVar10 = (*pcVar5)();
        return uVar10;
    }
    piVar9 = (int64_t *)(arg3 + 0x10);
    piVar11 = piVar9;
    if (piVar13 <= piVar9) {
        piVar11 = *(int64_t **)0x180782430;
    }
    if (piVar11 == *(int64_t **)0x180782430) {
code_r0x00018003987a:
        piVar13 = (int64_t *)0x0;
    } else {
        uVar12 = *(uint32_t *)((int64_t)piVar11 + 0xc);
        arg3 = (uint64_t)uVar12;
        if ((uVar12 != 6) && (uVar12 != 3)) goto code_r0x00018003987a;
        if (piVar13 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        piVar13 = (int64_t *)0x0;
        if (piVar9 == *(int64_t **)0x180782430) {
            piVar9 = piVar13;
        }
        iVar4 = *piVar9;
        if (iVar4 != 0) {
            uVar12 = *(int32_t *)(iVar4 + 0x10) + 0x10 + (int32_t)iVar4;
            piVar13 = (int64_t *)(uint64_t)uVar12;
            if (uVar12 == 0x7c9ab53b) {
                fcn.180038820(arg1, iVar3 + 0x38);
                goto code_r0x000180039807;
            }
            if (uVar12 == 0x86f3e971) {
                iVar7 = *(int32_t *)(iVar3 + 0x44);
            } else if (uVar12 == 0xf8aabb18) {
                iVar7 = *(int32_t *)(iVar3 + 0x48);
            } else {
                if (uVar12 == 0x76da998a) {
                    fcn.180086b20(arg1, *(undefined *)(iVar3 + 0x40), arg3, piVar13, iVar3, piVar8);
                    goto code_r0x000180039807;
                }
                if (uVar12 != 0x5c6ee1d3) goto code_r0x00018003987d;
                iVar7 = *(int32_t *)(iVar3 + 0x4c);
            }
            fcn.180086570(arg1, (double)iVar7);
            goto code_r0x000180039807;
        }
    }
code_r0x00018003987d:
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar8 + 1) = *(int32_t *)(piVar8 + 1) + 1;
        UNLOCK();
    }
    var_48h._0_4_ = (undefined4)iVar3;
    var_48h._4_4_ = (undefined4)((uint64_t)iVar3 >> 0x20);
    var_40h._0_4_ = SUB84(piVar8, 0);
    var_40h._4_4_ = (undefined4)((uint64_t)piVar8 >> 0x20);
    var_38h._0_4_ = (undefined4)var_48h;
    var_38h._4_4_ = var_48h._4_4_;
    uStack_30 = (undefined4)var_40h;
    uStack_2c = var_40h._4_4_;
    cVar6 = fcn.180038ef0(arg1, (int64_t)&var_38h, arg3, (int64_t)piVar13);
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar8 + 1;
        iVar7 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar7 == 1) {
            (**(code **)*piVar8)(piVar8);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)(*piVar8 + 8))(piVar8);
            }
        }
    }
    if (cVar6 == '\0') {
        fcn.180088560(arg1, 0x180622cd8, iVar2 + 0x18);
code_r0x000180039900:
        func_0x0001800883d0(arg1, 1, 0x180622ca0);
        pcVar5 = (code *)swi(3);
        uVar10 = (*pcVar5)();
        return uVar10;
    }
code_r0x000180039807:
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar8 + 1;
        iVar7 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar7 == 1) {
            (**(code **)*piVar8)(piVar8);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)(*piVar8 + 8))(piVar8);
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180039920
// Address: 0x180039920
// Size: 842 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h

undefined8 fcn.180039920(int64_t arg1)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    double dVar6;
    undefined uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    undefined8 uVar13;
    uint64_t arg4;
    undefined4 *puVar14;
    int64_t arg3;
    uint32_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (iVar17 = *piVar10, *(char *)(iVar17 + 3) == '{')) &&
       ((int64_t *)(iVar17 + 0x10) != (int64_t *)0x0)) {
        if (*(int64_t *)(iVar17 + 0x18) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(iVar17 + 0x18) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar3 = *(int64_t *)(iVar17 + 0x10);
        piVar10 = *(int64_t **)(iVar17 + 0x18);
        iVar17 = *(int64_t *)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar11 = (int64_t *)(iVar17 + 0x10U);
        if (piVar16 <= (int64_t *)(iVar17 + 0x10U)) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar9 = func_0x0001800a8360(arg1);
            if (iVar9 == 0) goto code_r0x000180039c38;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            iVar17 = *(int64_t *)(arg1 + 0x28);
            piVar16 = *(int64_t **)(arg1 + 0x40);
            piVar11 = (int64_t *)(iVar17 + 0x10U);
            if (piVar16 <= (int64_t *)(iVar17 + 0x10U)) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        arg3 = *piVar11 + 0x18;
        if (arg3 == 0) goto code_r0x000180039c38;
        piVar11 = (int64_t *)(iVar17 + 0x10);
        piVar12 = piVar11;
        if (piVar16 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((piVar12 == *(int64_t **)0x180782430) ||
           ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x000180039a54:
            arg4 = 0;
        } else {
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = (int64_t *)0x0;
            }
            iVar4 = *piVar11;
            if (iVar4 == 0) goto code_r0x000180039a54;
            arg4 = (uint64_t)(uint32_t)(*(int32_t *)(iVar4 + 0x10) + 0x10 + (int32_t)iVar4);
        }
        puVar14 = (undefined4 *)0x0;
        piVar11 = (int64_t *)(iVar17 + 0x20);
        piVar12 = piVar11;
        if (piVar16 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3, arg4, iVar3, piVar10);
            pcVar5 = (code *)swi(3);
            uVar13 = (*pcVar5)();
            return uVar13;
        }
        iVar9 = (int32_t)arg4;
        if (iVar9 == 0x7c9ab53b) {
            piVar12 = piVar11;
            if (piVar16 <= piVar11) {
                piVar12 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar12 + 0xc) == 9) {
                uVar15 = (uint32_t)*(uint8_t *)(*piVar12 + 3);
            } else {
                uVar15 = 0xffffffff;
            }
            if (uVar15 != *(uint32_t *)0x1807823d0) {
                uVar13 = fcn.180038990(arg1);
                fcn.180088560(arg1, 0x180622ac0, arg3, uVar13);
                pcVar5 = (code *)swi(3);
                uVar13 = (*pcVar5)();
                return uVar13;
            }
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            iVar9 = *(int32_t *)((int64_t)piVar11 + 0xc);
            if (iVar9 == 2) {
code_r0x000180039acd:
                puVar14 = (undefined4 *)*piVar11;
            } else if (iVar9 == 9) {
                puVar14 = (undefined4 *)(*piVar11 + 0x10);
            } else if (5 < iVar9) goto code_r0x000180039acd;
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x38) = *puVar14;
            *(undefined4 *)(iVar3 + 0x3c) = uVar2;
code_r0x000180039ae1:
            if (piVar10 != (int64_t *)0x0) {
                LOCK();
                piVar16 = piVar10 + 1;
                iVar9 = *(int32_t *)piVar16;
                *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)*piVar10)(piVar10);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar10 + 8))(piVar10);
                    }
                }
            }
            return 0;
        }
        if (iVar9 == -0x790c168f) {
            dVar6 = (double)fcn.180038be0(arg1, piVar11, arg3);
            *(int32_t *)(iVar3 + 0x44) = (int32_t)dVar6;
            goto code_r0x000180039ae1;
        }
        if (iVar9 == -0x75544e8) {
            dVar6 = (double)fcn.180038be0(arg1, piVar11, arg3);
            *(int32_t *)(iVar3 + 0x48) = (int32_t)dVar6;
            goto code_r0x000180039ae1;
        }
        if (iVar9 == 0x76da998a) {
            uVar7 = fcn.180038b70(arg1, piVar11, arg3);
            *(undefined *)(iVar3 + 0x40) = uVar7;
            goto code_r0x000180039ae1;
        }
        if (iVar9 == 0x5c6ee1d3) {
            dVar6 = (double)fcn.180038be0(arg1, piVar11, arg3);
            *(int32_t *)(iVar3 + 0x4c) = (int32_t)dVar6;
            goto code_r0x000180039ae1;
        }
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar10 + 1) = *(int32_t *)(piVar10 + 1) + 1;
            UNLOCK();
        }
        var_48h._0_4_ = (undefined4)iVar3;
        var_48h._4_4_ = (undefined4)((uint64_t)iVar3 >> 0x20);
        var_40h._0_4_ = SUB84(piVar10, 0);
        var_40h._4_4_ = (undefined4)((uint64_t)piVar10 >> 0x20);
        var_38h._0_4_ = (undefined4)var_48h;
        var_38h._4_4_ = var_48h._4_4_;
        uStack_30 = (undefined4)var_40h;
        uStack_2c = var_40h._4_4_;
        cVar8 = fcn.180038ff0(arg1, (int64_t)&var_38h, arg3, arg4);
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            piVar16 = piVar10 + 1;
            iVar9 = *(int32_t *)piVar16;
            *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                (**(code **)*piVar10)(piVar10);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                iVar9 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)(*piVar10 + 8))(piVar10);
                }
            }
        }
        if (cVar8 != '\0') goto code_r0x000180039ae1;
        fcn.180088560(arg1, 0x180622cd8, arg3);
    }
    func_0x0001800883d0();
code_r0x000180039c38:
    func_0x000180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar13 = (*pcVar5)();
    return uVar13;
}

// ============================================================
// Function: FUN_180039c70
// Address: 0x180039c70
// Size: 628 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel

undefined8 fcn.180039c70(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    uint64_t arg3;
    uint32_t uVar12;
    int64_t *piVar13;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar2 = *piVar7, *(char *)(iVar2 + 3) != '{')) ||
       ((int64_t *)(iVar2 + 0x10) == (int64_t *)0x0)) goto code_r0x000180039ecf;
    if (*(int64_t *)(iVar2 + 0x18) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar2 + 0x18) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar11 = *(int64_t *)(iVar2 + 0x10);
    piVar7 = *(int64_t **)(iVar2 + 0x18);
    arg3 = *(uint64_t *)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar8 = (int64_t *)(arg3 + 0x10);
    if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x000180039ea8;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        arg3 = *(uint64_t *)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar8 = (int64_t *)(arg3 + 0x10);
        if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar8;
    if (iVar2 + 0x18 == 0) {
code_r0x000180039ea8:
        func_0x000180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    piVar8 = (int64_t *)(arg3 + 0x10);
    piVar10 = piVar8;
    if (piVar13 <= piVar8) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
code_r0x000180039e49:
        piVar13 = (int64_t *)0x0;
    } else {
        uVar12 = *(uint32_t *)((int64_t)piVar10 + 0xc);
        arg3 = (uint64_t)uVar12;
        if ((uVar12 != 6) && (uVar12 != 3)) goto code_r0x000180039e49;
        if (piVar13 <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        piVar13 = (int64_t *)0x0;
        if (piVar8 == *(int64_t **)0x180782430) {
            piVar8 = piVar13;
        }
        iVar3 = *piVar8;
        if (iVar3 != 0) {
            uVar12 = *(int32_t *)(iVar3 + 0x10) + 0x10 + (int32_t)iVar3;
            piVar13 = (int64_t *)(uint64_t)uVar12;
            if (uVar12 == 0x7c9ab53b) {
                iVar11 = iVar11 + 0x38;
            } else {
                if (uVar12 != 0x70002f) {
                    if (uVar12 == 0xf8aabb18) {
                        fcn.180086570(arg1, (double)*(int32_t *)(iVar11 + 0x48));
                        goto code_r0x000180039dcb;
                    }
                    if (uVar12 == 0x76da998a) {
                        fcn.180086b20(arg1, *(undefined *)(iVar11 + 0x4c), arg3, piVar13, iVar11, piVar7);
                        goto code_r0x000180039dcb;
                    }
                    goto code_r0x000180039e4c;
                }
                iVar11 = iVar11 + 0x40;
            }
            fcn.180038820(arg1, iVar11);
            goto code_r0x000180039dcb;
        }
    }
code_r0x000180039e4c:
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar7 + 1) = *(int32_t *)(piVar7 + 1) + 1;
        UNLOCK();
    }
    var_48h._0_4_ = (undefined4)iVar11;
    var_48h._4_4_ = (undefined4)((uint64_t)iVar11 >> 0x20);
    var_40h._0_4_ = SUB84(piVar7, 0);
    var_40h._4_4_ = (undefined4)((uint64_t)piVar7 >> 0x20);
    var_38h._0_4_ = (undefined4)var_48h;
    var_38h._4_4_ = var_48h._4_4_;
    uStack_30 = (undefined4)var_40h;
    uStack_2c = var_40h._4_4_;
    cVar5 = fcn.180038ef0(arg1, (int64_t)&var_38h, arg3, (int64_t)piVar13);
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar7 + 1;
        iVar6 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    if (cVar5 == '\0') {
        fcn.180088560(arg1, 0x180622cb0, iVar2 + 0x18);
code_r0x000180039ecf:
        func_0x0001800883d0(arg1, 1, 0x180622ca0);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
code_r0x000180039dcb:
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar7 + 1;
        iVar6 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180039ef0
// Address: 0x180039ef0
// Size: 841 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180039ef0(int64_t arg1)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    double dVar6;
    undefined uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    undefined8 uVar13;
    uint64_t arg4;
    undefined4 *puVar14;
    int64_t arg3;
    uint32_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (iVar17 = *piVar10, *(char *)(iVar17 + 3) == '{')) &&
       ((int64_t *)(iVar17 + 0x10) != (int64_t *)0x0)) {
        if (*(int64_t *)(iVar17 + 0x18) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(iVar17 + 0x18) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar3 = *(int64_t *)(iVar17 + 0x10);
        piVar10 = *(int64_t **)(iVar17 + 0x18);
        iVar17 = *(int64_t *)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar11 = (int64_t *)(iVar17 + 0x10U);
        if (piVar16 <= (int64_t *)(iVar17 + 0x10U)) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar9 = func_0x0001800a8360(arg1);
            if (iVar9 == 0) goto code_r0x00018003a207;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            iVar17 = *(int64_t *)(arg1 + 0x28);
            piVar16 = *(int64_t **)(arg1 + 0x40);
            piVar11 = (int64_t *)(iVar17 + 0x10U);
            if (piVar16 <= (int64_t *)(iVar17 + 0x10U)) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        arg3 = *piVar11 + 0x18;
        if (arg3 == 0) goto code_r0x00018003a207;
        piVar11 = (int64_t *)(iVar17 + 0x10);
        piVar12 = piVar11;
        if (piVar16 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((piVar12 == *(int64_t **)0x180782430) ||
           ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x00018003a02b:
            arg4 = 0;
        } else {
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = (int64_t *)0x0;
            }
            iVar4 = *piVar11;
            if (iVar4 == 0) goto code_r0x00018003a02b;
            arg4 = (uint64_t)(uint32_t)(*(int32_t *)(iVar4 + 0x10) + 0x10 + (int32_t)iVar4);
        }
        puVar14 = (undefined4 *)0x0;
        piVar11 = (int64_t *)(iVar17 + 0x20);
        piVar12 = piVar11;
        if (piVar16 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3, arg4, iVar3, piVar10);
            pcVar5 = (code *)swi(3);
            uVar13 = (*pcVar5)();
            return uVar13;
        }
        iVar9 = (int32_t)arg4;
        if (iVar9 == 0x7c9ab53b) {
            piVar12 = piVar11;
            if (piVar16 <= piVar11) {
                piVar12 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar12 + 0xc) == 9) {
                uVar15 = (uint32_t)*(uint8_t *)(*piVar12 + 3);
            } else {
                uVar15 = 0xffffffff;
            }
            if (uVar15 != *(uint32_t *)0x1807823d0) {
                uVar13 = fcn.180038990(arg1);
                fcn.180088560(arg1, 0x180622ac0, arg3, uVar13);
                pcVar5 = (code *)swi(3);
                uVar13 = (*pcVar5)();
                return uVar13;
            }
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            iVar9 = *(int32_t *)((int64_t)piVar11 + 0xc);
            if (iVar9 == 2) {
code_r0x00018003a0a4:
                puVar14 = (undefined4 *)*piVar11;
            } else if (iVar9 == 9) {
                puVar14 = (undefined4 *)(*piVar11 + 0x10);
            } else if (5 < iVar9) goto code_r0x00018003a0a4;
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x38) = *puVar14;
            *(undefined4 *)(iVar3 + 0x3c) = uVar2;
code_r0x00018003a0b8:
            if (piVar10 != (int64_t *)0x0) {
                LOCK();
                piVar16 = piVar10 + 1;
                iVar9 = *(int32_t *)piVar16;
                *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)*piVar10)(piVar10);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar10 + 8))(piVar10);
                    }
                }
            }
            return 0;
        }
        if (iVar9 == 0x70002f) {
            puVar14 = (undefined4 *)fcn.180038a40((int64_t)&var_8h, arg1, *(int64_t **)0x180782430, arg3);
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x40) = *puVar14;
            *(undefined4 *)(iVar3 + 0x44) = uVar2;
            goto code_r0x00018003a0b8;
        }
        if (iVar9 == -0x75544e8) {
            dVar6 = (double)fcn.180038be0(arg1, piVar11, arg3);
            *(int32_t *)(iVar3 + 0x48) = (int32_t)dVar6;
            goto code_r0x00018003a0b8;
        }
        if (iVar9 == 0x76da998a) {
            uVar7 = fcn.180038b70(arg1, piVar11, arg3);
            *(undefined *)(iVar3 + 0x4c) = uVar7;
            goto code_r0x00018003a0b8;
        }
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar10 + 1) = *(int32_t *)(piVar10 + 1) + 1;
            UNLOCK();
        }
        var_38h._0_4_ = (undefined4)iVar3;
        var_38h._4_4_ = (undefined4)((uint64_t)iVar3 >> 0x20);
        var_30h._0_4_ = SUB84(piVar10, 0);
        var_30h._4_4_ = (undefined4)((uint64_t)piVar10 >> 0x20);
        var_28h._0_4_ = (undefined4)var_38h;
        var_28h._4_4_ = var_38h._4_4_;
        uStack_20 = (undefined4)var_30h;
        uStack_1c = var_30h._4_4_;
        cVar8 = fcn.180038ff0(arg1, (int64_t)&var_28h, arg3, arg4);
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            piVar16 = piVar10 + 1;
            iVar9 = *(int32_t *)piVar16;
            *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                (**(code **)*piVar10)(piVar10);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                iVar9 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)(*piVar10 + 8))(piVar10);
                }
            }
        }
        if (cVar8 != '\0') goto code_r0x00018003a0b8;
        fcn.180088560(arg1, 0x180622cb0, arg3);
    }
    func_0x0001800883d0();
code_r0x00018003a207:
    func_0x000180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar13 = (*pcVar5)();
    return uVar13;
}

// ============================================================
// Function: FUN_18003a240
// Address: 0x18003a240
// Size: 646 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_54h because it doesn't fit into ProtoModel

undefined8 fcn.18003a240(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    uint64_t arg3;
    uint32_t uVar12;
    int64_t *piVar13;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar2 = *piVar7, *(char *)(iVar2 + 3) != '{')) ||
       ((int64_t *)(iVar2 + 0x10) == (int64_t *)0x0)) goto code_r0x00018003a4b1;
    if (*(int64_t *)(iVar2 + 0x18) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar2 + 0x18) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar11 = *(int64_t *)(iVar2 + 0x10);
    piVar7 = *(int64_t **)(iVar2 + 0x18);
    arg3 = *(uint64_t *)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar8 = (int64_t *)(arg3 + 0x10);
    if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018003a48a;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        arg3 = *(uint64_t *)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar8 = (int64_t *)(arg3 + 0x10);
        if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar8;
    if (iVar2 + 0x18 == 0) {
code_r0x00018003a48a:
        func_0x000180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    piVar8 = (int64_t *)(arg3 + 0x10);
    piVar10 = piVar8;
    if (piVar13 <= piVar8) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
code_r0x00018003a42b:
        piVar13 = (int64_t *)0x0;
    } else {
        uVar12 = *(uint32_t *)((int64_t)piVar10 + 0xc);
        arg3 = (uint64_t)uVar12;
        if ((uVar12 != 6) && (uVar12 != 3)) goto code_r0x00018003a42b;
        if (piVar13 <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        piVar13 = (int64_t *)0x0;
        if (piVar8 == *(int64_t **)0x180782430) {
            piVar8 = piVar13;
        }
        iVar3 = *piVar8;
        if (iVar3 != 0) {
            uVar12 = *(int32_t *)(iVar3 + 0x10) + 0x10 + (int32_t)iVar3;
            piVar13 = (int64_t *)(uint64_t)uVar12;
            if (uVar12 == 0x33b250a2) {
                iVar11 = iVar11 + 0x38;
            } else if (uVar12 == 0x1514ae42) {
                iVar11 = iVar11 + 0x40;
            } else {
                if (uVar12 != 0x2e38559f) {
                    if (uVar12 == 0xf8aabb18) {
                        fcn.180086570(arg1, (double)*(int32_t *)(iVar11 + 0x50));
                        goto code_r0x00018003a39b;
                    }
                    if (uVar12 == 0x76da998a) {
                        fcn.180086b20(arg1, *(undefined *)(iVar11 + 0x54), arg3, piVar13, iVar11, piVar7);
                        goto code_r0x00018003a39b;
                    }
                    goto code_r0x00018003a42e;
                }
                iVar11 = iVar11 + 0x48;
            }
            fcn.180038820(arg1, iVar11);
            goto code_r0x00018003a39b;
        }
    }
code_r0x00018003a42e:
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar7 + 1) = *(int32_t *)(piVar7 + 1) + 1;
        UNLOCK();
    }
    var_48h._0_4_ = (undefined4)iVar11;
    var_48h._4_4_ = (undefined4)((uint64_t)iVar11 >> 0x20);
    var_40h._0_4_ = SUB84(piVar7, 0);
    var_40h._4_4_ = (undefined4)((uint64_t)piVar7 >> 0x20);
    var_38h._0_4_ = (undefined4)var_48h;
    var_38h._4_4_ = var_48h._4_4_;
    uStack_30 = (undefined4)var_40h;
    uStack_2c = var_40h._4_4_;
    cVar5 = fcn.180038ef0(arg1, (int64_t)&var_38h, arg3, (int64_t)piVar13);
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar7 + 1;
        iVar6 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    if (cVar5 == '\0') {
        fcn.180088560(arg1, 0x180622d28, iVar2 + 0x18);
code_r0x00018003a4b1:
        func_0x0001800883d0(arg1, 1, 0x180622ca0);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
code_r0x00018003a39b:
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar7 + 1;
        iVar6 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18003a4d0
// Address: 0x18003a4d0
// Size: 888 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18003a4d0(int64_t arg1)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    double dVar6;
    undefined uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    undefined8 uVar13;
    uint64_t arg4;
    undefined4 *puVar14;
    int64_t arg3;
    uint32_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (iVar17 = *piVar10, *(char *)(iVar17 + 3) == '{')) &&
       ((int64_t *)(iVar17 + 0x10) != (int64_t *)0x0)) {
        if (*(int64_t *)(iVar17 + 0x18) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(iVar17 + 0x18) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar3 = *(int64_t *)(iVar17 + 0x10);
        piVar10 = *(int64_t **)(iVar17 + 0x18);
        iVar17 = *(int64_t *)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar11 = (int64_t *)(iVar17 + 0x10U);
        if (piVar16 <= (int64_t *)(iVar17 + 0x10U)) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar9 = func_0x0001800a8360(arg1);
            if (iVar9 == 0) goto code_r0x00018003a816;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            iVar17 = *(int64_t *)(arg1 + 0x28);
            piVar16 = *(int64_t **)(arg1 + 0x40);
            piVar11 = (int64_t *)(iVar17 + 0x10U);
            if (piVar16 <= (int64_t *)(iVar17 + 0x10U)) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        arg3 = *piVar11 + 0x18;
        if (arg3 == 0) goto code_r0x00018003a816;
        piVar11 = (int64_t *)(iVar17 + 0x10);
        piVar12 = piVar11;
        if (piVar16 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((piVar12 == *(int64_t **)0x180782430) ||
           ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x00018003a60b:
            arg4 = 0;
        } else {
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = (int64_t *)0x0;
            }
            iVar4 = *piVar11;
            if (iVar4 == 0) goto code_r0x00018003a60b;
            arg4 = (uint64_t)(uint32_t)(*(int32_t *)(iVar4 + 0x10) + 0x10 + (int32_t)iVar4);
        }
        puVar14 = (undefined4 *)0x0;
        piVar11 = (int64_t *)(iVar17 + 0x20);
        piVar12 = piVar11;
        if (piVar16 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3, arg4, iVar3, piVar10);
            pcVar5 = (code *)swi(3);
            uVar13 = (*pcVar5)();
            return uVar13;
        }
        iVar9 = (int32_t)arg4;
        if (iVar9 == 0x33b250a2) {
            piVar12 = piVar11;
            if (piVar16 <= piVar11) {
                piVar12 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar12 + 0xc) == 9) {
                uVar15 = (uint32_t)*(uint8_t *)(*piVar12 + 3);
            } else {
                uVar15 = 0xffffffff;
            }
            if (uVar15 != *(uint32_t *)0x1807823d0) {
                uVar13 = fcn.180038990(arg1);
                fcn.180088560(arg1, 0x180622ac0, arg3, uVar13);
                pcVar5 = (code *)swi(3);
                uVar13 = (*pcVar5)();
                return uVar13;
            }
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            iVar9 = *(int32_t *)((int64_t)piVar11 + 0xc);
            if (iVar9 == 2) {
code_r0x00018003a684:
                puVar14 = (undefined4 *)*piVar11;
            } else if (iVar9 == 9) {
                puVar14 = (undefined4 *)(*piVar11 + 0x10);
            } else if (5 < iVar9) goto code_r0x00018003a684;
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x38) = *puVar14;
            *(undefined4 *)(iVar3 + 0x3c) = uVar2;
code_r0x00018003a698:
            if (piVar10 != (int64_t *)0x0) {
                LOCK();
                piVar16 = piVar10 + 1;
                iVar9 = *(int32_t *)piVar16;
                *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)*piVar10)(piVar10);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar10 + 8))(piVar10);
                    }
                }
            }
            return 0;
        }
        if (iVar9 == 0x1514ae42) {
            puVar14 = (undefined4 *)fcn.180038a40((int64_t)&var_8h, arg1, *(int64_t **)0x180782430, arg3);
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x40) = *puVar14;
            *(undefined4 *)(iVar3 + 0x44) = uVar2;
            goto code_r0x00018003a698;
        }
        if (iVar9 == 0x2e38559f) {
            puVar14 = (undefined4 *)fcn.180038a40((int64_t)&var_8h, arg1, *(int64_t **)0x180782430, arg3);
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x48) = *puVar14;
            *(undefined4 *)(iVar3 + 0x4c) = uVar2;
            goto code_r0x00018003a698;
        }
        if (iVar9 == -0x75544e8) {
            dVar6 = (double)fcn.180038be0(arg1, piVar11, arg3);
            *(int32_t *)(iVar3 + 0x50) = (int32_t)dVar6;
            goto code_r0x00018003a698;
        }
        if (iVar9 == 0x76da998a) {
            uVar7 = fcn.180038b70(arg1, piVar11, arg3);
            *(undefined *)(iVar3 + 0x54) = uVar7;
            goto code_r0x00018003a698;
        }
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar10 + 1) = *(int32_t *)(piVar10 + 1) + 1;
            UNLOCK();
        }
        var_38h._0_4_ = (undefined4)iVar3;
        var_38h._4_4_ = (undefined4)((uint64_t)iVar3 >> 0x20);
        var_30h._0_4_ = SUB84(piVar10, 0);
        var_30h._4_4_ = (undefined4)((uint64_t)piVar10 >> 0x20);
        var_28h._0_4_ = (undefined4)var_38h;
        var_28h._4_4_ = var_38h._4_4_;
        uStack_20 = (undefined4)var_30h;
        uStack_1c = var_30h._4_4_;
        cVar8 = fcn.180038ff0(arg1, (int64_t)&var_28h, arg3, arg4);
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            piVar16 = piVar10 + 1;
            iVar9 = *(int32_t *)piVar16;
            *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                (**(code **)*piVar10)(piVar10);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                iVar9 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)(*piVar10 + 8))(piVar10);
                }
            }
        }
        if (cVar8 != '\0') goto code_r0x00018003a698;
        fcn.180088560(arg1, 0x180622d28, arg3);
    }
    func_0x0001800883d0();
code_r0x00018003a816:
    func_0x000180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar13 = (*pcVar5)();
    return uVar13;
}

// ============================================================
// Function: FUN_18003a850
// Address: 0x18003a850
// Size: 664 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Removing arg arg_5ch because it doesn't fit into ProtoModel

undefined8
fcn.18003a850(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    char cVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t iVar11;
    uint64_t arg3;
    uint32_t uVar12;
    int64_t *piVar13;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar2 = *piVar7, *(char *)(iVar2 + 3) != '{')) ||
       ((int64_t *)(iVar2 + 0x10) == (int64_t *)0x0)) goto code_r0x00018003aad3;
    if (*(int64_t *)(iVar2 + 0x18) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar2 + 0x18) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar11 = *(int64_t *)(iVar2 + 0x10);
    piVar7 = *(int64_t **)(iVar2 + 0x18);
    arg3 = *(uint64_t *)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar8 = (int64_t *)(arg3 + 0x10);
    if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018003aaac;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        arg3 = *(uint64_t *)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar8 = (int64_t *)(arg3 + 0x10);
        if (piVar13 <= (int64_t *)(arg3 + 0x10)) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar8;
    if (iVar2 + 0x18 == 0) {
code_r0x00018003aaac:
        func_0x000180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
    piVar8 = (int64_t *)(arg3 + 0x10);
    piVar10 = piVar8;
    if (piVar13 <= piVar8) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (piVar10 == *(int64_t **)0x180782430) {
code_r0x00018003aa4d:
        piVar13 = (int64_t *)0x0;
    } else {
        uVar12 = *(uint32_t *)((int64_t)piVar10 + 0xc);
        arg3 = (uint64_t)uVar12;
        if ((uVar12 != 6) && (uVar12 != 3)) goto code_r0x00018003aa4d;
        if (piVar13 <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        piVar13 = (int64_t *)0x0;
        if (piVar8 == *(int64_t **)0x180782430) {
            piVar8 = piVar13;
        }
        iVar3 = *piVar8;
        if (iVar3 != 0) {
            uVar12 = *(int32_t *)(iVar3 + 0x10) + 0x10 + (int32_t)iVar3;
            piVar13 = (int64_t *)(uint64_t)uVar12;
            if (uVar12 == 0x33b250a2) {
                iVar11 = iVar11 + 0x38;
            } else if (uVar12 == 0x1514ae42) {
                iVar11 = iVar11 + 0x40;
            } else if (uVar12 == 0x2e38559f) {
                iVar11 = iVar11 + 0x48;
            } else {
                if (uVar12 != 0x3191a364) {
                    if (uVar12 == 0xf8aabb18) {
                        fcn.180086570(arg1, (double)*(int32_t *)(iVar11 + 0x58));
                        goto code_r0x00018003a9ab;
                    }
                    if (uVar12 == 0x76da998a) {
                        fcn.180086b20(arg1, *(undefined *)(iVar11 + 0x5c), arg3, piVar13, iVar11, piVar7);
                        goto code_r0x00018003a9ab;
                    }
                    goto code_r0x00018003aa50;
                }
                iVar11 = iVar11 + 0x50;
            }
            fcn.180038820(arg1, iVar11);
            goto code_r0x00018003a9ab;
        }
    }
code_r0x00018003aa50:
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar7 + 1) = *(int32_t *)(piVar7 + 1) + 1;
        UNLOCK();
    }
    var_48h._0_4_ = (undefined4)iVar11;
    var_48h._4_4_ = (undefined4)((uint64_t)iVar11 >> 0x20);
    var_40h._0_4_ = SUB84(piVar7, 0);
    var_40h._4_4_ = (undefined4)((uint64_t)piVar7 >> 0x20);
    var_38h._0_4_ = (undefined4)var_48h;
    var_38h._4_4_ = var_48h._4_4_;
    uStack_30 = (undefined4)var_40h;
    uStack_2c = var_40h._4_4_;
    cVar5 = fcn.180038ef0(arg1, (int64_t)&var_38h, arg3, (int64_t)piVar13);
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar7 + 1;
        iVar6 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    if (cVar5 == '\0') {
        fcn.180088560(arg1, 0x180622d00, iVar2 + 0x18);
code_r0x00018003aad3:
        func_0x0001800883d0(arg1, 1, 0x180622ca0);
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
    }
code_r0x00018003a9ab:
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar13 = piVar7 + 1;
        iVar6 = *(int32_t *)piVar13;
        *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18003aaf0
// Address: 0x18003aaf0
// Size: 935 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18003aaf0(int64_t arg1)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    double dVar6;
    undefined uVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    undefined8 uVar13;
    uint64_t arg4;
    undefined4 *puVar14;
    int64_t arg3;
    uint32_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (iVar17 = *piVar10, *(char *)(iVar17 + 3) == '{')) &&
       ((int64_t *)(iVar17 + 0x10) != (int64_t *)0x0)) {
        if (*(int64_t *)(iVar17 + 0x18) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(iVar17 + 0x18) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar3 = *(int64_t *)(iVar17 + 0x10);
        piVar10 = *(int64_t **)(iVar17 + 0x18);
        iVar17 = *(int64_t *)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar11 = (int64_t *)(iVar17 + 0x10U);
        if (piVar16 <= (int64_t *)(iVar17 + 0x10U)) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar9 = func_0x0001800a8360(arg1);
            if (iVar9 == 0) goto code_r0x00018003ae65;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            iVar17 = *(int64_t *)(arg1 + 0x28);
            piVar16 = *(int64_t **)(arg1 + 0x40);
            piVar11 = (int64_t *)(iVar17 + 0x10U);
            if (piVar16 <= (int64_t *)(iVar17 + 0x10U)) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        arg3 = *piVar11 + 0x18;
        if (arg3 == 0) goto code_r0x00018003ae65;
        piVar11 = (int64_t *)(iVar17 + 0x10);
        piVar12 = piVar11;
        if (piVar16 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((piVar12 == *(int64_t **)0x180782430) ||
           ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x00018003ac2b:
            arg4 = 0;
        } else {
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = (int64_t *)0x0;
            }
            iVar4 = *piVar11;
            if (iVar4 == 0) goto code_r0x00018003ac2b;
            arg4 = (uint64_t)(uint32_t)(*(int32_t *)(iVar4 + 0x10) + 0x10 + (int32_t)iVar4);
        }
        puVar14 = (undefined4 *)0x0;
        piVar11 = (int64_t *)(iVar17 + 0x20);
        piVar12 = piVar11;
        if (piVar16 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) == -1)) {
            fcn.180088560(arg1, 0x18063da20, 3, arg4, iVar3, piVar10);
            pcVar5 = (code *)swi(3);
            uVar13 = (*pcVar5)();
            return uVar13;
        }
        iVar9 = (int32_t)arg4;
        if (iVar9 == 0x33b250a2) {
            piVar12 = piVar11;
            if (piVar16 <= piVar11) {
                piVar12 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar12 + 0xc) == 9) {
                uVar15 = (uint32_t)*(uint8_t *)(*piVar12 + 3);
            } else {
                uVar15 = 0xffffffff;
            }
            if (uVar15 != *(uint32_t *)0x1807823d0) {
                uVar13 = fcn.180038990(arg1);
                fcn.180088560(arg1, 0x180622ac0, arg3, uVar13);
                pcVar5 = (code *)swi(3);
                uVar13 = (*pcVar5)();
                return uVar13;
            }
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            iVar9 = *(int32_t *)((int64_t)piVar11 + 0xc);
            if (iVar9 == 2) {
code_r0x00018003aca4:
                puVar14 = (undefined4 *)*piVar11;
            } else if (iVar9 == 9) {
                puVar14 = (undefined4 *)(*piVar11 + 0x10);
            } else if (5 < iVar9) goto code_r0x00018003aca4;
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x38) = *puVar14;
            *(undefined4 *)(iVar3 + 0x3c) = uVar2;
code_r0x00018003acb8:
            if (piVar10 != (int64_t *)0x0) {
                LOCK();
                piVar16 = piVar10 + 1;
                iVar9 = *(int32_t *)piVar16;
                *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)*piVar10)(piVar10);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar10 + 8))(piVar10);
                    }
                }
            }
            return 0;
        }
        if (iVar9 == 0x1514ae42) {
            puVar14 = (undefined4 *)fcn.180038a40((int64_t)&var_8h, arg1, *(int64_t **)0x180782430, arg3);
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x40) = *puVar14;
            *(undefined4 *)(iVar3 + 0x44) = uVar2;
            goto code_r0x00018003acb8;
        }
        if (iVar9 == 0x2e38559f) {
            puVar14 = (undefined4 *)fcn.180038a40((int64_t)&var_8h, arg1, *(int64_t **)0x180782430, arg3);
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x48) = *puVar14;
            *(undefined4 *)(iVar3 + 0x4c) = uVar2;
            goto code_r0x00018003acb8;
        }
        if (iVar9 == 0x3191a364) {
            puVar14 = (undefined4 *)fcn.180038a40((int64_t)&var_8h, arg1, *(int64_t **)0x180782430, arg3);
            uVar2 = puVar14[1];
            *(undefined4 *)(iVar3 + 0x50) = *puVar14;
            *(undefined4 *)(iVar3 + 0x54) = uVar2;
            goto code_r0x00018003acb8;
        }
        if (iVar9 == -0x75544e8) {
            dVar6 = (double)fcn.180038be0(arg1, piVar11, arg3);
            *(int32_t *)(iVar3 + 0x58) = (int32_t)dVar6;
            goto code_r0x00018003acb8;
        }
        if (iVar9 == 0x76da998a) {
            uVar7 = fcn.180038b70(arg1, piVar11, arg3);
            *(undefined *)(iVar3 + 0x5c) = uVar7;
            goto code_r0x00018003acb8;
        }
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar10 + 1) = *(int32_t *)(piVar10 + 1) + 1;
            UNLOCK();
        }
        var_38h._0_4_ = (undefined4)iVar3;
        var_38h._4_4_ = (undefined4)((uint64_t)iVar3 >> 0x20);
        var_30h._0_4_ = SUB84(piVar10, 0);
        var_30h._4_4_ = (undefined4)((uint64_t)piVar10 >> 0x20);
        var_28h._0_4_ = (undefined4)var_38h;
        var_28h._4_4_ = var_38h._4_4_;
        uStack_20 = (undefined4)var_30h;
        uStack_1c = var_30h._4_4_;
        cVar8 = fcn.180038ff0(arg1, (int64_t)&var_28h, arg3, arg4);
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            piVar16 = piVar10 + 1;
            iVar9 = *(int32_t *)piVar16;
            *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                (**(code **)*piVar10)(piVar10);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                iVar9 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)(*piVar10 + 8))(piVar10);
                }
            }
        }
        if (cVar8 != '\0') goto code_r0x00018003acb8;
        fcn.180088560(arg1, 0x180622d00, arg3);
    }
    func_0x0001800883d0();
code_r0x00018003ae65:
    func_0x000180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar13 = (*pcVar5)();
    return uVar13;
}

// ============================================================
// Function: FUN_18003aea0
// Address: 0x18003aea0
// Size: 1308 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_74h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_79h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

undefined8 fcn.18003aea0(int64_t arg1, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h, int64_t arg_78h)
{
    int32_t *piVar1;
    char **ppcVar2;
    float fVar3;
    float fVar4;
    int64_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    char cVar8;
    int32_t iVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint32_t *puVar14;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined8 *puVar17;
    char **ppcVar18;
    uint32_t uVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_28h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) == 9) && (iVar13 = *piVar10, *(char *)(iVar13 + 3) == '{')) &&
       ((int64_t *)(iVar13 + 0x10) != (int64_t *)0x0)) {
        if (*(int64_t *)(iVar13 + 0x18) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(iVar13 + 0x18) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar5 = *(int64_t *)(iVar13 + 0x10);
        piVar10 = *(int64_t **)(iVar13 + 0x18);
        iVar13 = *(int64_t *)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar11 = (int64_t *)(iVar13 + 0x10U);
        if (piVar16 <= (int64_t *)(iVar13 + 0x10U)) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar9 = func_0x0001800a8360(arg1, piVar11, piVar16, iVar13, iVar5, piVar10);
            if (iVar9 == 0) goto code_r0x00018003b3a8;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            iVar13 = *(int64_t *)(arg1 + 0x28);
            piVar16 = *(int64_t **)(arg1 + 0x40);
            piVar11 = (int64_t *)(iVar13 + 0x10U);
            if (piVar16 <= (int64_t *)(iVar13 + 0x10U)) {
                piVar11 = *(int64_t **)0x180782430;
            }
        }
        iVar6 = *piVar11;
        if (iVar6 + 0x18 == 0) goto code_r0x00018003b3a8;
        piVar11 = (int64_t *)(iVar13 + 0x10);
        piVar15 = piVar11;
        if (piVar16 <= piVar11) {
            piVar15 = *(int64_t **)0x180782430;
        }
        if ((piVar15 == *(int64_t **)0x180782430) ||
           ((*(int32_t *)((int64_t)piVar15 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar15 + 0xc) != 3)))) {
            piVar15 = (int64_t *)0x0;
        } else {
            if (piVar16 <= piVar11) {
                piVar11 = *(int64_t **)0x180782430;
            }
            piVar15 = (int64_t *)0x0;
            if (piVar11 == *(int64_t **)0x180782430) {
                piVar11 = piVar15;
            }
            iVar13 = *piVar11;
            if (iVar13 != 0) {
                uVar19 = *(int32_t *)(iVar13 + 0x10) + 0x10 + (int32_t)iVar13;
                piVar15 = (int64_t *)(uint64_t)uVar19;
                if (uVar19 == 0x7898f5) {
                    puVar17 = (undefined8 *)(iVar5 + 0x38);
                    if (0xf < *(uint64_t *)(iVar5 + 0x50)) {
                        puVar17 = (undefined8 *)*puVar17;
                    }
                    if (puVar17 == (undefined8 *)0x0) {
                        func_0x000180086510(arg1);
                    } else {
                        uVar12 = func_0x000180498cd0(puVar17);
                        func_0x0001800867f0(arg1, puVar17, uVar12);
                    }
                    goto code_r0x00018003b071;
                }
                if (uVar19 == 0x7c9ab53b) {
                    piVar16 = (int64_t *)(iVar5 + 0x58);
                } else {
                    if (uVar19 == 0x766319ea) {
                        fcn.180086b20(arg1, *(undefined *)(iVar5 + 0x78));
                        goto code_r0x00018003b071;
                    }
                    if (uVar19 == 0x9d971b60) {
                        fcn.180086b20(arg1, *(undefined *)(iVar5 + 0x79));
                        goto code_r0x00018003b071;
                    }
                    if (uVar19 == 0x5a7e3adc) {
                        fcn.1800388d0(arg1, iVar5 + 0x60);
                        goto code_r0x00018003b071;
                    }
                    if (uVar19 == 0x70002f) {
                        fcn.180086570(arg1, (double)*(float *)(iVar5 + 0x7c));
                        goto code_r0x00018003b071;
                    }
                    if (uVar19 == 0x78f039) {
                        fcn.180086570(arg1, (double)*(int32_t *)(iVar5 + 0x70));
                        goto code_r0x00018003b071;
                    }
                    if ((uVar19 == 0x73574aa2) || (uVar19 == 0x2132d063)) {
                        fcn.180086570(arg1, (double)*(float *)(iVar5 + 0x74));
                        goto code_r0x00018003b071;
                    }
                    if (uVar19 != 0xf6000a1) goto code_r0x00018003b31c;
                    if ((uint64_t)(*(int64_t *)0x180782330 - *(int64_t *)0x180782328 >> 3) <=
                        (uint64_t)(int64_t)*(int32_t *)(iVar5 + 0x70)) {
                        func_0x000180060370();
                        pcVar7 = (code *)swi(3);
                        uVar12 = (*pcVar7)();
                        return uVar12;
                    }
                    uVar12 = *(undefined8 *)(*(int64_t *)0x180782328 + (int64_t)*(int32_t *)(iVar5 + 0x70) * 8);
                    ppcVar18 = (char **)(iVar5 + 0x38);
                    if (0xf < *(uint64_t *)(iVar5 + 0x50)) {
                        ppcVar18 = (char **)*ppcVar18;
                    }
                    fVar3 = *(float *)(iVar5 + 0x7c);
                    iVar13 = func_0x000180498cd0(ppcVar18);
                    ppcVar2 = (char **)(iVar13 + (int64_t)ppcVar18);
                    puVar14 = (uint32_t *)func_0x00018012ec80(uVar12);
                    fVar4 = (float)puVar14[5];
                    fVar22 = 0.0;
                    var_10h._0_4_ = 0.0;
                    fVar23 = 0.0;
                    var_10h._4_4_ = 0.0;
                    fVar21 = 0.0;
                    if (ppcVar18 < ppcVar2) {
                        do {
                            var_8h._0_4_ = (uint32_t)*(char *)ppcVar18;
                            if ((uint32_t)var_8h < 0x80) {
                                ppcVar18 = (char **)((int64_t)ppcVar18 + 1);
                            } else {
                                iVar9 = func_0x0001800f5c80(&var_8h, ppcVar18, ppcVar2);
                                ppcVar18 = (char **)((int64_t)ppcVar18 + (int64_t)iVar9);
                            }
                            if ((uint32_t)var_8h == 10) {
                                if (fVar22 <= fVar21) {
                                    fVar22 = fVar21;
                                }
                                fVar23 = fVar23 + fVar3;
                                fVar20 = 0.0;
                                var_10h._0_4_ = fVar22;
                            } else {
                                fVar20 = fVar21;
                                if ((uint32_t)var_8h != 0xd) {
                                    if ((*puVar14 <= (uint32_t)var_8h) ||
                                       (fVar20 = *(float *)(*(int64_t *)(puVar14 + 2) + (uint64_t)(uint32_t)var_8h * 4),
                                       fVar20 < 0.0)) {
                                        fVar20 = (float)func_0x00018012bbd0(puVar14);
                                    }
                                    fVar20 = fVar20 * (fVar3 / fVar4) + fVar21;
                                    if (3.402823e+38 <= fVar20) break;
                                }
                            }
                            fVar21 = fVar20;
                        } while (ppcVar18 < ppcVar2);
                        if (fVar22 < fVar21) {
                            var_10h._0_4_ = fVar21;
                        }
                        if ((0.0 < fVar21) || (var_10h._4_4_ = fVar23, fVar23 == 0.0)) goto code_r0x00018003b2e8;
                    } else {
code_r0x00018003b2e8:
                        var_10h._4_4_ = fVar23 + fVar3;
                    }
                    piVar16 = &var_10h;
                }
                fcn.180038820(arg1, (int64_t)piVar16);
                goto code_r0x00018003b071;
            }
        }
code_r0x00018003b31c:
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar10 + 1) = *(int32_t *)(piVar10 + 1) + 1;
            UNLOCK();
        }
        var_b8h._0_4_ = (undefined4)iVar5;
        var_b8h._4_4_ = (undefined4)((uint64_t)iVar5 >> 0x20);
        var_b0h._0_4_ = SUB84(piVar10, 0);
        var_b0h._4_4_ = (undefined4)((uint64_t)piVar10 >> 0x20);
        var_a8h._0_4_ = (undefined4)var_b8h;
        var_a8h._4_4_ = var_b8h._4_4_;
        uStack_a0 = (undefined4)var_b0h;
        uStack_9c = var_b0h._4_4_;
        cVar8 = fcn.180038ef0(arg1, (int64_t)&var_a8h, (int64_t)piVar16, (int64_t)piVar15);
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            piVar16 = piVar10 + 1;
            iVar9 = *(int32_t *)piVar16;
            *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                (**(code **)*piVar10)(piVar10);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                iVar9 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)(*piVar10 + 8))(piVar10);
                }
            }
        }
        if (cVar8 != '\0') {
code_r0x00018003b071:
            if (piVar10 != (int64_t *)0x0) {
                LOCK();
                piVar16 = piVar10 + 1;
                iVar9 = *(int32_t *)piVar16;
                *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)*piVar10)(piVar10);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar10 + 8))(piVar10);
                    }
                }
            }
            return 1;
        }
        fcn.180088560(arg1, 0x180622d90, iVar6 + 0x18);
    }
    func_0x0001800883d0(arg1, 1, 0x180622ca0);
code_r0x00018003b3a8:
    func_0x000180088470(arg1, 2, 6);
    pcVar7 = (code *)swi(3);
    uVar12 = (*pcVar7)();
    return uVar12;
}

