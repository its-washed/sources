// Chunk 179 - 50 functions

// ============================================================
// Function: FUN_1802393c0
// Address: 0x1802393c0
// Size: 26 bytes
// ============================================================
undefined8
fcn.1802393c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_68h)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    uint64_t uVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    undefined4 *in_R8;
    int32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar13;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802393ca;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    iVar9 = *(int64_t *)(in_RCX + 0x38);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RSI;
    *(undefined8 *)(&stack0x00000020 + iVar5) = unaff_RDI;
    *(undefined8 *)(&stack0x00000018 + iVar5) = unaff_R12;
    *(undefined8 *)(&stack0x00000010 + iVar5) = unaff_R13;
    *(undefined8 *)(&stack0x00000008 + iVar5) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar5 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x1802ab7a2;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    uVar12 = 0;
    uVar2 = 0;
    if (iVar9 == 0) {
        if (in_R9 != (int32_t *)0x0) {
            *in_R9 = -1;
        }
        if (in_R8 != (undefined4 *)0x0) {
            *in_R8 = 0xffffffff;
        }
    } else {
        if (in_R9 != (int32_t *)0x0) {
            uVar2 = *in_R9 + 1;
        }
        uVar11 = uVar12;
        if (-1 < (int32_t)uVar2) {
            uVar11 = (uint64_t)uVar2;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab7f9;
        iVar3 = func_0x000180222010();
        if ((int32_t)uVar11 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab80b;
                uVar7 = func_0x000180222340(iVar9, uVar11);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab816;
                uVar8 = func_0x00018020e940(uVar7);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab81e;
                iVar3 = func_0x00018022cd20(uVar8);
                if (iVar3 == in_EDX) {
                    if (in_R9 != (int32_t *)0x0) {
                        *in_R9 = (int32_t)uVar11;
                        uVar12 = uVar7;
                        break;
                    }
                    bVar13 = uVar12 != 0;
                    uVar12 = uVar7;
                    if (bVar13) {
                        if (in_R8 == (undefined4 *)0x0) {
                            return 0;
                        }
                        *in_R8 = 0xfffffffe;
                        return 0;
                    }
                }
                uVar2 = (int32_t)uVar11 + 1;
                uVar11 = (uint64_t)uVar2;
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab83a;
                iVar3 = func_0x000180222010(iVar9);
            } while ((int32_t)uVar2 < iVar3);
            if (uVar12 != 0) {
                if (in_R8 != (undefined4 *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab870;
                    uVar4 = func_0x0001802ab4d0(uVar12);
                    *in_R8 = uVar4;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab87b;
                uVar8 = func_0x00018020e940(uVar12);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab883;
                iVar3 = func_0x00018022cd20(uVar8);
                if (iVar3 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab88e;
                iVar9 = func_0x0001802ab6e0(iVar3);
                if (iVar9 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab89e;
                uVar8 = func_0x0001802ab4e0(uVar12);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8a9;
                uVar10 = func_0x0001801bc820(uVar8);
                *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = uVar10;
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8b6;
                uVar4 = func_0x000180203a00(uVar8);
                pcVar1 = *(code **)(iVar9 + 8);
                if (pcVar1 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8c3;
                    uVar8 = (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8d5;
                    uVar8 = func_0x000180261770(0, (int64_t)&arg_50h + iVar6 + iVar5, uVar4, uVar8);
                    return uVar8;
                }
                pcVar1 = *(code **)(iVar9 + 0x20);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8ea;
                uVar8 = (*pcVar1)(0, (int64_t)&arg_50h + iVar6 + iVar5, uVar4);
                return uVar8;
            }
        }
        if (in_R9 != (int32_t *)0x0) {
            *in_R9 = -1;
        }
        if (in_R8 != (undefined4 *)0x0) {
            *in_R8 = 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802393e0
// Address: 0x1802393e0
// Size: 26 bytes
// ============================================================
undefined8 fcn.1802393e0(int64_t param_1, int32_t param_2, undefined4 *param_3, int32_t *param_4)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined8 uVar10;
    undefined8 unaff_RBX;
    uint64_t uVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar13;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802393ea;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    iVar9 = *(int64_t *)(param_1 + 0x20);
    *(undefined8 *)(&stack0x00000038 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar5) = unaff_RBP;
    *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RSI;
    *(undefined8 *)(&stack0x00000020 + iVar5) = unaff_RDI;
    *(undefined8 *)(&stack0x00000018 + iVar5) = unaff_R12;
    *(undefined8 *)(&stack0x00000010 + iVar5) = unaff_R13;
    *(undefined8 *)(&stack0x00000008 + iVar5) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar5 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x1802ab7a2;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    uVar12 = 0;
    uVar2 = 0;
    if (iVar9 == 0) {
        if (param_4 != (int32_t *)0x0) {
            *param_4 = -1;
        }
        if (param_3 != (undefined4 *)0x0) {
            *param_3 = 0xffffffff;
        }
    } else {
        if (param_4 != (int32_t *)0x0) {
            uVar2 = *param_4 + 1;
        }
        uVar11 = uVar12;
        if (-1 < (int32_t)uVar2) {
            uVar11 = (uint64_t)uVar2;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab7f9;
        iVar3 = func_0x000180222010();
        if ((int32_t)uVar11 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab80b;
                uVar7 = func_0x000180222340(iVar9, uVar11);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab816;
                uVar8 = func_0x00018020e940(uVar7);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab81e;
                iVar3 = func_0x00018022cd20(uVar8);
                if (iVar3 == param_2) {
                    if (param_4 != (int32_t *)0x0) {
                        *param_4 = (int32_t)uVar11;
                        uVar12 = uVar7;
                        break;
                    }
                    bVar13 = uVar12 != 0;
                    uVar12 = uVar7;
                    if (bVar13) {
                        if (param_3 == (undefined4 *)0x0) {
                            return 0;
                        }
                        *param_3 = 0xfffffffe;
                        return 0;
                    }
                }
                uVar2 = (int32_t)uVar11 + 1;
                uVar11 = (uint64_t)uVar2;
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab83a;
                iVar3 = func_0x000180222010(iVar9);
            } while ((int32_t)uVar2 < iVar3);
            if (uVar12 != 0) {
                if (param_3 != (undefined4 *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab870;
                    uVar4 = func_0x0001802ab4d0(uVar12);
                    *param_3 = uVar4;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab87b;
                uVar8 = func_0x00018020e940(uVar12);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab883;
                iVar3 = func_0x00018022cd20(uVar8);
                if (iVar3 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab88e;
                iVar9 = func_0x0001802ab6e0(iVar3);
                if (iVar9 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab89e;
                uVar8 = func_0x0001802ab4e0(uVar12);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8a9;
                uVar10 = func_0x0001801bc820(uVar8);
                *(undefined8 *)(&stack0x00000050 + iVar6 + iVar5) = uVar10;
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8b6;
                uVar4 = func_0x000180203a00(uVar8);
                pcVar1 = *(code **)(iVar9 + 8);
                if (pcVar1 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8c3;
                    uVar8 = (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8d5;
                    uVar8 = func_0x000180261770(0, &stack0x00000050 + iVar6 + iVar5, uVar4, uVar8);
                    return uVar8;
                }
                pcVar1 = *(code **)(iVar9 + 0x20);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8ea;
                uVar8 = (*pcVar1)(0, &stack0x00000050 + iVar6 + iVar5, uVar4);
                return uVar8;
            }
        }
        if (param_4 != (int32_t *)0x0) {
            *param_4 = -1;
        }
        if (param_3 != (undefined4 *)0x0) {
            *param_3 = 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239400
// Address: 0x180239400
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180239400(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180239410;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023941f;
    uVar3 = fcn.1802ab530(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2));
    if (*(int64_t *)(in_RCX + 0x68) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239430;
        iVar1 = fcn.180222010();
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239444;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)(in_RCX + 0x68) = 0;
        }
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180239460
// Address: 0x180239460
// Size: 26 bytes
// ============================================================
undefined8 fcn.180239460(int64_t arg_30h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t *piVar4;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar4 = *(int32_t **)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802ab590;
    iVar3 = fcn.18045a350();
    if (piVar4 != (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + (iVar2 - iVar3)) = 0x1802ab5a2;
        iVar1 = fcn.180222010();
        if ((in_EDX < iVar1) && (-1 < in_EDX)) {
            if (((piVar4 != (int32_t *)0x0) && (-1 < in_EDX)) && (in_EDX < *piVar4)) {
                return *(undefined8 *)(*(int64_t *)(piVar4 + 2) + (int64_t)in_EDX * 8);
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239480
// Address: 0x180239480
// Size: 26 bytes
// ============================================================
int32_t fcn.180239480(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t in_RCX;
    int64_t iVar8;
    int32_t iVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar8 = *(int64_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1802a7015;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a7025;
    iVar6 = fcn.18022cba0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
    if (iVar6 == 0) {
        return -2;
    }
    if (iVar8 != 0) {
        *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = unaff_RDI;
        iVar9 = 0;
        if (-1 < in_R8D + 1) {
            iVar9 = in_R8D + 1;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a7075;
        iVar2 = fcn.180222010(iVar8);
        while( true ) {
            if (iVar2 <= iVar9) {
                return -1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a708a;
            puVar7 = (undefined8 *)fcn.180222340(iVar8, iVar9);
            uVar1 = *puVar7;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a7095;
            iVar3 = fcn.180298380(uVar1, iVar6);
            if (iVar3 == 0) break;
            iVar9 = iVar9 + 1;
        }
        return iVar9;
    }
    return -1;
}

// ============================================================
// Function: FUN_1802394a0
// Address: 0x1802394a0
// Size: 26 bytes
// ============================================================
int32_t fcn.1802394a0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar5 = *(int64_t *)(param_1 + 0x68);
    *(undefined8 *)((int64_t)&uStackX_20 + -iVar2) = 0x1802ab5da;
    iVar3 = fcn.18045a350();
    if (iVar5 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + (-iVar2 - iVar3)) = 0x1802ab5ee;
    iVar1 = fcn.180222010();
    iVar4 = 0;
    if (0 < iVar1) {
        iVar4 = iVar1;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1802394c0
// Address: 0x1802394c0
// Size: 26 bytes
// ============================================================
undefined8 fcn.1802394c0(int64_t param_1, int32_t param_2, undefined4 *param_3, int32_t *param_4)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined8 uVar10;
    undefined8 unaff_RBX;
    uint64_t uVar11;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar13;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802394ca;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar9 = *(int64_t *)(param_1 + 0x68);
    *(undefined8 *)(&stack0x00000038 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar5) = unaff_RBP;
    *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RSI;
    *(undefined8 *)(&stack0x00000020 + iVar5) = unaff_RDI;
    *(undefined8 *)(&stack0x00000018 + iVar5) = unaff_R12;
    *(undefined8 *)(&stack0x00000010 + iVar5) = unaff_R13;
    *(undefined8 *)(&stack0x00000008 + iVar5) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar5 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x1802ab7a2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar12 = 0;
    uVar2 = 0;
    if (iVar9 == 0) {
        if (param_4 != (int32_t *)0x0) {
            *param_4 = -1;
        }
        if (param_3 != (undefined4 *)0x0) {
            *param_3 = 0xffffffff;
        }
    } else {
        if (param_4 != (int32_t *)0x0) {
            uVar2 = *param_4 + 1;
        }
        uVar11 = uVar12;
        if (-1 < (int32_t)uVar2) {
            uVar11 = (uint64_t)uVar2;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab7f9;
        iVar3 = fcn.180222010();
        if ((int32_t)uVar11 < iVar3) {
            do {
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab80b;
                uVar7 = fcn.180222340(iVar9, uVar11);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab816;
                uVar8 = func_0x00018020e940(uVar7);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab81e;
                iVar3 = func_0x00018022cd20(uVar8);
                if (iVar3 == param_2) {
                    if (param_4 != (int32_t *)0x0) {
                        *param_4 = (int32_t)uVar11;
                        uVar12 = uVar7;
                        break;
                    }
                    bVar13 = uVar12 != 0;
                    uVar12 = uVar7;
                    if (bVar13) {
                        if (param_3 == (undefined4 *)0x0) {
                            return 0;
                        }
                        *param_3 = 0xfffffffe;
                        return 0;
                    }
                }
                uVar2 = (int32_t)uVar11 + 1;
                uVar11 = (uint64_t)uVar2;
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab83a;
                iVar3 = fcn.180222010(iVar9);
            } while ((int32_t)uVar2 < iVar3);
            if (uVar12 != 0) {
                if (param_3 != (undefined4 *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab870;
                    uVar4 = func_0x0001802ab4d0(uVar12);
                    *param_3 = uVar4;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab87b;
                uVar8 = func_0x00018020e940(uVar12);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab883;
                iVar3 = func_0x00018022cd20(uVar8);
                if (iVar3 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab88e;
                iVar9 = func_0x0001802ab6e0(iVar3);
                if (iVar9 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab89e;
                uVar8 = func_0x0001802ab4e0(uVar12);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8a9;
                uVar10 = func_0x0001801bc820(uVar8);
                *(undefined8 *)(&stack0x00000050 + iVar6 + iVar5) = uVar10;
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8b6;
                uVar4 = func_0x000180203a00(uVar8);
                pcVar1 = *(code **)(iVar9 + 8);
                if (pcVar1 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8c3;
                    uVar8 = (*pcVar1)();
                    *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8d5;
                    uVar8 = func_0x000180261770(0, &stack0x00000050 + iVar6 + iVar5, uVar4, uVar8);
                    return uVar8;
                }
                pcVar1 = *(code **)(iVar9 + 0x20);
                *(undefined8 *)((int64_t)&uStack_8 + iVar6 + iVar5) = 0x1802ab8ea;
                uVar8 = (*pcVar1)(0, &stack0x00000050 + iVar6 + iVar5, uVar4);
                return uVar8;
            }
        }
        if (param_4 != (int32_t *)0x0) {
            *param_4 = -1;
        }
        if (param_3 != (undefined4 *)0x0) {
            *param_3 = 0xffffffff;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802394e0
// Address: 0x1802394e0
// Size: 23 bytes
// ============================================================
void fcn.1802394e0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 *puVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802394f4;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
        puVar7 = *(undefined8 **)arg1;
        if (puVar7 != (undefined8 *)0x0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
            do {
                if ((*(int32_t *)((int64_t)puVar7 + 0x24) == 0) && (pcVar1 = (code *)puVar7[3], pcVar1 != (code *)0x0))
                {
                    uVar2 = puVar7[2];
                    uVar3 = puVar7[1];
                    uVar4 = *puVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023952f;
                    (*pcVar1)(arg1, uVar4, uVar3, uVar2);
                }
                puVar5 = (undefined8 *)puVar7[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180239548;
                func_0x000180224990(puVar7, 0x1804e2c68, 0x25);
                puVar7 = puVar5;
            } while (puVar5 != (undefined8 *)0x0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023956a;
        func_0x000180224990(arg1, 0x1804e2c68, 0x29);
    }
    return;
}

// ============================================================
// Function: FUN_1802394f7
// Address: 0x1802394f7
// Size: 16 bytes
// ============================================================
void fcn.1802394e0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 *puVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802394f4;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
        puVar7 = *(undefined8 **)arg1;
        if (puVar7 != (undefined8 *)0x0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
            do {
                if ((*(int32_t *)((int64_t)puVar7 + 0x24) == 0) && (pcVar1 = (code *)puVar7[3], pcVar1 != (code *)0x0))
                {
                    uVar2 = puVar7[2];
                    uVar3 = puVar7[1];
                    uVar4 = *puVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023952f;
                    (*pcVar1)(arg1, uVar4, uVar3, uVar2);
                }
                puVar5 = (undefined8 *)puVar7[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180239548;
                func_0x000180224990(puVar7, 0x1804e2c68, 0x25);
                puVar7 = puVar5;
            } while (puVar5 != (undefined8 *)0x0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023956a;
        func_0x000180224990(arg1, 0x1804e2c68, 0x29);
    }
    return;
}

// ============================================================
// Function: FUN_180239507
// Address: 0x180239507
// Size: 78 bytes
// ============================================================
void fcn.1802394e0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 *puVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802394f4;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
        puVar7 = *(undefined8 **)arg1;
        if (puVar7 != (undefined8 *)0x0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
            do {
                if ((*(int32_t *)((int64_t)puVar7 + 0x24) == 0) && (pcVar1 = (code *)puVar7[3], pcVar1 != (code *)0x0))
                {
                    uVar2 = puVar7[2];
                    uVar3 = puVar7[1];
                    uVar4 = *puVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023952f;
                    (*pcVar1)(arg1, uVar4, uVar3, uVar2);
                }
                puVar5 = (undefined8 *)puVar7[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180239548;
                func_0x000180224990(puVar7, 0x1804e2c68, 0x25);
                puVar7 = puVar5;
            } while (puVar5 != (undefined8 *)0x0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023956a;
        func_0x000180224990(arg1, 0x1804e2c68, 0x29);
    }
    return;
}

// ============================================================
// Function: FUN_180239555
// Address: 0x180239555
// Size: 31 bytes
// ============================================================
void fcn.1802394e0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 *puVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802394f4;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
        puVar7 = *(undefined8 **)arg1;
        if (puVar7 != (undefined8 *)0x0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
            do {
                if ((*(int32_t *)((int64_t)puVar7 + 0x24) == 0) && (pcVar1 = (code *)puVar7[3], pcVar1 != (code *)0x0))
                {
                    uVar2 = puVar7[2];
                    uVar3 = puVar7[1];
                    uVar4 = *puVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023952f;
                    (*pcVar1)(arg1, uVar4, uVar3, uVar2);
                }
                puVar5 = (undefined8 *)puVar7[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180239548;
                func_0x000180224990(puVar7, 0x1804e2c68, 0x25);
                puVar7 = puVar5;
            } while (puVar5 != (undefined8 *)0x0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023956a;
        func_0x000180224990(arg1, 0x1804e2c68, 0x29);
    }
    return;
}

// ============================================================
// Function: FUN_180239574
// Address: 0x180239574
// Size: 1 bytes
// ============================================================
void fcn.1802394e0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 *puVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802394f4;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBX;
        puVar7 = *(undefined8 **)arg1;
        if (puVar7 != (undefined8 *)0x0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
            do {
                if ((*(int32_t *)((int64_t)puVar7 + 0x24) == 0) && (pcVar1 = (code *)puVar7[3], pcVar1 != (code *)0x0))
                {
                    uVar2 = puVar7[2];
                    uVar3 = puVar7[1];
                    uVar4 = *puVar7;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023952f;
                    (*pcVar1)(arg1, uVar4, uVar3, uVar2);
                }
                puVar5 = (undefined8 *)puVar7[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180239548;
                func_0x000180224990(puVar7, 0x1804e2c68, 0x25);
                puVar7 = puVar5;
            } while (puVar5 != (undefined8 *)0x0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18023956a;
        func_0x000180224990(arg1, 0x1804e2c68, 0x29);
    }
    return;
}

// ============================================================
// Function: FUN_180239580
// Address: 0x180239580
// Size: 40 bytes
// ============================================================
int64_t fcn.180239580(int64_t arg_30h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0x30;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180224d70;
    iVar1 = fcn.18045a350(0x30, 0x1804e2c68, 0x11);
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224d7b;
    iVar2 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar1 + iVar3), *(int64_t *)(&stack0x00000048 + iVar1 + iVar3)
                         );
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar3) = 0x180224d90;
        fcn.1804986e0(iVar2, 0, uVar4);
    }
    return iVar2;
}

// ============================================================
// Function: FUN_1802395d0
// Address: 0x1802395d0
// Size: 65 bytes
// ============================================================
undefined8 fcn.1802395d0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802395da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1802395e9;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1802395fc;
        iVar2 = fcn.18028a240(*(int64_t *)((int64_t)&iStackX_20 + iVar2));
        if (iVar2 != 0) {
            return *(undefined8 *)(iVar2 + 0x10);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239620
// Address: 0x180239620
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180239620(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18023963b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar7 = 0;
    if ((in_RCX < in_RDX) || (0x7fffffff < in_RCX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023984e;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239866;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239878;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239671;
        iVar1 = fcn.180243560(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239689;
            iVar1 = func_0x00018028c680(0, 0, 0x180239c60);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396a8;
                piVar3 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2c88, 0x166);
                if (piVar3 != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396bd;
                    uVar4 = func_0x000180221f60(0, in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396cc;
                    iVar5 = func_0x000180222290(uVar4, 0x180196ec0);
                    *piVar3 = iVar5;
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396d9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396f1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239703;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        uVar4 = 0x16d;
                    } else {
                        piVar3[2] = in_RCX;
                        while (in_RDX != 0) {
                            in_RDX = in_RDX - 1;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023973a;
                            piVar6 = (int64_t *)func_0x000180224d60(0x38, 0x1804e2c88, 0x53);
                            if (piVar6 == (int64_t *)0x0) break;
                            *(undefined4 *)((int64_t)piVar6 + 0x24) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239762;
                            iVar5 = (*(code *)0x69a166)(0, 0, 1, 0x1802ab9d0);
                            *piVar6 = iVar5;
                            if (iVar5 == 0) {
                                iVar5 = piVar6[3];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239799;
                                func_0x000180224990(iVar5, 0x1804e2c88, 0x5f);
                                iVar5 = *piVar6;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397a2;
                                (*(code *)0x69a158)(iVar5);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397b7;
                                func_0x000180224990(piVar6, 0x1804e2c88, 0x61);
                                break;
                            }
                            piVar6[3] = 0;
                            iVar5 = *piVar3;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239779;
                            func_0x000180222110(iVar5, piVar6);
                            iVar7 = iVar7 + 1;
                        }
                        piVar3[1] = iVar7;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397cd;
                        iVar1 = func_0x00018028a2c0(5, 1, piVar3);
                        if (iVar1 != 0) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397d6;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397ee;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239800;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239808;
                        func_0x000180239d60(piVar3);
                        iVar7 = *piVar3;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239810;
                        func_0x000180221d50(iVar7);
                        uVar4 = 0x18e;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239825;
                    func_0x000180224990(piVar3, 0x1804e2c88, uVar4);
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239662
// Address: 0x180239662
// Size: 458 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180239620(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18023963b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar7 = 0;
    if ((in_RCX < in_RDX) || (0x7fffffff < in_RCX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023984e;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239866;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239878;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239671;
        iVar1 = fcn.180243560(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239689;
            iVar1 = func_0x00018028c680(0, 0, 0x180239c60);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396a8;
                piVar3 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2c88, 0x166);
                if (piVar3 != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396bd;
                    uVar4 = func_0x000180221f60(0, in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396cc;
                    iVar5 = func_0x000180222290(uVar4, 0x180196ec0);
                    *piVar3 = iVar5;
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396d9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396f1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239703;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        uVar4 = 0x16d;
                    } else {
                        piVar3[2] = in_RCX;
                        while (in_RDX != 0) {
                            in_RDX = in_RDX - 1;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023973a;
                            piVar6 = (int64_t *)func_0x000180224d60(0x38, 0x1804e2c88, 0x53);
                            if (piVar6 == (int64_t *)0x0) break;
                            *(undefined4 *)((int64_t)piVar6 + 0x24) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239762;
                            iVar5 = (*(code *)0x69a166)(0, 0, 1, 0x1802ab9d0);
                            *piVar6 = iVar5;
                            if (iVar5 == 0) {
                                iVar5 = piVar6[3];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239799;
                                func_0x000180224990(iVar5, 0x1804e2c88, 0x5f);
                                iVar5 = *piVar6;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397a2;
                                (*(code *)0x69a158)(iVar5);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397b7;
                                func_0x000180224990(piVar6, 0x1804e2c88, 0x61);
                                break;
                            }
                            piVar6[3] = 0;
                            iVar5 = *piVar3;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239779;
                            func_0x000180222110(iVar5, piVar6);
                            iVar7 = iVar7 + 1;
                        }
                        piVar3[1] = iVar7;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397cd;
                        iVar1 = func_0x00018028a2c0(5, 1, piVar3);
                        if (iVar1 != 0) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397d6;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397ee;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239800;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239808;
                        func_0x000180239d60(piVar3);
                        iVar7 = *piVar3;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239810;
                        func_0x000180221d50(iVar7);
                        uVar4 = 0x18e;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239825;
                    func_0x000180224990(piVar3, 0x1804e2c88, uVar4);
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18023982c
// Address: 0x18023982c
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180239620(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18023963b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar7 = 0;
    if ((in_RCX < in_RDX) || (0x7fffffff < in_RCX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023984e;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239866;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239878;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239671;
        iVar1 = fcn.180243560(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239689;
            iVar1 = func_0x00018028c680(0, 0, 0x180239c60);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396a8;
                piVar3 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2c88, 0x166);
                if (piVar3 != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396bd;
                    uVar4 = func_0x000180221f60(0, in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396cc;
                    iVar5 = func_0x000180222290(uVar4, 0x180196ec0);
                    *piVar3 = iVar5;
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396d9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396f1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239703;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        uVar4 = 0x16d;
                    } else {
                        piVar3[2] = in_RCX;
                        while (in_RDX != 0) {
                            in_RDX = in_RDX - 1;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023973a;
                            piVar6 = (int64_t *)func_0x000180224d60(0x38, 0x1804e2c88, 0x53);
                            if (piVar6 == (int64_t *)0x0) break;
                            *(undefined4 *)((int64_t)piVar6 + 0x24) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239762;
                            iVar5 = (*(code *)0x69a166)(0, 0, 1, 0x1802ab9d0);
                            *piVar6 = iVar5;
                            if (iVar5 == 0) {
                                iVar5 = piVar6[3];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239799;
                                func_0x000180224990(iVar5, 0x1804e2c88, 0x5f);
                                iVar5 = *piVar6;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397a2;
                                (*(code *)0x69a158)(iVar5);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397b7;
                                func_0x000180224990(piVar6, 0x1804e2c88, 0x61);
                                break;
                            }
                            piVar6[3] = 0;
                            iVar5 = *piVar3;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239779;
                            func_0x000180222110(iVar5, piVar6);
                            iVar7 = iVar7 + 1;
                        }
                        piVar3[1] = iVar7;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397cd;
                        iVar1 = func_0x00018028a2c0(5, 1, piVar3);
                        if (iVar1 != 0) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397d6;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397ee;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239800;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239808;
                        func_0x000180239d60(piVar3);
                        iVar7 = *piVar3;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239810;
                        func_0x000180221d50(iVar7);
                        uVar4 = 0x18e;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239825;
                    func_0x000180224990(piVar3, 0x1804e2c88, uVar4);
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239842
// Address: 0x180239842
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180239620(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18023963b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar7 = 0;
    if ((in_RCX < in_RDX) || (0x7fffffff < in_RCX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023984e;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239866;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239878;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239671;
        iVar1 = fcn.180243560(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239689;
            iVar1 = func_0x00018028c680(0, 0, 0x180239c60);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396a8;
                piVar3 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2c88, 0x166);
                if (piVar3 != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396bd;
                    uVar4 = func_0x000180221f60(0, in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396cc;
                    iVar5 = func_0x000180222290(uVar4, 0x180196ec0);
                    *piVar3 = iVar5;
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396d9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396f1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239703;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        uVar4 = 0x16d;
                    } else {
                        piVar3[2] = in_RCX;
                        while (in_RDX != 0) {
                            in_RDX = in_RDX - 1;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023973a;
                            piVar6 = (int64_t *)func_0x000180224d60(0x38, 0x1804e2c88, 0x53);
                            if (piVar6 == (int64_t *)0x0) break;
                            *(undefined4 *)((int64_t)piVar6 + 0x24) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239762;
                            iVar5 = (*(code *)0x69a166)(0, 0, 1, 0x1802ab9d0);
                            *piVar6 = iVar5;
                            if (iVar5 == 0) {
                                iVar5 = piVar6[3];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239799;
                                func_0x000180224990(iVar5, 0x1804e2c88, 0x5f);
                                iVar5 = *piVar6;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397a2;
                                (*(code *)0x69a158)(iVar5);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397b7;
                                func_0x000180224990(piVar6, 0x1804e2c88, 0x61);
                                break;
                            }
                            piVar6[3] = 0;
                            iVar5 = *piVar3;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239779;
                            func_0x000180222110(iVar5, piVar6);
                            iVar7 = iVar7 + 1;
                        }
                        piVar3[1] = iVar7;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397cd;
                        iVar1 = func_0x00018028a2c0(5, 1, piVar3);
                        if (iVar1 != 0) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397d6;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397ee;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239800;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239808;
                        func_0x000180239d60(piVar3);
                        iVar7 = *piVar3;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239810;
                        func_0x000180221d50(iVar7);
                        uVar4 = 0x18e;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239825;
                    func_0x000180224990(piVar3, 0x1804e2c88, uVar4);
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239849
// Address: 0x180239849
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180239620(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar7;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x18023963b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar7 = 0;
    if ((in_RCX < in_RDX) || (0x7fffffff < in_RCX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023984e;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239866;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239878;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239671;
        iVar1 = fcn.180243560(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239689;
            iVar1 = func_0x00018028c680(0, 0, 0x180239c60);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396a8;
                piVar3 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2c88, 0x166);
                if (piVar3 != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396bd;
                    uVar4 = func_0x000180221f60(0, in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396cc;
                    iVar5 = func_0x000180222290(uVar4, 0x180196ec0);
                    *piVar3 = iVar5;
                    if (iVar5 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396d9;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802396f1;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239703;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        uVar4 = 0x16d;
                    } else {
                        piVar3[2] = in_RCX;
                        while (in_RDX != 0) {
                            in_RDX = in_RDX - 1;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023973a;
                            piVar6 = (int64_t *)func_0x000180224d60(0x38, 0x1804e2c88, 0x53);
                            if (piVar6 == (int64_t *)0x0) break;
                            *(undefined4 *)((int64_t)piVar6 + 0x24) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239762;
                            iVar5 = (*(code *)0x69a166)(0, 0, 1, 0x1802ab9d0);
                            *piVar6 = iVar5;
                            if (iVar5 == 0) {
                                iVar5 = piVar6[3];
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239799;
                                func_0x000180224990(iVar5, 0x1804e2c88, 0x5f);
                                iVar5 = *piVar6;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397a2;
                                (*(code *)0x69a158)(iVar5);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397b7;
                                func_0x000180224990(piVar6, 0x1804e2c88, 0x61);
                                break;
                            }
                            piVar6[3] = 0;
                            iVar5 = *piVar3;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239779;
                            func_0x000180222110(iVar5, piVar6);
                            iVar7 = iVar7 + 1;
                        }
                        piVar3[1] = iVar7;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397cd;
                        iVar1 = func_0x00018028a2c0(5, 1, piVar3);
                        if (iVar1 != 0) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397d6;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802397ee;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239800;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239808;
                        func_0x000180239d60(piVar3);
                        iVar7 = *piVar3;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239810;
                        func_0x000180221d50(iVar7);
                        uVar4 = 0x18e;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239825;
                    func_0x000180224990(piVar3, 0x1804e2c88, uVar4);
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239880
// Address: 0x180239880
// Size: 986 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.180239880(int64_t *placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
             int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1802398a4;
    var_10h = arg2;
    var_18h = arg3;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802398b9;
    iVar4 = fcn.180243560(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)(&stack0xfffffffffffffff0 + iVar5)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802398d0;
    iVar6 = fcn.18028a240(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5));
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802398ea;
        iVar4 = func_0x00018028c680(0, 0, 0x180239c60);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239905;
            iVar6 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239915;
                func_0x0001802ab930(iVar6);
                *(undefined8 *)(iVar6 + 0x10) = 0;
                *(undefined4 *)(iVar6 + 0x18) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023992e;
                iVar4 = func_0x00018028a2c0(4, 1, iVar6);
                if (iVar4 != 0) goto code_r0x00018023994a;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239947;
            func_0x000180224990(iVar6, 0x1804e2c88, 0x35);
        }
        iVar6 = 0;
    }
code_r0x00018023994a:
    if (iVar6 == 0) {
        return 0;
    }
    if (*placeholder_0 != 0) {
        *(int64_t *)(iVar6 + 0x10) = *placeholder_0;
    }
    uVar1 = *(undefined8 *)((int64_t)&arg_60h + iVar5);
    iVar2 = *(int64_t *)((int64_t)&arg_58h + iVar5);
    do {
        while (iVar7 = *(int64_t *)(iVar6 + 0x10), iVar7 != 0) {
            iVar4 = *(int32_t *)(iVar7 + 0x24);
            if (iVar4 == 3) {
                **(undefined4 **)((int64_t)&arg_48h + iVar5) = *(undefined4 *)(iVar7 + 0x20);
                *(undefined8 *)(*(int64_t *)(iVar6 + 0x10) + 0x28) = 0;
                uVar1 = *(undefined8 *)(iVar6 + 0x10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239be4;
                func_0x000180239e00(uVar1);
                *(undefined8 *)(iVar6 + 0x10) = 0;
                *placeholder_0 = 0;
                return 3;
            }
            if (iVar4 == 1) {
                *placeholder_0 = iVar7;
                *(undefined4 *)(*(int64_t *)(iVar6 + 0x10) + 0x24) = 2;
                *(undefined8 *)(iVar6 + 0x10) = 0;
                return 2;
            }
            if (iVar4 != 2) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b65;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b7d;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b8f;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar5));
                uVar1 = *(undefined8 *)(iVar6 + 0x10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b98;
                func_0x000180239e00(uVar1);
                *(undefined8 *)(iVar6 + 0x10) = 0;
                *placeholder_0 = 0;
                return 0;
            }
            iVar7 = *placeholder_0;
            if (iVar7 == 0) {
                return 0;
            }
            *(int64_t *)(iVar6 + 0x10) = iVar7;
            uVar8 = *(undefined8 *)(iVar7 + 0x30);
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802399b0;
            iVar7 = func_0x0001802454c0(uVar8);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b1f;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b37;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar5), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                              *(int64_t *)((int64_t)&var_18h + iVar5));
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b49;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar5));
                uVar1 = *(undefined8 *)(iVar6 + 0x10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b52;
                func_0x000180239e00(uVar1);
                *(undefined8 *)(iVar6 + 0x10) = 0;
                *placeholder_0 = 0;
                return 0;
            }
            uVar8 = **(undefined8 **)(iVar6 + 0x10);
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802399c9;
            (*(code *)0x69a148)(uVar8);
            iVar3 = *(int64_t *)(iVar6 + 0x10);
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802399d5;
            uVar8 = func_0x0001802454c0(iVar7);
            *(undefined8 *)(iVar3 + 0x30) = uVar8;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802399ea;
        puVar9 = (undefined8 *)fcn.18028a240(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5));
        if (puVar9 == (undefined8 *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802399fb;
            iVar4 = fcn.180239620(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5)
                                  , *(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            if (iVar4 == 0) goto code_r0x000180239c26;
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239a12;
            puVar9 = (undefined8 *)fcn.18028a240(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5));
        }
        uVar8 = *puVar9;
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239a1d;
        piVar10 = (int64_t *)func_0x000180222020(uVar8);
        if (piVar10 == (int64_t *)0x0) {
            if ((puVar9[2] != 0) && ((uint64_t)puVar9[2] <= (uint64_t)puVar9[1])) {
code_r0x000180239c26:
                *(undefined8 *)(iVar6 + 0x10) = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239a4f;
            piVar10 = (int64_t *)func_0x000180224d60(0x38, 0x1804e2c88, 0x53);
            if (piVar10 != (int64_t *)0x0) {
                *(undefined4 *)((int64_t)piVar10 + 0x24) = 0;
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar5) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239a78;
                iVar7 = (*(code *)0x69a166)(0, 0, 1, 0x1802ab9d0);
                *piVar10 = iVar7;
                if (iVar7 == 0) {
                    iVar2 = piVar10[3];
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239c08;
                    func_0x000180224990(iVar2, 0x1804e2c88, 0x5f);
                    iVar2 = *piVar10;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239c11;
                    (*(code *)0x69a158)(iVar2);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239c26;
                    func_0x000180224990(piVar10, 0x1804e2c88, 0x61);
                    goto code_r0x000180239c26;
                }
                puVar9[1] = puVar9[1] + 1;
            }
        }
        *(int64_t **)(iVar6 + 0x10) = piVar10;
        if (piVar10 == (int64_t *)0x0) {
            return 1;
        }
        if (iVar2 == 0) {
            piVar10[3] = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239aaf;
            iVar7 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar5));
            piVar10[3] = iVar7;
            iVar7 = *(int64_t *)(iVar6 + 0x10);
            iVar3 = *(int64_t *)(iVar7 + 0x18);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239c3b;
                func_0x000180239e00(iVar7);
                *(undefined8 *)(iVar6 + 0x10) = 0;
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239acf;
            fcn.180498030(iVar3, iVar2, uVar1);
        }
        uVar8 = *(undefined8 *)((int64_t)&arg_40h + iVar5);
        *(undefined8 *)(*(int64_t *)(iVar6 + 0x10) + 0x10) = in_R9;
        *(undefined8 *)(*(int64_t *)(iVar6 + 0x10) + 0x28) = uVar8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239af5;
        uVar11 = func_0x000180245b10(0);
        uVar8 = **(undefined8 **)(iVar6 + 0x10);
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b05;
        (*(code *)0x69a148)(uVar8);
        iVar7 = *(int64_t *)(iVar6 + 0x10);
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180239b11;
        uVar8 = func_0x0001802454c0(uVar11);
        *(undefined8 *)(iVar7 + 0x30) = uVar8;
    } while( true );
}

// ============================================================
// Function: FUN_180239c60
// Address: 0x180239c60
// Size: 242 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180239c60(int64_t arg_28h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180239c70;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239c82;
    piVar4 = (int64_t *)fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (piVar4 != (int64_t *)0x0) {
        if (*piVar4 != 0) {
            while( true ) {
                iVar1 = *piVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239c98;
                puVar5 = (undefined8 *)func_0x000180222020(iVar1);
                if (puVar5 == (undefined8 *)0x0) break;
                uVar6 = puVar5[3];
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239cb6;
                func_0x000180224990(uVar6, 0x1804e2c88, 0x5f);
                uVar6 = *puVar5;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239cbf;
                (*(code *)0x69a158)(uVar6);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239cd4;
                func_0x000180224990(puVar5, 0x1804e2c88, 0x61);
            }
        }
        iVar1 = *piVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239cde;
        func_0x000180221d50(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239cf3;
        func_0x000180224990(piVar4, 0x1804e2c88, 0x19a);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239d05;
        func_0x00018028a2c0(5, 1, 0);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239d0a;
    func_0x0001802ab990();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239d19;
    uVar6 = fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239d2e;
    iVar2 = func_0x00018028a2c0(4, 1, 0);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239d47;
        func_0x000180224990(uVar6, 0x1804e2c88, 0x4a);
    }
    return;
}

// ============================================================
// Function: FUN_180239d60
// Address: 0x180239d60
// Size: 28 bytes
// ============================================================
void fcn.180239d60(int64_t arg1, int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180239d70;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (*(int64_t *)arg1 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            while( true ) {
                iVar1 = *(int64_t *)arg1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239d89;
                puVar4 = (undefined8 *)func_0x000180222020(iVar1);
                if (puVar4 == (undefined8 *)0x0) break;
                uVar2 = puVar4[3];
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239da7;
                func_0x000180224990(uVar2, 0x1804e2c88, 0x5f);
                uVar2 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239db0;
                (*(code *)0x69a158)(uVar2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239dc5;
                func_0x000180224990(puVar4, 0x1804e2c88, 0x61);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180239d7c
// Address: 0x180239d7c
// Size: 80 bytes
// ============================================================
void fcn.180239d60(int64_t arg1, int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180239d70;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (*(int64_t *)arg1 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            while( true ) {
                iVar1 = *(int64_t *)arg1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239d89;
                puVar4 = (undefined8 *)func_0x000180222020(iVar1);
                if (puVar4 == (undefined8 *)0x0) break;
                uVar2 = puVar4[3];
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239da7;
                func_0x000180224990(uVar2, 0x1804e2c88, 0x5f);
                uVar2 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239db0;
                (*(code *)0x69a158)(uVar2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239dc5;
                func_0x000180224990(puVar4, 0x1804e2c88, 0x61);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180239dcc
// Address: 0x180239dcc
// Size: 6 bytes
// ============================================================
void fcn.180239d60(int64_t arg1, int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180239d70;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if (*(int64_t *)arg1 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
            while( true ) {
                iVar1 = *(int64_t *)arg1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239d89;
                puVar4 = (undefined8 *)func_0x000180222020(iVar1);
                if (puVar4 == (undefined8 *)0x0) break;
                uVar2 = puVar4[3];
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239da7;
                func_0x000180224990(uVar2, 0x1804e2c88, 0x5f);
                uVar2 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239db0;
                (*(code *)0x69a158)(uVar2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180239dc5;
                func_0x000180224990(puVar4, 0x1804e2c88, 0x61);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180239de0
// Address: 0x180239de0
// Size: 32 bytes
// ============================================================
undefined8 fcn.180239de0(void)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uVar9;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar8 = 1;
    iVar7 = 4;
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18028a250;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (iVar8 == 1) {
        uVar5 = 0;
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028a268;
        uVar5 = func_0x000180245b10(iVar8);
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028a27e;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
    if ((iVar2 != 0) && (iVar7 < 7)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028a293;
        iVar3 = fcn.180222760(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
        if ((iVar3 != 0) && (piVar1 = *(int32_t **)(iVar3 + (int64_t)iVar7 * 8), piVar1 != (int32_t *)0x0)) {
            uVar9 = 0;
            if ((piVar1 != (int32_t *)0x0) && (*(int64_t *)(piVar1 + 4) != 0)) {
                if (uVar5 <= *(uint64_t *)(piVar1 + 2)) {
                    iVar3 = *(int64_t *)(piVar1 + 6);
                    iVar7 = *piVar1 + -1;
                    if (iVar3 != 0) {
                        iVar2 = iVar7 * 4;
                        while (0 < iVar7) {
                            iVar7 = iVar7 + -1;
                            uVar6 = (uint8_t)iVar2;
                            iVar2 = iVar2 + -4;
                            iVar3 = *(int64_t *)(iVar3 + (uint64_t)((uint32_t)(uVar5 >> (uVar6 & 0x3f)) & 0xf) * 8);
                            if (iVar3 == 0) {
                                return 0;
                            }
                        }
                        uVar9 = *(undefined8 *)(iVar3 + (uint64_t)((uint32_t)uVar5 & 0xf) * 8);
                    }
                }
                return uVar9;
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239e00
// Address: 0x180239e00
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180239e00(int64_t arg_28h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint32_t **ppuVar9;
    uint32_t *puVar10;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    uint32_t uVar12;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180239e10;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180239e25;
    ppuVar9 = (uint32_t **)fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar8));
    if (ppuVar9 == (uint32_t **)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180239e32;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180239e4a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                      *(int64_t *)(&stack0x00000048 + iVar8));
        *(undefined8 *)(&stack0x00000038 + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar8) = in_R9;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar8) = 0x1802296e4;
        iVar6 = fcn.18045a350(0x33, 0xc0103);
        iVar6 = -iVar6;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar8) = 0x1802296f1;
        uVar7 = fcn.180229700(*(int64_t *)(&stack0x00000050 + iVar6 + iVar8), 
                              *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar8), 
                              *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar8), 
                              *(int64_t *)(&stack0x00000068 + iVar6 + iVar8));
        return uVar7;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180239e7c;
    func_0x000180224990(uVar3, 0x1804e2c88, 0x91);
    *(undefined8 *)(in_RCX + 0x18) = 0;
    puVar10 = *ppuVar9;
    uVar3 = *(undefined8 *)((int64_t)&arg_28h + iVar8);
    uVar11 = *(undefined8 *)((int64_t)aiStackX_18 + iVar8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar8) = 0x18022211a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (puVar10 == (uint32_t *)0x0) {
        return 0;
    }
    uVar12 = *puVar10;
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar8) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar6 + iVar8) = uVar11;
    *(undefined8 *)(&stack0x00000038 + iVar6 + iVar8) = 0x180221db5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (puVar10 == (uint32_t *)0x0) {
        *(undefined8 *)(&stack0x00000038 + iVar5 + iVar6 + iVar8) = 0x180221dcb;
        fcn.180229480(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar6 + iVar8), 
                      *(int64_t *)(&stack0x00000068 + iVar5 + iVar6 + iVar8));
        *(undefined8 *)(&stack0x00000038 + iVar5 + iVar6 + iVar8) = 0x180221de3;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar6 + iVar8), 
                      *(int64_t *)(&stack0x00000068 + iVar5 + iVar6 + iVar8), 
                      *(int64_t *)((int64_t)&arg_70h + iVar5 + iVar6 + iVar8), 
                      *(int64_t *)((int64_t)&arg_78h + iVar5 + iVar6 + iVar8), 
                      *(int64_t *)(&stack0x00000090 + iVar5 + iVar6 + iVar8));
        *(undefined8 *)(&stack0x00000038 + iVar5 + iVar6 + iVar8) = 0x180221df5;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_80h + iVar5 + iVar6 + iVar8));
    } else {
        if (*puVar10 == 0x7fffffff) {
            *(undefined8 *)(&stack0x00000038 + iVar5 + iVar6 + iVar8) = 0x180221e14;
            fcn.180229480(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar6 + iVar8), 
                          *(int64_t *)(&stack0x00000068 + iVar5 + iVar6 + iVar8));
            *(undefined8 *)(&stack0x00000038 + iVar5 + iVar6 + iVar8) = 0x180221e2c;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar6 + iVar8), 
                          *(int64_t *)(&stack0x00000068 + iVar5 + iVar6 + iVar8), 
                          *(int64_t *)((int64_t)&arg_70h + iVar5 + iVar6 + iVar8), 
                          *(int64_t *)((int64_t)&arg_78h + iVar5 + iVar6 + iVar8), 
                          *(int64_t *)(&stack0x00000090 + iVar5 + iVar6 + iVar8));
            *(undefined8 *)(&stack0x00000038 + iVar5 + iVar6 + iVar8) = 0x180221e3e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_80h + iVar5 + iVar6 + iVar8));
            return 0;
        }
        *(undefined8 *)(&stack0x00000038 + iVar5 + iVar6 + iVar8) = 0x180221e5d;
        iVar4 = func_0x0001802225d0();
        if (iVar4 != 0) {
            uVar1 = *puVar10;
            if (((int32_t)uVar12 < (int32_t)uVar1) && (-1 < (int32_t)uVar12)) {
                iVar2 = *(int64_t *)(puVar10 + 2);
                *(undefined8 *)((int64_t)&arg_70h + iVar5 + iVar6 + iVar8) = uVar3;
                *(undefined8 *)(&stack0x00000038 + iVar5 + iVar6 + iVar8) = 0x180221e99;
                fcn.180498030(iVar2 + (int64_t)(int32_t)(uVar12 + 1) * 8, (int64_t)(int32_t)uVar12 * 8 + iVar2, 
                              (int64_t)(int32_t)(uVar1 - uVar12) << 3);
                *(int64_t *)((int64_t)(int32_t)uVar12 * 8 + *(int64_t *)(puVar10 + 2)) = in_RCX;
            } else {
                *(int64_t *)(*(int64_t *)(puVar10 + 2) + (int64_t)(int32_t)uVar1 * 8) = in_RCX;
            }
            *puVar10 = *puVar10 + 1;
            puVar10[4] = 0;
            return (uint64_t)*puVar10;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180239ea0
// Address: 0x180239ea0
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180239ea0(int64_t arg_28h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180239eb0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180239ec2;
    puVar6 = (undefined8 *)fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    if (puVar6 == (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180239ef8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180239f10;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)(&stack0x00000038 + iVar5) = 0;
        *(undefined8 *)(&stack0x00000040 + iVar5) = in_R9;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = 0x1802296e4;
        iVar4 = fcn.18045a350(0x33, 0xc0103);
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + iVar5) = 0x1802296f1;
        fcn.180229700(*(int64_t *)(&stack0x00000050 + iVar4 + iVar5), *(int64_t *)(&stack0x00000058 + iVar4 + iVar5), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar5), *(int64_t *)(&stack0x00000068 + iVar4 + iVar5));
        return;
    }
    do {
        iVar4 = puVar6[2];
        pcVar1 = *(code **)(iVar4 + 0x10);
        uVar2 = *(undefined8 *)(iVar4 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180239ede;
        uVar3 = (*pcVar1)(uVar2);
        *(undefined4 *)(iVar4 + 0x20) = uVar3;
        *(undefined4 *)(iVar4 + 0x24) = 3;
        uVar2 = *puVar6;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180239ef1;
        (*(code *)0x69a148)(uVar2);
    } while( true );
}

// ============================================================
// Function: FUN_180239f30
// Address: 0x180239f30
// Size: 88 bytes
// ============================================================
void fcn.180239f30(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180239f40;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239f4e;
        fcn.18021fe80(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239f57;
        fcn.18021fe80(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
        uVar1 = *(undefined8 *)(arg1 + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239f6d;
        fcn.180224990(uVar1, 0x1804e2d00, 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180239f82;
        fcn.180224990(arg1, 0x1804e2d00, 0x41);
    }
    return;
}

// ============================================================
// Function: FUN_180239f90
// Address: 0x180239f90
// Size: 216 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180239f90(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    uint64_t uVar4;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180239fa5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180239fc5;
    iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), *(int64_t *)(&stack0x00000040 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)(iVar2 + 0x20) = in_RCX;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180239feb;
        iVar3 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar1));
        *(int64_t *)(iVar2 + 0x28) = iVar3;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023a009;
            fcn.180224990(iVar2, 0x1804e2d00, 0x29);
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023a020;
    iVar1 = fcn.1802450c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
    uVar4 = 0xffffffffffffffff;
    if (299999999999 < -iVar1 - 1U) {
        uVar4 = iVar1 + 300000000000;
    }
    *(uint64_t *)(iVar2 + 0x18) = uVar4 / 1000000;
    return iVar2;
}

// ============================================================
// Function: FUN_18023a070
// Address: 0x18023a070
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18023a070(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023a080;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18023a091;
    uVar2 = fcn.1802375f0(in_RDX);
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    *in_RCX = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_18023a0c0
// Address: 0x18023a0c0
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18023a0c0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023a0d0;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18023a0e1;
    uVar2 = fcn.1802375f0(in_RDX);
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    *(undefined8 *)(in_RCX + 8) = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_18023a130
// Address: 0x18023a130
// Size: 29 bytes
// ============================================================
void fcn.18023a130(int32_t *param_1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar8;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    pcVar6 = (code *)0x18023a330;
    if (param_1 != (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)(&stack0x00000050 + iVar4 + iVar5) = unaff_RBX;
        iVar7 = 0;
        *(undefined8 *)(&stack0x00000060 + iVar4 + iVar5) = unaff_R14;
        if (0 < *param_1) {
            *(undefined8 *)(&stack0x00000058 + iVar4 + iVar5) = unaff_RDI;
            iVar8 = 0;
            do {
                iVar1 = *(int64_t *)(iVar8 + *(int64_t *)(param_1 + 2));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(param_1 + 8);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220b2;
                        (*pcVar6)();
                    } else {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220ae;
                        (*pcVar2)(pcVar6, iVar1);
                    }
                }
                iVar7 = iVar7 + 1;
                iVar8 = iVar8 + 8;
            } while (iVar7 < *param_1);
        }
        uVar3 = *(undefined8 *)(param_1 + 2);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220ec;
        fcn.180224990(param_1, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_18023a150
// Address: 0x18023a150
// Size: 471 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint32_t fcn.18023a150(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    undefined8 *in_RDX;
    int32_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    int64_t var_10h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18023a16a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar12 = 1;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a187;
        iVar4 = fcn.180222010();
        iVar10 = 0;
        *(int32_t *)((int64_t)&arg_28h + iVar5) = iVar4;
        if (0 < iVar4) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a1aa;
                piVar6 = (int32_t *)fcn.180222340(in_RCX, iVar10);
                if (piVar6 != (int32_t *)0x0) {
                    iVar1 = *piVar6;
                    uVar11 = 0xffffffff;
                    *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
                    *(undefined8 *)((int64_t)&arg_40h + iVar5) = 0;
                    if (iVar1 == 0) {
                        uVar9 = *(undefined8 *)(piVar6 + 8);
                        uVar2 = *(undefined8 *)(piVar6 + 6);
                        uVar3 = in_RDX[2];
                        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a1f1;
                        iVar7 = func_0x00018023b200(uVar3, uVar2, uVar9);
                        if (iVar7 == 0) {
                            piVar6[0x18] = 1;
                            uVar11 = 0;
                        } else {
                            uVar9 = in_RDX[5];
                            uVar2 = in_RDX[4];
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a214;
                            iVar8 = func_0x0001802abaa0(uVar2, uVar9);
                            if (iVar8 != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a228;
                                uVar9 = func_0x0001801e8e30(iVar7);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a235;
                                iVar4 = func_0x000180235a30((int64_t)&arg_40h + iVar5, uVar9);
                                if (iVar4 == 1) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a24b;
                                    iVar4 = func_0x0001802abe30(iVar8, *(undefined8 *)((int64_t)&arg_40h + iVar5));
                                    if (iVar4 == 1) {
                                        if (piVar6[0x16] == 1) {
                                            if (in_RDX[1] != 0) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a26e;
                                                uVar9 = func_0x000180238400();
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a27b;
                                                iVar4 = func_0x000180235a30((int64_t)&arg_38h + iVar5, uVar9);
                                                if (iVar4 == 1) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a28d;
                                                    iVar4 = func_0x0001802abe10(iVar8, *(undefined8 *)
                                                                                        ((int64_t)&arg_38h + iVar5));
                                                    if (iVar4 == 1) goto code_r0x00018023a292;
                                                }
                                                goto code_r0x00018023a2da;
                                            }
                                            iVar4 = 4;
                                        } else {
code_r0x00018023a292:
                                            uVar9 = in_RDX[3];
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a29e;
                                            func_0x0001802abeb0(iVar8, uVar9);
                                            uVar9 = *in_RDX;
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a2ac;
                                            iVar4 = func_0x0001802abb40(iVar8, uVar9, 0);
                                            if (iVar4 == 1) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a2c3;
                                                iVar4 = func_0x0001802abff0(iVar8, piVar6);
                                                iVar4 = (iVar4 != 1) + 2;
                                            } else {
                                                iVar4 = 4;
                                            }
                                        }
                                        piVar6[0x18] = iVar4;
                                        uVar11 = (uint32_t)(iVar4 == 2);
                                    }
                                }
                            }
code_r0x00018023a2da:
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a2e4;
                            func_0x000180235820(*(undefined8 *)((int64_t)&arg_38h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a2ee;
                            func_0x000180235820(*(undefined8 *)((int64_t)&arg_40h + iVar5));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18023a2f6;
                            func_0x0001802ab9f0(iVar8);
                            if ((int32_t)uVar11 < 0) {
                                return uVar11;
                            }
                            iVar4 = *(int32_t *)((int64_t)&arg_28h + iVar5);
                        }
                    } else {
                        piVar6[0x18] = 5;
                        uVar11 = 0;
                    }
                    uVar12 = uVar12 & uVar11;
                }
                iVar10 = iVar10 + 1;
            } while (iVar10 < iVar4);
        }
    }
    return uVar12;
}

// ============================================================
// Function: FUN_18023a330
// Address: 0x18023a330
// Size: 141 bytes
// ============================================================
void fcn.18023a330(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18023a344;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023a360;
        fcn.180224990(uVar1, 0x1804e2d18, 0x27);
        uVar1 = *(undefined8 *)(arg1 + 0x30);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023a376;
        fcn.180224990(uVar1, 0x1804e2d18, 0x28);
        uVar1 = *(undefined8 *)(arg1 + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023a38c;
        fcn.180224990(uVar1, 0x1804e2d18, 0x29);
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023a3a2;
        fcn.180224990(uVar1, 0x1804e2d18, 0x2a);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023a3b7;
        fcn.180224990(arg1, 0x1804e2d18, 0x2b);
    }
    return;
}

// ============================================================
// Function: FUN_18023a440
// Address: 0x18023a440
// Size: 64 bytes
// ============================================================
void fcn.18023a440(void)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023a44a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18023a464;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1))
    ;
    if (puVar2 == (undefined4 *)0x0) {
        return;
    }
    puVar2[0x16] = 0xffffffff;
    *puVar2 = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_18023a480
// Address: 0x18023a480
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18023a480(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18023a495;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(undefined8 *)(in_RCX + 0x48);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023a4b7;
    fcn.180224990(uVar1, 0x1804e2d18, 0xad);
    *(undefined8 *)(in_RCX + 0x48) = 0;
    *(undefined8 *)(in_RCX + 0x50) = 0;
    *(undefined4 *)(in_RCX + 0x60) = 0;
    if ((in_RDX != 0) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023a4e6;
        iVar2 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(int64_t *)(in_RCX + 0x48) = iVar2;
        if (iVar2 == 0) {
            return 0;
        }
        *(int64_t *)(in_RCX + 0x50) = in_R8;
    }
    return 1;
}

// ============================================================
// Function: FUN_18023a580
// Address: 0x18023a580
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18023a580(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023a595;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = *in_RDX;
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = 0;
    *(int64_t *)((int64_t)&arg_30h + iVar1) = iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023a5c4;
    iVar2 = fcn.180228a10(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                          *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                          *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1), 
                          *(int64_t *)(&stack0x00000068 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar1) + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023a5f7;
    iVar2 = fcn.18023af80(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1));
    if (iVar2 != 0) {
        *in_RDX = *in_RDX + (int64_t)in_R8D;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023a60c;
    fcn.180228780(*(int64_t *)((int64_t)&arg_40h + iVar1));
    return iVar2;
}

// ============================================================
// Function: FUN_18023a620
// Address: 0x18023a620
// Size: 386 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

undefined4 fcn.18023a620(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    undefined *puVar6;
    int32_t iVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_20;
    
    uStack_20 = 0x18023a638;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a648;
    iVar2 = fcn.18023aa30(*(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
    if (iVar2 == -1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a652;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a66a;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a67c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a6a9;
        iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8));
        *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8) = iVar5;
        if (iVar5 != 0) {
            puVar6 = (undefined *)(iVar5 + 2);
            uVar8 = 2;
            iVar7 = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a6c6;
            iVar2 = fcn.180222010(in_RCX);
            if (iVar2 < 1) {
code_r0x00018023a753:
                puVar6 = *(undefined **)((int64_t)aiStackX_18 + iVar4 + -8);
                *puVar6 = (char)(uVar8 - 2 >> 8);
                puVar6[1] = (char)uVar8 + -2;
                *(int32_t *)((int64_t)&var_8h + iVar4) = (int32_t)uVar8;
                if ((int32_t)uVar8 != -1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a782;
                    uVar3 = fcn.180228a90(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000068 + iVar4)
                                          , *(int64_t *)(&stack0x00000070 + iVar4), 
                                          *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4)
                                         );
                    uVar1 = *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a79b;
                    fcn.180224990(uVar1, 0x1804e2d48, 0x191);
                    return uVar3;
                }
            } else {
                while( true ) {
                    *(undefined **)((int64_t)&arg_58h + iVar4) = puVar6 + 2;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a6e3;
                    fcn.180222340(in_RCX, iVar7);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a6f0;
                    iVar2 = fcn.18023a7b0(*(int64_t *)((int64_t)&var_8h + iVar4), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                    if (iVar2 == -1) break;
                    puVar6[1] = (char)iVar2;
                    *puVar6 = (char)((uint32_t)iVar2 >> 8);
                    iVar7 = iVar7 + 1;
                    uVar8 = uVar8 + (int64_t)(iVar2 + 2);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a712;
                    iVar2 = fcn.180222010(in_RCX);
                    if (iVar2 <= iVar7) {
                        if (uVar8 < 0x10000) goto code_r0x00018023a753;
                        break;
                    }
                    puVar6 = *(undefined **)((int64_t)&arg_58h + iVar4);
                }
                uVar1 = *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023a73d;
                fcn.180224990(uVar1, 0x1804e2d48, 0x16e);
                *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0;
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0xffffffff;
            }
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18023a7b0
// Address: 0x18023a7b0
// Size: 630 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18023a7b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined *puVar10;
    undefined *puVar11;
    int32_t *in_RCX;
    undefined *puVar12;
    undefined8 *in_RDX;
    uint64_t uVar13;
    undefined *puVar14;
    undefined *puVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18023a7ce;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    puVar11 = (undefined *)0x0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a7e1;
    iVar8 = fcn.18023a3f0();
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a7ea;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a802;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)((int64_t)&arg_38h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a814;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
        puVar10 = puVar11;
        goto code_r0x00018023a814;
    }
    if (*in_RCX == 0) {
        uVar13 = *(int64_t *)(in_RCX + 0xe) + 0x2f + *(int64_t *)(in_RCX + 0x14);
    } else {
        uVar13 = *(uint64_t *)(in_RCX + 4);
    }
    if (0x7fffffff < uVar13) {
        return 0xffffffff;
    }
    if (in_RDX == (undefined8 *)0x0) goto code_r0x00018023a9c6;
    puVar12 = (undefined *)*in_RDX;
    if (puVar12 == (undefined *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a87e;
        puVar10 = (undefined *)
                  fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
        puVar12 = puVar10;
        puVar15 = puVar10;
        if (puVar10 == (undefined *)0x0) goto code_r0x00018023a814;
    } else {
        puVar10 = puVar12 + uVar13;
        puVar15 = puVar11;
    }
    *in_RDX = puVar10;
    if (*in_RCX != 0) {
        uVar2 = *(undefined8 *)(in_RCX + 2);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023aa24;
        fcn.180498030(puVar12, uVar2, uVar13);
        goto code_r0x00018023a9c6;
    }
    *puVar12 = 0;
    puVar14 = puVar12 + 0x2b;
    puVar1 = *(undefined4 **)(in_RCX + 6);
    uVar5 = puVar1[1];
    uVar6 = puVar1[2];
    uVar7 = puVar1[3];
    *(undefined4 *)(puVar12 + 1) = *puVar1;
    *(undefined4 *)(puVar12 + 5) = uVar5;
    *(undefined4 *)(puVar12 + 9) = uVar6;
    *(undefined4 *)(puVar12 + 0xd) = uVar7;
    uVar5 = puVar1[5];
    uVar6 = puVar1[6];
    uVar7 = puVar1[7];
    *(undefined4 *)(puVar12 + 0x11) = puVar1[4];
    *(undefined4 *)(puVar12 + 0x15) = uVar5;
    *(undefined4 *)(puVar12 + 0x19) = uVar6;
    *(undefined4 *)(puVar12 + 0x1d) = uVar7;
    puVar12[0x21] = *(undefined *)((int64_t)in_RCX + 0x2f);
    puVar12[0x22] = *(undefined *)((int64_t)in_RCX + 0x2e);
    puVar12[0x23] = *(undefined *)((int64_t)in_RCX + 0x2d);
    puVar12[0x24] = *(undefined *)(in_RCX + 0xb);
    puVar12[0x25] = *(undefined *)((int64_t)in_RCX + 0x2b);
    puVar12[0x26] = *(undefined *)((int64_t)in_RCX + 0x2a);
    puVar12[0x27] = *(undefined *)((int64_t)in_RCX + 0x29);
    puVar12[0x28] = *(undefined *)(in_RCX + 10);
    puVar12[0x29] = *(undefined *)((int64_t)in_RCX + 0x39);
    puVar12[0x2a] = *(undefined *)(in_RCX + 0xe);
    if (*(int64_t *)(in_RCX + 0xe) != 0) {
        uVar2 = *(undefined8 *)(in_RCX + 0xc);
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a909;
        fcn.180498030(puVar14, uVar2);
        puVar14 = puVar14 + *(int64_t *)(in_RCX + 0xe);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a915;
    iVar8 = func_0x00018023a550(in_RCX);
    puVar10 = puVar15;
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a91e;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a936;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)((int64_t)&arg_38h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a948;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
    } else {
        if (*in_RCX == 0) {
            uVar2 = *(undefined8 *)(in_RCX + 0x14);
            if (puVar14 == (undefined *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a9f6;
                puVar11 = (undefined *)
                          fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9))
                ;
                puVar14 = puVar11;
                if (puVar11 == (undefined *)0x0) goto code_r0x00018023a9fe;
            }
            *puVar14 = *(undefined *)(in_RCX + 0x10);
            puVar14[1] = *(undefined *)((int64_t)in_RCX + 0x41);
            puVar14[2] = *(undefined *)((int64_t)in_RCX + 0x51);
            puVar14[3] = *(undefined *)(in_RCX + 0x14);
            uVar3 = *(undefined8 *)(in_RCX + 0x14);
            uVar4 = *(undefined8 *)(in_RCX + 0x12);
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a9be;
            fcn.180498030(puVar14 + 4, uVar4, uVar3);
            if ((int32_t)uVar2 != -4 && -1 < (int32_t)uVar2 + 4) {
code_r0x00018023a9c6:
                return uVar13 & 0xffffffff;
            }
            goto code_r0x00018023a814;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a956;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a96e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)((int64_t)&arg_38h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a980;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
    }
code_r0x00018023a9fe:
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023aa13;
    fcn.180224990(puVar11, 0x1804e2d48, 0xc2);
code_r0x00018023a814:
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18023a829;
    fcn.180224990(puVar10, 0x1804e2d48, 0xfb);
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18023aa30
// Address: 0x18023aa30
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

uint64_t fcn.18023aa30(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *piVar6;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [4];
    undefined auStack_28 [6];
    int64_t var_22h;
    
    _auStack_28 = 0x18023aa41;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    bVar1 = false;
    puVar8 = (undefined *)0x0;
    if (in_RDX != (int64_t *)0x0) {
        iVar4 = *in_RDX;
        bVar1 = false;
        if (iVar4 == 0) {
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa63;
            iVar2 = fcn.18023aa30(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10));
            if (iVar2 == -1) {
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa6d;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar3))
                ;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa85;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar3)
                              , *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), *(int64_t *)((int64_t)&arg_30h + iVar3))
                ;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa97;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
                return 0xffffffff;
            }
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023aabc;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
            *in_RDX = iVar4;
            if (iVar4 == 0) {
                return 0xffffffff;
            }
            bVar1 = true;
        }
        puVar8 = (undefined *)(iVar4 + 2);
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    uVar7 = 2;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + -8) = unaff_R14;
    iVar9 = 0;
    *(undefined8 *)(auStack_28 + iVar3) = 0x18023aaed;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        do {
            if (in_RDX == (int64_t *)0x0) {
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab3a;
                piVar6 = (int32_t *)fcn.180222340(in_RCX, iVar9);
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab45;
                iVar2 = fcn.18023a3f0(piVar6);
                if (iVar2 == 0) {
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023abe0;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023abf8;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac0a;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac1e;
                    fcn.180224990(0, 0x1804e2d48, 0xfb);
                    goto code_r0x00018023ac1e;
                }
                if (*piVar6 == 0) {
                    uVar5 = *(int64_t *)(piVar6 + 0xe) + 0x2f + *(int64_t *)(piVar6 + 0x14);
                } else {
                    uVar5 = *(uint64_t *)(piVar6 + 4);
                }
                if ((0x7fffffff < uVar5) || ((int32_t)uVar5 == -1)) goto code_r0x00018023ac1e;
            } else {
                *(undefined **)((int64_t)&arg_38h + iVar3) = puVar8 + 2;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab0e;
                fcn.180222340(in_RCX, iVar9);
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab1b;
                uVar5 = fcn.18023a7b0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                if ((int32_t)uVar5 == -1) goto code_r0x00018023ac1e;
                puVar8[1] = (char)uVar5;
                *puVar8 = (char)(uVar5 >> 8);
                puVar8 = *(undefined **)((int64_t)&arg_38h + iVar3);
            }
            iVar9 = iVar9 + 1;
            uVar7 = uVar7 + (int64_t)((int32_t)uVar5 + 2);
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab8d;
            iVar2 = fcn.180222010(in_RCX);
        } while (iVar9 < iVar2);
        if (0xffff < uVar7) {
code_r0x00018023ac1e:
            if (bVar1) {
                iVar4 = *in_RDX;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac38;
                fcn.180224990(iVar4, 0x1804e2d48, 0x16e);
                *in_RDX = 0;
            }
            return 0xffffffff;
        }
    }
    if (in_RDX != (int64_t *)0x0) {
        puVar8 = (undefined *)*in_RDX;
        *puVar8 = (char)(uVar7 - 2 >> 8);
        puVar8[1] = (char)uVar7 + -2;
        if (!bVar1) {
            *in_RDX = *in_RDX + uVar7;
        }
    }
    return uVar7 & 0xffffffff;
}

// ============================================================
// Function: FUN_18023aace
// Address: 0x18023aace
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

uint64_t fcn.18023aa30(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *piVar6;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [4];
    undefined auStack_28 [6];
    int64_t var_22h;
    
    _auStack_28 = 0x18023aa41;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    bVar1 = false;
    puVar8 = (undefined *)0x0;
    if (in_RDX != (int64_t *)0x0) {
        iVar4 = *in_RDX;
        bVar1 = false;
        if (iVar4 == 0) {
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa63;
            iVar2 = fcn.18023aa30(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10));
            if (iVar2 == -1) {
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa6d;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar3))
                ;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa85;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar3)
                              , *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), *(int64_t *)((int64_t)&arg_30h + iVar3))
                ;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa97;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
                return 0xffffffff;
            }
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023aabc;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
            *in_RDX = iVar4;
            if (iVar4 == 0) {
                return 0xffffffff;
            }
            bVar1 = true;
        }
        puVar8 = (undefined *)(iVar4 + 2);
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    uVar7 = 2;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + -8) = unaff_R14;
    iVar9 = 0;
    *(undefined8 *)(auStack_28 + iVar3) = 0x18023aaed;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        do {
            if (in_RDX == (int64_t *)0x0) {
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab3a;
                piVar6 = (int32_t *)fcn.180222340(in_RCX, iVar9);
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab45;
                iVar2 = fcn.18023a3f0(piVar6);
                if (iVar2 == 0) {
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023abe0;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023abf8;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac0a;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac1e;
                    fcn.180224990(0, 0x1804e2d48, 0xfb);
                    goto code_r0x00018023ac1e;
                }
                if (*piVar6 == 0) {
                    uVar5 = *(int64_t *)(piVar6 + 0xe) + 0x2f + *(int64_t *)(piVar6 + 0x14);
                } else {
                    uVar5 = *(uint64_t *)(piVar6 + 4);
                }
                if ((0x7fffffff < uVar5) || ((int32_t)uVar5 == -1)) goto code_r0x00018023ac1e;
            } else {
                *(undefined **)((int64_t)&arg_38h + iVar3) = puVar8 + 2;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab0e;
                fcn.180222340(in_RCX, iVar9);
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab1b;
                uVar5 = fcn.18023a7b0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                if ((int32_t)uVar5 == -1) goto code_r0x00018023ac1e;
                puVar8[1] = (char)uVar5;
                *puVar8 = (char)(uVar5 >> 8);
                puVar8 = *(undefined **)((int64_t)&arg_38h + iVar3);
            }
            iVar9 = iVar9 + 1;
            uVar7 = uVar7 + (int64_t)((int32_t)uVar5 + 2);
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab8d;
            iVar2 = fcn.180222010(in_RCX);
        } while (iVar9 < iVar2);
        if (0xffff < uVar7) {
code_r0x00018023ac1e:
            if (bVar1) {
                iVar4 = *in_RDX;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac38;
                fcn.180224990(iVar4, 0x1804e2d48, 0x16e);
                *in_RDX = 0;
            }
            return 0xffffffff;
        }
    }
    if (in_RDX != (int64_t *)0x0) {
        puVar8 = (undefined *)*in_RDX;
        *puVar8 = (char)(uVar7 - 2 >> 8);
        puVar8[1] = (char)uVar7 + -2;
        if (!bVar1) {
            *in_RDX = *in_RDX + uVar7;
        }
    }
    return uVar7 & 0xffffffff;
}

// ============================================================
// Function: FUN_18023abdb
// Address: 0x18023abdb
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

uint64_t fcn.18023aa30(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *piVar6;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [4];
    undefined auStack_28 [6];
    int64_t var_22h;
    
    _auStack_28 = 0x18023aa41;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    bVar1 = false;
    puVar8 = (undefined *)0x0;
    if (in_RDX != (int64_t *)0x0) {
        iVar4 = *in_RDX;
        bVar1 = false;
        if (iVar4 == 0) {
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa63;
            iVar2 = fcn.18023aa30(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10));
            if (iVar2 == -1) {
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa6d;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar3))
                ;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa85;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar3)
                              , *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), *(int64_t *)((int64_t)&arg_30h + iVar3))
                ;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023aa97;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
                return 0xffffffff;
            }
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023aabc;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
            *in_RDX = iVar4;
            if (iVar4 == 0) {
                return 0xffffffff;
            }
            bVar1 = true;
        }
        puVar8 = (undefined *)(iVar4 + 2);
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RBP;
    uVar7 = 2;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar3 + -8) = unaff_R14;
    iVar9 = 0;
    *(undefined8 *)(auStack_28 + iVar3) = 0x18023aaed;
    iVar2 = fcn.180222010(in_RCX);
    if (0 < iVar2) {
        do {
            if (in_RDX == (int64_t *)0x0) {
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab3a;
                piVar6 = (int32_t *)fcn.180222340(in_RCX, iVar9);
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab45;
                iVar2 = fcn.18023a3f0(piVar6);
                if (iVar2 == 0) {
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023abe0;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023abf8;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x10), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac0a;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 0x18));
                    *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac1e;
                    fcn.180224990(0, 0x1804e2d48, 0xfb);
                    goto code_r0x00018023ac1e;
                }
                if (*piVar6 == 0) {
                    uVar5 = *(int64_t *)(piVar6 + 0xe) + 0x2f + *(int64_t *)(piVar6 + 0x14);
                } else {
                    uVar5 = *(uint64_t *)(piVar6 + 4);
                }
                if ((0x7fffffff < uVar5) || ((int32_t)uVar5 == -1)) goto code_r0x00018023ac1e;
            } else {
                *(undefined **)((int64_t)&arg_38h + iVar3) = puVar8 + 2;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab0e;
                fcn.180222340(in_RCX, iVar9);
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab1b;
                uVar5 = fcn.18023a7b0(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                if ((int32_t)uVar5 == -1) goto code_r0x00018023ac1e;
                puVar8[1] = (char)uVar5;
                *puVar8 = (char)(uVar5 >> 8);
                puVar8 = *(undefined **)((int64_t)&arg_38h + iVar3);
            }
            iVar9 = iVar9 + 1;
            uVar7 = uVar7 + (int64_t)((int32_t)uVar5 + 2);
            *(undefined8 *)(auStack_28 + iVar3) = 0x18023ab8d;
            iVar2 = fcn.180222010(in_RCX);
        } while (iVar9 < iVar2);
        if (0xffff < uVar7) {
code_r0x00018023ac1e:
            if (bVar1) {
                iVar4 = *in_RDX;
                *(undefined8 *)(auStack_28 + iVar3) = 0x18023ac38;
                fcn.180224990(iVar4, 0x1804e2d48, 0x16e);
                *in_RDX = 0;
            }
            return 0xffffffff;
        }
    }
    if (in_RDX != (int64_t *)0x0) {
        puVar8 = (undefined *)*in_RDX;
        *puVar8 = (char)(uVar7 - 2 >> 8);
        puVar8[1] = (char)uVar7 + -2;
        if (!bVar1) {
            *in_RDX = *in_RDX + uVar7;
        }
    }
    return uVar7 & 0xffffffff;
}

// ============================================================
// Function: FUN_18023ac50
// Address: 0x18023ac50
// Size: 805 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_17h

uint32_t * fcn.18023ac50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    uint32_t *arg1;
    uint16_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t **in_RCX;
    uint64_t uVar6;
    uint8_t **in_RDX;
    uint32_t *arg1_00;
    uint64_t in_R8;
    uint8_t *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    int64_t var_17h;
    
    uStack_20 = 0x18023ac74;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    arg1_00 = (uint32_t *)0x0;
    if (0xfffe < in_R8 - 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023af22;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        goto code_r0x00018023af27;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ac97;
    arg1_00 = (uint32_t *)fcn.18023a440();
    if (arg1_00 == (uint32_t *)0x0) goto code_r0x00018023af4c;
    puVar7 = *in_RDX;
    uVar1 = *puVar7;
    *arg1_00 = (uint32_t)uVar1;
    if (uVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023aef3;
        iVar5 = fcn.180223170(*(int64_t *)((int64_t)&var_8h + iVar4));
        *(int64_t *)(arg1_00 + 2) = iVar5;
        if (iVar5 != 0) {
            *(uint64_t *)(arg1_00 + 4) = in_R8;
            puVar7 = puVar7 + in_R8;
code_r0x00018023af04:
            *in_RDX = puVar7;
            if (in_RCX == (uint32_t **)0x0) {
                return arg1_00;
            }
            arg1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023af15;
            fcn.18023a330((int64_t)arg1);
            *in_RCX = arg1_00;
            return arg1_00;
        }
        goto code_r0x00018023af4c;
    }
    if (in_R8 < 0x2b) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023acbf;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ace8;
        iVar5 = fcn.180223170(*(int64_t *)((int64_t)&var_8h + iVar4));
        *(int64_t *)(arg1_00 + 6) = iVar5;
        if (iVar5 == 0) goto code_r0x00018023af4c;
        *(undefined8 *)(arg1_00 + 8) = 0x20;
        uVar1 = puVar7[0x21];
        *(uint64_t *)(arg1_00 + 10) = (uint64_t)uVar1 << 0x38;
        uVar6 = (uint64_t)puVar7[0x22] << 0x30 | (uint64_t)uVar1 << 0x38;
        *(uint64_t *)(arg1_00 + 10) = uVar6;
        uVar6 = (uint64_t)puVar7[0x23] << 0x28 | uVar6;
        *(uint64_t *)(arg1_00 + 10) = uVar6;
        uVar6 = (uint64_t)puVar7[0x24] << 0x20 | uVar6;
        *(uint64_t *)(arg1_00 + 10) = uVar6;
        uVar6 = (uint64_t)puVar7[0x25] << 0x18 | uVar6;
        *(uint64_t *)(arg1_00 + 10) = uVar6;
        uVar6 = (uint64_t)puVar7[0x26] << 0x10 | uVar6;
        *(uint64_t *)(arg1_00 + 10) = uVar6;
        uVar6 = (uint64_t)puVar7[0x27] << 8 | uVar6;
        *(uint64_t *)(arg1_00 + 10) = uVar6;
        *(uint64_t *)(arg1_00 + 10) = puVar7[0x28] | uVar6;
        uVar6 = (uint64_t)CONCAT11(puVar7[0x29], puVar7[0x2a]);
        if (in_R8 - 0x2b < uVar6) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ad96;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            goto code_r0x00018023af27;
        }
        if (uVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023adbd;
            iVar5 = fcn.180223170(*(int64_t *)((int64_t)&var_8h + iVar4));
            *(int64_t *)(arg1_00 + 0xc) = iVar5;
            if (iVar5 == 0) goto code_r0x00018023af4c;
        }
        puVar7 = puVar7 + uVar6 + 0x2b;
        *(uint64_t *)(arg1_00 + 0xe) = uVar6;
        uVar6 = (in_R8 - 0x2b) - uVar6;
        if (*arg1_00 == 0) {
            if (uVar6 < 5) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ae08;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
code_r0x00018023ae14:
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ae20;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4));
                goto code_r0x00018023ae25;
            }
            *(uint8_t *)(arg1_00 + 0x10) = *puVar7;
            *(uint8_t *)((int64_t)arg1_00 + 0x41) = puVar7[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ae5c;
            iVar3 = func_0x00018023a3c0(arg1_00);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ae65;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                goto code_r0x00018023ae14;
            }
            uVar2 = CONCAT11(puVar7[2], puVar7[3]);
            if (puVar7 + (uVar6 - (int64_t)(puVar7 + 4)) < (uint8_t *)(uint64_t)uVar2) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ae96;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                goto code_r0x00018023ae14;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023aeb5;
            iVar3 = fcn.18023a480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4));
            if ((iVar3 == 1) &&
               (iVar3 = ((uint32_t)uVar2 - (int32_t)(puVar7 + (uVar6 - (int64_t)(puVar7 + 4)))) + (int32_t)uVar6,
               0 < iVar3)) {
                puVar7 = puVar7 + 4 + (int64_t)((uint8_t *)(uint64_t)uVar2 + (uVar6 - (int64_t)iVar3));
                goto code_r0x00018023af04;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023adde;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023adf6;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4));
code_r0x00018023ae25:
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ae32;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023ae37;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    }
code_r0x00018023af27:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023af3a;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023af4c;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
code_r0x00018023af4c:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023af54;
    fcn.18023a330((int64_t)arg1_00);
    return (uint32_t *)0x0;
}

// ============================================================
// Function: FUN_18023af80
// Address: 0x18023af80
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023af80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar7;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023af91;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (0xfffd < in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b161;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b179;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b18b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    puVar1 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    uVar6 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
    *in_RDX = (int64_t)(puVar1 + 2);
    if (uVar6 != in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afd7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afef;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b001;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if ((in_RCX == (int64_t *)0x0) || (iVar5 = *in_RCX, iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0ef;
        iVar5 = fcn.180221f20();
        if (iVar5 == 0) {
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b036;
        iVar4 = fcn.180222020(iVar5);
        while (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b048;
            fcn.18023a330(iVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b050;
            iVar4 = fcn.180222020(iVar5);
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    do {
        if (uVar6 == 0) {
            if (in_RCX == (int64_t *)0x0) {
                return iVar5;
            }
            if (*in_RCX != 0) {
                return iVar5;
            }
            *in_RCX = iVar5;
            return iVar5;
        }
        if (uVar6 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b118;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x00018023b11d:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b130;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b142;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018023b142;
        }
        puVar1 = (undefined *)*in_RDX;
        uVar7 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
        *in_RDX = (int64_t)(puVar1 + 2);
        if ((uVar7 == 0) || (uVar6 - 2 < uVar7)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b10c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            goto code_r0x00018023b11d;
        }
        uVar6 = (uVar6 - 2) - uVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b09e;
        iVar4 = fcn.18023ac50(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        if (iVar4 == 0) goto code_r0x00018023b142;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0b5;
        iVar2 = fcn.180222110(*(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
    } while (iVar2 != 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b105;
    fcn.18023a330(iVar4);
code_r0x00018023b142:
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b155;
        fcn.18023a130(iVar5);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023afad
// Address: 0x18023afad
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023af80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar7;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023af91;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (0xfffd < in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b161;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b179;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b18b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    puVar1 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    uVar6 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
    *in_RDX = (int64_t)(puVar1 + 2);
    if (uVar6 != in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afd7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afef;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b001;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if ((in_RCX == (int64_t *)0x0) || (iVar5 = *in_RCX, iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0ef;
        iVar5 = fcn.180221f20();
        if (iVar5 == 0) {
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b036;
        iVar4 = fcn.180222020(iVar5);
        while (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b048;
            fcn.18023a330(iVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b050;
            iVar4 = fcn.180222020(iVar5);
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    do {
        if (uVar6 == 0) {
            if (in_RCX == (int64_t *)0x0) {
                return iVar5;
            }
            if (*in_RCX != 0) {
                return iVar5;
            }
            *in_RCX = iVar5;
            return iVar5;
        }
        if (uVar6 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b118;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x00018023b11d:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b130;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b142;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018023b142;
        }
        puVar1 = (undefined *)*in_RDX;
        uVar7 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
        *in_RDX = (int64_t)(puVar1 + 2);
        if ((uVar7 == 0) || (uVar6 - 2 < uVar7)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b10c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            goto code_r0x00018023b11d;
        }
        uVar6 = (uVar6 - 2) - uVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b09e;
        iVar4 = fcn.18023ac50(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        if (iVar4 == 0) goto code_r0x00018023b142;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0b5;
        iVar2 = fcn.180222110(*(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
    } while (iVar2 != 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b105;
    fcn.18023a330(iVar4);
code_r0x00018023b142:
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b155;
        fcn.18023a130(iVar5);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b014
// Address: 0x18023b014
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023af80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar7;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023af91;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (0xfffd < in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b161;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b179;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b18b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    puVar1 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    uVar6 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
    *in_RDX = (int64_t)(puVar1 + 2);
    if (uVar6 != in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afd7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afef;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b001;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if ((in_RCX == (int64_t *)0x0) || (iVar5 = *in_RCX, iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0ef;
        iVar5 = fcn.180221f20();
        if (iVar5 == 0) {
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b036;
        iVar4 = fcn.180222020(iVar5);
        while (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b048;
            fcn.18023a330(iVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b050;
            iVar4 = fcn.180222020(iVar5);
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    do {
        if (uVar6 == 0) {
            if (in_RCX == (int64_t *)0x0) {
                return iVar5;
            }
            if (*in_RCX != 0) {
                return iVar5;
            }
            *in_RCX = iVar5;
            return iVar5;
        }
        if (uVar6 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b118;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x00018023b11d:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b130;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b142;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018023b142;
        }
        puVar1 = (undefined *)*in_RDX;
        uVar7 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
        *in_RDX = (int64_t)(puVar1 + 2);
        if ((uVar7 == 0) || (uVar6 - 2 < uVar7)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b10c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            goto code_r0x00018023b11d;
        }
        uVar6 = (uVar6 - 2) - uVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b09e;
        iVar4 = fcn.18023ac50(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        if (iVar4 == 0) goto code_r0x00018023b142;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0b5;
        iVar2 = fcn.180222110(*(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
    } while (iVar2 != 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b105;
    fcn.18023a330(iVar4);
code_r0x00018023b142:
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b155;
        fcn.18023a130(iVar5);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b055
// Address: 0x18023b055
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023af80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar7;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023af91;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (0xfffd < in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b161;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b179;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b18b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    puVar1 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    uVar6 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
    *in_RDX = (int64_t)(puVar1 + 2);
    if (uVar6 != in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afd7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afef;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b001;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if ((in_RCX == (int64_t *)0x0) || (iVar5 = *in_RCX, iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0ef;
        iVar5 = fcn.180221f20();
        if (iVar5 == 0) {
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b036;
        iVar4 = fcn.180222020(iVar5);
        while (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b048;
            fcn.18023a330(iVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b050;
            iVar4 = fcn.180222020(iVar5);
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    do {
        if (uVar6 == 0) {
            if (in_RCX == (int64_t *)0x0) {
                return iVar5;
            }
            if (*in_RCX != 0) {
                return iVar5;
            }
            *in_RCX = iVar5;
            return iVar5;
        }
        if (uVar6 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b118;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x00018023b11d:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b130;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b142;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018023b142;
        }
        puVar1 = (undefined *)*in_RDX;
        uVar7 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
        *in_RDX = (int64_t)(puVar1 + 2);
        if ((uVar7 == 0) || (uVar6 - 2 < uVar7)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b10c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            goto code_r0x00018023b11d;
        }
        uVar6 = (uVar6 - 2) - uVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b09e;
        iVar4 = fcn.18023ac50(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        if (iVar4 == 0) goto code_r0x00018023b142;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0b5;
        iVar2 = fcn.180222110(*(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
    } while (iVar2 != 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b105;
    fcn.18023a330(iVar4);
code_r0x00018023b142:
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b155;
        fcn.18023a130(iVar5);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b0d4
// Address: 0x18023b0d4
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023af80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar7;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023af91;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (0xfffd < in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b161;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b179;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b18b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    puVar1 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    uVar6 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
    *in_RDX = (int64_t)(puVar1 + 2);
    if (uVar6 != in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afd7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afef;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b001;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if ((in_RCX == (int64_t *)0x0) || (iVar5 = *in_RCX, iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0ef;
        iVar5 = fcn.180221f20();
        if (iVar5 == 0) {
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b036;
        iVar4 = fcn.180222020(iVar5);
        while (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b048;
            fcn.18023a330(iVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b050;
            iVar4 = fcn.180222020(iVar5);
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    do {
        if (uVar6 == 0) {
            if (in_RCX == (int64_t *)0x0) {
                return iVar5;
            }
            if (*in_RCX != 0) {
                return iVar5;
            }
            *in_RCX = iVar5;
            return iVar5;
        }
        if (uVar6 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b118;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x00018023b11d:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b130;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b142;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018023b142;
        }
        puVar1 = (undefined *)*in_RDX;
        uVar7 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
        *in_RDX = (int64_t)(puVar1 + 2);
        if ((uVar7 == 0) || (uVar6 - 2 < uVar7)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b10c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            goto code_r0x00018023b11d;
        }
        uVar6 = (uVar6 - 2) - uVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b09e;
        iVar4 = fcn.18023ac50(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        if (iVar4 == 0) goto code_r0x00018023b142;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0b5;
        iVar2 = fcn.180222110(*(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
    } while (iVar2 != 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b105;
    fcn.18023a330(iVar4);
code_r0x00018023b142:
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b155;
        fcn.18023a130(iVar5);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b0ea
// Address: 0x18023b0ea
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023af80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar7;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023af91;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (0xfffd < in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b161;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b179;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b18b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    puVar1 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    uVar6 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
    *in_RDX = (int64_t)(puVar1 + 2);
    if (uVar6 != in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afd7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afef;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b001;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if ((in_RCX == (int64_t *)0x0) || (iVar5 = *in_RCX, iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0ef;
        iVar5 = fcn.180221f20();
        if (iVar5 == 0) {
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b036;
        iVar4 = fcn.180222020(iVar5);
        while (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b048;
            fcn.18023a330(iVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b050;
            iVar4 = fcn.180222020(iVar5);
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    do {
        if (uVar6 == 0) {
            if (in_RCX == (int64_t *)0x0) {
                return iVar5;
            }
            if (*in_RCX != 0) {
                return iVar5;
            }
            *in_RCX = iVar5;
            return iVar5;
        }
        if (uVar6 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b118;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x00018023b11d:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b130;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b142;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018023b142;
        }
        puVar1 = (undefined *)*in_RDX;
        uVar7 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
        *in_RDX = (int64_t)(puVar1 + 2);
        if ((uVar7 == 0) || (uVar6 - 2 < uVar7)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b10c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            goto code_r0x00018023b11d;
        }
        uVar6 = (uVar6 - 2) - uVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b09e;
        iVar4 = fcn.18023ac50(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        if (iVar4 == 0) goto code_r0x00018023b142;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0b5;
        iVar2 = fcn.180222110(*(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
    } while (iVar2 != 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b105;
    fcn.18023a330(iVar4);
code_r0x00018023b142:
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b155;
        fcn.18023a130(iVar5);
    }
    return 0;
}

// ============================================================
// Function: FUN_18023b0fd
// Address: 0x18023b0fd
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18023af80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    uint64_t uVar7;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023af91;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (0xfffd < in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b161;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b179;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b18b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    puVar1 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    uVar6 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
    *in_RDX = (int64_t)(puVar1 + 2);
    if (uVar6 != in_R8 - 2U) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afd7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023afef;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b001;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if ((in_RCX == (int64_t *)0x0) || (iVar5 = *in_RCX, iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0ef;
        iVar5 = fcn.180221f20();
        if (iVar5 == 0) {
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b036;
        iVar4 = fcn.180222020(iVar5);
        while (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b048;
            fcn.18023a330(iVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b050;
            iVar4 = fcn.180222020(iVar5);
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    do {
        if (uVar6 == 0) {
            if (in_RCX == (int64_t *)0x0) {
                return iVar5;
            }
            if (*in_RCX != 0) {
                return iVar5;
            }
            *in_RCX = iVar5;
            return iVar5;
        }
        if (uVar6 < 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b118;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
code_r0x00018023b11d:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b130;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b142;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            goto code_r0x00018023b142;
        }
        puVar1 = (undefined *)*in_RDX;
        uVar7 = (uint64_t)CONCAT11(*puVar1, puVar1[1]);
        *in_RDX = (int64_t)(puVar1 + 2);
        if ((uVar7 == 0) || (uVar6 - 2 < uVar7)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b10c;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            goto code_r0x00018023b11d;
        }
        uVar6 = (uVar6 - 2) - uVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b09e;
        iVar4 = fcn.18023ac50(*(int64_t *)((int64_t)&iStackX_18 + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
        if (iVar4 == 0) goto code_r0x00018023b142;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b0b5;
        iVar2 = fcn.180222110(*(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
    } while (iVar2 != 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b105;
    fcn.18023a330(iVar4);
code_r0x00018023b142:
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023b155;
        fcn.18023a130(iVar5);
    }
    return 0;
}

