// Chunk 35 - 50 functions

// ============================================================
// Function: FUN_18007c820
// Address: 0x18007c820
// Size: 122 bytes
// ============================================================
void fcn.18007c820(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 2) * 4;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18007c887;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c8a0
// Address: 0x18007c8a0
// Size: 98 bytes
// ============================================================
void fcn.18007c8a0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 1) * 2;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18007c8ef;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c910
// Address: 0x18007c910
// Size: 65 bytes
// ============================================================
void fcn.18007c910(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t unaff_retaddr;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    fcn.180004e40(arg1 + 0x40);
    fcn.18000ace0(arg1 + 0x18);
    fcn.18007d750(unaff_retaddr);
    if ((arg1 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar2 == 0))
    {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18007c960
// Address: 0x18007c960
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c960(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c9d6;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c975
// Address: 0x18007c975
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c960(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c9d6;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c9b0
// Address: 0x18007c9b0
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007c960(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007c9d6;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007c9f0
// Address: 0x18007c9f0
// Size: 14 bytes
// ============================================================
void fcn.18007c9f0(int64_t arg1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if (iVar1 != 0) {
        if ((iVar1 != 0) && (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar1), iVar3 == 0)) {
            uVar4 = (*(code *)0x699ff6)();
            uVar4 = fcn.18046b63c(uVar4);
            puVar2 = (undefined4 *)fcn.18046b77c();
            *puVar2 = uVar4;
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18007ca00
// Address: 0x18007ca00
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18007ca00(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    arg1 = arg1 + -0x90;
    fcn.180079b80(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0xf0);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18007ca40
// Address: 0x18007ca40
// Size: 86 bytes
// ============================================================
void fcn.18007ca40(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t unaff_retaddr;
    
    func_0x00018002a260(arg1 + 0x28);
    fcn.18007c8a0(arg1 + 0x10);
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    fcn.180004e40(arg1 + 0x40);
    fcn.18000ace0(arg1 + 0x18);
    fcn.18007d750(unaff_retaddr);
    if ((arg1 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar2 == 0))
    {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18007caa0
// Address: 0x18007caa0
// Size: 2299 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h

void fcn.18007caa0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t *puVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined in_R9B;
    int64_t iVar17;
    int64_t *piVar18;
    int64_t iVar19;
    bool bVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    uVar8 = arg2 - arg1;
    piVar18 = (int64_t *)arg2;
    do {
        if ((int64_t)(uVar8 & 0xfffffffffffffff0) < 0x201) {
            piVar14 = (int64_t *)arg1;
            if ((int64_t *)arg1 != piVar18) {
                while (piVar14 = piVar14 + 2, piVar14 != piVar18) {
                    iVar19 = *piVar14;
                    iVar17 = piVar14[1];
                    *piVar14 = 0;
                    piVar14[1] = 0;
                    iVar3 = *(int32_t *)(*(int64_t *)arg1 + 0xc);
                    if (*(int32_t *)(iVar19 + 0xc) == iVar3) {
                        bVar20 = *(uint64_t *)(iVar19 + 0x28) < *(uint64_t *)(*(int64_t *)arg1 + 0x28);
                    } else {
                        bVar20 = *(int32_t *)(iVar19 + 0xc) < iVar3;
                    }
                    piVar10 = piVar14;
                    if (bVar20) {
                        piVar10 = piVar14 + 2;
                        piVar9 = piVar14;
                        while (piVar9 != (int64_t *)arg1) {
                            iVar6 = piVar9[-2];
                            piVar11 = piVar10 + -2;
                            iVar7 = piVar9[-1];
                            piVar16 = piVar9 + -2;
                            *piVar16 = 0;
                            piVar9[-1] = 0;
                            piVar15 = (int64_t *)piVar10[-1];
                            *piVar11 = iVar6;
                            piVar10[-1] = iVar7;
                            piVar10 = piVar11;
                            piVar9 = piVar16;
                            if (piVar15 != (int64_t *)0x0) {
                                LOCK();
                                piVar11 = piVar15 + 1;
                                iVar3 = *(int32_t *)piVar11;
                                *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
                                UNLOCK();
                                if (iVar3 == 1) {
                                    (**(code **)*piVar15)(piVar15);
                                    LOCK();
                                    piVar2 = (int32_t *)((int64_t)piVar15 + 0xc);
                                    iVar3 = *piVar2;
                                    *piVar2 = *piVar2 + -1;
                                    UNLOCK();
                                    if (iVar3 == 1) {
                                        (**(code **)(*piVar15 + 8))(piVar15);
                                    }
                                }
                            }
                        }
                        piVar9 = *(int64_t **)(arg1 + 8);
                        *(int64_t *)(arg1 + 8) = iVar17;
                        *(int64_t *)arg1 = iVar19;
                    } else {
                        while( true ) {
                            iVar6 = piVar10[-2];
                            piVar9 = piVar10 + -2;
                            if (*(int32_t *)(iVar19 + 0xc) == *(int32_t *)(iVar6 + 0xc)) {
                                bVar20 = *(uint64_t *)(iVar19 + 0x28) < *(uint64_t *)(iVar6 + 0x28);
                            } else {
                                bVar20 = *(int32_t *)(iVar19 + 0xc) < *(int32_t *)(iVar6 + 0xc);
                            }
                            if (!bVar20) break;
                            iVar7 = piVar10[-1];
                            piVar10[-1] = 0;
                            *piVar9 = 0;
                            piVar11 = (int64_t *)piVar10[1];
                            *piVar10 = iVar6;
                            piVar10[1] = iVar7;
                            piVar10 = piVar9;
                            if (piVar11 != (int64_t *)0x0) {
                                LOCK();
                                piVar9 = piVar11 + 1;
                                iVar3 = *(int32_t *)piVar9;
                                *(int32_t *)piVar9 = *(int32_t *)piVar9 + -1;
                                UNLOCK();
                                if (iVar3 == 1) {
                                    (**(code **)*piVar11)(piVar11);
                                    LOCK();
                                    piVar2 = (int32_t *)((int64_t)piVar11 + 0xc);
                                    iVar3 = *piVar2;
                                    *piVar2 = *piVar2 + -1;
                                    UNLOCK();
                                    if (iVar3 == 1) {
                                        (**(code **)(*piVar11 + 8))(piVar11);
                                    }
                                }
                            }
                        }
                        piVar9 = (int64_t *)piVar10[1];
                        piVar10[1] = iVar17;
                        *piVar10 = iVar19;
                    }
                    if (piVar9 != (int64_t *)0x0) {
                        LOCK();
                        piVar10 = piVar9 + 1;
                        iVar3 = *(int32_t *)piVar10;
                        *(int32_t *)piVar10 = *(int32_t *)piVar10 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar9)(piVar9);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar9 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar9 + 8))(piVar9);
                            }
                        }
                    }
                }
            }
            return;
        }
        iVar19 = (int64_t)piVar18 - arg1 >> 5;
        if (arg3 < 1) {
            uVar8 = (int64_t)piVar18 - arg1 >> 4;
            if (0 < iVar19) {
                iVar17 = (int64_t)(uVar8 - 1) >> 1;
                do {
                    iVar19 = iVar19 + -1;
                    iVar6 = *(int64_t *)(arg1 + iVar19 * 2 * 8);
                    var_60h = *(int64_t *)(arg1 + (iVar19 * 2 + 1) * 8);
                    *(int64_t *)(arg1 + iVar19 * 2 * 8) = 0;
                    *(int64_t *)(arg1 + (iVar19 * 2 + 1) * 8) = 0;
                    iVar7 = iVar19;
                    while (iVar7 < iVar17) {
                        iVar12 = iVar7 * 2 + 2;
                        iVar3 = *(int32_t *)(*(int64_t *)(arg1 + (iVar12 * 2 + -2) * 8) + 0xc);
                        iVar4 = *(int32_t *)(*(int64_t *)(arg1 + iVar12 * 2 * 8) + 0xc);
                        if (iVar4 == iVar3) {
                            bVar20 = *(uint64_t *)(*(int64_t *)(arg1 + iVar12 * 2 * 8) + 0x28) <
                                     *(uint64_t *)(*(int64_t *)(arg1 + (iVar12 * 2 + -2) * 8) + 0x28);
                        } else {
                            bVar20 = iVar4 < iVar3;
                        }
                        if (bVar20) {
                            iVar12 = iVar7 * 2 + 1;
                        }
                        iVar13 = *(int64_t *)(arg1 + iVar12 * 2 * 8);
                        iVar5 = *(int64_t *)(arg1 + (iVar12 * 2 + 1) * 8);
                        *(int64_t *)(arg1 + iVar12 * 2 * 8) = 0;
                        *(int64_t *)(arg1 + (iVar12 * 2 + 1) * 8) = 0;
                        *(int64_t *)(arg1 + iVar7 * 2 * 8) = iVar13;
                        piVar18 = *(int64_t **)(arg1 + (iVar7 * 2 + 1) * 8);
                        *(int64_t *)(arg1 + (iVar7 * 2 + 1) * 8) = iVar5;
                        iVar7 = iVar12;
                        if (piVar18 != (int64_t *)0x0) {
                            LOCK();
                            piVar14 = piVar18 + 1;
                            iVar3 = *(int32_t *)piVar14;
                            *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)*piVar18)(piVar18);
                                LOCK();
                                piVar2 = (int32_t *)((int64_t)piVar18 + 0xc);
                                iVar3 = *piVar2;
                                *piVar2 = *piVar2 + -1;
                                UNLOCK();
                                if (iVar3 == 1) {
                                    (**(code **)(*piVar18 + 8))(piVar18);
                                }
                            }
                        }
                    }
                    if ((iVar7 == iVar17) && ((uVar8 & 1) == 0)) {
                        func_0x000180063990((int64_t *)(arg1 + iVar7 * 2 * 8), (int64_t *)(arg1 + (uVar8 * 2 + -2) * 8))
                        ;
                        iVar7 = uVar8 - 1;
                    }
                    while (iVar19 < iVar7) {
                        iVar13 = iVar7 + -1 >> 1;
                        piVar18 = (int64_t *)(arg1 + iVar13 * 2 * 8);
                        iVar12 = *piVar18;
                        if (*(int32_t *)(iVar12 + 0xc) == *(int32_t *)(iVar6 + 0xc)) {
                            bVar20 = *(uint64_t *)(iVar12 + 0x28) < *(uint64_t *)(iVar6 + 0x28);
                        } else {
                            bVar20 = *(int32_t *)(iVar12 + 0xc) < *(int32_t *)(iVar6 + 0xc);
                        }
                        if (!bVar20) break;
                        iVar5 = piVar18[1];
                        *piVar18 = 0;
                        piVar18[1] = 0;
                        *(int64_t *)(arg1 + iVar7 * 2 * 8) = iVar12;
                        piVar18 = *(int64_t **)(arg1 + (iVar7 * 2 + 1) * 8);
                        *(int64_t *)(arg1 + (iVar7 * 2 + 1) * 8) = iVar5;
                        iVar7 = iVar13;
                        if (piVar18 != (int64_t *)0x0) {
                            LOCK();
                            piVar14 = piVar18 + 1;
                            iVar3 = *(int32_t *)piVar14;
                            *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)*piVar18)(piVar18);
                                LOCK();
                                piVar2 = (int32_t *)((int64_t)piVar18 + 0xc);
                                iVar3 = *piVar2;
                                *piVar2 = *piVar2 + -1;
                                UNLOCK();
                                if (iVar3 == 1) {
                                    (**(code **)(*piVar18 + 8))(piVar18);
                                }
                            }
                        }
                    }
                    *(int64_t *)(arg1 + iVar7 * 2 * 8) = iVar6;
                    piVar18 = *(int64_t **)(arg1 + (iVar7 * 2 + 1) * 8);
                    *(int64_t *)(arg1 + (iVar7 * 2 + 1) * 8) = var_60h;
                    if (piVar18 != (int64_t *)0x0) {
                        LOCK();
                        piVar14 = piVar18 + 1;
                        iVar3 = *(int32_t *)piVar14;
                        *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar18)(piVar18);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar18 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar18 + 8))(piVar18);
                            }
                        }
                    }
                    piVar18 = (int64_t *)arg2;
                } while (0 < iVar19);
            }
            if ((int64_t)uVar8 < 2) {
                return;
            }
            do {
                if (0x1f < (int64_t)((int64_t)piVar18 - arg1 & 0xfffffffffffffff0U)) {
                    var_60h = piVar18[-2];
                    piVar18[-2] = 0;
                    var_58h = piVar18[-1];
                    piVar18[-1] = 0;
                    iVar19 = *(int64_t *)(arg1 + 8);
                    *(int64_t *)(arg1 + 8) = 0;
                    iVar17 = *(int64_t *)arg1;
                    *(int64_t *)arg1 = 0;
                    piVar14 = (int64_t *)piVar18[-1];
                    piVar18[-2] = iVar17;
                    piVar18[-1] = iVar19;
                    if (piVar14 != (int64_t *)0x0) {
                        LOCK();
                        piVar10 = piVar14 + 1;
                        iVar3 = *(int32_t *)piVar10;
                        *(int32_t *)piVar10 = *(int32_t *)piVar10 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)*piVar14)(piVar14);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar14 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*piVar14 + 8))(piVar14);
                            }
                        }
                    }
                    func_0x00018007ed50(arg1, 0, (int64_t)(((int64_t)piVar18 - arg1) - 0x10U) >> 4, &var_60h, in_R9B);
                    iVar19 = var_58h;
                    if (var_58h != 0) {
                        LOCK();
                        piVar2 = (int32_t *)(var_58h + 8);
                        iVar3 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (***(code ***)var_58h)(var_58h);
                            LOCK();
                            piVar2 = (int32_t *)(iVar19 + 0xc);
                            iVar3 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar3 == 1) {
                                (**(code **)(*(int64_t *)iVar19 + 8))(iVar19);
                            }
                        }
                    }
                }
                piVar18 = piVar18 + -2;
            } while (0x1f < (int64_t)((int64_t)piVar18 - arg1 & 0xfffffffffffffff0U));
            return;
        }
        piVar14 = (int64_t *)(arg1 + iVar19 * 2 * 8);
        iVar19 = (int64_t)piVar18 + (-0x10 - arg1) >> 4;
        if (iVar19 < 0x29) {
            piVar10 = piVar18 + -2;
            piVar9 = (int64_t *)arg1;
        } else {
            iVar19 = iVar19 + 1 >> 3;
            func_0x00018007fbf0(arg1, (int64_t *)(arg1 + iVar19 * 2 * 8), (int64_t *)(arg1 + iVar19 * 4 * 8));
            func_0x00018007fbf0(piVar14 + iVar19 * -2, piVar14, piVar14 + iVar19 * 2);
            piVar10 = piVar18 + iVar19 * -2 + -2;
            func_0x00018007fbf0(piVar18 + iVar19 * -4 + -2, piVar10, piVar18 + -2);
            piVar9 = (int64_t *)(arg1 + iVar19 * 2 * 8);
        }
        func_0x00018007fbf0(piVar9, piVar14, piVar10);
        piVar10 = piVar14 + 2;
        if ((uint64_t)arg1 < piVar14) {
            iVar19 = *piVar14;
            while( true ) {
                iVar17 = piVar14[-2];
                piVar9 = piVar14 + -2;
                iVar3 = *(int32_t *)(iVar19 + 0xc);
                iVar4 = *(int32_t *)(iVar17 + 0xc);
                if (iVar4 == iVar3) {
                    bVar20 = *(uint64_t *)(iVar17 + 0x28) < *(uint64_t *)(iVar19 + 0x28);
                } else {
                    bVar20 = iVar4 < iVar3;
                }
                if (bVar20) break;
                if (iVar3 == iVar4) {
                    bVar20 = *(uint64_t *)(iVar19 + 0x28) < *(uint64_t *)(iVar17 + 0x28);
                } else {
                    bVar20 = iVar3 < iVar4;
                }
                if ((bVar20) || (piVar14 = piVar9, iVar19 = iVar17, piVar9 <= (uint64_t)arg1)) break;
            }
        }
        piVar11 = piVar10;
        piVar9 = piVar14;
        if (piVar10 < piVar18) {
            iVar19 = *piVar14;
            iVar3 = *(int32_t *)(iVar19 + 0xc);
            while( true ) {
                iVar4 = *(int32_t *)(*piVar10 + 0xc);
                puVar1 = (uint64_t *)(*piVar10 + 0x28);
                if (iVar4 == iVar3) {
                    bVar20 = *puVar1 < *(uint64_t *)(iVar19 + 0x28);
                } else {
                    bVar20 = iVar4 < iVar3;
                }
                piVar11 = piVar10;
                if (bVar20) break;
                if (iVar3 == iVar4) {
                    bVar20 = *(uint64_t *)(iVar19 + 0x28) < *puVar1;
                } else {
                    bVar20 = iVar3 < iVar4;
                }
                if ((bVar20) || (piVar10 = piVar10 + 2, piVar11 = piVar10, piVar18 <= piVar10)) break;
            }
        }
joined_r0x00018007cc43:
        piVar15 = piVar14;
        if (piVar10 < piVar18) {
            iVar19 = *piVar10;
            iVar3 = *(int32_t *)(*piVar14 + 0xc);
            puVar1 = (uint64_t *)(*piVar14 + 0x28);
            iVar4 = *(int32_t *)(iVar19 + 0xc);
            if (iVar3 == iVar4) {
                bVar20 = *puVar1 < *(uint64_t *)(iVar19 + 0x28);
            } else {
                bVar20 = iVar3 < iVar4;
            }
            if (!bVar20) {
                if (iVar4 == iVar3) {
                    bVar20 = *(uint64_t *)(iVar19 + 0x28) < *puVar1;
                } else {
                    bVar20 = iVar4 < iVar3;
                }
                if (bVar20) goto joined_r0x00018007ccc0;
                if (piVar11 != piVar10) {
                    iVar17 = *piVar11;
                    *piVar11 = iVar19;
                    *piVar10 = iVar17;
                    iVar19 = piVar11[1];
                    piVar11[1] = piVar10[1];
                    piVar10[1] = iVar19;
                }
                piVar11 = piVar11 + 2;
            }
            piVar10 = piVar10 + 2;
            goto joined_r0x00018007cc43;
        }
joined_r0x00018007ccc0:
        while (piVar14 = piVar15, piVar16 = piVar9, (uint64_t)arg1 < piVar16) {
            piVar9 = piVar16 + -2;
            iVar19 = *piVar9;
            iVar3 = *(int32_t *)(*piVar14 + 0xc);
            puVar1 = (uint64_t *)(*piVar14 + 0x28);
            iVar4 = *(int32_t *)(iVar19 + 0xc);
            if (iVar4 == iVar3) {
                bVar20 = *(uint64_t *)(iVar19 + 0x28) < *puVar1;
            } else {
                bVar20 = iVar4 < iVar3;
            }
            piVar15 = piVar14;
            if (!bVar20) {
                if (iVar3 == iVar4) {
                    bVar20 = *puVar1 < *(uint64_t *)(iVar19 + 0x28);
                } else {
                    bVar20 = iVar3 < iVar4;
                }
                if (bVar20) break;
                piVar15 = piVar14 + -2;
                if (piVar15 != piVar9) {
                    iVar17 = *piVar15;
                    *piVar15 = iVar19;
                    *piVar9 = iVar17;
                    iVar19 = piVar14[-1];
                    piVar14[-1] = piVar16[-1];
                    piVar16[-1] = iVar19;
                }
            }
        }
        if (piVar16 != (int64_t *)arg1) {
            piVar9 = piVar16 + -2;
            if (piVar10 == piVar18) {
                piVar15 = piVar14 + -2;
                if (piVar9 != piVar15) {
                    iVar19 = *piVar9;
                    *piVar9 = *piVar15;
                    *piVar15 = iVar19;
                    iVar19 = piVar16[-1];
                    piVar16[-1] = piVar14[-1];
                    piVar14[-1] = iVar19;
                }
                iVar19 = *piVar15;
                *piVar15 = piVar11[-2];
                piVar11[-2] = iVar19;
                iVar19 = piVar14[-1];
                piVar14[-1] = piVar11[-1];
                piVar11[-1] = iVar19;
                piVar11 = piVar11 + -2;
                piVar14 = piVar15;
            } else {
                iVar19 = *piVar10;
                *piVar10 = *piVar9;
                *piVar9 = iVar19;
                iVar19 = piVar10[1];
                piVar10[1] = piVar16[-1];
                piVar10 = piVar10 + 2;
                piVar16[-1] = iVar19;
            }
            goto joined_r0x00018007cc43;
        }
        if (piVar10 != piVar18) {
            if (piVar11 != piVar10) {
                iVar19 = *piVar14;
                *piVar14 = *piVar11;
                *piVar11 = iVar19;
                iVar19 = piVar14[1];
                piVar14[1] = piVar11[1];
                piVar11[1] = iVar19;
            }
            iVar19 = *piVar14;
            *piVar14 = *piVar10;
            *piVar10 = iVar19;
            iVar19 = piVar14[1];
            piVar14[1] = piVar10[1];
            piVar10[1] = iVar19;
            piVar10 = piVar10 + 2;
            piVar11 = piVar11 + 2;
            piVar14 = piVar14 + 2;
            piVar9 = piVar16;
            goto joined_r0x00018007cc43;
        }
        arg3 = (arg3 >> 2) + (arg3 >> 1);
        if ((int64_t)((int64_t)piVar14 - arg1 & 0xfffffffffffffff0U) <
            (int64_t)((int64_t)piVar18 - (int64_t)piVar11 & 0xfffffffffffffff0U)) {
            fcn.18007caa0(arg1, (int64_t)piVar14, arg3);
            piVar14 = piVar18;
            arg1 = (int64_t)piVar11;
            var_10h = arg2;
        } else {
            fcn.18007caa0((int64_t)piVar11, (int64_t)piVar18, arg3);
            var_10h = (int64_t)piVar14;
        }
        uVar8 = (int64_t)piVar14 - arg1;
        piVar18 = piVar14;
        arg2 = var_10h;
    } while( true );
}

// ============================================================
// Function: FUN_18007d3a0
// Address: 0x18007d3a0
// Size: 544 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.18007d3a0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t *piVar2;
    code *pcVar3;
    bool bVar4;
    char cVar5;
    uint32_t uVar6;
    undefined *puVar7;
    undefined8 uVar8;
    int64_t iVar9;
    uint32_t uVar10;
    undefined8 uVar11;
    uint32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_28h;
    
    uVar10 = 0;
    bVar4 = false;
    piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 8))();
    }
    cVar5 = func_0x00018007f7b0(arg1, 1);
    if (cVar5 != '\0') {
        *(undefined8 *)(arg2 + 0x10) = 0;
        puVar7 = (undefined *)arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            puVar7 = *(undefined **)arg2;
        }
        *puVar7 = 0;
        piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
        if ((*(uint8_t **)piVar2[7] == (uint8_t *)0x0) || (*(int32_t *)piVar2[10] < 1)) {
            uVar10 = (**(code **)(*piVar2 + 0x30))();
        } else {
            uVar10 = (uint32_t)**(uint8_t **)piVar2[7];
        }
        while (uVar10 != 0xffffffff) {
            if (uVar10 == (in_R8D & 0xff)) {
                bVar4 = true;
                piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
                if (*(int64_t *)piVar2[7] != 0) {
                    iVar1 = *(int32_t *)piVar2[10];
                    if (0 < iVar1) {
                        *(int32_t *)piVar2[10] = iVar1 + -1;
                        *(int64_t *)piVar2[7] = *(int64_t *)piVar2[7] + 1;
                        uVar10 = 0;
                        goto code_r0x00018007d4bd;
                    }
                }
                (**(code **)(*piVar2 + 0x38))();
                uVar10 = 0;
                goto code_r0x00018007d4bd;
            }
            if (0x7ffffffffffffffe < *(uint64_t *)(arg2 + 0x10)) {
                uVar10 = 2;
                goto code_r0x00018007d4bd;
            }
            func_0x00018000b460(arg2, uVar10 & 0xff);
            bVar4 = true;
            uVar10 = func_0x00018000e0e0(*(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1));
        }
        uVar10 = 1;
code_r0x00018007d4bd:
        if (bVar4) goto code_r0x00018007d50f;
    }
    uVar10 = uVar10 | 2;
code_r0x00018007d50f:
    iVar9 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar6 = 4;
    if (*(int64_t *)(iVar9 + 0x48 + arg1) != 0) {
        uVar6 = 0;
    }
    uVar10 = uVar6 | *(uint32_t *)(iVar9 + 0x10 + arg1) & 0x17 | uVar10;
    *(uint32_t *)(iVar9 + 0x10 + arg1) = uVar10;
    uVar10 = uVar10 & *(uint32_t *)(iVar9 + 0x14 + arg1);
    if (uVar10 != 0) {
        if ((uVar10 & 4) == 0) {
            uVar11 = 0x1805aae00;
            if ((uVar10 & 2) == 0) {
                uVar11 = 0x1805aae18;
            }
        } else {
            uVar11 = 0x1805aade8;
        }
        uVar8 = func_0x000180005e50(&var_60h, 1);
        func_0x0001800069f0(&var_50h, uVar11, uVar8);
        func_0x00018045bae0(&var_50h, 0x180698c38);
        pcVar3 = (code *)swi(3);
        iVar9 = (*pcVar3)();
        return iVar9;
    }
    piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x10))();
    }
    return arg1;
}

// ============================================================
// Function: FUN_18007d5c0
// Address: 0x18007d5c0
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d5c0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            iVar1 = *(int64_t *)(arg1 + 0x20);
            if (iVar1 != 0) {
                func_0x00018007dab0(iVar1);
                fcn.180459c3c(iVar1, 0x5f0);
            }
            fcn.180004e40(arg1);
            arg1 = arg1 + 0x30;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_18007d5d2
// Address: 0x18007d5d2
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d5c0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            iVar1 = *(int64_t *)(arg1 + 0x20);
            if (iVar1 != 0) {
                func_0x00018007dab0(iVar1);
                fcn.180459c3c(iVar1, 0x5f0);
            }
            fcn.180004e40(arg1);
            arg1 = arg1 + 0x30;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_18007d61e
// Address: 0x18007d61e
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d5c0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            iVar1 = *(int64_t *)(arg1 + 0x20);
            if (iVar1 != 0) {
                func_0x00018007dab0(iVar1);
                fcn.180459c3c(iVar1, 0x5f0);
            }
            fcn.180004e40(arg1);
            arg1 = arg1 + 0x30;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_18007d620
// Address: 0x18007d620
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d620(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar1 = *(int64_t *)(arg2 + 0x20);
    if (iVar1 != 0) {
        func_0x00018007dab0(iVar1);
        fcn.180459c3c(iVar1, 0x5f0);
    }
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar1 = *(int64_t *)arg2;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg2 + 0x18) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    return;
}

// ============================================================
// Function: FUN_18007d660
// Address: 0x18007d660
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d660(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t unaff_retaddr;
    int64_t var_8h;
    
    if (arg2 != 0) {
        piVar1 = *(int64_t **)(arg2 + 0xf0);
        if (piVar1 != (int64_t *)0x0) {
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg2 + 0xb8));
            *(undefined8 *)(arg2 + 0xf0) = 0;
        }
        fcn.180004e40(arg2 + 0x98);
        func_0x00018002a260(arg2 + 0x68);
        fcn.18007c8a0(arg2 + 0x50);
        iVar2 = *(int64_t *)(arg2 + 0x40);
        if (iVar2 != 0) {
            fcn.180004e40(iVar2 + 0x40);
            fcn.18000ace0(iVar2 + 0x18);
            fcn.18007d750(unaff_retaddr);
            fcn.180459c3c(iVar2, 0x60);
        }
        func_0x00018002a260(arg2 + 0x28);
        fcn.18007c8a0(arg2 + 0x10);
        iVar2 = *(int64_t *)arg2;
        if (iVar2 != 0) {
            fcn.180004e40(iVar2 + 0x40);
            fcn.18000ace0(iVar2 + 0x18);
            fcn.18007d750(unaff_retaddr);
            fcn.180459c3c(iVar2, 0x60);
        }
        fcn.180459c3c(arg2, 0x100);
    }
    return;
}

// ============================================================
// Function: FUN_18007d66e
// Address: 0x18007d66e
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d660(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t unaff_retaddr;
    int64_t var_8h;
    
    if (arg2 != 0) {
        piVar1 = *(int64_t **)(arg2 + 0xf0);
        if (piVar1 != (int64_t *)0x0) {
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg2 + 0xb8));
            *(undefined8 *)(arg2 + 0xf0) = 0;
        }
        fcn.180004e40(arg2 + 0x98);
        func_0x00018002a260(arg2 + 0x68);
        fcn.18007c8a0(arg2 + 0x50);
        iVar2 = *(int64_t *)(arg2 + 0x40);
        if (iVar2 != 0) {
            fcn.180004e40(iVar2 + 0x40);
            fcn.18000ace0(iVar2 + 0x18);
            fcn.18007d750(unaff_retaddr);
            fcn.180459c3c(iVar2, 0x60);
        }
        func_0x00018002a260(arg2 + 0x28);
        fcn.18007c8a0(arg2 + 0x10);
        iVar2 = *(int64_t *)arg2;
        if (iVar2 != 0) {
            fcn.180004e40(iVar2 + 0x40);
            fcn.18000ace0(iVar2 + 0x18);
            fcn.18007d750(unaff_retaddr);
            fcn.180459c3c(iVar2, 0x60);
        }
        fcn.180459c3c(arg2, 0x100);
    }
    return;
}

// ============================================================
// Function: FUN_18007d742
// Address: 0x18007d742
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d660(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t unaff_retaddr;
    int64_t var_8h;
    
    if (arg2 != 0) {
        piVar1 = *(int64_t **)(arg2 + 0xf0);
        if (piVar1 != (int64_t *)0x0) {
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg2 + 0xb8));
            *(undefined8 *)(arg2 + 0xf0) = 0;
        }
        fcn.180004e40(arg2 + 0x98);
        func_0x00018002a260(arg2 + 0x68);
        fcn.18007c8a0(arg2 + 0x50);
        iVar2 = *(int64_t *)(arg2 + 0x40);
        if (iVar2 != 0) {
            fcn.180004e40(iVar2 + 0x40);
            fcn.18000ace0(iVar2 + 0x18);
            fcn.18007d750(unaff_retaddr);
            fcn.180459c3c(iVar2, 0x60);
        }
        func_0x00018002a260(arg2 + 0x28);
        fcn.18007c8a0(arg2 + 0x10);
        iVar2 = *(int64_t *)arg2;
        if (iVar2 != 0) {
            fcn.180004e40(iVar2 + 0x40);
            fcn.18000ace0(iVar2 + 0x18);
            fcn.18007d750(unaff_retaddr);
            fcn.180459c3c(iVar2, 0x60);
        }
        fcn.180459c3c(arg2, 0x100);
    }
    return;
}

// ============================================================
// Function: FUN_18007d750
// Address: 0x18007d750
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d750(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        if (puVar1[3] != 0) {
            func_0x00018007d7d0(puVar1 + 3);
        }
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18007d773
// Address: 0x18007d773
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d750(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        if (puVar1[3] != 0) {
            func_0x00018007d7d0(puVar1 + 3);
        }
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18007d7af
// Address: 0x18007d7af
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007d750(int64_t arg1, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    *(undefined8 *)puVar1[1] = 0;
    puVar1 = (undefined8 *)*puVar1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar2 = (undefined8 *)*puVar1;
        if (puVar1[3] != 0) {
            func_0x00018007d7d0(puVar1 + 3);
        }
        fcn.180459c3c(puVar1, 0x20);
        puVar1 = puVar2;
    }
    if ((*(int64_t *)arg1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18007d7d0
// Address: 0x18007d7d0
// Size: 59 bytes
// ============================================================
void fcn.18007d7d0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t unaff_retaddr;
    
    if (arg2 != 0) {
        fcn.180004e40(arg2 + 0x40);
        fcn.18000ace0(arg2 + 0x18);
        fcn.18007d750(arg2 + 8, unaff_retaddr);
        fcn.180459c3c(arg2, 0x60);
    }
    return;
}

// ============================================================
// Function: FUN_18007d810
// Address: 0x18007d810
// Size: 479 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18007d810(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    undefined *puVar12;
    undefined8 uStack_70;
    undefined auStack_68 [40];
    int64_t var_8h;
    
    puVar12 = auStack_68;
    uVar11 = 0;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    uVar2 = *(uint64_t *)(arg3 + 0x10);
    uVar3 = *(uint64_t *)(arg4 + 0x10);
    uVar1 = uVar3 + uVar2;
    if ((*(uint64_t *)(arg3 + 0x18) - uVar2 < uVar3) || (*(uint64_t *)(arg3 + 0x18) < *(uint64_t *)(arg4 + 0x18))) {
        if (*(uint64_t *)(arg4 + 0x18) - uVar3 < uVar2) {
            if (0x7fffffffffffffff - uVar2 < uVar3) {
                func_0x0001800047c0();
                pcVar4 = (code *)swi(3);
                iVar10 = (*pcVar4)();
                return iVar10;
            }
            uVar8 = uVar1 | 0xf;
            if (uVar8 < 0x8000000000000000) goto code_r0x00018007d94f;
            uVar9 = 0x8000000000000027;
            puVar12 = auStack_68;
            uVar8 = 0x7fffffffffffffff;
            while( true ) {
                *(undefined8 *)(puVar12 + -8) = 0x18007d943;
                iVar10 = func_0x000180459890(uVar9);
                if (iVar10 != 0) break;
                pcVar4 = (code *)swi(0x29);
                uVar8 = (*pcVar4)(5);
                puVar12 = puVar12 + 8;
code_r0x00018007d94f:
                if (uVar8 < 0x16) {
                    uVar8 = 0x16;
                }
                if (uVar8 == 0xffffffffffffffff) goto code_r0x00018007d991;
                if (uVar8 + 1 < 0x1000) {
                    *(undefined8 *)(puVar12 + -8) = 0x18007d98e;
                    uVar11 = func_0x000180459890();
                    goto code_r0x00018007d991;
                }
                uVar9 = uVar8 + 0x28;
                if (uVar9 <= uVar8 + 1) {
                    *(undefined8 *)(puVar12 + -8) = 0x18007d9ee;
                    func_0x000180004720();
                    pcVar4 = (code *)swi(3);
                    iVar10 = (*pcVar4)();
                    return iVar10;
                }
            }
            uVar11 = iVar10 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar11 - 8) = iVar10;
code_r0x00018007d991:
            *(uint64_t *)arg1 = uVar11;
            *(uint64_t *)(arg1 + 0x10) = uVar1;
            *(uint64_t *)(arg1 + 0x18) = uVar8;
            if (0xf < *(uint64_t *)(arg3 + 0x18)) {
                arg3 = *(int64_t *)arg3;
            }
            *(undefined8 *)(puVar12 + -8) = 0x18007d9b4;
            func_0x000180498030(uVar11, arg3, uVar2);
            if (0xf < *(uint64_t *)(arg4 + 0x18)) {
                arg4 = *(int64_t *)arg4;
            }
            *(undefined8 *)(puVar12 + -8) = 0x18007d9cf;
            func_0x000180498030(uVar2 + uVar11, arg4, uVar3 + 1);
        } else {
            uVar5 = *(undefined4 *)(arg4 + 4);
            uVar6 = *(undefined4 *)(arg4 + 8);
            uVar7 = *(undefined4 *)(arg4 + 0xc);
            *(undefined4 *)arg1 = *(undefined4 *)arg4;
            *(undefined4 *)(arg1 + 4) = uVar5;
            *(undefined4 *)(arg1 + 8) = uVar6;
            *(undefined4 *)(arg1 + 0xc) = uVar7;
            uVar5 = *(undefined4 *)(arg4 + 0x14);
            uVar6 = *(undefined4 *)(arg4 + 0x18);
            uVar7 = *(undefined4 *)(arg4 + 0x1c);
            *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(arg4 + 0x10);
            *(undefined4 *)(arg1 + 0x14) = uVar5;
            *(undefined4 *)(arg1 + 0x18) = uVar6;
            *(undefined4 *)(arg1 + 0x1c) = uVar7;
            *(undefined8 *)(arg4 + 0x10) = 0;
            *(undefined8 *)(arg4 + 0x18) = 0xf;
            *(undefined *)arg4 = 0;
            iVar10 = *(int64_t *)arg1;
            func_0x000180498030(iVar10 + uVar2, iVar10, uVar3 + 1);
            if (0xf < *(uint64_t *)(arg3 + 0x18)) {
                arg3 = *(int64_t *)arg3;
            }
            func_0x000180498030(iVar10, arg3, uVar2);
            *(uint64_t *)(arg1 + 0x10) = uVar1;
        }
    } else {
        uVar5 = *(undefined4 *)(arg3 + 4);
        uVar6 = *(undefined4 *)(arg3 + 8);
        uVar7 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)arg1 = *(undefined4 *)arg3;
        *(undefined4 *)(arg1 + 4) = uVar5;
        *(undefined4 *)(arg1 + 8) = uVar6;
        *(undefined4 *)(arg1 + 0xc) = uVar7;
        uVar5 = *(undefined4 *)(arg3 + 0x14);
        uVar6 = *(undefined4 *)(arg3 + 0x18);
        uVar7 = *(undefined4 *)(arg3 + 0x1c);
        *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(arg3 + 0x10);
        *(undefined4 *)(arg1 + 0x14) = uVar5;
        *(undefined4 *)(arg1 + 0x18) = uVar6;
        *(undefined4 *)(arg1 + 0x1c) = uVar7;
        *(undefined8 *)(arg3 + 0x10) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0xf;
        *(undefined *)arg3 = 0;
        iVar10 = arg1;
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            iVar10 = *(int64_t *)arg1;
        }
        if (0xf < *(uint64_t *)(arg4 + 0x18)) {
            arg4 = *(int64_t *)arg4;
        }
        func_0x000180498030(uVar2 + iVar10, arg4, uVar3 + 1);
        *(uint64_t *)(arg1 + 0x10) = uVar1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18007d9f0
// Address: 0x18007d9f0
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18007d9f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000038;
    int64_t in_stack_00000040;
    
    fcn.18000fd90();
    *(undefined8 *)arg1 = 0x1804a5580;
    fcn.18007ec20(arg1, unaff_RBX, in_stack_00000020, in_stack_00000028, in_stack_00000038, in_stack_00000040);
    return arg1;
}

// ============================================================
// Function: FUN_18007da80
// Address: 0x18007da80
// Size: 36 bytes
// ============================================================
void fcn.18007da80(int64_t arg1)
{
    int64_t *piVar1;
    
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(**(int64_t **)arg1 + 4) + 0x48 + (int64_t)*(int64_t **)arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return;
}

// ============================================================
// Function: FUN_18007dab0
// Address: 0x18007dab0
// Size: 385 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18007dab0(int64_t arg1)
{
    uint64_t *puVar1;
    int64_t *piVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t unaff_RBX;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar6 = auStack_28;
    piVar2 = *(int64_t **)(arg1 + 0x528);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 0x4f0));
        *(undefined8 *)(arg1 + 0x528) = 0;
    }
    piVar2 = *(int64_t **)(arg1 + 0x4d0);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 0x498));
        *(undefined8 *)(arg1 + 0x4d0) = 0;
    }
    fcn.180004e40(arg1 + 0x450);
    fcn.180004e40(arg1 + 0x430);
    fcn.180004e40(arg1 + 0x408);
    fcn.180004e40(arg1 + 1000);
    fcn.180004e40(arg1 + 0x3c8);
    fcn.180004e40(arg1 + 0x3a8);
    piVar2 = *(int64_t **)(arg1 + 0x398);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 0x360));
        *(undefined8 *)(arg1 + 0x398) = 0;
    }
    piVar2 = *(int64_t **)(arg1 + 0x358);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 800));
        *(undefined8 *)(arg1 + 0x358) = 0;
    }
    piVar2 = *(int64_t **)(arg1 + 0x318);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 0x2e0));
        *(undefined8 *)(arg1 + 0x318) = 0;
    }
    fcn.18007c960(arg1 + 0x230, unaff_RBX);
    fcn.180004e40(arg1 + 0x1d0);
    piVar2 = *(int64_t **)(arg1 + 0x1c0);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 0x188));
        *(undefined8 *)(arg1 + 0x1c0) = 0;
    }
    fcn.180004e40(arg1 + 0x168);
    func_0x00018007eae0(arg1 + 0x118);
    func_0x000180065ea0(arg1 + 0xe8);
    func_0x00018007dc50(arg1 + 0x40);
    func_0x00018007eb60(arg1 + 0x28);
    uVar5 = *(uint64_t *)arg1;
    if (uVar5 != 0) {
        uVar4 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar5) >> 2) * 4;
        if (0xfff < uVar4) {
            puVar1 = (uint64_t *)(uVar5 - 8);
            uVar5 = (uVar5 - *puVar1) - 8;
            if (uVar5 < 0x20) {
                uVar4 = uVar4 + 0x27;
                uVar5 = *puVar1;
                puVar6 = auStack_28;
            } else {
                pcVar3 = (code *)swi(0x29);
                uVar4 = (*pcVar3)(5);
                puVar6 = auStack_20;
            }
        }
        *(undefined8 *)(puVar6 + -8) = 0x18007c887;
        fcn.180459c3c(uVar5, uVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007dc50
// Address: 0x18007dc50
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007dc50(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    piVar1 = *(int64_t **)(arg1 + 0xa0);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 0x68));
        *(undefined8 *)(arg1 + 0xa0) = 0;
    }
    piVar1 = *(int64_t **)(arg1 + 0x60);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 0x28));
        *(undefined8 *)(arg1 + 0x60) = 0;
    }
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        for (; iVar4 != iVar3; iVar4 = iVar4 + 0x38) {
            func_0x00018002ee50(iVar4);
        }
        iVar4 = *(int64_t *)arg1;
        iVar3 = iVar4;
        puVar5 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar4 >> 3) * 8)) &&
           (iVar3 = *(int64_t *)(iVar4 + -8), puVar5 = auStack_28, 0x1f < (iVar4 - iVar3) - 8U)) {
            iVar3 = 5;
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x18007c7ff;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007dcd0
// Address: 0x18007dcd0
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007dcd0(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t unaff_RBX;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    fcn.18007c960(arg1 + 0x100, unaff_RBX);
    fcn.180004e40(arg1 + 0xa0);
    piVar2 = *(int64_t **)(arg1 + 0x90);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 0x58));
        *(undefined8 *)(arg1 + 0x90) = 0;
    }
    if (0xf < *(uint64_t *)(arg1 + 0x50)) {
        iVar1 = *(int64_t *)(arg1 + 0x38);
        iVar4 = iVar1;
        puVar5 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x50) + 1) &&
           (iVar4 = *(int64_t *)(iVar1 + -8), puVar5 = auStack_28, 0x1f < (iVar1 - iVar4) - 8U)) {
            pcVar3 = (code *)swi(0x29);
            iVar4 = (*pcVar3)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x180004e88;
        fcn.180459c3c(iVar4);
    }
    *(undefined8 *)(arg1 + 0x48) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x38) = 0;
    return;
}

// ============================================================
// Function: FUN_18007dd30
// Address: 0x18007dd30
// Size: 2845 bytes
// ============================================================
void fcn.18007dd30(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int64_t **ppiVar14;
    char cVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t **ppiVar18;
    int64_t *piVar19;
    int64_t *piVar20;
    uint64_t uVar21;
    int64_t **ppiVar22;
    int64_t *piVar23;
    int64_t **ppiVar24;
    int64_t *piVar25;
    int64_t **arg1_00;
    int64_t *piVar26;
    int64_t **ppiVar27;
    int64_t iVar28;
    int64_t *piVar29;
    int64_t iVar30;
    int64_t **ppiVar31;
    int64_t *piVar32;
    int64_t var_10h;
    undefined auStack_128 [32];
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t *piStack_c8;
    int64_t var_c0h;
    int64_t *piStack_b8;
    int64_t var_b0h;
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t *piStack_88;
    int64_t var_80h;
    int64_t *piStack_78;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    var_70h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_128;
    uVar17 = arg2 - arg1;
    var_e8h = arg2;
    iVar28 = arg3;
joined_r0x00018007dd87:
    var_f8h = iVar28;
    if (0x400 < (int64_t)(uVar17 & 0xffffffffffffffe0)) {
        var_f8h = arg2 - arg1 >> 6;
        if (0 < arg3) {
            ppiVar24 = (int64_t **)(arg1 + var_f8h * 4 * 8);
            ppiVar18 = (int64_t **)(arg2 + -0x20);
            iVar30 = (int64_t)ppiVar18 - arg1 >> 5;
            ppiVar22 = ppiVar24;
            if (iVar30 < 0x29) {
                var_f8h = iVar28;
                func_0x00018007fcb0(arg1, ppiVar24, ppiVar18);
                ppiVar18 = (int64_t **)arg2;
            } else {
                iVar30 = iVar30 + 1 >> 3;
                var_f8h = iVar28;
                func_0x00018007fcb0(arg1, (int64_t **)(arg1 + iVar30 * 4 * 8), (int64_t **)(arg1 + iVar30 * 8 * 8));
                func_0x00018007fcb0(ppiVar24 + iVar30 * -4, ppiVar24, ppiVar24 + iVar30 * 4);
                func_0x00018007fcb0(ppiVar18 + iVar30 * -8, ppiVar18 + iVar30 * -4, ppiVar18);
                func_0x00018007fcb0((int64_t **)(arg1 + iVar30 * 4 * 8), ppiVar24, ppiVar18 + iVar30 * -4);
                ppiVar18 = (int64_t **)var_e8h;
            }
            while (ppiVar31 = ppiVar22, (uint64_t)arg1 < ppiVar31) {
                ppiVar22 = ppiVar31 + -4;
                cVar15 = func_0x00018002e900(ppiVar22, ppiVar31);
                if ((cVar15 < '\0') || (cVar15 = func_0x00018002e900(ppiVar31, ppiVar22), cVar15 < '\0')) break;
            }
            do {
                ppiVar24 = ppiVar24 + 4;
                ppiVar22 = ppiVar24;
                ppiVar27 = ppiVar31;
                if (ppiVar18 <= ppiVar24) goto joined_r0x00018007dea3;
                cVar15 = func_0x00018002e900(ppiVar24, ppiVar31);
                if ((cVar15 < '\0') || (cVar15 = func_0x00018002e900(ppiVar31, ppiVar24), cVar15 < '\0'))
                goto joined_r0x00018007dea3;
            } while( true );
        }
        uVar17 = arg2 - arg1 >> 5;
        var_e0h = uVar17;
        if (var_f8h < 1) goto code_r0x00018007e461;
        var_f0h = (int64_t)(uVar17 - 1) >> 1;
        goto code_r0x00018007e140;
    }
    if ((arg1 != arg2) && (ppiVar18 = (int64_t **)(arg1 + 0x20), ppiVar18 != (int64_t **)arg2)) {
code_r0x00018007e0d2:
        piVar32 = *ppiVar18;
        piVar25 = ppiVar18[1];
        piVar29 = ppiVar18[2];
        piVar20 = ppiVar18[3];
        ppiVar18[2] = (int64_t *)0x0;
        ppiVar18[3] = (int64_t *)0xf;
        *(undefined *)ppiVar18 = 0;
        piVar26 = *(int64_t **)(arg1 + 0x10);
        ppiVar22 = (int64_t **)arg1;
        if ((int64_t *)0xf < *(int64_t **)(arg1 + 0x18)) {
            ppiVar22 = *(int64_t ***)arg1;
        }
        piVar19 = &var_d0h;
        if ((int64_t *)0xf < piVar20) {
            piVar19 = piVar32;
        }
        piVar23 = piVar29;
        if (piVar26 < piVar29) {
            piVar23 = piVar26;
        }
        var_f0h = (int64_t)piVar20;
        var_d0h = (int64_t)piVar32;
        piStack_c8 = piVar25;
        var_c0h = (int64_t)piVar29;
        piStack_b8 = piVar20;
        iVar16 = func_0x000180497f30(piVar19, ppiVar22, piVar23);
        if (iVar16 == 0) {
            if (piVar26 <= piVar29) {
                ppiVar22 = ppiVar18;
                if (piVar29 <= piVar26) goto code_r0x00018007e6e0;
                goto code_r0x00018007e5e6;
            }
            cVar15 = -1;
        } else if (iVar16 < 0) {
            cVar15 = -1;
        } else {
code_r0x00018007e5e6:
            cVar15 = '\x01';
        }
        ppiVar22 = ppiVar18;
        if (-1 < cVar15) {
code_r0x00018007e6e0:
            ppiVar31 = ppiVar22;
            piVar26 = ppiVar31[-2];
            ppiVar22 = ppiVar31 + -4;
            ppiVar24 = ppiVar22;
            if ((int64_t *)0xf < ppiVar31[-1]) {
                ppiVar24 = (int64_t **)*ppiVar22;
            }
            piVar19 = &var_d0h;
            if (0xf < (uint64_t)var_f0h) {
                piVar19 = piVar32;
            }
            piVar23 = piVar29;
            if (piVar26 < piVar29) {
                piVar23 = piVar26;
            }
            iVar16 = func_0x000180497f30(piVar19, ppiVar24, piVar23);
            if (iVar16 == 0) {
                if (piVar29 < piVar26) {
                    cVar15 = -1;
                } else {
                    if (piVar29 <= piVar26) goto code_r0x00018007e7a5;
code_r0x00018007e72a:
                    cVar15 = '\x01';
                }
            } else {
                if (-1 < iVar16) goto code_r0x00018007e72a;
                cVar15 = -1;
            }
            if (-1 < cVar15) goto code_r0x00018007e7a5;
            if (ppiVar31 != ppiVar22) {
                piVar26 = ppiVar31[3];
                if ((int64_t *)0xf < piVar26) {
                    piVar19 = *ppiVar31;
                    piVar23 = (int64_t *)((int64_t)piVar26 + 1);
                    if ((int64_t *)0xfff < piVar23) {
                        if (0x1f < (uint64_t)((int64_t)piVar19 + (-8 - (int64_t)(int64_t *)piVar19[-1])))
                        goto code_r0x00018007e846;
                        piVar23 = piVar26 + 5;
                        piVar19 = (int64_t *)piVar19[-1];
                    }
                    fcn.180459c3c(piVar19, piVar23);
                }
                ppiVar31[3] = (int64_t *)0xf;
                ppiVar31[2] = (int64_t *)0x0;
                *(undefined *)ppiVar31 = 0;
                *(undefined4 *)ppiVar31 = *(undefined4 *)ppiVar22;
                *(undefined4 *)((int64_t)ppiVar31 + 4) = *(undefined4 *)((int64_t)ppiVar31 + -0x1c);
                *(undefined4 *)(ppiVar31 + 1) = *(undefined4 *)(ppiVar31 + -3);
                *(undefined4 *)((int64_t)ppiVar31 + 0xc) = *(undefined4 *)((int64_t)ppiVar31 + -0x14);
                *(undefined4 *)(ppiVar31 + 2) = *(undefined4 *)(ppiVar31 + -2);
                *(undefined4 *)((int64_t)ppiVar31 + 0x14) = *(undefined4 *)((int64_t)ppiVar31 + -0xc);
                *(undefined4 *)(ppiVar31 + 3) = *(undefined4 *)(ppiVar31 + -1);
                *(undefined4 *)((int64_t)ppiVar31 + 0x1c) = *(undefined4 *)((int64_t)ppiVar31 + -4);
                ppiVar31[-2] = (int64_t *)0x0;
                ppiVar31[-1] = (int64_t *)0xf;
                *(undefined *)ppiVar22 = 0;
            }
            goto code_r0x00018007e6e0;
        }
        ppiVar22 = ppiVar18 + 4;
        ppiVar24 = ppiVar18;
        while (ppiVar27 = ppiVar24, ppiVar31 = ppiVar22, (int64_t **)arg1 != ppiVar27) {
            ppiVar24 = ppiVar27 + -4;
            ppiVar22 = ppiVar31 + -4;
            if (ppiVar22 != ppiVar24) {
                piVar26 = ppiVar31[-1];
                if ((int64_t *)0xf < piVar26) {
                    piVar19 = *ppiVar22;
                    piVar23 = (int64_t *)((int64_t)piVar26 + 1);
                    if ((int64_t *)0xfff < piVar23) {
                        if (0x1f < (uint64_t)((int64_t)piVar19 + (-8 - (int64_t)(int64_t *)piVar19[-1])))
                        goto code_r0x00018007e846;
                        piVar23 = piVar26 + 5;
                        piVar19 = (int64_t *)piVar19[-1];
                    }
                    fcn.180459c3c(piVar19, piVar23);
                }
                ppiVar31[-1] = (int64_t *)0xf;
                ppiVar31[-2] = (int64_t *)0x0;
                *(undefined *)ppiVar22 = 0;
                piVar26 = ppiVar27[-3];
                *ppiVar22 = *ppiVar24;
                ppiVar31[-3] = piVar26;
                uVar3 = *(undefined4 *)((int64_t)ppiVar27 + -0xc);
                uVar4 = *(undefined4 *)(ppiVar27 + -1);
                uVar5 = *(undefined4 *)((int64_t)ppiVar27 + -4);
                *(undefined4 *)(ppiVar31 + -2) = *(undefined4 *)(ppiVar27 + -2);
                *(undefined4 *)((int64_t)ppiVar31 + -0xc) = uVar3;
                *(undefined4 *)(ppiVar31 + -1) = uVar4;
                *(undefined4 *)((int64_t)ppiVar31 + -4) = uVar5;
                ppiVar27[-2] = (int64_t *)0x0;
                ppiVar27[-1] = (int64_t *)0xf;
                *(undefined *)ppiVar24 = 0;
            }
        }
        piVar26 = piVar20;
        if ((int64_t *)arg1 == &var_d0h) goto code_r0x00018007e801;
        piVar26 = *(int64_t **)(arg1 + 0x18);
        if ((int64_t *)0xf < piVar26) {
            piVar19 = *(int64_t **)arg1;
            piVar23 = (int64_t *)((int64_t)piVar26 + 1);
            if ((int64_t *)0xfff < piVar23) {
                if (0x1f < (uint64_t)((int64_t)piVar19 + (-8 - (int64_t)(int64_t *)piVar19[-1]))) {
code_r0x00018007e846:
                    pcVar2 = (code *)swi(0x29);
                    (*pcVar2)(5);
                    pcVar2 = (code *)swi(3);
                    (*pcVar2)();
                    return;
                }
                piVar23 = piVar26 + 5;
                piVar19 = (int64_t *)piVar19[-1];
            }
            fcn.180459c3c(piVar19, piVar23);
        }
        *(int64_t **)arg1 = piVar32;
        *(int64_t **)(arg1 + 8) = piVar25;
        *(int64_t **)(arg1 + 0x10) = piVar29;
        *(int64_t **)(arg1 + 0x18) = piVar20;
        goto code_r0x00018007e834;
    }
code_r0x00018007e55d:
    func_0x000180459870(var_70h ^ (uint64_t)auStack_128);
    return;
code_r0x00018007e140:
    do {
        iVar28 = var_f8h + -1;
        piVar26 = *(int64_t **)(arg1 + iVar28 * 4 * 8);
        piVar32 = ((int64_t **)(arg1 + iVar28 * 4 * 8))[1];
        piVar25 = *(int64_t **)(arg1 + (iVar28 * 4 + 2) * 8);
        piVar29 = ((int64_t **)(arg1 + (iVar28 * 4 + 2) * 8))[1];
        *(int64_t **)(arg1 + (iVar28 * 4 + 2) * 8) = (int64_t *)0x0;
        *(int64_t **)(arg1 + (iVar28 * 4 + 3) * 8) = (int64_t *)0xf;
        *(undefined *)(arg1 + iVar28 * 4 * 8) = 0;
        iVar30 = iVar28;
        var_f8h = iVar28;
        var_90h = (int64_t)piVar26;
        piStack_88 = piVar32;
        var_80h = (int64_t)piVar25;
        piStack_78 = piVar29;
        if (iVar28 < var_f0h) {
            do {
                iVar1 = iVar30 * 2 + 2;
                cVar15 = func_0x00018002e900((int64_t **)(arg1 + iVar1 * 4 * 8), 
                                             (int64_t **)(arg1 + (iVar1 * 4 + -4) * 8));
                iVar28 = iVar30 * 2 + 1;
                if (-1 < cVar15) {
                    iVar28 = iVar1;
                }
                ppiVar22 = (int64_t **)(arg1 + iVar28 * 4 * 8);
                ppiVar18 = (int64_t **)(arg1 + iVar30 * 4 * 8);
                if (ppiVar18 != ppiVar22) {
                    piVar20 = ppiVar18[3];
                    if ((int64_t *)0xf < piVar20) {
                        piVar19 = *ppiVar18;
                        piVar23 = (int64_t *)((int64_t)piVar20 + 1);
                        if ((int64_t *)0xfff < piVar23) {
                            if (0x1f < (uint64_t)((int64_t)piVar19 + (-8 - (int64_t)(int64_t *)piVar19[-1])))
                            goto code_r0x00018007e846;
                            piVar23 = piVar20 + 5;
                            piVar19 = (int64_t *)piVar19[-1];
                        }
                        fcn.180459c3c(piVar19, piVar23);
                    }
                    ppiVar18[2] = (int64_t *)0x0;
                    ppiVar18[3] = (int64_t *)0xf;
                    *(undefined *)ppiVar18 = 0;
                    uVar3 = *(undefined4 *)((int64_t)ppiVar22 + 4);
                    uVar4 = *(undefined4 *)(ppiVar22 + 1);
                    uVar5 = *(undefined4 *)((int64_t)ppiVar22 + 0xc);
                    *(undefined4 *)ppiVar18 = *(undefined4 *)ppiVar22;
                    *(undefined4 *)((int64_t)ppiVar18 + 4) = uVar3;
                    *(undefined4 *)(ppiVar18 + 1) = uVar4;
                    *(undefined4 *)((int64_t)ppiVar18 + 0xc) = uVar5;
                    uVar3 = *(undefined4 *)((int64_t)ppiVar22 + 0x14);
                    uVar4 = *(undefined4 *)(ppiVar22 + 3);
                    uVar5 = *(undefined4 *)((int64_t)ppiVar22 + 0x1c);
                    *(undefined4 *)(ppiVar18 + 2) = *(undefined4 *)(ppiVar22 + 2);
                    *(undefined4 *)((int64_t)ppiVar18 + 0x14) = uVar3;
                    *(undefined4 *)(ppiVar18 + 3) = uVar4;
                    *(undefined4 *)((int64_t)ppiVar18 + 0x1c) = uVar5;
                    ppiVar22[2] = (int64_t *)0x0;
                    ppiVar22[3] = (int64_t *)0xf;
                    *(undefined *)ppiVar22 = 0;
                }
                iVar30 = iVar28;
            } while (iVar28 < var_f0h);
        }
        iVar30 = var_f8h;
        if ((iVar28 == var_f0h) && ((uVar17 & 1) == 0)) {
            func_0x000180012c10((int64_t **)(arg1 + iVar28 * 4 * 8), (int64_t **)(arg1 + (uVar17 * 4 + -4) * 8));
            iVar28 = uVar17 - 1;
        }
        var_d8h = (int64_t)piVar29;
        if (iVar30 < iVar28) {
            do {
                iVar30 = iVar28 + -1 >> 1;
                piVar20 = &var_90h;
                if (0xf < (uint64_t)var_d8h) {
                    piVar20 = piVar26;
                }
                ppiVar18 = (int64_t **)(arg1 + iVar30 * 4 * 8);
                piVar19 = *(int64_t **)(arg1 + (iVar30 * 4 + 2) * 8);
                if ((int64_t *)0xf < *(int64_t **)(arg1 + (iVar30 * 4 + 3) * 8)) {
                    ppiVar18 = (int64_t **)*ppiVar18;
                }
                piVar23 = piVar19;
                if (piVar25 < piVar19) {
                    piVar23 = piVar25;
                }
                iVar16 = func_0x000180497f30(ppiVar18, piVar20, piVar23);
                uVar17 = var_e0h;
                if (iVar16 == 0) {
                    if (piVar25 <= piVar19) {
                        if (piVar25 < piVar19) goto code_r0x00018007e2fb;
                        break;
                    }
                    cVar15 = -1;
                } else if (iVar16 < 0) {
                    cVar15 = -1;
                } else {
code_r0x00018007e2fb:
                    cVar15 = '\x01';
                }
                if (-1 < cVar15) break;
                ppiVar22 = (int64_t **)(arg1 + iVar30 * 4 * 8);
                ppiVar18 = (int64_t **)(arg1 + iVar28 * 4 * 8);
                if (ppiVar18 != ppiVar22) {
                    piVar20 = ppiVar18[3];
                    if ((int64_t *)0xf < piVar20) {
                        piVar19 = *ppiVar18;
                        piVar23 = (int64_t *)((int64_t)piVar20 + 1);
                        if ((int64_t *)0xfff < piVar23) {
                            if (0x1f < (uint64_t)((int64_t)piVar19 + (-8 - (int64_t)(int64_t *)piVar19[-1])))
                            goto code_r0x00018007e846;
                            piVar23 = piVar20 + 5;
                            piVar19 = (int64_t *)piVar19[-1];
                        }
                        fcn.180459c3c(piVar19, piVar23);
                    }
                    ppiVar18[3] = (int64_t *)0xf;
                    ppiVar18[2] = (int64_t *)0x0;
                    *(undefined *)ppiVar18 = 0;
                    piVar20 = ppiVar22[1];
                    *ppiVar18 = *ppiVar22;
                    ppiVar18[1] = piVar20;
                    uVar3 = *(undefined4 *)((int64_t)ppiVar22 + 0x14);
                    uVar4 = *(undefined4 *)(ppiVar22 + 3);
                    uVar5 = *(undefined4 *)((int64_t)ppiVar22 + 0x1c);
                    *(undefined4 *)(ppiVar18 + 2) = *(undefined4 *)(ppiVar22 + 2);
                    *(undefined4 *)((int64_t)ppiVar18 + 0x14) = uVar3;
                    *(undefined4 *)(ppiVar18 + 3) = uVar4;
                    *(undefined4 *)((int64_t)ppiVar18 + 0x1c) = uVar5;
                    ppiVar22[2] = (int64_t *)0x0;
                    ppiVar22[3] = (int64_t *)0xf;
                    *(undefined *)ppiVar22 = 0;
                }
                iVar28 = iVar30;
                uVar17 = var_e0h;
            } while (var_f8h < iVar30);
        }
        ppiVar18 = (int64_t **)(arg1 + iVar28 * 4 * 8);
        if (ppiVar18 == (int64_t **)&var_90h) {
            if (0xf < (uint64_t)var_d8h) {
                uVar21 = var_d8h + 1;
                piVar32 = piVar26;
                if (0xfff < uVar21) {
                    piVar32 = (int64_t *)piVar26[-1];
                    if (0x1f < (uint64_t)((int64_t)piVar26 + (-8 - (int64_t)piVar32))) goto code_r0x00018007e846;
                    uVar21 = var_d8h + 0x28;
                }
                fcn.180459c3c(piVar32, uVar21);
            }
        } else {
            piVar20 = ppiVar18[3];
            if ((int64_t *)0xf < piVar20) {
                piVar19 = *ppiVar18;
                if (0xfff < (int64_t)piVar20 + 1U) {
                    if ((uint64_t)((int64_t)piVar19 + (-8 - piVar19[-1])) < 0x20) {
                        fcn.180459c3c(piVar19[-1], piVar20 + 5);
                        *ppiVar18 = piVar26;
                        ppiVar18[1] = piVar32;
                        ppiVar18[2] = piVar25;
                        ppiVar18[3] = piVar29;
                        goto code_r0x00018007e443;
                    }
                    goto code_r0x00018007e846;
                }
                fcn.180459c3c(piVar19);
            }
            *ppiVar18 = piVar26;
            ppiVar18[1] = piVar32;
            ppiVar18[2] = piVar25;
            ppiVar18[3] = piVar29;
        }
code_r0x00018007e443:
        arg2 = var_e8h;
        iVar28 = var_f8h;
    } while (0 < var_f8h);
code_r0x00018007e461:
    var_f8h = iVar28;
    if (1 < (int64_t)uVar17) {
        do {
            if (0x3f < (int64_t)(arg2 - arg1 & 0xffffffffffffffe0U)) {
                var_b0h._0_4_ = *(undefined4 *)(arg2 + -0x20);
                var_b0h._4_4_ = *(undefined4 *)(arg2 + -0x1c);
                uStack_a8 = *(undefined4 *)(arg2 + -0x18);
                uStack_a4 = *(undefined4 *)(arg2 + -0x14);
                ppiVar18 = (int64_t **)(arg2 + -0x20);
                var_a0h._0_4_ = *(undefined4 *)(arg2 + -0x10);
                var_a0h._4_4_ = *(undefined4 *)(arg2 + -0xc);
                var_98h._0_4_ = *(undefined4 *)(arg2 + -8);
                var_98h._4_4_ = *(undefined4 *)(arg2 + -4);
                *(int64_t **)(arg2 + -0x10) = (int64_t *)0x0;
                *(int64_t **)(arg2 + -8) = (int64_t *)0xf;
                *(undefined *)ppiVar18 = 0;
                if (ppiVar18 != (int64_t **)arg1) {
                    *(int64_t **)(arg2 + -0x10) = (int64_t *)0x0;
                    *(int64_t **)(arg2 + -8) = (int64_t *)0xf;
                    *(undefined *)ppiVar18 = 0;
                    uVar3 = *(undefined4 *)(arg1 + 4);
                    uVar4 = *(undefined4 *)(arg1 + 8);
                    uVar5 = *(undefined4 *)(arg1 + 0xc);
                    *(undefined4 *)ppiVar18 = *(undefined4 *)arg1;
                    *(undefined4 *)(arg2 + -0x1c) = uVar3;
                    *(undefined4 *)(arg2 + -0x18) = uVar4;
                    *(undefined4 *)(arg2 + -0x14) = uVar5;
                    uVar3 = *(undefined4 *)(arg1 + 0x14);
                    uVar4 = *(undefined4 *)(arg1 + 0x18);
                    uVar5 = *(undefined4 *)(arg1 + 0x1c);
                    *(undefined4 *)(arg2 + -0x10) = *(undefined4 *)(arg1 + 0x10);
                    *(undefined4 *)(arg2 + -0xc) = uVar3;
                    *(undefined4 *)(arg2 + -8) = uVar4;
                    *(undefined4 *)(arg2 + -4) = uVar5;
                    *(int64_t **)(arg1 + 0x10) = (int64_t *)0x0;
                    *(int64_t **)(arg1 + 0x18) = (int64_t *)0xf;
                    *(undefined *)arg1 = 0;
                }
                func_0x00018007f9f0(arg1, 0, (int64_t)ppiVar18 - arg1 >> 5, &var_b0h);
                if (0xf < CONCAT44(var_98h._4_4_, (undefined4)var_98h)) {
                    iVar30 = CONCAT44(var_b0h._4_4_, (undefined4)var_b0h);
                    iVar28 = iVar30;
                    if ((0xfff < CONCAT44(var_98h._4_4_, (undefined4)var_98h) + 1) &&
                       (iVar28 = *(int64_t *)(iVar30 + -8), 0x1f < (iVar30 - iVar28) - 8U)) goto code_r0x00018007e846;
                    fcn.180459c3c(iVar28);
                }
            }
            arg2 = arg2 + -0x20;
        } while (0x3f < (int64_t)(arg2 - arg1 & 0xffffffffffffffe0U));
    }
    goto code_r0x00018007e55d;
joined_r0x00018007dea3:
    arg1_00 = ppiVar22;
    if (ppiVar24 < ppiVar18) {
        cVar15 = func_0x00018002e900(ppiVar27, ppiVar24);
        if (-1 < cVar15) {
            cVar15 = func_0x00018002e900(ppiVar24, ppiVar27);
            if (cVar15 < '\0') goto joined_r0x00018007def6;
            if (arg1_00 != ppiVar24) {
                piVar26 = ppiVar24[1];
                uVar3 = *(undefined4 *)arg1_00;
                uVar4 = *(undefined4 *)((int64_t)arg1_00 + 4);
                uVar5 = *(undefined4 *)(arg1_00 + 1);
                uVar6 = *(undefined4 *)((int64_t)arg1_00 + 0xc);
                uVar7 = *(undefined4 *)(arg1_00 + 2);
                uVar8 = *(undefined4 *)((int64_t)arg1_00 + 0x14);
                uVar9 = *(undefined4 *)(arg1_00 + 3);
                uVar10 = *(undefined4 *)((int64_t)arg1_00 + 0x1c);
                *arg1_00 = *ppiVar24;
                arg1_00[1] = piVar26;
                uVar11 = *(undefined4 *)((int64_t)ppiVar24 + 0x14);
                uVar12 = *(undefined4 *)(ppiVar24 + 3);
                uVar13 = *(undefined4 *)((int64_t)ppiVar24 + 0x1c);
                *(undefined4 *)(arg1_00 + 2) = *(undefined4 *)(ppiVar24 + 2);
                *(undefined4 *)((int64_t)arg1_00 + 0x14) = uVar11;
                *(undefined4 *)(arg1_00 + 3) = uVar12;
                *(undefined4 *)((int64_t)arg1_00 + 0x1c) = uVar13;
                *(undefined4 *)ppiVar24 = uVar3;
                *(undefined4 *)((int64_t)ppiVar24 + 4) = uVar4;
                *(undefined4 *)(ppiVar24 + 1) = uVar5;
                *(undefined4 *)((int64_t)ppiVar24 + 0xc) = uVar6;
                *(undefined4 *)(ppiVar24 + 2) = uVar7;
                *(undefined4 *)((int64_t)ppiVar24 + 0x14) = uVar8;
                *(undefined4 *)(ppiVar24 + 3) = uVar9;
                *(undefined4 *)((int64_t)ppiVar24 + 0x1c) = uVar10;
            }
            arg1_00 = arg1_00 + 4;
        }
        ppiVar24 = ppiVar24 + 4;
        ppiVar22 = arg1_00;
        goto joined_r0x00018007dea3;
    }
joined_r0x00018007def6:
    while (arg2 = (int64_t)ppiVar27, ppiVar14 = ppiVar31, ppiVar27 = (int64_t **)arg2, (uint64_t)arg1 < ppiVar14) {
        ppiVar31 = ppiVar14 + -4;
        cVar15 = func_0x00018002e900(ppiVar31, arg2);
        ppiVar18 = (int64_t **)var_e8h;
        if (-1 < cVar15) {
            cVar15 = func_0x00018002e900(arg2, ppiVar31);
            ppiVar18 = (int64_t **)var_e8h;
            if (cVar15 < '\0') break;
            ppiVar27 = (int64_t **)(arg2 + -0x20);
            if (ppiVar27 != ppiVar31) {
                piVar26 = ppiVar14[-3];
                uVar3 = *(undefined4 *)ppiVar27;
                uVar4 = *(undefined4 *)(arg2 + -0x1c);
                uVar5 = *(undefined4 *)(arg2 + -0x18);
                uVar6 = *(undefined4 *)(arg2 + -0x14);
                uVar7 = *(undefined4 *)(arg2 + -0x10);
                uVar8 = *(undefined4 *)(arg2 + -0xc);
                uVar9 = *(undefined4 *)(arg2 + -8);
                uVar10 = *(undefined4 *)(arg2 + -4);
                *ppiVar27 = *ppiVar31;
                *(int64_t **)(arg2 + -0x18) = piVar26;
                uVar11 = *(undefined4 *)((int64_t)ppiVar14 + -0xc);
                uVar12 = *(undefined4 *)(ppiVar14 + -1);
                uVar13 = *(undefined4 *)((int64_t)ppiVar14 + -4);
                *(undefined4 *)(arg2 + -0x10) = *(undefined4 *)(ppiVar14 + -2);
                *(undefined4 *)(arg2 + -0xc) = uVar11;
                *(undefined4 *)(arg2 + -8) = uVar12;
                *(undefined4 *)(arg2 + -4) = uVar13;
                *(undefined4 *)ppiVar31 = uVar3;
                *(undefined4 *)((int64_t)ppiVar14 + -0x1c) = uVar4;
                *(undefined4 *)(ppiVar14 + -3) = uVar5;
                *(undefined4 *)((int64_t)ppiVar14 + -0x14) = uVar6;
                *(undefined4 *)(ppiVar14 + -2) = uVar7;
                *(undefined4 *)((int64_t)ppiVar14 + -0xc) = uVar8;
                *(undefined4 *)(ppiVar14 + -1) = uVar9;
                *(undefined4 *)((int64_t)ppiVar14 + -4) = uVar10;
            }
        }
    }
    if (ppiVar14 != (int64_t **)arg1) {
        ppiVar31 = ppiVar14 + -4;
        if (ppiVar24 == ppiVar18) {
            ppiVar27 = (int64_t **)(arg2 + -0x20);
            if (ppiVar31 != ppiVar27) {
                piVar26 = *(int64_t **)(arg2 + -0x18);
                uVar3 = *(undefined4 *)ppiVar31;
                uVar4 = *(undefined4 *)((int64_t)ppiVar14 + -0x1c);
                uVar5 = *(undefined4 *)(ppiVar14 + -3);
                uVar6 = *(undefined4 *)((int64_t)ppiVar14 + -0x14);
                uVar7 = *(undefined4 *)(ppiVar14 + -2);
                uVar8 = *(undefined4 *)((int64_t)ppiVar14 + -0xc);
                uVar9 = *(undefined4 *)(ppiVar14 + -1);
                uVar10 = *(undefined4 *)((int64_t)ppiVar14 + -4);
                *ppiVar31 = *ppiVar27;
                ppiVar14[-3] = piVar26;
                uVar11 = *(undefined4 *)(arg2 + -0xc);
                uVar12 = *(undefined4 *)(arg2 + -8);
                uVar13 = *(undefined4 *)(arg2 + -4);
                *(undefined4 *)(ppiVar14 + -2) = *(undefined4 *)(arg2 + -0x10);
                *(undefined4 *)((int64_t)ppiVar14 + -0xc) = uVar11;
                *(undefined4 *)(ppiVar14 + -1) = uVar12;
                *(undefined4 *)((int64_t)ppiVar14 + -4) = uVar13;
                *(undefined4 *)ppiVar27 = uVar3;
                *(undefined4 *)(arg2 + -0x1c) = uVar4;
                *(undefined4 *)(arg2 + -0x18) = uVar5;
                *(undefined4 *)(arg2 + -0x14) = uVar6;
                *(undefined4 *)(arg2 + -0x10) = uVar7;
                *(undefined4 *)(arg2 + -0xc) = uVar8;
                *(undefined4 *)(arg2 + -8) = uVar9;
                *(undefined4 *)(arg2 + -4) = uVar10;
            }
            ppiVar22 = arg1_00 + -4;
            if (ppiVar27 != ppiVar22) {
                piVar26 = arg1_00[-3];
                uVar3 = *(undefined4 *)ppiVar27;
                uVar4 = *(undefined4 *)(arg2 + -0x1c);
                uVar5 = *(undefined4 *)(arg2 + -0x18);
                uVar6 = *(undefined4 *)(arg2 + -0x14);
                uVar7 = *(undefined4 *)(arg2 + -0x10);
                uVar8 = *(undefined4 *)(arg2 + -0xc);
                uVar9 = *(undefined4 *)(arg2 + -8);
                uVar10 = *(undefined4 *)(arg2 + -4);
                *ppiVar27 = *ppiVar22;
                *(int64_t **)(arg2 + -0x18) = piVar26;
                uVar11 = *(undefined4 *)((int64_t)arg1_00 + -0xc);
                uVar12 = *(undefined4 *)(arg1_00 + -1);
                uVar13 = *(undefined4 *)((int64_t)arg1_00 + -4);
                *(undefined4 *)(arg2 + -0x10) = *(undefined4 *)(arg1_00 + -2);
                *(undefined4 *)(arg2 + -0xc) = uVar11;
                *(undefined4 *)(arg2 + -8) = uVar12;
                *(undefined4 *)(arg2 + -4) = uVar13;
                *(undefined4 *)ppiVar22 = uVar3;
                *(undefined4 *)((int64_t)arg1_00 + -0x1c) = uVar4;
                *(undefined4 *)(arg1_00 + -3) = uVar5;
                *(undefined4 *)((int64_t)arg1_00 + -0x14) = uVar6;
                *(undefined4 *)(arg1_00 + -2) = uVar7;
                *(undefined4 *)((int64_t)arg1_00 + -0xc) = uVar8;
                *(undefined4 *)(arg1_00 + -1) = uVar9;
                *(undefined4 *)((int64_t)arg1_00 + -4) = uVar10;
            }
        } else {
            if (ppiVar24 != ppiVar31) {
                piVar26 = ppiVar14[-3];
                uVar3 = *(undefined4 *)ppiVar24;
                uVar4 = *(undefined4 *)((int64_t)ppiVar24 + 4);
                uVar5 = *(undefined4 *)(ppiVar24 + 1);
                uVar6 = *(undefined4 *)((int64_t)ppiVar24 + 0xc);
                uVar7 = *(undefined4 *)(ppiVar24 + 2);
                uVar8 = *(undefined4 *)((int64_t)ppiVar24 + 0x14);
                uVar9 = *(undefined4 *)(ppiVar24 + 3);
                uVar10 = *(undefined4 *)((int64_t)ppiVar24 + 0x1c);
                *ppiVar24 = *ppiVar31;
                ppiVar24[1] = piVar26;
                uVar11 = *(undefined4 *)((int64_t)ppiVar14 + -0xc);
                uVar12 = *(undefined4 *)(ppiVar14 + -1);
                uVar13 = *(undefined4 *)((int64_t)ppiVar14 + -4);
                *(undefined4 *)(ppiVar24 + 2) = *(undefined4 *)(ppiVar14 + -2);
                *(undefined4 *)((int64_t)ppiVar24 + 0x14) = uVar11;
                *(undefined4 *)(ppiVar24 + 3) = uVar12;
                *(undefined4 *)((int64_t)ppiVar24 + 0x1c) = uVar13;
                *(undefined4 *)ppiVar31 = uVar3;
                *(undefined4 *)((int64_t)ppiVar14 + -0x1c) = uVar4;
                *(undefined4 *)(ppiVar14 + -3) = uVar5;
                *(undefined4 *)((int64_t)ppiVar14 + -0x14) = uVar6;
                *(undefined4 *)(ppiVar14 + -2) = uVar7;
                *(undefined4 *)((int64_t)ppiVar14 + -0xc) = uVar8;
                *(undefined4 *)(ppiVar14 + -1) = uVar9;
                *(undefined4 *)((int64_t)ppiVar14 + -4) = uVar10;
            }
            ppiVar24 = ppiVar24 + 4;
            ppiVar22 = arg1_00;
        }
        goto joined_r0x00018007dea3;
    }
    if (ppiVar24 != ppiVar18) {
        if ((arg1_00 != ppiVar24) && ((int64_t **)arg2 != arg1_00)) {
            piVar26 = arg1_00[1];
            uVar3 = *(undefined4 *)arg2;
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            uVar7 = *(undefined4 *)(arg2 + 0x10);
            uVar8 = *(undefined4 *)(arg2 + 0x14);
            uVar9 = *(undefined4 *)(arg2 + 0x18);
            uVar10 = *(undefined4 *)(arg2 + 0x1c);
            *(int64_t **)arg2 = *arg1_00;
            *(int64_t **)(arg2 + 8) = piVar26;
            uVar11 = *(undefined4 *)((int64_t)arg1_00 + 0x14);
            uVar12 = *(undefined4 *)(arg1_00 + 3);
            uVar13 = *(undefined4 *)((int64_t)arg1_00 + 0x1c);
            *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1_00 + 2);
            *(undefined4 *)(arg2 + 0x14) = uVar11;
            *(undefined4 *)(arg2 + 0x18) = uVar12;
            *(undefined4 *)(arg2 + 0x1c) = uVar13;
            *(undefined4 *)arg1_00 = uVar3;
            *(undefined4 *)((int64_t)arg1_00 + 4) = uVar4;
            *(undefined4 *)(arg1_00 + 1) = uVar5;
            *(undefined4 *)((int64_t)arg1_00 + 0xc) = uVar6;
            *(undefined4 *)(arg1_00 + 2) = uVar7;
            *(undefined4 *)((int64_t)arg1_00 + 0x14) = uVar8;
            *(undefined4 *)(arg1_00 + 3) = uVar9;
            *(undefined4 *)((int64_t)arg1_00 + 0x1c) = uVar10;
        }
        if ((int64_t **)arg2 != ppiVar24) {
            piVar26 = ppiVar24[1];
            uVar3 = *(undefined4 *)arg2;
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            uVar7 = *(undefined4 *)(arg2 + 0x10);
            uVar8 = *(undefined4 *)(arg2 + 0x14);
            uVar9 = *(undefined4 *)(arg2 + 0x18);
            uVar10 = *(undefined4 *)(arg2 + 0x1c);
            *(int64_t **)arg2 = *ppiVar24;
            *(int64_t **)(arg2 + 8) = piVar26;
            uVar11 = *(undefined4 *)((int64_t)ppiVar24 + 0x14);
            uVar12 = *(undefined4 *)(ppiVar24 + 3);
            uVar13 = *(undefined4 *)((int64_t)ppiVar24 + 0x1c);
            *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(ppiVar24 + 2);
            *(undefined4 *)(arg2 + 0x14) = uVar11;
            *(undefined4 *)(arg2 + 0x18) = uVar12;
            *(undefined4 *)(arg2 + 0x1c) = uVar13;
            *(undefined4 *)ppiVar24 = uVar3;
            *(undefined4 *)((int64_t)ppiVar24 + 4) = uVar4;
            *(undefined4 *)(ppiVar24 + 1) = uVar5;
            *(undefined4 *)((int64_t)ppiVar24 + 0xc) = uVar6;
            *(undefined4 *)(ppiVar24 + 2) = uVar7;
            *(undefined4 *)((int64_t)ppiVar24 + 0x14) = uVar8;
            *(undefined4 *)(ppiVar24 + 3) = uVar9;
            *(undefined4 *)((int64_t)ppiVar24 + 0x1c) = uVar10;
        }
        ppiVar24 = ppiVar24 + 4;
        ppiVar22 = arg1_00 + 4;
        ppiVar31 = ppiVar14;
        ppiVar27 = (int64_t **)(arg2 + 0x20);
        goto joined_r0x00018007dea3;
    }
    arg3 = (var_f8h >> 2) + (var_f8h >> 1);
    var_f8h = arg3;
    if ((int64_t)(arg2 - arg1 & 0xffffffffffffffe0U) <
        (int64_t)((int64_t)ppiVar18 - (int64_t)arg1_00 & 0xffffffffffffffe0U)) {
        fcn.18007dd30(arg1, arg2, arg3);
        arg1 = (int64_t)arg1_00;
        arg2 = (int64_t)ppiVar18;
    } else {
        fcn.18007dd30((int64_t)arg1_00, (int64_t)ppiVar18, arg3);
        var_e8h = arg2;
    }
    uVar17 = arg2 - arg1;
    iVar28 = var_f8h;
    goto joined_r0x00018007dd87;
code_r0x00018007e7a5:
    piVar26 = (int64_t *)var_f0h;
    if (ppiVar31 == (int64_t **)&var_d0h) {
code_r0x00018007e801:
        if ((int64_t *)0xf < piVar26) {
            piVar25 = (int64_t *)((int64_t)piVar26 + 1);
            piVar29 = piVar32;
            if ((int64_t *)0xfff < piVar25) {
                piVar29 = (int64_t *)piVar32[-1];
                if (0x1f < (uint64_t)((int64_t)piVar32 + (-8 - (int64_t)piVar29))) goto code_r0x00018007e846;
                piVar25 = piVar26 + 5;
            }
            fcn.180459c3c(piVar29, piVar25);
        }
    } else {
        piVar26 = ppiVar31[3];
        if ((int64_t *)0xf < piVar26) {
            piVar19 = *ppiVar31;
            if (0xfff < (int64_t)piVar26 + 1U) {
                if (0x1f < (uint64_t)((int64_t)piVar19 + (-8 - piVar19[-1]))) goto code_r0x00018007e846;
                fcn.180459c3c(piVar19[-1], piVar26 + 5);
                *ppiVar31 = piVar32;
                ppiVar31[1] = piVar25;
                ppiVar31[2] = piVar29;
                ppiVar31[3] = piVar20;
                goto code_r0x00018007e834;
            }
            fcn.180459c3c(piVar19);
        }
        *ppiVar31 = piVar32;
        ppiVar31[1] = piVar25;
        ppiVar31[2] = piVar29;
        ppiVar31[3] = piVar20;
    }
code_r0x00018007e834:
    ppiVar18 = ppiVar18 + 4;
    if (ppiVar18 == (int64_t **)arg2) goto code_r0x00018007e55d;
    goto code_r0x00018007e0d2;
}

// ============================================================
// Function: FUN_18007e850
// Address: 0x18007e850
// Size: 449 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h

undefined (*) [16] fcn.18007e850(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined (*pauVar9) [16];
    undefined4 *puVar10;
    undefined (*pauVar11) [16];
    uint64_t uVar12;
    undefined (*pauVar13) [16];
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    iVar2 = *(int64_t *)arg1;
    iVar8 = *(int64_t *)(arg1 + 8) - iVar2 >> 5;
    if (iVar8 == 0x7ffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        pauVar11 = (undefined (*) [16])(*pcVar4)();
        return pauVar11;
    }
    iVar15 = arg2 - iVar2 >> 5;
    uVar1 = iVar8 + 1;
    uVar12 = *(int64_t *)(arg1 + 0x10) - iVar2 >> 5;
    uVar14 = 0x7ffffffffffffff;
    if ((uVar12 <= 0x7ffffffffffffff - (uVar12 >> 1)) && (uVar14 = (uVar12 >> 1) + uVar12, uVar14 < uVar1)) {
        uVar14 = uVar1;
    }
    pauVar9 = (undefined (*) [16])func_0x0001800511d0(arg1, uVar14);
    pauVar13 = pauVar9 + iVar15 * 2;
    func_0x00018000b4d0(pauVar13, arg3);
    puVar3 = *(undefined4 **)(arg1 + 8);
    puVar10 = *(undefined4 **)arg1;
    pauVar11 = pauVar9;
    if ((undefined4 *)arg2 == puVar3) {
        for (; puVar10 != puVar3; puVar10 = puVar10 + 8) {
            *pauVar11 = ZEXT816(0);
            *(undefined8 *)pauVar11[1] = 0;
            *(undefined8 *)(pauVar11[1] + 8) = 0;
            uVar5 = puVar10[1];
            uVar6 = puVar10[2];
            uVar7 = puVar10[3];
            *(undefined4 *)*pauVar11 = *puVar10;
            *(undefined4 *)(*pauVar11 + 4) = uVar5;
            *(undefined4 *)(*pauVar11 + 8) = uVar6;
            *(undefined4 *)(*pauVar11 + 0xc) = uVar7;
            uVar5 = puVar10[5];
            uVar6 = puVar10[6];
            uVar7 = puVar10[7];
            *(undefined4 *)pauVar11[1] = puVar10[4];
            *(undefined4 *)(pauVar11[1] + 4) = uVar5;
            *(undefined4 *)(pauVar11[1] + 8) = uVar6;
            *(undefined4 *)(pauVar11[1] + 0xc) = uVar7;
            *(undefined8 *)(puVar10 + 4) = 0;
            *(undefined8 *)(puVar10 + 6) = 0xf;
            *(undefined *)puVar10 = 0;
            pauVar11 = pauVar11 + 2;
        }
    } else {
        for (; puVar10 != (undefined4 *)arg2; puVar10 = puVar10 + 8) {
            *pauVar11 = ZEXT816(0);
            *(undefined8 *)pauVar11[1] = 0;
            *(undefined8 *)(pauVar11[1] + 8) = 0;
            uVar5 = puVar10[1];
            uVar6 = puVar10[2];
            uVar7 = puVar10[3];
            *(undefined4 *)*pauVar11 = *puVar10;
            *(undefined4 *)(*pauVar11 + 4) = uVar5;
            *(undefined4 *)(*pauVar11 + 8) = uVar6;
            *(undefined4 *)(*pauVar11 + 0xc) = uVar7;
            uVar5 = puVar10[5];
            uVar6 = puVar10[6];
            uVar7 = puVar10[7];
            *(undefined4 *)pauVar11[1] = puVar10[4];
            *(undefined4 *)(pauVar11[1] + 4) = uVar5;
            *(undefined4 *)(pauVar11[1] + 8) = uVar6;
            *(undefined4 *)(pauVar11[1] + 0xc) = uVar7;
            *(undefined8 *)(puVar10 + 4) = 0;
            *(undefined8 *)(puVar10 + 6) = 0xf;
            *(undefined *)puVar10 = 0;
            pauVar11 = pauVar11 + 2;
        }
        puVar3 = *(undefined4 **)(arg1 + 8);
        pauVar11 = pauVar9 + iVar15 * 2 + 2;
        if ((undefined4 *)arg2 != puVar3) {
            do {
                *pauVar11 = ZEXT816(0);
                *(undefined8 *)pauVar11[1] = 0;
                *(undefined8 *)(pauVar11[1] + 8) = 0;
                uVar5 = *(undefined4 *)(arg2 + 4);
                uVar6 = *(undefined4 *)(arg2 + 8);
                uVar7 = *(undefined4 *)(arg2 + 0xc);
                *(undefined4 *)*pauVar11 = *(undefined4 *)arg2;
                *(undefined4 *)(*pauVar11 + 4) = uVar5;
                *(undefined4 *)(*pauVar11 + 8) = uVar6;
                *(undefined4 *)(*pauVar11 + 0xc) = uVar7;
                uVar5 = *(undefined4 *)(arg2 + 0x14);
                uVar6 = *(undefined4 *)(arg2 + 0x18);
                uVar7 = *(undefined4 *)(arg2 + 0x1c);
                *(undefined4 *)pauVar11[1] = *(undefined4 *)(arg2 + 0x10);
                *(undefined4 *)(pauVar11[1] + 4) = uVar5;
                *(undefined4 *)(pauVar11[1] + 8) = uVar6;
                *(undefined4 *)(pauVar11[1] + 0xc) = uVar7;
                *(undefined8 *)(arg2 + 0x10) = 0;
                *(undefined8 *)(arg2 + 0x18) = 0xf;
                *(undefined *)arg2 = 0;
                pauVar11 = pauVar11 + 2;
                arg2 = arg2 + 0x20;
            } while ((undefined4 *)arg2 != puVar3);
        }
    }
    func_0x00018007f6f0(arg1, pauVar9, uVar1, uVar14, arg1, pauVar9, uVar14, pauVar13 + 2, pauVar13 + 2);
    return pauVar9 + iVar15 * 2;
}

// ============================================================
// Function: FUN_18007ea20
// Address: 0x18007ea20
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007ea20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x10) {
            func_0x00018000d070(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xfffffffffffffff0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18007eaa8;
        fcn.180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x10 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x10 + arg2;
    return;
}

// ============================================================
// Function: FUN_18007ea47
// Address: 0x18007ea47
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007ea20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x10) {
            func_0x00018000d070(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xfffffffffffffff0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18007eaa8;
        fcn.180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x10 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x10 + arg2;
    return;
}

// ============================================================
// Function: FUN_18007ea82
// Address: 0x18007ea82
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007ea20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x10) {
            func_0x00018000d070(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xfffffffffffffff0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18007eaa8;
        fcn.180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x10 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x10 + arg2;
    return;
}

// ============================================================
// Function: FUN_18007eae0
// Address: 0x18007eae0
// Size: 118 bytes
// ============================================================
void fcn.18007eae0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 2) * 4;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                uVar3 = 5;
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18007eb43;
        fcn.180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007eb60
// Address: 0x18007eb60
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007eb60(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x48) {
            fcn.180004e40(iVar3 + 0x28);
            fcn.180004e40(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007ec01;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007eb79
// Address: 0x18007eb79
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007eb60(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x48) {
            fcn.180004e40(iVar3 + 0x28);
            fcn.180004e40(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007ec01;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007ebd8
// Address: 0x18007ebd8
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007eb60(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x48) {
            fcn.180004e40(iVar3 + 0x28);
            fcn.180004e40(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18007ec01;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18007ec20
// Address: 0x18007ec20
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007ec20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, int64_t arg_50h,
                  int64_t arg_58h, undefined8 placeholder_11, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar6 = auStack_48;
    puVar7 = auStack_48;
    if (0x7fffffff < (uint64_t)arg3) {
        fcn.180454670();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (uint32_t)arg4 & 0xffffffdf;
    if ((arg3 == 0) || (((uint8_t)uVar5 & 6) == 6)) {
        *(undefined8 *)(arg1 + 0x68) = 0;
    } else {
        if ((uint64_t)arg3 < 0x1000) {
            uVar8 = fcn.180459890(arg3);
        } else {
            if (arg3 + 0x27U <= (uint64_t)arg3) {
                fcn.180004720();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar3 = fcn.180459890();
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_40;
            }
            uVar8 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar8 - 8) = iVar3;
            puVar7 = puVar6;
        }
        *(undefined8 *)(puVar7 + -8) = 0x18007ecaf;
        func_0x000180498030(uVar8, arg2, arg3);
        *(uint64_t *)(arg1 + 0x68) = uVar8 + arg3;
        if ((arg4 & 4U) == 0) {
            **(uint64_t **)(arg1 + 0x18) = uVar8;
            **(uint64_t **)(arg1 + 0x38) = uVar8;
            **(int32_t **)(arg1 + 0x50) = (int32_t)(uVar8 + arg3) - (int32_t)uVar8;
        }
        if ((arg4 & 2U) == 0) {
            uVar1 = *(uint64_t *)(arg1 + 0x68);
            uVar4 = uVar8;
            if ((arg4 & 0x18U) != 0) {
                uVar4 = uVar1;
            }
            **(uint64_t **)(arg1 + 0x20) = uVar8;
            **(uint64_t **)(arg1 + 0x40) = uVar4;
            **(int32_t **)(arg1 + 0x58) = (int32_t)uVar1 - (int32_t)uVar4;
            if ((arg4 & 4U) != 0) {
                **(uint64_t **)(arg1 + 0x18) = uVar8;
                **(uint64_t **)(arg1 + 0x38) = uVar8;
                **(undefined4 **)(arg1 + 0x50) = 0;
            }
        }
        uVar5 = uVar5 | 1;
    }
    *(uint32_t *)(arg1 + 0x70) = uVar5;
    return;
}

// ============================================================
// Function: FUN_18007ec46
// Address: 0x18007ec46
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007ec20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, int64_t arg_50h,
                  int64_t arg_58h, undefined8 placeholder_11, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar6 = auStack_48;
    puVar7 = auStack_48;
    if (0x7fffffff < (uint64_t)arg3) {
        fcn.180454670();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (uint32_t)arg4 & 0xffffffdf;
    if ((arg3 == 0) || (((uint8_t)uVar5 & 6) == 6)) {
        *(undefined8 *)(arg1 + 0x68) = 0;
    } else {
        if ((uint64_t)arg3 < 0x1000) {
            uVar8 = fcn.180459890(arg3);
        } else {
            if (arg3 + 0x27U <= (uint64_t)arg3) {
                fcn.180004720();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar3 = fcn.180459890();
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_40;
            }
            uVar8 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar8 - 8) = iVar3;
            puVar7 = puVar6;
        }
        *(undefined8 *)(puVar7 + -8) = 0x18007ecaf;
        func_0x000180498030(uVar8, arg2, arg3);
        *(uint64_t *)(arg1 + 0x68) = uVar8 + arg3;
        if ((arg4 & 4U) == 0) {
            **(uint64_t **)(arg1 + 0x18) = uVar8;
            **(uint64_t **)(arg1 + 0x38) = uVar8;
            **(int32_t **)(arg1 + 0x50) = (int32_t)(uVar8 + arg3) - (int32_t)uVar8;
        }
        if ((arg4 & 2U) == 0) {
            uVar1 = *(uint64_t *)(arg1 + 0x68);
            uVar4 = uVar8;
            if ((arg4 & 0x18U) != 0) {
                uVar4 = uVar1;
            }
            **(uint64_t **)(arg1 + 0x20) = uVar8;
            **(uint64_t **)(arg1 + 0x40) = uVar4;
            **(int32_t **)(arg1 + 0x58) = (int32_t)uVar1 - (int32_t)uVar4;
            if ((arg4 & 4U) != 0) {
                **(uint64_t **)(arg1 + 0x18) = uVar8;
                **(uint64_t **)(arg1 + 0x38) = uVar8;
                **(undefined4 **)(arg1 + 0x50) = 0;
            }
        }
        uVar5 = uVar5 | 1;
    }
    *(uint32_t *)(arg1 + 0x70) = uVar5;
    return;
}

// ============================================================
// Function: FUN_18007ed3b
// Address: 0x18007ed3b
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007ec20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, int64_t arg_50h,
                  int64_t arg_58h, undefined8 placeholder_11, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar6 = auStack_48;
    puVar7 = auStack_48;
    if (0x7fffffff < (uint64_t)arg3) {
        fcn.180454670();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (uint32_t)arg4 & 0xffffffdf;
    if ((arg3 == 0) || (((uint8_t)uVar5 & 6) == 6)) {
        *(undefined8 *)(arg1 + 0x68) = 0;
    } else {
        if ((uint64_t)arg3 < 0x1000) {
            uVar8 = fcn.180459890(arg3);
        } else {
            if (arg3 + 0x27U <= (uint64_t)arg3) {
                fcn.180004720();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar3 = fcn.180459890();
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_40;
            }
            uVar8 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar8 - 8) = iVar3;
            puVar7 = puVar6;
        }
        *(undefined8 *)(puVar7 + -8) = 0x18007ecaf;
        func_0x000180498030(uVar8, arg2, arg3);
        *(uint64_t *)(arg1 + 0x68) = uVar8 + arg3;
        if ((arg4 & 4U) == 0) {
            **(uint64_t **)(arg1 + 0x18) = uVar8;
            **(uint64_t **)(arg1 + 0x38) = uVar8;
            **(int32_t **)(arg1 + 0x50) = (int32_t)(uVar8 + arg3) - (int32_t)uVar8;
        }
        if ((arg4 & 2U) == 0) {
            uVar1 = *(uint64_t *)(arg1 + 0x68);
            uVar4 = uVar8;
            if ((arg4 & 0x18U) != 0) {
                uVar4 = uVar1;
            }
            **(uint64_t **)(arg1 + 0x20) = uVar8;
            **(uint64_t **)(arg1 + 0x40) = uVar4;
            **(int32_t **)(arg1 + 0x58) = (int32_t)uVar1 - (int32_t)uVar4;
            if ((arg4 & 4U) != 0) {
                **(uint64_t **)(arg1 + 0x18) = uVar8;
                **(uint64_t **)(arg1 + 0x38) = uVar8;
                **(undefined4 **)(arg1 + 0x50) = 0;
            }
        }
        uVar5 = uVar5 | 1;
    }
    *(uint32_t *)(arg1 + 0x70) = uVar5;
    return;
}

// ============================================================
// Function: FUN_18007ed41
// Address: 0x18007ed41
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007ec20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, int64_t arg_50h,
                  int64_t arg_58h, undefined8 placeholder_11, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar6 = auStack_48;
    puVar7 = auStack_48;
    if (0x7fffffff < (uint64_t)arg3) {
        fcn.180454670();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar5 = (uint32_t)arg4 & 0xffffffdf;
    if ((arg3 == 0) || (((uint8_t)uVar5 & 6) == 6)) {
        *(undefined8 *)(arg1 + 0x68) = 0;
    } else {
        if ((uint64_t)arg3 < 0x1000) {
            uVar8 = fcn.180459890(arg3);
        } else {
            if (arg3 + 0x27U <= (uint64_t)arg3) {
                fcn.180004720();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            iVar3 = fcn.180459890();
            if (iVar3 == 0) {
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)(5);
                puVar6 = auStack_40;
            }
            uVar8 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar8 - 8) = iVar3;
            puVar7 = puVar6;
        }
        *(undefined8 *)(puVar7 + -8) = 0x18007ecaf;
        func_0x000180498030(uVar8, arg2, arg3);
        *(uint64_t *)(arg1 + 0x68) = uVar8 + arg3;
        if ((arg4 & 4U) == 0) {
            **(uint64_t **)(arg1 + 0x18) = uVar8;
            **(uint64_t **)(arg1 + 0x38) = uVar8;
            **(int32_t **)(arg1 + 0x50) = (int32_t)(uVar8 + arg3) - (int32_t)uVar8;
        }
        if ((arg4 & 2U) == 0) {
            uVar1 = *(uint64_t *)(arg1 + 0x68);
            uVar4 = uVar8;
            if ((arg4 & 0x18U) != 0) {
                uVar4 = uVar1;
            }
            **(uint64_t **)(arg1 + 0x20) = uVar8;
            **(uint64_t **)(arg1 + 0x40) = uVar4;
            **(int32_t **)(arg1 + 0x58) = (int32_t)uVar1 - (int32_t)uVar4;
            if ((arg4 & 4U) != 0) {
                **(uint64_t **)(arg1 + 0x18) = uVar8;
                **(uint64_t **)(arg1 + 0x38) = uVar8;
                **(undefined4 **)(arg1 + 0x50) = 0;
            }
        }
        uVar5 = uVar5 | 1;
    }
    *(uint32_t *)(arg1 + 0x70) = uVar5;
    return;
}

// ============================================================
// Function: FUN_18007ed50
// Address: 0x18007ed50
// Size: 470 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018007ee55: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018007ee5a)

undefined8 *
fcn.18007ed50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, undefined8 placeholder_5
             , int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    code *pcVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 *puVar8;
    int64_t *piVar9;
    undefined8 unaff_RBX;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStack_70 [6];
    
    iVar11 = arg3 + -1 >> 1;
    iVar12 = arg2;
    iVar14 = arg2;
    if (arg2 < iVar11) {
        do {
            iVar13 = iVar14 * 2 + 2;
            iVar12 = *(int64_t *)(arg1 + -0x10 + iVar13 * 0x10);
            iVar6 = *(int64_t *)(arg1 + iVar13 * 0x10);
            iVar3 = *(int32_t *)(iVar12 + 0xc);
            iVar4 = *(int32_t *)(iVar6 + 0xc);
            if (iVar4 == iVar3) {
                bVar15 = *(uint64_t *)(iVar6 + 0x28) < *(uint64_t *)(iVar12 + 0x28);
            } else {
                bVar15 = iVar4 < iVar3;
            }
            iVar12 = iVar14 * 2 + 1;
            if (!bVar15) {
                iVar12 = iVar13;
            }
            uVar10 = *(undefined8 *)(arg1 + iVar12 * 0x10);
            uVar7 = *(undefined8 *)(arg1 + 8 + iVar12 * 0x10);
            *(undefined8 *)(arg1 + iVar12 * 0x10) = 0;
            *(undefined8 *)(arg1 + 8 + iVar12 * 0x10) = 0;
            *(undefined8 *)(arg1 + iVar14 * 0x10) = uVar10;
            piVar9 = *(int64_t **)(arg1 + 8 + iVar14 * 0x10);
            *(undefined8 *)(arg1 + 8 + iVar14 * 0x10) = uVar7;
            if (piVar9 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar9 + 1;
                iVar3 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    auStack_70[0] = 0x18007ee0f;
                    (**(code **)*piVar9)(piVar9);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar9 + 0xc);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        auStack_70[0] = 0x18007ee27;
                        (**(code **)(*piVar9 + 8))(piVar9);
                    }
                }
            }
            iVar14 = iVar12;
        } while (iVar12 < iVar11);
    }
    uVar10 = 0;
    iVar14 = iVar12;
    if ((iVar12 == iVar11) && ((arg3 & 1U) == 0)) {
        arg4 = arg1 + -0x10 + arg3 * 0x10;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_70;
        auStack_70[0] = 0x18007ee5a;
        unaff_RSI = arg1;
    } else {
        while (uVar10 = unaff_RBX, iVar12 = unaff_RDI, arg2 < iVar14) {
            iVar13 = iVar14 + -1 >> 1;
            iVar3 = *(int32_t *)(*(int64_t *)arg4 + 0xc);
            piVar9 = (int64_t *)(iVar13 * 0x10 + arg1);
            iVar11 = *piVar9;
            if (*(int32_t *)(iVar11 + 0xc) == iVar3) {
                bVar15 = *(uint64_t *)(iVar11 + 0x28) < *(uint64_t *)(*(int64_t *)arg4 + 0x28);
            } else {
                bVar15 = *(int32_t *)(iVar11 + 0xc) < iVar3;
            }
            if (!bVar15) break;
            iVar6 = piVar9[1];
            *piVar9 = 0;
            piVar9[1] = 0;
            *(int64_t *)(arg1 + iVar14 * 0x10) = iVar11;
            piVar9 = *(int64_t **)(arg1 + 8 + iVar14 * 0x10);
            *(int64_t *)(arg1 + 8 + iVar14 * 0x10) = iVar6;
            iVar14 = iVar13;
            unaff_RDI = iVar12;
            unaff_RBX = uVar10;
            if (piVar9 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar9 + 1;
                iVar3 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    auStack_70[0] = 0x18007eede;
                    (**(code **)*piVar9)(piVar9);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar9 + 0xc);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    unaff_RDI = iVar12;
                    unaff_RBX = uVar10;
                    if (iVar3 == 1) {
                        auStack_70[0] = 0x18007eef6;
                        (**(code **)(*piVar9 + 8))(piVar9);
                        unaff_RDI = iVar12;
                        unaff_RBX = uVar10;
                    }
                }
            }
        }
    }
    puVar8 = (undefined8 *)(arg1 + iVar14 * 0x10);
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = uVar10;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = iVar12;
    uVar10 = *(undefined8 *)arg4;
    uVar7 = *(undefined8 *)(arg4 + 8);
    *(undefined8 *)arg4 = 0;
    *(undefined8 *)(arg4 + 8) = 0;
    piVar9 = (int64_t *)puVar8[1];
    *puVar8 = uVar10;
    puVar8[1] = uVar7;
    if (piVar9 == (int64_t *)0x0) {
        return puVar8;
    }
    *(int64_t *)((int64_t)*(undefined **)0x20 + 8) = unaff_RSI;
    LOCK();
    piVar1 = piVar9 + 1;
    iVar3 = *(int32_t *)piVar1;
    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
        pcVar5 = *(code **)*piVar9;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1800639db;
        (*pcVar5)(piVar9);
        LOCK();
        piVar2 = (int32_t *)((int64_t)piVar9 + 0xc);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar5 = *(code **)(*piVar9 + 8);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1800639ee;
            (*pcVar5)(piVar9);
        }
    }
    return puVar8;
}

// ============================================================
// Function: FUN_18007f010
// Address: 0x18007f010
// Size: 1596 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch

void fcn.18007f010(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *arg1;
    uint64_t *puVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    undefined8 *puVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [16];
    bool bVar11;
    bool bVar12;
    int32_t iVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    undefined *puVar16;
    undefined *puVar17;
    undefined8 *puVar18;
    uint64_t uVar19;
    int64_t **ppiVar20;
    int64_t **ppiVar21;
    int64_t *piVar22;
    uint64_t uVar23;
    int64_t **ppiVar24;
    int64_t **ppiVar25;
    int64_t *piVar26;
    int64_t iVar27;
    int64_t **ppiVar28;
    int64_t iVar29;
    undefined *puVar30;
    undefined *puVar31;
    undefined8 *puVar32;
    int64_t **ppiVar33;
    int64_t iVar34;
    int64_t **ppiVar35;
    undefined8 uStack_110;
    undefined auStack_108 [8];
    undefined auStack_100 [24];
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t iStack_88;
    int64_t var_80h;
    uint64_t uStack_78;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar30 = auStack_108;
    puVar31 = auStack_108;
    var_70h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_108;
    var_d8h._0_4_ = 0;
    arg1 = (int64_t *)(arg2 + 0x60);
    iVar27 = *arg1;
    iVar29 = *(int64_t *)(arg2 + 0x68);
    if (iVar27 != iVar29) {
        do {
            fcn.180004e40(iVar27);
            iVar27 = iVar27 + 0x20;
        } while (iVar27 != iVar29);
        *(int64_t *)(arg2 + 0x68) = *arg1;
    }
    puVar1 = (uint64_t *)(arg2 + 0x10);
    if (*puVar1 == 0) goto code_r0x00018007f60b;
    iVar27 = *(int64_t *)(arg2 + 0x58);
    puVar30 = auStack_108;
    if ((iVar27 == 0) || (puVar30 = auStack_108, *(int64_t *)(arg2 + 0x30) == 0)) goto code_r0x00018007f243;
    uVar2 = *(uint32_t *)(arg2 + 0x20);
    uVar19 = (uint64_t)(int32_t)uVar2;
    if ((int32_t)uVar2 < 0) {
code_r0x00018007f113:
        var_c0h = 0;
        var_b8h = 0xf;
        stack0xffffffffffffff31 = SUB1615(ZEXT816(0), 1);
        auVar10[15] = 0;
        auVar10._0_15_ = stack0xffffffffffffff31;
        _var_d0h = auVar10 << 8;
        piVar15 = &var_d0h;
        bVar12 = false;
        bVar11 = true;
    } else {
        iVar29 = *(int64_t *)(iVar27 + 0x40);
        uVar14 = (*(int64_t *)(iVar27 + 0x48) - iVar29 >> 3) * 0x6db6db6db6db6db7;
        if ((int32_t)uVar14 < (int32_t)uVar2) goto code_r0x00018007f113;
        if (uVar14 < uVar19 || uVar14 - uVar19 == 0) goto code_r0x00018007f646;
        var_d8h._4_4_ = *(undefined4 *)(uVar19 * 0x38 + 0x28 + iVar29);
        var_d0h = CONCAT44(0, uVar2);
        var_d8h._0_4_ = uVar2;
        func_0x00018015d450((int64_t *)(iVar27 + 0x40), &var_b0h, var_d0h, CONCAT44(var_d8h._4_4_, uVar2));
        piVar15 = &var_b0h;
        bVar12 = true;
        bVar11 = false;
    }
    puVar17 = (undefined *)*piVar15;
    var_90h = (int64_t)puVar17;
    iStack_88 = piVar15[1];
    uVar19 = piVar15[2];
    uVar14 = piVar15[3];
    var_80h = uVar19;
    uStack_78 = uVar14;
    piVar15[2] = 0;
    piVar15[3] = 0xf;
    *(undefined *)piVar15 = 0;
    puVar30 = auStack_108;
    if ((bVar11) && (puVar30 = auStack_108, 0xf < (uint64_t)var_b8h)) {
        iVar27 = var_d0h;
        puVar30 = auStack_108;
        if ((0xfff < var_b8h + 1U) &&
           (iVar27 = *(int64_t *)(var_d0h + -8), puVar30 = auStack_108, 0x1f < (var_d0h - iVar27) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar27 = (*pcVar6)(5);
            puVar30 = auStack_100;
        }
        *(undefined8 *)(puVar30 + -8) = 0x18007f1a8;
        fcn.180459c3c(iVar27);
    }
    if ((bVar12) && (uVar3 = *(uint64_t *)(puVar30 + 0x70), 0xf < uVar3)) {
        iVar27 = *(int64_t *)(puVar30 + 0x58);
        uVar23 = uVar3 + 1;
        if (uVar23 < 0x1000) {
code_r0x00018007f1e8:
            *(undefined8 *)(puVar30 + -8) = 0x18007f1ed;
            fcn.180459c3c(iVar27, uVar23);
            goto code_r0x00018007f1ed;
        }
        if ((iVar27 - *(int64_t *)(iVar27 + -8)) - 8U < 0x20) {
            uVar23 = uVar3 + 0x28;
            iVar27 = *(int64_t *)(iVar27 + -8);
            goto code_r0x00018007f1e8;
        }
code_r0x00018007f63f:
        pcVar6 = (code *)swi(0x29);
        (*pcVar6)(5);
        puVar31 = puVar30 + 8;
code_r0x00018007f646:
        *(undefined8 *)(puVar31 + -8) = 0x18007f64b;
        func_0x000180060370();
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
code_r0x00018007f1ed:
    if (uVar19 < *(uint64_t *)(arg2 + 0x30)) {
        if (0xf < uVar14) {
            uVar19 = uVar14 + 1;
            if (0xfff < uVar19) {
                if ((undefined *)0x1f < puVar17 + (-8 - (int64_t)*(undefined **)(puVar17 + -8)))
                goto code_r0x00018007f63f;
                uVar19 = uVar14 + 0x28;
                puVar17 = *(undefined **)(puVar17 + -8);
            }
            *(undefined8 *)(puVar30 + -8) = 0x18007f243;
            fcn.180459c3c(puVar17, uVar19);
        }
code_r0x00018007f243:
        iVar27 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar27 = *(int64_t *)arg2;
        }
        *(int64_t *)(puVar30 + 0x38) = iVar27;
        *(uint64_t *)(puVar30 + 0x40) = *puVar1;
        *(undefined8 *)(puVar30 + 0x20) = 2;
        *(undefined8 *)(puVar30 + -8) = 0x18007f27b;
        func_0x000180161660(*(int64_t *)0x18077afd8, arg1, puVar30 + 0x38);
        if (*(int64_t *)(arg2 + 0x50) != 0) {
            puVar4 = *(undefined8 **)(*(int64_t *)(arg2 + 0x50) + 0x140);
            for (puVar5 = (undefined8 *)*puVar4; puVar5 != puVar4; puVar5 = (undefined8 *)*puVar5) {
                uVar19 = *puVar1;
                if (uVar19 < (uint64_t)puVar5[4]) {
                    iVar27 = arg2;
                    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                        iVar27 = *(int64_t *)arg2;
                    }
                    if ((uint64_t)puVar5[5] < 0x10) {
                        puVar32 = puVar5 + 2;
                    } else {
                        puVar32 = (undefined8 *)puVar5[2];
                    }
                    if (uVar19 != 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x18007f38e;
                        puVar18 = (undefined8 *)
                                  func_0x000180457f40(puVar32, (undefined8 *)(uVar19 + (int64_t)puVar32), iVar27);
                        if ((puVar18 == (undefined8 *)(uVar19 + (int64_t)puVar32)) || (puVar18 != puVar32))
                        goto code_r0x00018007f3c7;
                    }
                    iVar27 = *(int64_t *)(arg2 + 0x68);
                    if (iVar27 == *(int64_t *)(arg2 + 0x70)) {
                        *(undefined8 *)(puVar30 + -8) = 0x18007f3c7;
                        fcn.18007e850((int64_t)arg1, iVar27, (int64_t)(puVar5 + 2));
                    } else {
                        *(undefined8 *)(puVar30 + -8) = 0x18007f3b0;
                        func_0x00018000b4d0(iVar27, puVar5 + 2);
                        *(int64_t *)(arg2 + 0x68) = *(int64_t *)(arg2 + 0x68) + 0x20;
                    }
                }
code_r0x00018007f3c7:
            }
        }
    } else {
        puVar16 = puVar30 + 0x78;
        if (0xf < uVar14) {
            puVar16 = puVar17;
        }
        if ((puVar16[*(uint64_t *)(arg2 + 0x30) - 1] == ':') || (puVar16[*(uint64_t *)(arg2 + 0x30) - 1] == '.')) {
            bVar11 = true;
        } else {
            bVar11 = false;
        }
        if (0xf < uVar14) {
            uVar19 = uVar14 + 1;
            if (0xfff < uVar19) {
                if ((undefined *)0x1f < puVar17 + (-8 - (int64_t)*(undefined **)(puVar17 + -8)))
                goto code_r0x00018007f63f;
                uVar19 = uVar14 + 0x28;
                puVar17 = *(undefined **)(puVar17 + -8);
            }
            *(undefined8 *)(puVar30 + -8) = 0x18007f323;
            fcn.180459c3c(puVar17, uVar19);
        }
        if (!bVar11) goto code_r0x00018007f243;
        iVar27 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar27 = *(int64_t *)arg2;
        }
        *(int64_t *)(puVar30 + 0x38) = iVar27;
        *(uint64_t *)(puVar30 + 0x40) = *puVar1;
        *(undefined8 *)(puVar30 + 0x20) = 1;
        *(undefined8 *)(puVar30 + -8) = 0x18007f364;
        func_0x000180161660(*(int64_t *)0x18077afd8 + 0x40, arg1, puVar30 + 0x38);
    }
    iVar27 = *(int64_t *)(arg2 + 0x68);
    iVar29 = *arg1;
    *(undefined8 *)(puVar30 + -8) = 0x18007f3f0;
    fcn.18007dd30(iVar29, iVar27, iVar27 - iVar29 >> 5);
    ppiVar33 = *(int64_t ***)(arg2 + 0x68);
    ppiVar28 = (int64_t **)*arg1;
    if ((int64_t **)*arg1 != ppiVar33) {
        do {
            do {
                ppiVar35 = ppiVar28;
                ppiVar28 = ppiVar35 + 4;
                if (ppiVar28 == ppiVar33) goto code_r0x00018007f5cd;
                ppiVar24 = ppiVar28;
                if ((int64_t *)0xf < ppiVar28[3]) {
                    ppiVar24 = (int64_t **)*ppiVar28;
                }
                ppiVar20 = ppiVar35;
                if ((int64_t *)0xf < ppiVar35[3]) {
                    ppiVar20 = (int64_t **)*ppiVar35;
                }
            } while (ppiVar35[2] != ppiVar28[2]);
            if (ppiVar35[2] == (int64_t *)0x0) break;
            *(undefined8 *)(puVar30 + -8) = 0x18007f442;
            iVar13 = func_0x000180497f30(ppiVar20, ppiVar24);
        } while (iVar13 != 0);
joined_r0x00018007f45e:
        ppiVar20 = ppiVar28;
        ppiVar24 = ppiVar35;
        ppiVar28 = ppiVar20 + 4;
        if (ppiVar28 != ppiVar33) {
            ppiVar25 = ppiVar28;
            if ((int64_t *)0xf < ppiVar20[7]) {
                ppiVar25 = (int64_t **)*ppiVar28;
            }
            ppiVar21 = ppiVar24;
            if ((int64_t *)0xf < ppiVar24[3]) {
                ppiVar21 = (int64_t **)*ppiVar24;
            }
            if (ppiVar24[2] == ppiVar20[6]) goto code_r0x00018007f48c;
            goto code_r0x00018007f49a;
        }
        ppiVar24 = ppiVar24 + 4;
        if (ppiVar24 != ppiVar33) {
            ppiVar28 = *(int64_t ***)(arg2 + 0x68);
            for (; ppiVar33 != ppiVar28; ppiVar33 = ppiVar33 + 4) {
                if (ppiVar24 != ppiVar33) {
                    piVar15 = ppiVar24[3];
                    if ((int64_t *)0xf < piVar15) {
                        piVar22 = *ppiVar24;
                        piVar26 = (int64_t *)((int64_t)piVar15 + 1);
                        if ((int64_t *)0xfff < piVar26) {
                            if (0x1f < (uint64_t)((int64_t)piVar22 + (-8 - (int64_t)(int64_t *)piVar22[-1])))
                            goto code_r0x00018007f63f;
                            piVar26 = piVar15 + 5;
                            piVar22 = (int64_t *)piVar22[-1];
                        }
                        *(undefined8 *)(puVar30 + -8) = 0x18007f571;
                        fcn.180459c3c(piVar22, piVar26);
                    }
                    ppiVar24[2] = (int64_t *)0x0;
                    ppiVar24[3] = (int64_t *)0xf;
                    *(undefined *)ppiVar24 = 0;
                    uVar7 = *(undefined4 *)((int64_t)ppiVar33 + 4);
                    uVar8 = *(undefined4 *)(ppiVar33 + 1);
                    uVar9 = *(undefined4 *)((int64_t)ppiVar33 + 0xc);
                    *(undefined4 *)ppiVar24 = *(undefined4 *)ppiVar33;
                    *(undefined4 *)((int64_t)ppiVar24 + 4) = uVar7;
                    *(undefined4 *)(ppiVar24 + 1) = uVar8;
                    *(undefined4 *)((int64_t)ppiVar24 + 0xc) = uVar9;
                    uVar7 = *(undefined4 *)((int64_t)ppiVar33 + 0x14);
                    uVar8 = *(undefined4 *)(ppiVar33 + 3);
                    uVar9 = *(undefined4 *)((int64_t)ppiVar33 + 0x1c);
                    *(undefined4 *)(ppiVar24 + 2) = *(undefined4 *)(ppiVar33 + 2);
                    *(undefined4 *)((int64_t)ppiVar24 + 0x14) = uVar7;
                    *(undefined4 *)(ppiVar24 + 3) = uVar8;
                    *(undefined4 *)((int64_t)ppiVar24 + 0x1c) = uVar9;
                    ppiVar33[2] = (int64_t *)0x0;
                    ppiVar33[3] = (int64_t *)0xf;
                    *(undefined *)ppiVar33 = 0;
                }
                ppiVar24 = ppiVar24 + 4;
            }
            ppiVar33 = *(int64_t ***)(arg2 + 0x68);
            for (ppiVar28 = ppiVar24; ppiVar28 != ppiVar33; ppiVar28 = ppiVar28 + 4) {
                *(undefined8 *)(puVar30 + -8) = 0x18007f5bf;
                fcn.180004e40(ppiVar28);
            }
            *(int64_t ***)(arg2 + 0x68) = ppiVar24;
        }
    }
code_r0x00018007f5cd:
    iVar27 = *(int64_t *)(arg2 + 0x68);
    if (0x14 < (uint64_t)(iVar27 - *arg1 >> 5)) {
        iVar34 = *arg1 + 0x280;
        for (iVar29 = iVar34; iVar29 != iVar27; iVar29 = iVar29 + 0x20) {
            *(undefined8 *)(puVar30 + -8) = 0x18007f5fd;
            fcn.180004e40(iVar29);
        }
        *(int64_t *)(arg2 + 0x68) = iVar34;
    }
code_r0x00018007f60b:
    *(undefined8 *)(puVar30 + -8) = 0x18007f61b;
    func_0x000180459870(*(uint64_t *)(puVar30 + 0x98) ^ (uint64_t)puVar30);
    return;
code_r0x00018007f48c:
    ppiVar35 = ppiVar24;
    if (ppiVar24[2] != (int64_t *)0x0) {
        *(undefined8 *)(puVar30 + -8) = 0x18007f496;
        iVar13 = func_0x000180497f30(ppiVar21, ppiVar25);
        if (iVar13 != 0) {
code_r0x00018007f49a:
            ppiVar35 = ppiVar24 + 4;
            if (ppiVar35 != ppiVar28) {
                piVar15 = ppiVar24[7];
                if ((int64_t *)0xf < piVar15) {
                    piVar22 = *ppiVar35;
                    piVar26 = (int64_t *)((int64_t)piVar15 + 1);
                    if ((int64_t *)0xfff < piVar26) {
                        if (0x1f < (uint64_t)((int64_t)piVar22 + (-8 - (int64_t)(int64_t *)piVar22[-1])))
                        goto code_r0x00018007f63f;
                        piVar26 = piVar15 + 5;
                        piVar22 = (int64_t *)piVar22[-1];
                    }
                    *(undefined8 *)(puVar30 + -8) = 0x18007f4df;
                    fcn.180459c3c(piVar22, piVar26);
                }
                ppiVar24[6] = (int64_t *)0x0;
                ppiVar24[7] = (int64_t *)0xf;
                *(undefined *)ppiVar35 = 0;
                uVar7 = *(undefined4 *)((int64_t)ppiVar20 + 0x24);
                uVar8 = *(undefined4 *)(ppiVar20 + 5);
                uVar9 = *(undefined4 *)((int64_t)ppiVar20 + 0x2c);
                *(undefined4 *)ppiVar35 = *(undefined4 *)ppiVar28;
                *(undefined4 *)((int64_t)ppiVar24 + 0x24) = uVar7;
                *(undefined4 *)(ppiVar24 + 5) = uVar8;
                *(undefined4 *)((int64_t)ppiVar24 + 0x2c) = uVar9;
                uVar7 = *(undefined4 *)((int64_t)ppiVar20 + 0x34);
                uVar8 = *(undefined4 *)(ppiVar20 + 7);
                uVar9 = *(undefined4 *)((int64_t)ppiVar20 + 0x3c);
                *(undefined4 *)(ppiVar24 + 6) = *(undefined4 *)(ppiVar20 + 6);
                *(undefined4 *)((int64_t)ppiVar24 + 0x34) = uVar7;
                *(undefined4 *)(ppiVar24 + 7) = uVar8;
                *(undefined4 *)((int64_t)ppiVar24 + 0x3c) = uVar9;
                ppiVar20[6] = (int64_t *)0x0;
                ppiVar20[7] = (int64_t *)0xf;
                *(undefined *)ppiVar28 = 0;
            }
        }
    }
    goto joined_r0x00018007f45e;
}

// ============================================================
// Function: FUN_18007f660
// Address: 0x18007f660
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18007f660(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x20) {
        fcn.180004e40(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x20)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18007f670
// Address: 0x18007f670
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18007f660(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x20) {
        fcn.180004e40(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x20)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18007f6b7
// Address: 0x18007f6b7
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18007f660(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x20) {
        fcn.180004e40(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x20)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18007f6f0
// Address: 0x18007f6f0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007f6f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18007f778;
        fcn.180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x20 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x20 + arg2;
    return;
}

// ============================================================
// Function: FUN_18007f717
// Address: 0x18007f717
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007f6f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18007f778;
        fcn.180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x20 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x20 + arg2;
    return;
}

// ============================================================
// Function: FUN_18007f752
// Address: 0x18007f752
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18007f6f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x20) {
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffe0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18007f778;
        fcn.180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x20 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x20 + arg2;
    return;
}

// ============================================================
// Function: FUN_18007f7b0
// Address: 0x18007f7b0
// Size: 570 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18007f7b0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    bool bVar3;
    uint32_t uVar4;
    undefined8 *puVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int64_t iVar8;
    char in_DL;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_40h;
    
    iVar8 = *(int32_t *)(*(int64_t *)arg1 + 4) + arg1;
    if (*(uint32_t *)(iVar8 + 0x10) == 0) {
        if (*(int64_t *)(iVar8 + 0x50) != 0) {
            func_0x00018000fad0();
        }
        if ((in_DL == '\0') && ((*(uint8_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x18 + arg1) & 1) != 0)) {
            piVar1 = *(int64_t **)(*(int64_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x40 + arg1) + 8);
            var_70h = (int64_t)piVar1;
            (**(code **)(*piVar1 + 8))(piVar1);
            iVar8 = func_0x00018000a390(&var_78h);
            if (piVar1 != (int64_t *)0x0) {
                puVar5 = (undefined8 *)(**(code **)(*piVar1 + 0x10))(piVar1);
                if (puVar5 != (undefined8 *)0x0) {
                    (**(code **)*puVar5)(puVar5, 1);
                }
            }
            piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
            if ((*(uint8_t **)piVar1[7] == (uint8_t *)0x0) || (*(int32_t *)piVar1[10] < 1)) {
                uVar6 = (**(code **)(*piVar1 + 0x30))();
            } else {
                uVar6 = (uint64_t)**(uint8_t **)piVar1[7];
            }
            while ((int32_t)uVar6 != -1) {
                bVar3 = false;
                if ((*(uint8_t *)(*(int64_t *)(iVar8 + 0x18) + (uVar6 & 0xff) * 2) & 0x48) == 0)
                goto code_r0x00018007f8cf;
                uVar6 = func_0x00018000e0e0(*(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1));
            }
            bVar3 = true;
code_r0x00018007f8cf:
            if (bVar3) {
                iVar8 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
                uVar4 = 4;
                if (*(int64_t *)(iVar8 + 0x48 + arg1) != 0) {
                    uVar4 = 0;
                }
                uVar4 = uVar4 | *(uint32_t *)(iVar8 + 0x10 + arg1) & 0x14 | 3;
                *(uint32_t *)(iVar8 + 0x10 + arg1) = uVar4;
                uVar4 = uVar4 & *(uint32_t *)(iVar8 + 0x14 + arg1);
                if (uVar4 != 0) {
                    if ((uVar4 & 4) == 0) {
                        uVar9 = 0x1805aae00;
                        if ((uVar4 & 2) == 0) {
                            uVar9 = 0x1805aae18;
                        }
                    } else {
                        uVar9 = 0x1805aade8;
                    }
                    uVar7 = func_0x000180005e50(&var_78h, 1);
                    func_0x0001800069f0(&var_40h, uVar9, uVar7);
                    fcn.18045bae0(var_78h);
                    pcVar2 = (code *)swi(3);
                    uVar9 = (*pcVar2)();
                    return uVar9;
                }
            }
        }
        uVar9 = CONCAT71((unkint7)((uint64_t)*(int64_t *)arg1 >> 8), 
                         *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x10 + arg1) == 0);
    } else {
        uVar4 = 4;
        if (*(int64_t *)(iVar8 + 0x48) != 0) {
            uVar4 = 0;
        }
        uVar4 = uVar4 | *(uint32_t *)(iVar8 + 0x10) & 0x15 | 2;
        *(uint32_t *)(iVar8 + 0x10) = uVar4;
        uVar4 = uVar4 & *(uint32_t *)(iVar8 + 0x14);
        if (uVar4 != 0) {
            if ((uVar4 & 4) == 0) {
                uVar9 = 0x1805aae00;
                if ((uVar4 & 2) == 0) {
                    uVar9 = 0x1805aae18;
                }
            } else {
                uVar9 = 0x1805aade8;
            }
            uVar7 = func_0x000180005e50(&var_78h, 1);
            func_0x0001800069f0(&var_68h, uVar9, uVar7);
            fcn.18045bae0(var_78h);
            pcVar2 = (code *)swi(3);
            uVar9 = (*pcVar2)();
            return uVar9;
        }
        uVar9 = 0;
    }
    return uVar9;
}

